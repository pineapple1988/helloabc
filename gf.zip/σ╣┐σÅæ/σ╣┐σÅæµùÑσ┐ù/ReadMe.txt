这个是登录的: https://static.95508.com/mdss/mcube/674EA96201616-product/20181045/1.1.1.132_all/nebula/20181045_1.1.1.132.amr

这个是登录验证的: https://static.95508.com/mdss/mcube/674EA96201616-product/20181019/1.1.1.128_all/nebula/20181019_1.1.1.128.amr


这个是转账的: https://static.95508.com/mdss/mcube/674EA96201616-product/20181002/1.1.2.23_all/nebula/20181002_1.1.2.23.amr

主要看这几个文件中的逻辑:
transferValidate.js
transferProcess.js
bankCardTransfer.js
transferFail.js


关注下这个RPC的调用 transCode := "MP6342"

cgb_html/20181002_1.1.1.72.amr/20181002/cgb_new_transfer/transfer/transferValidate.js:1208		client.redirect("/cgb_new_transfer/transfer/transferFail.html", t)


cgb_trasnfer_html/cgb_new_transfer/transfer/electronicReceipt.html
cgb_trasnfer_html/cgb_new_transfer/transfer/resultPage.html
cgb_trasnfer_html/cgb_new_transfer/transfer/transferFail.html


client.redirect("/cgb_new_transfer/transfer/transferResult.html");
client.redirect("/cgb_new_transfer/transfer/transferFail.html");
client.redirect("/cgb_new_transfer/transfer/resultPage.html");


设备绑定
https://static.95508.com/mdss/mcube/674EA96201616-product/20181045/1.1.1.123_all/nebula/20181045_1.1.1.123.amr
