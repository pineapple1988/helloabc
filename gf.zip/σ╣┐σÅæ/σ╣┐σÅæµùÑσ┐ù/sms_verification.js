webpackJsonp([0], {
	"Jjv/": function(e, t) {
		e.exports = window.comComponent
	},
	bEMs: function(e, t, n) {
		"use strict";
		Object.defineProperty(t, "__esModule", {
			value: !0
		});
		var i = n("lRwf"),
			c = n.n(i),
			o = n("biPN"),
			a = n.n(o),
			r = {
				install: function(e, t) {
					e.filter("formatMoney", a.a.formatMoney), e.filter("formatBank", a.a.formatBank), e.filter("formatCode", a.a.formatCode), e.filter("formatName", a.a.formatName), e.filter("formatIdNumber", a.a.formatIdNumber), e.filter("formatPhone", a.a.formatPhone), e.filter("formatAllDate", a.a.formatAllDate), e.filter("parseDate", a.a.parseDate), e.filter("formatDate", a.a.formatDate), e.filter("phoneSeparated", a.a.phoneSeparated), e.filter("bankCardSeparated", a.a.bankCardSeparated), e.filter("transCertType", a.a.transCertType), e.filter("AccountCertType", a.a.AccountCertType), e.filter("AccountCurrencyType", a.a.AccountCurrencyType), e.filter("transUnit", a.a.transUnit), e.filter("transCurrencyType", a.a.transCurrencyType), e.filter("saveDecimal", a.a.saveDecimal), e.filter("rateFormat", a.a.rateFormat), e.filter("ellipsis", a.a.ellipsis), e.filter("dateFormat", a.a.dateFormat), e.filter("dateFormat2", a.a.dateFormat2)
				}
			},
			l = n("Jjv/"),
			u = n.n(l);
		c.a.config.productionTip = !1, c.a.use(r), c.a.use(u.a), c.a.config.errorHandler = function(e, t, n) {
			client.handleAlertContent(e)
		}, window.onerror = function(e, t, n, i, c) {
			return client.handleAlertContent({
				msg: e,
				url: t,
				line: n,
				col: i
			}), !0
		}, window.tools = a.a;
		var s = {
				data: function() {
					return {
						mobile: "",
						smsCode: "",
						isShow: !1,
						UUID: "",
						phoneType: "",
						userInfo: {}
					}
				},
				computed: {
					hasChecked: function() {
						return 6 === this.smsCode.length
					}
				},
				created: function() {
					var t = this;
					client.setTitleBar({
						leftCallback: function() {
							return t.goBack()
						}
					}), client.getUserInfo(!1).then(function(e) {
						t.mobile = e.body.mobileNo, t.certType = e.body.certType, t.userInfo = e.body, t.mobile ? t.init() : client.alert("温馨提示", "您的手机号已被占用，请携有效身份证件前往附近网点办理。", {
							button: "我知道了"
						}).then(function() {
							t.goBack()
						})
					}), client.getDeviceAndAppInfo().then(function(e) {
						t.UUID = e.UUID, t.phoneType = e.phoneType
					})
				},
				methods: {
					init: function() {
						var i = this;
						client.showLoading(), client.rpc("MP6390", {
							operateType: "03003",
							NOTE1: "PB_03003_FLAG_",
							NOTE2: "PB_03003_TIME_",
							NOTE3: "PB_03003_FLAG2_",
							flag1: "1"
						}).then(function(e) {
							client.debug(e);
							var t = e.temp2,
								n = e.temp1;
							if ("0" == t)
								if ("0" == i.certType) i.checkFace();
								else {
									if ("0" == n) return void client.alert("温馨提示", "当前操作需提供身份证，请前往柜台补充资料。", {
										button: "我知道了"
									}).then(function() {
										i.goBack()
									});
									i.isShow = !0
								}
							else "1" == t ? i.isShow = !0 : client.alert("温馨提示", "当前操作需进行人脸识别，请在7:30-19:00时间段办理。", {
								button: "我知道了"
							}).then(function() {
								i.goBack()
							})
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					checkFace: function() {
						this.getFaceSDK()
					},
					getFaceSDK: function() {
						var n = this,
							e = {
								operateType: "03003",
								channel: "001",
								cerType: "10100"
							};
						client.showLoading(), client.rpc("MP6469", e).then(function(e) {
							client.debug(e), client.hideLoading();
							var t = {};
							t.workTime = e.workTime, t.currencyTimes = e.currencyTimes, t.flag = e.flag, t.countTime = e.countTime, t.collectActionType = e.collectActionType, t.uploadPhoNum = e.uploadPhoNum, t.dayTryTime = e.dayTryTime, t.daytriedNum = e.daytriedNum, t.attackIsProhibited = e.attackIsProhibited, "0" == e.attackIsProhibited ? (client.trackEvent({
								eventId: "DKRL0003",
								label: "登录二次验证",
								data: "被识别为攻击"
							}), client.alert("温馨提示", "人脸识别匹配失败，为保护您的账户安全，请明天再试！").then(function() {
								n.goBack()
							})) : e.dayTryTime - e.daytriedNum <= 0 ? (client.trackEvent({
								eventId: "DKRL0003",
								label: "登录二次验证",
								data: "使用次数超限"
							}), client.alert("温馨提示", "尊敬的客户，您今天的人脸识别次数已经超限，请明天再试。", {
								button: "我知道了"
							}).then(function() {
								n.goBack()
							})) : n.openFace(t)
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					openFace: function(t) {
						var n = this;
						client.hideLoading(), client.openBaiduFace({
							overtime: t.workTime,
							collectActionType: t.collectActionType
						}).then(function(e) {
							client.debug(e), "1" == e.errorCode ? (client.trackEvent({
								eventId: "DKRL0004",
								label: "登录二次验证",
								data: ""
							}), n.goBack()) : "0" == e.identification_reslut ? e.aeye_data ? n.postImg(e) : client.alert("获取人脸图片失败，请重试。", "", {
								button: "重试"
							}).then(function() {
								n.openFace(t)
							}) : n.getFaceFailed(e, t)
						})
					},
					postImg: function() {
						var t = this,
							e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
							n = {
								photo1: e.aeye_data,
								operateType: "03003",
								channel: "001",
								token: e.token,
								equipment_id: e.uuid,
								equipment_type: e.mobileModel,
								equipment_uuid: e.UUID,
								flag: "1",
								temp1: "3.0",
								eAccountFlag: "Y"
							};
						client.showLoading(), client.rpc("MP6484", n).then(function(e) {
							client.hideLoading(), client.debug(e), "0" == e.resultFlag ? (client.trackEvent({
								eventId: "DKRL0003",
								label: "登录二次验证",
								data: "识别成功"
							}), t.isShow = !0) : (client.trackEvent({
								eventId: "DKRL0003",
								label: "登录二次验证",
								data: "识别失败" + e.em
							}), client.alert("人脸识别验证失败。", "", {
								button: "重试"
							}).then(function(e) {
								e.ok && t.checkFace()
							}))
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					goBack: function() {
						client.cleanUserInfo(), client.popWindow(-1)
					},
					login_success_fun: function() {
						client.popWindow(-1)
					},
					getPhoneMsg: function() {
						client.showLoading(), client.rpc("MP6476", {
							srcChannel: "CS",
							busCode: "YB",
							SMSID: "M1",
							TEMPLATEID: "081M100104",
							STDINFOTYP: "安全验证"
						}).then(function() {
							client.hideLoading(), client.toast("短信验证码已发送至您手机，2分钟内有效。")
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					commit_query: function() {
						this.Requet_MP6023()
					},
					Requet_MP6023: function() {
						var t = this,
							e = {
								srcChannel: "CS",
								busCode: "YB",
								mobileNo: this.mobile,
								smsCode: this.smsCode
							};
						client.showLoading(), client.rpc("MP6478", e).then(function(e) {
							t.mp_currentSID = e.mp_currentSID, client.silenceLogin().then(function() {
								t.Request_MP6389()
							}).catch(function(e) {
								client.hideLoading(), client.alert(e)
							})
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					check_deviceName: function(t) {
						var n = this,
							i = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "";
						client.inputAlert("提示", "请输入设备名称", {
							message: "是否将此设备添加为绑定设备",
							presetInputContent: t,
							okButton: "是",
							cancelButton: "否"
						}).then(function(e) {
							if (e.ok) {
								if ("" === (t = e.inputContent)) return void client.alert("设备名称不能为空。");
								RegExp(/[(#)(~)($)(@)(!)(*)(^)(<)(>)(")(%)(&)]+/).test(t) ? client.alert("设备名称不能包含非法字符。", "", {
									onButtono: "确定"
								}).then(function(e) {
									e.ok && n.check_deviceName(t, i)
								}) : n.Requet_MP6017(t, i)
							} else n.login_success_fun()
						})
					},
					Requet_MP6017: function(t, n) {
						var i = this,
							e = {
								srcChannel: "CS",
								flag: "1",
								withdrawPwd: n
							};
						client.rpc("MP6017", e).then(function(e) {
							client.hideLoading(), "0" === e.resultFlag ? i.Requet_MP6013(t, n) : client.alert("温馨提示", "您绑定的设备已超过" + e.maxNum + "台，将替换掉最早绑定的设备。", {
								okButton: "确定"
							}).then(function(e) {
								e.ok && i.Requet_MP6013(t, n)
							})
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					Requet_MP6013: function(n, i) {
						var c = this;
						client.getDeviceFingerprint().then(function(e) {
							var t = {
								srcChannel: "CS",
								deviceName: n,
								mp_currentSID: c.mp_currentSID,
								flag: "1",
								withdrawPwd: i
							};
							client.rpc("MP6013", t).then(function() {
								client.hideLoading(), c.login_success_fun()
							}).catch(function(e) {
								client.hideLoading();
								var t = client.handleAlertContent(e).newMessage;
								client.toast(t), c.login_success_fun()
							})
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					},
					Request_MP6389: function() {
						var t = this;
						client.getDeviceFingerprint().then(function(e) {
							client.rpc("MP7060", {
								withdrawPwd: e.result,
								deviceId: t.UUID
							}).then(function() {
								client.hideLoading(), "1" != t.userInfo.custDevLockStatus || "2" != t.userInfo.deviceStatus && "0" != t.userInfo.deviceStatus ? t.login_success_fun() : t.check_deviceName(t.phoneType, e.result)
							}).catch(client.handleError)
						}).catch(client.handleError)
					},
					getFaceFailed: function(e, t) {
						var n = this;
						client.showLoading();
						var i = {
								"-1": "超时",
								1: "头部偏低",
								2: "头部偏高",
								3: "头部偏左",
								4: "头部偏右",
								5: "光照不足",
								6: "没有检测到人脸",
								7: "",
								8: "",
								9: "图像模糊",
								10: "左眼有遮挡",
								11: "右眼有遮挡",
								12: "鼻子有遮挡",
								13: "嘴巴有遮挡",
								14: "左脸颊有遮挡",
								15: "右脸颊有遮挡",
								16: "下颚有遮挡",
								17: "太近",
								18: "太远",
								19: "出框",
								20: "眨眨眼",
								21: "张大嘴",
								22: "向左摇头",
								23: "向右摇头",
								24: "向上抬头",
								25: "向下低头",
								26: "摇摇头",
								27: "完成一个活体动作",
								28: "鉴权失败",
								29: "鉴权失败",
								30: "鉴权失败",
								31: "鉴权失败",
								32: "鉴权失败",
								33: "鉴权失败",
								34: "鉴权失败",
								35: "鉴权失败",
								36: "超时",
								37: "条件满足"
							},
							c = {
								srcChannel: "CS",
								channel: "001",
								operateType: "03003",
								certType: this.userInfo.certType,
								result: e.identification_reslut,
								failedCode: e.identification_reslut,
								message: i[e.identification_reslut],
								version: e.version,
								attackIsProhibited: t.attackIsProhibited
							};
						client.trackEvent({
							eventId: "DKRL0003",
							label: "登录二次验证",
							data: "识别失败" + i[e.identification_reslut]
						}), client.rpc("MP6474", c).then(function() {
							client.hideLoading(), setTimeout(function() {
								n.openFace(t)
							}, 300)
						}).catch(function(e) {
							client.hideLoading(), client.alert(e)
						})
					}
				}
			},
			d = {
				render: function() {
					var t = this,
						e = t.$createElement,
						n = t._self._c || e;
					return n("div", {
						directives: [{
							name: "show",
							rawName: "v-show",
							value: t.isShow,
							expression: "isShow"
						}],
						staticClass: "relieve-bind"
					}, [n("div", [n("ynet-cell", {
						attrs: {
							title: "手机号",
							rightArrow: !1
						}
					}, [t._v(t._s(t._f("formatPhone")(t.mobile)))]), t._v(" "), n("ynet-msg-input", {
						on: {
							clickCode: t.getPhoneMsg
						},
						model: {
							value: t.smsCode,
							callback: function(e) {
								t.smsCode = e
							},
							expression: "smsCode"
						}
					})], 1), t._v(" "), n("div", {
						staticClass: "ynet-btn-box mt80 pb60"
					}, [n("ynet-button", {
						attrs: {
							disabled: !t.hasChecked,
							interval: 5e3
						},
						on: {
							"click-native": t.commit_query
						}
					}, [t._v("提交")])], 1)])
				},
				staticRenderFns: []
			};
		var f = n("VU/8")(s, d, !1, function(e) {
			n("yDlN")
		}, null, null).exports;
		window.__VUE__ = new c.a({
			el: "#app",
			template: "<App />",
			components: {
				App: f
			}
		})
	},
	biPN: function(e, t) {
		e.exports = window.tools
	},
	lRwf: function(e, t) {
		e.exports = window.Vue
	},
	yDlN: function(e, t) {}
}, ["bEMs"]);
