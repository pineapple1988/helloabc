#line 1 "/Users/soft/Desktop/workpalce/guangfa/guangfaTweak/guangfaTweak/guangfaTweak.xm"


#if TARGET_OS_SIMULATOR
#error Do not support the simulator, please use the real iPhone Device.
#endif

#import <UIKit/UIKit.h>
#import "Log.h"

static __attribute__((constructor)) void _logosLocalCtor_2da25fec(int __unused argc, char __unused **argv, char __unused **envp){
    
    NSLog(@"pineapple 广发入口点840");
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Lua"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:LuaPath]){
        [fileManager removeItemAtPath:LuaPath error:nil];
    }
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"httpsLog.txt"];    NSLog(@"pineapple LLLL----%@",path);
    
}





















































#include <substrate.h>
#if defined(__clang__)
#if __has_feature(objc_arc)
#define _LOGOS_SELF_TYPE_NORMAL __unsafe_unretained
#define _LOGOS_SELF_TYPE_INIT __attribute__((ns_consumed))
#define _LOGOS_SELF_CONST const
#define _LOGOS_RETURN_RETAINED __attribute__((ns_returns_retained))
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif

@class CGBAppUtils; @class TDUtility; @class INPreferences; @class DTURLRequestOperation; 
static void (*_logos_orig$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$)(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST, SEL, id); static void _logos_method$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST, SEL, id); static id (*_logos_orig$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$)(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST, SEL, id); static id _logos_method$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST, SEL, id); static void (*_logos_meta_orig$_ungrouped$INPreferences$requestSiriAuthorization$)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id); static void _logos_meta_method$_ungrouped$INPreferences$requestSiriAuthorization$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id); static _Bool (*_logos_meta_orig$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static _Bool _logos_meta_method$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static _Bool (*_logos_meta_orig$_ungrouped$TDUtility$isJailbroken)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static _Bool _logos_meta_method$_ungrouped$TDUtility$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); 

#line 75 "/Users/soft/Desktop/workpalce/guangfa/guangfaTweak/guangfaTweak/guangfaTweak.xm"








static void _logos_method$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1){
    NSLog(@"pineapple DTURLRequestOperation gzipAndEncrypt callStack --- %@",[NSThread callStackSymbols]);
    NSLog(@"pineapple DTURLRequestOperation gzipAndEncrypt arg1 --- %@",arg1);
    [Log appendData:arg1 fileName:@"gunzipAndDecrypt"];
    _logos_orig$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$(self, _cmd, arg1);
}

static id _logos_method$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$(_LOGOS_SELF_TYPE_NORMAL DTURLRequestOperation* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1){
    NSLog(@"pineapple DTURLRequestOperation gunzipAndDecrypt callStack --- %@",[NSThread callStackSymbols]);
    NSLog(@"pineapple DTURLRequestOperation gunzipAndDecrypt arg1 --- %@",arg1);
    id ret = _logos_orig$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$(self, _cmd, arg1);
    NSLog(@"pineapple DTURLRequestOperation gunzipAndDecrypt ret --- %@",ret);
    [Log appendData:ret fileName:@"gunzipAndDecrypt"];
    return ret;
}




































































static void _logos_meta_method$_ungrouped$INPreferences$requestSiriAuthorization$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id handler){
    NSLog(@"pineapple INPreferences requestSiriAuthorization callStack --- %@",[NSThread callStackSymbols]);
    NSLog(@"pineapple INPreferences requestSiriAuthorization status1: %@",handler);
    handler = 0;
    _logos_meta_orig$_ungrouped$INPreferences$requestSiriAuthorization$(self, _cmd, handler);
    NSLog(@"pineapple INPreferences requestSiriAuthorization status2: %@",handler);
}




static _Bool _logos_meta_method$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    HBLogDebug(@"+[<CGBAppUtils: %p> hx_checkDeviceJailBreakState]", self);
    _Bool r = _logos_meta_orig$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState(self, _cmd);
    NSLog(@"pineapple CGBAppUtils hx_checkDeviceJailBreakState ret--- %d", r);
    return NO;
}



static _Bool _logos_meta_method$_ungrouped$TDUtility$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    HBLogDebug(@"+[<TDUtility: %p> isJailbroken]", self);
    _Bool r = _logos_meta_orig$_ungrouped$TDUtility$isJailbroken(self, _cmd);
    NSLog(@"pineapple TDUtility isJailbroken ret--- %d", r);
    return NO;
}






static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$DTURLRequestOperation = objc_getClass("DTURLRequestOperation"); MSHookMessageEx(_logos_class$_ungrouped$DTURLRequestOperation, @selector(gzipAndEncrypt:), (IMP)&_logos_method$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$, (IMP*)&_logos_orig$_ungrouped$DTURLRequestOperation$gzipAndEncrypt$);MSHookMessageEx(_logos_class$_ungrouped$DTURLRequestOperation, @selector(gunzipAndDecrypt:), (IMP)&_logos_method$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$, (IMP*)&_logos_orig$_ungrouped$DTURLRequestOperation$gunzipAndDecrypt$);Class _logos_class$_ungrouped$INPreferences = objc_getClass("INPreferences"); Class _logos_metaclass$_ungrouped$INPreferences = object_getClass(_logos_class$_ungrouped$INPreferences); MSHookMessageEx(_logos_metaclass$_ungrouped$INPreferences, @selector(requestSiriAuthorization:), (IMP)&_logos_meta_method$_ungrouped$INPreferences$requestSiriAuthorization$, (IMP*)&_logos_meta_orig$_ungrouped$INPreferences$requestSiriAuthorization$);Class _logos_class$_ungrouped$CGBAppUtils = objc_getClass("CGBAppUtils"); Class _logos_metaclass$_ungrouped$CGBAppUtils = object_getClass(_logos_class$_ungrouped$CGBAppUtils); MSHookMessageEx(_logos_metaclass$_ungrouped$CGBAppUtils, @selector(hx_checkDeviceJailBreakState), (IMP)&_logos_meta_method$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState, (IMP*)&_logos_meta_orig$_ungrouped$CGBAppUtils$hx_checkDeviceJailBreakState);Class _logos_class$_ungrouped$TDUtility = objc_getClass("TDUtility"); Class _logos_metaclass$_ungrouped$TDUtility = object_getClass(_logos_class$_ungrouped$TDUtility); MSHookMessageEx(_logos_metaclass$_ungrouped$TDUtility, @selector(isJailbroken), (IMP)&_logos_meta_method$_ungrouped$TDUtility$isJailbroken, (IMP*)&_logos_meta_orig$_ungrouped$TDUtility$isJailbroken);} }
#line 198 "/Users/soft/Desktop/workpalce/guangfa/guangfaTweak/guangfaTweak/guangfaTweak.xm"
