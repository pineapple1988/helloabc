//
//  Log.m
//  mingshenglibDylib
//
//  Created by digua on 2019/6/15.
//  Copyright © 2019年 digua. All rights reserved.
//

#import "Log.h"
@implementation Log

void append(NSString *msg){
    
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"logfile.txt"];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[msg dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}

+(void) append:(NSMutableDictionary*)dictmsg fileName:(NSString*)strFileName{
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Lua"];
    NSError *error;
    [[NSFileManager defaultManager] createDirectoryAtPath:LuaPath withIntermediateDirectories:YES attributes:nil error:&error];
    
    NSLog(@"LLLL---%@",error);
    NSString *path = [LuaPath stringByAppendingPathComponent:strFileName];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    
    NSString* msg = [Log dictionaryToJson:dictmsg];
    NSString* strAuthorization = [dictmsg objectForKey:@"Authorization"];
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[strAuthorization dataUsingEncoding:NSUTF8StringEncoding]];
    NSString * strN = @"\r";
    [handle writeData:[strN dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}

+(void) appendStr:(NSString*)strMsg fileName:(NSString*)strFileName{
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [documentsDirectory stringByAppendingPathComponent:@"Lua"];
    [[NSFileManager defaultManager] createDirectoryAtPath:LuaPath withIntermediateDirectories:YES attributes:nil error:nil];
    strFileName=[strFileName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    NSString *path = [LuaPath stringByAppendingPathComponent:strFileName];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    


    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[strMsg dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}

+(NSString*) readLuaFile:(NSString*)strFileName{
    
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [documentsDirectory stringByAppendingPathComponent:@"Lua"];
    [[NSFileManager defaultManager] createDirectoryAtPath:LuaPath withIntermediateDirectories:YES attributes:nil error:nil];
    strFileName=[strFileName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    NSString *path = [LuaPath stringByAppendingPathComponent:strFileName];
    
    NSLog(@"pineapple readLuaFile path: %@",path);
    
    NSData *reader = [NSData dataWithContentsOfFile:path];
    NSLog(@"pineapple readLuaFile reader length: %tu",reader.length);
    NSLog(@"pineapple readLuaFile reader : %@",reader);

    NSData *base64Data = [reader base64EncodedDataWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    NSLog(@"pineapple readLuaFile base64Data : %@",base64Data);
    
    NSString * ret = [NSString stringWithUTF8String:(const char *)[base64Data bytes]];
    NSLog(@"pineapple readLuaFile ret : %@",ret);
    
    return ret;
}

+(NSData*) readLuaFileNSData:(NSString*)strFileName{
    
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [documentsDirectory stringByAppendingPathComponent:@"Lua"];
    [[NSFileManager defaultManager] createDirectoryAtPath:LuaPath withIntermediateDirectories:YES attributes:nil error:nil];
    strFileName=[strFileName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    NSString *path = [LuaPath stringByAppendingPathComponent:strFileName];
    
    NSLog(@"pineapple readLuaFile path: %@",path);
    
    NSData *reader = [NSData dataWithContentsOfFile:path];
    NSLog(@"pineapple readLuaFile reader length: %tu",reader.length);
    NSLog(@"pineapple readLuaFile reader : %@",reader);
    
    return reader;
}

+(NSString *)convertToJsonData:(NSDictionary *)dict{
    NSLog(@"pineapple convertToJsonData");
    NSError *error;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    NSLog(@"pineapple convertToJsonData2");
    NSString *jsonString;
    
    if (!jsonData) {
        
        NSLog(@"%@",error);
        
    }else{
        
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSLog(@"pineapple convertToJsonData3");
        
    }
    
    NSLog(@"pineapple convertToJsonData4");
    
    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];
    
    NSRange range = {0,jsonString.length};
    
    //去掉字符串中的空格
    
    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];
    
    NSRange range2 = {0,mutStr.length};
    
    //去掉字符串中的换行符
    
    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    NSLog(@"pineapple convertToJsonData5");
    return mutStr;
    
}



+(void) appendData:(NSData*)strMsg fileName:(NSString*)strFileName{
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *LuaPath = [documentsDirectory stringByAppendingPathComponent:@"Lua"];
    [[NSFileManager defaultManager] createDirectoryAtPath:LuaPath withIntermediateDirectories:YES attributes:nil error:nil];
    strFileName=[strFileName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    NSString *path = [LuaPath stringByAppendingPathComponent:strFileName];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }

    
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:strMsg];
    NSString * strN = @"\r\n\r\n\r\n";
    [handle writeData:[strN dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}

+ (NSString*)dictionaryToJson:(NSMutableDictionary *)dic
{
    NSError *parseError = nil;
    @try {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:&parseError];
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    } @catch (NSException *exception) {
        NSLog(@"LLLL - %@",exception);
    } @finally {
        
    }
    
}

void _Log(NSString *prefix, const char *file, int lineNumber, const char *funcName, NSMutableDictionary *format,...) {
    NSString* strformat = [Log dictionaryToJson:format];
    va_list ap;
    va_start (ap, format);
    strformat = [strformat stringByAppendingString:@"\n"];
    NSString *msg = [[NSString alloc] initWithFormat:[NSString stringWithFormat:@"%@",strformat] arguments:ap];
    va_end (ap);
    fprintf(stderr,"%s%50s:%3d - %s",[prefix UTF8String], funcName, lineNumber, [msg UTF8String]);
    append(msg);
    
    
}


@end
