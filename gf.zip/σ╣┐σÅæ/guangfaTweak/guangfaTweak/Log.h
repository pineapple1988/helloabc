//
//  Log.h
//  mingshenglibDylib
//
//  Created by digua on 2019/6/15.
//  Copyright © 2019年 digua. All rights reserved.
//

#import <Foundation/Foundation.h>

//#define NSLog(args...) _Log(@"DEBUG ", __FILE__,__LINE__,__PRETTY_FUNCTION__,args);
@interface Log : NSObject
void _Log(NSString *prefix, const char *file, int lineNumber, const char *funcName, NSMutableDictionary *format,...);
+(NSString*)dictionaryToJson:(NSMutableDictionary *)dic;
+(void) append:(NSMutableDictionary*)dictmsg fileName:(NSString*)strFileName;
+(void) appendStr:(NSString*)strMsg fileName:(NSString*)strFileName;
+(void) appendData:(NSData*)strMsg fileName:(NSString*)strFileName;
+(NSString*) readLuaFile:(NSString*)strFileName;
+(NSData*) readLuaFileNSData:(NSString*)strFileName;
+(NSString *)convertToJsonData:(NSDictionary *)dict;
@end
