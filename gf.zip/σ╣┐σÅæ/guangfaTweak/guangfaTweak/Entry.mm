//
//  Entry.m
//  testLogosTweak
//
//  Created by soft on 10/30/19.
//

#import <Foundation/Foundation.h>
#import <substrate.h>
#import <mach-o/dyld.h>
#import <CommonCrypto/CommonDigest.h>




static inline void
hook_symbol(void* addr, void *new_func, void **old_func) {
    MSHookFunction(addr, new_func, old_func);
}

#define HOOK_SYMBOL(addr, func) hook_symbol(addr, (void*) new_##func, (void**) &orig_##func)
#define HOOK_DEF(ret, func, ...) \
static ret (*orig_##func)(__VA_ARGS__); \
static ret new_##func(__VA_ARGS__)

//void* (*orig_UIImagePNGRepresentation)(void* a1);
//
//void* new_UIImagePNGRepresentation(void* a1){
//    void *ret = orig_UIImagePNGRepresentation(a1);
//    NSLog(@"pineapple  addrUIImagePNGRepresentation ret %@ ", ret);
//    //    NSLog(@"fuckxbk---CLSMachOSliceGetExecutablePath--%@",r);
//    return ret;
//
//}


HOOK_DEF(int64_t, sub_10061480, int64_t a1, int64_t a2, int64_t a3, int64_t a4, int64_t a5, int64_t a6, int64_t a7, int64_t a8, int a9, int a10, int a11, int a12, void *a13, char *a14, int64_t a15, int64_t a16, void *a17, char *a18) {
    NSLog(@"pineapple  sub_10061480 in ");


    //long ret = orig_sub_10061480(x0, x1);


    return 3;
}

//HOOK_DEF(void*, addrUIImagePNGRepresentation, void* x0) {
//    NSLog(@"pineapple  addrUIImagePNGRepresentation in ");
//    //long data = x0+0x10;
//
//    void* ret = orig_addrUIImagePNGRepresentation(x0);
//
//    NSLog(@"pineapple  addrUIImagePNGRepresentation ret %@ ", ret);
//
//
//    return ret;
//}




__attribute__((constructor)) static void entry() {
//    long main_module_base = (long)_dyld_get_image_header(0);
//
//    long sub_10061480 = main_module_base + 0x61480;
//    HOOK_SYMBOL((void*)sub_10061480, sub_10061480);
    
    //hook 系统类函数
    // 二进制文件路劲
//    NSString *binaryFilepath = [[NSBundle mainBundle] executablePath];
//    NSLog(@"pineapple binaryFilepath = %@", binaryFilepath);
//    MSImageRef image = MSGetImageByName([binaryFilepath UTF8String]);
//    if (image) {
//        // 一定要加一个下划线
//        void *addrUIImagePNGRepresentation = MSFindSymbol(image,"_requestSiriAuthorization");
//        if (addrUIImagePNGRepresentation) {
//            MSHookFunction(addrUIImagePNGRepresentation,(void*)new_UIImagePNGRepresentation,(void**)&orig_UIImagePNGRepresentation);
//        } else {
//            NSLog(@"pineapple no found addrUIImagePNGRepresentation");
//        }
//    } else {
//        NSLog(@"pineapple no found image");
//    }
    
}

