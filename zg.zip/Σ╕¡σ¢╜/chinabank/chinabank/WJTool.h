
#import <Foundation/Foundation.h>
#import "./hookzz/hookzz.h"
#import "substrate.h"

@interface WJTool : NSObject

+ (NSString *)data2HexStr:(NSData *)data;
+ (void) print:(NSString*)log;
//+ (NSData *)zLibDecompressed:(NSData *)inData;

@end

#define WJLog(FORMAT, ...) printf("%s\n", [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);

#define rl_SEL(name) NSSelectorFromString(@""#name"")
#define rl_Class(name) NSClassFromString(@""#name"")


static inline void
hook_symbol(void* addr, void *new_func, void **old_func) {
    MSHookFunction(addr, new_func, old_func);
}
#define HOOK_SYMBOL(addr, func) hook_symbol(addr, (void*) new_##func, (void**) &orig_##func)
#define HOOK_DEF(ret, func, ...) \
static ret (*orig_##func)(__VA_ARGS__); \
static ret new_##func(__VA_ARGS__)

