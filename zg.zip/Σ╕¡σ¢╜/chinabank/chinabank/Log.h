//
//  Log.h
//  mingshenglibDylib
//
//  Created by digua on 2019/6/15.
//  Copyright © 2019年 digua. All rights reserved.
//

#import <Foundation/Foundation.h>

//#define NSLog(args...) _Log(@"DEBUG ", __FILE__,__LINE__,__PRETTY_FUNCTION__,args);
@interface Log : NSObject
void _Log(NSString *prefix, const char *file, int lineNumber, const char *funcName, NSMutableDictionary *format,...);
+(NSString*)dictionaryToJson:(NSMutableDictionary *)dic;
+(void)append:(NSMutableDictionary*)dictmsg fileName:(NSString*)strFileName;
+(void) appendStr:(NSString*)dictmsg fileName:(NSString*)strFileName;
+(NSData *)uncompressZippedData:(NSData *)compressedData;
+(NSData *)replaceNoUtf8:(NSData *)data;
+(NSString *)cleanUTF8:(NSData *)data;
@end
