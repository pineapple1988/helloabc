#line 1 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/chinabank/chinabank6.10/chinabank/chinabank/chinabank.xm"


#if TARGET_OS_SIMULATOR
#error Do not support the simulator, please use the real iPhone Device.
#endif

#import <UIKit/UIKit.h>
#import "Log.h"

@interface MABIIRequestEncryModel : NSObject

+(id)decryStringWithSafaData:(id)arg1 safeRandom:(id)arg2 timestamp:(id)arg3 encryType:(unsigned int)arg4;
@end

@interface MBDIFaceRecognitionViewController : NSObject

-(void)setActionArray:(id)arg1;
@end

static __attribute__((constructor)) void _logosLocalCtor_237d3b64(int __unused argc, char __unused **argv, char __unused **envp){

    NSLog(@"中国银行6.10入口点");
    
}



#include <substrate.h>
#if defined(__clang__)
#if __has_feature(objc_arc)
#define _LOGOS_SELF_TYPE_NORMAL __unsafe_unretained
#define _LOGOS_SELF_TYPE_INIT __attribute__((ns_consumed))
#define _LOGOS_SELF_CONST const
#define _LOGOS_RETURN_RETAINED __attribute__((ns_returns_retained))
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif

@class MBDIFaceRecognitionViewController; @class CloudwalkFaceSDK; @class SCModel; @class CWDeviceStatusManager; @class HLSchInfo; @class LFoundation; @class BWTSDKLogUpLoadModel; @class IFlySystemInfo; 
static bool (*_logos_meta_orig$_ungrouped$IFlySystemInfo$isJailbroken)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$IFlySystemInfo$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool (*_logos_orig$_ungrouped$SCModel$isJailBreak)(_LOGOS_SELF_TYPE_NORMAL SCModel* _LOGOS_SELF_CONST, SEL); static bool _logos_method$_ungrouped$SCModel$isJailBreak(_LOGOS_SELF_TYPE_NORMAL SCModel* _LOGOS_SELF_CONST, SEL); static bool (*_logos_meta_orig$_ungrouped$HLSchInfo$isJailbroken)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$HLSchInfo$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool (*_logos_meta_orig$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak1)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak1(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool (*_logos_meta_orig$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak2)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak2(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool (*_logos_meta_orig$_ungrouped$LFoundation$isJailbreak)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$LFoundation$isJailbreak(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool (*_logos_meta_orig$_ungrouped$CWDeviceStatusManager$isDeviceEscape)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static bool _logos_meta_method$_ungrouped$CWDeviceStatusManager$isDeviceEscape(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL); static void (*_logos_orig$_ungrouped$MBDIFaceRecognitionViewController$randomActions)(_LOGOS_SELF_TYPE_NORMAL MBDIFaceRecognitionViewController* _LOGOS_SELF_CONST, SEL); static void _logos_method$_ungrouped$MBDIFaceRecognitionViewController$randomActions(_LOGOS_SELF_TYPE_NORMAL MBDIFaceRecognitionViewController* _LOGOS_SELF_CONST, SEL); static long (*_logos_orig$_ungrouped$CloudwalkFaceSDK$cwGetHackerInfoByBestImage)(_LOGOS_SELF_TYPE_NORMAL CloudwalkFaceSDK* _LOGOS_SELF_CONST, SEL); static long _logos_method$_ungrouped$CloudwalkFaceSDK$cwGetHackerInfoByBestImage(_LOGOS_SELF_TYPE_NORMAL CloudwalkFaceSDK* _LOGOS_SELF_CONST, SEL); 

#line 27 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/chinabank/chinabank6.10/chinabank/chinabank/chinabank.xm"

static bool _logos_meta_method$_ungrouped$IFlySystemInfo$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}





static bool _logos_method$_ungrouped$SCModel$isJailBreak(_LOGOS_SELF_TYPE_NORMAL SCModel* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}





static bool _logos_meta_method$_ungrouped$HLSchInfo$isJailbroken(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}





static bool _logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak1(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}


static bool _logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak2(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}





static bool _logos_meta_method$_ungrouped$LFoundation$isJailbreak(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}





static bool _logos_meta_method$_ungrouped$CWDeviceStatusManager$isDeviceEscape(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd){
    
    return NO;
}




static void _logos_method$_ungrouped$MBDIFaceRecognitionViewController$randomActions(_LOGOS_SELF_TYPE_NORMAL MBDIFaceRecognitionViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
    [self setActionArray:@[@"向左转头，然后正对屏幕",@"闭眼，然后睁眼",@"张嘴",]];
}




static long _logos_method$_ungrouped$CloudwalkFaceSDK$cwGetHackerInfoByBestImage(_LOGOS_SELF_TYPE_NORMAL CloudwalkFaceSDK* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
    return 0;
}




























































































static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$IFlySystemInfo = objc_getClass("IFlySystemInfo"); Class _logos_metaclass$_ungrouped$IFlySystemInfo = object_getClass(_logos_class$_ungrouped$IFlySystemInfo); { MSHookMessageEx(_logos_metaclass$_ungrouped$IFlySystemInfo, @selector(isJailbroken), (IMP)&_logos_meta_method$_ungrouped$IFlySystemInfo$isJailbroken, (IMP*)&_logos_meta_orig$_ungrouped$IFlySystemInfo$isJailbroken);}Class _logos_class$_ungrouped$SCModel = objc_getClass("SCModel"); { MSHookMessageEx(_logos_class$_ungrouped$SCModel, @selector(isJailBreak), (IMP)&_logos_method$_ungrouped$SCModel$isJailBreak, (IMP*)&_logos_orig$_ungrouped$SCModel$isJailBreak);}Class _logos_class$_ungrouped$HLSchInfo = objc_getClass("HLSchInfo"); Class _logos_metaclass$_ungrouped$HLSchInfo = object_getClass(_logos_class$_ungrouped$HLSchInfo); { MSHookMessageEx(_logos_metaclass$_ungrouped$HLSchInfo, @selector(isJailbroken), (IMP)&_logos_meta_method$_ungrouped$HLSchInfo$isJailbroken, (IMP*)&_logos_meta_orig$_ungrouped$HLSchInfo$isJailbroken);}Class _logos_class$_ungrouped$BWTSDKLogUpLoadModel = objc_getClass("BWTSDKLogUpLoadModel"); Class _logos_metaclass$_ungrouped$BWTSDKLogUpLoadModel = object_getClass(_logos_class$_ungrouped$BWTSDKLogUpLoadModel); { MSHookMessageEx(_logos_metaclass$_ungrouped$BWTSDKLogUpLoadModel, @selector(p_isJailBreak1), (IMP)&_logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak1, (IMP*)&_logos_meta_orig$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak1);}{ MSHookMessageEx(_logos_metaclass$_ungrouped$BWTSDKLogUpLoadModel, @selector(p_isJailBreak2), (IMP)&_logos_meta_method$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak2, (IMP*)&_logos_meta_orig$_ungrouped$BWTSDKLogUpLoadModel$p_isJailBreak2);}Class _logos_class$_ungrouped$LFoundation = objc_getClass("LFoundation"); Class _logos_metaclass$_ungrouped$LFoundation = object_getClass(_logos_class$_ungrouped$LFoundation); { MSHookMessageEx(_logos_metaclass$_ungrouped$LFoundation, @selector(isJailbreak), (IMP)&_logos_meta_method$_ungrouped$LFoundation$isJailbreak, (IMP*)&_logos_meta_orig$_ungrouped$LFoundation$isJailbreak);}Class _logos_class$_ungrouped$CWDeviceStatusManager = objc_getClass("CWDeviceStatusManager"); Class _logos_metaclass$_ungrouped$CWDeviceStatusManager = object_getClass(_logos_class$_ungrouped$CWDeviceStatusManager); { MSHookMessageEx(_logos_metaclass$_ungrouped$CWDeviceStatusManager, @selector(isDeviceEscape), (IMP)&_logos_meta_method$_ungrouped$CWDeviceStatusManager$isDeviceEscape, (IMP*)&_logos_meta_orig$_ungrouped$CWDeviceStatusManager$isDeviceEscape);}Class _logos_class$_ungrouped$MBDIFaceRecognitionViewController = objc_getClass("MBDIFaceRecognitionViewController"); { MSHookMessageEx(_logos_class$_ungrouped$MBDIFaceRecognitionViewController, @selector(randomActions), (IMP)&_logos_method$_ungrouped$MBDIFaceRecognitionViewController$randomActions, (IMP*)&_logos_orig$_ungrouped$MBDIFaceRecognitionViewController$randomActions);}Class _logos_class$_ungrouped$CloudwalkFaceSDK = objc_getClass("CloudwalkFaceSDK"); { MSHookMessageEx(_logos_class$_ungrouped$CloudwalkFaceSDK, @selector(cwGetHackerInfoByBestImage), (IMP)&_logos_method$_ungrouped$CloudwalkFaceSDK$cwGetHackerInfoByBestImage, (IMP*)&_logos_orig$_ungrouped$CloudwalkFaceSDK$cwGetHackerInfoByBestImage);}} }
#line 189 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/chinabank/chinabank6.10/chinabank/chinabank/chinabank.xm"
