//
//  Log.m
//  mingshenglibDylib
//
//  Created by digua on 2019/6/15.
//  Copyright © 2019年 digua. All rights reserved.
//

#import "Log.h"

#import "zlib.h"
@implementation Log

void append(NSString *msg){
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"logfile.txt"];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[msg dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}

+(void) append:(NSMutableDictionary*)dictmsg fileName:(NSString*)strFileName{
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:strFileName];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    
    NSString* msg = [Log dictionaryToJson:dictmsg];
    NSString* strAuthorization = [dictmsg objectForKey:@"Authorization"];
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[msg dataUsingEncoding:NSUTF8StringEncoding]];
    NSString * strN = @"\r\n";
    [handle writeData:[strN dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}


+(void) appendStr:(NSMutableString*)dictmsg fileName:(NSString*)strFileName{
    // get path to Documents/somefile.txt
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:strFileName];
    
    // create if needed
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]){
        fprintf(stderr,"Creating file at %s",[path UTF8String]);
        [[NSData data] writeToFile:path atomically:YES];
    }
    
    
    // append
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:path];
    [handle truncateFileAtOffset:[handle seekToEndOfFile]];
    [handle writeData:[dictmsg dataUsingEncoding:NSUTF8StringEncoding]];
    NSString * strN = @"\r\n";
    [handle writeData:[strN dataUsingEncoding:NSUTF8StringEncoding]];
    [handle closeFile];
}


+ (NSString*)dictionaryToJson:(NSMutableDictionary *)dic
{
    NSError *parseError = nil;
    @try {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:&parseError];
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    } @catch (NSException *exception) {
        NSLog(@"LLLL - %@",exception);
    } @finally {
        
    }
    
}

void _Log(NSString *prefix, const char *file, int lineNumber, const char *funcName, NSMutableDictionary *format,...) {
    NSString* strformat = [Log dictionaryToJson:format];
    va_list ap;
    va_start (ap, format);
    strformat = [strformat stringByAppendingString:@"\n"];
    NSString *msg = [[NSString alloc] initWithFormat:[NSString stringWithFormat:@"%@",strformat] arguments:ap];
    va_end (ap);
    fprintf(stderr,"%s%50s:%3d - %s",[prefix UTF8String], funcName, lineNumber, [msg UTF8String]);
    append(msg);
}


//+(NSData *)uncompressZippedData:(NSData *)compressedData
//
//{
//    
//    
//    
//    if ([compressedData length] == 0) return compressedData;
//    
//    
//    
//    unsigned full_length = [compressedData length];
//    
//    
//    
//    unsigned half_length = [compressedData length] / 2;
//    
//    NSMutableData *decompressed = [NSMutableData dataWithLength: full_length + half_length];
//    
//    BOOL done = NO;
//    
//    int status;
//    
//    z_stream strm;
//    
//    strm.next_in = (Bytef *)[compressedData bytes];
//    
//    strm.avail_in = [compressedData length];
//    
//    strm.total_out = 0;
//    
//    strm.zalloc = Z_NULL;
//    
//    strm.zfree = Z_NULL;
//    
//    if (inflateInit2(&strm, (15+32)) != Z_OK) return nil;
//    
//    while (!done) {
//        
//        // Make sure we have enough room and reset the lengths.
//        
//        if (strm.total_out >= [decompressed length]) {
//            
//            [decompressed increaseLengthBy: half_length];
//            
//        }
//        
//        strm.next_out = [decompressed mutableBytes] + strm.total_out;
//        
//        strm.avail_out = [decompressed length] - strm.total_out;
//        
//        // Inflate another chunk.
//        
//        status = inflate (&strm, Z_SYNC_FLUSH);
//        
//        if (status == Z_STREAM_END) {
//            
//            done = YES;
//            
//        } else if (status != Z_OK) {
//            
//            break;
//            
//        }
//        
//        
//        
//    }
//    
//    if (inflateEnd (&strm) != Z_OK) return nil;
//    
//    // Set real length.
//    
//    if (done) {
//        
//        [decompressed setLength: strm.total_out];
//        
//        return [NSData dataWithData: decompressed];
//        
//    } else {
//        
//        return nil;
//        
//    }
//    
//}

//替换非utf8字符
//注意：如果是三字节utf-8，第二字节错误，则先替换第一字节内容(认为此字节误码为三字节utf8的头)，然后判断剩下的两个字节是否非法；
+ (NSData *)replaceNoUtf8:(NSData *)data
{
    char aa[] = {'A','A','A','A','A','A'}; //utf8最多6个字符，当前方法未使用
    NSMutableData *md = [NSMutableData dataWithData:data];
    int loc = 0;
    while (loc < [md length])
    {
        char buffer;
        [md getBytes:&buffer range:NSMakeRange(loc, 1)];
        if ((buffer & 0x80) == 0) //0xxx xxxx 1个Byte
        {
            loc++;
            continue;
        }
        else if ((buffer & 0xE0) == 0xC0) //110x xxxx 2个Byte
        {
            loc++; //此处可能越界，要判断
            if (loc >= md.length) { //此时的buffer已经是最后一个Byte
                loc--;
                //非法字符，将这个字符（一个byte）替换为A
                [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
                break;
            }
            [md getBytes:&buffer range:NSMakeRange(loc, 1)];
            if ((buffer & 0xC0) == 0x80) //10xx xxxx 第2个Byte
            {
                loc++;
                continue;
            }
            loc--;
            //非法字符，将这个字符（一个byte）替换为A
            [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
            loc++;
            continue;
        }
        else if ((buffer & 0xF0) == 0xE0) //1110 xxxx 3个Byte
        {
            loc++; //此处可能越界，要判断
            if (loc >= md.length) { //此时的buffer已经是最后一个Byte
                loc--;
                //非法字符，将这个字符（一个byte）替换为A
                [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
                break;
            }
            [md getBytes:&buffer range:NSMakeRange(loc, 1)];
            if ((buffer & 0xC0) == 0x80) //10xx xxxx 第2个Byte
            {
                loc++; //此处可能越界，要判断
                if (loc >= md.length) { //此时的buffer已经是最后一个Byte
                    loc--;
                    //非法字符，将这个字符（一个byte）替换为A
                    [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
                    break;
                }
                [md getBytes:&buffer range:NSMakeRange(loc, 1)];
                if ((buffer & 0xC0) == 0x80) //10xx xxxx 第3个Byte
                {
                    loc++;
                    continue;
                }
                loc--;
            }
            loc--;
            //非法字符，将这个字符（一个byte）替换为A
            [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
            loc++;
            continue;
        }
        else
        {
            //非法字符，将这个字符（一个byte）替换为A
            [md replaceBytesInRange:NSMakeRange(loc, 1) withBytes:aa length:1];
            loc++;
            continue;
        }
    }
    
    return md;
}



@end
