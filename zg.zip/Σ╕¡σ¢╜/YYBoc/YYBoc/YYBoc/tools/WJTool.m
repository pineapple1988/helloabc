
//#include <zlib.h>
#import "WJTool.h"

@implementation WJTool

+ (NSString *)data2HexStr:(NSData *)data
{
    NSString *(^ByteBuf2Str)(Byte *, int, int) = ^NSString *(Byte *buf, int len, int lineIndex) {
        
        NSMutableString *hexStr = [NSMutableString string];
        NSMutableString *charStr = [NSMutableString string];
        for (int i = 0; i < len; i++) {
            [hexStr appendFormat:@"%02X ", buf[i]];
            if (buf[i] >= 32 && buf[i] <= 126) {
                [charStr appendFormat:@"%c", buf[i]];
            } else {
                [charStr appendString:@"."];
            }
            
        }
        
        // 不到16字节用空格补
        if (len < 16) {
            for (int i = 0; i < (16-len)*3; i++) {
                [hexStr appendString:@" "];
            }
        }
        
        NSMutableString *rltStr = [NSMutableString string];
        NSString *lineStr = [NSString stringWithFormat:@"%08X", lineIndex*16];
        [rltStr appendString:lineStr];
        [rltStr appendString:@"   "];
        [rltStr appendString:hexStr];
        [rltStr appendString:@"   "];
        [rltStr appendString:charStr];
        return rltStr;
    };
    
    NSMutableString *appendStr = [NSMutableString string];
    [appendStr appendString:@"\n"];
    int curIndex = 0;
    int curLine = 0;
    while (curIndex < data.length)
    {
        NSUInteger len = data.length - curIndex > 16 ? 16 : data.length - curIndex;
        NSString *oneLineStr = ByteBuf2Str((Byte *)(data.bytes + curIndex), (int)len, curLine);
        [appendStr appendString:oneLineStr];
        [appendStr appendString:@"\n"];
        curIndex += len;
        curLine++;
    }
    [appendStr appendString:@"\n"];
    return appendStr;
}

+ (void) print:(NSString*)log {
    while (log.length > 0x380) {
        NSString* sub = [log substringToIndex:0x380];
        NSLog(@"[YYYYY]\n%@", sub);
        log = [log substringFromIndex:0x380];
    };
    NSLog(@"[YYYYY]\n%@", log);
}

@end
