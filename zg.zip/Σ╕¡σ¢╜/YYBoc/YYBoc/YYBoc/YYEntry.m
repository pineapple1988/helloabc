//
//  YYEntry.m
//  YYAlipay
//
//  Created by jj yy on 8/8/19.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <zlib.h>
#import <dlfcn.h>
#import <sys/sysctl.h>
#import "fishhook.h"
#import "tools/WJTool.h"
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonHMAC.h>

@interface AppID : NSObject
+(NSString*) createNewAppID;
@end

HOOK_DEF(void, sub_102537844, long x0, long x1) {
    NSMutableString* log = [[NSMutableString alloc] initWithString:@"=============图片加密===========\r\n"];
    
    long pIn = *(long*)x0;
    size_t inLen = *(size_t*)(x0 + 8);
    NSData* inData = [[NSData alloc] initWithBytes:(void*)pIn length:inLen];
    NSString* inStr = [NSString stringWithFormat:@"inData -> %@", [WJTool data2HexStr:inData]];
    [log appendString:inStr];
    
    orig_sub_102537844(x0, x1);
    
    long pOut = *(long*)x1;
    size_t outLen = *(size_t*)(x1 + 8);
    NSData* outData = [[NSData alloc] initWithBytes:(void*)pOut length:outLen];
    NSString* outStr = [NSString stringWithFormat:@"outData -> %@", [WJTool data2HexStr:outData]];
    [log appendString:outStr];
    [WJTool print:log];
}


__attribute__((constructor)) static void entry() {
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
           // 延迟执行
           dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
               [WJTool print:[[UIDevice currentDevice] model]];
//               [WJTool print:[rl_Class(AppID) createNewAppID]];
           });
    }];
    long main_module_base = (long)_dyld_get_image_header(0);
    NSString *pathHome = NSHomeDirectory();
    [WJTool print:[NSString stringWithFormat:@"main_moduld_base: %p \npath: %@", (void *)main_module_base, pathHome]];
    
//    long sub_102537844 = main_module_base + 0x2537844;
//    HOOK_SYMBOL((void*)sub_102537844, sub_102537844);
}
