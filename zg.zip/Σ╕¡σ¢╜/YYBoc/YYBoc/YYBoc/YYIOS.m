//
//  YYIOS.m
//
//  Created by jj yy on 2019/12/20.
//  Copyright © 2019 jj yy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <zlib.h>
#import <dlfcn.h>

#import <sys/sysctl.h>
#import "fishhook.h"
#import "tools/WJTool.h"
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonHMAC.h>
#import "Log.h"

HOOK_DEF(CCCryptorStatus, CCCrypt, CCOperation op, CCAlgorithm alg, CCOptions options, const void *key, size_t keyLength,
         const void *iv, const void *dataIn, size_t dataInLength, void *dataOut, size_t dataOutAvailable, size_t *dataOutMoved) {
    NSMutableString* log = [[NSMutableString alloc] initWithString:@"=============CCCrypt===========\r\n"];
    
    if (kCCEncrypt == op) {
        [log appendString:@"kCCEncrypt\r\n"];
    } else {
        [log appendString:@"kCCDecrypt\r\n"];
    }
    
    switch (alg) {
        case kCCAlgorithmAES:
            [log appendString:@"kCCAlgorithmAES\r\n"];
            break;
        case kCCAlgorithmDES:
            [log appendString:@"kCCAlgorithmDES\r\n"];
            break;
        case kCCAlgorithm3DES:
            [log appendString:@"kCCAlgorithm3DES\r\n"];
            break;
        case kCCAlgorithmCAST:
            [log appendString:@"kCCAlgorithmCAST\r\n"];
            break;
        case kCCAlgorithmRC4:
            [log appendString:@"kCCAlgorithmRC4\r\n"];
            break;
        case kCCAlgorithmRC2:
            [log appendString:@"kCCAlgorithmRC2\r\n"];
            break;
        case kCCAlgorithmBlowfish:
            [log appendString:@"kCCAlgorithmBlowfish\r\n"];
            break;
        default:
            [log appendString:@"unknown CCAlgorithm\r\n"];
            break;
    }
    
    switch (options) {
        case kCCOptionPKCS7Padding:
            [log appendString:@"kCCOptionPKCS7Padding\r\n"];
            break;
       case kCCOptionECBMode:
            [log appendString:@"kCCOptionECBMode\r\n"];
            break;
       case kCCOptionPKCS7Padding|kCCOptionECBMode:
            [log appendString:@"kCCOptionPKCS7Padding|kCCOptionECBMode\r\n"];
            break;
       default:
            [log appendString:@"unknown CCOptions\r\n"];
            break;
    }
    NSData* keyData = [[NSData alloc] initWithBytes:key length:keyLength];
    NSString* keyStr = [NSString stringWithFormat:@"keyDaya -> %@", [WJTool data2HexStr:keyData]];
    [log appendString:keyStr];
    
    if (iv != NULL) {
        NSData* ivData = [[NSData alloc] initWithBytes:iv length:0x10];
        NSString* ivStr = [NSString stringWithFormat:@"ivDaya -> %@", [WJTool data2HexStr:ivData]];
        [log appendString:ivStr];
    }
    
    NSData* inData = [[NSData alloc] initWithBytes:dataIn length:dataInLength];
    NSString* inStr = [NSString stringWithFormat:@"inData -> %@", [WJTool data2HexStr:inData]];
    [log appendString:inStr];
    
    CCCryptorStatus ret = orig_CCCrypt(op, alg, options, key, keyLength, iv, dataIn, dataInLength, dataOut, dataOutAvailable, dataOutMoved);
    
    NSData* outData = [[NSData alloc] initWithBytes:dataOut length:*dataOutMoved];
    NSString* outStr = [NSString stringWithFormat:@"outData -> %@", [WJTool data2HexStr:outData]];
    [log appendString:outStr];
    [WJTool print:log];
    
    [Log appendStr:log fileName:@"myLog.txt"];
    return ret;
}

HOOK_DEF(OSStatus, SecKeyEncrypt, SecKeyRef key, SecPadding padding, const uint8_t *plainText, size_t plainTextLen, uint8_t *cipherText, size_t *cipherTextLen) {
    NSMutableString* log = [[NSMutableString alloc] initWithString:@"=============SecKeyEncrypt===========\r\n"];
    NSString* keyStr = [NSString stringWithFormat:@"keyDaya -> %@", key];
    [log appendString:keyStr];
    switch (padding) {
        case kSecPaddingNone:
            [log appendString:@"kSecPaddingNone\r\n"];
            break;
        case kSecPaddingPKCS1:
            [log appendString:@"kSecPaddingPKCS1\r\n"];
            break;
        case kSecPaddingOAEP:
            [log appendString:@"kSecPaddingOAEP\r\n"];
            break;
        case kSecPaddingSigRaw:
            [log appendString:@"kSecPaddingSigRaw\r\n"];
            break;
        case kSecPaddingPKCS1MD2:
            [log appendString:@"kSecPaddingPKCS1MD2\r\n"];
            break;
        case kSecPaddingPKCS1MD5:
            [log appendString:@"kSecPaddingPKCS1MD5\r\n"];
            break;
        case kSecPaddingPKCS1SHA1:
            [log appendString:@"kSecPaddingPKCS1SHA1\r\n"];
            break;
        case kSecPaddingPKCS1SHA224:
            [log appendString:@"kSecPaddingPKCS1SHA224\r\n"];
            break;
        case kSecPaddingPKCS1SHA256:
            [log appendString:@"kSecPaddingPKCS1SHA256\r\n"];
            break;
        case kSecPaddingPKCS1SHA384:
            [log appendString:@"kSecPaddingPKCS1SHA384\r\n"];
            break;
        case kSecPaddingPKCS1SHA512:
            [log appendString:@"kSecPaddingPKCS1SHA512\r\n"];
            break;
        default:
            [log appendString:@"unknown padding\r\n"];
            break;
    }
    
    NSData* inData = [[NSData alloc] initWithBytes:plainText length:plainTextLen];
    NSString* inStr = [NSString stringWithFormat:@"inData -> %@", [WJTool data2HexStr:inData]];
    [log appendString:inStr];
    
    CCCryptorStatus ret = orig_SecKeyEncrypt(key, padding, plainText, plainTextLen, cipherText, cipherTextLen);
    
    NSData* outData = [[NSData alloc] initWithBytes:cipherText length:*cipherTextLen];
    NSString* outStr = [NSString stringWithFormat:@"outData -> %@", [WJTool data2HexStr:outData]];
    [log appendString:outStr];
    [WJTool print:log];
    [Log appendStr:log fileName:@"myLog.txt"];
    return ret;
}


HOOK_DEF(void, CCHmac, CCHmacAlgorithm algorithm, const void *key, size_t keyLength, const void *data, size_t dataLength, void *macOut) {
    size_t macOutSize = 0;
    NSMutableString* log = [[NSMutableString alloc] initWithString:@"=============CCHmac===========\r\n"];
    switch (algorithm) {
        case kCCHmacAlgSHA1:
            [log appendString:@"kCCHmacAlgSHA1\r\n"];
            macOutSize = CC_SHA1_DIGEST_LENGTH;
            break;
        case kCCHmacAlgMD5:
            [log appendString:@"kCCHmacAlgMD5\r\n"];
            macOutSize = CC_MD5_DIGEST_LENGTH;
            break;
        case kCCHmacAlgSHA256:
            [log appendString:@"kCCHmacAlgSHA256\r\n"];
            macOutSize = CC_SHA256_DIGEST_LENGTH;
            break;
        case kCCHmacAlgSHA384:
            [log appendString:@"kCCHmacAlgSHA384\r\n"];
            macOutSize = CC_SHA384_DIGEST_LENGTH;
            break;
        case kCCHmacAlgSHA512:
            [log appendString:@"kCCHmacAlgSHA512\r\n"];
            macOutSize = CC_SHA512_DIGEST_LENGTH;
            break;
        case kCCHmacAlgSHA224:
            [log appendString:@"kCCHmacAlgSHA224\r\n"];
            macOutSize = CC_SHA224_DIGEST_LENGTH;
            break;
        default:
            [log appendString:@"unknown algorithm\r\n"];
            break;
    }
    
    NSData* keyData = [[NSData alloc] initWithBytes:key length:keyLength];
    NSString* keyStr = [NSString stringWithFormat:@"key -> %@", [WJTool data2HexStr:keyData]];
    [log appendString:keyStr];
    
    NSData* inData = [[NSData alloc] initWithBytes:data length:dataLength];
    NSString* inStr = [NSString stringWithFormat:@"inData -> %@", [WJTool data2HexStr:inData]];
    [log appendString:inStr];
    
    orig_CCHmac(algorithm, key, keyLength, data, dataLength, macOut);
    
    NSData* outData = [[NSData alloc] initWithBytes:macOut length:macOutSize];
    NSString* outStr = [NSString stringWithFormat:@"outData -> %@", [WJTool data2HexStr:outData]];
    [log appendString:outStr];
    
    [Log appendStr:log fileName:@"myLog.txt"];
    [WJTool print:log];
    
    
}

__attribute__((constructor)) static void entry() {
    HOOK_SYMBOL(CCCrypt, CCCrypt);
    HOOK_SYMBOL(SecKeyEncrypt, SecKeyEncrypt);
    HOOK_SYMBOL(CCHmac, CCHmac);
}
