package abc

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"bufio"
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	uuid "github.com/satori/go.uuid"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

// Account 农业银行
type Account struct {
	PhoneNumber       string `json:"phoneNumber"`
	CardNo            string `json:"cardNo"`
	LoginPwd          string `json:"loginPwd"`
	PayPwd            string `json:"payPwd"`
	DeviceInfo        string `json:"deviceInfo"`
	DeviceSerial      string `json:"deviceSerial"`
	SoftTokenTime     string `json:"softTokenTime"`
	SoftTokenKey1     []byte `json:"softTokenKey1"`
	SoftTokenKey2     []byte `json:"softTokenKey2"`
	Model             string `json:"model"`
	DiskSpace         int64  `json:"diskSpace"`
	LocalIP           string `json:"localIP"`
	MNC               string `json:"mnc"`
	MCC               string `json:"mcc"`
	UTDID             string `json:"utdid"`
	RandomNum         string `json:"randomNum"`
	ActiveState       string `json:"activeState"`
	LoginUserType     string `json:"loginUserType"`
	SystemVersion     string `json:"systemVersion"`
	ClientVersion     string `json:"clientVersion"`
	WholeMenuVersion  string `json:"wholeMenuVersion"`
	SepID             string `json:"sepID"`
	newMobileFlag     string
	faceAuthLoginFlag string
	redisID           string
	postURLFull       []string
	postURL           []string
	serverIP          []string
	thsessionid       string
	c                 *http.Client
	logger            *log2.MyLog
}

func NewAccount(phoneNumber, loginPwd, payPwd string) *Account {
	a := &Account{
		PhoneNumber: phoneNumber,
		LoginPwd:    loginPwd,
		PayPwd:      payPwd,
	}
	a.UTDID = newUTDID()
	a.ClientVersion = "10500"
	a.WholeMenuVersion = "926"
	a.Model = tools.NewModel()
	a.DeviceInfo = strings.ToUpper(uuid.NewV4().String())
	a.DeviceSerial = strings.ToUpper(uuid.NewV4().String()) + "iPhone"
	a.SystemVersion = tools.NewSysVersion()
	a.DiskSpace = tools.NewDiskSpace(a.Model) - int64(tools.RandBetween(1*1024*1024*1024, 3*1024*1024*1024))
	a.LocalIP = tools.NewIPV4()
	a.MNC = "460"
	a.MCC = tools.CarrierCode(tools.CarrierByPhoneNum(phoneNumber))
	a.Save()
	return a
}

func (a *Account) Save() {
	path := "./abc/bin/" + a.PhoneNumber + ".json"
	tools.SaveJSON2File(path, a)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (a *Account) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	u, _ := url.Parse("http://127.0.0.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// Login 登陆
func (a *Account) Login() base.LoginResultCode {
	a.logger = &log2.MyLog{
		Prefix: fmt.Sprintf("[ABC][%s]", a.PhoneNumber),
	}
	a.c = a.NewHTTPClient()

	a.qryPaperGoldAuPrice()
	time.Sleep(2 * time.Second)

	serverRandom := a.getServerRandomNum()
	if serverRandom.ResCode != 0 {
		a.logger.Errorf("Login getServerRandomNum出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			serverRandom.Data.MbankErrorCode,
			serverRandom.Data.MbankErrorType,
			serverRandom.Data.MbankErrorDest,
			serverRandom.Data.MbankErrorMessage)
		return base.LoginResultFail
	}

	loginInit := a.genLoginInit()
	if loginInit.ResCode != 0 {
		a.logger.Errorf("Login genLoginInit出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			loginInit.Data.MbankErrorCode,
			loginInit.Data.MbankErrorType,
			loginInit.Data.MbankErrorDest,
			loginInit.Data.MbankErrorMessage)
		return base.LoginResultFail
	}

	if a.ActiveState != "1" {
		regCheck := a.userRegCheck()
		if regCheck.Data.LoginUserType == "" {
			a.logger.Errorf("Login userRegCheck code=%s msg=%s",
				regCheck.Data.ErrorCode,
				regCheck.Data.ErrorMsg)
			return base.LoginResultFail
		}
		a.LoginUserType = regCheck.Data.LoginUserType

		phoneCheckForLogin := a.inputPhoneCheckForLogin()
		if phoneCheckForLogin.Data.ReturnCode != "000000" {
			a.logger.Errorf("Login inputPhoneCheckForLogin出错 code=%s msg=%s",
				phoneCheckForLogin.Data.ReturnCode,
				phoneCheckForLogin.Data.ReturnMsg)
			return base.LoginResultFail
		}
	}

	preHand := a.loginPreHand()
	if preHand.ResCode != 0 {
		a.logger.Errorf("Login loginPreHand111出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			preHand.Data.MbankErrorCode,
			preHand.Data.MbankErrorType,
			preHand.Data.MbankErrorDest,
			preHand.Data.MbankErrorMessage)
		return base.LoginResultFail
	}

	loginRes := a.loginAuth(serverRandom.Data.ServerRandom, loginInit.Data.RandomNum, preHand.Data.LoginPreHandN)
	if loginRes.ResCode != 0 {
		a.logger.Errorf("Login loginAuth111出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			loginRes.Data.MbankErrorCode,
			loginRes.Data.MbankErrorType,
			loginRes.Data.MbankErrorDest,
			loginRes.Data.MbankErrorMessage)
		return base.LoginResultFail
	}
	if loginRes.Data.IsActivate == "false" {
		// 需要发送短信去激活,先生成需要发送的短信
		keyIv, _ := base64.StdEncoding.DecodeString(loginRes.Data.Key)
		key := keyIv[:32]
		iv := keyIv[32:48]

		inData := []byte(a.PhoneNumber + "|" + loginInit.Data.RandomNum)
		enData := tools.AESCBCEncrypt(inData, key, iv)

		sms := "MBAPACTIVATE#" + base64.StdEncoding.EncodeToString(enData)

		// 谨防陌生人转发诈骗！
		// 谨防骗子转发此激活码
		a.logger.Infof("需要发送绑定短信到95599:%s", sms+loginInit.Data.SmsContent)

		// 等待至少10秒以上
		a.logger.Info("等待发送短信完成")
		br := bufio.NewReader(os.Stdin)
		_, _, _ = br.ReadLine()
		a.logger.Info("收到继续登陆的信号")

		serverRandom = a.getServerRandomNum()
		if serverRandom.ResCode != 0 {
			a.logger.Errorf("Login getServerRandomNum222 err=%d", serverRandom.ResCode)
			return base.LoginResultFail
		}
		preHand = a.loginPreHand()
		if preHand.ResCode != 0 {
			a.logger.Errorf("Login loginPreHand222 err=%d", preHand.ResCode)
			return base.LoginResultFail
		}
		loginRes = a.loginAuth(serverRandom.Data.ServerRandom, loginInit.Data.RandomNum, preHand.Data.LoginPreHandN)
		if loginRes.ResCode != 0 {
			a.logger.Errorf("Login loginAuth222出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
				loginRes.Data.MbankErrorCode,
				loginRes.Data.MbankErrorType,
				loginRes.Data.MbankErrorDest,
				loginRes.Data.MbankErrorMessage)
			return base.LoginResultFail
		}
		if loginRes.Data.IsActivate == "false" {
			a.logger.Error("短信激活失败")
			a.ActiveState = ""
			return base.LoginResultFail
		} else {
			a.ActiveState = "1"
			a.RandomNum = loginInit.Data.RandomNum
		}
	}
	time.Sleep(2 * time.Second)
	a.afterloginPb()

	//if a.SepID == "" {
	//	sepID := a.getSepID()
	//	a.SepID = sepID.Data.SepID
	//}

	// 短信登陆完 保存数据
	a.Save()

	if loginRes.ResCode != 0 {
		a.logger.Errorf("登陆错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			loginRes.Data.MbankErrorCode,
			loginRes.Data.MbankErrorType,
			loginRes.Data.MbankErrorDest,
			loginRes.Data.MbankErrorMessage)
		return base.LoginResultFail
	}

	if loginRes.Data.SSignFlag == "6" {
		a.logger.Error("当前账号未开通快e付，请手动开通后再登陆")
		return base.LoginResultFail
	}

	if loginRes.Data.SSignFlag != "1" || a.SoftTokenTime == "" {
		var key []byte

		a.initUserType()
		mng01 := a.softtokenmng01()
		reSignRes := a.softTokenVerify()
		if reSignRes.ResCode != 0 {
			a.logger.Error("softTokenVerify 系统异常")
			return base.LoginResultFail
		}

		if reSignRes.Data.CFlag == "0" {
			// 再发送一次短信
			keyIv, _ := base64.StdEncoding.DecodeString(reSignRes.Data.Key)
			aesKey := keyIv[:32]
			aesIV := keyIv[32:48]

			inData := []byte(a.PhoneNumber + "|" + reSignRes.Data.Random)
			enData := tools.AESCBCEncrypt(inData, aesKey, aesIV)

			sms := "MBSTOKEN#" + base64.StdEncoding.EncodeToString(enData)
			a.RandomNum = reSignRes.Data.Random
			a.logger.Infof("需要发送绑定短信到95599:%s", sms+mng01.Data.SmsContent)

			// 等待至少10秒以上
			a.logger.Info("等待发送短信完成")
			br := bufio.NewReader(os.Stdin)
			_, _, _ = br.ReadLine()
			a.logger.Info("收到继续登陆的信号")
		}

		if mng01.Data.FaceauthFlag == "1" {
			paramRes := a.getFaceAuthParam()
			if paramRes.ResCode != 0 {
				a.logger.Infof("获取刷脸参数失败 errCode=%d", paramRes.ResCode)
				return base.LoginResultFail
			}

			faceAuthnew := a.secFaceAuthNew()
			if faceAuthnew.ResCode != 0 {
				a.logger.Errorf("刷脸出错 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
					faceAuthnew.Data.MbankErrorCode,
					faceAuthnew.Data.MbankErrorType,
					faceAuthnew.Data.MbankErrorDest,
					faceAuthnew.Data.MbankErrorMessage)
				return base.LoginResultFail
			}
			// 进行刷脸
			//authRes := a.tryFace(&paramRes.Data.FaceAuthParams)
			//if authRes.Code != "SUCCESS" || authRes.SubCode != "SUCCESS" {
			//	a.logger.Infof("刷脸失败 Code=%s, SubCode=%s", authRes.Code, authRes.SubCode)
			//	return base.LoginResultFail
			//}
			//// 需要比对刷脸相识度
			//score, _ := strconv.ParseFloat(paramRes.Data.FaceAuthParams.FaceAuthScore, 64)
			//liveness, _ := strconv.ParseFloat(paramRes.Data.FaceAuthParams.FaceAuthLiveness, 64)
			//authContent := &faceAuthContentRes{}
			//_ = json.Unmarshal([]byte(authRes.Content), authContent)
			//faceLiveness := strings.Split(authContent.ExtInfo.Faceliveness, ",")
			//if len(faceLiveness) >= 2 && len(authContent.Result) >= 1 {
			//	authLiveness, _ := strconv.ParseFloat(faceLiveness[1], 64)
			//	if authContent.Result[0].Score >= score && authLiveness >= liveness {
			//		a.logger.Infof("刷脸返回 authScore=%f authLiveness=%f", authContent.Result[0].Score, authLiveness)
			//		// 提交刷脸数据
			//		secAuthRes := a.secFaceAuth(authContent)
			//		if secAuthRes.Data == "1" {
			//			a.logger.Info("刷脸成功")
			//		}
			//	}
			//}
		}

		reSignRes, key = a.softTokenActive()
		if reSignRes.Data.AckMsg == "" {
			a.SoftTokenTime = ""
			a.logger.Errorf("短信再次激活失败")
			return base.LoginResultFail
		}

		//if reSignRes.Data.AckMsg == "" {
		//	reSignRes, key = a.softTokenReSign()
		//	// 这里出错也不要处理
		//	if reSignRes.Data.RespCode != "0000" || reSignRes.Data.StokenAckMsg == "" {
		//		a.logger.Infof("softTokenReSign异常 code=%s msg=%s", reSignRes.Data.RespCode, reSignRes.Data.RespMsg)
		//	}
		//}
		msg := reSignRes.Data.AckMsg
		if msg == "" {
			msg = reSignRes.Data.StokenAckMsg
		}
		if msg == "" {
			return base.LoginResultSuccess
		}
		// 解析
		ackBytes, _ := base64.StdEncoding.DecodeString(msg)
		if ackBytes[8] == 0x20 && ackBytes[9] == 0x3 && ackBytes[10] == 0x10 && ackBytes[11] == 0x2 {
			// 先解密
			enAck := ackBytes[len(ackBytes)-0x60:]
			ack, _ := tools.SM4ECBDecrypt(enAck, key)

			// 读取重要的数据
			ackBuf := bytes.NewBuffer(ack)
			var tt uint16
			var ll uint16
			var tmp []byte
			var err error
			for {
				tt = 0
				ll = 0
				err = binary.Read(ackBuf, binary.BigEndian, &tt)
				if err != nil {
					break
				}
				err = binary.Read(ackBuf, binary.BigEndian, &ll)
				if err != nil {
					break
				}
				tmp = make([]byte, ll)
				_, err = ackBuf.Read(tmp)
				if err != nil {
					break
				}

				if tt == 0x1010 {
					//qs = tmp
				}
				if tt == 0x1005 {
					a.SoftTokenTime = string(tmp)
				}
				if tt == 0x1004 {
					a.SoftTokenKey1 = tmp
				}
				if tt == 0x1006 {
					// t0 = string(tmp)
				}
				if tt == 0x1007 {
					a.SoftTokenKey2 = tmp
				}
			}
		}

		//// 判断 快e付 状态
		//// 开通快e付后，每日在设定限额内仅凭密码即可转账或支付，最高限额50000元
		//mng := a.softTokenMng()
		//if mng.Return.Flag != "0" { // 0,已签约，1，未签约，2，种子异常，3，关闭，4，综管作废，7，过期
		//	a.logger.Errorf("快e付异常 FLAG=%s", mng.Return.Flag)
		//	return base.LoginResultFail
		//}
		//
		//reRegister, _ := a.softTokenReregister()
		//if reRegister.Return.Status != "0" { // 0：Stoken存在匹配  1：存在不匹配（密钥需要更新）  2：不存在
		//	reSignRes, _ = a.softTokenReSign()
		//	if reSignRes.Info.RespCode != "0000" {
		//		a.logger.Errorf("softTokenReSign异常 code=%s msg=%s", reSignRes.Info.RespCode, reSignRes.Info.RespMsg)
		//		return base.LoginResultFail
		//	}
		//}
		a.Save()
	}
	return base.LoginResultSuccess
}

// CardList 查询卡列表 以及获取余额等信息
func (a *Account) CardList() {
	//a.getAppID("myaccount")
	res := a.acctServiceMyAccount()
	a.CardNo = res.Data.DefAccBalanceInfo.AccNo
	a.Save()
}

// BillList 查询账单
func (a *Account) BillList() {
	a.detailQryInit(a.CardNo)
	res := a.detailQryFilter("20201129", "20210205")
	a.detailQryMore(res.Data.KeyNext)
}

// Transfer 转账
func (a *Account) Transfer(destCardNo, destName, amount, remark string) base.TransferResultCode {
	//a.getAppID("transfer_new")
	entrenRes := a.traEntren()
	if entrenRes.ResCode != 0 {
		a.logger.Errorf("进入转账页面出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			entrenRes.Data.MbankErrorCode,
			entrenRes.Data.MbankErrorType,
			entrenRes.Data.MbankErrorDest,
			entrenRes.Data.MbankErrorMessage)

		return base.TransferResultFail
	}

	fBalance, _ := strconv.ParseFloat(entrenRes.Data.Balance, 64)
	fAmount, _ := strconv.ParseFloat(amount, 64)
	if fBalance < fAmount {
		a.logger.Error("转账余额不足！")
		return base.TransferResultFail
	}

	bank := a.checkBank(destCardNo)
	if bank.ResCode != 0 {
		a.logger.Errorf("查询银行出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			bank.Data.MbankErrorCode,
			bank.Data.MbankErrorType,
			bank.Data.MbankErrorDest,
			bank.Data.MbankErrorMessage)

		if bank.Data.MbankErrorCode == "sso" {
			a.logger.Error("需要重登陆")
		}

		if bank.Data.MbankErrorCode == "TR0002" {
			a.logger.Error("需要重登陆")
		}
		return base.TransferResultFail
	}

	confirm := a.traInfoConfirm(destCardNo, destName, amount, remark, bank.Data.Unibank, bank.Data.Unibankname, bank.Data.SubBank, "")
	if confirm.Data.ConfirmFlag == "flwTips" {
		confirm = a.traInfoConfirm(destCardNo, destName, amount, remark, bank.Data.Unibank, bank.Data.Unibankname, bank.Data.SubBank, "1")
	}
	if confirm.ResCode != 0 {
		a.logger.Errorf("提交转账出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			confirm.Data.MbankErrorCode,
			confirm.Data.MbankErrorType,
			confirm.Data.MbankErrorDest,
			confirm.Data.MbankErrorMessage)
		return base.TransferResultFail
	}

	var qs []byte
	var t0 = ""
	query, key := a.applySTokenStatusQuery()
	if query.ResCode != 0 || query.Data.Status != 0 {
		update, key1 := a.applySTokenStatusUpdate()
		if update.ResCode != 0 {
			a.logger.Errorf("applySTokenStatusUpdate 出现错误 err=%d", update.ResCode)
			return base.TransferResultFail
		}
		ackBytes, _ := base64.StdEncoding.DecodeString(update.Data.AckMsg)
		if ackBytes[8] == 0x20 && ackBytes[9] == 0x3 && ackBytes[10] == 0x10 && ackBytes[11] == 0x2 {
			// 先解密
			enAck := ackBytes[len(ackBytes)-0x60:]
			ack, _ := tools.SM4ECBDecrypt(enAck, key1)

			// 读取重要的数据
			ackBuf := bytes.NewBuffer(ack)
			var tt uint16
			var ll uint16
			var tmp []byte
			var err error
			for {
				tt = 0
				ll = 0
				err = binary.Read(ackBuf, binary.BigEndian, &tt)
				if err != nil {
					break
				}
				err = binary.Read(ackBuf, binary.BigEndian, &ll)
				if err != nil {
					break
				}
				tmp = make([]byte, ll)
				_, err = ackBuf.Read(tmp)
				if err != nil {
					break
				}

				if tt == 0x1010 {
					qs = tmp
				}
				if tt == 0x1005 {
					a.SoftTokenTime = string(tmp)
				}
				if tt == 0x1004 {
					a.SoftTokenKey1 = tmp
				}
				if tt == 0x1006 {
					t0 = string(tmp)
				}
				if tt == 0x1007 {
					a.SoftTokenKey2 = tmp
				}
			}
		}
		// 这里要保存一下
		a.Save()
	} else {
		ackBytes, _ := base64.StdEncoding.DecodeString(query.Data.AckMsg)
		if ackBytes[8] == 0x20 && ackBytes[9] == 0x1 && ackBytes[10] == 0x10 && ackBytes[11] == 0x4 {
			// 先解密
			enAck := ackBytes[len(ackBytes)-0x20:]
			ack, _ := tools.SM4ECBDecrypt(enAck, key)

			// 读取打qs和t0
			ackBuf := bytes.NewBuffer(ack)
			var tt uint16
			var ll uint16
			var tmp []byte
			_ = binary.Read(ackBuf, binary.BigEndian, &tt)
			_ = binary.Read(ackBuf, binary.BigEndian, &ll)
			tmp = make([]byte, ll)
			_, _ = ackBuf.Read(tmp)
			if tt == 0x1010 {
				qs = tmp
			}
			if tt == 0x1006 {
				t0 = string(tmp)
			}

			_ = binary.Read(ackBuf, binary.BigEndian, &tt)
			_ = binary.Read(ackBuf, binary.BigEndian, &ll)
			tmp = make([]byte, ll)
			_, _ = ackBuf.Read(tmp)
			if tt == 0x1010 {
				qs = tmp
			}
			if tt == 0x1006 {
				t0 = string(tmp)
			}
		}
	}

	if len(qs) <= 0 || t0 == "" {
		a.logger.Errorf("生成HTOP数据参数不完整 t0=%s, qs=%+v", t0, qs)
		return base.TransferResultFail
	}

	signInfo := a.getSignInfo()
	if signInfo.ResCode != 0 {
		a.logger.Errorf("getSignInfo出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			signInfo.Data.MbankErrorCode,
			signInfo.Data.MbankErrorType,
			signInfo.Data.MbankErrorDest,
			signInfo.Data.MbankErrorMessage)
		// AP90252  您未绑定有效的安全认证设备
		if signInfo.Data.MbankErrorCode == "AP90252" {
			// 直接进行重新进行短信激活
			a.SoftTokenTime = ""
			a.Save()
		}
		return base.TransferResultFail
	}

	msg := a.genReqSTokenHOTP(qs, t0, signInfo.Data.ChallengeInfo.Coord)

	cfca := a.cfcaServerKey()
	if cfca.ResCode != 0 {
		a.logger.Errorf("cfcaServerKey 出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			cfca.Data.MbankErrorCode,
			cfca.Data.MbankErrorType,
			cfca.Data.MbankErrorDest,
			cfca.Data.MbankErrorMessage)
		return base.TransferResultFail
	}

	verifyPwd, enPwd := a.verifyPwd(cfca.Data.Sr)
	if verifyPwd.ResCode != 0 {
		a.logger.Errorf("verifyPwd 出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			verifyPwd.Data.MbankErrorCode,
			verifyPwd.Data.MbankErrorType,
			verifyPwd.Data.MbankErrorDest,
			verifyPwd.Data.MbankErrorMessage)
		return base.TransferResultFail
	}
	if verifyPwd.Data.AccPwdCorrect != "1" {
		a.logger.Error("转账密码不正确")
		return base.TransferResultFail
	}

	// 刷脸
	if (confirm.Data.FaceEnable == "1" || confirm.Data.GrayStatus == "2") && verifyPwd.Data.FaceRes.CstNo != "" {
		a.logger.Info("转账转账下一步需要刷脸")
		authRes := a.tryFace(&verifyPwd.Data.FaceRes)
		if authRes.Code != "SUCCESS" || authRes.SubCode != "SUCCESS" {
			a.logger.Errorf("刷脸失败 code=%s, msg=%s, subCode=%s, subMsg=%s",
				authRes.Code,
				authRes.Msg,
				authRes.SubCode,
				authRes.SubMsg)
			return base.TransferResultFail
		}

		// 解析返回的数据,比对刷脸相识度
		score, _ := strconv.ParseFloat(verifyPwd.Data.FaceRes.FaceAuthScore, 64)
		liveness, _ := strconv.ParseFloat(verifyPwd.Data.FaceRes.FaceAuthLiveness, 64)
		authContent := &faceAuthContentRes{}
		_ = json.Unmarshal([]byte(authRes.Content), authContent)
		faceLiveness := strings.Split(authContent.ExtInfo.Faceliveness, ",")
		if len(faceLiveness) <= 1 || len(authContent.Result) < 1 {
			a.logger.Errorf("刷脸结果数据解析失败 authContent=%+v", authContent)
			return base.TransferResultFail
		}
		authLiveness, _ := strconv.ParseFloat(faceLiveness[1], 64)
		if authLiveness < liveness || authContent.Result[0].Score < score {
			a.logger.Errorf("刷脸结果不达标 authScore=%f authLiveness=%f", authContent.Result[0].Score, authLiveness)
			return base.TransferResultFail
		}

		if verifyPwd.Data.FaceRes.FaceAuthSecondAuthControl == "1" {
			// 提交刷脸数据
			secAuthRes := a.transferSecFaceAuth(authContent)
			if secAuthRes.ResCode != 0 {
				a.logger.Errorf("transferSecFaceAuth 出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
					secAuthRes.Data.MbankErrorCode,
					secAuthRes.Data.MbankErrorType,
					secAuthRes.Data.MbankErrorDest,
					secAuthRes.Data.MbankErrorMessage)
				return base.TransferResultFail
			}

			if secAuthRes.Data.FaceSuccess == "1" {
				a.logger.Info("刷脸成功")
			}
		}
	}

	traInitiate := a.traInitiate(enPwd, msg)
	if traInitiate.Data.MbankErrorCode != "" {
		a.logger.Errorf("确认转账出现错误 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
			traInitiate.Data.MbankErrorCode,
			traInitiate.Data.MbankErrorType,
			traInitiate.Data.MbankErrorDest,
			traInitiate.Data.MbankErrorMessage)
		return base.TransferResultFail
	}

	// VerifyFlag == "1" 表示到账成功，同行这里就成功了
	if traInitiate.Data.VerifyFlag != "1" {
		// 循环去获取是否转账成功
		time.Sleep(3 * time.Second)
		verify := a.supVerify(traInitiate.Data.Trn.Logno)
		if verify.Data.VerifyFlag == "1" {
			return base.TransferResultSuccess
		}
		if verify.ResCode != 0 {
			// 	确认失败
			a.logger.Infof("转账失败 errorCode=%s, errorType=%s, errorDest=%s, errorMessage=%s",
				verify.Data.MbankErrorCode,
				verify.Data.MbankErrorType,
				verify.Data.MbankErrorDest,
				verify.Data.MbankErrorMessage)
			return base.TransferResultFail
		}
	} else {
		return base.TransferResultSuccess
	}
	return base.TransferResultFail
}
