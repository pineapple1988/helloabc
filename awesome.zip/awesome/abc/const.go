package abc

const (
	urlMgw = "https://mobilepaas.abchina.com:441/mgw.htm"

	bundleShortVersion = "6.3.1"
	bundleVersion      = "6.3.11"

	sm2X = "704C1947C010C0F4DD95A9597DCE73CEB900870F804E5CB1E751B20F478BA4B5"
	sm2Y = "D521BCB53A75EB8FC249AFC31D08E2E6B978E02A2D4C69B0CE2E9727963D151D"

	appID          = "A230192191308" // meta.config
	productId      = "A230192191308_IOS"
	productVersion = "10.1.68.150810110000"
	workspaceID    = "product"
	utdidHmacKey   = "d6fc3a4a06adbde89223bvefedc24fecde188aaa9161"
	signSalt       = "fd5c348acb537d7f9c1624ed500a94a3"
	pemRsaPub      = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5ESzmKnguJubwSLdf76V
Hm1UnZfKXDUgKPe0sgRHMfcsMTeKsN7HLpvQD+uU7Jo1PcD+7jeB0rU11IEWyZt2
Lcci2NAQk76zwJI7k+c1D58J5sSBXzPesz/27GXkLyDnXJO8cvBahcMwgypiFCYH
JaAO4FOCADWL99yfCnRwgo3iqr7JB6KMQjtCIENOoKwcOAhWOWmkfblB2fFc9N/F
pcYGBf0xFyq9lOFeRX0gLuYunx0MWCLyNa7EPnAEYAM3DAXNDJ7+6LnQCXGwI6w7
8olHk/Rod36BzbLjEnw+NDG7qnT85WNlT21EveaNEvGkhbNhgeNzfKu68k3R444r
1wIDAQAB
-----END PUBLIC KEY-----`
	faceAesKey  = "26bc5ae59b11ad9186c8ff2686594daacabcfb38a4b4ac9ca033e8a8e4b5d4bd"
	faceMD5Salt = "092d25d695ef70922e4db9ee4362ebd362f95ab4fe4765642f5b0cbf0972cf58"
)

var defaultIV []byte

func init() {
	defaultIV = []byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	}
}
