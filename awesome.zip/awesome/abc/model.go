package abc

type CollectData struct {
	NT            string `json:"NT"`
	AV            string `json:"AV"`
	OperationTime string `json:"OperationTime"`
	UserId        string `json:"UserId"`
	CA            string `json:"CA"`
	DeviceID      string `json:"Device_ID"`
	MU            string `json:"MU"`
	SY            string `json:"SY"`
	AN            string `json:"AN"`
	PN            string `json:"PN"`
	VI            string `json:"VI"`
	Location      string `json:"Location"`
	EM            string `json:"EM"`
	KeyValues     struct {
		StartAppTime string `json:"StartAppTime"`
		OfflineStart string `json:"Offline_Start"`
		EndAppTime   string `json:"EndAppTime"`
	} `json:"KeyValues"`
	AppKey       string `json:"appKey"`
	DM           string `json:"DM"`
	AppStartTime string `json:"AppStartTime"`
	OS           string `json:"OS"`
	TM           string `json:"TM"`
}

type userRegCheckRes struct {
	Data struct {
		ErrorCode     string `json:"errorCode"`
		ErrorMsg      string `json:"errorMsg"`
		LoginUserType string `json:"loginUserType"`
		RegCheck      string `json:"regCheck"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type checkForLoginRes struct {
	Data struct {
		IfPhoneCheckedAuth  string `json:"ifPhoneCheckedAuth"`
		InputPhoneCheckInfo string `json:"inputPhoneCheckInfo"`
		InputPhoneCheckTime string `json:"inputPhoneCheckTime"`
		PhoneCheckLoginFlag string `json:"phoneCheckLoginFlag"`
		ReturnCode          string `json:"returnCode"`
		ReturnMsg           string `json:"returnMsg"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type getSepIDRes struct {
	Data struct {
		SepID string `json:"sepID"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type loginPreHandRes struct {
	Data struct {
		mBankError
		LoginPreHandN string `json:"loginPreHandN"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type loginAuthRes struct {
	Data struct {
		mBankError
		AccountDate       string `json:"accountDate"`
		AcPhoneNo         string `json:"acPhoneNo"`
		FaceAuthLoginFlag string `json:"faceAuthLoginFlag"`
		Key               string `json:"key"`
		NewMobileFlag     string `json:"newMobileFlag"`
		BranchSessionID   string `json:"branchSessionID"`
		CPidMd5           string `json:"cPidMd5"`
		CalendarInfo      struct {
			DetailData     string `json:"detailData"`
			EndDate        string `json:"endDate"`
			IsLoginShift   string `json:"isLoginShift"`
			MaxEventsCount string `json:"maxEventsCount"`
			ServerDate     string `json:"serverDate"`
		} `json:"calendarinfo"`
		CityCode             string `json:"cityCode"`
		CustInfoFlag         string `json:"custInfoFlag"`
		CustLvlDis           string `json:"custLvlDis"`
		CustLvlDisNum        string `json:"custLvlDisNum"`
		CustPreServLvl       string `json:"custPreServLvl"`
		CustPrivateBankLevel string `json:"custPrivateBankLevel"`
		ExpTipErrMsg         string `json:"expTipErrMsg"`
		ExpireFlag           string `json:"expireFlag"`
		FileFlag             string `json:"fileFlag"`
		HintTimes            string `json:"hintTimes"`
		IfGdprNeedSign       string `json:"ifGdprNeedSign"`
		IsActivate           string `json:"isActivate"`
		IsIntegration        string `json:"isIntegration"`
		PhoneNoDES           string `json:"phoneNoDES"`
		SSignFlag            string `json:"sSignFlag"`
		Sexual               string `json:"sexual"`
		StokenAckMsg         string `json:"stokenAckMsg"`
		StokenMaxValue       string `json:"stokenMaxValue"`
		Userinfo             struct {
			CityFilter           string `json:"cityFilter"`
			CustPrivateBankLevel string `json:"custPrivateBankLevel"`
			LastLogin            string `json:"lastLogin"`
			MyPropertyFilter     string `json:"myPropertyFilter"`
			UserType             string `json:"userType"`
			Username             string `json:"username"`
		} `json:"userinfo"`
		VIPCustLvl     string `json:"vIPCustLvl"`
		VoiceGuideFlag string `json:"voiceGuideFlag"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type faceAuthLoginParamGetRes struct {
	Data struct {
		mBankError
		AmlFlag        string `json:"amlFlag"`
		FaceAuthParams struct {
			CstName                   string `json:"cstName"`
			CstNo                     string `json:"cstNo"`
			CurrentDate               string `json:"currentDate"`
			CurrentTime               string `json:"currentTime"`
			Did                       string `json:"did"`
			DidType                   string `json:"didType"`
			EndTime                   string `json:"endTime"`
			FaceAuthDayLimit          string `json:"faceAuthDayLimit"`
			FaceAuthLiveness          string `json:"faceAuthLiveness"`
			FaceAuthScore             string `json:"faceAuthScore"`
			FaceAuthSecondAuthControl string `json:"faceAuthSecondAuthControl"`
			FaceAuthTimesLimit        string `json:"faceAuthTimesLimit"`
			FaceAuthURL               string `json:"faceAuthUrl"`
			StartTime                 string `json:"startTime"`
		} `json:"faceAuthParams"`
		IfActiveSuccess string `json:"ifActiveSuccess"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type groupmember struct {
	LoginType     string `json:"logintype"`
	ChannelId     string `json:"channelid"`
	ImageName     string `json:"imagename"`
	Title         string `json:"title"`
	ChannelType   string `json:"channeltype"`
	Type          string `json:"type"`
	Url           string `json:"url"`
	CanDelete     string `json:"candelete"`
	ChannelState  string `json:"channelstate"`
	LoginState    string `json:"loginstate"`
	ChannelState2 string `json:"channel_state"`
	LoginState2   string `json:"login_state"`
}

type nativeMenu struct {
	GroupName   string        `json:"groupname"`
	GroupMember []groupmember `json:"groupmember"`
}

type channel struct {
	Title        string `json:"title"`
	Url          string `json:"url"`
	Id           string `json:"id"`
	Fid          string `json:"fid"`
	Order        string `json:"order"`
	BCode        string `json:"bcode"`
	Type         string `json:"type"`
	CanDelete    string `json:"candelete"`
	ChannelType  string `json:"channeltype"`
	LoginType    string `json:"logintype"`
	LoginState   string `json:"loginstate"`
	ChannelState string `json:"channel_state"`
}

type LoginRes struct {
	Sn                  string `json:"sn"`
	KeyCompany          string `json:"keyCompany"`
	Dn                  string `json:"dn"`
	SignAlg             string `json:"signAlg"`
	HashAlg             string `json:"hashAlg"`
	CPidMd5             string `json:"cPidMd5"`
	VoiceGuideFlag      string `json:"voiceGuideFlag"`
	ExpireNotificaiton  string `json:"expireNotificaiton"`
	CheckInfo           string `json:"checkInfo"`
	NoticeInfo          string `json:"noticeInfo"`
	UpdateUrl           string `json:"updateUrl"`
	CheckInfo2          string `json:"check_info"`
	LibName             string `json:"libName"`
	MenuVersion         string `json:"menuVersion"`
	Sexual              string `json:"sexual"`
	CustPreServLvl      string `json:"custPreServLvl"`
	VIPCustLvl          string `json:"vIPCustLvl"`
	CustLvlDisNum       string `json:"custLvlDisNum"`
	CustLvlDis          string `json:"custLvlDis"`
	CustInfoFlag        string `json:"custInfoFlag"`
	AntiMonFlag         string `json:"antiMonFlag"`
	HintTimes           string `json:"hintTimes"`
	AccountDate         string `json:"accountDate"`
	MutiIDFlag          string `json:"mutiIDFlag"`
	ImpInfoFlag         string `json:"impInfoFlag"`
	UnImpInfoFlag       string `json:"unImpInfoFlag"`
	DifEffeErrorType    string `json:"difEffeErrorType"`
	IfGdprNeedSign      string `json:"ifGdprNeedSign"`
	DidEndLoginDay      string `json:"didEndLoginDay"`
	WillForbidErrMsg    string `json:"willForbidErrMsg"`
	EndLoginDate        string `json:"endLoginDate"`
	FileFlag            string `json:"fileFlag"`
	CFlagMsg            string `json:"cFlagMsg"`
	SameDevice          string `json:"same_device"`
	SSignFlag           string `json:"sSignFlag"`
	StokenAckMsg        string `json:"stokenAckMsg"`
	StokenMaxValue      string `json:"stokenMaxValue"`
	ImToken             string `json:"imToken"`
	Isupdate            string `json:"isupdate"`
	NewVersion          string `json:"newversion"`
	BranchSessionID     string `json:"branchSessionID"`
	IsWholeMenuUpdate   string `json:"isWholeMenuUpdate"`
	NewWholeMenuVersion string `json:"newWholeMenuVersion"`
	UserInfo            struct {
		UserName         string `json:"username"`
		UserType         string `json:"userType"`
		LastLogin        string `json:"lastLogin"`
		CityFilter       string `json:"cityFilter"`
		MyPropertyFilter string `json:"myPropertyFilter"`
		MonthBillTips    string `json:"monthBillTips"`
		CustMenuName     string `json:"custMenuName"`
		LogoutTitle      string `json:"logoutTitle"`
	} `json:"userinfo"`
	AccountInfo struct {
		IsSetDefaultAcc string                   `json:"isSetDefaultAcc"`
		AccInfo         []map[string]interface{} `json:"accInfo"`
	} `json:"accountInfo"`
	CalendarInfo struct {
		ServerDate   string                   `json:"serverDate"`
		EndDate      string                   `json:"endDate"`
		IsLoginShift string                   `json:"isLoginShift"`
		DetailData   []map[string]interface{} `json:"detailData"`
	} `json:"calendarinfo"`
	MainMenu struct {
		MyMenu       []map[string]interface{} `json:"mymenu"`
		NativeMyMenu []nativeMenu             `json:"nativemymenu"`
		TabBar       []groupmember            `json:"tabbar"`
		Service      []groupmember            `json:"service"`
		FinDex       []groupmember            `json:"findex"`
		MinDex       []groupmember            `json:"mindex"`
	} `json:"mainmenu"`
	Personal struct {
		MaxNum   string    `json:"max_num"`
		Version  string    `json:"version"`
		Channels []channel `json:"channels"`
	} `json:"personal"`
	Personal410 struct {
		MaxNum   string    `json:"max_num"`
		Version  string    `json:"version"`
		Channels []channel `json:"channels"`
	} `json:"personal_410"`
	PersonalKg410 struct {
		MaxNum   string    `json:"max_num"`
		Version  string    `json:"version"`
		Channels []channel `json:"channels"`
	} `json:"personal_kg410"`
	PersonalKg500 struct {
		MaxNum   string    `json:"max_num"`
		Version  string    `json:"version"`
		Channels []channel `json:"channels"`
	} `json:"personal_kg500"`
	PersonalServiceNative    []nativeMenu             `json:"personal_service_native"`
	PersonalServiceNative410 []nativeMenu             `json:"personal_service_native_410"`
	PersonalService          []map[string]interface{} `json:"personal_service"`
}

type initUserTypeRes struct {
	Data struct {
		LogonMobileOpen string `json:"logonMobileOpen"`
		RespCode        string `json:"respCode"`
		MBCusLvl        string `json:"mbCusLvl"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type softtokenmng01Res struct {
	Data struct {
		SignFlag             string `json:"signFlag"`
		Flag                 string `json:"flag"`
		GuardLmt             string `json:"guardLmt"`
		SafetoolFlag         string `json:"safetool_flag"`
		FaceLimit            string `json:"faceLimit"`
		SmsContent           string `json:"smsContent"`
		FaceauthFlag         string `json:"faceauth_flag"`
		MobileNo             string `json:"mobileNo"`
		SystemDailyQuota     string `json:"systemDailyQuota"`
		SRegChannel          string `json:"sRegChannel"`
		SoftTokenDayPayQuota string `json:"softTokenDayPayQuota"`
		ActiveFlag           string `json:"activeFlag"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type faceAuthParams struct {
	CstName                   string `json:"cstName"`
	CstNo                     string `json:"cstNo"`
	CurrentDate               string `json:"currentDate"`
	CurrentTime               string `json:"currentTime"`
	Did                       string `json:"did"`
	DidType                   string `json:"didType"`
	EndTime                   string `json:"endTime"`
	FaceAuthDayLimit          string `json:"faceAuthDayLimit"`
	FaceAuthLiveness          string `json:"faceAuthLiveness"`
	FaceAuthScore             string `json:"faceAuthScore"`
	FaceAuthSecondAuthControl string `json:"faceAuthSecondAuthControl"`
	FaceAuthTimesLimit        string `json:"faceAuthTimesLimit"`
	FaceAuthURL               string `json:"faceAuthUrl"`
	StartTime                 string `json:"startTime"`
}

type faceAuthParamRes struct {
	Data struct {
		mBankError
		FaceAuthParams faceAuthParams `json:"faceAuthParams"`
		Flag           string         `json:"flag"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type faceAuthRes struct {
	Code    string `json:"code"`
	Msg     string `json:"msg"`
	SubCode string `json:"subCode"`
	SubMsg  string `json:"subMsg"`
	Content string `json:"content"`
}

type faceAuthContentRes struct {
	ResultNum int `json:"result_num"`
	Result    []struct {
		IndexI string  `json:"index_i"`
		IndexJ string  `json:"index_j"`
		Score  float64 `json:"score"`
	} `json:"result"`
	ExtInfo struct {
		Faceliveness string `json:"faceliveness"`
	} `json:"ext_info"`
	LogID int64 `json:"log_id"`
}

type secFaceAuthRes struct {
	Data        string `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type secFaceAuthNewRes struct {
	Data struct {
		mBankError
		FaceObj struct {
			PicChecksim string `json:"picChecksim"`
			Picid1      string `json:"picid1"`
			Picstatus   string `json:"picstatus"`
			Pid         string `json:"pid"`
			ResnCode    string `json:"resnCode"`
			ResnDesc    string `json:"resnDesc"`
			RespCode    string `json:"respCode"`
		} `json:"faceObj"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type softTokenReregisterRes struct {
	Return struct {
		ErrorCode string `json:"error_code"`
		Status    string `json:"status"`
		AckMsg    string `json:"ackMsg"`
		ErrorMsg  string `json:"error_msg"`
	} `json:"return"`
}

type softTokenReSignRes struct {
	Data struct {
		RespCode     string `json:"RespCode"`
		RespMsg      string `json:"RespMsg"`
		StokenAckMsg string `json:"stokenAckMsg"`
		AckMsg       string `json:"ackMsg"`
		CFlag        string `json:"cFlag"`
		Key          string `json:"key"`
		Random       string `json:"Random"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type SelectedAcc struct {
	AccNo    string `json:"accNo"`
	AccType  string `json:"accType"`
	CurCode  string `json:"curCode"`
	CashFlag string `json:"cashFlag"`
}

type Acc struct {
	AccountName     string `json:"accountName"`
	AccType         string `json:"accType"`
	AccNo           string `json:"accNo"`
	Alias           string `json:"alias"`
	CBranchName     string `json:"cBranchName"`
	CBranchCode     string `json:"cBranchCode"`
	CCurrency       string `json:"cCurrency"`
	CBank           string `json:"cBank"`
	CABISBranchProv string `json:"cABISBranchProv"`
	CBranchProv     string `json:"cBranchProv"`
	CCashFlag       string `json:"cCashFlag"`
	CIsDefaultDid   string `json:"cIsDefaultDid"`
	SRegChannel     string `json:"sRegChannel"`
	HidFlag         string `json:"hidFlag"`
}

type Row struct {
	ATxnIn       string `json:"aTxnIn"`
	ATxnOut      string `json:"aTxnOut"`
	TrnDate      string `json:"trnDate"`
	TrnTime      string `json:"trnTime"`
	Comment      string `json:"comment"`
	ShortComment string `json:"shortComment"`
	LongComment  string `json:"longComment"`
	Type         string `json:"type"`
	Channel      string `json:"channel"`
	TrnCstName   string `json:"trnCstName"`
	TrnAccNo     string `json:"trnAccNo"`
	Balance      string `json:"balance"`
	Index        string `json:"index"`
}

type InitQueryBillRes struct {
	Return struct {
		ErrorCode       string      `json:"error_code"`
		ErrorMsg        string      `json:"error_msg"`
		JumpFrom        string      `json:"jumpFrom"`
		AlertWinFlag    string      `json:"alertWinFlag"`
		MiniProgramFlag string      `json:"miniProgramFlag"`
		FilterQueryFlag string      `json:"filterQueryFlag"`
		ReverseEnable   string      `json:"reverseEnable"`
		SelectedAcc     SelectedAcc `json:"selectedAcc"`
		IsReverse       string      `json:"isReverse"`
		StartDate       string      `json:"startDate"`
		EndDate         string      `json:"endDate"`
		DayBeforeWeek   string      `json:"dayBeforeWeek"`
		Today           string      `json:"today"`
		KeyNext         string      `json:"keyNext"` // 拉去下一页的关键参数,不是"0"表示还有下一页
		TrnCommList     []struct {
			TrnComm string `json:"trnComm"`
		} `json:"trnCommList"`
		AccList      []Acc  `json:"accList"`
		IsFirst      string `json:"isFirst"`
		CurrencyRows []struct {
			CurCode  string `json:"curCode"`
			CashFlag string `json:"cashFlag"`
		} `json:"currencyRows"`
		Rows []Row `json:"rows"`
	} `json:"return"`
}

type QueryBillRes struct {
	Return struct {
		ErrorCode     string      `json:"error_code"`
		ErrorMsg      string      `json:"error_msg"`
		SelectedAcc   SelectedAcc `json:"selectedAcc"`
		ReverseEnable string      `json:"reverseEnable"`
		IsReverse     string      `json:"isReverse"`
		StartDate     string      `json:"startDate"`
		EndDate       string      `json:"endDate"`
		KeyNext       string      `json:"keyNext"` // 拉去下一页的关键参数,不是"0"表示还有下一页
		IsFirst       string      `json:"isFirst"`
		Rows          []Row       `json:"rows"`
	} `json:"return"`
}

type getAppIDRes struct {
	Data struct {
		AppID string `json:"appId"`
		Flag  string `json:"flag"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
	Timestamp   int64  `json:"timestamp"`
}

type acctServiceMyAccountRes struct {
	Data struct {
		BalanceErrorMsg   string `json:"balanceErrorMsg"`
		DefAccBalanceInfo struct {
			AccAvlBalance string `json:"accAvlBalance"`
			AccBalance    string `json:"accBalance"`
			AccNo         string `json:"accNo"`
		} `json:"defAccBalanceInfo"`
		DepositAccList []interface{} `json:"depositAccList"`
		EbankAccList   []struct {
			AbisPrv     string `json:"abisPrv"`
			AccNo       string `json:"accNo"`
			AccOpenDate string `json:"accOpenDate"`
			AccType     string `json:"accType"`
			Alias       string `json:"alias"`
			Auth        string `json:"auth"`
			Bank        string `json:"bank"`
			BranchCode  string `json:"branchCode"`
			BranchName  string `json:"branchName"`
			CashFlag    string `json:"cashFlag"`
			City        string `json:"city"`
			CurCode     string `json:"curCode"`
			EBRegBranch string `json:"eBRegBranch"`
			EaFlag      string `json:"eaFlag"`
			EaType      string `json:"eaType"`
			EaTypeName  string `json:"eaTypeName"`
			HideFlag    string `json:"hideFlag"`
			IsDefault   string `json:"isDefault"`
			Level       string `json:"level"`
			Mask        string `json:"mask"`
			PdciOpntl   string `json:"pdciOpntl"`
			Prv         string `json:"prv"`
			PwdSig      string `json:"pwdSig"`
			RegChannel  string `json:"regChannel"`
		} `json:"ebankAccList"`
		JumpFrom        string        `json:"jumpFrom"`
		NoEbankEAccList []interface{} `json:"noEbankEAccList"`
		QrcodeShareFlag string        `json:"qrcodeShareFlag"`
		SelectAccType   string        `json:"selectAccType"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type detailQryRes struct {
	Data struct {
		AccList []struct {
			AbisPrv     string `json:"abisPrv"`
			AccNo       string `json:"accNo"`
			AccOpenDate string `json:"accOpenDate"`
			AccType     string `json:"accType"`
			Alias       string `json:"alias"`
			Auth        string `json:"auth"`
			Bank        string `json:"bank"`
			BranchCode  string `json:"branchCode"`
			BranchName  string `json:"branchName"`
			CashFlag    string `json:"cashFlag"`
			City        string `json:"city"`
			CurCode     string `json:"curCode"`
			EBRegBranch string `json:"eBRegBranch"`
			EaFlag      string `json:"eaFlag"`
			EaType      string `json:"eaType"`
			EaTypeName  string `json:"eaTypeName"`
			HideFlag    string `json:"hideFlag"`
			IsDefault   string `json:"isDefault"`
			Level       string `json:"level"`
			Mask        string `json:"mask"`
			PdciOpntl   string `json:"pdciOpntl"`
			Prv         string `json:"prv"`
			PwdSig      string `json:"pwdSig"`
			RegChannel  string `json:"regChannel"`
		} `json:"accList"`
		AlertWinFlag string `json:"alertWinFlag"`
		CurrencyList []struct {
			CashFlag string `json:"cashFlag"`
			CurCode  string `json:"curCode"`
		} `json:"currencyList"`
		DayBeforeWeek string `json:"dayBeforeWeek"`
		DetailPage    []struct {
			ATxnOut      string `json:"aTxnOut"`
			TCol1        string `json:"tCol1"`
			DTxn         string `json:"dTxn"`
			Channel      string `json:"channel"`
			Index        string `json:"index"`
			BankName     string `json:"bankName"`
			Type         string `json:"type"`
			ShortComment string `json:"shortComment"`
			MerchantName string `json:"merchantName"`
			LongComment  string `json:"longComment"`
			ATxnIn       string `json:"aTxnIn"`
			TrnAccNo     string `json:"trnAccNo"`
			Balance      string `json:"balance"`
			TrnCstName   string `json:"trnCstName"`
			Comment      string `json:"comment"`
		} `json:"detailPage"`
		EmailExportFlag string `json:"emailExportFlag"`
		EndDate         string `json:"endDate"`
		FilterQueryFlag string `json:"filterQueryFlag"`
		IsFirst         string `json:"isFirst"`
		IsReverse       string `json:"isReverse"`
		JumpFrom        string `json:"jumpFrom"`
		KeyNext         string `json:"keyNext"`
		MiniProgramFlag string `json:"miniProgramFlag"`
		ReverseEnable   string `json:"reverseEnable"`
		SelectAcc       struct {
			AbisPrv     string `json:"abisPrv"`
			AccNo       string `json:"accNo"`
			AccOpenDate string `json:"accOpenDate"`
			AccType     string `json:"accType"`
			Alias       string `json:"alias"`
			Auth        string `json:"auth"`
			Bank        string `json:"bank"`
			BranchCode  string `json:"branchCode"`
			BranchName  string `json:"branchName"`
			CashFlag    string `json:"cashFlag"`
			City        string `json:"city"`
			CurCode     string `json:"curCode"`
			EBRegBranch string `json:"eBRegBranch"`
			EaFlag      string `json:"eaFlag"`
			EaType      string `json:"eaType"`
			EaTypeName  string `json:"eaTypeName"`
			HideFlag    string `json:"hideFlag"`
			IsDefault   string `json:"isDefault"`
			Level       string `json:"level"`
			Mask        string `json:"mask"`
			PdciOpntl   string `json:"pdciOpntl"`
			Prv         string `json:"prv"`
			PwdSig      string `json:"pwdSig"`
			RegChannel  string `json:"regChannel"`
		} `json:"selectAcc"`
		StartDate   string   `json:"startDate"`
		Today       string   `json:"today"`
		TrnCommList []string `json:"trnCommList"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type traEntrenRes struct {
	Data struct {
		mBankError
		Balance  string `json:"balance"`
		BankList []struct {
			Sig  string `json:"sig"`
			Sub  string `json:"sub"`
			Name string `json:"name"`
		} `json:"bankList"`
		FromAccList []struct {
			AbisPrv     string `json:"abisPrv"`
			AccNo       string `json:"accNo"`
			AccOpenDate string `json:"accOpenDate"`
			AccType     string `json:"accType"`
			Alias       string `json:"alias"`
			Auth        string `json:"auth"`
			Bank        string `json:"bank"`
			BranchCode  string `json:"branchCode"`
			BranchName  string `json:"branchName"`
			CashFlag    string `json:"cashFlag"`
			City        string `json:"city"`
			CurCode     string `json:"curCode"`
			EBRegBranch string `json:"eBRegBranch"`
			EaFlag      string `json:"eaFlag"`
			EaType      string `json:"eaType"`
			EaTypeName  string `json:"eaTypeName"`
			HideFlag    string `json:"hideFlag"`
			IsDefault   string `json:"isDefault"`
			Level       string `json:"level"`
			Mask        string `json:"mask"`
			PdciOpntl   string `json:"pdciOpntl"`
			Prv         string `json:"prv"`
			PwdSig      string `json:"pwdSig"`
			RegChannel  string `json:"regChannel"`
		} `json:"fromAccList"`
		FromAccNo string `json:"fromAccNo"`
		FromIndex string `json:"fromIndex"`
		JumpFrom  string `json:"jumpFrom"`
		OcrURL    string `json:"ocrUrl"`
		PayeeList []struct {
			AccName    string `json:"accName"`
			AccNo      string `json:"accNo"`
			AccType    string `json:"accType,omitempty"`
			Bank       string `json:"bank"`
			BankName   string `json:"bankName"`
			BranchCode string `json:"branchCode,omitempty"`
			Index      int    `json:"index"`
			RegChannel string `json:"regChannel,omitempty"`
			BranchName string `json:"branchName,omitempty"`
			CstNo      string `json:"cstNo,omitempty"`
			Real       string `json:"real,omitempty"`
			Srlno      string `json:"srlno,omitempty"`
			SubBank    string `json:"subBank,omitempty"`
		} `json:"payeeList"`
		QrcodeAcc struct {
			Index int `json:"index"`
		} `json:"qrcodeAcc"`
		RecentIndex string `json:"recentIndex"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type searchBankRes struct {
	Data struct {
		mBankError
		SubBank     string `json:"subBank"`
		Unibank     string `json:"unibank"`
		Unibankname string `json:"unibankname"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type uniTransfer02Res struct {
	Data struct {
		mBankError
		ConfirmFlag    string `json:"confirmFlag"`
		FaceEnable     string `json:"faceEnable"`
		FromAccNo      string `json:"fromAccNo"`
		GrayStatus     string `json:"gray_status"`
		PositionEnable string `json:"positionEnable"`
		StStatus       string `json:"stStatus"`
		ToAccName      string `json:"toAccName"`
		ToAccNo        string `json:"toAccNo"`
		ToBankName     string `json:"toBankName"`
		TrnAmt         string `json:"trnAmt"`
		WarningTrnSum  string `json:"warningTrnSum"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type getSignInfoRes struct {
	Data struct {
		mBankError
		AuthFlag      string `json:"authFlag"`
		CfcaRandom    string `json:"cfcaRandom"`
		ChallengeInfo struct {
			Coord string `json:"coord"`
		} `json:"challengeInfo"`
		StStatus string `json:"stStatus"`
		SttMob   string `json:"sttMob"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type applySTokenStatusQueryRes struct {
	Data struct {
		AckMsg string `json:"ackMsg"`
		Status int    `json:"status"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type applySTokenStatusUpdateRes struct {
	Data struct {
		AckMsg   string `json:"ackMsg"`
		MobileNO string `json:"mobileNo"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type cfcaServerKeyRes struct {
	Data struct {
		mBankError
		Sr string `json:"sr"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
	Timestamp   int64  `json:"timestamp"`
}

type verifyPwdRes struct {
	Data struct {
		mBankError
		AccPwdCorrect string         `json:"accPwdCorrect"`
		FaceRes       faceAuthParams `json:"faceRes"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type traInitiateRes struct {
	Data struct {
		mBankError
		EncryptParms string `json:"encryptParms"`
		FromAccName  string `json:"fromAccName"`
		FromAccNo    string `json:"fromAccNo"`
		Lotteryinfo  struct {
			ImgURL    string `json:"imgUrl"`
			ImgURL2   string `json:"imgUrl2"`
			ReturnTyp string `json:"returnTyp"`
			TransNo   string `json:"transNo"`
			URL       string `json:"url"`
			Token     string `json:"token"`
		} `json:"lotteryinfo"`
		MiniJumpParam string `json:"miniJumpParam"`
		MiniShareImg  string `json:"miniShareImg"`
		MiniShareURL  string `json:"miniShareUrl"`
		ShareFlag     string `json:"shareFlag"`
		ShareParms    struct {
			MiniShareURL    string `json:"miniShareUrl"`
			MiniImgType1    string `json:"miniImgType1"`
			MiniImgType2    string `json:"miniImgType2"`
			ShareFlag       string `json:"shareFlag"`
			EncryptParms    string `json:"encryptParms"`
			MiniImgType2Big string `json:"miniImgType2Big"`
			MiniImgType1Big string `json:"miniImgType1Big"`
			ShareURL        string `json:"shareUrl"`
			MiniShareImg    string `json:"miniShareImg"`
			MiniJumpParam   string `json:"miniJumpParam"`
		} `json:"shareParms"`
		ToAccBank     string `json:"toAccBank"`
		ToAccBankName string `json:"toAccBankName"`
		ToAccName     string `json:"toAccName"`
		ToAccNo       string `json:"toAccNo"`
		Trn           struct {
			Logno         string `json:"logno"`
			Pps           string `json:"pps"`
			IbpsEnable    string `json:"ibpsEnable"`
			ArriveType    string `json:"arriveType"`
			Amt           string `json:"amt"`
			Land          string `json:"land"`
			UpdateAmtFlag string `json:"updateAmtFlag"`
		} `json:"trn"`
		VerifyFlag string `json:"verifyFlag"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type supVerifyRes struct {
	AppID            interface{} `json:"appId"`
	TrCode           interface{} `json:"trCode"`
	TrVersion        interface{} `json:"trVersion"`
	ResCode          int         `json:"resCode"`
	ResMessage       interface{} `json:"resMessage"`
	ErrorDescription interface{} `json:"errorDescription"`
	ResponseID       interface{} `json:"responseId"`
	UniqueID         interface{} `json:"uniqueId"`
	FlowNum          int         `json:"flowNum"`
	SpecVersion      string      `json:"specVersion"`
	AppIPAddress     interface{} `json:"appIpAddress"`
	AppMacAddress    interface{} `json:"appMacAddress"`
	Timestamp        interface{} `json:"timestamp"`
	NonceString      interface{} `json:"nonceString"`
	SignType         string      `json:"signType"`
	SignStamp        interface{} `json:"signStamp"`
	EncryptType      string      `json:"encryptType"`
	Extension        struct {
	} `json:"extension"`
	Data struct {
		mBankError
		EncryptParms string `json:"encryptParms"`
		FromAccName  string `json:"fromAccName"`
		FromAccNo    string `json:"fromAccNo"`
		Lotteryinfo  struct {
			ImgURL    string `json:"imgUrl"`
			ImgURL2   string `json:"imgUrl2"`
			ReturnTyp string `json:"returnTyp"`
			TransNo   string `json:"transNo"`
			URL       string `json:"url"`
			Token     string `json:"token"`
		} `json:"lotteryinfo"`
		MiniJumpParam string `json:"miniJumpParam"`
		MiniShareImg  string `json:"miniShareImg"`
		MiniShareURL  string `json:"miniShareUrl"`
		ShareFlag     string `json:"shareFlag"`
		ShareParms    struct {
			MiniShareURL    string `json:"miniShareUrl"`
			MiniImgType1    string `json:"miniImgType1"`
			MiniImgType2    string `json:"miniImgType2"`
			ShareFlag       string `json:"shareFlag"`
			EncryptParms    string `json:"encryptParms"`
			MiniImgType2Big string `json:"miniImgType2Big"`
			MiniImgType1Big string `json:"miniImgType1Big"`
			ShareURL        string `json:"shareUrl"`
			MiniShareImg    string `json:"miniShareImg"`
			MiniJumpParam   string `json:"miniJumpParam"`
		} `json:"shareParms"`
		ToAccBank     string `json:"toAccBank"`
		ToAccBankName string `json:"toAccBankName"`
		ToAccName     string `json:"toAccName"`
		ToAccNo       string `json:"toAccNo"`
		Trn           struct {
			Pps             string `json:"pps"`
			UnionPaySignURL string `json:"unionPaySignUrl"`
			IbpsEnable      string `json:"ibpsEnable"`
			ArriveType      string `json:"arriveType"`
			Amt             string `json:"amt"`
			Land            string `json:"land"`
			UpdateAmtFlag   string `json:"updateAmtFlag"`
		} `json:"trn"`
		VerifyFlag string `json:"verifyFlag"`
	} `json:"data"`
	EncryptData interface{} `json:"encryptData"`
}

type getServerRandomNumRes struct {
	Data struct {
		mBankError
		ServerRandom string `json:"serverRandom"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type genLoginInitRes struct {
	Data struct {
		mBankError
		ChangUserLoginOn     string `json:"changUserLoginOn"`
		FaceControlFlag      string `json:"faceControlFlag"`
		InputPhoneCheckClear string `json:"inputPhoneCheckClear"`
		IsOpenAppleLogin     string `json:"isOpenAppleLogin"`
		IsRegisterLogin      string `json:"isRegisterLogin"`
		LoginPwdForgetFlag   string `json:"loginPwdForgetFlag"`
		LoginQuickGuideFlag  string `json:"loginQuickGuideFlag"`
		LoginUserType        string `json:"loginUserType"`
		MobileNo             string `json:"mobileNo"`
		RandomNum            string `json:"randomNum"`
		ShowRegisterFlag     string `json:"showRegisterFlag"`
		SmsContent           string `json:"smsContent"`
		SmsContentFlag       string `json:"smsContentFlag"`
		WchatLoginOn         string `json:"wchatLoginOn"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type transferSecFaceAuthRes struct {
	Data struct {
		mBankError
		FaceSuccess     string      `json:"faceSuccess"`
		PositionSuccess interface{} `json:"positionSuccess"`
	} `json:"data"`
	EncryptType string `json:"encryptType"`
	Extension   struct {
	} `json:"extension"`
	FlowNum     int    `json:"flowNum"`
	ResCode     int    `json:"resCode"`
	SignType    string `json:"signType"`
	SpecVersion string `json:"specVersion"`
}

type mBankError struct {
	MbankErrorCode    string `json:"mbank_errorCode"`
	MbankErrorType    string `json:"mbank_errorType"`
	MbankErrorDest    string `json:"mbank_errorDest"`
	MbankErrorMessage string `json:"mbank_errorMessage"`
}
