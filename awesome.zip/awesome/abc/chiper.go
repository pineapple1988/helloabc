package abc

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm2"
	"awesome/tools/gmsm/sm3"
	"bytes"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"github.com/robertkrimen/otto"
	"io/ioutil"
	"lukechampine.com/uint128"
	"math/big"
	"strconv"
	"strings"
)

func (a *Account) deviceToken() string {
	digest := sm3.Sm3Sum([]byte(a.DeviceSerial))
	dd := make([]byte, 0x80)
	copy(dd, digest)
	digest = sm3.Sm3Sum(dd)
	return fmt.Sprintf("%x", digest)
}

func (a *Account) genReqSTokenEnable() (string, []byte) {
	// 生成sm4 key
	key := tools.RandBytes(16)
	// sm2 加密 sm4 key
	enSM2 := sm2Encrypt(key, sm2X, sm2Y)
	// sm4 需要加密的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x10, 0x08, 0x00, 0x20})     // 固定
	buffer.Write(sm3.Sm3Sum([]byte(a.DeviceSerial))) // sm3数据结果长度0x20
	buffer.Write([]byte{0x10, 0x01, 0x00, 0x0B})     // 固定
	buffer.Write([]byte(a.PhoneNumber))              // 电话号码长度0xB

	enSM4, _ := tools.SM4ECBEncrypt(buffer.Bytes(), key)

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x02, 0x00, 0x00,
	})
	buffer.Write(enSM4)
	mac := sm3.Sm3Sum(buffer.Bytes())

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write(mac[0x1c:])
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x02, 0x00, 0x00,
	})
	buffer.Write(enSM4)

	return base64.StdEncoding.EncodeToString(buffer.Bytes()), key
}

func (a *Account) genReqSTokenReEnable() (string, []byte) {
	// 生成sm4 key
	key := tools.RandBytes(16)
	// sm2 加密 sm4 key
	enSM2 := sm2Encrypt(key, sm2X, sm2Y)
	// sm4 需要加密的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x10, 0x08, 0x00, 0x20})     // 固定
	buffer.Write(sm3.Sm3Sum([]byte(a.DeviceSerial))) // sm3数据结果长度0x20
	buffer.Write([]byte{0x10, 0x01, 0x00, 0x0B})     // 固定
	buffer.Write([]byte(a.PhoneNumber))              // 电话号码长度0xB

	enSM4, _ := tools.SM4ECBEncrypt(buffer.Bytes(), key)

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x03, 0x00, 0x00,
	})
	buffer.Write(enSM4)
	mac := sm3.Sm3Sum(buffer.Bytes())

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write(mac[0x1c:])
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x03, 0x00, 0x00,
	})
	buffer.Write(enSM4)

	return base64.StdEncoding.EncodeToString(buffer.Bytes()), key
}

func (a *Account) genReqSTokenState() (string, []byte) {
	// 生成sm4 key
	key := tools.RandBytes(16)
	//key := []byte{
	//	0x5F, 0xCF, 0x27, 0x7D, 0xE9, 0xDB, 0xF2, 0x1B, 0xB5, 0x95, 0xB3, 0x5B, 0xB1, 0x0D, 0xA1, 0xE3,
	//}
	// sm2 加密 sm4 key
	enSM2 := sm2Encrypt(key, sm2X, sm2Y)
	//enSM2 := []byte{
	//	0x04, 0xEA, 0x18, 0x3C, 0xBB, 0x00, 0x6D, 0x27, 0xF2, 0xD9, 0xF1, 0x7F, 0x35, 0xE8, 0xBF, 0x99,
	//	0x9B, 0x0D, 0xF1, 0xC2, 0x60, 0x77, 0x48, 0xD2, 0x05, 0xA3, 0xC2, 0x29, 0x9E, 0x66, 0xA8, 0x4E,
	//	0x0E, 0x67, 0xED, 0xE6, 0xED, 0xD7, 0x0E, 0x8C, 0x66, 0x6F, 0x0E, 0x41, 0xA0, 0xB0, 0x75, 0x5F,
	//	0x20, 0x6D, 0xDF, 0xEB, 0x4F, 0x08, 0xB1, 0x48, 0x37, 0x2F, 0x95, 0xD9, 0x54, 0x68, 0x4B, 0x01,
	//	0x67, 0x49, 0xC1, 0xA5, 0x60, 0x17, 0xEA, 0x08, 0x38, 0x5A, 0xD9, 0xAA, 0xE1, 0xE3, 0x69, 0xFB,
	//	0x31, 0x47, 0xA9, 0x6E, 0x59, 0x19, 0x27, 0x07, 0x7F, 0xC9, 0x71, 0x7A, 0xCD, 0xD1, 0x16, 0xCA,
	//	0x52, 0x4D, 0x62, 0x19, 0x73, 0x5B, 0x86, 0x26, 0xC1, 0x27, 0x8C, 0x98, 0x97, 0x40, 0xD8, 0x9F,
	//	0xA2,
	//}

	// sm4 需要加密的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x10, 0x05, 0x00, 0xA})                  // 固定,时间戳长度10
	buffer.Write([]byte(a.SoftTokenTime))                        // 时间戳
	buffer.Write([]byte{0x10, 0x09, 0x00, 0x20})                 // 固定
	buffer.Write(sm3.Sm3Sum(sm3.Sm3Sum([]byte(a.DeviceSerial)))) // 两次sm3数据 长度0x20
	buffer.Write([]byte{0x10, 0x01, 0x00, 0x0B})                 // 固定
	buffer.Write([]byte(a.PhoneNumber))                          // 电话号码长度0xB
	enSM4, _ := tools.SM4ECBEncrypt(buffer.Bytes(), key)

	// 算hash
	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write([]byte{0x00, 0xD4}) // 总数据长度是0xd4
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x01, 0x00, 0x00,
	})
	buffer.Write(enSM4)
	mac := sm3.Sm3Sum(buffer.Bytes())

	// 最后的结果
	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write(mac[0x1c:])
	buffer.Write([]byte{0x00, 0xD4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x01, 0x00, 0x00,
	})
	buffer.Write(enSM4)

	return base64.StdEncoding.EncodeToString(buffer.Bytes()), key
}

func (a *Account) genReqSTokenHOTP(qs []byte, t0, coord string) string {
	deviceDigest := sm3.Sm3Sum([]byte(a.DeviceSerial))
	coordDigest := sm3.Sm3Sum([]byte(coord))

	digest := sm3.Sm3Sum(a.SoftTokenKey2)
	enSM4, _ := tools.SM4ECBEncrypt([]byte(a.PhoneNumber), digest[0x10:])

	buf := bytes.NewBuffer([]byte{})
	buf.Write(enSM4)
	buf.Write(deviceDigest)
	digest = sm3.Sm3Sum(buf.Bytes())
	for i := 0; i < 49; i++ {
		digest = sm3.Sm3Sum(digest)
	}

	buf.Reset()
	buf.Write(digest)
	buf.Write(a.SoftTokenKey1)
	digest = sm3.Sm3Sum(buf.Bytes())

	buf.Reset()
	buf.Write(digest[:0x14])
	tt, _ := strconv.ParseInt(t0, 10, 32)
	ttt := uint128.From64(uint64(tt))
	mmm := ttt.Mul64(0x8888888888888889)
	mmm = mmm.Rsh(64).Rsh(5)
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00})
	_ = binary.Write(buf, binary.BigEndian, uint32(mmm.Lo))
	buf.Write(deviceDigest)
	buf.Write([]byte(hex.EncodeToString(coordDigest[:0x10])))
	buf.Write(qs)
	digest = sm3.Sm3Sum(buf.Bytes())
	// 算出最后的code
	code0 := ((uint32(digest[4])<<24)&0xFF00FFFF|(uint32(digest[5])<<16))&0xFFFF00FF | (uint32(digest[6]) << 8) | uint32(digest[7])
	code1 := ((uint32(digest[0])<<24)&0xFF00FFFF|(uint32(digest[1])<<16))&0xFFFF00FF | (uint32(digest[2]) << 8) | uint32(digest[3])
	code2 := ((uint32(digest[8])<<24)&0xFF00FFFF|(uint32(digest[9])<<16))&0xFFFF00FF | (uint32(digest[10]) << 8) | uint32(digest[11])
	code3 := ((uint32(digest[12])<<24)&0xFF00FFFF|(uint32(digest[13])<<16))&0xFFFF00FF | (uint32(digest[14]) << 8) | uint32(digest[15])
	code4 := ((uint32(digest[16])<<24)&0xFF00FFFF|(uint32(digest[17])<<16))&0xFFFF00FF | (uint32(digest[18]) << 8) | uint32(digest[19])
	code5 := ((uint32(digest[20])<<24)&0xFF00FFFF|(uint32(digest[21])<<16))&0xFFFF00FF | (uint32(digest[22]) << 8) | uint32(digest[23])
	code6 := ((uint32(digest[24])<<24)&0xFF00FFFF|(uint32(digest[25])<<16))&0xFFFF00FF | (uint32(digest[26]) << 8) | uint32(digest[27])
	code7 := ((uint32(digest[28])<<24)&0xFF00FFFF|(uint32(digest[29])<<16))&0xFFFF00FF | (uint32(digest[30]) << 8) | uint32(digest[31])
	code := (code0 + code1 + code2 + code3 + code4 + code5 + code6 + code7) % 0xf4240
	cc := fmt.Sprintf("%06d", code)

	// 生成sm4 key
	key := tools.RandBytes(16)
	//key := []byte{
	//	0x5F, 0xCF, 0x27, 0x7D, 0xE9, 0xDB, 0xF2, 0x1B, 0xB5, 0x95, 0xB3, 0x5B, 0xB1, 0x0D, 0xA1, 0xE3,
	//}
	// sm2 加密 sm4 key
	enSM2 := sm2Encrypt(key, sm2X, sm2Y)
	//enSM2 := []byte{
	//	0x04, 0xEA, 0x18, 0x3C, 0xBB, 0x00, 0x6D, 0x27, 0xF2, 0xD9, 0xF1, 0x7F, 0x35, 0xE8, 0xBF, 0x99,
	//	0x9B, 0x0D, 0xF1, 0xC2, 0x60, 0x77, 0x48, 0xD2, 0x05, 0xA3, 0xC2, 0x29, 0x9E, 0x66, 0xA8, 0x4E,
	//	0x0E, 0x67, 0xED, 0xE6, 0xED, 0xD7, 0x0E, 0x8C, 0x66, 0x6F, 0x0E, 0x41, 0xA0, 0xB0, 0x75, 0x5F,
	//	0x20, 0x6D, 0xDF, 0xEB, 0x4F, 0x08, 0xB1, 0x48, 0x37, 0x2F, 0x95, 0xD9, 0x54, 0x68, 0x4B, 0x01,
	//	0x67, 0x49, 0xC1, 0xA5, 0x60, 0x17, 0xEA, 0x08, 0x38, 0x5A, 0xD9, 0xAA, 0xE1, 0xE3, 0x69, 0xFB,
	//	0x31, 0x47, 0xA9, 0x6E, 0x59, 0x19, 0x27, 0x07, 0x7F, 0xC9, 0x71, 0x7A, 0xCD, 0xD1, 0x16, 0xCA,
	//	0x52, 0x4D, 0x62, 0x19, 0x73, 0x5B, 0x86, 0x26, 0xC1, 0x27, 0x8C, 0x98, 0x97, 0x40, 0xD8, 0x9F,
	//	0xA2,
	//}

	// sm4 需要加密的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x10, 0x03, 0x00, 0x6}) // 固定
	buffer.Write([]byte(cc))
	buffer.Write([]byte{0x10, 0x01, 0x00, 0x0B}) // 固定
	buffer.Write([]byte(a.PhoneNumber))          // 电话号码长度0xB
	enSM4, _ = tools.SM4ECBEncrypt(buffer.Bytes(), key)

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write([]byte{0x00, 0xA4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x05, 0x00, 0x00,
	})
	buffer.Write(enSM4)
	mac := sm3.Sm3Sum(buffer.Bytes())

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write(mac[0x1c:])
	buffer.Write([]byte{0x00, 0xA4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x05, 0x00, 0x00,
	})
	buffer.Write(enSM4)

	return base64.StdEncoding.EncodeToString(buffer.Bytes())
}

func sm2Encrypt(in []byte, x, y string) []byte {

	pub := &sm2.PublicKey{
		Curve: sm2.P256Sm2(),
	}
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	out, err := pub.Encrypt(in)
	if err != nil {
		return nil
	}

	// 这里的输出顺序需要改变一下
	c1 := out[:0x41]
	c3 := out[0x41:0x61]
	c2 := out[0x61:]
	// 这里一定要用copy 不能使用append
	realOut := make([]byte, len(out))
	copy(realOut, c1)
	copy(realOut[len(c1):], c2)
	copy(realOut[len(c1)+len(c2):], c3)
	return realOut
}

func newUTDID() string {
	ts := tools.Timestamp()
	r := tools.RandBetween(0x10000000, 0xFFFFFFFF)
	uuid := tools.NewUUIDUpper()
	hc := hashCode(uuid)

	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, ts)
	_ = binary.Write(buffer, binary.BigEndian, uint32(r))
	_ = binary.Write(buffer, binary.BigEndian, uint8(3))
	_ = binary.Write(buffer, binary.BigEndian, uint8(0))
	_ = binary.Write(buffer, binary.BigEndian, hc)

	hb := hmacBase64Value(buffer.Bytes(), utdidHmacKey)
	_ = binary.Write(buffer, binary.BigEndian, hashCode(hb))

	return base64.StdEncoding.EncodeToString(buffer.Bytes())
}

// HashCode 计算字符串的hashcode
func hashCode(str string) uint32 {
	if str == "" {
		return 0
	}

	b := []byte(str)
	var r uint32
	for i := 0; i < len(b); i++ {
		r = uint32(b[i]) + 31*r
	}

	return r
}

// HMACBase64Value 计算hmac值
func hmacBase64Value(in []byte, key string) string {
	h := hmac.New(sha1.New, []byte(key))
	h.Write(in)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

func digits10toMy64(x int64) string {
	table := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")

	index := 11
	arr := make([]byte, index)

	for x > 0 {
		index--
		arr[index] = table[x&0x3F]
		x >>= 6
	}

	return string(arr[index:])
}

func my64toDigits10(x string) int64 {
	table := "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/"

	v := int64(0)
	for _, i := range x {
		v <<= 6
		index := strings.IndexRune(table, i)
		v += int64(index)
	}

	return v
}

func sign(op string, body []byte, ts string) string {
	reqData := base64.StdEncoding.EncodeToString(body)
	param := fmt.Sprintf("%+v&Operation-Type=%+v&Request-Data=%+v&Ts=%+v",
		signSalt, op, reqData, ts)
	return fmt.Sprintf("%x", md5.Sum([]byte(param)))
}

// RandString 生成随机字符串
func generateRandom(count int) string {
	rndBytes := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")
	rndBytesLen := len(rndBytes)
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytes[tools.RandIntn(rndBytesLen)])
	}

	return string(buffer)
}

func intToBytes(x int) []byte {
	var buf = make([]byte, 4)

	binary.BigEndian.PutUint32(buf, uint32(x))
	return buf
}

// 转账密码相关
func getEncryptedInputValueAndClientRandom(password string, serverRandom []byte) (string, string) {
	js := "./abc/bin/cfcasip.js"
	jsBytes, err := ioutil.ReadFile(js)
	if err != nil {
		panic(err)
	}
	vm := otto.New()
	_, err = vm.Run(string(jsBytes))
	if err != nil {
		return "", ""
	}

	// 支付密码是6 登陆密码18
	maxLength := 6
	if len(password) > 6 {
		maxLength = 18
	}
	enPwd, err := vm.Call("getEncryptedInputValue", nil, password, maxLength, serverRandom)
	if err != nil {
		return "", ""
	}

	fullClientRandom, err := vm.Call("getEncryptedClientRandom", nil)
	if err != nil {
		return "", ""
	}
	random, _ := fullClientRandom.Export()
	goRandom := make([]byte, 256)
	for i := 0; i < 256; i++ {
		switch random.([]interface{})[i].(type) {
		case float64:
			goRandom[i] = byte(random.([]interface{})[i].(float64))
		case float32:
			goRandom[i] = byte(random.([]interface{})[i].(float32))
		case int64:
			goRandom[i] = byte(random.([]interface{})[i].(int64))
		case int32:
			goRandom[i] = byte(random.([]interface{})[i].(int32))
		case int8:
			goRandom[i] = byte(random.([]interface{})[i].(int8))
		}
	}
	//fmt.Println(hex.Dump(goRandom))

	rsaKey := `-----BEGIN PUBLIC KEY-----
MIIBCgKCAQEAzUEgI4XTYiYkxY/Pb7wYqqOXSDm7tKST1PfQ7fXPxK/Zx5HvPVbi
FYBl7DBOw+yw/k0MR5BJWF4L/Po7RpWgm/LwqIHVN30HMFxu9TFeizTTW6/OkigQ
GzdtlLqFCrVUCYezZHSB5HxwLFxiUgN/JTJZQ7U+xgRF1X+Fjr2OkZkD1N/vITQz
vnyrzVY0pgen7Mi4sEoYjMfyyqeYFeQ6ORuQP0Lann2RCZWfyAF9WRDS7/1pUZso
/SdxL66BR/lxDBKkfDq6NHexgoODRmwb6QWHTuXiUjuGpy9Kn/MbqUaFrWUExmKK
BvjxgRs6K1C3qVcxnUX881L5OE1NQH4tpwIDAQAB
-----END PUBLIC KEY-----`
	key := tools.DecodePublicKeyPEMData(rsaKey)
	outClientRandom, _ := tools.RSAEncryptNoPadding(goRandom, key)

	return enPwd.String(), base64.StdEncoding.EncodeToString(outClientRandom)
}

//func rpcDecrypt(inData []byte, deKey []byte) []byte {
//	key, iv := getSM4KeyAndIV(deKey)
//	ret, _ := tools.SM4CBCDecrypt(inData, key, iv)
//	return ret
//}
//
//func rpcEncrypt(inData []byte) ([]byte, []byte) {
//	secKey, secData, deKey := enCryptRPC(inData, 3)
//	crypeType := []byte{0x03}
//	secKeyLenth := intToBytes(len(secKey))[1:4] //取长度三字节
//	crypeTypeX := []byte{0x0d}
//	secDataLenth := intToBytes(len(secData))[1:4] //取长度三字节
//
//	bodyArray := [][]byte{crypeType, secKeyLenth, secKey, crypeTypeX, secDataLenth, secData}
//	body := bytes.Join(bodyArray, []byte{})
//
//	return body, deKey
//}
//
//func enCryptRPC(inData []byte, mode int) ([]byte, []byte, []byte) {
//	// 生成随机数
//	k := []byte(generateRandom(16))
//
//	// 读取sm2 曲线
//	pubKey, _ := R.ReadPublicKeyFromMem([]byte(pemRsaPub), nil)
//
//	// 乘法
//	curve := sm2.P256Sm2()
//	x1, y1 := curve.ScalarMult(curve.Params().Gx, curve.Params().Gy, k)
//	x2, y2 := curve.ScalarMult(pubKey.X, pubKey.Y, k)
//
//	// 生成了secKey和deKey
//	secKey := compress(x1.Bytes(), y1.Bytes())
//	deKey := compress(x2.Bytes(), y2.Bytes())
//
//	// 获取到加密的Key和IV
//	key, iv := getSM4KeyAndIV(deKey)
//	secData, _ := tools.SM4CBCEncrypt(inData, key, iv)
//
//	return secKey, secData, deKey
//}
//
//func compress(x, y []byte) []byte {
//	com := byte(0x2)
//	if y[len(y)-1]&0x01 == 0x1 {
//		com = 0x3
//	}
//
//	return append([]byte{com}, x...)
//}
//
//func getSM4KeyAndIV(inData []byte) ([]byte, []byte) {
//	dekey1 := inData[0x0:0x10]
//	dekey2 := inData[0x10:0x20]
//	dekey3 := inData[0x20:0x21]
//
//	key := make([]byte, 0x10)
//
//	for i := 0; i < 0x10; i++ {
//		key[i] = dekey1[i] ^ dekey2[i]
//	}
//	iv := []byte{0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F}
//	iv[0] = dekey3[0]
//	return key, iv
//}
