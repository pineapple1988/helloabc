package abc

import (
	"awesome/tools"
	"bytes"
	"compress/gzip"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-http-utils/headers"
	"github.com/golang/protobuf/proto"
	"image"
	"image/draw"
	"image/jpeg"
	"io"
	"io/ioutil"
	"net/http"
	"sort"
	"strconv"
	"strings"
)

func (a *Account) addBaseHeader(op string, body []byte) *http.Header {
	ts := digits10toMy64(tools.TimestampEx())
	s := sign(op, body, ts)
	return &http.Header{
		"AppId":            {appID},
		"productId":        {productId},
		"WorkspaceId":      {workspaceID},
		"Version":          {"2"},
		"appversion":       {bundleShortVersion},
		"x-mgs-encryption": {"1"},
		"productVersion":   {productVersion},
		"Accept":           {"*/*"},
		"Accept-Language":  {"zh-cn"},
		"Accept-Encoding":  {"gzip, deflate, br"},
		"Operation-Type":   {op},
		"Platform":         {"IOS"},
		"Did":              {a.UTDID},
		"User-Agent":       {fmt.Sprintf("MbapMPaaS/%s CFNetwork/1120 Darwin/%s", bundleVersion, tools.KernelVersion(a.SystemVersion))},
		"Ts":               {ts},
		"Sign":             {s},
		"UniformGateway":   {urlMgw},
		"thsessionid":      {a.thsessionid},
		"sepID":            {a.SepID},
	}
}

func (a *Account) aliPost(header *http.Header, body []byte) ([]byte, error) {
	// gzip 压缩
	bodyZ, err := tools.GZipCompress(body)
	if err != nil {
		return nil, err
	}

	// 生成key
	aesKey := generateRandom(16)

	// 对key进行rsa加密
	rsaPub := tools.DecodePublicKeyPEMData(pemRsaPub)
	aeskeyE, err := tools.RSAEncrypt([]byte(aesKey), rsaPub)
	if err != nil {
		return nil, err
	}

	// 对数据进行aes加密
	bodyE := tools.AESCBCEncrypt(bodyZ, []byte(aesKey), defaultIV)

	// 组包
	buffer := bytes.NewBuffer([]byte{})
	// key加密类型
	buffer.Write([]byte{0x01})
	// key加密后长度
	buffer.Write(intToBytes(len(aeskeyE))[1:])
	// 加密后key
	buffer.Write(aeskeyE)
	// 数据加密类型
	buffer.Write([]byte{0x0B})
	// 数据加密后长度
	buffer.Write(intToBytes(len(bodyE))[1:])
	// 加密后数据
	buffer.Write(bodyE)

	// 生成req
	req, err := http.NewRequest("POST", urlMgw, bytes.NewReader(buffer.Bytes()))
	if err != nil {
		return nil, err
	}

	// 添加header
	if header != nil {
		req.Header = *header
	}

	req.Header.Set("thsessionid", a.thsessionid)

	// 执行http请求
	resp, err := a.c.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()

	// 处理返回头中的 thsessionid
	if resp.Header.Get("thsessionid") != "" {
		a.thsessionid = resp.Header.Get("thsessionid")
	}

	reader := resp.Body
	if resp.Header.Get(headers.ContentEncoding) == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return nil, err
		}
	}

	// 全部读出来
	respData, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}

	if string(respData) == "down" {
		return nil, errors.New("系统正在维护")
	}

	// 对返回数据进行解密操作
	respD := tools.AESCBCDecrypt(respData, []byte(aesKey), defaultIV)

	// 解压缩
	respZ, err := tools.GZipUncompress(respD)
	if err != nil {
		return nil, err
	}

	return respZ, nil
}

func (a *Account) qryPaperGoldAuPrice() {

	body, _ := json.Marshal(&map[string]interface{}{
		"step": "paperGoldAuPrice/qryPaperGoldAuPrice",
		"_requestBody": map[string]interface{}{
			"thsessionid": "",
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.bankabc.investhome", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"paper_gold"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("qryPaperGoldAuPrice post err=%+v", err)
		return
	}
	a.logger.Infof("qryPaperGoldAuPrice req >>>> %s", string(body))
	a.logger.Infof("qryPaperGoldAuPrice resp>>>> %s", string(resp))
}

func (a *Account) afterloginPb() {
	timestamp := strconv.FormatInt(tools.TimestampEx()/1000*1000, 10)
	reqObj := &SwitchInfoReqPb{
		ClientVersion:    proto.String(bundleShortVersion),
		Utdid:            proto.String(a.UTDID),
		UserId:           proto.String(a.PhoneNumber),
		Imei:             proto.String(""),
		LastResponseTime: proto.String(timestamp),
		SystemType:       proto.String("ios"),
		ProductId:        proto.String(productId + "-product"),
		MobileBrand:      proto.String("apple"),
		MobileModel:      proto.String(tools.PhoneName(a.Model)),
		OsVersion:        proto.String(a.SystemVersion),
		Manufacturer:     proto.String("apple"),
	}
	body, _ := proto.Marshal(reqObj)

	header := a.addBaseHeader("alipay.client.switches.all.get.afterloginPb", body)
	header.Set(headers.ContentType, "application/protobuf")

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("afterloginPb post err=%+v", err)
		return
	}

	respObj := &SwitchInfoRespPb{}
	_ = proto.Unmarshal(resp, respObj)

	a.logger.Infof("afterloginPb req >>>> %s", proto.MarshalTextString(reqObj))
	a.logger.Infof("afterloginPb resp>>>> %s", proto.MarshalTextString(respObj))
}

func (a *Account) getServerRandomNum() *getServerRandomNumRes {
	res := &getServerRandomNumRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data":        map[string]string{},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankUser.getServerRandomNum", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("getServerRandomNum post err=%+v", err)
		return res
	}
	a.logger.Infof("getServerRandomNum req >>>> %s", string(body))
	a.logger.Infof("getServerRandomNum resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) genLoginInit() *genLoginInitRes {
	res := &genLoginInitRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data":        map[string]string{},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankController.genLoginInit", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("genLoginInit post err=%+v", err)
		return res
	}
	a.logger.Infof("genLoginInit req >>>> %s", string(body))
	a.logger.Infof("genLoginInit resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) userRegCheck() *userRegCheckRes {
	res := &userRegCheckRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"mobileNo": a.PhoneNumber,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankController.userRegCheck", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("userRegCheck post err=%+v", err)
		return res
	}
	a.logger.Infof("userRegCheck req >>>> %s", string(body))
	a.logger.Infof("userRegCheck resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) inputPhoneCheckForLogin() *checkForLoginRes {
	res := &checkForLoginRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"mobileNo": a.PhoneNumber,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankcontroller.inputPhoneCheckForLogin", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("inputPhoneCheckForLogin post err=%+v", err)
		return res
	}
	a.logger.Infof("inputPhoneCheckForLogin req >>>> %s", string(body))
	a.logger.Infof("inputPhoneCheckForLogin resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) loginPreHand() *loginPreHandRes {
	res := &loginPreHandRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data":        map[string]string{},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankController.loginPreHand", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("loginPreHand post err=%+v", err)
		return res
	}
	a.logger.Infof("loginPreHand req >>>> %s", string(body))
	a.logger.Infof("loginPreHand resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) getSepID() *getSepIDRes {
	res := &getSepIDRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"mobileNo": a.PhoneNumber,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankController.getSepID", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"point"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("getSepID post err=%+v", err)
		return res
	}
	a.logger.Infof("getSepID req >>>> %s", string(body))
	a.logger.Infof("getSepID resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 登陆
func (a *Account) loginAuth(serverRandom, randNum, loginPreHandN string) *loginAuthRes {
	res := &loginAuthRes{}

	sr, _ := base64.StdEncoding.DecodeString(serverRandom)
	enPwd, clientRandom := getEncryptedInputValueAndClientRandom(a.LoginPwd, sr)

	dataMap := map[string]interface{}{
		"deviceInfo":     a.DeviceInfo,
		"version":        bundleShortVersion,
		"mobileNo":       a.PhoneNumber,
		"clientIp":       "",
		"deviceToken":    a.deviceToken(),
		"lbsStr":         " # # # # ",
		"deviceType":     a.Model,
		"isCleanSession": "",
		"loginType":      3,
		"password":       enPwd,
		"activeState":    a.ActiveState,
		"clientRandom":   clientRandom,
		"agent":          "iphone",
		"submitCode":     "",
		"loginPreHand":   loginPreHandN,
		"lbsAddress":     "",
	}
	if a.ActiveState != "1" {
		dataMap["randomNum"] = randNum
	}

	bodyMap := &map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data":        dataMap,
			"thsessionid": a.thsessionid,
		},
	}

	body, _ := json.Marshal(bodyMap)
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankUser.loginAuth", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("loginAuth post err=%+v", err)
		return res
	}
	a.logger.Infof("loginAuth req >>>> %s", string(body))
	a.logger.Infof("loginAuth resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 登陆获取刷脸数据
func (a *Account) faceAuthLoginParamGet(randNum string) *faceAuthLoginParamGetRes {
	res := &faceAuthLoginParamGetRes{}

	bodyMap := &map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"newMobileFlag": "1",
				"randomNum":     randNum,
				"mobileNo":      a.PhoneNumber,
			},
			"thsessionid": a.thsessionid,
		},
	}

	body, _ := json.Marshal(bodyMap)
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankcontroller.faceAuthLoginParamGet", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("faceAuthLoginParamGet post err=%+v", err)
		return res
	}
	a.logger.Infof("faceAuthLoginParamGet req >>>> %s", string(body))
	a.logger.Infof("faceAuthLoginParamGet resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 点击"限额/支付"
func (a *Account) initUserType() *initUserTypeRes {
	res := &initUserTypeRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"thsessionid": a.thsessionid,
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.safecenter.safecenterlogonpwd.initUserType", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"safecenter_login_setting"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("initUserType post err=%+v", err)
		return res
	}
	a.logger.Infof("initUserType req >>>> %s", string(body))
	a.logger.Infof("initUserType resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// step01
func (a *Account) softtokenmng01() *softtokenmng01Res {
	res := &softtokenmng01Res{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"device_info": a.DeviceInfo,
			},
			"thsessionid": a.thsessionid,
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenmng.softtokenmng01", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_mng"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("softtokenmng01 post err=%+v", err)
		return res
	}
	a.logger.Infof("softtokenmng01 req >>>> %s", string(body))
	a.logger.Infof("softtokenmng01 resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 获取刷脸参数
func (a *Account) getFaceAuthParam() *faceAuthParamRes {
	res := &faceAuthParamRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data":        map[string]string{},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenmng.getfaceauthparams", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_mng"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("getFaceAuthParam post err=%+v", err)
		return res
	}
	a.logger.Infof("getFaceAuthParam req >>>> %s", string(body))
	a.logger.Infof("getFaceAuthParam resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 刷脸
func (a *Account) tryFace(param *faceAuthParams) *faceAuthRes {
	authRes := &faceAuthRes{}

	wcp := &map[string]interface{}{
		"cuid_2":   "123456789",
		"wloc":     "0.000000:0.000000",
		"fk_wcp":   fmt.Sprintf("fp=&diskCapacity=%d&upTime=%d", a.DiskSpace, tools.RandBetween(5*86400, 30*86400)),
		"wibk":     "false",
		"wmip":     a.LocalIP,
		"operator": fmt.Sprintf("%s-%s", a.MNC, a.MCC), // mnc-mcc
		"bundleId": "com.bankabc.iphonerelease",
		"nettype":  1,
		"appname":  "中国农业银行",
	}
	wcpBytes, _ := json.Marshal(wcp)
	b64Wcp := base64.StdEncoding.EncodeToString(wcpBytes)

	// 图片要求 256*256像素
	// 读取图片数据
	origImgBytes, err := ioutil.ReadFile("./abc/bin/111.jpg")
	if err != nil {
		panic(err)
	}
	// decode图片
	jpg, err := jpeg.Decode(bytes.NewReader(origImgBytes))
	if err != nil {
		panic(err)
	}
	rgba := image.NewRGBA(image.Rect(jpg.Bounds().Min.X, jpg.Bounds().Min.Y, jpg.Bounds().Max.X, jpg.Bounds().Max.Y))
	draw.Draw(rgba, rgba.Bounds(), jpg, jpg.Bounds().Min, draw.Src)
	// 开始算hash
	md := md5.Sum(rgba.Pix)
	points := make([]byte, 0x10)
	points[0] = rgba.Pix[0x8080]
	points[1] = rgba.Pix[0x8180]
	points[2] = rgba.Pix[0x8280]
	points[3] = rgba.Pix[0x8380]
	points[4] = rgba.Pix[0x18080]
	points[5] = rgba.Pix[0x18180]
	points[6] = rgba.Pix[0x18280]
	points[7] = rgba.Pix[0x18380]
	points[8] = rgba.Pix[0x28080]
	points[9] = rgba.Pix[0x28180]
	points[10] = rgba.Pix[0x28280]
	points[11] = rgba.Pix[0x28380]
	points[12] = rgba.Pix[0x38080]
	points[13] = rgba.Pix[0x38180]
	points[14] = rgba.Pix[0x38280]
	points[15] = rgba.Pix[0x38380]
	md = md5.Sum(append(md[:], points...))

	processID := strings.ReplaceAll(tools.NewUUIDUpper(), "-", "")
	timestamp := strconv.FormatInt(tools.TimestampEx(), 10)
	ua := fmt.Sprintf("BDRIM-1.2.0.0-IOS-Channel_%d_%d_iPhone_%s_%s_%s_%s",
		tools.ScreenWidthPx(a.Model), tools.ScreenHeightPx(a.Model), a.Model, a.SystemVersion, bundleShortVersion, bundleVersion)
	ctx := &map[string]string{
		"name":       param.CstName,
		"identity":   param.Did,
		"processid":  processID,
		"encode":     "utf-8",
		"datetime":   timestamp,
		"validbegin": param.StartTime,
		"type":       "certinfo",
		"is_save":    param.CstNo,
		"idtype":     param.DidType,
		"ua":         ua,
		"client":     "ios",
		"validend":   param.EndTime,
		"wcp":        b64Wcp,
		"sp_params":  "CwAAAAAAAADOlgrwtv7d+UA7MkQ8xT+H",
		"imgdigests": strings.ToUpper(hex.EncodeToString(md[:])),
		"image":      base64.StdEncoding.EncodeToString(origImgBytes),
	}
	ctxBytes, _ := json.Marshal(ctx)
	aesKey, _ := hex.DecodeString(faceAesKey)
	enCtxBytes := tools.AESCBCEncrypt(ctxBytes, aesKey, defaultIV)

	body := &map[string]string{
		"signType":      "MD5",
		"bizContent":    fmt.Sprintf("%x", enCtxBytes),
		"appID":         "1010",
		"apiID":         "faceR.match",
		"isNeedEncrypt": "true",
		"charset":       "UTF-8",
		"timestamp":     tools.TimeFmtEx0(), //20210206160848613
		"apiVersion":    "1.0",
	}
	keys := make([]string, 0)
	for k := range *body {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	str := ""
	for _, v := range keys {
		if str != "" {
			str = str + "&"
		}
		str = fmt.Sprintf("%s%s=%s", str, v, (*body)[v])
	}
	str = fmt.Sprintf("%s&key=%s", str, faceMD5Salt)
	md = md5.Sum([]byte(str))
	// 添加sign
	(*body)["sign"] = fmt.Sprintf("%x", md)

	bodyBytes, _ := json.Marshal(body)

	req, _ := http.NewRequest("POST", param.FaceAuthURL, bytes.NewReader(bodyBytes))
	req.Header.Set(headers.ContentType, "application/json; charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("BankABCPro/%s (%s; iOS %s) SAPIBiometricLib/1.3.6",
		bundleShortVersion, a.Model, a.SystemVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate, br")

	resp, _ := a.c.Do(req)
	// 如果是gzip需要解压
	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return authRes
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		return authRes
	}

	_ = resp.Body.Close()
	type faceRes struct {
		Sign     string `json:"sign"`
		RespBody string `json:"respBody"`
	}
	enRes := &faceRes{}
	_ = json.Unmarshal(respBody, enRes)
	// 解密数据

	enBody, _ := hex.DecodeString(enRes.RespBody)

	//fmt.Println(hex.Dump(aesKey))
	// 对数据进行aes加密
	deBody := tools.AESCBCDecrypt(enBody, aesKey, defaultIV)

	_ = json.Unmarshal(deBody, authRes)

	return authRes
}

// 提交刷脸返回的数据 验证刷脸是否成功
func (a *Account) secFaceAuth(content *faceAuthContentRes) *secFaceAuthRes {
	res := &secFaceAuthRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"faceScore":    fmt.Sprintf("%f", content.Result[0].Score),
				"faceLiveness": content.ExtInfo.Faceliveness,
				"logID":        fmt.Sprintf("%d", content.LogID),
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenmng.secfaceauth", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_mng"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("secFaceAuth post err=%+v", err)
		return res
	}
	a.logger.Infof("secFaceAuth req >>>> %s", string(body))
	a.logger.Infof("secFaceAuth resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) secFaceAuthNew() *secFaceAuthNewRes {
	res := &secFaceAuthNewRes{}

	// 图片要求(宽*高)480*640像素
	// 读取图片数据
	//origImgBytes, err := ioutil.ReadFile("./abc/bin/111.jpg")
	//if err != nil {
	//	panic(err)
	//}
	//b64Img := base64.StdEncoding.EncodeToString(origImgBytes)

	//timestamp := fmt.Sprintf("%d", tools.TimestampEx())
	//key := "hidden_c" // hidden_cw
	//enTimestamp, _ := tools.DESECBEncrypt([]byte(timestamp), []byte(key))
	//b64EnTimestamp := base64.StdEncoding.EncodeToString(enTimestamp)
	//fmt.Println(b64EnTimestamp)

	// 这些数据现在改为 手机端提交上来
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"bestImg":    "/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAAqACAAQAAAABAAAB4KADAAQAAAABAAACgAAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgCgAHgAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMABgYGBgYGCgYGCg4KCgoOEg4ODg4SFxISEhISFxwXFxcXFxccHBwcHBwcHCIiIiIiIicnJycnLCwsLCwsLCwsLP/bAEMBBwcHCwoLEwoKEy4fGh8uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLv/dAAQAHv/aAAwDAQACEQMRAD8A9swKXAptKOlcprcABS4FIKWmZiYFJilooAcBxTu1IOlL2pANowKDRmgYiinYFMzTsmmSS4FLSUtSaiilwKbRQIXj0o/CkoouIKDSCnVRI3AqVcUyloETZpuKiZjSB2pFE2KXAqHe1G80CJ+KTIqHeaTPNFxljipMD0qAGnh6Ch3FLTMinA1RA/Ao4ozSZFIYUmBRkUtMkTA9KTAp1NzQAtNNOJppNIsi4pOKU03NAgOKaRS5phakUMIFMxzTjSUmMbgUYFLRSAdtFG0UtLSuWR4oxTqSqJGbRRtFOpKZmO2Cl2igUuak2DaKMCkpM0wHYoxTc0UgP//Q9pp9NFPxXKUJRRRTELRRRSKHDpSmkHSloJIzTc0ppMUxh1qWmKOaloJHClptOqTUSiiimQLRRRSGIKdTRTqokViFGTTN7HBUcGpacAKQyEg0m01NijFBJDilK08iimMbijBp9KKVihuKKdTcUCCjmlpKYBk0mTSZpRTJHBiKXcaSkqblDtxpMmm0ZouAuTSUUUxCUlFFACnpUNSk8VFUmo2kNGaSmSNp2KM84p2aVhhRmikpWGPoooplDaDRRTMxlOptOoJCjiiimIccU3FSYpNtQbn/0fa6etMp61ylikUgFOPSkFAgpKcaKAGikPSlHNGKZIlFLijFI0Hin0wZxT6QxtGKKWmQJS0UUDFooopDFFKBSU8UxDhT6bS0CFopM0A0hikU3FSZFMOO1UMMCnYpKXNAxuKYRT80uKCCPBpKkxSUDI6WnUYoFciopTRQSOpKWkxSKCmnpT6TFADaKXFGKBjCDioyKnIphFIorYoxTqKozG7ec0tLSUrDuOpKWikVcbS0UVRAtFLRikUNpaXFJQAtJRRQA6ijFGDSKP/S9pqVagqdTxXKUTHpTaU9KQUixtJRzilpmY3pRQaTNMQ40UlFIoeKkqNakNABSU6koGNooooEFLSUtAC4p9NFPoAfiloopDExRilooAaKWloqhDcUYxTqKAE5peaXFGKCxKSlooASiiiggSjANGaKADFHFLSVJZEaSiiqMh1FFFIoQ00inUhpiG7abipaTFIsj20m01JRSKItpo2mpKSggbtNG2n0UwDApCvpTqKRQzBo2k0+igYzFAFPooENooopkn//0/aBUq1EKlWuQ1HDNA60ZoFMgdRmloFIYUmKdijFMRERRjNOI5pRQA4CnGiimISl7UUUANooNFIYtKKSikUKKlFRCpBTJH0UgooAdRRS1SELijFLRSGNxS4paKAGYoxTqKYhmKSn0hFACUUtGKRQlJTsUYoAbRS0UhDOKMUpGaQjFIZHRQKKogdSUtJSKEopM0mTQMMUUhNMJNAEmaM1Hk0uTSLH5oplKKLALmkyabnFJupkEuaTNM3GjcTQMlpKZmjNKxQ7OKM0yjNMk//U9nxUgpgpwrkLJO1KKQUtMQ+lxSCnUiwoopRQIaetA4oopki7qM02loAXNLSUUxCmkpxptSWFLikp1AhBTxTRUgpiFpRRRSLHUtNpaaJEoooqiRaKSigB1GaKKQwooooAbSUtFMQtJTqSkUJRS4pMUrAJSGnUmKQEFBp+DSEVRA2kpxpMUDEop2KTFSXcbSEU/FJQMiwaSpaaRTJG0U7FIRQMZRRRQISijFFMkKSloxQAtFGKKRR//9X2qilxRiuQ1HL0p1NXpThTIJBRSZooAWlpuaXPFIsZRTc0uaZBIDS00UtIsKWm0uaZAUUUUAKKfTBTqBhTxUdPzQIfSUUc0hjhS0wZp+aoQ6ikzRmkUJRRmjNMi4UUUUDuOopKSgdx1FNpaVguFBpKWmTcXNLTaM0FXCkxRmjNIm4YoxS5pKRQwrTdtSUUwK+KMVJik20yBDSGpMUmKRRHRTyKbigsZimkU+koJEwaUU6ikUNx3oxSmigBtFOxRigY2jFLijFAH//W9pp2BSDrTq5SgHSnCmLTqYiekNFIak0G0lFFMgSiikoGLQKQUtBJNRSClpFBRRRQAgpaQUtMQtOplOBpiA0lKKUUCHCng0ylFAx2aKSimIKSiloJFoptFBQUZpKKCQzS5pKKAHZpabRmgodRRRSEOzS5ptITU3NLATSUwZzT6YgpKWigAzRRRSLFopKKAGGozTzUZqjIKSnUUirhRRRSKCkpaKACkoozQAUUUUDP/9f2sUuKKWuUsMUoNJRQA7NJSClpkAaSlptAxaKKKRQU5abRQBMKWmA07NAhaKSlpDClzSUmaBgDTgajzSg0yR9ApAaWmIdmlXrTacOtA2h+KKTrSigkSilopgJRRxS5zSAbRRRTJH0nvS005pFBmiiimITOKM0GkHPWkAuaQ0tGKRQ0HFLu9aaR6UhFAx25aNwqPbSYNAifcKNwqLBoxQUTbhSbhUVJQBKSDTM0lFIBM0tFFUSGKMUtFABijFOopFDcUYp1JQAmKMUtJQB//9D2ylpKdXKixtFFFUSPFLTRS1IxCabSmm0xC0UmaM0AOopM0tIoWnA02lFAiQmjNJRSLFpKWimQJS0lLSLFpRTaWgQopRTRS1SIH0tNzThQSxaWkpaYxOadSUCkAlLRSUwCiiigQlLRRQAlAooFIYtJmiikMbSU7FNphcQ0lPpMUAHNLS0UhkdFOpKYhKKU9aSpLG/SnZptFMkkzRTaWkMM0lLijFUSJSZpTSUhjs0UlFIZ/9H2wGnZqLNPBrkNGOpKTNJTBMKXNMzS5oJJDTaKKBhRRRQAlFFFAhaUdabTh1piJqKKKk0FpKKKAClpBTsUCI6KQkKMscCud1PxZoWkqxurhdy/wqcmqSuZHT01pI0+8QK8F1j4uhJz/Zse5OnzcV5xd+Pdcu2kBlISTqM9PpVKBdz60bVNPRirzICDjBNRtrmlRsUe5QMOozzXxfPrmo3DB3mYsOM5qk97dSN5jSMW65zzVchFz7Bn8e+G4AxNxu2HBApsHj/w3OodbgDJxzx+NfHfmOepzmkDuBgZxT5Aufa0PizQ7gny7pMKMnJrRg1vSbltkF1Gx9Awr4fiu5ogwUn5hg/SiO9uon3xSMpHoaOQdz7ySWJ8hGDbTg4PQ0+vizT/ABdrVgrCK5fk7jznJ967PS/i1rduxa62yjk4b9MVLplXPqGkrzPw/wDEzSNW8uG6xBM/v8ua9FhuYJwDDIrZGRg1DTAlp1GKKCRtFGKWgBuaTNLgUYpCFopabQUJSUtJQMSilxTaYhaTNIaSkMU0UlFIsWlxTc0ZoAfgUlMzRk0yCXNJuplFIoduNIaTvTqBic0hNKeKSgD/0vZRTxUYqQVygxcUlOpDTJEopaSkWPzRSUGgodRTaKRQuacKjp4oEFOFNpwpiHiloooJuMopTXM674o03Q4XaZ98qjOwHmiwHRO6RoXkIVV5JNcDrPxH0HTN8UT+dKo4A6H8a8T8TfETUtWk/wBEd4FGRhTwwrzWaV5XMjnk1soEXPTNc+KGtan5kMREcTdAOuP8a84nu7i5cyTOzMe5NQrC0h4q5Da/OFbOfSqSSNGUESRiTgmryWUrDNdJBYDy0YEDPtxWzBZiJx0wefb8KdyVE5WPSJd2DyOxrbsdDimj80rkqMkV0jW6yLheMc4x/IVoWtuwhJXGDwcdz64rNyL5DjU0uMHey4XOCPSpn0pIogzpxnFdgbRgcgZ2/wAvSonhVlKDgscgGlzMfIcfc6NErDavyDA9+azrjRDHgopIJz+Fd6lq86qF5ZWwc+lMaL9+FXGMkfSjmHynms+mPEx25PGfwqmbSVei9a9NuYFMglC8FSrD3zWebNYwgK8cg+wquYnkPP4nlgfzE4I710mj+MNX0m4NzHKzHpgnirF1pseT0BbkfSuefT5AGdQcCr0ZlY+hfDnxYtryVLbVIyrvgBl6Zr163vba7TzLeRXHsa+EwWjPHBFdZ4d8VX2iziVZGZVGAuePyqJRKPscmjNcF4a8c6driiJ2CSkcBup+vvXdgg8isrDDNJmkooCw/NJmkopFC5ozTRS0yR+eKbSZppNSULSUmaWmIKSjNGaACjFFLSLDFFBpaAEooooAKDRSUyBhpM4opDTJP//T9mFOpopetcpY7NLTBTqCRhpOacaKBXEFIetOFIfWmFxRS0cUcUiriUUUUySWlFNNLSNLjsmnA8VHXM+Jdft9HtCC37xhgD0oSIuZHi/xpa6NA1vbMHnbj6V82atqd5qc7XNzIzk+tX9Uea9uXuJCWLEk81kpaySuI0BreKsLcyfKZzgVbjsJCM7Sa7Ox0A5wy7vqK6K38Pt/EuPoal1EjdU2ebQ2DkbSpU/StpNO8tE81MejD/PFegweHhngHI9a1E0MKMMD71LqoSotnn0VmsA3bic88dK07eASnBAL9scYrsD4fZjhBj0NTDQkjwqr8/cip9oWqLRgmHAXd8xHfvVyC1YuPKBCH+ddNFosm0FhmtBdKIwrZI/Sp5zb2bOSkgCMPK5fuCcVWuLR9wMq4z6f0ru00ZjICcFR0z1qxLohlO9jj6dafMR7NnnzK9uh4GSeSKpSxImGU5Djknsa7abQHLHZwnYj/Cof7Am+7gYzRzB7NnEXEYWDaecsOfY1TmAdxGB8w4Nd7P4ddhsDADuKzP8AhHpIZQ4XIFPmE6TOOni8y4YMo2qcc9vpURsQVKkYAGF9s10lzpM32h2jBKMclT2ND2MhhzznAz+FHMg9kzgbrR1l+WMYwetc9d6dLbnIBI9fWvW3s1LDK9Bk4rMvbEuQpHyYwBTVQl0mec6Zq9xpk6zwgFkOVz619IeD/Gqanaol/Kvm4+Yj19AK+er/AEWeFmZQcCs62mnsJhLG+0qcjBrRpMwcWj7ezkZHejNeZfD/AMTnVbc29y2ZB3LZY/XsK9OrJqxI7Jpc0UYqTUTNLmkxRimQGaTNFJSGMzRuoxTaogkzRkU2ikUPoqOlyaAHYophpN1MkkoqPcaXdQBJRmm7qTdSGOpDSZphagZ//9T2bpRTsUhrlBi0tNzRuoAeaSk3UZFAx1JRmm0ALRSUhJoEOzSZpp5oxQA7NLmo6cKARWv76GwtXubhtqoM18z+KPEFxrd20i8op+XJ7V33xB1wu502F/lT7wxXldjYyahMFHQ9eK1irK4buwzTtPur1+p298V6HYaEqKNy9K1dM0xLaFVx0reVQowK56lVt6HdSpdyla2MUSgkVqLAgHSmKQOtTg5rNts2UEiZERegqwu2oBkU7NSb2LakVKm0mqSselWUPOaLk2LyirSIMfNiqSyACrEcgPGcYqiGi0FAI7U51cHPY+tMD7uVpxdepbIq7kWGkZ6dBTDggAih2XOc1AXpG1hrKuckZqGbyyOFxTmcng1A5qWwRVaNGBGOKoSW0eNu3itJjk1GRzU3KsjFayXOcVXayjbtg1ukc1A6indkuKOLv9NU54yDXEat4eLq0kAA9q9jeJWGCKz5LCNwQR171cajRjOimeDaVqNxot4JI2dGVvmAOM47V9R+FPFNprtooj3CQDkGvB/FWgNATeQj6471L4H8QSaberCz7Y3PQJkn8a6E1JHBKLiz6joqta3C3ECSpnDDuMGrGahmYUtJmimIdmjiikpFjaQ4paQigQYo20uMUUAJijFLRQAhptPpKBjcUU6koGNpM0UlAhxNNoxRQM//1fZ80maWkIrkKG0lFLTIGUtFJTETUCigVJoOpKdRimIZRSkYptAxtZmsX39n2Mk45bBxWnXj/wAQtakMg06MgKOWIPWqS1IPMb6W4v7x5JPvMeT2ru9A0xYIlLDnvXIaXD504dvujsa9MscKoFFaWljooR1uzSAcNgABf1qYAYxUYII4p2TXGegkSheasKOcVCnNWkXFBomKoJp+w9qco9KlAOOaYEG0rzVhTT1TIwelTbB6UgIDUqMT2/GkII6d6BgDBpgWI3YDBOaQ5bgkUkfFPIGc1RNhgVSMMelB6U4U3getMZCwIOaQqas7c+tPwoGAKmxaM5hUZGOtXXGetQlc0gIDjrULCrLCqzHmpYNFY03ANKxqLOKVzOxQ1O1W4gZCMgivFb+2k0q/3wkoVbKkV7zLhlxXl/im2V8nHIrejK2hhiIK1z1jwD4gfWNN8q4IMkXBPAz+Fd/XzP4A1ZbHVUt5SAkhxkgn+VfTAII4GK3lueaHWnUUVJQzNGaMUYpki0UnNHNAEtLSZoqTUKKKKAI6aaWmUzMKKKSgY+kNLkUhIoKEopM0ZoJP/9b2akpcUGuUApaKWkUNpKdikoAQU4U2nimSLS4oFLTAYRTcVIabQIoajdfY7SS4/uivmTWLl72+kkmfLMa948dXb22jOsbbS/HBxXzkh8ybByTmrguozpdMTy9oWu3tS/l5brXLabbHg5zXXQx7UArCrJHZRiXY2yKsA1BGnFWFjYmsToRZQ1cQg1AkJAqdVxSsbFhW5qbIHWqoJBqRWyaLFXLa1ZVcCswSYarQmK45BFUZ2LhWoyoJ6ZqMT5qTeuKLFDgopxX2pAwxxTWcirsKwjMTxTwcc1H5g/GomuFX73FLlKLOc0hqvFOrEkmnPcRqpbnjtQ0ArDIqIjHSmRzrKgcAjPY9acWFTYq5Xc4qq5q22CearSJuPFJxJuUn61CT3qw8ZFVTx1qSbkckmelclrcQdTnvXVuPSsPULfzUYGnB6k1FdHlcLPaXqy9AjZ96+q/Dt+NR0qG5yDlRznNfMeowCCYHHPY17V8N5WksnCsCnp0INdmjR5clZnpdJSnrSZqTMWlFFHSgsKTNJk4ptAC0UlFMQ6kpKQnFKwCk5pKbmlzTAdSUhak3VJoNoopKZmIaQUhNJTA//9f2bNJRS4rkLE7UuaSimQLmkoooGPHSlpo6U6gBaKKKBBSZpaSiwHnPxI50tSAeDzivCrEGa7UKK+ifGdqt1pUgdsBRnpXg2jx/8TIRuMGtFsOO53tjbiNAMVrqMCooYwtLNKIlzjNcj3O+C0LyOAMtxSPqccRwgziuTuNQnZyvT8apNcSn7vNUoXKlUsd0urIRk08axAD715w9xcc4T9azJL+4DYKsK09miPas9bbV7UcsaF1a1LfKcg968eW9uW6AgVbS8lX7pIz2NDggVW56/wDbI87lORTHvtuD2PSvMo9VlGATyOtX/wC1CdoJ6UnE1Uz0BL5QcE4qYXgJ+9Xn4vyZMqeK0Le/LcP+YqbGikdoLzHQ097ssvWuV+1AdDQb4KOTQO5032tiMZqrNfKmNxrAN8Bzmsm9vTIy7TjHehMps7KK/jZsdKtpqEO/DHp3rzz7dszk4OKq3GpyBNqnJ7E1ZDkenf2na7iFYf0pX1K2HzbxxXjf22fBZnOewHSq51Cf++T+NHKR7Q9ek1eAcqwNQf2zHivK0vpurE/lV+O5nPOG/HvRyIn2jPRV1eJjg81cZkkTehzXnS3Dsc4I9cVbiv7iA4j5WplTBVH1OwbrVOdcg5qC11Dz1xIhDetXAyyqcdqwtZmu6POtYjxNkDpXX/Deac3skcf3SPmXNYXiFUXAHBNb/wAPbKSS4N7E21k+Uj1FdENjhrK0j2vBpeaM0ZpnOMzRRRVCFp2abRSKHUlJmjNACGmmlNJQIMUYozRmkMWiiigojopaKZmJTadRgUDR/9D2SnUoFLiuQsZRS0tMkKKdTT1pDAU6milqiApaSimIfTTTjTKRRQ1KK0ltW+2EKgHU14rcnSRe/wChnMqNkcEZUV6R4zuvs1jGCeHbFec2Nsfs00zY3TcA+gqXI3hC6ubazJtyKzb65AUnOK5fxbaa2iW40jzWQLiTy+ufevMG+3zXAtp2k8wnGHJzn8aI0lLW5pKq1pY9TM8Rch5VX6kVajuNHj/1t1Hn2asiz8MWFmitcIZnwCxY8Z9hWqv2C24jhjXHoooatsWm2XE1Dw9/FLv/AN0Mf6VaF94a7pI30jb/AAqhHfOxPlIqqO5wBVoX8EfzT3aqO4XmpdylYe934YYYAmT/ALZN/hWdO2gvkxzlf95GH9Kutrejr/y8yN9Fqv8A25pjnakrc/3hSuykkYUzWAPyXCH6nH86hW4QfcZWA9xXUBkuVJiCyA/Q1mT6daucvAn/AHziquHoZxnLc4q/ayytwKpHRYicws8J7bDkfkc1HaTavb3p0uOBJ5+qOflUr6mla41Kx1sYmYdDTjBOT0NXLXT/ABSyg5sh7EOa2H03xRHDv22PTr+8pcptc5ORJFzWTIrFsmretapr2kAQXtnDK8x2xSRE7Sx7EHmoRoN3Mol1G4Znbkxx/Ko9uOTRawmzOd1T/WOqj3IFV/tNkx5nQ/Qk/wAq3I9HsIeRAhI7sNx/XNXkEcQxGgH0AFHMjOzMWFdMb70/5Ix/pWrAnh1R++kkJ/65N/hWit4yDGAo96tw37OMLNGPqRRzDsUo5fCqDJd/xjYf0pJdQ8NqMJOnXowI/mK2BPOw+V0b6EVTlm/56xAj1wCKXMQiv9q8PuP3V1CD/vCqkotgN8MiP7gg1NLFpc/E0EbfVRWNe+GNJukLWyeQ/YoePyoTT0ZUrmzZTndg4rdSRRnnrXgE326wuntVkcOjY+Unmu88LR65LJKdRMoi8s7TJ0z2681cqXW5lGtfSxq6rHDfXojllWMLgqD1PvXsHhnS7WwtFa3YPkDJHrXm93pccumxy4HnQqCW9fWu48GMzxS/3VAGPc0RfQxqwvqzuqKKWqMQopM0lAxc0UlJQIWkzijNNJ4oEBNNpDSUCFNGaSigYuaWm5ozQSOopM0UwJaKKKk1P//R9nBpc0gpa5bFC9KKKKLCEpuOadRTsISjFOoxRYQtLSYpaBiGgCilFAHmvxGBeGCNfc1jRQ+XbRxDsorrvGVqJktpSOA2DXNPjaCKwmd9F+4PQEqK5LX/AAzLqF/bajZBA8bfvM8ZUV2dsN4Ga0ViB49aFJorlTOXurNniyo5xXKXGmXzOdowK9PEPy4x7VTlt+elHOy/Zo8vbw/eyckk+xPFSromo+UYWhBHrmu9aIKeahYAdCapVGJ000edr4Q1SR/3jIgHHzE1tWnhJIXBnuVOOyj/AOvXSspP3iTQuEOQBT9poL2MShF4aTzPNt7p0b1CjFbqacSgWba7eoGM1HHcMvari3hHapuVGKRz2rPHYOsMW3zG6g+n9KpWLu+qm4jj3zLEEAB45Oa0tR09b26NxKMYHUegq54XsGSOS9kUqZ3LKG6hegFF1Y0S1N60j1mVRgRxfXmtafT9aMAzdJ06bK0rJeQDWxebI4gO5p20HzWPD/FNvcW8cDXz+YsMqyKw4xg85qi2rvFdYumQRsMjA5/OvQ9fsE1KzltmH3lIH1rzq301buyiN1GfNi+Rge5XjNK/cUrt6HWJZR3EKzoQVYZBFUL7TtQMezT0TJ6sxxj6VftppYIFgXhVGAKR55c9ajqVY4G80DWnjPmfvG9mz+lcvNpGrwuS1s4H0J/lXqkwZmypINV83Snh81oqljGVK557YWd2soaVHVR1PIrWZ75OLUyD65I/WuxjaUfeXJqZZWzgrilKpfoJUrHHw3N2OLmPJ9hXR2CtJjIIHvW1DBG/zEA1ppboqkgVnzGnKzidP8PuNdudWmVSrYEXcj1NdPOuxMZ5NbUdusaDPWsm7BaYKPWm5NjUUhVXMWw9CMVueDFaKO5jf+8CKytpCjPpW14cl2TywMPvcg047mVZe6zss0bqbRW55w+im0lAD80UUUFhSGlpppAMooopkDKKWigQUUtHagYlLmkpaAEpaSlpkn//0vZ6WkFFc4haWkopFC0UUUALmjNJRQAU6kpaBDKUUlApkmJ4kQNp2T/CwNcC3PSvQfEP/ILc+hFeb+ZWFTc7qOxegm8v5a1o5lHJrmxJht3pTmvPQmosdUTomuYlJKmqE12G6Vhi6fcCprTgms5EIuI2Df3kb+hqrDIJGZjmoiDVvy4HP7uX/voEU42rdQ6H8aLAUCpPShYmJ5rTW0k9V/MVJ9kcdWQf8CFOwzPCYpwGTVxrdUGWkTH1zVCSWJZVihO9ieT2Ap2A0IohN+7x8o6+9bkUYXAUYArPtgQABWvEueKARt6eoJwadfyhufSltRiIkDtVGZg7HPFPoVbUovhqwb63EEgnQYV+G9M+tb8nqKozuhUxvyD1FQM51xzUZGaSZ1tZAsxJjP3W7j61cjhgmXMcy8+vFSUUGSm7QK1PsbH7siH/AIEKY2nS9mT/AL6FBFyhgUxkB5FaA09/4pYx/wACFSLbWUZxPNn/AHRmlYdzPikaIj0rbiuopAFY49agll0+OPEMRdvVjgfkKxjulkyOPYdKLAjpLyZfL/dnms6FWlYO1VFWUNhulaMJwKCWiy44rQ0oBZBN/dbH51lNJxitDSZQ9ytt/eO4/hTW5FTY7nHNFNzSZrc85js07FR1JQAmKMUtFMQw0lONNoJGUUtJTJCjFOpKRQ3FGDS0tMkKWiikMKSloxQB/9P2ilpuaXNcxQUUmTRmmQLRSZNFADqM0lFIoWiijNACUuaSimSY3iHP9mPXl+7mvTvETOulvtGc4B9hXlTEisZnbQ2FZqTbmowfWpwKi5rFkLfJUiyHHBpsqMx4p8VtK+B0oR0XJVuMcmpftq1dg0pSAZK1YrC1Tjbk1RJgi9foqk/hTXurk/djNdX5cSjAUVC4U8YxSLRyEjX0hwFwK09L0x1BuJe9adwqqhY9BUK6rbRxYBHHahFs1ogAK0YWAbFcdHrUYkwSMGt2C8iPzq1WJHeWNv51uQp5xWHcxFHKnsaoQ6w0H+qfb9DTJtSEuWZhk03YSTuSMRtwKz3h8w81Ra/UE4YVJFfxE8sM1DGUry32/upRkNWadKmTm2k49DXQXUySR/N17UyEfKCah2KRheRqcfG3d7inh74D5oj+VdOrYqyrjHY0htnFvNKByhH1FVWuJO9d+yxNwQKpy2lq2dyDmnYi5xHnsetalmuTuarsum2+eBgUqxpENo7UASleKhztNEkvYVWMmTSEydpMCug8NRh53mPVRiuSd93FdV4ekEJZvUgUR3M6qurI7Q0UtJXQeYG6gODT6XAoGR5pQadgUmKZAhOaSnbaXApFjKKkxSYoAjp+2gCn0yCPApcUGkoAdiiiigYUUUUAf//U9o4ppPOBS9qj5zXKWOooopkDqAKWigYYpaWloAZS4oopkhiiiigQ2WNJUaJwCrDBBrxzVLQ2V9JAegPH0r2bFcT4usAyJfIORw1ZzXU3pSs7Hn3vVyMAiqoq3GR2rNnXFkyRgmtOFQMetU4xxVxeBSuaovK3NS76ph6lDUXLLBc0nU5pvFPWkaFDUjstpD/smvL5LsHIYkGvVruMXETRAdRXnV1otwsjKBkZ71SQpM5Z5b2KTzIJd3+y3Stm01udVHmfK3p1FUJreW3YiRDx3xUGOhHSqMebU6X+2ZuxFKdZmIxurn9hxSrx9aVzbmY+/wBU1kt/oYUD1bk1Np97qWc3bhj7DFWoLG6uQGROD0Jq2NC1E8gDA9DUspS1NO0vpZ50hJzuPT2r0JI8KBXF6FokltP9ouPvCu5B4qSinMwhUuAWx2HWpomBUH1odN3NRAEdKZLRMWqNnphPHNRE0XM7CSNzVVmOaslahbg4qTQqMKqyErVmU4rPkfccUXJYA5bNdRoMT3MuwDCKdzH+lctjAx3rLg8eXWh3klrFGksIPOeDn61pTi5PQ5as+VHvVLiuN0PxtpOtERZMEp/hfoT7Guyrdq2559xwp1NFOpALSUtJQUJRRRQAlFApaZItFOpKRQ00lOooAbRRiigQUUUUAf/V9kpaMClxXKWJThTaXNMgWjNJS5pgOpabS5pDY6im5ooFcdRSUlADqqXcCXVu8L9GGKsk461EzUgTseL3MD2tw9vIMFDikibmu18U2Mbxi+UhWXg5OMiuD3FTispRsdlKV0bMTgirisKwUm21pQy7hiszoTNMY601mYghTg+tNSmyttUkUje5NGzqgUncR3pJLjZyTjHXNZhnZV+bJz0qtLKZB5bcCqsZuRrLdq5ymeafDDLchjj8TWfDNbRDMrAKKqXPiRUPk2eAOmaoqKcjWudBt5EJlKjPvWJ/widnK22C5AbsM1nSahLMcyyFjUa3IU7g2DRqdMaMerLcvhHUI2IGCvrWvpvhRIv3l5zUNn4mu7eIxCTcD681Vm1mW4P7yQmixSorudf/AGakShYCMDtxUE8bRjcoI9a5eDUZ4zujetiDXv4LkA+4pGMqVtjUSXYcN931q4kqbeDWezRXC+ZbEc9qoP5mAp4we9Izu0dF5gGVfg00kVktcMEBfk0q3KLjjB7jtSNOY0T7VHg0quGGRSnmkTchbFVXNTSHaDVCSUUzMrTORkVTzipZnHWqDOT1pBJj7m4EED3DdEUmvKDOLh2lbqxJr024sJ9Tj+zQMvJ+YN3rnrrwbdQMSgKsOx6H6Gqp4mnB8smebiayvymHp0kkV0AhwMZz6EV9GeEtcXVLIQTNmeIYPuPWvnuGzuLSVhcoVI6Zrf0fVJ9NvFuoGwV4IPQiu52mrowUj6TFOri9F8X2eoTCzucQz9v7rfSuyBNZNDuPzRSZpRSGGKMUUUFCilpKWgQ2iiimIKMUUUALiilpDSGNpMUtFMR//9b2WikpGNcwx1LUQNOyaZJNmk3UzNFIsM0UYFFBmJS5pKWmSS5zS1RvL600+E3F5IsaD1PX6V5hrHxFkJZNJQIg481+T+AoSua3PT7y9tLGIzXcqxIO7HFeT+IfitptkrQ6TGZ5egduEH9TXk+u67faoxa4meQjuxrhZs5JJrRQ7kXNzWfFWta3c/aL24ZsHKqDhV+gFd14d8QLqkAtrgj7Qg/76HrXmOnaZd6pOILVc+rHoPqa9W0vRrHQ4cJiWdh80hH6D2rmxNWEFZmkajizZEhU81dhlDcZrIEoc46GpEkZDkVhGSkro7YTT1R1cEgxjNTSn5a5qG+aPk1oC/SaMdjVGikMnuUD4HasK8uJSCVzgelaRHmy5zmraIifNgZqblpHm82ozSlkUOQvtVcT3XVI3z9K9EmSwdsuihqUPEn3EUgdK3i1Y2iux56o1Y/OttJg0yWbUEOJbeQfnXpSX4XAxitWO9VwN6qw9xV6FqDPF/t8iMcxv+dS/wBqsq4EchJ+lewva6ZLy1rGSeTxVmC20eIn/RY+QAcj0p2Roos8ki1eQj7sg/CrK6m55JI+oNeuhtNiB2wR8+wrPmlsz8vlpj6CocUXys85t9blgfKSY9q218RpKAGPNbJFk33ooz+ApEs7CUFGgQqTzxipaRhKAlvqiSjB5HtV1JTI23tVB7G3jJ+zoFHoKbAxiOD0zWTZg1Y62AkLipnbAzWXFOBHkmq8t8Omc+4qTS5bmmHrWVNOKqy3WSc1nT3IUZNBDJ5Zh3NU5Jgi72OBVUyFzk1HOP3W49KUnoc05aGrpPn2kpmlk8wSN16Y9q9QtJY7uIBxuB9a8106Az2DsOwyPwru7OeKx09ruY4CLn6mvCxd5S03PFxGsjz3xaIV1JoIc7YxyPQ+lciGKnIq7fXMt3cyXEhyzsSfxqjht1fV4Sm6dKMWaU1aJp+dlUmH3l4z3r3HwhrDanp2yZt0sOAT6jtXgqONmz1r0rwJf2Nks/2uVY92AoPetprQ1R65mjNUre+s7r/j3lV/oas5rAaJc0uajzS0iiTdS5qLNKOaRQ7Ip2aZilpiFzRmmZozQIkzRmm5ozQMUmikooA//9f2POKYSTRRXMMBThTaXNADqKZmkzTJJBS1HmjcaBNEtY+uazBotmbmXlzwi+pq9cXcFpEZ7hwiL3NeC+K9efVr5nU4iThAfT1qoxuBQ1DVb3Wr4yXchIznbngD0ArmNUlBfC8Adq07QlI2lb+LgVj6mQspb++P1rW1hNmFNJjPpSabpc+sXGxAViB+Z/auw0fwnJfx/btQykP8K92/+tXYmzgsYhHboEUDgCvOxGPjH3Y7k85n2dva6VaiC1UKo6nux96haUvyelLJKMnNRknbkda8qUnJ8zJIJJmXkcYq1b3ay4RyA386yZ5ckism6nMQBU854xW9FtHTSk0zsWY0I5DcniqVnM01skjdSOfrVjpXYjuTNiCUdqnaasqEgnirojkI4pmkXoQ3YR0+XqKxjLKnQkVvG2kNULiwlwSqk0yygL6YcMAw96lXVzF1U/hVdoZF6g1XeM1SbKU2jXXxIgO1gRVkeIrcnburnPs+7mj7KD2p8xt7eR0x1qF+FcVH9tibq5rAS1xyBVhYyKlyH7Zs1BfqpOwZ9zVmC4nnPUge1ZsNu0hHFbkMDRrg8VDYnNs0I3CqBULtjJNNwQKjfO01BMmQyXTKmM8VRMpzkGmy4zjNVWcDiqMCy0pxjNVXJc81HuzTxk0ENllRUk4Bi201OlSbTJKsYGcmspbFT2uddoVsosWTHJU8Vz3iLVhJDFp8JOFG58dM+ldS8yaRpb3JxwvA/wBo9BXkjytI5d+rHJrny/DqrVc5LRHhW5pthvHemlhnNIR3ppPOB+NfRmw7zQimRulTW08g+c9+1ZQb7RLtH+rT9TWmg9aZB1+h3xivoXMnlqGG5j0xXuMN5a3AzBKj/wC6Qa+aorryXxs38fTFWl1G6icvECB6A81E43KTsfS1BrwG28XaxachpCB2JDD8q6vT/iEJSEukBPfHyn8qxdNmyZ6jmng1zdn4m0i8wFl2MezVvI8cg3RsGHqDmoaAkpc1HzmnGmQOzRmo6UZoAsUU2lqTUMUYzS0maAP/0PYKKSlrmKEoqKWaKBDJO6oo7scCuT1DxvpFmSlvuuXH9z7v/fRqrNknY0V5Hc+PdVlJ+zxxwL/32f14rDuPFety8NcOP93A/lVKmxcx7tJLFEN0jBR7nFY114k0m0B3S7iOy814Hc6neXH+tmdvqxrMd5G53t+dUqQ3I7rxJ4ifVLgmPKwRD5V9T6muC+a6uNrcL1P0qyrKYQrnrT1ZFjIX8+9aKNtDO4yRl+5GMKvAFaehabaahqCfaxnygWA7EisXvkVv6C/lalCc43ZU/jWWI/hysRLZnfT8sEAAx6VzWoFskHnFdIUJLNmuev0JJC18fGWupzQObB+fnmiZsIMGiQbG4qF+V3HtXUmdCMiduorHQCa43DkLWnek+WzVUs0AX3r0KMdLnXSib+myYLRHoea0SGiOV5HpWJasY7lT68V0JGea3OxDoZhkMOvpW/ayrIK5OWNlPmR53elOttQIIWT5GoLjKx3yKhqysaHjFcrBq6g7WI+taKapFjrQaqSNWSyt25IHPrVCTSrZjnbS/b4zjcR+dL9tiP3WFBRTk0uAD5RUCaYjNitV5g4qLzAp4NBoRJokXUmp00SEHJOamiulC4Y1YW8Qd6QhY9OhiGQKilQDoKc98mME1Va7UqaljuRuFUZrJuLgD5VOaZeX6gE5wK5t78u5SLmixLkX5Jsnjk1XyTUca85brU4HNUYbiqKsKM01VqUYUZPAqWVYX7q7jW3o9kZZxK46Vk28ZnYMRx/CP61pX+rR6Xb/AGa2P+kMuP8AdB7/AFrGfNL3Y7nDiqlo8qKPinUhPcCwhP7uHrju1cpxSkljuY5J5JpCQK9bDUFSgoo4oxsrDWbHAqjPMXkFtHyzdSOwourhLaEyseew75qKwt3C+dL/AKyTk/4VuUatunloI1HAqwzqilj25pinaMVQuZfOkFuvQctTGW7eTzE8wdSauq/YiqFquyM/WrgxQySwSD0qNljk4kHPqOCKTNJmkWSRrND/AKuTIH97r+dbNrrGq2jDy3YD/ZOaxAamV8dOtFgO+tPHd7BgXI8wD1GDXT2njnSp8LPmMn8RXj4dm6GlLN24qXBMfMz6EtdU068GbadH9gRn8q0a+aBNIhyDgjuK3rDxRq9h/qpi6/3X+YfrUOn2FzHvlKK840/x/DIAuoRbD/eT/Cuxs9b0y/H+jzKT6Hg1m4NF3Nc0YFGfSlqSj//R9A1HxJpGmZWWUPIP4E+Zv06Vw9/461CfKafEsC/3n+Zvy6VwqkHnpTi+BSUEibli8u7u8cvezvMfRjx+VUldd2D0qOWQk+lQbjnmqSEXnmgTeCOOgNQyT2jtvGRjt61UlORVYnFaKdhNGmfs0hbG3luPpTDBCsLPGu85I654H41kscnNNJNX7VdUTykyyAkr6ClL84NUYD+/cH0qVydp9azuFi4PvAetbenKBqFuB2OTWHbsrqCD061sWG972MDrntXNX+BhJ6HqDx7YuKwL1AAT6105XdCM9qxLuIEHNfFOVpHDF2OIuo8EtVCXJXPQAVtXiAqRjpWRMNkfTPFdlNnRF6nPXrZjI9TTrZML71WuWaS42noK04UwoNevSVonp0URnKkMOorpIpBJGrg9RWAy5yKtWUxQ+S3TtWh02NU+tVbi3ScYbgjpVn3oPNAWMGW3vLf5oTvHoagXUHjbbKpUiugOaryQxSZ3qDmncLdigmrAdSatpqqnndj61ny6XG3MeVqjJp7gbQcn1qkkx80kdWurKV4YYpP7VQ/xVxptJgox296b9luW4H86rlRn7SR176qqnBOaaNXB71yRs7knjP4mnJYXJ5LYosivaSOpk1qMDl8VUfXmfKQgsay49OXO58n61pxW6J90AVnJI0TkyrEt1dHdckqPStOKFIhhB+NKowM1KGqWCRIuKmGDVcyKveqkt4RwgyaRpdGq0iIMsaZEGuGy/CDoKzIt0r7pDyO1XpLoWy4UZY9BTUG9ERKokjSnv1sIsRnMzDAH90etcw8jyMXkYsx6k0FnZmeQ5JOSaQkda7qNBQ16nmVJczuSEjbzVGadIxuJ2hf1ptxcIgIB+uP5VmMkty67uMn5V9B6mtyBkCSajefaJR+7j6D1roMc5pscawRiJei96az4yc8UxDbq4EMRbqx4A9TUNrGY03P95+SarwE3k/ntzGn3fc+taqrubpwKpEE4XAFTAe1MHHJ5p5bHFJlIKKbuHXNG7mlYdx1PBqHdTw1OxJbQ4qTeKpb6NxpFE5IJpwqtmpFbtRYRZUDrVhGKEGNip9RVPNSq1KxR09l4h1aywI5iy+jciuwsfHUbYS+jIPdk6flXlqsRzmnjnmpcExpn/9LhQ+BTJHJHFVw+OKCwxzWljIUtnvTN4zio2akFSWStyM1UkOTxVhmyKrHrVWIG5pMUUCkBSkfyZlY9DVxiGP1rO1IERh/7pqxbSCWIOKBCNILWbOfleup0uYLdxyiuauYxLEVP1FSaTeCVPLZsMhxxWdSHNFoGj6FgYyQCRuOBWTeYyeKzfDusedGLG4OXH3Se9bt1AXJZRkivicTQlSqNSRyyVmcddQ9cDiubv1KxgKDk13U8PykMMVzN9AxHSroyHCRw3l5nOOprVjT5QKrSx7JwK0Iwa92m/dPaobELR85qAoQ2RwRWmVzUbxg1ZuEM+cK1XM1lMjKeKsxSnoaBlk0zBPSpQaXrQFimR61Ay8VoYB61GyA0yLFDbTcDpirbRjtUXlnNIsiCijAqbZRspjRDtpQcU4rio24oJFMhAqJpWpGaq7NRYLj2YnrSLktxUWWPFTL8vAq4QcmZzmki2svl5C8sf0qPnqxyTTcqtNZxXbCmoo5Z1OZkhOAay7u8SD5QfmPbqahvdQWA7IzuY9AOabaWvlA3l2cyHn/drVIzHRp5CG6uR838K+n/ANer9tEyr5sud78/QelVrdXuH+1yj5B9wHv71dZwBubrTEwdwOO9Ys0r3c32SLoD85Hp6UXlyw/cw8yP09qu2FqLaPB5dup96ZmXo4lijEcYwB2qygxTEXJ+nWpsikWNyaCaOKaaCUJ1pQaSiqESAipAaiHWn1LKHZoptApDJKM0zJooEO3U/wAzNQUooJLiy461YWVccHNURnpTgSOlIs//0/OKjY00SEcUhPetAuJRyaTpRmghi9OtMIp2c00mgkjxRRmkNBJXvE3wsB6VQ0wkwlSeVOCK1yMjFc+ZvsF8SfuuaRR0KkEYNcze+Zpt558X3W5NdIGVhuToarXdsbmIqevagZqaZqwkKSxnDLXrGk6/Be4im+WTtk9a+aI3nsJsZIOea7DTdaBKknDDofSuLF4ONda7kzhc+gbm2WUN6etclf2rx5DDjsexqHSvF0RQR3v/AH2K6qU213B5kZEiNXy9XDVKMrTRx8ri9Tyi7g2Tq2O9ThcCt/VdLMLeYmWQ8g+lYxXA5r1sNK8bnu4WSlEhxSEU+kroudJGVB61CyelW8U0qKAsRKx71MGqPbTgMUCJc0mc02imA0j1ppUYp+KQ0AR00nFSGonNAEDtVd3PansHLHJ47ComXNAiEljShGan/IvU1UmvFjGBWsKTbM6lVJFossY29TVdpT17VjSaiqEk8msybUZbhvLgBYnsK7YQS0OCU2zclv4lPJ6VnNe3N0/k2YyfXsKS10aaY7719o/u961Zrm00yLZCAvHQdTWljILe0gscz3DB5TySe1OiV9Rk8x/lt0P/AH1/9aq1vZ3Gov8AaLvKRDkKe/1rbdwoCoAFHAFBYrsuMDgDgAVlXdyIxleT2FTTTBaitrbzJPPn/AUEi6fZsrG5uBmRufpWwAM8DmmDd0FS4CjHf1oAcDjjtS5pvU8UdKCgoozSZpki0Um6l4pFCinZFNzTGNMgkJpM1HRQMlzSg1HSZosUyYGnVBnFO38UCJgxp4aoN1PU5qSj/9TywGnZBpmaXitCB2aSk3U0nFAiSkoBzyKDgCpKIzS005JpaZIlYGsw718wdRW+TUE0QlQqe9OxJgadqWzEEx4HQ108cisPl5FcHe2z28hx09a1dN1LAEMp9qVwN68sYbtSCMN2NcncW1zYSZcfL6jpXZK/8QPFOcLMuyQAg9jTKOas79wRz+FdppniK5tD+6YgHqDyD+Fcfd6K8ZM1m3/AazhdTQNsnUrWdSmpq0kS1fc9ytfFVrcII7pNp6HHI/KlmgtZ182zcOp6gdRXkNvfxsBhvwrZt79kO5SVPqK5HgYxd4F05cjujrZIjGcAVDmqEesMflmw49e9WxcW8vMbc+h4rOVJxPShVjIlzijNRljUe/5uazNyxQKhD09XycUhDhQabuFGT1pk3HUhpA1DEUCuB5qFu9QzXkEIy7c+g61hXWqSSZEQ2r+tXGm2RKqomrNPDGDvbn071lzagMHbxWFLdbBljzWVLelyQK64UUjllXb2Ny41D0/WsaW9ZjgHk0yC0vL18RqSPU9K6mx0W2tcS3P7xx+QrVIyeu5ztppV1fkM3yJ6muqtrGz09f3eN3940XF/BEpyQAO1c893danL5FqCF7mrRkaN5qgD+Vbje54AFWLDSWZ/tmoct2XsKs6fpkFgu4/NIepNXnc560FDy424A47CqMsuODT5ZcDiq6I0zZ7UALDCsp8xvwq9tCn2poCxjGaEJl56KD19aZmWVIXn1oJpCcnpTTxSLF3Ck3DtTcimjrmmIm3UtNopFCmnCm0opgHNBpTmkpiFprUuaKkq4uQRSfjRnmigbYUGkyKQmi5Ao4PSpRntUANTDNDA/9XyapA3FQ7qkHStCBTyKacrTqCccUCEBpc0zIooJsO3UCm0tADqOMUlFBRSvLVbiMggZrjZ4HhkKkYr0DGRis2+sVuVwv3qmwjnLTU5LcbG+YV0NvqMMighhz2rkZ7aSFiHHSmxkjkcUCO+EyNwKbLFDcLtkUMPeuOi1GWDryK1oNXgIy/GaLhYmn0OL71oxjb0PIqkzX1iNs8ZZR/EORW9BewScA1aEkbjGQfalcoxbe8hkXIbB9KuCcdBUdzpdrP84GxvVeKzDY39scwkSj0PWnYEzfS9mXo3FWV1FP4xz7Vy0d4ykpcIUPuKlMqMcqc1nKkmbxrSR1KXcb/capTOa4zzGB+X9K07d7wcnhf9qsXh+xUcT3OlE/vT/tIA+Y1hyXSoPm4rMm1FAcZyfapVA2eIR0cmoRx+59qy59UkbIB2j2rnpLudx8in61XWC9uDhUY+9bRpJHLKtJ7F6a+QE5OTWbJfSPlUFacOhSP81y+32FbEFjaWn3FGfU8mteUybvuc1Bpd1dsGb5R710Npo9nbjfN8596syXcMYJJAxWBda0MlYvmosM6aW7ht1wpCj8q5m81guSsBzz1rPjjv9TfCgkfpXTadosFrh5Tuf9KdirmRZ6PcXz+ddEhP511cMFvZxiOBQKnBAGF4HpULYx70zG4pb1NQNJjpT3GBVV5EUZb8qCiZV38HoamZhEAqjn0FQLvkAA+RffrVuKNFPHXuTyTSKIhEXbfMeOy/41ayAMAcU1lGARSNgdKYDiabmm5NFMA7+1LSYpRxTIDNLmm0ZoAlDCpKjQU88CkWKTTeTwaCabuNIoKTNNz60mfXinYgfSZoz6Uh5FADs0mabRmlYCSpRUa9M1IOnFBZ/9bx6pQeMVATUgPGK1MSbcaQnNNJpfrSLHKfSlpoNLSAcD60Z5ptPFADKWg0VRA4UdDxQKWkMqzWsU+Qw61mNoyZwtbtL3pWGcpc6NMo3RnPtXPzRSRNtkUg16b9KqXNlDdL+8UZ9anlLuedRzPGwKk1sWtxdTMBGwz70670WSIlouRWcge2kBcEUWIdjrI4tTAztVvxqyGv0A3w8eo5rOhv4doIZx+NaaajGQBvb86LiHNiRdtxCSPcVTOk27nfExi9c81ofaI5GyWb86dsVj8kuD700Uye1tLSBQUXc/8AeNTSWbSHLNtHtVMfaY+irIB6Hmm/aJM4YFc+tMlDX0u0JzKxY+5pqafbc+WgH1qRrmCIbidxqhPqQwctxQBeMFuo+cg4/KmSXUcahUx+Fc+97LMCIUL1GLLU5+WGwe9FhGnPqqJn5vwrEm1aV/8AV9a0YtC3HM0n5VrQ6fYWvKIGP+1zSGcpDZahfndg7fU8Cty20G3iw1w28+g6VqG4A4JAA7ChZA5607CLaeXGmyJQqjsKXkc1EuBjvUoDYx0zTJFLIBljimeYMYRd2fTp+dO8uNR8w3fWq8s+PlWkWRvu6SPj2X/GmI652Rp+J60DB5JyasLxnii4x6Iw61ZUCoUHtVkAAUFDOcY7UwinE80xj3qiALClBpnU08CpLAE9qdz3NMHBpcmgQ8CkpM0tUAqnAo3dqbu7UnFBAtJiiigB1JS000ixSaCaSkpDGEmjdTCaFGaozJge1Tr0qADFTL0yaQH/1/HScCnqcioTzUi9KskdmlpgPalqjIlFLTKXNI0HipKhzTt1IBxOTSmowc1JgUwEFFFFMzY6lptGecGkUFHSkPXikpkjzzxVS4sredCpHP8AWrXPelqTQ4ee1ltnwQcetNVmFdrJGkgwwzWVPp6EllGPpRYgqQyfKMVfVuc1TWPyztNWlGBSGXlkOM5xVtXLr83zZrI3sOnSk+2Mp46UXLRoyWVvMMOmD7VAmkwxn1+vNNS/PQ0/7eKYiwIFjBEahfpQxfaVIqNbxWOal+0R96dyStJcuqhUjJx7VUdL64+8BGprSMwJpVcseKVyiimnpjMrM/6VfhgiiwAgqZASOaU9c0wHA9T2pjSAHimO3GOlUpHA4oJJ5JwB71VB3HJpg+c81YRMGpLBVFWFGRUe2pVzVEkqjinFsCjtUZoEPzTc0UlI0HAUtIKKBC0tJRQAgNLUdOzxTIH5oFNpaRYvX2o9xTfrTsjtQAKcjmmnAozTaogQ0w8UpppoJDinDjpUWRTx0oKLKjJ9KmDYGKgjNPcgDNSM/9DxXdmpgM1X6VZFaGY4Ck780vWigQU8ZpntRjHWkMkoHpSAA1KABQMjANSY4zRxSmmSLilpM44o3Uhi031pck0c0wDBAzmkBzSEim+9Ax+O9KB3pBnFGewoIFPtSEgjFGTQRjgUAUrmDf8AMOoqqjs3ynqK1jweKyLqNoZPOTkHqKLFD3idjhelR/Y5CM5q1a3KuOetaSFCOKmwXOd+xyila2lweK6DjvSEA9qdiDAEEuRiplgmJra2CpNgAoLM+O2bvVyOILipgMYpGyM0xD96g4qBpAOajdgOSaoyTdqm5RJLOCeKqjc5NNHzmrixgUASIoHNTUwLUm00yh4qUDikVR3p59qBDSabkUE4phNAxM0003NFUZjtx6Uu49KZQKBEuaWmUc0hk1FNBpcikWR5pM0UVRkS8UpphNKDUmwuaKKYSRQBEWxUTNzQxOahOSaoyH7gO9Tg8VW6dKevBoGXFPam3JpF9artIGY8fL2qCj//0fElO5sVY6HFU4fvj2q6epNWQh6mlJqMHmnUAPFNbJNJvIpu40DJEIxT81ADT85pkEm6jNM4FLQBJmlyKYKM0FD8g07cOhNRUdaBDz6UdqTmlwaRQDinZpo9aXNAhQTS55plIaZI49aY6hhTqXHHSkWZ+wx/dGKtQSEdakwepqux28igVi+GBGKXHtVGOU5zVgS5NAWLAp5bAquJM0x5OcZpgSPJg1UlnwOtMlk9+lZ8k1FxWJJJT1z1qIIXOTTFDMeavxxg8mpGOiRR0qxtI7UoXFKQOtVYQ9aeBTVQnmpcYosA+mk0vv6UxjSKI2PFRE084/Gm47UyQBPSngcUmKWkUNBpQabSiqJH0maBSHrQSOpRmkpuTSLH560A803NAoAkpvejNITSAU1ETzRuzSUxATUJqY1CaBhTxUWacDSGSg4Qk1XUE9ulS5IjJ9KSL+dBJ//S8JgPIHpV/vWXbK8dxtf9K08g9K0ZgiSlpopaRtcbmkozRTMx9PWmUoNI0FBxT6izTweKZmKKXA70maKZJMKdgUxWA60u4HpUmoppM8UmeaQnIxQA3Ipai24p9BkOpRimc4xSZIpgT4zxS/MopgzUgNI0G4JFQmM5q1xS8VRJTKMOQKNrVdIXvUT4X6VJpcrbsCqzuSc1NJJHgg9apM/ehsyGSSHGKaoDdacCXNWYU9qVyxY0GKs7QowKRRjrT8HvTEKfSpFXPNMCk8ip1HGKoLEg4oJyeaCcCoyw6ikXYezYNQswWkZ+M1CWJPFJiHlhSbqiORxihfWkKxJkUZFNo71VyLEtGeaj3Y4p2eaCifOKaTTKMnPFIoZubtSZzR7k0cZzTMiXmkHNJmgHnNK5oLQc00knige9O5IA0cnk0UZpXGBqE1NUDfWgZFmnA1GRzSjANO5JaHKkHpQTjgUwN8tMJzUln//T8QhLGbLc5FWGwDxVa3Ykn6VMDzzViQucHFLkd6j5J5NPz68UGYvHaloop3EBozSGii4yQHmnimAd6fSLQ4UYpBThQSNIozinUGmgI80ufWlHFDAnmgQZpM07bijFIokzS4pgzT15pDE5pwptITVEktGcVEWqFnNICZmwOaqSTYHIpWf1qnI+aLgI0vHTrUYJkbIGM+nSjqKsRIRyelSXYaq7asJ7UAKafgCqMyQNzUyAseajRSTVpV2ikakijA9qUtgZphbiom5NMAZuwNNJppGfpSdOaBEbEYpo46U9wmAQeopny0MzCl9qSikA8daU+wpvWl9qEWMzTs03FHWrJH5paSikAuM0nOeaUYpvWkMeCKkxk46Cos4pN3rSsIecDpzSbqTcO9RnB6cUDHlqb70E5pM0CE6VEzYOTUpqGQ1RJE7846UtRMOakFIscSQgpoJ70kxARQOaaue9BB//1PB7Qlgxq3VKwxtYVcqyUOHWpM54qEGpAaAY/pSdeaUGlzSJI6XFLQKokfS0lLTKsPXrT6jBFLnHSkOxKMEZpc03J60hbtSLFzRmmA5NAbNMkXdSZ9aTNMzQIlB4zmkDGmZGKM0E2Ji1MLc0wtUTN2oLsSluMiq7P3FNMmKhYhvakybCvIw55NQnk0HJ4zR3pWHYVRxUw+Xt1pF61PjPWnYBy57VMAfzqJUParKrQWSomKlbIHFR7sdKiZyc0yWDPURY1GW/GmljnFFxJk4fFNzTA2RzS1IEg60deaaDS0ihOaKKKAEyaUk0lFNEikkjpR0oLHpTTnHamBKaTkDmmA4p2e9IYgNLznIpMmjJpkgaQmjNJQSNzQDTCe1KDTHYlopmaXNSA6onPpUmaruxplETZJzSrjPNMJNC8nFMRJOOEx0pqntT5z8imoQ+ACaQj//V8E07PlPu7mrYI6VFaR+VGfQmnEYqxJku7HFOUk1HjHenrRcY8GlyKjB5wadmgkfmnUwVJzxntQwFp2ab0NNLZouMfSGm5OadTATcaTNGKXFAgzigGjbRQIfRSe9BbHBpFC4phpS4xULSCmIRmxUZY4pCwNMLDpSARjUbHHSlZlxmoS5PekBJ1OalQ5ODUKt3qZB60iiVVz0qyqVAhPap1c9DVkkwUCnZAqPNMZ+uKLkEjnGcVCWzTS2TTcgHmpuaBkk80daT6UtBIUZpy4J5pSvNOwwB5qQc1EQaepx1qRi0c0E80EmgkdSZFBJxUfP4UyhGJzkUZ5oPSgc0yRKXNIcUAA0E2F3UoNJtp1ArC00njinVGxphYQ80CgH1opXNBaWm0UgFzjPvUDdalYgc1XZs0XAGIpoIyKQihBzTKLE5G1AO9VHf5gtWLg4CDpUYVCdxNIVj/9bwtT+6XB600cdKEyIUyO1JWhFhakU4qIYp4pMCzRTFPan0ihAcU8MKjGKcAKZmPBJOBWjbrHEjGZRz0rOXGc1M8rP17UAPfZk7RUfApC3HFMJJpGhLSZpm6mlqBjmamF8Cml8Uzf1pkkvmHvTGcmoS1NLYpAKXNRlzTSajJoAdupC5qLJpRzQIRgW709FwaUCnqOaCiRU71bSPIqBB2NW1WgYwLipMZowKOlMzFOMcUwkjpSMwFRk5pDHZpKSilcpC0U3NLQSTK1SHFQA08GncZLijbg4pmaCxpDHmmUb93FJQAneijNGaBCcUZpKM1QhaPpSE8Zpu6gB2TS59aYTTSeaAHk4puaTFNJxQA6kzTdw6UVIx+aAc0ylXpQUI5qDNSO1QE0xDSRT4yN1V93PNTR8nmmQSXZ5QYqMZxTr1tuz3FQJKCMUCP//Z",
				"hackString": "/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAAqACAAQAAAABAAAB4KADAAQAAAABAAACgAAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgCgAHgAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMABgYGBgYGCgYGCg4KCgoOEg4ODg4SFxISEhISFxwXFxcXFxccHBwcHBwcHCIiIiIiIicnJycnLCwsLCwsLCwsLP/bAEMBBwcHCwoLEwoKEy4fGh8uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLv/dAAQAHv/aAAwDAQACEQMRAD8A9swKXAptKOlcprcABS4FIKWmZiYFJilooAcBxTu1IOlL2pANowKDRmgYiinYFMzTsmmSS4FLSUtSaiilwKbRQIXj0o/CkoouIKDSCnVRI3AqVcUyloETZpuKiZjSB2pFE2KXAqHe1G80CJ+KTIqHeaTPNFxljipMD0qAGnh6Ch3FLTMinA1RA/Ao4ozSZFIYUmBRkUtMkTA9KTAp1NzQAtNNOJppNIsi4pOKU03NAgOKaRS5phakUMIFMxzTjSUmMbgUYFLRSAdtFG0UtLSuWR4oxTqSqJGbRRtFOpKZmO2Cl2igUuak2DaKMCkpM0wHYoxTc0UgP//Q9pp9NFPxXKUJRRRTELRRRSKHDpSmkHSloJIzTc0ppMUxh1qWmKOaloJHClptOqTUSiiimQLRRRSGIKdTRTqokViFGTTN7HBUcGpacAKQyEg0m01NijFBJDilK08iimMbijBp9KKVihuKKdTcUCCjmlpKYBk0mTSZpRTJHBiKXcaSkqblDtxpMmm0ZouAuTSUUUxCUlFFACnpUNSk8VFUmo2kNGaSmSNp2KM84p2aVhhRmikpWGPoooplDaDRRTMxlOptOoJCjiiimIccU3FSYpNtQbn/0fa6etMp61ylikUgFOPSkFAgpKcaKAGikPSlHNGKZIlFLijFI0Hin0wZxT6QxtGKKWmQJS0UUDFooopDFFKBSU8UxDhT6bS0CFopM0A0hikU3FSZFMOO1UMMCnYpKXNAxuKYRT80uKCCPBpKkxSUDI6WnUYoFciopTRQSOpKWkxSKCmnpT6TFADaKXFGKBjCDioyKnIphFIorYoxTqKozG7ec0tLSUrDuOpKWikVcbS0UVRAtFLRikUNpaXFJQAtJRRQA6ijFGDSKP/S9pqVagqdTxXKUTHpTaU9KQUixtJRzilpmY3pRQaTNMQ40UlFIoeKkqNakNABSU6koGNooooEFLSUtAC4p9NFPoAfiloopDExRilooAaKWloqhDcUYxTqKAE5peaXFGKCxKSlooASiiiggSjANGaKADFHFLSVJZEaSiiqMh1FFFIoQ00inUhpiG7abipaTFIsj20m01JRSKItpo2mpKSggbtNG2n0UwDApCvpTqKRQzBo2k0+igYzFAFPooENooopkn//0/aBUq1EKlWuQ1HDNA60ZoFMgdRmloFIYUmKdijFMRERRjNOI5pRQA4CnGiimISl7UUUANooNFIYtKKSikUKKlFRCpBTJH0UgooAdRRS1SELijFLRSGNxS4paKAGYoxTqKYhmKSn0hFACUUtGKRQlJTsUYoAbRS0UhDOKMUpGaQjFIZHRQKKogdSUtJSKEopM0mTQMMUUhNMJNAEmaM1Hk0uTSLH5oplKKLALmkyabnFJupkEuaTNM3GjcTQMlpKZmjNKxQ7OKM0yjNMk//U9nxUgpgpwrkLJO1KKQUtMQ+lxSCnUiwoopRQIaetA4oopki7qM02loAXNLSUUxCmkpxptSWFLikp1AhBTxTRUgpiFpRRRSLHUtNpaaJEoooqiRaKSigB1GaKKQwooooAbSUtFMQtJTqSkUJRS4pMUrAJSGnUmKQEFBp+DSEVRA2kpxpMUDEop2KTFSXcbSEU/FJQMiwaSpaaRTJG0U7FIRQMZRRRQISijFFMkKSloxQAtFGKKRR//9X2qilxRiuQ1HL0p1NXpThTIJBRSZooAWlpuaXPFIsZRTc0uaZBIDS00UtIsKWm0uaZAUUUUAKKfTBTqBhTxUdPzQIfSUUc0hjhS0wZp+aoQ6ikzRmkUJRRmjNMi4UUUUDuOopKSgdx1FNpaVguFBpKWmTcXNLTaM0FXCkxRmjNIm4YoxS5pKRQwrTdtSUUwK+KMVJik20yBDSGpMUmKRRHRTyKbigsZimkU+koJEwaUU6ikUNx3oxSmigBtFOxRigY2jFLijFAH//W9pp2BSDrTq5SgHSnCmLTqYiekNFIak0G0lFFMgSiikoGLQKQUtBJNRSClpFBRRRQAgpaQUtMQtOplOBpiA0lKKUUCHCng0ylFAx2aKSimIKSiloJFoptFBQUZpKKCQzS5pKKAHZpabRmgodRRRSEOzS5ptITU3NLATSUwZzT6YgpKWigAzRRRSLFopKKAGGozTzUZqjIKSnUUirhRRRSKCkpaKACkoozQAUUUUDP/9f2sUuKKWuUsMUoNJRQA7NJSClpkAaSlptAxaKKKRQU5abRQBMKWmA07NAhaKSlpDClzSUmaBgDTgajzSg0yR9ApAaWmIdmlXrTacOtA2h+KKTrSigkSilopgJRRxS5zSAbRRRTJH0nvS005pFBmiiimITOKM0GkHPWkAuaQ0tGKRQ0HFLu9aaR6UhFAx25aNwqPbSYNAifcKNwqLBoxQUTbhSbhUVJQBKSDTM0lFIBM0tFFUSGKMUtFABijFOopFDcUYp1JQAmKMUtJQB//9D2ylpKdXKixtFFFUSPFLTRS1IxCabSmm0xC0UmaM0AOopM0tIoWnA02lFAiQmjNJRSLFpKWimQJS0lLSLFpRTaWgQopRTRS1SIH0tNzThQSxaWkpaYxOadSUCkAlLRSUwCiiigQlLRRQAlAooFIYtJmiikMbSU7FNphcQ0lPpMUAHNLS0UhkdFOpKYhKKU9aSpLG/SnZptFMkkzRTaWkMM0lLijFUSJSZpTSUhjs0UlFIZ/9H2wGnZqLNPBrkNGOpKTNJTBMKXNMzS5oJJDTaKKBhRRRQAlFFFAhaUdabTh1piJqKKKk0FpKKKAClpBTsUCI6KQkKMscCud1PxZoWkqxurhdy/wqcmqSuZHT01pI0+8QK8F1j4uhJz/Zse5OnzcV5xd+Pdcu2kBlISTqM9PpVKBdz60bVNPRirzICDjBNRtrmlRsUe5QMOozzXxfPrmo3DB3mYsOM5qk97dSN5jSMW65zzVchFz7Bn8e+G4AxNxu2HBApsHj/w3OodbgDJxzx+NfHfmOepzmkDuBgZxT5Aufa0PizQ7gny7pMKMnJrRg1vSbltkF1Gx9Awr4fiu5ogwUn5hg/SiO9uon3xSMpHoaOQdz7ySWJ8hGDbTg4PQ0+vizT/ABdrVgrCK5fk7jznJ967PS/i1rduxa62yjk4b9MVLplXPqGkrzPw/wDEzSNW8uG6xBM/v8ua9FhuYJwDDIrZGRg1DTAlp1GKKCRtFGKWgBuaTNLgUYpCFopabQUJSUtJQMSilxTaYhaTNIaSkMU0UlFIsWlxTc0ZoAfgUlMzRk0yCXNJuplFIoduNIaTvTqBic0hNKeKSgD/0vZRTxUYqQVygxcUlOpDTJEopaSkWPzRSUGgodRTaKRQuacKjp4oEFOFNpwpiHiloooJuMopTXM674o03Q4XaZ98qjOwHmiwHRO6RoXkIVV5JNcDrPxH0HTN8UT+dKo4A6H8a8T8TfETUtWk/wBEd4FGRhTwwrzWaV5XMjnk1soEXPTNc+KGtan5kMREcTdAOuP8a84nu7i5cyTOzMe5NQrC0h4q5Da/OFbOfSqSSNGUESRiTgmryWUrDNdJBYDy0YEDPtxWzBZiJx0wefb8KdyVE5WPSJd2DyOxrbsdDimj80rkqMkV0jW6yLheMc4x/IVoWtuwhJXGDwcdz64rNyL5DjU0uMHey4XOCPSpn0pIogzpxnFdgbRgcgZ2/wAvSonhVlKDgscgGlzMfIcfc6NErDavyDA9+azrjRDHgopIJz+Fd6lq86qF5ZWwc+lMaL9+FXGMkfSjmHynms+mPEx25PGfwqmbSVei9a9NuYFMglC8FSrD3zWebNYwgK8cg+wquYnkPP4nlgfzE4I710mj+MNX0m4NzHKzHpgnirF1pseT0BbkfSuefT5AGdQcCr0ZlY+hfDnxYtryVLbVIyrvgBl6Zr163vba7TzLeRXHsa+EwWjPHBFdZ4d8VX2iziVZGZVGAuePyqJRKPscmjNcF4a8c6driiJ2CSkcBup+vvXdgg8isrDDNJmkooCw/NJmkopFC5ozTRS0yR+eKbSZppNSULSUmaWmIKSjNGaACjFFLSLDFFBpaAEooooAKDRSUyBhpM4opDTJP//T9mFOpopetcpY7NLTBTqCRhpOacaKBXEFIetOFIfWmFxRS0cUcUiriUUUUySWlFNNLSNLjsmnA8VHXM+Jdft9HtCC37xhgD0oSIuZHi/xpa6NA1vbMHnbj6V82atqd5qc7XNzIzk+tX9Uea9uXuJCWLEk81kpaySuI0BreKsLcyfKZzgVbjsJCM7Sa7Ox0A5wy7vqK6K38Pt/EuPoal1EjdU2ebQ2DkbSpU/StpNO8tE81MejD/PFegweHhngHI9a1E0MKMMD71LqoSotnn0VmsA3bic88dK07eASnBAL9scYrsD4fZjhBj0NTDQkjwqr8/cip9oWqLRgmHAXd8xHfvVyC1YuPKBCH+ddNFosm0FhmtBdKIwrZI/Sp5zb2bOSkgCMPK5fuCcVWuLR9wMq4z6f0ru00ZjICcFR0z1qxLohlO9jj6dafMR7NnnzK9uh4GSeSKpSxImGU5Djknsa7abQHLHZwnYj/Cof7Am+7gYzRzB7NnEXEYWDaecsOfY1TmAdxGB8w4Nd7P4ddhsDADuKzP8AhHpIZQ4XIFPmE6TOOni8y4YMo2qcc9vpURsQVKkYAGF9s10lzpM32h2jBKMclT2ND2MhhzznAz+FHMg9kzgbrR1l+WMYwetc9d6dLbnIBI9fWvW3s1LDK9Bk4rMvbEuQpHyYwBTVQl0mec6Zq9xpk6zwgFkOVz619IeD/Gqanaol/Kvm4+Yj19AK+er/AEWeFmZQcCs62mnsJhLG+0qcjBrRpMwcWj7ezkZHejNeZfD/AMTnVbc29y2ZB3LZY/XsK9OrJqxI7Jpc0UYqTUTNLmkxRimQGaTNFJSGMzRuoxTaogkzRkU2ikUPoqOlyaAHYophpN1MkkoqPcaXdQBJRmm7qTdSGOpDSZphagZ//9T2bpRTsUhrlBi0tNzRuoAeaSk3UZFAx1JRmm0ALRSUhJoEOzSZpp5oxQA7NLmo6cKARWv76GwtXubhtqoM18z+KPEFxrd20i8op+XJ7V33xB1wu502F/lT7wxXldjYyahMFHQ9eK1irK4buwzTtPur1+p298V6HYaEqKNy9K1dM0xLaFVx0reVQowK56lVt6HdSpdyla2MUSgkVqLAgHSmKQOtTg5rNts2UEiZERegqwu2oBkU7NSb2LakVKm0mqSselWUPOaLk2LyirSIMfNiqSyACrEcgPGcYqiGi0FAI7U51cHPY+tMD7uVpxdepbIq7kWGkZ6dBTDggAih2XOc1AXpG1hrKuckZqGbyyOFxTmcng1A5qWwRVaNGBGOKoSW0eNu3itJjk1GRzU3KsjFayXOcVXayjbtg1ukc1A6indkuKOLv9NU54yDXEat4eLq0kAA9q9jeJWGCKz5LCNwQR171cajRjOimeDaVqNxot4JI2dGVvmAOM47V9R+FPFNprtooj3CQDkGvB/FWgNATeQj6471L4H8QSaberCz7Y3PQJkn8a6E1JHBKLiz6joqta3C3ECSpnDDuMGrGahmYUtJmimIdmjiikpFjaQ4paQigQYo20uMUUAJijFLRQAhptPpKBjcUU6koGNpM0UlAhxNNoxRQM//1fZ80maWkIrkKG0lFLTIGUtFJTETUCigVJoOpKdRimIZRSkYptAxtZmsX39n2Mk45bBxWnXj/wAQtakMg06MgKOWIPWqS1IPMb6W4v7x5JPvMeT2ru9A0xYIlLDnvXIaXD504dvujsa9MscKoFFaWljooR1uzSAcNgABf1qYAYxUYII4p2TXGegkSheasKOcVCnNWkXFBomKoJp+w9qco9KlAOOaYEG0rzVhTT1TIwelTbB6UgIDUqMT2/GkII6d6BgDBpgWI3YDBOaQ5bgkUkfFPIGc1RNhgVSMMelB6U4U3getMZCwIOaQqas7c+tPwoGAKmxaM5hUZGOtXXGetQlc0gIDjrULCrLCqzHmpYNFY03ANKxqLOKVzOxQ1O1W4gZCMgivFb+2k0q/3wkoVbKkV7zLhlxXl/im2V8nHIrejK2hhiIK1z1jwD4gfWNN8q4IMkXBPAz+Fd/XzP4A1ZbHVUt5SAkhxkgn+VfTAII4GK3lueaHWnUUVJQzNGaMUYpki0UnNHNAEtLSZoqTUKKKKAI6aaWmUzMKKKSgY+kNLkUhIoKEopM0ZoJP/9b2akpcUGuUApaKWkUNpKdikoAQU4U2nimSLS4oFLTAYRTcVIabQIoajdfY7SS4/uivmTWLl72+kkmfLMa948dXb22jOsbbS/HBxXzkh8ybByTmrguozpdMTy9oWu3tS/l5brXLabbHg5zXXQx7UArCrJHZRiXY2yKsA1BGnFWFjYmsToRZQ1cQg1AkJAqdVxSsbFhW5qbIHWqoJBqRWyaLFXLa1ZVcCswSYarQmK45BFUZ2LhWoyoJ6ZqMT5qTeuKLFDgopxX2pAwxxTWcirsKwjMTxTwcc1H5g/GomuFX73FLlKLOc0hqvFOrEkmnPcRqpbnjtQ0ArDIqIjHSmRzrKgcAjPY9acWFTYq5Xc4qq5q22CearSJuPFJxJuUn61CT3qw8ZFVTx1qSbkckmelclrcQdTnvXVuPSsPULfzUYGnB6k1FdHlcLPaXqy9AjZ96+q/Dt+NR0qG5yDlRznNfMeowCCYHHPY17V8N5WksnCsCnp0INdmjR5clZnpdJSnrSZqTMWlFFHSgsKTNJk4ptAC0UlFMQ6kpKQnFKwCk5pKbmlzTAdSUhak3VJoNoopKZmIaQUhNJTA//9f2bNJRS4rkLE7UuaSimQLmkoooGPHSlpo6U6gBaKKKBBSZpaSiwHnPxI50tSAeDzivCrEGa7UKK+ifGdqt1pUgdsBRnpXg2jx/8TIRuMGtFsOO53tjbiNAMVrqMCooYwtLNKIlzjNcj3O+C0LyOAMtxSPqccRwgziuTuNQnZyvT8apNcSn7vNUoXKlUsd0urIRk08axAD715w9xcc4T9azJL+4DYKsK09miPas9bbV7UcsaF1a1LfKcg968eW9uW6AgVbS8lX7pIz2NDggVW56/wDbI87lORTHvtuD2PSvMo9VlGATyOtX/wC1CdoJ6UnE1Uz0BL5QcE4qYXgJ+9Xn4vyZMqeK0Le/LcP+YqbGikdoLzHQ097ssvWuV+1AdDQb4KOTQO5032tiMZqrNfKmNxrAN8Bzmsm9vTIy7TjHehMps7KK/jZsdKtpqEO/DHp3rzz7dszk4OKq3GpyBNqnJ7E1ZDkenf2na7iFYf0pX1K2HzbxxXjf22fBZnOewHSq51Cf++T+NHKR7Q9ek1eAcqwNQf2zHivK0vpurE/lV+O5nPOG/HvRyIn2jPRV1eJjg81cZkkTehzXnS3Dsc4I9cVbiv7iA4j5WplTBVH1OwbrVOdcg5qC11Dz1xIhDetXAyyqcdqwtZmu6POtYjxNkDpXX/Deac3skcf3SPmXNYXiFUXAHBNb/wAPbKSS4N7E21k+Uj1FdENjhrK0j2vBpeaM0ZpnOMzRRRVCFp2abRSKHUlJmjNACGmmlNJQIMUYozRmkMWiiigojopaKZmJTadRgUDR/9D2SnUoFLiuQsZRS0tMkKKdTT1pDAU6milqiApaSimIfTTTjTKRRQ1KK0ltW+2EKgHU14rcnSRe/wChnMqNkcEZUV6R4zuvs1jGCeHbFec2Nsfs00zY3TcA+gqXI3hC6ubazJtyKzb65AUnOK5fxbaa2iW40jzWQLiTy+ufevMG+3zXAtp2k8wnGHJzn8aI0lLW5pKq1pY9TM8Rch5VX6kVajuNHj/1t1Hn2asiz8MWFmitcIZnwCxY8Z9hWqv2C24jhjXHoooatsWm2XE1Dw9/FLv/AN0Mf6VaF94a7pI30jb/AAqhHfOxPlIqqO5wBVoX8EfzT3aqO4XmpdylYe934YYYAmT/ALZN/hWdO2gvkxzlf95GH9Kutrejr/y8yN9Fqv8A25pjnakrc/3hSuykkYUzWAPyXCH6nH86hW4QfcZWA9xXUBkuVJiCyA/Q1mT6daucvAn/AHziquHoZxnLc4q/ayytwKpHRYicws8J7bDkfkc1HaTavb3p0uOBJ5+qOflUr6mla41Kx1sYmYdDTjBOT0NXLXT/ABSyg5sh7EOa2H03xRHDv22PTr+8pcptc5ORJFzWTIrFsmretapr2kAQXtnDK8x2xSRE7Sx7EHmoRoN3Mol1G4Znbkxx/Ko9uOTRawmzOd1T/WOqj3IFV/tNkx5nQ/Qk/wAq3I9HsIeRAhI7sNx/XNXkEcQxGgH0AFHMjOzMWFdMb70/5Ix/pWrAnh1R++kkJ/65N/hWit4yDGAo96tw37OMLNGPqRRzDsUo5fCqDJd/xjYf0pJdQ8NqMJOnXowI/mK2BPOw+V0b6EVTlm/56xAj1wCKXMQiv9q8PuP3V1CD/vCqkotgN8MiP7gg1NLFpc/E0EbfVRWNe+GNJukLWyeQ/YoePyoTT0ZUrmzZTndg4rdSRRnnrXgE326wuntVkcOjY+Unmu88LR65LJKdRMoi8s7TJ0z2681cqXW5lGtfSxq6rHDfXojllWMLgqD1PvXsHhnS7WwtFa3YPkDJHrXm93pccumxy4HnQqCW9fWu48GMzxS/3VAGPc0RfQxqwvqzuqKKWqMQopM0lAxc0UlJQIWkzijNNJ4oEBNNpDSUCFNGaSigYuaWm5ozQSOopM0UwJaKKKk1P//R9nBpc0gpa5bFC9KKKKLCEpuOadRTsISjFOoxRYQtLSYpaBiGgCilFAHmvxGBeGCNfc1jRQ+XbRxDsorrvGVqJktpSOA2DXNPjaCKwmd9F+4PQEqK5LX/AAzLqF/bajZBA8bfvM8ZUV2dsN4Ga0ViB49aFJorlTOXurNniyo5xXKXGmXzOdowK9PEPy4x7VTlt+elHOy/Zo8vbw/eyckk+xPFSromo+UYWhBHrmu9aIKeahYAdCapVGJ000edr4Q1SR/3jIgHHzE1tWnhJIXBnuVOOyj/AOvXSspP3iTQuEOQBT9poL2MShF4aTzPNt7p0b1CjFbqacSgWba7eoGM1HHcMvari3hHapuVGKRz2rPHYOsMW3zG6g+n9KpWLu+qm4jj3zLEEAB45Oa0tR09b26NxKMYHUegq54XsGSOS9kUqZ3LKG6hegFF1Y0S1N60j1mVRgRxfXmtafT9aMAzdJ06bK0rJeQDWxebI4gO5p20HzWPD/FNvcW8cDXz+YsMqyKw4xg85qi2rvFdYumQRsMjA5/OvQ9fsE1KzltmH3lIH1rzq301buyiN1GfNi+Rge5XjNK/cUrt6HWJZR3EKzoQVYZBFUL7TtQMezT0TJ6sxxj6VftppYIFgXhVGAKR55c9ajqVY4G80DWnjPmfvG9mz+lcvNpGrwuS1s4H0J/lXqkwZmypINV83Snh81oqljGVK557YWd2soaVHVR1PIrWZ75OLUyD65I/WuxjaUfeXJqZZWzgrilKpfoJUrHHw3N2OLmPJ9hXR2CtJjIIHvW1DBG/zEA1ppboqkgVnzGnKzidP8PuNdudWmVSrYEXcj1NdPOuxMZ5NbUdusaDPWsm7BaYKPWm5NjUUhVXMWw9CMVueDFaKO5jf+8CKytpCjPpW14cl2TywMPvcg047mVZe6zss0bqbRW55w+im0lAD80UUUFhSGlpppAMooopkDKKWigQUUtHagYlLmkpaAEpaSlpkn//0vZ6WkFFc4haWkopFC0UUUALmjNJRQAU6kpaBDKUUlApkmJ4kQNp2T/CwNcC3PSvQfEP/ILc+hFeb+ZWFTc7qOxegm8v5a1o5lHJrmxJht3pTmvPQmosdUTomuYlJKmqE12G6Vhi6fcCprTgms5EIuI2Df3kb+hqrDIJGZjmoiDVvy4HP7uX/voEU42rdQ6H8aLAUCpPShYmJ5rTW0k9V/MVJ9kcdWQf8CFOwzPCYpwGTVxrdUGWkTH1zVCSWJZVihO9ieT2Ap2A0IohN+7x8o6+9bkUYXAUYArPtgQABWvEueKARt6eoJwadfyhufSltRiIkDtVGZg7HPFPoVbUovhqwb63EEgnQYV+G9M+tb8nqKozuhUxvyD1FQM51xzUZGaSZ1tZAsxJjP3W7j61cjhgmXMcy8+vFSUUGSm7QK1PsbH7siH/AIEKY2nS9mT/AL6FBFyhgUxkB5FaA09/4pYx/wACFSLbWUZxPNn/AHRmlYdzPikaIj0rbiuopAFY49agll0+OPEMRdvVjgfkKxjulkyOPYdKLAjpLyZfL/dnms6FWlYO1VFWUNhulaMJwKCWiy44rQ0oBZBN/dbH51lNJxitDSZQ9ytt/eO4/hTW5FTY7nHNFNzSZrc85js07FR1JQAmKMUtFMQw0lONNoJGUUtJTJCjFOpKRQ3FGDS0tMkKWiikMKSloxQB/9P2ilpuaXNcxQUUmTRmmQLRSZNFADqM0lFIoWiijNACUuaSimSY3iHP9mPXl+7mvTvETOulvtGc4B9hXlTEisZnbQ2FZqTbmowfWpwKi5rFkLfJUiyHHBpsqMx4p8VtK+B0oR0XJVuMcmpftq1dg0pSAZK1YrC1Tjbk1RJgi9foqk/hTXurk/djNdX5cSjAUVC4U8YxSLRyEjX0hwFwK09L0x1BuJe9adwqqhY9BUK6rbRxYBHHahFs1ogAK0YWAbFcdHrUYkwSMGt2C8iPzq1WJHeWNv51uQp5xWHcxFHKnsaoQ6w0H+qfb9DTJtSEuWZhk03YSTuSMRtwKz3h8w81Ra/UE4YVJFfxE8sM1DGUry32/upRkNWadKmTm2k49DXQXUySR/N17UyEfKCah2KRheRqcfG3d7inh74D5oj+VdOrYqyrjHY0htnFvNKByhH1FVWuJO9d+yxNwQKpy2lq2dyDmnYi5xHnsetalmuTuarsum2+eBgUqxpENo7UASleKhztNEkvYVWMmTSEydpMCug8NRh53mPVRiuSd93FdV4ekEJZvUgUR3M6qurI7Q0UtJXQeYG6gODT6XAoGR5pQadgUmKZAhOaSnbaXApFjKKkxSYoAjp+2gCn0yCPApcUGkoAdiiiigYUUUUAf//U9o4ppPOBS9qj5zXKWOooopkDqAKWigYYpaWloAZS4oopkhiiiigQ2WNJUaJwCrDBBrxzVLQ2V9JAegPH0r2bFcT4usAyJfIORw1ZzXU3pSs7Hn3vVyMAiqoq3GR2rNnXFkyRgmtOFQMetU4xxVxeBSuaovK3NS76ph6lDUXLLBc0nU5pvFPWkaFDUjstpD/smvL5LsHIYkGvVruMXETRAdRXnV1otwsjKBkZ71SQpM5Z5b2KTzIJd3+y3Stm01udVHmfK3p1FUJreW3YiRDx3xUGOhHSqMebU6X+2ZuxFKdZmIxurn9hxSrx9aVzbmY+/wBU1kt/oYUD1bk1Np97qWc3bhj7DFWoLG6uQGROD0Jq2NC1E8gDA9DUspS1NO0vpZ50hJzuPT2r0JI8KBXF6FokltP9ouPvCu5B4qSinMwhUuAWx2HWpomBUH1odN3NRAEdKZLRMWqNnphPHNRE0XM7CSNzVVmOaslahbg4qTQqMKqyErVmU4rPkfccUXJYA5bNdRoMT3MuwDCKdzH+lctjAx3rLg8eXWh3klrFGksIPOeDn61pTi5PQ5as+VHvVLiuN0PxtpOtERZMEp/hfoT7Guyrdq2559xwp1NFOpALSUtJQUJRRRQAlFApaZItFOpKRQ00lOooAbRRiigQUUUUAf/V9kpaMClxXKWJThTaXNMgWjNJS5pgOpabS5pDY6im5ooFcdRSUlADqqXcCXVu8L9GGKsk461EzUgTseL3MD2tw9vIMFDikibmu18U2Mbxi+UhWXg5OMiuD3FTispRsdlKV0bMTgirisKwUm21pQy7hiszoTNMY601mYghTg+tNSmyttUkUje5NGzqgUncR3pJLjZyTjHXNZhnZV+bJz0qtLKZB5bcCqsZuRrLdq5ymeafDDLchjj8TWfDNbRDMrAKKqXPiRUPk2eAOmaoqKcjWudBt5EJlKjPvWJ/widnK22C5AbsM1nSahLMcyyFjUa3IU7g2DRqdMaMerLcvhHUI2IGCvrWvpvhRIv3l5zUNn4mu7eIxCTcD681Vm1mW4P7yQmixSorudf/AGakShYCMDtxUE8bRjcoI9a5eDUZ4zujetiDXv4LkA+4pGMqVtjUSXYcN931q4kqbeDWezRXC+ZbEc9qoP5mAp4we9Izu0dF5gGVfg00kVktcMEBfk0q3KLjjB7jtSNOY0T7VHg0quGGRSnmkTchbFVXNTSHaDVCSUUzMrTORkVTzipZnHWqDOT1pBJj7m4EED3DdEUmvKDOLh2lbqxJr024sJ9Tj+zQMvJ+YN3rnrrwbdQMSgKsOx6H6Gqp4mnB8smebiayvymHp0kkV0AhwMZz6EV9GeEtcXVLIQTNmeIYPuPWvnuGzuLSVhcoVI6Zrf0fVJ9NvFuoGwV4IPQiu52mrowUj6TFOri9F8X2eoTCzucQz9v7rfSuyBNZNDuPzRSZpRSGGKMUUUFCilpKWgQ2iiimIKMUUUALiilpDSGNpMUtFMR//9b2WikpGNcwx1LUQNOyaZJNmk3UzNFIsM0UYFFBmJS5pKWmSS5zS1RvL600+E3F5IsaD1PX6V5hrHxFkJZNJQIg481+T+AoSua3PT7y9tLGIzXcqxIO7HFeT+IfitptkrQ6TGZ5egduEH9TXk+u67faoxa4meQjuxrhZs5JJrRQ7kXNzWfFWta3c/aL24ZsHKqDhV+gFd14d8QLqkAtrgj7Qg/76HrXmOnaZd6pOILVc+rHoPqa9W0vRrHQ4cJiWdh80hH6D2rmxNWEFZmkajizZEhU81dhlDcZrIEoc46GpEkZDkVhGSkro7YTT1R1cEgxjNTSn5a5qG+aPk1oC/SaMdjVGikMnuUD4HasK8uJSCVzgelaRHmy5zmraIifNgZqblpHm82ozSlkUOQvtVcT3XVI3z9K9EmSwdsuihqUPEn3EUgdK3i1Y2iux56o1Y/OttJg0yWbUEOJbeQfnXpSX4XAxitWO9VwN6qw9xV6FqDPF/t8iMcxv+dS/wBqsq4EchJ+lewva6ZLy1rGSeTxVmC20eIn/RY+QAcj0p2Roos8ki1eQj7sg/CrK6m55JI+oNeuhtNiB2wR8+wrPmlsz8vlpj6CocUXys85t9blgfKSY9q218RpKAGPNbJFk33ooz+ApEs7CUFGgQqTzxipaRhKAlvqiSjB5HtV1JTI23tVB7G3jJ+zoFHoKbAxiOD0zWTZg1Y62AkLipnbAzWXFOBHkmq8t8Omc+4qTS5bmmHrWVNOKqy3WSc1nT3IUZNBDJ5Zh3NU5Jgi72OBVUyFzk1HOP3W49KUnoc05aGrpPn2kpmlk8wSN16Y9q9QtJY7uIBxuB9a8106Az2DsOwyPwru7OeKx09ruY4CLn6mvCxd5S03PFxGsjz3xaIV1JoIc7YxyPQ+lciGKnIq7fXMt3cyXEhyzsSfxqjht1fV4Sm6dKMWaU1aJp+dlUmH3l4z3r3HwhrDanp2yZt0sOAT6jtXgqONmz1r0rwJf2Nks/2uVY92AoPetprQ1R65mjNUre+s7r/j3lV/oas5rAaJc0uajzS0iiTdS5qLNKOaRQ7Ip2aZilpiFzRmmZozQIkzRmm5ozQMUmikooA//9f2POKYSTRRXMMBThTaXNADqKZmkzTJJBS1HmjcaBNEtY+uazBotmbmXlzwi+pq9cXcFpEZ7hwiL3NeC+K9efVr5nU4iThAfT1qoxuBQ1DVb3Wr4yXchIznbngD0ArmNUlBfC8Adq07QlI2lb+LgVj6mQspb++P1rW1hNmFNJjPpSabpc+sXGxAViB+Z/auw0fwnJfx/btQykP8K92/+tXYmzgsYhHboEUDgCvOxGPjH3Y7k85n2dva6VaiC1UKo6nux96haUvyelLJKMnNRknbkda8qUnJ8zJIJJmXkcYq1b3ay4RyA386yZ5ckism6nMQBU854xW9FtHTSk0zsWY0I5DcniqVnM01skjdSOfrVjpXYjuTNiCUdqnaasqEgnirojkI4pmkXoQ3YR0+XqKxjLKnQkVvG2kNULiwlwSqk0yygL6YcMAw96lXVzF1U/hVdoZF6g1XeM1SbKU2jXXxIgO1gRVkeIrcnburnPs+7mj7KD2p8xt7eR0x1qF+FcVH9tibq5rAS1xyBVhYyKlyH7Zs1BfqpOwZ9zVmC4nnPUge1ZsNu0hHFbkMDRrg8VDYnNs0I3CqBULtjJNNwQKjfO01BMmQyXTKmM8VRMpzkGmy4zjNVWcDiqMCy0pxjNVXJc81HuzTxk0ENllRUk4Bi201OlSbTJKsYGcmspbFT2uddoVsosWTHJU8Vz3iLVhJDFp8JOFG58dM+ldS8yaRpb3JxwvA/wBo9BXkjytI5d+rHJrny/DqrVc5LRHhW5pthvHemlhnNIR3ppPOB+NfRmw7zQimRulTW08g+c9+1ZQb7RLtH+rT9TWmg9aZB1+h3xivoXMnlqGG5j0xXuMN5a3AzBKj/wC6Qa+aorryXxs38fTFWl1G6icvECB6A81E43KTsfS1BrwG28XaxachpCB2JDD8q6vT/iEJSEukBPfHyn8qxdNmyZ6jmng1zdn4m0i8wFl2MezVvI8cg3RsGHqDmoaAkpc1HzmnGmQOzRmo6UZoAsUU2lqTUMUYzS0maAP/0PYKKSlrmKEoqKWaKBDJO6oo7scCuT1DxvpFmSlvuuXH9z7v/fRqrNknY0V5Hc+PdVlJ+zxxwL/32f14rDuPFety8NcOP93A/lVKmxcx7tJLFEN0jBR7nFY114k0m0B3S7iOy814Hc6neXH+tmdvqxrMd5G53t+dUqQ3I7rxJ4ifVLgmPKwRD5V9T6muC+a6uNrcL1P0qyrKYQrnrT1ZFjIX8+9aKNtDO4yRl+5GMKvAFaehabaahqCfaxnygWA7EisXvkVv6C/lalCc43ZU/jWWI/hysRLZnfT8sEAAx6VzWoFskHnFdIUJLNmuev0JJC18fGWupzQObB+fnmiZsIMGiQbG4qF+V3HtXUmdCMiduorHQCa43DkLWnek+WzVUs0AX3r0KMdLnXSib+myYLRHoea0SGiOV5HpWJasY7lT68V0JGea3OxDoZhkMOvpW/ayrIK5OWNlPmR53elOttQIIWT5GoLjKx3yKhqysaHjFcrBq6g7WI+taKapFjrQaqSNWSyt25IHPrVCTSrZjnbS/b4zjcR+dL9tiP3WFBRTk0uAD5RUCaYjNitV5g4qLzAp4NBoRJokXUmp00SEHJOamiulC4Y1YW8Qd6QhY9OhiGQKilQDoKc98mME1Va7UqaljuRuFUZrJuLgD5VOaZeX6gE5wK5t78u5SLmixLkX5Jsnjk1XyTUca85brU4HNUYbiqKsKM01VqUYUZPAqWVYX7q7jW3o9kZZxK46Vk28ZnYMRx/CP61pX+rR6Xb/AGa2P+kMuP8AdB7/AFrGfNL3Y7nDiqlo8qKPinUhPcCwhP7uHrju1cpxSkljuY5J5JpCQK9bDUFSgoo4oxsrDWbHAqjPMXkFtHyzdSOwourhLaEyseew75qKwt3C+dL/AKyTk/4VuUatunloI1HAqwzqilj25pinaMVQuZfOkFuvQctTGW7eTzE8wdSauq/YiqFquyM/WrgxQySwSD0qNljk4kHPqOCKTNJmkWSRrND/AKuTIH97r+dbNrrGq2jDy3YD/ZOaxAamV8dOtFgO+tPHd7BgXI8wD1GDXT2njnSp8LPmMn8RXj4dm6GlLN24qXBMfMz6EtdU068GbadH9gRn8q0a+aBNIhyDgjuK3rDxRq9h/qpi6/3X+YfrUOn2FzHvlKK840/x/DIAuoRbD/eT/Cuxs9b0y/H+jzKT6Hg1m4NF3Nc0YFGfSlqSj//R9A1HxJpGmZWWUPIP4E+Zv06Vw9/461CfKafEsC/3n+Zvy6VwqkHnpTi+BSUEibli8u7u8cvezvMfRjx+VUldd2D0qOWQk+lQbjnmqSEXnmgTeCOOgNQyT2jtvGRjt61UlORVYnFaKdhNGmfs0hbG3luPpTDBCsLPGu85I654H41kscnNNJNX7VdUTykyyAkr6ClL84NUYD+/cH0qVydp9azuFi4PvAetbenKBqFuB2OTWHbsrqCD061sWG972MDrntXNX+BhJ6HqDx7YuKwL1AAT6105XdCM9qxLuIEHNfFOVpHDF2OIuo8EtVCXJXPQAVtXiAqRjpWRMNkfTPFdlNnRF6nPXrZjI9TTrZML71WuWaS42noK04UwoNevSVonp0URnKkMOorpIpBJGrg9RWAy5yKtWUxQ+S3TtWh02NU+tVbi3ScYbgjpVn3oPNAWMGW3vLf5oTvHoagXUHjbbKpUiugOaryQxSZ3qDmncLdigmrAdSatpqqnndj61ny6XG3MeVqjJp7gbQcn1qkkx80kdWurKV4YYpP7VQ/xVxptJgox296b9luW4H86rlRn7SR176qqnBOaaNXB71yRs7knjP4mnJYXJ5LYosivaSOpk1qMDl8VUfXmfKQgsay49OXO58n61pxW6J90AVnJI0TkyrEt1dHdckqPStOKFIhhB+NKowM1KGqWCRIuKmGDVcyKveqkt4RwgyaRpdGq0iIMsaZEGuGy/CDoKzIt0r7pDyO1XpLoWy4UZY9BTUG9ERKokjSnv1sIsRnMzDAH90etcw8jyMXkYsx6k0FnZmeQ5JOSaQkda7qNBQ16nmVJczuSEjbzVGadIxuJ2hf1ptxcIgIB+uP5VmMkty67uMn5V9B6mtyBkCSajefaJR+7j6D1roMc5pscawRiJei96az4yc8UxDbq4EMRbqx4A9TUNrGY03P95+SarwE3k/ntzGn3fc+taqrubpwKpEE4XAFTAe1MHHJ5p5bHFJlIKKbuHXNG7mlYdx1PBqHdTw1OxJbQ4qTeKpb6NxpFE5IJpwqtmpFbtRYRZUDrVhGKEGNip9RVPNSq1KxR09l4h1aywI5iy+jciuwsfHUbYS+jIPdk6flXlqsRzmnjnmpcExpn/9LhQ+BTJHJHFVw+OKCwxzWljIUtnvTN4zio2akFSWStyM1UkOTxVhmyKrHrVWIG5pMUUCkBSkfyZlY9DVxiGP1rO1IERh/7pqxbSCWIOKBCNILWbOfleup0uYLdxyiuauYxLEVP1FSaTeCVPLZsMhxxWdSHNFoGj6FgYyQCRuOBWTeYyeKzfDusedGLG4OXH3Se9bt1AXJZRkivicTQlSqNSRyyVmcddQ9cDiubv1KxgKDk13U8PykMMVzN9AxHSroyHCRw3l5nOOprVjT5QKrSx7JwK0Iwa92m/dPaobELR85qAoQ2RwRWmVzUbxg1ZuEM+cK1XM1lMjKeKsxSnoaBlk0zBPSpQaXrQFimR61Ay8VoYB61GyA0yLFDbTcDpirbRjtUXlnNIsiCijAqbZRspjRDtpQcU4rio24oJFMhAqJpWpGaq7NRYLj2YnrSLktxUWWPFTL8vAq4QcmZzmki2svl5C8sf0qPnqxyTTcqtNZxXbCmoo5Z1OZkhOAay7u8SD5QfmPbqahvdQWA7IzuY9AOabaWvlA3l2cyHn/drVIzHRp5CG6uR838K+n/ANer9tEyr5sud78/QelVrdXuH+1yj5B9wHv71dZwBubrTEwdwOO9Ys0r3c32SLoD85Hp6UXlyw/cw8yP09qu2FqLaPB5dup96ZmXo4lijEcYwB2qygxTEXJ+nWpsikWNyaCaOKaaCUJ1pQaSiqESAipAaiHWn1LKHZoptApDJKM0zJooEO3U/wAzNQUooJLiy461YWVccHNURnpTgSOlIs//0/OKjY00SEcUhPetAuJRyaTpRmghi9OtMIp2c00mgkjxRRmkNBJXvE3wsB6VQ0wkwlSeVOCK1yMjFc+ZvsF8SfuuaRR0KkEYNcze+Zpt558X3W5NdIGVhuToarXdsbmIqevagZqaZqwkKSxnDLXrGk6/Be4im+WTtk9a+aI3nsJsZIOea7DTdaBKknDDofSuLF4ONda7kzhc+gbm2WUN6etclf2rx5DDjsexqHSvF0RQR3v/AH2K6qU213B5kZEiNXy9XDVKMrTRx8ri9Tyi7g2Tq2O9ThcCt/VdLMLeYmWQ8g+lYxXA5r1sNK8bnu4WSlEhxSEU+kroudJGVB61CyelW8U0qKAsRKx71MGqPbTgMUCJc0mc02imA0j1ppUYp+KQ0AR00nFSGonNAEDtVd3PansHLHJ47ComXNAiEljShGan/IvU1UmvFjGBWsKTbM6lVJFossY29TVdpT17VjSaiqEk8msybUZbhvLgBYnsK7YQS0OCU2zclv4lPJ6VnNe3N0/k2YyfXsKS10aaY7719o/u961Zrm00yLZCAvHQdTWljILe0gscz3DB5TySe1OiV9Rk8x/lt0P/AH1/9aq1vZ3Gov8AaLvKRDkKe/1rbdwoCoAFHAFBYrsuMDgDgAVlXdyIxleT2FTTTBaitrbzJPPn/AUEi6fZsrG5uBmRufpWwAM8DmmDd0FS4CjHf1oAcDjjtS5pvU8UdKCgoozSZpki0Um6l4pFCinZFNzTGNMgkJpM1HRQMlzSg1HSZosUyYGnVBnFO38UCJgxp4aoN1PU5qSj/9TywGnZBpmaXitCB2aSk3U0nFAiSkoBzyKDgCpKIzS005JpaZIlYGsw718wdRW+TUE0QlQqe9OxJgadqWzEEx4HQ108cisPl5FcHe2z28hx09a1dN1LAEMp9qVwN68sYbtSCMN2NcncW1zYSZcfL6jpXZK/8QPFOcLMuyQAg9jTKOas79wRz+FdppniK5tD+6YgHqDyD+Fcfd6K8ZM1m3/AazhdTQNsnUrWdSmpq0kS1fc9ytfFVrcII7pNp6HHI/KlmgtZ182zcOp6gdRXkNvfxsBhvwrZt79kO5SVPqK5HgYxd4F05cjujrZIjGcAVDmqEesMflmw49e9WxcW8vMbc+h4rOVJxPShVjIlzijNRljUe/5uazNyxQKhD09XycUhDhQabuFGT1pk3HUhpA1DEUCuB5qFu9QzXkEIy7c+g61hXWqSSZEQ2r+tXGm2RKqomrNPDGDvbn071lzagMHbxWFLdbBljzWVLelyQK64UUjllXb2Ny41D0/WsaW9ZjgHk0yC0vL18RqSPU9K6mx0W2tcS3P7xx+QrVIyeu5ztppV1fkM3yJ6muqtrGz09f3eN3940XF/BEpyQAO1c893danL5FqCF7mrRkaN5qgD+Vbje54AFWLDSWZ/tmoct2XsKs6fpkFgu4/NIepNXnc560FDy424A47CqMsuODT5ZcDiq6I0zZ7UALDCsp8xvwq9tCn2poCxjGaEJl56KD19aZmWVIXn1oJpCcnpTTxSLF3Ck3DtTcimjrmmIm3UtNopFCmnCm0opgHNBpTmkpiFprUuaKkq4uQRSfjRnmigbYUGkyKQmi5Ao4PSpRntUANTDNDA/9XyapA3FQ7qkHStCBTyKacrTqCccUCEBpc0zIooJsO3UCm0tADqOMUlFBRSvLVbiMggZrjZ4HhkKkYr0DGRis2+sVuVwv3qmwjnLTU5LcbG+YV0NvqMMighhz2rkZ7aSFiHHSmxkjkcUCO+EyNwKbLFDcLtkUMPeuOi1GWDryK1oNXgIy/GaLhYmn0OL71oxjb0PIqkzX1iNs8ZZR/EORW9BewScA1aEkbjGQfalcoxbe8hkXIbB9KuCcdBUdzpdrP84GxvVeKzDY39scwkSj0PWnYEzfS9mXo3FWV1FP4xz7Vy0d4ykpcIUPuKlMqMcqc1nKkmbxrSR1KXcb/capTOa4zzGB+X9K07d7wcnhf9qsXh+xUcT3OlE/vT/tIA+Y1hyXSoPm4rMm1FAcZyfapVA2eIR0cmoRx+59qy59UkbIB2j2rnpLudx8in61XWC9uDhUY+9bRpJHLKtJ7F6a+QE5OTWbJfSPlUFacOhSP81y+32FbEFjaWn3FGfU8mteUybvuc1Bpd1dsGb5R710Npo9nbjfN8596syXcMYJJAxWBda0MlYvmosM6aW7ht1wpCj8q5m81guSsBzz1rPjjv9TfCgkfpXTadosFrh5Tuf9KdirmRZ6PcXz+ddEhP511cMFvZxiOBQKnBAGF4HpULYx70zG4pb1NQNJjpT3GBVV5EUZb8qCiZV38HoamZhEAqjn0FQLvkAA+RffrVuKNFPHXuTyTSKIhEXbfMeOy/41ayAMAcU1lGARSNgdKYDiabmm5NFMA7+1LSYpRxTIDNLmm0ZoAlDCpKjQU88CkWKTTeTwaCabuNIoKTNNz60mfXinYgfSZoz6Uh5FADs0mabRmlYCSpRUa9M1IOnFBZ/9bx6pQeMVATUgPGK1MSbcaQnNNJpfrSLHKfSlpoNLSAcD60Z5ptPFADKWg0VRA4UdDxQKWkMqzWsU+Qw61mNoyZwtbtL3pWGcpc6NMo3RnPtXPzRSRNtkUg16b9KqXNlDdL+8UZ9anlLuedRzPGwKk1sWtxdTMBGwz70670WSIlouRWcge2kBcEUWIdjrI4tTAztVvxqyGv0A3w8eo5rOhv4doIZx+NaaajGQBvb86LiHNiRdtxCSPcVTOk27nfExi9c81ofaI5GyWb86dsVj8kuD700Uye1tLSBQUXc/8AeNTSWbSHLNtHtVMfaY+irIB6Hmm/aJM4YFc+tMlDX0u0JzKxY+5pqafbc+WgH1qRrmCIbidxqhPqQwctxQBeMFuo+cg4/KmSXUcahUx+Fc+97LMCIUL1GLLU5+WGwe9FhGnPqqJn5vwrEm1aV/8AV9a0YtC3HM0n5VrQ6fYWvKIGP+1zSGcpDZahfndg7fU8Cty20G3iw1w28+g6VqG4A4JAA7ChZA5607CLaeXGmyJQqjsKXkc1EuBjvUoDYx0zTJFLIBljimeYMYRd2fTp+dO8uNR8w3fWq8s+PlWkWRvu6SPj2X/GmI652Rp+J60DB5JyasLxnii4x6Iw61ZUCoUHtVkAAUFDOcY7UwinE80xj3qiALClBpnU08CpLAE9qdz3NMHBpcmgQ8CkpM0tUAqnAo3dqbu7UnFBAtJiiigB1JS000ixSaCaSkpDGEmjdTCaFGaozJge1Tr0qADFTL0yaQH/1/HScCnqcioTzUi9KskdmlpgPalqjIlFLTKXNI0HipKhzTt1IBxOTSmowc1JgUwEFFFFMzY6lptGecGkUFHSkPXikpkjzzxVS4sredCpHP8AWrXPelqTQ4ee1ltnwQcetNVmFdrJGkgwwzWVPp6EllGPpRYgqQyfKMVfVuc1TWPyztNWlGBSGXlkOM5xVtXLr83zZrI3sOnSk+2Mp46UXLRoyWVvMMOmD7VAmkwxn1+vNNS/PQ0/7eKYiwIFjBEahfpQxfaVIqNbxWOal+0R96dyStJcuqhUjJx7VUdL64+8BGprSMwJpVcseKVyiimnpjMrM/6VfhgiiwAgqZASOaU9c0wHA9T2pjSAHimO3GOlUpHA4oJJ5JwB71VB3HJpg+c81YRMGpLBVFWFGRUe2pVzVEkqjinFsCjtUZoEPzTc0UlI0HAUtIKKBC0tJRQAgNLUdOzxTIH5oFNpaRYvX2o9xTfrTsjtQAKcjmmnAozTaogQ0w8UpppoJDinDjpUWRTx0oKLKjJ9KmDYGKgjNPcgDNSM/9DxXdmpgM1X6VZFaGY4Ck780vWigQU8ZpntRjHWkMkoHpSAA1KABQMjANSY4zRxSmmSLilpM44o3Uhi031pck0c0wDBAzmkBzSEim+9Ax+O9KB3pBnFGewoIFPtSEgjFGTQRjgUAUrmDf8AMOoqqjs3ynqK1jweKyLqNoZPOTkHqKLFD3idjhelR/Y5CM5q1a3KuOetaSFCOKmwXOd+xyila2lweK6DjvSEA9qdiDAEEuRiplgmJra2CpNgAoLM+O2bvVyOILipgMYpGyM0xD96g4qBpAOajdgOSaoyTdqm5RJLOCeKqjc5NNHzmrixgUASIoHNTUwLUm00yh4qUDikVR3p59qBDSabkUE4phNAxM0003NFUZjtx6Uu49KZQKBEuaWmUc0hk1FNBpcikWR5pM0UVRkS8UpphNKDUmwuaKKYSRQBEWxUTNzQxOahOSaoyH7gO9Tg8VW6dKevBoGXFPam3JpF9artIGY8fL2qCj//0fElO5sVY6HFU4fvj2q6epNWQh6mlJqMHmnUAPFNbJNJvIpu40DJEIxT81ADT85pkEm6jNM4FLQBJmlyKYKM0FD8g07cOhNRUdaBDz6UdqTmlwaRQDinZpo9aXNAhQTS55plIaZI49aY6hhTqXHHSkWZ+wx/dGKtQSEdakwepqux28igVi+GBGKXHtVGOU5zVgS5NAWLAp5bAquJM0x5OcZpgSPJg1UlnwOtMlk9+lZ8k1FxWJJJT1z1qIIXOTTFDMeavxxg8mpGOiRR0qxtI7UoXFKQOtVYQ9aeBTVQnmpcYosA+mk0vv6UxjSKI2PFRE084/Gm47UyQBPSngcUmKWkUNBpQabSiqJH0maBSHrQSOpRmkpuTSLH560A803NAoAkpvejNITSAU1ETzRuzSUxATUJqY1CaBhTxUWacDSGSg4Qk1XUE9ulS5IjJ9KSL+dBJ//S8JgPIHpV/vWXbK8dxtf9K08g9K0ZgiSlpopaRtcbmkozRTMx9PWmUoNI0FBxT6izTweKZmKKXA70maKZJMKdgUxWA60u4HpUmoppM8UmeaQnIxQA3Ipai24p9BkOpRimc4xSZIpgT4zxS/MopgzUgNI0G4JFQmM5q1xS8VRJTKMOQKNrVdIXvUT4X6VJpcrbsCqzuSc1NJJHgg9apM/ehsyGSSHGKaoDdacCXNWYU9qVyxY0GKs7QowKRRjrT8HvTEKfSpFXPNMCk8ip1HGKoLEg4oJyeaCcCoyw6ikXYezYNQswWkZ+M1CWJPFJiHlhSbqiORxihfWkKxJkUZFNo71VyLEtGeaj3Y4p2eaCifOKaTTKMnPFIoZubtSZzR7k0cZzTMiXmkHNJmgHnNK5oLQc00knige9O5IA0cnk0UZpXGBqE1NUDfWgZFmnA1GRzSjANO5JaHKkHpQTjgUwN8tMJzUln//T8QhLGbLc5FWGwDxVa3Ykn6VMDzzViQucHFLkd6j5J5NPz68UGYvHaloop3EBozSGii4yQHmnimAd6fSLQ4UYpBThQSNIozinUGmgI80ufWlHFDAnmgQZpM07bijFIokzS4pgzT15pDE5pwptITVEktGcVEWqFnNICZmwOaqSTYHIpWf1qnI+aLgI0vHTrUYJkbIGM+nSjqKsRIRyelSXYaq7asJ7UAKafgCqMyQNzUyAseajRSTVpV2ikakijA9qUtgZphbiom5NMAZuwNNJppGfpSdOaBEbEYpo46U9wmAQeopny0MzCl9qSikA8daU+wpvWl9qEWMzTs03FHWrJH5paSikAuM0nOeaUYpvWkMeCKkxk46Cos4pN3rSsIecDpzSbqTcO9RnB6cUDHlqb70E5pM0CE6VEzYOTUpqGQ1RJE7846UtRMOakFIscSQgpoJ70kxARQOaaue9BB//1PB7Qlgxq3VKwxtYVcqyUOHWpM54qEGpAaAY/pSdeaUGlzSJI6XFLQKokfS0lLTKsPXrT6jBFLnHSkOxKMEZpc03J60hbtSLFzRmmA5NAbNMkXdSZ9aTNMzQIlB4zmkDGmZGKM0E2Ji1MLc0wtUTN2oLsSluMiq7P3FNMmKhYhvakybCvIw55NQnk0HJ4zR3pWHYVRxUw+Xt1pF61PjPWnYBy57VMAfzqJUParKrQWSomKlbIHFR7sdKiZyc0yWDPURY1GW/GmljnFFxJk4fFNzTA2RzS1IEg60deaaDS0ihOaKKKAEyaUk0lFNEikkjpR0oLHpTTnHamBKaTkDmmA4p2e9IYgNLznIpMmjJpkgaQmjNJQSNzQDTCe1KDTHYlopmaXNSA6onPpUmaruxplETZJzSrjPNMJNC8nFMRJOOEx0pqntT5z8imoQ+ACaQj//V8E07PlPu7mrYI6VFaR+VGfQmnEYqxJku7HFOUk1HjHenrRcY8GlyKjB5wadmgkfmnUwVJzxntQwFp2ab0NNLZouMfSGm5OadTATcaTNGKXFAgzigGjbRQIfRSe9BbHBpFC4phpS4xULSCmIRmxUZY4pCwNMLDpSARjUbHHSlZlxmoS5PekBJ1OalQ5ODUKt3qZB60iiVVz0qyqVAhPap1c9DVkkwUCnZAqPNMZ+uKLkEjnGcVCWzTS2TTcgHmpuaBkk80daT6UtBIUZpy4J5pSvNOwwB5qQc1EQaepx1qRi0c0E80EmgkdSZFBJxUfP4UyhGJzkUZ5oPSgc0yRKXNIcUAA0E2F3UoNJtp1ArC00njinVGxphYQ80CgH1opXNBaWm0UgFzjPvUDdalYgc1XZs0XAGIpoIyKQihBzTKLE5G1AO9VHf5gtWLg4CDpUYVCdxNIVj/9bwtT+6XB600cdKEyIUyO1JWhFhakU4qIYp4pMCzRTFPan0ihAcU8MKjGKcAKZmPBJOBWjbrHEjGZRz0rOXGc1M8rP17UAPfZk7RUfApC3HFMJJpGhLSZpm6mlqBjmamF8Cml8Uzf1pkkvmHvTGcmoS1NLYpAKXNRlzTSajJoAdupC5qLJpRzQIRgW709FwaUCnqOaCiRU71bSPIqBB2NW1WgYwLipMZowKOlMzFOMcUwkjpSMwFRk5pDHZpKSilcpC0U3NLQSTK1SHFQA08GncZLijbg4pmaCxpDHmmUb93FJQAneijNGaBCcUZpKM1QhaPpSE8Zpu6gB2TS59aYTTSeaAHk4puaTFNJxQA6kzTdw6UVIx+aAc0ylXpQUI5qDNSO1QE0xDSRT4yN1V93PNTR8nmmQSXZ5QYqMZxTr1tuz3FQJKCMUCP//Z,-223,-6.972874e+09,-1.12646e+11,-1.743218e+09,-6.310415e-23,-8.095511e-34,-1.551686e-20,-0.006676879,-1.795599e-37,-223,-2.789202e+10,-6.973137e+09,-1.489912e-26,5.223253e+36,1.976728e+31,-3.365395e-07,-1.764694e-20,-8.723629e-31,-2.802677e+10,-6.186516,0.7854766,0.2750077_/9j/4AAQSkZJRgABAQAAkACQAAD/4QCARXhpZgAATU0AKgAAAAgABQESAAMAAAABAAEAAAEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAIdpAAQAAAABAAAAWgAAAAAAAACQAAAAAQAAAJAAAAABAAKgAgAEAAAAAQAAAeCgAwAEAAAAAQAAAoAAAAAA/+0AOFBob3Rvc2hvcCAzLjAAOEJJTQQEAAAAAAAAOEJJTQQlAAAAAAAQ1B2M2Y8AsgTpgAmY7PhCfv/iDFhJQ0NfUFJPRklMRQABAQAADEhMaW5vAhAAAG1udHJSR0IgWFlaIAfOAAIACQAGADEAAGFjc3BNU0ZUAAAAAElFQyBzUkdCAAAAAAAAAAAAAAAAAAD21gABAAAAANMtSFAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEWNwcnQAAAFQAAAAM2Rlc2MAAAGEAAAAbHd0cHQAAAHwAAAAFGJrcHQAAAIEAAAAFHJYWVoAAAIYAAAAFGdYWVoAAAIsAAAAFGJYWVoAAAJAAAAAFGRtbmQAAAJUAAAAcGRtZGQAAALEAAAAiHZ1ZWQAAANMAAAAhnZpZXcAAAPUAAAAJGx1bWkAAAP4AAAAFG1lYXMAAAQMAAAAJHRlY2gAAAQwAAAADHJUUkMAAAQ8AAAIDGdUUkMAAAQ8AAAIDGJUUkMAAAQ8AAAIDHRleHQAAAAAQ29weXJpZ2h0IChjKSAxOTk4IEhld2xldHQtUGFja2FyZCBDb21wYW55AABkZXNjAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA81EAAQAAAAEWzFhZWiAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPZGVzYwAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdmlldwAAAAAAE6T+ABRfLgAQzxQAA+3MAAQTCwADXJ4AAAABWFlaIAAAAAAATAlWAFAAAABXH+dtZWFzAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAACjwAAAAJzaWcgAAAAAENSVCBjdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23////AABEIAoAB4AMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2wBDAAYGBgYGBgoGBgoOCgoKDhIODg4OEhcSEhISEhccFxcXFxcXHBwcHBwcHBwiIiIiIiInJycnJywsLCwsLCwsLCz/2wBDAQcHBwsKCxMKChMuHxofLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/3QAEAB7/2gAMAwEAAhEDEQA/APasD0pcL6CiiuU0F2r6Cl2r6CgUtAhpVfQUm1fQU6igBwVcdBTtq46CkHSnGkBFgego2r6ClopgKFX0FKEX0FJmnCkAu1fQUbR6ClpaAE2j0FG0egpaKAE2j0FLtHpRRRcA2r6Cl2r6CgU6mA3avoKkQL6CkooAkwvoKTC+gqIk0gY0gJsL6CjC+gqHcaXeaAJcL6Cm/L6UzcaTJpgTBVPYU7avoKiDYpwemBKAvoKXaPQVHuFPDCgBdi+go2r6Cl3Zpu4UALtX0FG1fQUbhRkUAG1fQUbV9BS5FJkUAIVXHQUwqvcCnk0wkUARkL2Apu1fQU6kJoAYVX0FIVX0FOphakMjKrnoKaVX0FONNpDQm0ego2r6ClzS1LGG1fSjavoKKWkA0qPQUm0elPpKsBNq+lJsX0p1GKAGiNPQUuxPSgcUuaAE2L6CjavoKKKAHbV9BRhRTaO1AH//0Pa6WkFOxXKWFFFFABRRRQBIOlBoHSkNIBppuadSUxgOalpijmpKACiiikIWiiigAooooABT6YKfTAGOBmo8yHBA4qWpBSAhINJtNT4oxQBBigipSBTaYDMUYp9LiiwDcUU/FNoAKKKKYBk0UUUAGaXJpKSlcB2TSZNFJQAuTSUUZoAKSikoAQ1FUhzUdIoQ000ppKAG04UUuaQwpKKKAFpaSimAtFLSUCG06kpaACjApaKAGnFNwKfRigD/0fa+1PX1plPUcVylj6TFONJSAaaMUpoyKYCjgUhpeopKQDKKWjFMY5akqIA1JSEFLRRQMSilooAKKKKBC04Cm08UwHCn02lzSAWimk0oNACkUzFSZptUAmKdim5pc0ALTCKdS4oAjwaSpKSgBlFSU3FADaKUijFIBKTNLSUAFIeadSYoAbS0YowaBjCDioyKmIphxSAixRinUUDGbRnNLilpKAuHNJzT6SkFxKWilpgFJS0YoASloxRQAZopKXFABRRilxmgD//S9qFTLUFTqRXIWOY0lDdKWgBKTnNKaKACkpaSgBKSlJpKYEi9KfTVp1ABSYp1JQMSiiikIBS0lLQAtOxTRUo60ALiloooATFFLRQAmKMUtFUAmKSnUUAMxS0uKMUAFFFFABRRikoAWkNGKOlIBDRS5ptACUUvNJQAUUUUAFNIpc0UDGYFIVp+KMUgIttG2n0UDI9po2mpKSgBu00u2nUUAJgUhFOooAbik20+igBm2lxTqKAG06ikoA//0/aKlWoh0qRa5CyWgdTTc0oNAD6SilFADcUYp9JigCMilAyacRSgUAOApTRRmmAUdqKO1ADaKKKQBQKKKAHCpRUQqQGgB9FIKWgBcUuDSU4GmgEwaXFLkUZFMBuKMU6igBmKKfRQAzFJTu9KRQAykpaMUAN5paWigBtGKdSVIDaTFOIzSEUANoopKYBRRSUALSUmaTNIoXFJQTUZJoAfmjNMooAdnFLUdLTAfSZwabmkzQA/NLmo8mjcaAJaSo8mk70gJMignNMooA//1PaMU8U2nCuQsf2pRSClpgOp1IKWkAUtFFACGkHHFBzR3oAdmiiigB1FJRTASilNJSAKXFJTqAAVIKYBUgoAKUUUUAOpabS00AtFFFMBQaQmiigBc0ZpKKADvSk0lFACUYpaKAExRS0lACUmKdSYpWATFIadSUgIzSU/BowcUAMptOIpMUwG0U7ikpDuNpDT8UlAxmDSVJSGgCOiloOKYCUUUUAFFFGKACkpcUYoATNLSUtAH//V9ppRRQK5CyQdKUdaQdKUUwJKKSikAUUmaWgAzRTMmlzQA/NLTRS0ALS0lLmgBKKKKAAU+mCnUALUgqOnZoAWlpKMetADs0tN6U7NUAUUUUCuFFFFA7hRRRQK4UUUUBcKKKKAuLQaSloC4UtJRmgLhRRRmkNMTFGKWkpANK5pu2n0UAREUmKlNNxQAykqTFG2gZFRUhFMxQA3FGKWigY0ijBp1JQA3FLinUUAMNJzTiKMUwGU7GaXFGKAP//W9rooFLXKWOHSnCmCnigB2aKSikAUhpabQAlFJRTAdmnZ5qOn9RxSAfS0g6UtABRRRQAClpBS0AOpaZTs0wFooooAUU8UynChCHUUZozTAKKKKBBRSUUALmjNJRQAZpabS0ALRSUUALRRRSGLmjNNpC1IdhxNJk0wdafQMSloooEFFJRmgBaKSigAJqM040w0DEzSUtFAXEooooASilpMUAFFLSUAFGaOtJigZ//X9rFLigUtcpYUoNJRQBJSUClpAHSme9KabTAKKKKACnCm0UATDpS0zNOFIBaKTmloAKKKTNAC0tNzS0AOpabmlpgOzSr1ptKOtAWJKSilpkhRk0UnNAC0lLRQAUlLRQAUUlFABSZNLRQAZpM0tJgUALmmml6UmakpDQ22nb/WmkelJimBJvFJvFR4pMUgJdwo3CosGlwaAJNwo3CoqTFAEhYGm5pMUUAGaWjiimAuKMUtFACYoxS0UAJikxTqSgBMUYpaSgD/0PbKWkp2K5SxKKKKLgOpe1NFLmgAJptKabQAtFJmjNAC0UmaKAHU8GmU4daAH0ZpM0UALRSUUAFFFLigYtKKbS0hDhSiminZpoY+im5pwpkC0tFFABRRRQAUlLRQAlFLSUAFLSUtACUlFFABSdKXFIaQ0xKKKXFA7jKMU6igBvNLS0UAMop1FADKKDSUgFozSUtADs0U2loAXNFGKKYCUZopKQC5ozSUUAf/0fawaWoxTxXIWx3akpM0lMLjqdmo807NADjTaKKACikpaACgUUUALTgabSjrQBJRilpDSAM0UlFADqWmiloAWimsyoNzkKB3Nctq3jTQNIDC4uFZx/CpzTSuI6uo3mij++wH1NfPus/F6b7Qf7Nj+QcfNXnF1411y7eTdM2yTORn+VWqYrn12+taZE5SSdAwOME1E/iTRYnMb3SBh2zzXxfPq9/Owd5WLDjOarSXNw7b3clvXPNVyBc+up/iL4bg3/vi2zqBTIPiR4bnQOJtuTj5uOPWvkQMx685oy4HGcU+RCufZ0HjXw/OW23KgKMnPpWjB4k0O6fy4LyNj6ZxXxLHcTRBgpPzDB+lMW4njffG5Ujng4o5B3PvOO4t5SwikVtpwcHODU1fENj4m1axDCG4dSTnr1NdhpfxU1+0YvcSCUEk4YZqXTC59XZozXk3h/4qaZqXlwagohlfjI+7XpsF9aXQHkSqxboAealpgXKWjFGKQDaKWkoAM0ZooxSGApDS4oxSBDaKXFJTKG0tBFNoELSZpDSUgDNJS0UwDFLim0ZNICTFJTc0mTQA/NGajzS0ALmlpopaAEozQabzmgD/0vZ+RTxTacK5CxcUlOpKYhtFLSUhjs0U2lNAC0U2ii4Ds0tMpwoAWngd6ZThTGSZoNLRSERminGuT8QeLdN0GNxIweZRnYDzTEdRJLHChklYKqjJJ9K841v4naJpxeG1PnSqOOyk/WvFPEvj7UtYmzC7QgZHyMQCPcV57LI0jF2PJNaRgFz0DW/iVrmqmSIP5cTdFHpXAS3Es7F5GLE9zyajWBpDmr0FoN4U9TWiRLTKKxSvzg1ejsZWANdNBYr5StnB6HAyB9a14bRY3BGPm9OlFylE5ZNGkByfunoTW3p+iwzJvYZZRz9RXSNAJF28g9cf4D1q7aW58osCD2OOM+9Q5FchyC6WgbzCvQ4I9jU0mlJFFu2jAOK682j5+UZ2n/IqGSJSCn3dx4zS5mHIcjc6TEpBVBtGPqc9az7jQtvzRLkEnH0ruo7R5l8tfvI2PoKZJEfOCrwM4PtT5g5Tze40lkbCAnjOPaqJs5l5C5zXp9xDlxLjoCrVnm08sJ8vHf2FPmFyHnqNJC4deCK3dL8Uappdz9phlbcOOTxWnd6dFn038iuefTpMM6jgVV0Kx7n4c+LYmkS21WMktgbh617PZ6nZX6eZbSq49jXwtteI9MGuk0DxHe6NciaORsKOFzxn6VEoiPtHNJmvOvC/j6x1kLBcN5chHGep+vvXoYIIyKzaAXdRuNNopFDt1GTTciigB2aXJpooNAC7qSkpDSAKTNJmigAzRRiimAUuKOKKQBikxS0UwExS4oopAJilzR0pKAA03pzSnmkNAH//0/Z6UUlFchY/NLTRS0yRKSnUlIq4CkJ5p1N70BcM0tGKKAuFKKSgUAOoFFFMLkmaUNxTM1yXijxHBo1s0Qb964IHtQlcVzI8YeOLfSYWtbRg07cZ9K+btU1C61GZri4dnJPUnNaV/wCbeTvO+WZiSazY7OSZxGin3raMbC3MTyWc4FXo9OkI+7mu2sdAIPI3fUV0MHh4n7yD6ik6iRoqbPOINPdhtZCPpW2umtGiB0yPUf1r0GDw8gOFXB9TWrHogUYK/lWbqo1VFs86iso4BuBZs88Vp28Kyna2Gc9D0IrtG0BnOFAHoe9S/wBhpGAgTLHqan2haotHN+RgKCNxH51chtCzBowVRuo9/wAa6iLRXCjIzV9dKK4U8g9fSjnH7NnJywKjKIx849cg1XurSTgzLnPp/hXdrozFx0KjoDVqTRPN+Zzj6dafML2bPOirW8bEYY+o5qnJGgAkTnd97PY13M3h/LkpwvqOtQHw/KBtBG09aOZB7NnDzxhbcjqCwOR2FUJsO4iAGRxkdDXoc/h0t8oYAenrWa3hx4pA6KCBRzB7JnDzxl5ypAKofwH0qM2I2lcYAHHtmunutGma5aSMHa3LA9KY+nyeTzwQMGnzEeykcDdaSsmUUYx3rnrzTJYOUBK+vrXrTWW4rlc4HNZ17Y78KR8vYVSmQ6TPM9O1O406ZZYcbkOVyM819FeDPG639ssWpTKZepP9AK8J1DQ5omZ0BwOax4Wls5RKr7SvIqmkzNxaPuJWDKGHQ80ua8n+Hnig6hCbS5bLjoSxZj9ewFesdeRzWTQBmkyaXAoxSAATQTS4pMUAJmjNFJQAZNJupabigB26jIptJTAk4paipwoAdS0wk0m6kBJRUe40bqYD6SkyKTNIB3SkNNzTSTQM/9T2gUUUvSuQoKdTN1G6mIcaSk3UuaAF7U2lJptADqKSkoAdSZFMoxQBJmjNR0/3oAo6lqEGm2cl1cHCoP1r5m8R67ca1dPNkEZ+XPpXefEHXDLM2nxP8qdR715pYae+ozAZO3v6VrFW1C12M03Tbi9fJJ2+o4r0Sx0RUUZXge1amnaZHbRKoHSttQAMCuepVb2O2lS7le2tI4lBIrSWJMdKYpA61ODmsbnUoJEiKq9BVhStVxkU7NBdi6CKlQrmqKsatJ1zQFi8Oasoi/xYqksgAqxHIDxnHpTRFi3tGcdKe6OOc4z61Gr7uRTi6DktxVXFYjOD+FMJXAGKbIy53ZquXFO5Vh7Kp5IqGcqRwoFKXzxUDMKhspIrsisCMcVQkt0xtA4rQY81ERzSuOxkNZrnOKqtZJzkVusO9QuuafMyXFHHXumg5OM5ritV8P8AmKZIQFPpXrzxBhgiqL2UbAgrwauNRoxnRTPn+yu7jR73chdHQ8gHHSvp3wh4ttdctliwyyqOQea8Z8VeHyqtdwgZHXHes/wdrsul3yLvKIxAIC7ia6E1JHnzi4s+sKKp2N0t3apMmcEfxDBq4DUEC5ooooATNGaKSkUFJxS4pMGgBMUYFLS0AJijFFJQAhFNxUmaTNADMUU6kpgJRmkpKAFJptGKMUhn/9X2fNNzRRiuUYUlFLQAlKKKSgB1OplPoAWkxTqMUAM68U2nEYptABWRrmoHT7CSUfe2nGe1bGK8X+IOtSyzjTkICJ1x1NOK1A80unnv7tpJfvMeTXoWg6YsES569643SYfNnEjcjsDXp1ltVAKK0tLI3oR11LwDh+wXH41OMYxUQwadXIdyJQOasKOahTmrSLQaJjlGafsPanKPSplU4oKIApU5NTqTUipng9Kl2e1AiAg1KjE9eKCCD9aBgcGmBYjdgMZzmg5YkE02PIqQ4zmmKw1QpHzHpTCP/rVJjvTMDtmmMgZSKQqetWtmeopTgcAUrDRnspFRkYPNXn96gIzSGV2xULCrLrVd8ipYmiAmmjBpWNQ5pCsU9Qt1nhZDzkV4lq9o+mX3mREr82QR2Ne8SYZcV5t4ngEik7ea3oys7HJXhpc9G+HXiKXVbFrW6bLxdCcZIr0yvlvwRqq6dq0ccvCO2ORmvqNCHUMBgEZraW5wBxRinYoqRiUUuKTmgYUUc96KAFpKWigApKKKAF4pjGlJqOgAooopgFFFJmgAopKM0DP/1vZaKKK5RhRS06gBlJTyKbQAVIKaBTxQAtGKBS0AIRTcU80lAGbqd0bOyknHVRXzFqs7Xd5I8zkszV7x48u3t9GZI2wX4PNfOsf7ybHJOa0ggOn02PZtC121qzCPnrXL6ZbHiutij2qBXPVlc7KMS7G+RVgGoI0AFWViYmsbHUiZDVtDUKQECpguKLFFlTzU24Dk1UBIPNSK5JNFirl1eRVpVwKyxIQ3FW/OIxyCKaAtFR6UwgFqhFxk1L5gxVWFYkCg0pHtSBhims+KdgsNLMeKfnFMMgxULXAX73FOwy1nNNNVorlS3JpXuFAJHPtSsMewyKiIxTIp/MTeVKn0PWnFqmw7kLmqchq42M1WkTcalxC5Sc1CWxVp4yKqMCOtKxNyF3zxXK63EJEbPeuocelYt/B5qFTTi7MzqK6PKNrW12H7Bs19S+FdQGoaPDNkHAxwc9PXNfNup2/kSAgZPY17D8NpWkt5AG+XjKnqDXZo1c8uSs7HqlFJ3ozUki0lFFIdgpM0mTSUDFzR3pKKAHUU2mk0WAUnNJSZozTAKSgsKbmkAppKKSgBTTaCaSmM/9f2XNJRS4rlGFLmkooAU0lFFADx0paSl5oAdRSUtABSZ5opKLAec/EjnTFIB4PJFeG2Kma7AAr6H8Z2iXWlyByQFGRivCNGjI1IRuMVa2Kjud9ZQBEArUUYFMhjCiknl8pcjmuR7nfBaFxHVRl+AKjk1RYzhBxXKz3s7uVPAqkZpTyvNaRgKU7HcjV1xk04a1CDXnjzXJ/hH51lyXl0GwUar9mifas9bbWrZeWP5Uqazalvl6HvXkK3N0x+6cVYW6lQ/KSPY0nBFqrc9g+3RZ3KcionviCD68ivMo9VlGASQRWgNUJ2gnOKTiaqZ6At+oODUwvAf4q89+3kyZB4rRt74nhufepsWpHai89DzT2uyV61yv2odjSG+C9TQO50wu2IxnpVSe+VMbj1rAN+Bk5rKvb3zSMHGD1p3Bs7GHUEZsHira6jDvwx4HevOzfbOp5x1qrcajIqbVOT2JqyHI9O/ta13EK349qc2qWvXcOK8b+1y4LM53dsdKgN7N/eJ/GjlIdQ9dl1mEcowJqD+2lxXliXc55O78q0I57g84I+vejkRPtWehrrCMeeau+ZHMm6M5rzpJ3fnaR+NWY7ueBgY+n1qZQRSqPqdo1VJkyDVO01GSVdsic+taCuJQfasGjTdHnusxfvdwHArofh5cT/ANqNHHxuHIqh4iCKvpnitDwFYvPefaEYq8XH1rphsedWXvHu2DS80gJxS5oMRKSiimMKdmm0UAOyaKbmjNAAaaacabQAmKMUZpM0gCiiigAooooAQ03FOooGf//Q9kpaXFLtrlGJg0lPxS0AR0VJTO9ADhThSUtAC0tJRTAKbTjTOc0AUNTS0a0Y3pCxjua8XuG0trwiy5lRsjgj5a9C8bXX2a0hUnh2Nef2Fti0lkY/NOcZ7gVEpG8IXVzaWZNuVrKvrpQpO4D61zPi7T9bPkf2QJWjVcOIzjp615i8d9Jci1m3iUtt2uTnP40QpqWtzWVVrSx6h9qttxDzov1YVajvtDT790hb2yf5Cs6x8OWFig86MSvgEl+Rn2Favm2tvxHGi/RRTatsNMsR6poX+3J/uox/pVxdT0PvbTsPaJqzU1CViSu1VHdjirA1G2jG+e647hMmpdy9C1Jf6Awx9muV9/KNZlxJokmShlX/AHom/wAKstr2jL0mlb8Kh/t/TXbCO4z03D/CldlKxhzPYD7ky4/2gV/mKrC6iU/JIh/EV1glFyMwlXH61n3FlDIT5kKn6qKd+47djJ88v83Bz6VoWskjHAqo2iwMcx7oT6ocfoeKhtX1i1vjpcUaTysNySN8o2+rCi1xqVjq40mYdDUn2Sc9qtWmm+KmAzNZj/gDmtxtL8TxwbhLZ8jrsf8AxpcpdzkpIZVyKx5Uctk1f1rUPEWiRf6dDb3AlO2N4srhj0yDVZNBuZ0E2qTM8jcmNDtQe3HWi1iWzMkljj/1sir9SBUQubJv+Wyt/ugt/IVuR6RZQHKwJn1Iyf1q8m2MYRQMego5kKzMSEae3LNIf92J/wDCte3GgqP3sdyT7RNV0XzxjDEIPep4dTRjj7TGv1IpcwrESXPhyMZMNx9TE3+FNl1XQFGEYqc9Hjcf0rWW5dx8k8bf8CFV5Z5B99dw9Rg0uYLIof2l4dYfLcxKT6nH86pyzWH3oJ43/wCBCrsjWM3E0SN/vKKyLzw5o16h8uIRMejJx+lUpLZhJNGlY3HOMgj2rfSRR3614Dd29zpt69mjtuVsDaTk+nSu58K22um5Lah5q25Q48w8ZPTrzVSpdbmSrO/LY2tYSG9uxHNKqKvKg9Wr1rwtpVnZWqyWzhyQMketefT6XHNpi5AMsIyGxya7HwUWYSeiqOPc0lLoZ1YN6s76kooqznFopM0lAxc0UlJmgQtGaTNITQAE0maSjFIBCaM80hooAdk0tMzS7qAHUUlLQAUUUZoA/9H2fNLnNJzS1y2GLRRRRYApO9LzRRYApaWjFFgEpaTFLTADSAUtKKAPMPiKGk+zxL3H8zWYkQjgSIfwgCup8ZWwlktZiOASK55zwDWEzvotciJUUkCuX1zw0+oX9rqNrsV4m/eZ4yo/rXX2w3gZrQWIEYqVJo15UzlbuyaSPMfWuWn0m+dzt4FenCAlcY6VSlgOarnY/Zo8zbw3dvyWyfc1Muh6j5RhZFIPGQa7l4gDzULKB92mqjB00zz0eD9Td/ndFHuT0rYtPCSQuDPcqcdlFdIUz15oXCHgCq9oT7GJTi8NQGXzIbmRGHcAVupp5KhJSHYfxYxmoI7hhV1bsjtUXLjFI5zWJIrBlhiK+Y3UH0/pVCyeSXVfPjj3zLEFG08cmtXUbAX9z58qgYHUdcVZ8L6eyCS+dSpmYlQ3UKOBTvoK2p0NpDrMygfJF+tbD6Xqxg5vB9NtaFko4Brau9kUIA60W0NeY8Q8V2VxbWqvdyGZI3WQHpgqazH1h4rlWuHUROMgAc+3Nela1ZpqFrLbMOHUivNrbS/OslhuosyQMUOe+Oho9SZXb0OqhtYrq3W4jOVYZBqnfaZfPFssPLUnqzf0q1ayyW8CwLwq9BSPNLnrUdQscNdeHNVdCJHWRv8Ae/pXMT6FrMLkm3bHsM/yr1GZS5yCQarbLhT8rk/WtVUsZyp3PPrHT71ZQ0sTKo9QQa1njvh/x6iRcfXH5V2MZmX7wzmphK4OCMVLqX6CVKxx8U18vFxHuPsMGuhsVkcjIIHvW5DEsnzHBrUit0Ck4rPmNFE4e38Ps+vy6tMFKAARjqc9ya6icbEIz1rZitlSMZ6nmsm9GZAo9abk2CikOjH7sKe4ra8Gq0TXSP3YEVlBSFFbXh6by7mSFh98ZBojuRWXus7TNGabS10Hmi0UlFABmikpaACkpaaeaQBSUdqKAG/Sg9aUik+tACUUvFKaYC0maM0daQBmlpADmnUAf//S9pooormGFBoooASlpKWgBc0ZpKKAAU6kpaACiiigDnvEyBrFWP8ACwNcIea77xJ/yDWPoRXnW/jisah10di/bzeX8tayTKOTXNCTad3pSveHtWZ1xZ0rXMaklTwaoTXQY8Vhi6fcCprTgntJEIuIyG/vI39DVWKIHYsc1EQaubLdv9XJj/eBH+NL9lJGQ6H8aLD0M8gnpQsbE81qLZv6r/30Kf8AYmHV0H/AhTsBnhMU8DJq40CIMtIv4c1QkliWRY4SXY9T2Ap2A0IoRN8hHyjr71txRhcBRgCqFsCAAK14lzxRYEbOngE80+/lDdO1JaL+7OB2qlM25jkVXQLalJyD1rDv7YRN9qQcHhv8a3ZPUVRmkXG1uh6isyjnHHeo8ZonZLWT95kxHoR1FW4ktphlJh+INICkUpm0Ctb7Hn7siH8cUxtObtJH/wB9CgRncU10Dc1of2fj700Y/HNSLb2KHE0xP+6DSsFzMidoSMdK3IruJ1CsevWoZJdPjjxDEXPqxwPyFY53SyZHHsOlIaOmuZ08rEZ5rLiVpm3NVULMrc8ir8HHNANFphxirumALL539xh+RrOaTAq3pkoa5W2/56MCfoKa3M57Hd0UhNJmug8ti5pabT6BCYoxS0UwG0lONNpAFFFFACUYNLiigBMUfSlooAbgU7FFFABRmjFGKAP/0/aKWm80uTXMMWim5NLQAtFJk0mTQA6jNNBp1ABRRRQAU6m0UAYHiX/kGt9RXmYavS/EzOumEKMgkA+1eWkkVlPc6qL0JGYnik2k1GDU4BrO50xZWbKmpVkOODzSSozHinxWsr4HSmjRMmS4C8mpftq1dg0pCAZDWrFY2qYG3OKYzAF6/RVJpr3V0fuxmus8uJRgKKgcA8AYpFo46Q30h6bRWnpemOoNxLWnOqqhY9qhXVbdItoI4qkJmvCABxV+FgGxXHJrUYfBIwa3IL2JvnDVYI77T4POhKqeax7qFo5GVuxrLh1doT+7fafY0Tap5xLOwye9DsCi7kjEbcVnvEJDzVGTUFBPzU6K/iJ5YZqGWV7y32fu5BlWrNOkuvzW0mPY1vXU6SRYbr2qODO0E9xUFIw/s2px8AbvcU/OoKPmjNdIrYq2j8djQJnFtLOByhH4VWeeQferviIzwQKqS21s4O5QaLEXRw5nbvWnZjcdxrQl063J4GKRYkiG0UiiUrxUBO00skvYVVaXJoJZYaTFbXh2NZLsynqo4rl3k3HFdH4fl8mRn+gNOO5jUV1ZHdmkpevNFbnmjd1KHBp9LtFMQ3NLmlxSYoASkpcUuKQDaKdgUYosA2nbaMU+gBuBRilNNzTAXFFFFABRRRQB/9T2fIppPNFNrmGPFGTSUUCF5paWloGJilpRS0AJRilooASloooAjmiSeJoZACrDBzXjWoWzWl5JA38LHH0r2nFcJ4usACt8g9mqJLqa0pa2ODAxVxBkVVq3GRWLOyJOkYNaUKgAVVjHFXF4FFzZF1TUu6qQc1MGouWTGQ0g5OabUi0FFDUDstnP+ya8uluxyGyDXq15H58RiA6jFedXeiXCykKMj3qkiZM5h5btJPMglJ/2W5FbFprVwqjzPlb0HIqjPbS27ESIRjviocdCOlMhSOj/ALZmzwaU6zMRjdXP7DjNCnn3ouaczH3+p6wxxZ7QO5bJNSadeapnN44b6DFW4LG5uQDGnB7mrg0LUMEgDA9Kl6iUtTRtr6WWZIS2dxAxXokcWEAriND0OWC4FxcdR0ru1PHtUmiK8zeUhbBbHYdakifcgbGM9jSyLuqEZHSgGiwWqJnqMt61GaLkWGSNzVRmO6rJFQsME0gKjDvVVyVzVmQ4NUJHycUXJYA5bNdFokUlzceUgwuQWPtXNjgVnp43ufD981tFGssZxvB4OfrVwjd6HPVnyq57xgdKXFcbofjbSNaIiyYJj/C/Qn2NdlW7VtzguKKfTBTzQAUlLSUAJRRRQAUUU6gBKKdSUANNJTqKAEopaSgAooooA//V9koopa5hhTqbThQIWikp1AwzS0lGaBDqKbkUZoC46im0UAOzVK/tkvLZ4H/iHH1q2TUTNSsNOx4vPC9tM8EgwyHBojbFdl4o0+Nl+3oQrDhs8ZrhtxFZSjY7qUro2YnBFXFYVgpLtrRhm3cVmbpmiMGmuWwQpwaRMUkh2qSKDS5LEXRQrncfWle42d/rWZ9oZVJbJqtNLvXyyMA9adiXI1ReK5JTPNOhiluc4H4ms+CSBOZGAUVDc+I44f3Nn+dUOKcjSuNBilQmUgZHrWJ/wiVvK22GcA9hms6TUric5llJ9qjW6KncGIPrRqdEaK6lqXwnqETEDDAVq6Z4TC/vLwZpLPxTdW8ZiLb8+vNVp9dnuD88hoaKVBdzrv7NWBQsGMCoJ0MY3qCAOtczBqlwp3JJ+da8OvA/LcqCPUVJEqVtjRSXacHp61dSVNvBrPJiuF8y2PXtVB2lAC9MGgyu0b+8DhuDTWNZRuG2gycmnLcIuOCD3BpFc1zQNMwaUOGGRQeaQiM1WkNTyHAqhJKMUgKczHmqmalmk71nNISKCJMmllEUbTMeEBJ/CvKJbkXU8kzdWYmvSp7S41CI21uy5PUE9RXOXXg67hY+WCrDseh+lXTxFOm7SZ5eJrK/KYdhI8V0oXoR+tfRPg7XRqVmLSdszRDHPcV8/wAFlc2sxFyhQgcE1v6Rqc+m3iXULYKn8xXc7TV0YRlc+lhTq4rRvGFnqEws7rEM56f3W+ldmCaxasaXH0UmaUUAJijFLRQMBS0lFAC0UUUAJRilooATFFLSUAJRiiigD//W9kpaSkJrmGOpajBp2aAHnFJuptFADt1GaSloExaWkooEOpapXt/aadCZ7yRY0Hqev0rzDWPiK/zJpKBEHHmydT9BTUbjueo3d5a2MRnu5ViQd2OK8o8Q/FbS7FWh0qMzy9AzcIP6mvJde16/1RibiZ5P94/0rhJS2Tk5rRQXUVzd1rxXret3Hn3lwxAOVUHCr9AK7nw94gTU7cW9wQLhB/31715hp+mXmqTiC0TJ7t2A9TXq2l6LY6HF8mJZ2HzOf6Vz4mrCCsyo1HFm4JCDzVyGUHvWQswckd6kWQqeK5oyUldHfCaeqOst5ARjNWJD8tczDfGPk1pLfpNHxwao2UiCe4QPtHasO9upMHGcD0rSb95JnOasJFGPmKii4JHnc+qu5MSljjrgGqX2uTqqvn6V6LPa6dI5ZkAb8qAlrGOI1IHStotWNoo87Fxfn5lhkx9Ka95cqf3kUi16al5GoxtAx2rUSa3lAEkaMPcZqtDVQZ40NRZG+7JUv9rbRgJISfavWJNI0WYlmtxknnHAqxb6P4fhbJtlbIx83NVZGnKzyuLWTjHzD6irK6qW53V6wtrokIO22jx24FUZo9MPyiCP/vkVDig5WcHba3LA2Ufj0zW4niJJlAbG6tE2mmN1gj/KkXTtMlBQwLgnqBg/nUNImVMfBqSSDDYx7VcSQyHb2rOOnW0Hy2y4HpnNOgYxEgn/AOtWTZztWOogJC4NTs2Ky4pgI8k1FLegcE5+lILlqab1rKmnFVpbrJOazZ7gAbiaCSxLNxkmqbS7RuY4FVDIXbNMmyYyT0qW9DKcjS0wzW05uJHDq7ce3tXp1pNHdxAOAwPrXmumQtPZPjnAyPwrvdPkitLE3Ux2oi7jXh4y8paHg4nWRwXjBYI9Q+zwk4Rcn2J7VxobByKvaldyXt3Jcv1difwrPG7NfVYOm6dKMWa01aJp+blEmH30OM17d4O1h9SsDFOd0kOBk9SK8IRwE2+tekeA76zs3nN3KsW4ALuPWt5rQ0R6/mjNVILy0uf+PeVJP905qxmuc0Q/NLmo80uaQD80ZpmaWgB2RS5puKWmA7NGaZk0ZoAfmjNNzRmgBc0UmaKAP//X9j3Yph5oormGAzTxTKXNAD6KZmjNAEgpaizRuNAmiasTXdbg0SzNxJ8znhF9TV+4u4LSEz3LhFHc14H4p1x9Wvmk3YiThB7VcY3EUb7VL3Wr0y3kpYdcdgPQVzGpy5fCnAHGK1bX5Imkbqx4rB1IhZW/2ua1tYlsxppcZpNO0ubWLjauViB+Z/QV12j+Epb6MX2oZSH+FO7V2Bs4LGIRQIEUDgCvPxGPjD3Y7mfOU7O3ttKtRBagKoHJ7sfU1GZWflqHkAPWomchTjrXkSk5PmYyCSZl+YcGrVvdrL8rcN/OsieXORWTcXBhw6kg54xXTRbR0UpNM7NmJ4FKkhDYzgVTtZjNAkjdSOfrU44rsO9M2YJFxwasGcYxWXCfSrW2Q0jaL0I7pAyZU81jedNH0Jrc8hz2rPubOQZIBp3LuU/t8g4ZQamTVxFwwNUzGw6ioHjzVKTKVRo3E8RRZwSR9asjxBak7d4zXK/Z93IFJ9lz2quY1VdnWnWIXGFcVD9tRustc0tqFOQKtLGQOalyD2zZs/bYlyVyTU0F3PMcIdorKihZzgCty3haNcYxUOQnNmlG+0AZyaic9TUWGFNfJU1Bm3cY92ypjNUfOOflNMlPOKqs4HFMgtNKcc1Udi55pm8mgZoIbJlqWXHl4piDFSMpkdYgM7jUyJlsdZ4dtgLUgjkjpWH4h1UfZY9OhYgjl8foK6eNo9K017psAKuR9e1eTSzvNK8rdXJJ/GubAUFVquctkeE1zTbG7u5ppYUEd6YTzgV9EbE3mBBvboKfbzyZ3nv0HtWaW+0SeUv3E6+59K0UXHtQB1Wj3zxXcTiXywHGSTwBXvEF3bXIzBIkn+6Qa+aYrlYH2ld/FXE1OeGTfCCF9AeaiUblp2PpEUE8V4JbeMdYtOd0hUdjhq6rTviGk5CXMYJ744P5GsnTZSkeoA08Guds/Eek3mAsuxj2bit1GRxujYMPUHNQ0x3JqXNMoNIB+aM1Hk0vNAD6Wm0tABRRRmgD/9D2CikzRXMMWimSyxwoZJmCKOpY4FclqHjfRrMlIN1y47R9M/U00rgdfS15NceP9SkJ+zwRxD/ayx/oKxLjxjrkuR55UH+6AKtUmK57i8iRjdIwUe5rHuvEOlWgO+UMR2XmvA7nV9RuD+9nc/iay3mnbkyMfqapUSXI7rxL4hfVLlmTIhj4Rff1NcGFa7uNrfd6n6VaLBogrHk04FFiIUYPc1oo20Fe4yRlztThRwK19A0q01HUBLdc+SNwU9CawRkmum8ON5OooM/fBFYYq6pSsTLZncT8sEUAAdq5fUS24g10xUkFs1zl+hJIFfIRk29Tmgc4PvnvROxCjFD/ACNgVE+ChY9q60zdGTO+M44rFTE9xuHIFad6T5bMKq2cYVeOtehRjpc7KUTf0x/vQnp1FaJDRH1WsOzfy7lfQ8V0TDNbnUOgmUkMK6C1kRxxXHyq0Z8yPJPoKntNRzjPyt6UFxnY7xESrKwxsORXNW+qIcKxrRTUIzxuoNlJF6TT7Z+SBWfJotsxLYqf7ajYyeKcbtf4WFBaM59IgA4quNKVjgVstKGqISbTmgCmmhjqWqwmhRg8nNXY7nIwx5qwtyo70hkMelxxcikkjVegqV71QME1Ua7Ug1DuBA4CjNZdxcBRtWi8vVAODxXMSagCxVPmNNIlyNCWbn1NV9xaoUUk7m6mrAHNMgEBqwopqipBheTSbCxKAFUsa1dJtGnnErjheazIENwwb+Ht71r3eqQ6RbeXCc3Djgeme5rnnzS92O5x4qpyx5UUfFepB5BpsB+WPlsd29PwrjwR3605mZ2MjksW5J9TTCRXr4WgqMFE4IRshHfHTrVKeYlhbx/ffrjsKLq4jtommc9OgqrYwyEG5l4kk5+g9K6Rs1raMRoEUdKskhQSe3NRp8q1Tupt7i3Q9eW+lAFu3lEimQdz+lXlfPBFZ1ou1Wq6tIZOSKidI5D845HccGlzTM0DJYlniOI5Mgf3uv51tW2taraEbGYD/ZOaxAakV8c96VgO/tPHl5Dxc4kA9Rg11Fn440m4IExMZP4ivH97P3p2SOlJwQ+Zn0La6lp94M206P7AjP5VfxXzUJpEIKnBHccVu2PirV7E/u5i6j+F/mH61m6XYfMe806vOtO8fQSALqEWw/3k6flXY2etaZfjNvOpPoTg1m4NFXNSjFFLSA//0fQNQ8S6Rpg2zSh5B/BH8zfp0rib7x3fz5XToVhX+8/zN+VcKu3GQMUFsVKgkK5ZvL28vX3307zH0J4/KqcZUsAeAaryPUQfmrRJoNLbruDcYOBUBls2kD5wOm2qUpzVcnFaKdhNGmY7eTpjlj+X51E9vGkHmKpc885Pb6Vlk5NG5sYycelX7VdieUmEgYEelN8znFU7c/vHU1I+Que4rK47F1eWAHet/Sl/4mcAXtkk1gwMpUOOa2dLLtfx465rmxOtNim9GemSx7I+KwL2MAE+tdVIoaMe1YN5Fwc18VzWkckXY4e5jwd3vVGbOzPQCtq8jBB44rJuBsTB5rtps3i9Tnb05XHqakt0wnHWqc7NJcbecCtWFMLXr0laJ6dFaEJyrBh2rpYpBJGrjuKwGBIxVqym2Hym6dq0N7GsaqT2yTc9COmKt0hoHYwZVvLXlf3gpkepEHD5UjtW6wzVKa1gkyWUZ9aq4rPoQpqw/iarcepqTkNWLLpa5/dsR9apyWEy/KrZPrVJJj55I7hNV+Xg/rQdUHZv1rhfIulUAE8e9MMV4en86OVD9qzt31ULwWpo1f8A2q4gw3pPf8aelreN1bFFkHtGdfLrCjq+PxqhLrwOUjyx9qxF0/dzISa1IbWOLG0AVEkh80mV45Lu8OZSVWtKC2SEfKMn1pyrjmrAIxUspIcKkA5qEyKO9VpLzHCjJpWKujSMiqMscVHHvuW54j/nWdFvmcNJ27Vfe5W1XAGWPQU1BvRESqJI05b5NPh3LgyEEIvp7muXeSSVzJK25j1JpHd5HMkhyx70hOBmu2jQUNep5lSXNK4pOV+lVJZUUZJ2gd6ZcTpGvXHrWVIJLllOMAnCr6+5roMxiCTU7sM3+pjOcetdCFAIxUcUQt4hEOo6mnMxFMBZ7hYYi7du3qaqWkbBTLJ99+TUKOb24yeY4+nua1Qu5sDpTQE6LtUD8TUqg0gwetLnaKAQ6imbx60m7nFKw7kvSniod1SA0hlhTjrTywqrmmbjQBYOCaUCoAaeGoAsBasxkoQY2Kn2OKqA1IrkUWA6az8Q6vY4EcxZfRuRXYWPjqJsJfxkHuydPyry4MetL1qXBMaZ/9LiA5AqJ5DjrUO/AxTS2etXYQrMcZbmowwqNmpFbmlYRK3TNVXapnYmqx600hCZo5pKBQ0IqFxFcDPG6rZ54rM1L5dknoauwv5kYcd6EgQ1Zfs0uwnh+RXWaTKEvUcc5rkryISRe45FXNJvRNGpDYdOOPas6sOaLiTJXR7/ABHfF5h4FY94ASRVfQNXF5CLWc/vV/WtO6hLEuBkjtXxGIoypTakjjaszkbqHrxkVzWoKVQKoOTXdzwgoQa5i/hY9qujI2hI4YRHzzWvGnAqs6bZwK0UHFe9Tfuns0diu8feoCuDuHFaRGaiePIqzUdBPkbW61bzWSUZDxVqKYng0wLRqM81LkGl60h2KxFV2Ga0Nq96iZFNMLGcVB60gRRVpohnim+Xii4WINopcCptlJsFA0R4pQcU8rUbACkMUyYFRtM3ao2aoC1FgHu5Y0iglqjySeKmB2jAq4QcmZTkkWVlEQIHLfyqIkklmOSaiGBQXA613QpqJxVKnMSdqzru8SAYJ5NQXuox23AOWPQDkmorS1LE3t7948qPStTEdEu1Td3QwP4VPr6mr9rG+PtEowzdB6Cq8Ia8fz5B+6U/Ln+IjvV5n43MaYDnYDr1rGuZpJ5PscJ5P3iOwpby78sbI+ZH+6Kn0+0+zpukOZG5JoAuwwrBGscY4FW0BApiDJwPxqXNACg+lBaimmgY0804YFJRQBLmnA1GKUE0ASik4plFICUGl3CosmkosMnD08SVWzTgTSEWlkI4qwrjHNUAxNSA4oGf/9PzemsajD0hNaCA4oyKQ03NBLJDzULU8tTTSAbRSZoyDQBTvk8y3YVBprFrfg9OCK0mUMpHrXP284srxo3+65oEdCMMMN3rmJXk0u+3p9xq6fgjK1RvrX7TEcjkDigDe0vVvnSeFuRXq+la5bahhGO2T0PevmO3nnsZNvPuK7TTdaG5WDYYdDXDjMHGuvMznTue+XVqsgbH51yN/bOmVYY9Km0rxXbTRiK8IQ/3u1dDcxwXEO7h0boQa+VqYepRlaaOblcXqeS3EGycH1qwFwK2tU014JNy/MmeD6VlshFezh5Xjc9zCyTiRYppGKfwKCa6DqIioPWoimPu1ZwKTaKBNEaMcc1OGFRFaUCgRNmmk0lIaYxpANNK4p+KQ0ARUhOKeaYeBSAgd6rO5PSntvLHJG3tUbLQIhJNIELcAVJhR941Xmu0iGFraFJtmU6qRY+SJeetV2lbqKyZNQVSSxzWVcao8h2Q8k9hXbCCWiOKdS5vy3qKcMelZsmoTzv5Nou5j3FQW2lXV0d903lr6d62Wez0mLEQC+p7mrsZkNtYJbN9pvW3S+/QVIm/UpSE+WBfvN6+wqvFBc6o/nT5SHtnq1beUiQRRAKi0wFJUKEThV4AFZ93cCNN3XHapZp1QZNVYLf7Swml+72FABY2jM/2u4HzHoPQVtADOAOaaOPlWpAoXn+L1oEOBI47d6CaTIpKBi80UopOKAFwaUUmaKBodin8DpTRSGmAuaTPNJk0lIY+jNNzTc0ATZFLk1Dml3DFAiXcepp4bNV91SqeKQH/1PLBUmai3UuasgUnJpKQE85paAEpDS0dBQAw0mKXOaPpQgFArndYtyGEy10dVbmITRlDQFzI07Us4hmP0NdErA8DmvP7qB7eU/oa39N1MOoilOD0pXEal7p0N2pIGG7Vyckc9hLtkBA9a7dX7g8U2aGK5XZKoIoAwrPUW4yc122meJ7i0GxDuU9VbpXA3OkT27GW1O4Dt3qol68bbJgVqKlKM1aSE0nue823ifT7tBHcLsyMHuKZc2kDr5tswdD6c4ryK3u1OMNW3bajJEcxuy/TpXH9RjF3gaUpcj0OnljKHpUFV49ZEnyzgMPUcGpxJBIMxMD7HrUSpSjuelCrGQucUZzTCTUYc55qLGhPRUQenCQUCJc0lN3elG71oAfTCOaXcKaWFACHmoz0NRz3UMAzI2PasK61V3yIRtX171cabZnKokass0UYJdgKy5dQUA7OPrWFLdbfmc5rKmvSxOK6oUUtzllXb2NufUQBweaxZr9mPB5qvFBdXj7YlLe/aumsNChhIlvDvYfw9hWyVjnbb3MG2sLzUW+X5V7sa6q1020sBkYL/wB41PNdQQrxhVHpXOT6hPfSeRZg88bqpCNG+1SOJtkfzMeABS2GmS3Li81HtyE7VPp2kRWf76c75D3PatZ5DVMBSyhdo6DoKpSSDoakkkAGRzVRUeZ+Bx3pCuSRwrOdzdBV8KFwBwKYqiMbaVWMpwOFHU+v0oAnXaOTzQeTmkYjsMYprcUAOopmaM80DH5NHNFHNABThSUooAdntRSdKM0wEoNJmk570h3HZpmDS0nfNAXFwaMYpMigtmgBR1qVeKgzzU6k0gR//9XybNSZ4qLdTx0qyB/WkJxxS0jEdKAA0n0pODSd6ADNKKB1pexoACM0YpaKAMy+s1nQnHIrj5EeFyOQRXoRGRg1kahp4lG5Bz7UmK5kWeqtGNk3ze9b8F9FIMgg5rjJYWibDCnISnKnFIZ3fnIeBUU1tb3I2yqG/nXKxak8Jw+SK17fVbdvvHBNO4EU2hlDus3wfQ1W+0XVn8l0hHv2ro4rqGTgMDUxMci7Thh6GlcRkwXUMq5VufrVtZ8dDiqtxo9vJl4SYm9ulZ5ttQteQPNX1HWiw07HRrqEy8ZyPep11GM/f4rlYr1T8suVb3GKlaQHlTmodKLNo15I61bhHGUYGneeRXHCV1OVOK0rea8PUZX1aueWHfQ2jiU9zo0uOKebgdTWI9yqDms2fUEAILZNCoPqU8QjppNQijBOcn0FZM+qyvkIdo/Wuakv5GGEUn3qoDeTnCKx+lawopGE68nsas16u4knJrOk1AsCFHWrUGiXM3zzsEHp1NbNvptnbc43H1ateUxbb3OahsLy8OcED1NdBa6HbRDfcHeR+VX3uYogegArEu9aQDbGdx9qdhHQGaC2XEeFHtXP3usjlYTuNZIa+1J9kYJHoOldDp+gxQ4kuDuYdu1OwXMu20681N/MmJVK6y2s7WwjCxLz696sDCKAnAFMbke9CC41mJ71Cz4pzccj8qrs6AbmPFNiHqC5wehqYskK4/SoUZpB+74HqasRxKvOcn1PWkAwRtK26U4XsO5q2MKMAYFNK5HFIeBimMdupuabRmgY6lBpo5paAHbhS5FMxS0CHA5qTFRJUp6UAIW4pmcmlJ4pmec0AOzjikPBpCSab1oAfzQGpueacelADT1pvfNLRQMcDmpRUSY/GphjFAj/1vIqdk1FnvUtWQKCaOvNJRnNAD1NFNFLmgB4zS0zJp455oAKSlNJ7GgBaKO9FAijcWEc4ORWW2ikcKa6IU6iwHG3Ok3CLuX5hWE6ujbWGCK9OwKzrzTYLoZK4b1FKw7nCxXMsTAqxxW1a3V1KR5OCfeoLrR5oCSnK1TgZreUbwQO9KwzrIzqQGWi3fQ1OtxcrxJCw98VVi1CIKCsr/pWmmoIVH7w/kKCSu4gnGJo/wAxVM6OpO6CQoPRula/no7Z8xv0xRsZzlJFP1pgSWthawgH/WP6np+AqaWzmkPBCCqoa4i4Me4eqnNNF4zHaMgn1oAjfSYn5mlY+3So49Ktf+WSZ+tXHnij+aQ7j7dKpTamApwQBSAsGytwPnI+gGBQ00UKhUA49K5+XUmfIjUsfaoFh1S4+6u0H14pgbE2pKmRuArEm1gnKoCTVhNDmdv3zitODSrC3IYqZG96AOZjh1DUDhASv6VtW3h+NMNdPn2FbnnKq7Vwo9BSBwx4p2AmhSC3TZAgUD061KMjmowFGAetPG7HHGfWgQpYdzio/MQDCgsfagxx4+f5qikmVRtTj6UDGOz87mCj25NQo0W7aibiO55pRzyeanXA6DFADkDZ5qytQDrVpVXGTTGByBgVGfepNwpretIBhIHSgU3rThQA6l5pveloGOAzQcCkzQD6UCHKeKcWpmcCk60AOJzTaKMUDDPFNNKeKSgQlKTSUnNAClqTcKYTikXmmBYBxUy9KgWp04XPrSA//9fxsmps1XqbtmrIH5paYvvTs0wHClpmaXNADxTgeKjBxTs0gHDn3pxqIGpMUAOpOvWilxTASlooOM0AFHT6UnQ0mM80riHEK3FZ91p9vPGRgbqvc0uB1oGcLLDJbPtYYpySPwwrspYYpRh1BrKm01ckr8opWEQRS5AINXkbvVBIwh296uoOKAuXEmYdDirQbzF+cBs1keYw4HSlF4UOB0ouMuy2FvMMEFfYGqy6NGpy3zfWpE1AHgipfty+tMQ9bWOL/VIFpzO2CCKaLtGPSpfOj60AVZLtUXAQn6Cqbvez8InljsTxWm0wJ4oDlqdwM9LBmGZpCf8Adq/DbQxfw5+pqynI5pT15pgKuM8DAprOB0pjnA44qlK/HXmkBNJKoFVchjmowd5qdF7GkMcoHap1BIpoWp19KAHKtPJxRTDmgAzQaaaTNADqBRR9KACnZptFADwR0NJTaXNADsikzTaKAH4NLTcijigBw96aRRmkNACUhOKM1GTQAdacvHIqKnjOKAJ1yTU+cDFV1NOY8UAf/9DxcGpgM1WHUVaHFWSOx6UgJowaDQIKWm5NKSc4oAfzQKQD3qQDFADQCakANLxSUAOAIpc03d2pM0ASZpuQKXJ7U3/JpgL70tRk80UgsSUU3PpS5FMAobBGKM+lKRg4pAZ1zADyOoqBXZxt9K1SOaybkNby+YvQ0CB43JwvSoTaSnnitK2njkXnr3q6oT+GkFznfs0ooMMuOhroyBjmmbF6YosBzwinyMZqysU2ec1shBUuwAUwM6OCQ9auxxhamHHSkbPJosApZegqFnC1Gz4NUpJu1FxkssoycVTDFycU375xVpIgvNAD0QDmrAApirUgU9qAHjrUoXHNCJ6088CgBhNNJ9aQnFMLc0AKaOlR55pc0ASbsUbuwqOigCbNHGaj57U7PagB4oxTc0uaAA03PPNLScUAOGKCQKSkOKAHUUzmk3Y60wBjioWbmnE81AeTQA4nmp1zjNVakUkUAWA1E/3c0xeTzUckilsDlaQH/9HxNDk1YB5qpCfmANW/4qszRJQTTQfWgmgoUZ7UjZNJuNJmgRIhA61JnioFJqTrQA/NKTTKMmgB496dwajzilzQA8HFOzUVLQAGl7CkpcHvQA4Yo4pgPGadk0AOoyD2puaaRmgQpBzUToHGDUnNFMDO8vyj8tXIHJ604jJyRURYIc0gsXwcgYpapxzc5qcSg0DsWBTs4GariTPSo3lPQmmBM0gFVpZ8DrUcklZ8swBpXCxJJMeTmq2GkOTTQC55q9HGDigB8UQAq0AR2oAxTz60WAVeKeBzyKaqnOam6dadgHDikY0mf0pjGgBGqGnEkcGm0AGadim07mkAZpeKbS0APFL7UCkzinYBKKQnmjIpDHZ60A9qTPpRQAuDSgGmZNLmgQ49OKiNLmkoACRjNQEipT1qEjvTASnA4qPPNOzSAmD8EnqKg5apBkKTSRnjNAH/0vDLcjIq6etZdpvExEg6dq1Dg8irZmhM0uaQetLQMXNApPpRzQA6nioxS5zQBLS4qMGn5FADwaD60gOaWgBaXik4opgGaXPFNpGORikApx60pNQ4xUmaAFwacKQk4xTMnNAE1LyopoJ60ucmgBOWHAqAxk9s1dAA6UbRQBQKsvbg0YarpUHrUbbRQO5FuwM+lVnck5qaRo8GqTN3pXERSyEjFRoA/wB6n/f6irMSAcAUXHcEj+mKtquBTQMUu4imMlzT1GeaiVSeasoMCncVh68UhOTSngVGzAUXCw4nFRFsUjSDqKgLZpCJSRTAwFN5phpXAnDA0uai96WmBJmlyKZmlz70ATA4FMLc03IpOM0wF3U3NL70YFIB2cUbqbnijvTAcTSZpCQeBTfwpAPzmiowadn1pgKcVE+MVJg1C5PSgCHkU4HPSmN9aQZHekBYXkEGnZCjio1YgcUhbNID/9PxCLLyHPpU544qCBjhjTtxzVkIk3U6mcmnUAOoooxTASgGlpuBSAkzTx7UwDvTwcdKYD6TPNIKdSAOnIpM0tGKAEzTSafgd6CuaAG9aM0u3FGOKQx+c0oHNMx3qQUAHNITTqjOQaYiUH5SfSjeRUW7ioi5BouBOWqpJJikdzVN5DzQAPJjPfNQ7i78DGaTO6rMSHr2pMaHRrtNWFJByKAozxT+lCFYXPOacqljSKM1ZRSKY7j1XA5p24KM0hbiomJNAxWcnio2560hHoabz36UxCHpikxUjIoUENnIpmB0JpDENKDRiikAopeKbRQJoXNKeKYR3pfpTTCw7JpQc00CjNAh2aKb70ZoAdxTup9KjB9aXdQA4jHvTc5pCwIpvAGBQAp4pM02lFAC5NQsTzUuc1HJTArs+KQNnmmyc0o4WgCcPhOnU0zdSSYEII55qNST1pAf/9Twq2cshNT/AFqpZf6o/WrXNaEoeGz7U/qeKjFPXjikFh+cUdaQnvSjpQIUc0UA4pOtAEgHFLimg07J6UDsOA9qd0phwKBigLEnWgUgNJkUBYWlBHem5FMzQFiTdmm5pPpRQMkBBFLvPaozgAY4puSOTQBOWxUZbnNM3VEzelArExPGRUDMAc0wyEcVCzA9OKQWB5evWoD8xzSt9aTJPIFAWBV9KsJkfjTVHNTAA0ASIcdakwTzUIUjpVlAaaGSRqQcmpicUzdUbvmmKwrPUZao2bBpm44pDJd1LmoQx708njIpAPzSHrmgUUgFyabzS5pKAF3cUEnNJjApAcUAPJyMU1TS7qYc4pgS7uMU3Jpo4NJ3pkj+lKDk0wY704ECkAp4puec0pPGKaaYClvSkB9KYSOgpM4oCxJ9RRTAfWnZoAWo3YU8mq7nmgCJjzSBuaQn0FNHJoAsyg+UOMc1GuB1/SpHJEQ9M1Er8ZpDP//V8FsObbnrmrVRWqbLfBpSasglBp4qEdetSigokBFFMzS0CsPGKUimCpcZIz2oYWHdqOlNzjigsDQMdmkJxSZoIzQA/cabnNJTsUANzg04HigrTTxQA8U4Uyl6UAONNJ7UbhioywoAY7elRFiBSkgHmomYZpANJpjHAxQzADNQ789aGA8HvUy/SoAcirEfPWgCUKDVhYzxiogccVOrE8VSFclCjqafwtMzTGb0pDHO3pUDP6UhbNM4zzSuAdTmnUlLQAUZpygE80pXn2osA0HmpQQelREYpQcUgHkgdaO9H0oyaAFpMikLEUzJ6UwAk5yKTJoooAXNLmmmgc0CsOzSg5poXmpOlArCY70EikJNMzQFgPqBTfc07rTaLlADzS03A70tArC5xk1BJ1qYkAZqu7ZPWi4xGPGBUS7gfWlNCjJp3EWJmAiUetV2YbQKkm/1S/U0xEB5JpBY/9bw48IoHpUYpxOAoPpUeTVkDxx0qQMKiFO4pFE+aDTVNLkUAPBFOyTSDGOtFMB45rQhhh8tjMOe1Z4AzmppJmkPzdqTARlUcDpTOKM800sO1ADwKMgUwv6UwtmmBIzelMLE9aYWppalcCXzKY0melRE1GWApAPLmmFzTCT1qMmncB+/mmO7DpUe40ZzSAYdx605Rzg0oANPC80gJVSrKR8ZqNcdKsqMDiqQAE708CjFL9aZIN04qNiV4xQzVETmpAfn1oqM8ilBFA7jqdTaX3pjJVbipMZGarD1qQNRcCQqDSbaNwo3c0gF6U0t6UFgeM0w8UAHNJ9aWkxQAvFGMGjPNGaBBRQc4z2poNMB3NO3DGDTKb360DFNJ3pTSHii4B0oJphcU3d3pAOJFKDmozzSg0CFY8YqsTz0qRyRzUG6qGOJpUIzURaljPPNAFi5O2NPc1EPan3ZKxRnrmqolA4xQI//2Q==,-223,-1.126397e+11,-1.743251e+09,-1.726474e+09,-7.006691e+09,-2.802677e+10,-2.265856e-34,9.326161e+08,3.661782e+17,-223,-7.006691e+09,-2.802624e+10,-2.802624e+10,-1.12646e+11,-3.824084e-27,2.413978e+17,-6.101491e-23,-0.01737323,-3.863692e-18,-7.633996,2.569312,0.4874715",
				"timeStamp":  "1kZVhfcYidGTLd3r+EDnpw==",
			},
			"thsessionid": a.thsessionid,
		},
	})

	//body, _ := json.Marshal(&map[string]interface{}{
	//	"_requestBody": map[string]interface{}{
	//		"data": map[string]string{
	//			"bestImg":    b64Img,
	//			"hackString": b64Img,
	//			"timeStamp":  b64EnTimestamp,
	//		},
	//		"thsessionid": a.thsessionid,
	//	},
	//})

	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenmng.secfaceauthnew", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_limit_charge"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("secFaceAuthNew post err=%+v", err)
		return res
	}
	a.logger.Infof("secFaceAuthNew req >>>> %s", string(body))
	a.logger.Infof("secFaceAuthNew resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) softTokenVerify() *softTokenReSignRes {
	res := &softTokenReSignRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"device_finger": a.deviceToken(),
			},
			"thsessionid": a.thsessionid,
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenreregister.reregister02", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_reregister"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("softTokenVerify post err=%+v", err)
		return res
	}
	a.logger.Infof("softTokenVerify req >>>> %s", string(body))
	a.logger.Infof("softTokenVerify resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 签约快e付
func (a *Account) softTokenActive() (*softTokenReSignRes, []byte) {
	res := &softTokenReSignRes{}

	stokenSignMsg, key := a.genReqSTokenReEnable()

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"message":                  stokenSignMsg,
				"random":                   a.RandomNum,
				"device_finger":            a.deviceToken(),
				"device_type":              a.Model,
				"agent":                    "iphone",
				"soft_token_activate_flag": "1",
			},
			"thsessionid": a.thsessionid,
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenreregister.reregister03", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"soft_token_reregister"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("softTokenActive post err=%+v", err)
		return res, key
	}
	a.logger.Infof("softTokenActive req >>>> %s", string(body))
	a.logger.Infof("softTokenActive resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res, key
}

func (a *Account) softTokenReSign() (*softTokenReSignRes, []byte) {
	res := &softTokenReSignRes{}
	stokenSignMsg, key := a.genReqSTokenReEnable()

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"stokenReSignMsg": stokenSignMsg,
				"deviceInfo":      a.DeviceInfo,
				"lbsAddress":      "",
				"lbsStrXfraud":    " # # # # ",
				"clientIp":        "",
			},
			"thsessionid": a.thsessionid,
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.ebankcontroller.softtokenResign", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"login"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("softTokenReSign post err=%+v", err)
		return res, key
	}
	a.logger.Infof("softTokenReSign req >>>> %s", string(body))
	a.logger.Infof("softTokenReSign resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res, key
}

// 获取AppID
func (a *Account) getAppID(app string) *getAppIDRes {
	res := &getAppIDRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"businessId": app,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.common.authority.getappid", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{app}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("getAppID post err=%+v", err)
		return res
	}
	a.logger.Infof("getAppID[%s] req >>>> %s", app, string(body))
	a.logger.Infof("getAppID[%s] resp>>>> %s", app, string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 查询卡列表第二步，获取到卡列表以及余额等信息
func (a *Account) acctServiceMyAccount() *acctServiceMyAccountRes {
	res := &acctServiceMyAccountRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"isFirst": 1,
				"isClear": "",
				"accType": "1",
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.acctservice.myaccount.init", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"myaccount"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("acctServiceMyAccount post err=%+v", err)
		return res
	}
	a.logger.Infof("acctServiceMyAccount req >>>> %s", string(body))
	a.logger.Infof("acctServiceMyAccount resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 查询账单第一步，获取最新的交易信息
func (a *Account) detailQryInit(cardNo string) *detailQryRes {
	res := &detailQryRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"accNo":     cardNo,
				"encAccNo":  "",
				"jump_from": "myaccount",
				"version":   "4.2.0",
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.detailqry.init", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"detail_qry_new"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("detailQryInit post err=%+v", err)
		return res
	}
	a.logger.Infof("detailQryInit req >>>> %s", string(body))
	a.logger.Infof("detailQryInit resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 查询账单，根据时间返回数据
// start eg: 20201129
// end   eg: 20210205
func (a *Account) detailQryFilter(start, end string) *detailQryRes {
	res := &detailQryRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"queryTrnComm":    0,
				"fromIndex":       "0",
				"queryTrnAccNo":   "",
				"queryTrnAccName": "",
				"queryTrnType":    1,
				"dSt":             start,
				"comQueryFlag":    "1",
				"curIndex":        "0",
				"isReverse":       "1",
				"queryTrnAmtSt":   "",
				"queryTrnAmtEnd":  "",
				"dEnd":            end,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.detailqry.filter", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"detail_qry_new"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("detailQryFilter post err=%+v", err)
		return res
	}
	a.logger.Infof("detailQryFilter req >>>> %s", string(body))
	a.logger.Infof("detailQryFilter resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 查询账单，查询下一页
// keyNext eg: 1,20210109,354205116,1
func (a *Account) detailQryMore(keyNext string) *detailQryRes {
	res := &detailQryRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"sKeyNext": keyNext,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.detailqry.more", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"detail_qry_new"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("detailQryMore post err=%+v", err)
		return res
	}
	a.logger.Infof("detailQryMore req >>>> %s", string(body))
	a.logger.Infof("detailQryMore resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 点击账号转账
func (a *Account) traEntren() *traEntrenRes {
	res := &traEntrenRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"recentIndex": "",
				"toAccNo":     "",
				"fromAccNo":   "",
				"qrcodeUri":   "",
				"jumpFrom":    "",
				"version":     "",
				"agent":       "",
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer01", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("traEntren post err=%+v", err)
		return res
	}
	a.logger.Infof("traEntren req >>>> %s", string(body))
	a.logger.Infof("traEntren resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 转账第一步，查询对方银行
func (a *Account) checkBank(destCardNO string) *searchBankRes {
	res := &searchBankRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"accNo": destCardNO,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer11", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("checkBank post err=%+v", err)
		return res
	}
	a.logger.Infof("checkBank req >>>> %s", string(body))
	a.logger.Infof("checkBank resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

// 转账第二步，提交输入信息
func (a *Account) traInfoConfirm(destCardNO, destName, amount, remark, uniBank, uniBankName, subBank, flw string) *uniTransfer02Res {
	res := &uniTransfer02Res{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"fromIndex":   "0",
				"toIndex":     "",
				"arriveType":  "0",
				"recentIndex": "",
				"flw":         flw,
				"trnAmt":      amount,
				"toAccName":   destName,
				"initToNo":    destCardNO,
				"toBank":      uniBank,
				"toBankName":  uniBankName,
				"pps":         remark, // 备注
				"fsf":         "",
				"toAccNo":     destCardNO,
				"toSubBank":   subBank,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer02", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("traInfoConfirm post err=%+v", err)
		return res
	}
	a.logger.Infof("traInfoConfirm req >>>> %s", string(body))
	a.logger.Infof("traInfoConfirm resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) getSignInfo() *getSignInfoRes {
	res := &getSignInfoRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"operatorType": "",
				"latitude":     "",
				"coordFlag":    "",
				"longitude":    "",
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer08", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("getSignInfo post err=%+v", err)
		return res
	}
	a.logger.Infof("getSignInfo req >>>> %s", string(body))
	a.logger.Infof("getSignInfo resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) applySTokenStatusQuery() (*applySTokenStatusQueryRes, []byte) {
	res := &applySTokenStatusQueryRes{}

	msg, key := a.genReqSTokenState()
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"encMsg": msg,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenpublic.query", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("applySTokenStatusQuery post err=%+v", err)
		return res, key
	}
	a.logger.Infof("applySTokenStatusQuery req >>>> %s", string(body))
	a.logger.Infof("applySTokenStatusQuery resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res, key
}

func (a *Account) applySTokenStatusUpdate() (*applySTokenStatusUpdateRes, []byte) {
	res := &applySTokenStatusUpdateRes{}

	msg, key := a.genReqSTokenReEnable()
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"status": "0",
				"encMsg": msg,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.softtokenpublic.update", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("applySTokenStatusUpdate post err=%+v", err)
		return res, key
	}
	a.logger.Infof("applySTokenStatusUpdate req >>>> %s", string(body))
	a.logger.Infof("applySTokenStatusUpdate resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res, key
}

func (a *Account) cfcaServerKey() *cfcaServerKeyRes {
	res := &cfcaServerKeyRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.mbnk.group4.cfca.getsr", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"cfca_sr"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("cfcaServerKey post err=%+v", err)
		return res
	}
	a.logger.Infof("cfcaServerKey req >>>> %s", string(body))
	a.logger.Infof("cfcaServerKey resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) verifyPwd(serverRandom string) (*verifyPwdRes, string) {
	res := &verifyPwdRes{}
	sr, _ := base64.StdEncoding.DecodeString(serverRandom)

	enPwd, clientRandom := getEncryptedInputValueAndClientRandom(a.PayPwd, sr)
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"accPwd":       enPwd,
				"clientRandom": clientRandom,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer12", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("verifyPwd post err=%+v", err)
		return res, enPwd
	}
	a.logger.Infof("verifyPwd req >>>> %s", string(body))
	a.logger.Infof("verifyPwd resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res, enPwd
}

// 转账提交刷脸第二次验证
func (a *Account) transferSecFaceAuth(content *faceAuthContentRes) *transferSecFaceAuthRes {
	res := &transferSecFaceAuthRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]string{
				"faceScore":    fmt.Sprintf("%f", content.Result[0].Score),
				"faceLiveness": content.ExtInfo.Faceliveness,
				"logID":        fmt.Sprintf("%d", content.LogID),
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer13", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("transferSecFaceAuth post err=%+v", err)
		return res
	}
	a.logger.Infof("transferSecFaceAuth req >>>> %s", string(body))
	a.logger.Infof("transferSecFaceAuth resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) traInitiate(accPwd, encMsg string) *traInitiateRes {
	res := &traInitiateRes{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"dypassword":  "",
				"encMsg":      encMsg,
				"trnSafeFlag": "2",
				"accPwd":      accPwd,
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer03", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("traInitiate post err=%+v", err)
		return res
	}
	a.logger.Infof("traInitiate req >>>> %s", string(body))
	a.logger.Infof("traInitiate resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}

func (a *Account) supVerify(logno string) *supVerifyRes {
	res := &supVerifyRes{}
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"data": map[string]interface{}{
				"logno": logno,
				"maxT":  "1",
			},
			"thsessionid": a.thsessionid,
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := a.addBaseHeader("com.abchina.mbank.transfer.uniTransfer09", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["channelid"] = []string{"uni_transfer"}

	resp, err := a.aliPost(header, body)
	if err != nil {
		a.logger.Errorf("supVerify post err=%+v", err)
		return res
	}
	a.logger.Infof("supVerify req >>>> %s", string(body))
	a.logger.Infof("supVerify resp>>>> %s", string(resp))

	_ = json.Unmarshal(resp, res)

	return res
}
