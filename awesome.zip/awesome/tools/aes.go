package tools

import (
	"awesome/tools/cipher2"
	"crypto/aes"
	"crypto/cipher"
)

// AESCBCEncrypt 使用PKCS7填充
func AESCBCEncrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)

	in = pkcs7Pad(in, c.BlockSize())
	out := make([]byte, len(in))

	e := cipher.NewCBCEncrypter(c, iv)
	e.CryptBlocks(out, in)

	return out
}

// AESCBCZeroPadEncrypt 使用zero填充
func AESCBCZeroPadEncrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)

	in = zeroPad(in, c.BlockSize())
	out := make([]byte, len(in))

	e := cipher.NewCBCEncrypter(c, iv)
	e.CryptBlocks(out, in)

	return out
}

// AESCBCDecrypt 去除PKCS7填充
func AESCBCDecrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)
	out := make([]byte, len(in))

	decrypted := cipher.NewCBCDecrypter(c, iv)
	decrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}

// AESCBCZeroPadDecrypt 去除zero填充
func AESCBCZeroPadDecrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)
	out := make([]byte, len(in))

	decrypted := cipher.NewCBCDecrypter(c, iv)
	decrypted.CryptBlocks(out, in)

	return zeroUnpad(out)
}

// AESECBEncrypt 使用PKCS7填充
func AESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBEncrypter(c)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// AESECBZeroPadEncrypt 使用0填充
func AESECBZeroPadEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = zeroPad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBEncrypter(c)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// AESECBDecrypt 去除PKCS7填充
func AESECBDecrypt(in, key []byte) []byte {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil
	}

	if len(in)%c.BlockSize() != 0 {
		return nil
	}

	out := make([]byte, len(in))

	decrypted := cipher2.NewECBDecrypter(c)
	decrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}

// AESDecrypt 不使用任何模式的aes解密
func AESDecrypt(in, key []byte) []byte {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil
	}

	if len(in)%c.BlockSize() != 0 {
		return nil
	}

	out := make([]byte, len(in))
	tmp := out
	for {
		if len(in) < c.BlockSize() {
			break
		}
		c.Decrypt(tmp, in)
		in = in[c.BlockSize():]
		tmp = tmp[c.BlockSize():]
	}

	return pkcs7Unpad(out)
}
