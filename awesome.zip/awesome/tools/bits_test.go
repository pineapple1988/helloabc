package tools

import (
	"fmt"
	"testing"
)

func TestRotateLeft(t *testing.T) {
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 1))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 5))
}

func TestRotateRight(t *testing.T) {
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 1))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 5))
}

func TestReverseSlice(t *testing.T) {
	fmt.Println(ReverseSlice([]byte{1, 2, 3, 4}))
}
