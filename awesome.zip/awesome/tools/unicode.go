package tools

import (
	"strconv"
	"strings"
)

// ToUnicodeString 将中文转换为unicode
// 大人 -> \u5927\u4eba
func ToUnicodeString(str string) string {
	return strings.ReplaceAll(strconv.QuoteToASCII(str), "\"", "")
}
