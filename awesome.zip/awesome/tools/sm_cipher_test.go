package tools

import (
	"awesome/tools/gmsm/sm2"
	"fmt"
	"testing"
)

func TestSm2(t *testing.T) {
	ss := `-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAEv3+t5KZeJc5KcqW0Ye83Tn3EjAc7
KHrIzCpvmNao3CwhrVC6TDzOU1zA3Afr1q6C2t69WsXOeGkC3oJYUOJRng==
-----END PUBLIC KEY-----`
	pub, _ := sm2.ReadPublicKeyFromMem([]byte(ss), nil)
	fmt.Println(pub.X)
	fmt.Println(pub.Y)
}
