package tools

import "testing"

func TestCFStringHash(t *testing.T) {
	if n := CFStringHash("fuck"); n != 34155961213 {
		t.Fatalf("测试失败, 计算值: %+v, 需要值: %+v.", n, 34155961213)
	}

	if n := CFStringHash("hello world."); n != 16577796679035647126 {
		t.Fatalf("测试失败, 计算值: %+v, 需要值: %+v.", n, uint64(16577796679035647126))
	}
}
