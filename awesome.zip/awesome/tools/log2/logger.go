package log2

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os"
)

const (
	infoPrefix  = "[INFO ] - "
	errorPrefix = "[ERROR] - "
)

var (
	logInfo  = log.New(os.Stdout, infoPrefix, log.LstdFlags|log.Lmicroseconds)
	logError = log.New(os.Stdout, errorPrefix, log.LstdFlags|log.Lmicroseconds|log.Llongfile)
)

// Info 普通日志
func Info(log string) {
	_ = logInfo.Output(2, log)
}

// Infof 普通日志
func Infof(logFmt string, logs ...interface{}) {
	_ = logInfo.Output(2, fmt.Sprintf(logFmt, logs...))
}

// Error 错误日志
func Error(log string) {
	_ = logError.Output(2, log)
}

// Errorf 错误日志
func Errorf(logFmt string, logs ...interface{}) {
	_ = logError.Output(2, fmt.Sprintf(logFmt, logs...))
}

// InfoJSON json格式的数据日志
func InfoJSON(log string) {
	var dst bytes.Buffer
	if err := json.Indent(&dst, []byte(log), "", "\t"); err != nil {
		Errorf("json.Indent err = %+v", err)
	}

	_ = logInfo.Output(2, dst.String())
}

// MyLog 日志结构体，为不同的日志添加不同前缀
type MyLog struct {
	Prefix string
}

// Info 普通日志
func (m *MyLog) Info(log string) {
	logInfo.Output(2, m.Prefix+log)
}

// Infof 普通日志
func (m *MyLog) Infof(logFmt string, logs ...interface{}) {
	logInfo.Output(2, m.Prefix+fmt.Sprintf(logFmt, logs...))
}

// InfoJSON json格式的数据日志
func (m *MyLog) InfoJSON(prefix, log string) {
	var dst bytes.Buffer

	// 这样会进行排序
	obj := &map[string]interface{}{}
	_ = json.Unmarshal([]byte(log), obj)
	objM, _ := json.Marshal(obj)
	log = string(objM)

	if err := json.Indent(&dst, []byte(log), "", "  "); err != nil {
		m.Errorf("json.Indent err = %+v", err)
	}

	m.Info(prefix + dst.String())
}

// Error 错误日志
func (m *MyLog) Error(log string) {
	logError.Output(2, m.Prefix+log)
}

// Errorf 错误日志
func (m *MyLog) Errorf(logFmt string, logs ...interface{}) {
	logError.Output(2, m.Prefix+fmt.Sprintf(logFmt, logs...))
}
