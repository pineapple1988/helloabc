package tools

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"log"
	"math/big"
)

// RSAEncrypt RSA加密, 并用PKCS1, V1.5填充
func RSAEncrypt(plain []byte, key *rsa.PublicKey) ([]byte, error) {
	MaxBlockSize := key.Size() - 11

	var buf, toEncrypt, encrypted []byte
	var err error

	toEncrypt = plain
	for {
		if len(plain) == 0 {
			break
		} else if len(plain) <= MaxBlockSize {
			toEncrypt = plain
			plain = []byte{}
		} else {
			toEncrypt = plain[:MaxBlockSize]
			plain = plain[MaxBlockSize:]
		}

		encrypted, err = rsa.EncryptPKCS1v15(rand.Reader, key, toEncrypt)
		if err != nil {
			return nil, err
		}

		buf = append(buf, encrypted...)
	}

	return buf, nil
}

// RSADecrypt RSA解密, 并用去除pkcs1.5填充
func RSADecrypt(plain []byte, key *rsa.PrivateKey) ([]byte, error) {
	MaxBlockSize := key.Size()

	var buf, toDecrypt, decrypted []byte
	var err error

	toDecrypt = plain
	for {
		if len(plain) == 0 {
			break
		} else if len(plain) <= MaxBlockSize {
			toDecrypt = plain
			plain = []byte{}
		} else {
			toDecrypt = plain[:MaxBlockSize]
			plain = plain[MaxBlockSize:]
		}

		decrypted, err = rsa.DecryptPKCS1v15(rand.Reader, key, toDecrypt)
		if err != nil {
			return nil, err
		}

		buf = append(buf, decrypted...)
	}

	return buf, nil
}

// DecodePublicKeyPEMData 从pem中解析出publicKey
func DecodePublicKeyPEMData(pemData string) *rsa.PublicKey {
	block, _ := pem.Decode([]byte(pemData))
	if block == nil || block.Type != "PUBLIC KEY" {
		log.Fatal("failed to decode PEM block containing public key")
	}
	if key, err := x509.ParsePKIXPublicKey(block.Bytes); err == nil {
		return key.(*rsa.PublicKey)
	}
	if key, err := x509.ParsePKCS1PublicKey(block.Bytes); err == nil {
		return key
	}

	return nil
}

// X509RsaEncrypt 先使用x509解析key,然后加密
func X509RsaEncrypt(plain []byte, key []byte) ([]byte, error) {
	cert, err := x509.ParseCertificate(key)
	if err != nil {
		return nil, err
	}
	pub := cert.PublicKey.(*rsa.PublicKey)

	return RSAEncrypt(plain, pub)
}

// RSAEncryptNoPadding
func RSAEncryptNoPadding(plain []byte, key *rsa.PublicKey) ([]byte, error) {
	m := new(big.Int).SetBytes(plain)
	c := new(big.Int)
	e := big.NewInt((int64)(key.E))
	c.Exp(m, e, key.N)
	return c.Bytes(), nil
}
