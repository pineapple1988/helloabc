package tools

import (
	"bytes"
	"compress/gzip"
	"errors"
	"fmt"
	"github.com/go-http-utils/headers"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
)

// DoHTTP 最原始的执行http操作
func DoHTTP(c *http.Client, method, u string, query *url.Values, header *http.Header, body []byte) ([]byte, error) {
	if query != nil {
		url0, err := url.Parse(u)
		if err != nil {
			return nil, err
		}

		query0 := url0.Query()
		// 添加query
		for key, value := range *query {
			if value == nil {
				continue
			}
			for _, item := range value {
				query0.Add(key, item)
			}
		}
		url0.RawQuery = query0.Encode()

		u = url0.String()
		if strings.HasSuffix(u, "=") {
			u = u[:len(u)-1]
		}
	}

	// 进行压缩
	if header != nil && header.Get(headers.ContentEncoding) == "gzip" {
		body, _ = GZipCompress(body)
	}

	// 生成req
	req, err := http.NewRequest(method, u, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}

	// 添加header
	if header != nil {
		req.Header = *header
	}

	// 执行http请求
	resp, err := c.Do(req)
	if err != nil {
		return nil, err
	}

	defer func() {
		_ = resp.Body.Close()
	}()

	reader := resp.Body
	if resp.Header.Get(headers.ContentEncoding) == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return nil, err
		}
	}

	// 全部读出来
	respData, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}

	ct := strings.ToUpper(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "GBK") {
		if respData, err = GBK2UTF8(respData); err != nil {
			return nil, err
		}
	}

	return respData, nil
}

// DoHTTPGet http get 操作
func DoHTTPGet(c *http.Client, u string, query *url.Values, header *http.Header) ([]byte, error) {
	return DoHTTP(c, "GET", u, query, header, nil)
}

// DoHTTPPost http post 操作
func DoHTTPPost(c *http.Client, u string, query *url.Values, header *http.Header, body []byte) ([]byte, error) {
	return DoHTTP(c, "POST", u, query, header, body)
}

// DoHTTPPostForm http post form 操作
func DoHTTPPostForm(c *http.Client, u string, query *url.Values, header *http.Header, body []byte) ([]byte, error) {
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	return DoHTTPPost(c, u, query, header, body)
}

// DoHTTPPostJSON http post json 操作
func DoHTTPPostJSON(c *http.Client, u string, query *url.Values, header *http.Header, body []byte) ([]byte, error) {
	header.Set(headers.ContentType, "application/json")
	return DoHTTPPost(c, u, query, header, body)
}

// DoHTTPReq 进行http操作
func DoHTTPReq(c *http.Client, req *http.Request) (string, error) {
	if c == nil {
		return "", errors.New("http客户端为空")
	}

	if req == nil {
		return "", errors.New("http请求为空")
	}

	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer func() {
		_ = resp.Body.Close()
	}()

	return HTTPGetBody(resp)
}

// HTTPGetBody 取http响应数据
func HTTPGetBody(resp *http.Response) (string, error) {
	// http状态码
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("提交数据响应错误, 状态码: %d", resp.StatusCode)
	}

	var err error

	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if body, err = gzip.NewReader(body); err != nil {
			return "", err
		}
	}

	data, err := ioutil.ReadAll(body)
	if err != nil {
		return "", err
	}

	// 如果有gbk编码转成utf8
	ct := strings.ToUpper(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "GBK") {
		if data, err = GBK2UTF8(data); err != nil {
			return "", err
		}
	}

	return string(data), nil
}
