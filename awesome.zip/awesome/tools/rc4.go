package tools

import "crypto/rc4"

// RC4Encrypt rc4加密实现
func RC4Encrypt(buf, key []byte) error {
	c, err := rc4.NewCipher(key)
	if err != nil {
		return err
	}

	// 先加密一些字节
	var arr []byte
	for i := 0; i < 0x271; i++ {
		arr = append(arr, byte(i))
	}

	c.XORKeyStream(arr, arr)

	// 加密内容
	c.XORKeyStream(buf, buf)

	return nil
}

// CCCryptRC4Encrypt ios CCCrypt中的RC4加密
func CCCryptRC4Encrypt(buf, key []byte) ([]byte, error) {
	c, err := rc4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	// 加密内容
	c.XORKeyStream(buf, buf)

	return buf, nil
}
