package tools

import (
	"awesome/tools/cipher2"
	"awesome/tools/gmsm/sm2"
	"awesome/tools/gmsm/sm4"
	"crypto/cipher"
	"math/big"
)

// SM2Encrypt pkcs7填充
func SM2Encrypt(in []byte, x, y string) ([]byte, error) {
	pub := &sm2.PublicKey{
		Curve: sm2.P256Sm2(),
	}
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	out, err := pub.Encrypt(in)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// SM4ECBEncrypt pkcs7填充
func SM4ECBEncrypt(in, key []byte) ([]byte, error) {
	s4, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, s4.BlockSize())
	out := make([]byte, len(in))

	c := cipher2.NewECBEncrypter(s4)
	c.CryptBlocks(out, in)

	return out, nil
}

// SM4ECBDecrypt 去除pkcs7填充
func SM4ECBDecrypt(in, key []byte) ([]byte, error) {
	s4, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	out := make([]byte, len(in))

	c := cipher2.NewECBDecrypter(s4)
	c.CryptBlocks(out, in)

	return pkcs7Unpad(out), nil
}

// SM4CBCEncrypt 使用PKCS7填充
func SM4CBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}
	in = pkcs7Pad(in, c.BlockSize())
	out := make([]byte, len(in))

	e := cipher.NewCBCEncrypter(c, iv)
	e.CryptBlocks(out, in)

	return out, nil
}

// SM4CBCDecrypt 并去除PKCS7填充
func SM4CBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}
	out := make([]byte, len(in))

	decrypted := cipher.NewCBCDecrypter(c, iv)
	decrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out), nil
}
