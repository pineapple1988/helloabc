package tools

import (
	"awesome/tools/log2"
	"encoding/json"
	"io/ioutil"
	"os"
)

// FileExist 判断文件是否存在
func FileExist(path string) bool {
	_, err := os.Stat(path)
	if err != nil && os.IsNotExist(err) {
		return false
	}
	return true
}

// LoadJSONFromFile 从文件中加载json对象
func LoadJSONFromFile(path string, v interface{}) error {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		log2.Errorf("LoadJsonFromFile ioutil.ReadFile err %+v.", err)
		return err
	}

	if err = json.Unmarshal(data, v); err != nil {
		log2.Errorf("LoadJsonFromFile json.Unmarshal err %+v.", err)
		return err
	}

	return nil
}

// SaveJSON2File 保存json对象到文件
func SaveJSON2File(path string, v interface{}) {
	infoBytes, err := json.MarshalIndent(v, "", "\t")
	if err != nil {
		log2.Errorf("SaveJson2File json.MarshalIndent err %+v.", err)
	}

	err = ioutil.WriteFile(path, infoBytes, 0644)
	if err != nil {
		log2.Errorf("SaveJson2File ioutil.WriteFile err %+v.", err)
	}
}
