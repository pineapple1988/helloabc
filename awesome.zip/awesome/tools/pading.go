package tools

import "bytes"

func pkcs7Pad(b []byte, blocksize int) []byte {
	n := blocksize - (len(b) % blocksize)
	pb := make([]byte, len(b)+n)
	copy(pb, b)
	copy(pb[len(b):], bytes.Repeat([]byte{byte(n)}, n))
	return pb
}

func pkcs7Unpad(b []byte) []byte {
	c := b[len(b)-1]
	n := int(c)
	if n == 0 || n > 0x10 {
		return b
	}
	for i := 0; i < n; i++ {
		if b[len(b)-n+i] != c {
			return b
		}
	}
	return b[:len(b)-n]
}

func zeroPad(b []byte, blocksize int) []byte {
	n := blocksize - (len(b) % blocksize)
	pb := make([]byte, len(b)+n)
	copy(pb, b)
	copy(pb[len(b):], bytes.Repeat([]byte{0}, n))
	return pb
}

func zeroUnpad(b []byte) []byte {
	total := len(b)
	count := 0
	for i := total - 1; i >= 0; i-- {
		if b[i] != 0 {
			break
		} else {
			count++
		}
	}
	return b[:total-count]
}
