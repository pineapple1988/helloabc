package ccb

type requestReq struct {
	ID            string      `json:"id"`
	Preassociated string      `json:"preassociated"`
	Params        interface{} `json:"params"`
	TxCode        string      `json:"txCode"`
	Version       string      `json:"version"`
}

type headerReq struct {
	Device       string `json:"device"`
	ClientAllVer string `json:"clientAllVer"`
	Ext          string `json:"ext"`
	Local        string `json:"local"`
	Platform     string `json:"platform"`
	Language     string `json:"language"`
	Version      string `json:"version"`
	Agent        string `json:"agent"`
}

type bodyJSON struct {
	Request []*requestReq `json:"request"`
	Header  interface{}   `json:"header"`
}

type bodyReq struct {
	MBSKEY   string `json:"MBSKEY"`
	USERID   string `json:"USERID"`
	SKEY     string `json:"SKEY"`
	BRANCHID string `json:"BRANCHID"`
	JSON     string `json:"JSON"`
}

type channelAddressRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode        string `json:"errCode"`
			ErrMessage     string `json:"errMessage"`
			CHANNELADDRESS struct {
				RCRDNUM   int    `json:"RCRD_NUM"`
				Timestamp string `json:"timestamp"`
				AddrList  []struct {
					DATACENTER    string `json:"DATACENTER"`
					RULE          string `json:"RULE"`
					ADDRESSPREFIX string `json:"ADDRESS_PREFIX"`
					CLIENTTYPE    string `json:"CLIENT_TYPE"`
					MULTICHANNEL  string `json:"MULTI_CHANNEL"`
				} `json:"addrList"`
			} `json:"CHANNELADDRESS"`
		} `json:"result"`
	} `json:"response"`
}

type baseRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode    string `json:"errCode"`
			ErrMessage string `json:"errMessage"`
		} `json:"result"`
		EResult string `json:"eresult"`
	} `json:"response"`
}

type baseResMem interface {
	getHeaderStatus() string
	getResponseEResult() string
}

func (br *baseRes) getHeaderStatus() string {
	return br.Header.Status
}

func (br *baseRes) getResponseEResult() string {
	return br.Response[0].EResult
}

type loginInfo struct {
	ParamSecurity struct {
		UserToken        string `json:"UserToken"`
		PubKey           string `json:"PubKey"`
		MN               string `json:"MN"`
		Mode             string `json:"mode"`
		PassUpFlag       string `json:"passUpFlag"`
		PassUpMessage    string `json:"passUpMessage"`
		MsgIndex         string `json:"msgIndex"`
		TimeStr          string `json:"timeStr"`
		Num              string `json:"num"`
		Tip              string `json:"tip"`
		NeedFlag         string `json:"needFlag"`
		SmsFlowNo        string `json:"smsFlowNo"`
		SECCONTROL       string `json:"SECCONTROL"`
		SECMSG           string `json:"SECMSG"`
		ACCARRAY         string `json:"ACCARRAY"`
		VerifyType       string `json:"verifyType"`
		UkeyStatus       string `json:"ukeyStatus"`
		UkeyNo           string `json:"ukeyNo"`
		UkeyCertNo       string `json:"ukeyCertNo"`
		UkeyUpdateDate   string `json:"ukeyUpdateDate"`
		UkeyExpireDate   string `json:"ukeyExpireDate"`
		APPID            string `json:"APPID"`
		LoginNum         string `json:"LoginNum"`
		LastLoginTime    string `json:"lastLoginTime"`
		PassedOnceString string `json:"passedOnceString"`
	} `json:"param_security"`
	Pversion struct {
		PversionID   string `json:"pversion_id"`
		PversionTip  string `json:"pversion_tip"`
		PversionPage string `json:"pversion_page"`
	} `json:"pversion"`
	MBCACCOUNT []struct {
		ACCNO             string `json:"ACC_NO"`
		ACCNAME           string `json:"ACC_NAME"`
		ACCTYPE           string `json:"ACC_TYPE"`
		STATUS            string `json:"STATUS"`
		ACCALIAS          string `json:"ACC_ALIAS"`
		OPENDATE          string `json:"OPEN_DATE"`
		BRANCHCODE        string `json:"BRANCH_CODE"`
		BBRANCHCODE       string `json:"BBRANCH_CODE"`
		CHANNEL           string `json:"CHANNEL"`
		ACCDESC           string `json:"ACC_DESC"`
		CPWFLAG           string `json:"CPW_FLAG"`
		FIRSTACCFLAG      string `json:"FIRST_ACC_FLAG"`
		SIGNBRANCHCODE    string `json:"SIGN_BRANCH_CODE"`
		SIGNBBRANCHCODE   string `json:"SIGN_BBRANCH_CODE"`
		BBRANCHCODEWD     string `json:"BBRANCH_CODE_WD"`
		SIGNBBRANCHCODEWD string `json:"SIGN_BBRANCH_CODE_WD"`
	} `json:"MBC_ACCOUNT"`
	MBCOTHERACCOUNT []struct {
		ACCNO                string `json:"ACC_NO"`
		ACCNAME              string `json:"ACC_NAME"`
		ACCTYPE              string `json:"ACC_TYPE"`
		STATUS               string `json:"STATUS"`
		ACCALIAS             string `json:"ACC_ALIAS"`
		OPENDATE             string `json:"OPEN_DATE"`
		BRANCHCODE           string `json:"BRANCH_CODE"`
		BBRANCHCODE          string `json:"BBRANCH_CODE"`
		CHANNEL              string `json:"CHANNEL"`
		ACCDESC              string `json:"ACC_DESC"`
		CPWFLAG              string `json:"CPW_FLAG"`
		FIRSTACCFLAG         string `json:"FIRST_ACC_FLAG"`
		SIGNBRANCHCODE       string `json:"SIGN_BRANCH_CODE"`
		SIGNBBRANCHCODE      string `json:"SIGN_BBRANCH_CODE"`
		BBRANCHCODEWD        string `json:"BBRANCH_CODE_WD"`
		SIGNBBRANCHCODEWD    string `json:"SIGN_BBRANCH_CODE_WD"`
		ChinaUnionPayAgreeNO string `json:"ChinaUnionPayAgreeNO"`
		TradeBankCode        string `json:"TradeBankCode"`
		SpecialCtrlFlag      string `json:"SpecialCtrlFlag"`
	} `json:"MBC_OTHER_ACCOUNT"`
	SetvarParams struct {
		USERID              string `json:"USERID"`
		BRANCHID            string `json:"BRANCHID"`
		SKEY                string `json:"SKEY"`
		MBSKEY              string `json:"MBSKEY"`
		MOBILENO            string `json:"MOBILENO"`
		RANDOMTRANS         string `json:"RANDOMTRANS"`
		MONTHSTART          string `json:"MONTHSTART"`
		MONTHEND            string `json:"MONTHEND"`
		BONUS               string `json:"BONUS"`
		SPDRAW              string `json:"SPDRAW"`
		CONTROLBONDSHOWFLAG string `json:"CONTROLBONDSHOWFLAG"`
		GAME                string `json:"GAME"`
		SHORTCUTFLAG        string `json:"SHORTCUTFLAG"`
		INVESTFLAG          string `json:"INVESTFLAG"`
		FINANCINGFLAG       string `json:"FINANCINGFLAG"`
		FBONUS              string `json:"FBONUS"`
		SCRATCH             string `json:"SCRATCH"`
		FCHARGER            string `json:"FCHARGER"`
		LOGINMENUF          string `json:"LOGIN_MENUF"`
		NEWBILLSWITCH       string `json:"NEW_BILLSWITCH"`
		USERBRANCHID        string `json:"USER_BRANCHID"`
		SHOWSHAKETRANS      string `json:"SHOWSHAKETRANS"`
		MARKETTITILE        string `json:"MARKET_TITILE"`
		INSUFLAG            string `json:"INSUFLAG"`
		USERNAME            string `json:"USERNAME"`
		CARDTYPE            string `json:"CARD_TYPE"`
		CARDID              string `json:"CARD_ID"`
		SGNINST             string `json:"SGN_INST"`
		WhiteCustType       string `json:"whiteCustType"`
		VersionType         string `json:"versionType"`
		NotVerifyVersion    string `json:"notVerifyVersion"`
		HBSESSIONSWITCH     string `json:"HB_SESSION_SWITCH"`
		NETBANKHEARTBEAT    string `json:"NETBANK_HEARTBEAT"`
		MBSHEARTBEAT        string `json:"MBS_HEARTBEAT"`
		MAXIDELTIME         string `json:"MAX_IDEL_TIME"`
		PostAddress         string `json:"postAddress"`
		PostCode            string `json:"postCode"`
		PlatformCustNo      string `json:"platformCust_No"`
		ECIFCustNo          string `json:"ECIFCust_No"`
		PlatformFlag        string `json:"platformFlag"`
		ESmsFlag            string `json:"eSmsFlag"`
		IDCARD15TO18        string `json:"IDCARD15TO18"`
		PlatformFlag2       string `json:"platformFlag2"`
		FingerprintSwitch   string `json:"FingerprintSwitch"`
		ECUACVoiceEffect    string `json:"ECUACVoiceEffect"`
		VoiceprintSwitch    string `json:"VoiceprintSwitch"`
		FingerprintOther    string `json:"FingerprintOther"`
		VoiceprintEverUse   string `json:"VoiceprintEverUse"`
		BindFlag            string `json:"bindFlag"`
		FingerLogin         string `json:"fingerLogin"`
		PlatformFlag3       string `json:"platformFlag3"`
		CHANNELADDRESS      struct {
			RCRDNUM   int    `json:"RCRD_NUM"`
			Timestamp string `json:"timestamp"`
			AddrList  []struct {
				DATACENTER    string `json:"DATACENTER"`
				RULE          string `json:"RULE"`
				ADDRESSPREFIX string `json:"ADDRESS_PREFIX"`
				CLIENTTYPE    string `json:"CLIENT_TYPE"`
				MULTICHANNEL  string `json:"MULTI_CHANNEL"`
			} `json:"addrList"`
		} `json:"CHANNELADDRESS"`
		LZF2DCode       string `json:"LZF_2DCode"`
		LZFLingQAcct    string `json:"LZF_LingQAcct"`
		Beta40Cust      string `json:"Beta40Cust"`
		ThemeNo         string `json:"ThemeNo"`
		ThemeColor      string `json:"ThemeColor"`
		BiologyVerifySw struct {
		} `json:"biologyVerifySw"`
		Acc4HalfBind        string `json:"Acc4HalfBind"`
		IsGreetingsNameShow string `json:"IsGreetingsNameShow"`
		CustomerBitmap      string `json:"CustomerBitmap"`
		TheSignFlag         string `json:"theSignFlag"`
		SignWhiteFlag       string `json:"SignWhiteFlag"`
		MarketingFlag       struct {
		} `json:"marketingFlag"`
		EncEcifNoName      string `json:"encEcifNoName"`
		CurrentDateTime    string `json:"CurrentDateTime"`
		CCBEmployeeFlag    string `json:"CCBEmployeeFlag"`
		OtherBankWhiteFlag string `json:"OtherBankWhiteFlag"`
		CCBEmployeeNo      string `json:"CCBEmployeeNo"`
		NewBitmap          string `json:"NewBitmap"`
		AntiLaunderSwitch  string `json:"AntiLaunderSwitch"`
		Gender             string `json:"Gender"`
		HuaWeiMateXStr     string `json:"HuaWeiMateXStr"`
		ToUpdateA6ID       string `json:"toUpdateA6ID"`
		UsingA6ID          string `json:"usingA6ID"`
		CustOpenDate       string `json:"Cust_OpenDate"`
		OtherBitmap        string `json:"OtherBitmap"`
	} `json:"setvar_params"`
}

type loginRes struct {
	baseRes
	loginInfo
}

type bindTokenLoginRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		ErrCode    string `json:"errCode"`
		ErrMessage string `json:"errMessage"`
		TxCode     string `json:"txCode"`
		ID         string `json:"id"`
		Status     string `json:"status"`
		Result     struct {
			ErrCode    string `json:"errCode"`
			ErrMessage string `json:"errMessage"`
			AlertTips  string `json:"alert_tips"`
			loginInfo
		} `json:"result"`
		EResult string `json:"eresult"`
	} `json:"response"`
}

type encDatRes struct {
	EncDat string `json:"encDat"`
}

type reqURLRes struct {
	Success       string `json:"SUCCESS"`
	MTTC          string `json:"MTTC"`
	TxCode        string `json:"TXCODE"`
	SysEvtTraceID string `json:"SYS_EVT_TRACE_ID"`
	ReqURL        string `json:"REQ_URL"`
}

type searchBankRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode        string `json:"errCode"`
			ErrMessage     string `json:"errMessage"`
			RegionFlag     string `json:"regionFlag"`
			InAccType      string `json:"inAccType"`
			BankName       string `json:"bankName"`
			BankCode       string `json:"bankCode"`
			InMobileStatus string `json:"inMobileStatus"`
			InBranchCode   string `json:"inBranchCode"`
			CCBInsID       string `json:"CCBIns_ID"`
		} `json:"result"`
	} `json:"response"`
}

type transferSmsCodeRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode          string `json:"errCode"`
			ErrMessage       string `json:"errMessage"`
			Fee              string `json:"fee"`
			FType            string `json:"fType"`
			InAccBbranchCode string `json:"inAccBbranchCode"`
			InAccBranchDesc  string `json:"inAccBranchDesc"`
			ReserveSign      string `json:"reserveSign"`
			Percent          string `json:"percent"`
			AccCash          string `json:"accCash"`
			CurFlag          string `json:"curFlag"`
			CardNum          string `json:"cardNum"`
			SecFlow          string `json:"secFlow"`
			SecFlag          string `json:"secFlag"`
			IsRepeatPayTip   string `json:"isRepeatPayTip"`
			RepeatTip        string `json:"repeatTip"`
			SmsTitle         string `json:"smsTitle"`
			Msgindex         string `json:"msgindex"`
			MaxTime          string `json:"maxTime"`
			Resentcount      string `json:"resentcount"`
			RmtPstcrpt       string `json:"rmtPstcrpt"`
			SafeType         string `json:"safeType"`
			SafeSignT        string `json:"safeSignT"`
			SafeContent      string `json:"safeContent"`
			AcmDrwAmt        string `json:"acmDrwAmt"`
			DayAcDN          string `json:"dayAcDN"`
			LimitTipFlag     string `json:"limitTipFlag"`
			LimitTipStr      string `json:"limitTipStr"`
			LimitOneWTipFlag string `json:"limitOneWTipFlag"`
			InAccNo434       string `json:"inAccNo434"`
			UUID             string `json:"UUID"`
			PopCtl           string `json:"pop_ctl"`
			LimitOneWTipStr  string `json:"limitOneWTipStr"`
		} `json:"result"`
	} `json:"response"`
}

type transferRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode            string `json:"errCode"`
			ErrMessage         string `json:"errMessage"`
			CreditNo           string `json:"creditNo"`
			InAccName          string `json:"inAccName"`
			Amount             string `json:"amount"`
			InAccNo            string `json:"inAccNo"`
			AccNo              string `json:"accNo"`
			AccName            string `json:"accName"`
			BankName           string `json:"bankName"`
			OutAccAfterBalance string `json:"outAccAfterBalance"`
			OriTransactionSN   string `json:"ori_transaction_sn"`
			EvtTraceIDEc       string `json:"EVT_TRACE_ID_EC"`
			RmtStCd            string `json:"Rmt_StCd"`
			BsnRctCD           string `json:"BsnRct_CD"`
			BsnRctInf          string `json:"BsnRct_Inf"`
			InAccNo434         string `json:"inAccNo434"`
			SmsNotifyFlag      string `json:"smsNotifyFlag"`
			Safe               struct {
				TxCode   string `json:"txCode"`
				SafeCode string `json:"safeCode"`
				SafeData struct {
					ShowPassword      string `json:"showPassword"`
					ErrCode           string `json:"errCode"`
					ErrMsg            string `json:"errMsg"`
					VoicePrint        string `json:"voicePrint"`
					FaceFeature       string `json:"faceFeature"`
					VerifyOrder       string `json:"verifyOrder"`
					NeedImageValidate string `json:"needImageValidate"`
					Title             string `json:"title"`
				} `json:"safeData"`
			} `json:"safe"`
		} `json:"result"`
	} `json:"response"`
}

type balanceRes struct {
	Success   string `json:"SUCCESS"`
	ErrorCode string `json:"ERRORCODE"`
	ErrorMsg  string `json:"ERRORMSG"`
	AcBa      string `json:"AcBa"`
	AvlBal    string `json:"Avl_Bal"`
}

type detailsInfo struct {
	CreditID   string `json:"Crdeit_Id"`
	Amount     string `json:"Amount"`
	TaxAmount  string `json:"Tax_Amount"`
	TransPlace string `json:"Transplace"`
	DeRemark1  string `json:"De_Remark1"`
	DeRemark2  string `json:"De_Remark2"`
	PayName    string `json:"PayName"`
	OccurDate  string `json:"Occur_Date"`
	KeepAmt    string `json:"KeepAmt"`
	CurCode    string `json:"CurCode"`
	RecAccount string `json:"Rec_Account"`
	TransDate  string `json:"Transdate"`
	TransTime  string `json:"Transtime"`
	Remark     string `json:"Remark"`
	TransSign  string `json:"TransSign"`
}

type detailsRes struct {
	Success      string        `json:"SUCCESS"`
	ErrorCode    string        `json:"ERRORCODE"`
	ErrorMsg     string        `json:"ERRORMSG"`
	DebitAmount  string        `json:"Debit_Amount"`
	CreditAmount string        `json:"Credit_Amount"`
	CurrentPage  string        `json:"Current_Page"`
	TotalPage    string        `json:"TPage"`
	List         []detailsInfo `json:"LIST"`
}

type encryptReq struct {
	MBSKEY   string `json:"MBSKEY"`
	JSON     string `json:"JSON"`
	USERID   string `json:"USERID"`
	SKEY     string `json:"SKEY"`
	BRANCHID string `json:"BRANCHID"`
	DataDic  string `json:"DataDic"`
}

// TransferResultInfo 转帐返回信息, 用于查询
type TransferResultInfo struct {
	CreditNO         string `json:"creditNo"`
	OriTransactionSN string `json:"oriTransactionSN"`
	EvtTraceIDEC     string `json:"evtTraceIdEc"`
	RcvPymtPsAccNO   string `json:"rcvPymtPsAccNo"` // 收款卡号
	ChnlCustNO       string `json:"chnlCustNo"`     // 身份证号
	PyPsnAccNO       string `json:"pyPsnAccNo"`     // 卡号
	RmtAmt           string `json:"rmtAmt"`
	DataDic          string `json:"dataDic"`
	TradeNo          string `json:"tradeNo"`
}

type queryTransferRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ChnlCustNO      string `json:"CHNL_CUST_NO"`     // "370323199803203027",
			EvtTraceIDEC    string `json:"EVT_TRACE_ID_EC"`  // "1010055241577138259018394",
			PyClrgBsnTPCD   string `json:"Py_Clrg_Bsn_TpCd"` //"",
			RmtCcyCD        string `json:"Rmt_CcyCd"`        // 156",
			RmtAmt          string `json:"Rmt_Amt"`          // "0.01",
			AREfDt          string `json:"AR_EfDt"`          // "20191224",
			PyPsnNm         string `json:"Py_Psn_Nm"`        // "宋树雨",
			PyPsnAccNO      string `json:"Py_Psn_AccNo"`     // "6217002340037369941",
			PyPsDpBkNm      string `json:"PyPsDpBk_Nm"`      // "中国建设银行济南长清支行大学科技园分理处",
			PyPsDpBkBrNO    string `json:"PyPsDpBk_BrNo"`    // "105451001409",
			RPPDBnkBrNO     string `json:"RPPDBnk_BrNo"`     // "103100000026",
			RcvPymtPsFullNm string `json:"RcvPymtPs_FullNm"` // "尤康",
			RcvPymtPsAccNO  string `json:"RcvPymtPs_AccNo"`  // "6230520460026137277",
			RPPDBnkNm       string `json:"RPPDBnk_Nm"`       // "中国农业银行资金清算中心",
			RcvbHdCg        string `json:"Rcvb_HdCg"`        // "0",
			FeeAccNO        string `json:"Fee_AccNo"`        // "",
			Rmrk            string `json:"Rmrk"`             // "跨行转出",
			TRNSTCD         string `json:"TRN_ST_CD"`        // "00",
			RmtStCD         string `json:"Rmt_StCd"`         // "ZF05",
			BsnRctInf       string `json:"BsnRct_Inf"`       // "账号、户名不符",
			BsnRctCD        string `json:"BsnRct_CD"`        // "PR09"
		} `json:"result"`
	} `json:"response"`
}
