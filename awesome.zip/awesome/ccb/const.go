package ccb

const (
	resCodeSuccess      = "01"
	appVersion          = "5.01"
	clientAllVer        = "5.0.1.001#20210303"
	mobileClientVersion = "5.0.1.001.VC20210303#202103030000"
	techniquVersion     = "5.01001"
	secVersion          = "10.0.0"
	versionDate         = "20210303"
	ua                  = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2"
	password3DesKey     = "AwCfw7RhNN50fTb89lagn34Z"
	password3DesIV      = "37xmtqlp"
	post3DesKey         = "tGpVe0Hr3vq6FYHNyciHLf28"
	post3DesIV          = "dU2Uyxgv"
	decryptAesKey       = "4xAsNN2fyJCzi4Ks" // 4xAsNN2fyJCzi4Ksf6WHPOcT 太长了 只需要128位
)

const (
	urlCCBNewClient     = "https://mobile.ccb.com/cmccb/servlet/ccbNewClient"
	urlB2CMainPlat00MB  = "https://ibsbjstar.ccb.com.cn/CCBIS/B2CMainPlat_00_MB"
	urlMch5ccbNewClient = "https://mobile.ccb.com/MCH5/cmccb/servlet/ccbNewClient"
	urlB2CMainPlat07MB  = "https://ibsbjstar.ccb.com.cn/CCBIS/B2CMainPlat_07_MB"
)
