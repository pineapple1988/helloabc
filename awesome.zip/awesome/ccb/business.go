package ccb

import (
	"awesome/tools"
	"compress/gzip"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/go-http-utils/headers"
)

// ErrOperationTimeout 操作超时
var ErrOperationTimeout = errors.New("操作超时")

// ErrOperationError 操作出现错误
var ErrOperationError = errors.New("操作出现错误")

// ErrSessionTimeout 会话过期，需要重新登陆
var ErrSessionTimeout = errors.New("会话过期，需要重新登陆")

// ErrUnmarshalResponseData 反序列化返回数据出现错误
var ErrUnmarshalResponseData = errors.New("反序列化返回数据出现错误")

// ErrEncRequestData 加密请求数据出现错误
var ErrEncRequestData = errors.New("加密请求数据出现错误")

var comHeaderReq = headerReq{
	Device:       "iPhone",
	ClientAllVer: clientAllVer,
	Ext:          "",
	Local:        "ZH_cn",
	Platform:     "iOS",
	Language:     "CN",
	Version:      "1.05",
	Agent:        "mbp1.0",
}

func comRequestReq(params interface{}, txCode string) requestReq {
	return requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        params,
		TxCode:        txCode,
		Version:       "1.0.0",
	}
}

func (b *Bank) getMbcInfo(userToken string) (string, string, string) {
	strScale := tools.Scale(b.HardwareInfo.Model)
	fScale, _ := strconv.ParseFloat(strScale, 32)

	scale := int(fScale)
	width := tools.ScreenWidthPt(b.HardwareInfo.Model)
	heignt := tools.ScreenHeightPt(b.HardwareInfo.Model)
	screenSize := fmt.Sprintf("%d*%d", width*scale, (heignt-20)*scale)

	// MBCCB/*//*/00000000000000/*/jj的 iPhone/*/iOS/*/13.1.3/*/iPhone/*/750*1294/*/5472E59D-86CD-44C8-A99D-81650D877CB0/*//*//*/0.000000/*/0.000000/*/0
	mbcUserInfo := fmt.Sprintf(`MBCCB/*/%s/*/00000000000000/*/%s/*/%s/*/%s/*/%s/*/%s/*/%s/*//*//*/0.000000/*/0.000000/*/0`,
		userToken,
		b.HardwareInfo.OwnerName,
		"iOS",
		b.HardwareInfo.SystemVersion,
		"iPhone",
		screenSize,
		b.HardwareInfo.IDFV,
	)
	mbcUserInfo = base64.StdEncoding.EncodeToString([]byte(mbcUserInfo))

	// 建行手机银行
	// %E5%BB%BA%E8%A1%8C%E6%89%8B%E6%9C%BA%E9%93%B6%E8%A1%8C/20201228 CFNetwork/1107.1 Darwin/19.0.0
	userAgent := "%E5%BB%BA%E8%A1%8C%E6%89%8B%E6%9C%BA%E9%93%B6%E8%A1%8C/" + versionDate + " CFNetwork/1107.1" + tools.KernelVersion(b.HardwareInfo.SystemVersion)

	// MBCCCB/iPhone/iOS13.1.3/4.42/1.01/5472E59D-86CD-44C8-A99D-81650D877CB0/chinamworld/750*1294
	mbcUserAgent := fmt.Sprintf(`MBCCCB/%s/iOS%s/%s/%s/%s/%s/%s`,
		"iPhone", b.HardwareInfo.SystemVersion, appVersion, "1.01", b.HardwareInfo.IDFV, "chinamworld", screenSize)

	return userAgent, mbcUserAgent, mbcUserInfo
}

func doHTTP(c *http.Client, req *http.Request) (string, error) {
	// 执行http请求
	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer func() {
		_ = resp.Body.Close()
	}()

	reader := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return "", err
		}
	}

	// 全部读出来
	body, err := ioutil.ReadAll(reader)
	if err != nil {
		return "", err
	}

	ct := strings.ToUpper(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "GBK") {
		if body, err = tools.GBK2UTF8(body); err != nil {
			return "", err
		}
	}

	return string(body), nil
}

func (b *Bank) getCookie(name string) string {
	u, err := url.Parse(fmt.Sprintf("https://mobile.ccb.com/%s/cmccb/servlet/ccbNewClient", b.MultiChannel))
	if err != nil {
		return ""
	}

	cookies := b.c.Jar.Cookies(u)
	var v string
	for _, cookie := range cookies {
		if cookie.Name == name {
			if v, err = url.QueryUnescape(cookie.Value); err != nil {
				return ""
			} else {
				return v
			}
		}
	}

	return ""
}

func (b *Bank) updateMBSKey() {
	key := b.getCookie("CCBIBS1")
	if key != "" {
		b.MbsKey = key
		// b.logger.Infof("UpdateMSBKey: %+v.", key)
	}
}

func (b *Bank) postHTTPDataAndDecrypt(data string, res interface{}) (string, error) {
	body, err := b.postHTTPData(data, res)
	if err != nil {
		return body, err
	}

	base := res.(baseResMem)
	if base.getHeaderStatus() != resCodeSuccess {
		b.logger.Errorf("http 请求失败返回 baseRes=%+v.", base)
		return body, nil
	}

	if base.getResponseEResult() == "" {
		return body, nil
	}

	// 有数据,需要解密
	eResult, err := base64.StdEncoding.DecodeString(base.getResponseEResult())
	if err != nil {
		b.logger.Errorf("postHTTPDataAndDecrypt base64.StdEncoding.DecodeString err EResult=%+v", base.getResponseEResult())
		return "", errors.New("postHTTPDataAndDecrypt base64.StdEncoding.DecodeString err")
	}

	result := tools.AESDecrypt(eResult, []byte(decryptAesKey))
	if err = json.Unmarshal(result, res); err != nil {
		b.logger.Errorf("postHTTPDataAndDecrypt 反序列化响应数据错误, body: %s, err: %+v.", body, err)
		return "", ErrUnmarshalResponseData
	}

	return string(result), nil
}

func (b *Bank) postHTTPData(data string, res interface{}) (string, error) {
	u := fmt.Sprintf("https://mobile.ccb.com/%s/cmccb/servlet/ccbNewClient", b.MultiChannel)
	return b.postHTTPDataEx(u, data, res)
}

func (b *Bank) postHTTPDataEx(url, data string, res interface{}) (string, error) {
	req, err := http.NewRequest("POST", url, strings.NewReader(data))
	if err != nil {
		b.logger.Errorf("创建http请求错误: %+v.", err)
		return "", err
	}

	userAgent, mbcUserAgent, mbcUserInfo := b.getMbcInfo(b.UserToken)

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate, br")
	req.Header.Add(headers.UserAgent, userAgent)
	req.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")

	// Add, Set会修正
	req.Header["clientAllVer"] = []string{clientAllVer}
	req.Header["MBC-User-Agent"] = []string{mbcUserAgent}
	req.Header["MBC-User-Info"] = []string{mbcUserInfo}
	req.Header["UA"] = []string{"IPHONE"}
	req.Header["UserToken"] = []string{b.UserToken}

	body, err := doHTTP(b.c, req)
	if err != nil {
		b.logger.Errorf("http操作错误: %+v.", err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", ErrOperationTimeout
		}

		if strings.Contains(err.Error(), "701") {
			b.logger.Errorf("http操作701, url: %s, 数据: %s.", url, data)
			return "", ErrSessionTimeout
		}

		return "", ErrOperationError
	}

	b.updateMBSKey()

	if strings.Contains(body, "Error 404--Not Found") {
		b.logger.Errorf("http请求响应404: %s.", body)
		return "", ErrOperationError
	}

	if res != nil {
		if err = json.Unmarshal([]byte(body), res); err != nil {
			b.logger.Errorf("反序列化响应数据错误, body: %s, err: %+v.", body, err)
			return "", ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (b *Bank) getHTTPData(path, data string, res interface{}, retEncData bool) (string, error) {
	if path == "" {
		return "", errors.New("url参数错误, 请重新登录")
	}

	reqData, err := jsonEncrypt(data)
	if err != nil {
		b.logger.Errorf("加密请求数据错误, data: %s, err: %+v.", data, err)
		return "", errors.New("getHTTPData postEncrypt 加密错误")
	}

	query := url.Values{}
	query.Set("SYS_CODE", "0760")
	query.Set("MP_CODE", "02")
	query.Set("SEC_VERSION", secVersion)
	query.Set("APP_NAME", "com.ccb.ccbDemo")
	query.Set("SKEY", b.SkeyB2C)
	query.Set("GLOBAL_SKEY", b.SKey)
	query.Set("ccbParam", reqData)
	if retEncData {
		query.Set("retEncDat", "1")
	}
	path = fmt.Sprintf("%s?%s", path, query.Encode())

	req, err := http.NewRequest("GET", path, nil)
	if err != nil {
		b.logger.Errorf("创建http请求错误: %+v.", err)
		return "", errors.New("getHTTPData 创建http请求错误")
	}

	_, mbcUserAgent, _ := b.getMbcInfo("")
	req.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.UserAgent, ua)

	req.Header["MBC-User-Agent"] = []string{mbcUserAgent}
	req.Header["UA"] = []string{ua}

	body, err := doHTTP(b.c, req)
	if err != nil {
		b.logger.Errorf("http操作错误: %+v.", err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", ErrOperationTimeout
		}

		return "", ErrOperationError
	}

	b.logger.Infof("httpGet操作成功, \r\ndata: %s, \r\nbody: %s.", data, body)

	if strings.Contains(body, "重新登录") {
		return "", ErrSessionTimeout
	}
	if retEncData {
		retEnc := &encDatRes{}
		if err = json.Unmarshal([]byte(body), retEnc); err != nil {
			b.logger.Errorf("反序列化响应数据错误111: %+v.", err)
			return "", ErrUnmarshalResponseData
		}
		// 解密
		encDat, _ := base64.StdEncoding.DecodeString(retEnc.EncDat)
		if encDat != nil {
			decDat := tools.AESDecrypt(encDat, []byte(decryptAesKey))
			if decDat != nil {
				body = string(decDat)
			}
		}
	}
	if res != nil {
		if err = json.Unmarshal([]byte(body), res); err != nil {
			b.logger.Errorf("反序列化响应数据错误: %+v.", err)
			return "", ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (b *Bank) queryChannelAddress() (*channelAddressRes, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{}
	if b.UserToken != "" {
		reqParams["UserToken"] = b.UserToken
	} else {
		reqParams["UserDN"] = b.Account
	}

	request := comRequestReq(reqParams, "XA0001")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := url.Values{}
	reqBody.Set("MBSKEY", "")
	reqBody.Set("USERID", "")
	reqBody.Set("SKEY", "")
	reqBody.Set("BRANCHID", "")
	reqBody.Set("JSON", string(jsonStr))

	res := channelAddressRes{}
	body, err := b.postHTTPDataEx(urlCCBNewClient, reqBody.Encode(), &res)
	if err != nil {
		return nil, err
	}
	b.logger.Infof("queryChannelAddress请求成功, \r\ndata: %s, \r\nbody: %s.", reqBody.Encode(), body)

	return &res, nil
}

// 第一次登录绑定设备
func (b *Bank) firstLogin(smsCode string) (*loginRes, error) {
	reqHeader := comHeaderReq
	reqParams := map[string]string{
		"MBSKEY":          "",
		"USERID":          "",
		"techniquVersion": techniquVersion,
		"DN":              b.Account,
		"SKEY":            "",
		"BRANCHID":        "",
		"SECCODE":         smsCode,
		"PASSWORD":        fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(b.LoginPwd)),
	}
	request := comRequestReq(reqParams, "Q70021")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   "",
		USERID:   "",
		SKEY:     "",
		BRANCHID: "010231000",
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("firstLogin JSON加密错误: %+v.", err)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "Q70021")

	res := loginRes{}
	body, err := b.postHTTPDataAndDecrypt(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	b.logger.Infof("fistLogin请求成功, \r\ndata: %s, \r\nbody: %s.", string(jsonBuff), body)
	return &res, nil
}

func (b *Bank) verifyPayPassword(smsCode string) (*loginRes, error) {
	reqHeader := comHeaderReq
	reqParams := map[string]string{
		"techniquVersion": techniquVersion,
		"DN":              b.Account,
		"ACCOUNT":         b.AccNo,
		// 这个密码应该是和登陆时加密完成一样的，这里就不去理会了
		"ACCPASSWORD": fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(b.PayPwd)),
		"SECCODE":     smsCode,
		"PASSWORD":    fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(b.LoginPwd)),
	}
	request := comRequestReq(reqParams, "Q70021")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   b.MbsKey,
		USERID:   b.UserID,
		SKEY:     "",
		BRANCHID: "010231000",
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("verifyPayPassword JSON加密错误, jsonBuff: %+v", jsonBuff)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "Q70021")

	res := loginRes{}
	body, err := b.postHTTPDataAndDecrypt(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}
	b.logger.Infof("verifyPayPassword请求成功, \r\ndata: %s, \r\nbody: %s.", string(jsonBuff), body)

	return &res, nil
}

func (b *Bank) getReqURL() (*reqURLRes, error) {
	values := url.Values{}
	values.Set("CRDT_NO", b.UserID)
	values.Set("BRANCHID", b.BranchCode)
	values.Set("MTTC", "")
	values.Set("TX_TIME", tools.TimeFmtEx0())
	values.Set("Cfm_St_Ind", "1")
	values.Set("TXCODE", "SJ1100")
	values.Set("DeviceInfo", "1#"+b.HardwareInfo.SystemVersion+"#"+tools.PhoneName(b.HardwareInfo.Model))
	values.Set("MobileClientVersion", mobileClientVersion)
	values.Set("PT_STYLE", "3")
	values.Set("PT_LANGUAGE", "CN")
	values.Set("USERID", b.UserID)
	values.Set("TXN_TERM_INF", b.HardwareInfo.IDFV+"##")
	values.Set("CCB_IBSVersion", "V6")

	res := reqURLRes{}
	if _, err := b.getHTTPData(urlB2CMainPlat00MB, values.Encode(), &res, false); err != nil {
		return nil, err
	}

	return &res, nil
}

// 已绑定设备登录，需要userID, userToken
func (b *Bank) bindTokenLogin() (*bindTokenLoginRes, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{
		"UserToken":       b.UserToken,
		"BRANCHID":        "",
		"MBSKEY":          "",
		"voiceStr":        "",
		"valCode":         "",
		"SKEY":            "",
		"techniquVersion": techniquVersion,
		"MOBILE":          b.Account,
		"USERID":          b.UserID,
		"flowNo":          "",
		"PWD":             fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(b.LoginPwd)),
	}

	request := comRequestReq(reqParams, "QU7020")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   "",
		USERID:   b.UserID,
		SKEY:     "",
		BRANCHID: "010231000",
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("bindTokenLogin JSON加密错误： %+v.", err)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "QU7020")

	res := bindTokenLoginRes{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	// 需要解密
	if res.Response[0].EResult != "" {
		eresult, e1 := base64.StdEncoding.DecodeString(res.Response[0].EResult)
		if e1 != nil {
			b.logger.Errorf("bindTokenLogin base64.StdEncoding.DecodeString err EResult=%+v", res.Response[0].EResult)
			return nil, errors.New("bindTokenLogin base64.StdEncoding.DecodeString err")
		}

		result := tools.AESDecrypt(eresult, []byte(decryptAesKey))
		if e2 := json.Unmarshal(result, &res.Response[0].Result); e2 != nil {
			b.logger.Errorf("bindTokenLogin 反序列化响应数据错误, body: %s, err: %+v.", body, err)
			return nil, ErrUnmarshalResponseData
		}
		b.logger.Infof("bindTokenLogin 请求成功, eresult: %s", string(result))
	}

	b.logger.Infof("bindTokenLogin 请求成功, \r\ndata: %s, \r\nbody: %s.", string(jsonBuff), body)

	return &res, nil
}

// 网银登录成功后发送第一个数据包，获取sKey
func (b *Bank) getSkey() error {
	values := url.Values{}

	values.Add("Cfm_St_Ind", "1")
	values.Add("BRANCHID", b.BranchCode)
	values.Add("MTTC", "")
	values.Add("TX_TIME", tools.TimeFmtEx0())
	values.Add("TXCODE", "SJ1001")
	values.Add("MOBIL_NO", b.Account)
	values.Add("DeviceInfo", "1#"+b.HardwareInfo.SystemVersion+"#"+tools.PhoneName(b.HardwareInfo.Model))
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("PT_STYLE", "3")
	values.Add("ECTIP_SKEY", b.SKey)
	values.Add("USERID", b.UserID)
	values.Add("PT_LANGUAGE", "CN")
	values.Add("TXN_TERM_INF", b.HardwareInfo.IDFV+"##")
	values.Add("CCB_IBSVersion", "V6")

	res := map[string]string{}
	if _, err := b.getHTTPData(b.ReqURL, values.Encode(), &res, true); err != nil {
		return err
	}

	if res["SUCCESS"] != "true" {
		b.logger.Errorf("getSkey返回完成状态为假，code: %+v, msg: %+v.",
			res["ERRORCODE"], res["ERRORMSG"])

		return errors.New(res["ERRORMSG"])
	}

	b.SkeyB2C = res["SKEY"]
	b.logger.Infof("getSkey成功, SKEY: %+v.", b.SkeyB2C)

	return nil
}

// 查询账户余额
func (b *Bank) getBalance() (*balanceRes, error) {
	values := url.Values{}
	date := tools.TimeFmt()
	dateTM := date[len(date)-6:]
	dateDT := date[:len(date)-6]
	values.Add("TXN_INSID", b.BranchCode)
	values.Add("BRANCHID", b.BranchCode)
	values.Add("MTTC", "")
	values.Add("PT_STYLE", "3")
	values.Add("TXN_TERM_INF", b.HardwareInfo.IDFV+"##")
	values.Add("LNG_ID", "zh-cn")
	values.Add("TXCODE", "SJ5803")
	values.Add("CCB_IBSVersion", "V6")
	values.Add("TXN_ITT_CHNL_ID", "0006")
	values.Add("PT_LANGUAGE", "CN")
	values.Add("MULTI_TENANCY_ID", "CN000")
	values.Add("CshEx_Cd", "1")
	values.Add("TXN_TM", dateTM) // 这个是时间的时分秒
	values.Add("Cfm_St_Ind", "1")
	values.Add("TXN_ITT_CHNL_CGY", "10030006")
	values.Add("TXN_DT", dateDT) // 这个是时间的年月日
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("CcyCd", "156")
	values.Add("USERID", b.UserID)
	values.Add("DbCrd_CardNo", b.AccNo)
	values.Add("TX_TIME", tools.TimeFmtEx0())
	values.Add("DeviceInfo", "1#"+b.HardwareInfo.SystemVersion+"#"+b.HardwareInfo.OwnerName)
	values.Add("TXN_STFF_ID", "0")

	res := balanceRes{}
	if _, err := b.getHTTPData(b.ReqURL, values.Encode(), &res, false); err != nil {
		return nil, err
	}

	return &res, nil
}

// 账单查询
func (b *Bank) getDetails(startDate, endDate string, page int) (*detailsRes, error) {
	if page < 1 {
		page = 1
	}

	values := url.Values{}
	values.Add("Id_Type", "01")
	values.Add("Curcode", "01")
	values.Add("Branch_Code", b.BBranchCode)
	values.Add("BRANCHID", b.BranchCode)
	values.Add("MTTC", "")
	values.Add("Account_No", b.AccNo)
	values.Add("PT_STYLE", "3")
	values.Add("TXN_TERM_INF", b.HardwareInfo.IDFV+"##")
	values.Add("Acc_Sign", "0")
	values.Add("DiyFlag", "0")
	values.Add("TXCODE", "SJ3102")
	values.Add("CCB_IBSVersion", "V6")
	values.Add("PT_LANGUAGE", "CN")
	values.Add("Cust_No", b.UserID)
	values.Add("Start_Date", startDate)
	values.Add("End_Date", endDate)
	values.Add("Id_Num", b.UserID)
	values.Add("Depositno", "")
	values.Add("Cfm_St_Ind", "1")
	values.Add("USERID", b.UserID)
	values.Add("OutCash", "0")
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("Sequenceno", "0")
	values.Add("Cust_Name", url.QueryEscape(b.AccName))
	values.Add("TX_TIME", tools.TimeFmtEx0())
	values.Add("Acc_Type", b.AccType)
	values.Add("Current_Page", fmt.Sprintf("%d", page))
	values.Add("DeviceInfo", "1#"+b.HardwareInfo.SystemVersion+"#"+b.HardwareInfo.OwnerName)
	values.Add("Pdt_Code", "0101")

	res := detailsRes{}
	if _, err := b.getHTTPData(b.ReqURL, values.Encode(), &res, false); err != nil {
		return nil, err
	}
	return &res, nil
}

// 转账记录
func (b *Bank) getTransferDetails(startDate, endDate string, page int) (map[string]interface{}, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{
		"Rsrv_Bmp_ECD":    "",
		"RcvPymtPs_Nm":    "",
		"Bmp_ECD":         "",
		"StDt":            startDate,
		"Cst_ID":          b.CustNo,
		"REC_IN_PAGE":     "10",
		"RcvPymtPs_AccNo": "",
		"EdDt":            endDate,
		"PAGE_JUMP":       "1",
	}

	request := comRequestReq(reqParams, "NZN006")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := map[string]string{
		"MBSKEY":   b.MbsKey,
		"BRANCHID": b.BranchCode,
		"USERID":   b.UserID,
		"SKEY":     b.SKey,
		"DataDic":  "1",
		"JSON":     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("getTransferDetails JSON加密错误: %+v.", err)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "NZN006")
	res := map[string]interface{}{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	b.logger.Infof("getTransferDetails请求成功, \r\ndata: %s, \r\nbody: %s.", string(jsonStr), body)

	return res, nil
}

// 查询目标银行名字，代码
func (b *Bank) searchBank(cardno string) (*searchBankRes, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{
		"inAccNo": cardno,
	}

	request := comRequestReq(reqParams, "NZN001")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqData := url.Values{}
	reqData.Set("MBSKEY", b.MbsKey)
	reqData.Set("BRANCHID", b.BranchCode)
	reqData.Set("USERID", b.UserID)
	reqData.Set("SKEY", b.SKey)
	reqData.Set("DataDic", "1")
	reqData.Set("JSON", string(jsonStr))

	res := searchBankRes{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	b.logger.Infof("searchBank请求成功, data: %s, body: %s.", string(jsonStr), body)

	return &res, nil
}

// 发送转账验证码
func (b *Bank) transferSmsCode(isSameBank bool) (*transferSmsCodeRes, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{
		"accBranchCode":   b.BranchCode,
		"regionFlag":      b.regionFlag,
		"inAccNo":         b.targetCard,
		"amount":          b.amount,
		"accNo":           b.AccNo,
		"inAccName":       b.targetName,
		"accType":         b.AccType,
		"inetBankWayFlag": "",
	}

	if isSameBank {
		reqParams["selSubAccMsg"] = "0101,01,0,0,人民币"
	} else {
		reqParams["bankCode"] = b.bankCode
	}

	request := comRequestReq(reqParams, "NZN002")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	jsonBuff, _ := json.Marshal(&map[string]string{
		"MBSKEY":   b.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   b.UserID,
		"SKEY":     b.SKey,
		"DataDic":  "1",
		"BRANCHID": b.BranchCode,
	})

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("transferSmsCode JSON加密错误： %+v.", err)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "NZN002")

	res := transferSmsCodeRes{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	b.updateMBSKey()

	b.logger.Infof("transferSmsCode请求成功, data: %s, body: %s.", string(jsonBuff), body)

	return &res, nil
}

//转账
func (b *Bank) transfer(code string, isSameBank, needPassword bool) (*transferRes, string, error) {
	reqHeader := comHeaderReq

	accCode := "0101"
	if b.cardNum != "" {
		accCode = b.cardNum
	}

	curFlag := "01"
	if b.curFlag != "" {
		curFlag = b.curFlag
	}

	reqParams := map[string]string{
		"inAccName":       b.targetName,
		"amount":          b.amount,
		"curFlag":         curFlag,
		"accCode":         accCode,
		"inAccNo":         b.targetCard,
		"accName":         b.AccName,
		"regionFlag":      b.regionFlag,
		"inetBankWayFlag": "",
		"accBranchCode":   b.BranchCode,
		"secFlow":         b.secFlow,
		"safeContent":     b.safeContent,
		"secFlag":         b.secFlag,
		"fee":             b.fee,
		"accType":         b.AccType,
		"safeType":        "SMS",
		"accCash":         "0",
		"secCode":         code, //验证码
		"accNo":           b.AccNo,
	}

	if b.note != "" {
		reqParams["rmtPstcrpt"] = b.note
	}
	// else {
	// 	reqParams["rmtPstcrpt"] = "货款"
	// }

	if isSameBank {
		reqParams["inAccBbranchCode"] = b.inAccBbranchCode
		reqParams["reserveSign"] = b.reserveSign
		reqParams["fType"] = b.fType
		reqParams["bBranchCode"] = b.BBranchCode
		reqParams["accFlag"] = "0"
	} else {
		reqParams["bankCode"] = b.bankCode
		reqParams["bankName"] = b.bankName
	}

	if needPassword {
		reqParams["safeAccPsw"] = b.PayPwd
		reqParams["operation"] = "verifyPassword"
	}

	request := comRequestReq(reqParams, "NZN003")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := map[string]string{
		"MBSKEY":   b.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   b.UserID,
		"SKEY":     b.SKey,
		"DataDic":  "1",
		"BRANCHID": b.BranchCode,
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("transfer JSON加密错误: %+v.", err)
		return nil, "", ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "NZN003")

	res := transferRes{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, "", err
	}

	b.logger.Infof("transfer请求成功, data: %s, body: %s.", string(jsonBuff), body)

	return &res, body, nil
}

func (b *Bank) queryTransfer(info *TransferResultInfo) (*queryTransferRes, error) {
	reqHeader := comHeaderReq

	reqParams := map[string]string{
		"ori_transaction_sn": info.OriTransactionSN,
		"EVT_TRACE_ID_EC":    info.EvtTraceIDEC,
		"RcvPymtPs_AccNo":    info.RcvPymtPsAccNO,
		"CHNL_CUST_NO":       info.ChnlCustNO,
		"Py_Psn_AccNo":       info.PyPsnAccNO,
		"Rmt_Amt":            info.RmtAmt,
		"DataDic":            info.DataDic,
	}

	request := comRequestReq(reqParams, "PGJ004")

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := map[string]string{
		"MBSKEY":   b.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   b.UserID,
		"SKEY":     b.SKey,
		"BRANCHID": b.BranchCode,
		"DataDic":  "1",
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		b.logger.Errorf("queryTransfer JSON加密错误: %+v.", err)
		return nil, ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "PGJ004")

	res := queryTransferRes{}
	body, err := b.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	b.logger.Infof("queryTransfer请求成功, data: %s, body: %s.", string(jsonBuff), body)

	return &res, nil
}
