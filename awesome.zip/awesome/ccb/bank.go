package ccb

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"crypto/tls"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"strings"
	"time"
)

// Bank 建设银行
type Bank struct {
	c                      *http.Client
	logger                 *log2.MyLog
	Account                string       `json:"account"`  // 账号，手机号
	LoginPwd               string       `json:"loginPwd"` // 登陆密码
	PayPwd                 string       `json:"payPwd"`   // 支付密码
	HardwareInfo           HardwareInfo `json:"hardwareInfo"`
	AccNo                  string       `json:"accNo"`
	AccName                string       `json:"accName"`
	AccType                string       `json:"accType"`
	BranchCode             string       `json:"barnchCode"`
	BBranchCode            string       `json:"bbarnchCode"`
	UserID                 string       `json:"userID"`
	UserToken              string       `json:"userToken"`
	MbsKey                 string       `json:"mbsKey"`
	SKey                   string       `json:"sKey"`
	SkeyB2C                string       `json:"sKeyB2c"`
	CustNo                 string       `json:"custNo"`
	CardNo                 string       `json:"cardNo"`
	ReqURL                 string       `json:"reqUrl"`
	ReqURLUpdateTime       uint32       `json:"reqUrlUpdateTime "`
	MultiChannel           string       `json:"multiChannel"`
	MultiChannelUpdateTime uint32       `json:"multiChannelUpdateTime"`
	// 登录绑定
	secControl string
	secMsg     string
	//转账用到的
	targetCard       string
	targetName       string
	amount           string
	note             string
	regionFlag       string
	bankName         string
	bankCode         string
	curFlag          string
	cardNum          string
	secFlow          string
	secFlag          string
	safeContent      string
	fee              string
	inAccBbranchCode string
	reserveSign      string
	fType            string
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	Model         string `json:"model"`         // 设备类型
	OwnerName     string `json:"ownerName"`     // 设备用户名 jj的 iPhone
	IDFV          string `json:"idfv"`
}

// New 创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:      account,
		LoginPwd:     loginPwd,
		PayPwd:       payPwd,
		HardwareInfo: HardwareInfo{},
	}

	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.OwnerName = tools.NewOwnerName()
	b.HardwareInfo.IDFV = tools.NewUUIDUpper()
	b.Save()
	return b
}

// Save 保存账号信息
func (b *Bank) Save() {
	path := "./ccb/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (b *Bank) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	//u, _ := url.Parse("http://127.0.0.1:9090")
	//u, _ := url.Parse("http://192.168.137.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// Login 登陆
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.c = b.NewHTTPClient()
	// log
	b.logger = &log2.MyLog{
		Prefix: fmt.Sprintf("[CCB][%s]", b.Account),
	}

	// 拿地址
	if b.MultiChannel == "" || (tools.Timestamp()-b.MultiChannelUpdateTime > 86400) {
		channelAddress, err := b.queryChannelAddress()
		if err != nil {
			b.logger.Errorf("获取服务器请求路径操作错误: %+v.", err)
			return base.LoginResultFail
		}
		if channelAddress.Header.Status != resCodeSuccess {
			b.logger.Errorf("获取服务器请求路径失败, 代码:  %+v, 信息: %+v.", channelAddress.Response[0].Result.ErrCode, channelAddress.Response[0].Result.ErrMessage)
			return base.LoginResultFail
		}
		for _, v := range channelAddress.Response[0].Result.CHANNELADDRESS.AddrList {
			if v.CLIENTTYPE == "01" || strings.Contains(v.RULE, "/cmccb/servlet/") {
				b.MultiChannel = v.MULTICHANNEL
				b.MultiChannelUpdateTime = tools.Timestamp()
				b.Save()
				b.logger.Infof("获取MultiChannel成功: %s.", v.MULTICHANNEL)
				break
			}
		}
		// 还是空
		if b.MultiChannel == "" {
			b.logger.Error("无法获取服务器请求路径, 请重试.")
			return base.LoginResultFail
		}
	}

	// 第一次登陆需要银行手机号发送 88#88 到 95533 获取登陆短信
	if b.UserID == "" || b.UserToken == "" {
		b.logger.Info("用户首次登录,需要银行手机号发送 88#88 到 95533 获取登陆短信")
		return base.LoginResultFailNeedSms
	}

	// 正常登录
	res, err := b.bindTokenLogin()
	if err != nil {
		b.logger.Errorf("登录操作错误: %+v.", err)
		return base.LoginResultFail
	}

	if res.Header.Status != resCodeSuccess {
		msg := res.Response[0].Result.ErrMessage
		if strings.Contains(msg, "输入信息不正确") {
			b.logger.Error("登录密码错误")
			return base.LoginResultFailWrongPwd
		}

		b.logger.Errorf("普通登录错误: %+v.", msg)
		return base.LoginResultFail
	}

	tips := res.Response[0].Result.AlertTips
	if strings.Contains(tips, "重新进行设备绑定") {
		b.logger.Errorf("普通登录错误: %+v.", tips)
		return base.LoginResultFailNeedSms
	}

	return b.loginComplete(&res.Response[0].Result.loginInfo)
}

// LoginVerifySMS 登陆短信验证码校验
func (b *Bank) LoginVerifySMS(code string) base.LoginResultCode {
	b.logger.Info("首次验证码登录, 验证码: " + code)
	res, err := b.firstLogin(code)
	if err != nil {
		b.logger.Errorf("校验登录验证码错误: %+v.", err)
		return base.LoginResultFail
	}
	if res.Header.Status != resCodeSuccess {
		msg := res.Response[0].Result.ErrMessage
		b.logger.Errorf("校验登录验证码失败, 代码: %+v, 信息: %+v.", res.Response[0].Result.ErrCode, msg)

		if strings.Contains(msg, "手机号码或授权码不正确") {
			return base.LoginResultFailWrongSms
		}

		if strings.Contains(msg, "输入信息不正确") {
			return base.LoginResultFailWrongPwd
		}
		return base.LoginResultFail
	}

	loginCode := b.loginComplete(&res.loginInfo)
	if loginCode == base.LoginResultFailNeedSms {
		// 进行绑定
		if strings.Contains(b.secMsg, "系统监测到您已绑定其它设备") {
			verifyRes, err := b.verifyPayPassword(code)
			if err != nil {
				b.logger.Errorf("输入支付密码绑定设备登录错误: %+v.", err)
				return base.LoginResultFail
			}

			if verifyRes.Header.Status != resCodeSuccess {
				b.logger.Errorf("输入支付密码绑定设备登录失败, 代码: %+v, 信息: %+v.", verifyRes.Response[0].Result.ErrCode,
					verifyRes.Response[0].Result.ErrMessage)
				return base.LoginResultFail
			}
			return b.loginComplete(&verifyRes.loginInfo)
		}

		b.logger.Errorf("校验验证码登录无法获取UserToken, 代码: %+v, 信息: %+v.", b.secControl, b.secMsg)
		return base.LoginResultFail
	}

	return loginCode
}

func (b *Bank) loginComplete(res *loginInfo) base.LoginResultCode {
	if res.ParamSecurity.UserToken != "" {
		b.UserToken = res.ParamSecurity.UserToken
	}
	if res.ParamSecurity.SECCONTROL != "" {
		b.secControl = res.ParamSecurity.SECCONTROL
	}
	if res.ParamSecurity.SECMSG != "" {
		b.secMsg = res.ParamSecurity.SECMSG
	}
	b.UserID = res.SetvarParams.USERID
	b.SKey = res.SetvarParams.SKEY
	b.MbsKey = res.SetvarParams.MBSKEY
	// 查询转账记录需要，可以不用
	b.CustNo = res.SetvarParams.ECIFCustNo

	// 哪里请求路径不对
	if len(res.SetvarParams.CHANNELADDRESS.AddrList) != 0 {
		for _, v := range res.SetvarParams.CHANNELADDRESS.AddrList {
			if v.CLIENTTYPE == "01" || strings.Contains(v.RULE, "/cmccb/servlet/") {
				b.MultiChannel = v.MULTICHANNEL
				b.MultiChannelUpdateTime = tools.Timestamp()
				b.logger.Infof("修正MultiChannel为: %s.", v.MULTICHANNEL)
				break
			}
		}
	}

	b.Save()

	if len(res.MBCACCOUNT) <= 0 {
		b.logger.Error("该帐号银行卡列表为空.")
		return base.LoginResultFail
	}

	if b.CardNo == "" {
		b.AccNo = res.MBCACCOUNT[0].ACCNO
		b.AccName = res.MBCACCOUNT[0].ACCNAME
		b.AccType = res.MBCACCOUNT[0].ACCTYPE
		b.BranchCode = res.MBCACCOUNT[0].BRANCHCODE
		b.BBranchCode = res.MBCACCOUNT[0].BBRANCHCODE
		b.logger.Infof("没有指定卡号, 选择默认卡号[%s].", b.AccNo)
	} else {
		// 找出指定卡号
		exists := false
		for _, v := range res.MBCACCOUNT {
			if v.ACCNO == b.CardNo {
				b.AccNo = v.ACCNO
				b.AccName = v.ACCNAME
				b.AccType = v.ACCTYPE
				b.BranchCode = v.BRANCHCODE
				b.BBranchCode = v.BBRANCHCODE
				exists = true
				break
			}
		}

		if !exists {
			b.logger.Errorf("没有找到指定的银行卡号: %s", b.CardNo)
			return base.LoginResultFail
		}
	}

	// 没有获取到UserToken
	if b.UserToken == "" {
		// 绑定
		return base.LoginResultFailNeedSms
	}

	// 如果路径为空
	if b.ReqURL == "" || (tools.Timestamp()-b.ReqURLUpdateTime > 86400) {
		reqURL, err := b.getReqURL()
		if err != nil {
			b.logger.Errorf("获取reqUrl操作错误: %+v.", err)
			return base.LoginResultFail
		}

		if reqURL.Success != "true" {
			b.logger.Error("获取reqUrl失败.")
			return base.LoginResultFail
		}

		b.ReqURL = reqURL.ReqURL
		b.ReqURLUpdateTime = tools.Timestamp()
		b.Save()
		b.logger.Infof("获取reqUrl成功: %s.", b.ReqURL)
	}

	if err := b.getSkey(); err != nil {
		b.logger.Errorf("验证码登录获取Skey错误: %+v.", err)
		return base.LoginResultFail
	}

	return base.LoginResultSuccess
}

// Balance 查询余额
func (b *Bank) Balance() {
	b.getBalance()
}

// BillList 查询账单
func (b *Bank) BillList(startDate, endDate string) {
	b.getDetails(startDate, endDate, 1)
}

// Transfer 转账
func (b *Bank) Transfer(destCardNo, destName, amount, remark string) base.TransferResultCode {
	bank, err := b.searchBank(destCardNo)
	if err != nil {
		b.logger.Errorf("查询转帐目标银行卡信息错误: %+v.", err)
		return base.TransferResultFail
	}
	if bank.Header.Status != resCodeSuccess {
		b.logger.Errorf("转帐操作失败: %+v.", bank.Response[0].Result.ErrMessage)
		return base.TransferResultFail
	}

	b.regionFlag = bank.Response[0].Result.RegionFlag
	b.bankName = bank.Response[0].Result.BankName
	b.bankCode = bank.Response[0].Result.BankCode

	b.logger.Infof("查询成功, 目标银行: %+v,银行代码: %+v, 地区: %+v.", b.bankName, b.bankCode, b.regionFlag)

	if b.bankCode == "" && b.regionFlag != "1" {
		b.logger.Errorf("查询不到转账卡号的bankcode, 卡号: %+v.", destCardNo)
		return base.TransferResultFail
	}

	// 保存转帐参数
	b.targetName = destName
	b.targetCard = destCardNo
	b.amount = amount
	b.note = remark

	// 发送短信验证码
	// 错误码：0760S0008002  首次使用此账户进行转账汇款,需要激活
	code, err := b.transferSmsCode(b.regionFlag == "1")
	if err != nil {
		b.logger.Errorf("发送转帐验证码错误: %+v.", err)
		return base.TransferResultFail
	}

	if code.Header.Status != resCodeSuccess {
		errCode := code.Response[0].Result.ErrCode
		errMsg := code.Response[0].Result.ErrMessage
		b.logger.Errorf("发送转帐验证码失败, 代码: %+v, 信息: %+v.", errCode, errMsg)
		return base.TransferResultFail
	}

	b.curFlag = code.Response[0].Result.CurFlag
	b.cardNum = code.Response[0].Result.CardNum
	b.secFlow = code.Response[0].Result.SecFlow
	b.secFlag = code.Response[0].Result.SecFlag
	b.safeContent = code.Response[0].Result.SafeContent
	b.fee = code.Response[0].Result.Fee

	b.inAccBbranchCode = code.Response[0].Result.InAccBbranchCode
	b.reserveSign = code.Response[0].Result.ReserveSign
	b.fType = code.Response[0].Result.FType

	return base.TransferResultFailNeedSms
}

// TransferVerifySMS 转账验证短信
func (b *Bank) TransferVerifySMS(code string) base.TransferResultCode {
	b.logger.Info("转账验证，收到验证码: " + code)

	transfer, _, err := b.transfer(code, b.regionFlag == "1", false)
	if err != nil {
		b.logger.Errorf("转帐操作错误: %+v.", err)
		return base.TransferResultFail
	}
	if transfer.Header.Status != resCodeSuccess {
		msg := transfer.Response[0].Result.ErrMessage
		b.logger.Errorf("转帐操作失败, 代码: %+v, 信息: %+v", transfer.Response[0].Result.ErrCode, msg)
		return base.TransferResultFail
	}
	// 需要更多验证
	if transfer.Response[0].Result.Safe.SafeCode != "" {
		// 需要图形验证码
		if transfer.Response[0].Result.Safe.SafeData.NeedImageValidate == "1" {
			b.logger.Info("转帐操作失败, 需要图形验证码进行转帐.")
			return base.TransferResultFail
		}
		// 需要验证密码
		// 在输入密码的同时这里虽然也弹出了图片验证码，但是是本地验证的
		if transfer.Response[0].Result.Safe.SafeData.ShowPassword == "1" {
			time.Sleep(time.Second * time.Duration(rand.Intn(5)+3))
			transfer, _, err = b.transfer(code, b.regionFlag == "1", true)
			if err != nil {
				b.logger.Errorf("转帐操作验证密码操作错误: %+v.", err)
				return base.TransferResultFail
			}
			if transfer.Header.Status != resCodeSuccess {
				msg := transfer.Response[0].Result.ErrMessage
				b.logger.Errorf("转帐操作失败, 代码: %+v, 信息: %+v.", transfer.Response[0].Result.ErrCode, msg)
				return base.TransferResultFail
			}

			if transfer.Response[0].Result.Safe.SafeCode != "" {
				msg := transfer.Response[0].Result.Safe.SafeData.ErrMsg
				b.logger.Errorf("转帐操作失败, 代码: %+v, 信息: %+v.", transfer.Response[0].Result.Safe.SafeData.ErrCode, msg)
				return base.TransferResultFail
			}
		}
	}

	// 查询是否成功
	if b.regionFlag == "1" {
		return base.TransferResultSuccess
	}
	info := TransferResultInfo{
		CreditNO:         transfer.Response[0].Result.CreditNo,
		OriTransactionSN: transfer.Response[0].Result.OriTransactionSN,
		EvtTraceIDEC:     transfer.Response[0].Result.EvtTraceIDEc,
		RcvPymtPsAccNO:   b.targetCard,
		ChnlCustNO:       b.UserID,
		PyPsnAccNO:       b.AccNo,
		RmtAmt:           transfer.Response[0].Result.Amount,
		DataDic:          "1",
		// TradeNo:          b.OrderNo,
	}
	for i := 0; i < 5; i++ {
		time.Sleep(time.Second * 2)
		result, err := b.queryTransfer(&info)
		if err != nil {
			continue
		}

		if result.Header.Status != resCodeSuccess {
			b.logger.Errorf("查询转帐状态失败, 流水号: %+v, code: %+v.", info.CreditNO, result.Header.Status)
			continue
		}

		// 确认成功的
		if result.Response[0].Result.BsnRctInf == "success" {
			break
		}

		// 确认失败的
		b.logger.Infof("查询转帐状态失败, 流水号: %+v, 信息: %+v.", info.CreditNO, result.Response[0].Result.BsnRctInf)
		return base.TransferResultFail
	}

	return base.TransferResultSuccess
}
