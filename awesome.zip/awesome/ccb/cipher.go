package ccb

import (
	"awesome/tools"
	"encoding/base64"
	"fmt"
)

func jsonEncrypt(plainText string) (string, error) {
	enData, err := tools.TripleDESCBCEncrypt([]byte(plainText), []byte(post3DesKey), []byte(post3DesIV))
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(enData), nil
}

func passMd5(password string) string {
	str := fmt.Sprintf("%s%s", "20160506070809111", password)
	str = passwordEncrypt(str)
	randStr := tools.RandDecString(15)
	str = fmt.Sprintf("%s|%s||%s", "1.0.0.1", str, randStr)

	buff, _ := tools.TripleDESCBCEncrypt([]byte(str), []byte(password3DesKey), []byte(password3DesIV))
	return base64.StdEncoding.EncodeToString(buff)
}

func passwordEncrypt(password string) string {
	keyLenAry := []int{8, 16, 16}
	// 随机加密算法
	algID := tools.RandIntn(3)
	// 生成随机key
	key := tools.RandBytes(keyLenAry[algID])
	// 根据不同算法进行加密
	var out []byte
	switch algID {
	case 0: // des
		out, _ = tools.DESCBCZeroPadEncrypt([]byte(password), key, key)
	case 1: // aes
		out, _ = tools.AESECBZeroPadEncrypt([]byte(password), key)
	case 2: // rc4
		out, _ = tools.CCCryptRC4Encrypt([]byte(password), key)
	}

	if len(out) <= 0 {
		return ""
	}

	final := make([]byte, 2)
	final[0] = byte(algID)
	final[1] = byte(len(key))

	lenKey := len(key)
	lenOut := len(out)
	minLen := lenKey
	if lenKey > lenOut {
		minLen = lenOut
	}

	for i := 0; i < minLen; i++ {
		final = append(final, key[i], out[i])
	}

	if lenKey < lenOut {
		final = append(final, out[lenKey:]...)
	} else {
		final = append(final, key[lenOut:]...)
	}

	checksum := checkSum(final[2:], len(final)-2)
	// checksum := crc16.ChecksumIBM(final[2:])
	final = append(final, byte(checksum))
	final = append(final, byte(checksum>>8))
	// fmt.Println(hex.Dump(final))

	return base64.StdEncoding.EncodeToString(final)
}

func checkSum(buff []byte, len int) int {
	i := 0
	result := 0
	for {
		v5 := buff[i]
		v6 := 8
		for {
			v7 := 2*result&0xFFFFFFFE | int(v5>>7)&1
			v5 *= 2
			if (result & 0x8000) > 0 {
				result = v7 ^ 0x1021
			} else {
				result = v7
			}
			v6--
			if v6 <= 0 {
				break
			}
		}

		result = result & 0xffff
		i++
		if i == len {
			break
		}
	}
	return result
}
