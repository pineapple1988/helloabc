package ABC

import (
	"awesome/utils"
	"awesome/utils/log2"
	"testing"
	"time"
)

func TestStart(t *testing.T) {
	acc := &Account{}
	if utils.Exist("./bin/18457184594.json") {
		utils.LoadJsonFromFile("./bin/18457184594.json", acc)
	} else {
		acc = NewAccount("18457184594", "aa168168", "456456")
	}

	group := New(acc)
	if group.HandShake() {
		group.GetDataCollectConfig()
		log2.Infof("HandShake success")
		time.Sleep(3 * time.Second)
		group.GetDataCollectConfig()
		group.GetDescVersion()
		time.Sleep(1 * time.Second)
		group.GetRecommendProduct()
		//group.CollectData()
		time.Sleep(1 * time.Second)
		group.GetUI()
		time.Sleep(1 * time.Second)
		onceAesKey, onceAesIv := group.GetDynamicKey()
		if onceAesKey != nil && onceAesIv != nil {
			isLogin, sms := group.Login(onceAesKey, onceAesIv)
			if isLogin {
				time.Sleep(2 * time.Second)
				_ = group.InitBillQuery()
				res1 := group.QueryBillByDate("1","20190821", "20191119")
				if res1.Return.KeyNext != "" &&  res1.Return.KeyNext != "0" {
					// 拉去下一单
					res1 = group.QueryBillNext(res1.Return.KeyNext)
				}
			} else {
				// 等待发送短信发出后，去获取初始化刷脸参数
				log2.Info("sendSMS " + sms)
				// App 上是至少等待10秒，实际上可以等待更久
				time.Sleep(10*time.Second)
				faceRes := group.GetFaceAuthLoginParam()
				if faceRes.Return.IfActiveSuccess == "1" && group.faceAuthLoginFlag == "1" &&
					group.newMobileFlag == "1" {
					// 需要人脸认证啦,这里什么都不做
				}
				// 测试发现，没发送短信，还是登陆成功了，可以拉单
				group.Acc.ActiveState = "1"
				isLogin, _ := group.Login(onceAesKey, onceAesIv)
				if isLogin {
					time.Sleep(2 * time.Second)
					_ = group.InitBillQuery()
					res1 := group.QueryBillByDate("1", "20190821", "20191119")
					if res1.Return.KeyNext != "" && res1.Return.KeyNext != "0" {
						// 拉去下一单
						res1 = group.QueryBillNext(res1.Return.KeyNext)
					}
				} else {
					log2.Info("登陆失败")
				}
			}
		}
	} else {
		log2.Infof("HandShake error")
	}

	select {}
}