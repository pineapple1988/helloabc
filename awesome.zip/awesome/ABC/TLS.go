package ABC

import (
	"awesome/utils"
	"awesome/utils/log2"
	"bytes"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha1"
	"crypto/x509"
	"encoding/binary"
	"fmt"
	"io"
)

type TLS struct {
	rnc             []byte
	rns             []byte
	Rns2            []byte `json:"rns2"`
	pms             []byte
	pms2            []byte
	ms              []byte
	ms2             []byte
	serialN         int64
	clientKey       []byte
	clientIv        []byte
	serverKey       []byte
	serverIv        []byte
	clientHmacKey   []byte
	serverHmacKey   []byte
	sessionId       string
	ServerRSAPubKey []byte `json:"serverRsaPubKey"`
	clientHelloBody []byte
	serverHelloBody []byte
	clientKeyExBody []byte
	serverKeyExBody []byte
}

const (
	TLS_MD_PREMASTER_SECRET_CONST       = "premaster secret"
	TLS_MD_MASTER_SECRET_CONST          = "master secret"
	TLS_MD_CLIENT_FINISH_CONST          = "client finished"
	TLS_MD_MASTER_SECRET2_CONST         = "master secret2"
	TLS_MD_CLIENT_SERVER_KEYIVMAC_CONST = "key expansion"
	TLS_MD_SERVER_FINISH_CONST          = "server finished"
	TLS_ONCE_SECRET_CONST               = "once secret"
)

func (t *TLS) getClientRandom(count int) []byte {
	b := make([]byte, count)
	for i := 0; i < count; i++ {
		b[i] = byte(utils.RandInt31())
	}
	return b
}

func (t *TLS) hmacMD5SHA1XOR(prf, label, seed []byte, length int) []byte {
	halfLen := (len(prf) & 1) + (len(prf) >> 1)
	md5SourceAry := prf[:halfLen]
	sha1SourceAry := prf[halfLen:]
	param2BA := &bytes.Buffer{}
	param2BA.Write(label)
	param2BA.Write(seed)
	md5Ary := t.hmacMD5(md5SourceAry, param2BA.Bytes(), length)
	sha1Ary := t.hmacSHA1(sha1SourceAry, param2BA.Bytes(), length)
	return t.hMacXOR(md5Ary, sha1Ary)
}

func (t *TLS) hmacMD5(key, data []byte, size int) []byte {
	rltBA := &bytes.Buffer{}
	lastData := data
	for len(rltBA.Bytes()) <= size {
		hmd5 := hmac.New(md5.New, key)
		hmd5.Write(lastData)
		lastData = hmd5.Sum(nil)
		t := &bytes.Buffer{}
		t.Write(lastData)
		t.Write(data)
		hmd5.Reset()
		hmd5.Write(t.Bytes())
		rltBA.Write(hmd5.Sum(nil))
	}
	return rltBA.Bytes()[:size]
}
func (t *TLS) hmacSHA1(key, data []byte, size int) []byte {
	rltBA := &bytes.Buffer{}
	lastData := data
	for len(rltBA.Bytes()) <= size {
		hmd5 := hmac.New(sha1.New, key)
		hmd5.Write(lastData)
		lastData = hmd5.Sum(nil)
		t := &bytes.Buffer{}
		t.Write(lastData)
		t.Write(data)
		hmd5.Reset()
		hmd5.Write(t.Bytes())
		rltBA.Write(hmd5.Sum(nil))
	}
	return rltBA.Bytes()[:size]
}
func (t *TLS) hMacXOR(p1, p2 []byte) []byte {
	buf := &bytes.Buffer{}
	for i := 0; i < len(p1); i++ {
		buf.WriteByte(p1[i] ^ p2[i])
	}
	return buf.Bytes()
}

func (t *TLS) getClientProtocolVersion() []byte {
	return []byte{0x01, 0x00}
}

func (t *TLS) getSessionId() []byte {
	return []byte{0x00}
}

func (t *TLS) getCipherSuite() []byte {
	return []byte{0x00, 0x04, 0x00, 0x07, 0x00, 0x06}
}

func (t *TLS) getCertSerialNumber() []byte {
	if len(t.ServerRSAPubKey) == 0 {
		return []byte{0x00}
	}

	cert, err := x509.ParseCertificate(t.ServerRSAPubKey)
	if err != nil {
		log2.Error("getCertSerialNumber 获取rsa 序列号错误")
		return []byte{0x00}
	}

	b := &bytes.Buffer{}
	b.WriteByte(byte(len(cert.SerialNumber.Bytes())))
	b.Write(cert.SerialNumber.Bytes())

	return b.Bytes()
}

func (t *TLS) createOnceRNC() []byte {
	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.LittleEndian, utils.Timestamp())
	buffer.Write(t.getClientRandom(28))
	return buffer.Bytes()
}

func (t *TLS) createFullClientHelloBody() []byte {
	t.rnc = t.createOnceRNC()
	buffer1 := bytes.NewBuffer([]byte{})
	buffer1.Write(t.getClientProtocolVersion())
	buffer1.Write(t.rnc)
	buffer1.Write(t.getSessionId())
	buffer1.Write(t.getCipherSuite())
	buffer1.Write(t.getCertSerialNumber())

	buffer2 := bytes.NewBuffer([]byte{})
	buffer2.WriteByte(1)
	_ = binary.Write(buffer2, binary.BigEndian, uint32(len(buffer1.Bytes())))
	buffer2.Write(buffer1.Bytes())

	t.clientHelloBody = make([]byte, buffer2.Len())
	copy(t.clientHelloBody, buffer2.Bytes())

	return t.clientHelloBody
}
func (t *TLS) getPreMasterSecret() []byte {
	prf := t.getClientRandom(46)
	lable := []byte(TLS_MD_PREMASTER_SECRET_CONST)
	seed := bytes.NewBuffer([]byte{})
	seed.Write(t.rnc)
	seed.Write(t.rns)
	hmacData := t.hmacMD5SHA1XOR(prf, lable, seed.Bytes(), 46)

	buffer := bytes.NewBuffer([]byte{})
	buffer.Write(t.getClientProtocolVersion())
	buffer.Write(hmacData)

	return buffer.Bytes()
}
func (t *TLS) getClientKeyExchangeBody() []byte {
	t.pms = t.getPreMasterSecret()
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write(t.pms)
	buffer.Write(t.rns)
	buffer.WriteByte(0)
	enBuffer := utils.X509RsaEncrypt(buffer.Bytes(), t.ServerRSAPubKey)

	buffer.Reset()
	buffer.WriteByte(9)
	_ = binary.Write(buffer, binary.BigEndian, int32(len(enBuffer)))
	buffer.Write(enBuffer)

	return buffer.Bytes()
}

func (t *TLS) getChangeCipherSpecBody() []byte {
	return []byte{0x07, 0x00, 0x00, 0x00, 0x01, 0x00}
}

func (t *TLS) getVerifyData(body []byte) []byte {
	seed := &bytes.Buffer{}
	seed.Write(t.rnc)
	seed.Write(t.rns)
	label := []byte(TLS_MD_MASTER_SECRET_CONST)
	t.ms = t.hmacMD5SHA1XOR(t.pms, label, seed.Bytes(), 68)

	seed.Reset()
	md5DigestData := md5.Sum(body)
	sha1DigestData := sha1.Sum(body)
	seed.Write(md5DigestData[:])
	seed.Write(sha1DigestData[:])
	label = []byte(TLS_MD_CLIENT_FINISH_CONST)
	return t.hmacMD5SHA1XOR(t.ms, label, seed.Bytes(), 12)
}

func (t *TLS) getFinishedBody(body []byte) []byte {
	verify := t.getVerifyData(body)

	buffer := &bytes.Buffer{}
	buffer.WriteByte(0xA)
	_ = binary.Write(buffer, binary.BigEndian, int32(len(verify)))
	buffer.Write(verify)

	return buffer.Bytes()
}
func (t *TLS) clientHelloRequest(group *WorkGroup) bool {
	clientHelloBody := t.createFullClientHelloBody()

	//fmt.Println("clientHelloRequest req \n" + hex.Dump(clientHelloBody))

	resp := group.post(phoneUrl+"/user/hello?agent=iphone",
		&map[string]string{
			"appname":            "ebank",
			"last_prompted_time": "",
			"ota_version":        fmt.Sprintf("IP-UMP-%s-000000", bundleShortVersion),
		}, &map[string]string{
			headerXEmpEigenvalue: group.getXEmpEigenvalue(),
		}, clientHelloBody, false)

	//fmt.Println("clientHelloRequest resp \n" + hex.Dump(resp))

	if resp == nil {
		log2.Error("clientHelloRequest post err")
		return false
	} else {
		return t.handleFullServerHelloResponse(resp)
	}
}

func (t *TLS) sendClientKeyExchange(group *WorkGroup) bool {
	buffer := &bytes.Buffer{}

	clientKeyExchangeBody := t.getClientKeyExchangeBody()
	changeCipherSpecBody := t.getChangeCipherSpecBody()

	buffer.Write(t.clientHelloBody)
	buffer.Write(t.serverHelloBody)
	buffer.Write(clientKeyExchangeBody)
	buffer.Write(changeCipherSpecBody)

	finishBody := t.getFinishedBody(buffer.Bytes())

	buffer.Reset()
	buffer.Write(clientKeyExchangeBody)
	buffer.Write(changeCipherSpecBody)
	buffer.Write(finishBody)

	t.clientKeyExBody = buffer.Bytes()

	//fmt.Println("sendClientKeyExchange req \n" + hex.Dump(t.clientKeyExBody))

	resp := group.post(phoneUrl+"/user/exchange?agent=iphone",
		&map[string]string{
			"appname":            "ebank",
			"last_prompted_time": "",
			"ota_version":        fmt.Sprintf("IP-UMP-%s-000000", bundleShortVersion),
		}, &map[string]string{
			headerXEmpEigenvalue: group.getXEmpEigenvalue(),
		}, t.clientKeyExBody, false)

	//fmt.Println("sendClientKeyExchange resp \n" + hex.Dump(resp))

	if resp == nil {
		log2.Error("sendClientKeyExchange post err")
		return false
	} else {
		return t.handleFullServerKeyExchangeResponse(resp)
	}
}

func (t *TLS) clientHelloAndKeyExchange(group *WorkGroup) bool {
	// 拷贝rns2 -> rns
	t.rns = make([]byte, len(t.Rns2))
	copy(t.rns, t.Rns2)

	buffer := &bytes.Buffer{}
	buffer.Write(t.createFullClientHelloBody())
	buffer.Write(t.getClientKeyExchangeBody())
	buffer.Write(t.getChangeCipherSpecBody())
	buffer.Write(t.getFinishedBody(buffer.Bytes()))
	t.clientHelloBody = buffer.Bytes()

	//fmt.Println("clientHelloAndKeyExchange req \n" + hex.Dump(t.clientHelloBody))

	resp := group.post(phoneUrl+"/user/handshake?agent=iphone",
		&map[string]string{
			"appname":            "ebank",
			"last_prompted_time": "",
			"ota_version":        fmt.Sprintf("IP-UMP-%s-000000", bundleShortVersion),
		}, &map[string]string{
			headerXEmpEigenvalue: group.getXEmpEigenvalue(),
		}, t.clientHelloBody, false)

	//fmt.Println("clientHelloAndKeyExchange resp \n" + hex.Dump(resp))

	if resp == nil {
		log2.Error("clientHelloAndKeyExchange post err")
		return false
	} else {
		return t.handleSimpleClientHelloAndKeyExchangeResponse(resp)
	}
}

func (t *TLS) handleSimpleClientHelloAndKeyExchangeResponse(resp []byte) bool {
	reader := bytes.NewReader(resp)
	t.handleServerHello(reader)
	if t.handleServerCertificate(reader) {
		if t.parseServerKeyExchange(reader) {
			t.handleChangeCipher(reader)
			if t.handleFinish(reader) {
				t.handleInitContent(reader)
				return true
			}
		}
	}
	return false
}

func (t *TLS) handleFullServerHelloResponse(resp []byte) bool {
	t.serverHelloBody = resp
	reader := bytes.NewReader(resp)
	t.handleServerHello(reader)
	return t.handleServerCertificate(reader)
}

func (t *TLS) handleFullServerKeyExchangeResponse(resp []byte) bool {
	reader := bytes.NewReader(resp)
	if t.parseServerKeyExchange(reader) {
		t.handleChangeCipher(reader)
		if t.handleFinish(reader) {
			t.handleInitContent(reader)
			return true
		}
	}

	return false
}

func (t *TLS) handleServerHello(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	if f != 2 {
		_, _ = reader.Seek(4, io.SeekCurrent)
	}
	// 在读取6个字节
	_, _ = reader.Seek(6, io.SeekCurrent)
	// 读取rns
	t.rns = make([]byte, 0x20)
	_, _ = reader.Read(t.rns)
	// 读取sessionId
	sessionIdLen, _ := reader.ReadByte()
	sessionId := make([]byte, sessionIdLen)
	_, _ = reader.Read(sessionId)
	t.sessionId = string(sessionId)
	_, _ = reader.Seek(2, io.SeekCurrent)
}

func (t *TLS) handleServerCertificate(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	if f == 4 {
		var keyLen uint32
		_ = binary.Read(reader, binary.BigEndian, &keyLen)
		t.ServerRSAPubKey = make([]byte, keyLen)
		_, _ = reader.Read(t.ServerRSAPubKey)
		return true
	}
	log2.Error("handleServerCertificate error f != 4")
	return false
}
func (t *TLS) parseServerKeyExchange(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	if f == 5 {
		key := t.getAesKey(t.ms)
		iv := t.getAesIv(t.ms)

		// 读出需要解密的内容
		var enDataLen uint32
		_ = binary.Read(reader, binary.BigEndian, &enDataLen)
		enData := make([]byte, enDataLen)
		_, _ = reader.Read(enData)

		// 解密
		plainData := utils.AesCBCDecryptWithPkcs7Unpadding(enData, key, iv)
		plainReader := bytes.NewReader(plainData)
		t.Rns2 = make([]byte, 32)
		_, _ = plainReader.Read(t.Rns2)

		// 准备开始校验了
		v27 := make([]byte, 2)
		v16 := make([]byte, 46)
		hmacData := make([]byte, 20)
		_, _ = plainReader.Read(v27)
		_, _ = plainReader.Read(v16)
		_, _ = plainReader.Read(hmacData)

		if t.verifyHmac(t.ms, append(append(t.Rns2, v27...), v16...), hmacData) {
			t.pms2 = append(v27, v16...)
			label := []byte(TLS_MD_MASTER_SECRET2_CONST)
			seed := append(t.rnc, t.rns...)
			t.ms2 = t.hmacMD5SHA1XOR(t.pms2, label, seed, 48)
			t.createAesKey(t.ms2, seed)
			return true
		}

		log2.Error("handleServerCertificate 建立安全通道失败，原因为hmac较验失败。")
		return false
	}

	log2.Error("handleServerCertificate error f != 5")
	return false
}

func (t *TLS) handleChangeCipher(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f != 7 {
		dataLen = 0
	}
	dataLen += uint32(reader.Size()) - uint32(reader.Len())
	_, _ = reader.Seek(0, io.SeekStart)
	t.serverKeyExBody = make([]byte, dataLen)
	_, _ = reader.Read(t.serverKeyExBody)
}

func (t *TLS) handleFinish(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f == 10 {
		finishData := make([]byte, dataLen)
		_, _ = reader.Read(finishData)
		if t.verifyFinishData(finishData) {
			return true
		}
		log2.Error("handleFinish verifyFinishData 建立安全通道失败，原因为finish较验失败")
		return false
	}
	log2.Error("handleFinish error f != 10")
	return false
}

func (t *TLS) handleInitContent(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f == 11 {
		initContent := make([]byte, dataLen)
		_, _ = reader.Read(initContent)
		content := utils.AesCBCDecryptWithPkcs7Unpadding(initContent, t.serverKey, t.serverIv)
		log2.Info(" handleInitContent >>>>>>>> ")
		log2.InfoJson(string(content))
		return
	}
	log2.Error("handleInitContent error f != 11")
}

func (t *TLS) verifyFinishData(data []byte) bool {
	var allData []byte
	if len(t.clientHelloBody) > 0 {
		allData = append(allData, t.clientHelloBody...)
	}
	if len(t.serverHelloBody) > 0 {
		allData = append(allData, t.serverHelloBody...)
	}
	if len(t.clientKeyExBody) > 0 {
		allData = append(allData, t.clientKeyExBody...)
	}
	if len(t.serverKeyExBody) > 0 {
		allData = append(allData, t.serverKeyExBody...)
	}

	label := []byte(TLS_MD_SERVER_FINISH_CONST)
	md5Ary := md5.Sum(allData)
	sha1Ary := sha1.Sum(allData)

	retAry := t.hmacMD5SHA1XOR(t.ms2, label, append(md5Ary[:], sha1Ary[:]...), 12)

	if len(retAry) <= 0 || len(data) <= 0 {
		return false
	}

	if len(retAry) != len(data) {
		return false
	}

	for i, v := range retAry {
		if v != data[i] {
			return false
		}
	}

	return true
}

func (t *TLS) verifyHmac(ms, orgData, hmacData []byte) bool {
	key := t.getHmacKey(ms)
	hmacSha1 := hmac.New(sha1.New, key)
	hmacSha1.Write(orgData)
	digest := hmacSha1.Sum(nil)

	if len(digest) <= 0 || len(hmacData) <= 0 {
		return false
	}

	if len(digest) != len(hmacData) {
		return false
	}

	for i, v := range digest {
		if v != hmacData[i] {
			return false
		}
	}

	return true
}

func (t *TLS) createAesKey(key, seed []byte) {
	label := []byte(TLS_MD_CLIENT_SERVER_KEYIVMAC_CONST)
	allKeyIv := t.hmacMD5SHA1XOR(key, label, seed, 136)
	//fmt.Println(hex.Dump(allKeyIv))
	t.clientKey = t.getAesKey(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientKey))
	t.clientIv = t.getAesIv(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientIv))
	t.clientHmacKey = t.getHmacKey(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientHmacKey))

	t.serverKey = t.getAesKey(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverKey))
	t.serverIv = t.getAesIv(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverIv))
	t.serverHmacKey = t.getHmacKey(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverHmacKey))
}

func (t *TLS) getAesKey(data []byte) []byte {
	return data[:32]
}

func (t *TLS) getAesIv(data []byte) []byte {
	return data[32:48]
}

func (t *TLS) getHmacKey(data []byte) []byte {
	return data[48:68]
}
