package ABC

import (
	"encoding/xml"
)

type CollectData struct {
	NT            string `json:"NT"`
	AV            string `json:"AV"`
	OperationTime string `json:"OperationTime"`
	UserId        string `json:"UserId"`
	CA            string `json:"CA"`
	DeviceID      string `json:"Device_ID"`
	MU            string `json:"MU"`
	SY            string `json:"SY"`
	AN            string `json:"AN"`
	PN            string `json:"PN"`
	VI            string `json:"VI"`
	Location      string `json:"Location"`
	EM            string `json:"EM"`
	KeyValues     struct {
		StartAppTime string `json:"StartAppTime"`
		OfflineStart string `json:"Offline_Start"`
		EndAppTime   string `json:"EndAppTime"`
	} `json:"KeyValues"`
	AppKey       string `json:"appKey"`
	DM           string `json:"DM"`
	AppStartTime string `json:"AppStartTime"`
	OS           string `json:"OS"`
	TM           string `json:"TM"`
}

type dynamicKey struct {
	state        xml.Name
	ServerRandom string `xml:"serverrandom,attr"`
	Status       string `xml:"status,attr"`
}

type GetUIRes struct {
	Return struct {
		ErrorCode            string `json:"error_code"`
		ErrorMsg             string `json:"error_msg"`
		IsActivate           string `json:"is_activate"`
		Entry                string `json:"entry"`
		XhtmlPage            string `json:"xhtml_page"`
		CstNo                string `json:"cstNo"`
		CstName              string `json:"cstName"`
		CertType             string `json:"certType"`
		CertID               string `json:"certId"`
		CertCode             string `json:"certCode"`
		NewMobileFlag        string `json:"newMobileFlag"`
		IdValidDate          string `json:"idValidDate"`
		IdStartDate          string `json:"idStartDate"`
		FaceAuthScore        string `json:"faceAuthScore"`
		FaceLiveness         string `json:"faceLiveness"`
		FaceSecAuthEnable    string `json:"faceSecAuthEnable"`
		FaceAuthTimesLimit   string `json:"faceAuthTimesLimit"`
		FaceAuthUrl          string `json:"faceAuthUrl"`
		FaceAuthLoginFlag    string `json:"face_auth_login_flag"`
		OtaVersion           string `json:"otaVersion"`
		TestLoginMode        string `json:"test_login_mode"`
		RegisterFlg          string `json:"registerFlg"`
		RandomNum            string `json:"randomNum"`
		ActiveState          string `json:"activeState"`
		MobileNo             string `json:"mobileNo"`
		Key                  string `json:"key"`
		AcPhoneNo            string `json:"ac_phone_no"`
		PhyBackFlag          string `json:"phyBackFlag"`
		InputPhoneCheckClear string `json:"inputPhoneCheckClear"`
		AndrFingAdapFlag     string `json:"andr_fing_adap_flag"`
		IosPrivRepFlag       string `json:"ios_priv_rep_flag"`
	} `json:"return"`
}

type groupmember struct {
	LoginType     string `json:"logintype"`
	ChannelId     string `json:"channelid"`
	ImageName     string `json:"imagename"`
	Title         string `json:"title"`
	ChannelType   string `json:"channeltype"`
	Type          string `json:"type"`
	Url           string `json:"url"`
	CanDelete     string `json:"candelete"`
	ChannelState  string `json:"channelstate"`
	LoginState    string `json:"loginstate"`
	ChannelState2 string `json:"channel_state"`
	LoginState2   string `json:"login_state"`
}

type nativeMenu struct {
	GroupName   string        `json:"groupname"`
	GroupMember []groupmember `json:"groupmember"`
}

type channel struct {
	Title        string `json:"title"`
	Url          string `json:"url"`
	Id           string `json:"id"`
	Fid          string `json:"fid"`
	Order        string `json:"order"`
	BCode        string `json:"bcode"`
	Type         string `json:"type"`
	CanDelete    string `json:"candelete"`
	ChannelType  string `json:"channeltype"`
	LoginType    string `json:"logintype"`
	LoginState   string `json:"loginstate"`
	ChannelState string `json:"channel_state"`
}

type LoginRes struct {
	Return struct {
		ErrorCode           string `json:"error_code"`
		ErrorMsg            string `json:"error_msg"`
		Sn                  string `json:"sn"`
		KeyCompany          string `json:"keyCompany"`
		Dn                  string `json:"dn"`
		SignAlg             string `json:"signAlg"`
		HashAlg             string `json:"hashAlg"`
		CPidMd5             string `json:"cPidMd5"`
		VoiceGuideFlag      string `json:"voiceGuideFlag"`
		ExpireNotificaiton  string `json:"expireNotificaiton"`
		CheckInfo           string `json:"checkInfo"`
		NoticeInfo          string `json:"noticeInfo"`
		UpdateUrl           string `json:"updateUrl"`
		CheckInfo2          string `json:"check_info"`
		LibName             string `json:"libName"`
		MenuVersion         string `json:"menuVersion"`
		Sexual              string `json:"sexual"`
		CustPreServLvl      string `json:"custPreServLvl"`
		VIPCustLvl          string `json:"vIPCustLvl"`
		CustLvlDisNum       string `json:"custLvlDisNum"`
		CustLvlDis          string `json:"custLvlDis"`
		CustInfoFlag        string `json:"custInfoFlag"`
		AntiMonFlag         string `json:"antiMonFlag"`
		HintTimes           string `json:"hintTimes"`
		AccountDate         string `json:"accountDate"`
		MutiIDFlag          string `json:"mutiIDFlag"`
		ImpInfoFlag         string `json:"impInfoFlag"`
		UnImpInfoFlag       string `json:"unImpInfoFlag"`
		DifEffeErrorType    string `json:"difEffeErrorType"`
		IfGdprNeedSign      string `json:"ifGdprNeedSign"`
		DidEndLoginDay      string `json:"didEndLoginDay"`
		WillForbidErrMsg    string `json:"willForbidErrMsg"`
		EndLoginDate        string `json:"endLoginDate"`
		FileFlag            string `json:"fileFlag"`
		CFlagMsg            string `json:"cFlagMsg"`
		SameDevice          string `json:"same_device"`
		SSignFlag           string `json:"sSignFlag"`
		StokenAckMsg        string `json:"stokenAckMsg"`
		StokenMaxValue      string `json:"stokenMaxValue"`
		ImToken             string `json:"imToken"`
		Isupdate            string `json:"isupdate"`
		NewVersion          string `json:"newversion"`
		BranchSessionID     string `json:"branchSessionID"`
		IsWholeMenuUpdate   string `json:"isWholeMenuUpdate"`
		NewWholeMenuVersion string `json:"newWholeMenuVersion"`
		UserInfo            struct {
			UserName         string `json:"username"`
			UserType         string `json:"userType"`
			LastLogin        string `json:"lastLogin"`
			CityFilter       string `json:"cityFilter"`
			MyPropertyFilter string `json:"myPropertyFilter"`
			MonthBillTips    string `json:"monthBillTips"`
			CustMenuName     string `json:"custMenuName"`
			LogoutTitle      string `json:"logoutTitle"`
		} `json:"userinfo"`
		AccountInfo struct {
			IsSetDefaultAcc string                   `json:"isSetDefaultAcc"`
			AccInfo         []map[string]interface{} `json:"accInfo"`
		} `json:"accountInfo"`
		CalendarInfo struct {
			ServerDate   string                   `json:"serverDate"`
			EndDate      string                   `json:"endDate"`
			IsLoginShift string                   `json:"isLoginShift"`
			DetailData   []map[string]interface{} `json:"detailData"`
		} `json:"calendarinfo"`
		MainMenu struct {
			MyMenu       []map[string]interface{} `json:"mymenu"`
			NativeMyMenu []nativeMenu             `json:"nativemymenu"`
			TabBar       []groupmember            `json:"tabbar"`
			Service      []groupmember            `json:"service"`
			FinDex       []groupmember            `json:"findex"`
			MinDex       []groupmember            `json:"mindex"`
		} `json:"mainmenu"`
		Personal struct {
			MaxNum   string    `json:"max_num"`
			Version  string    `json:"version"`
			Channels []channel `json:"channels"`
		} `json:"personal"`
		Personal410 struct {
			MaxNum   string    `json:"max_num"`
			Version  string    `json:"version"`
			Channels []channel `json:"channels"`
		} `json:"personal_410"`
		PersonalKg410 struct {
			MaxNum   string    `json:"max_num"`
			Version  string    `json:"version"`
			Channels []channel `json:"channels"`
		} `json:"personal_kg410"`
		PersonalServiceNative    []nativeMenu             `json:"personal_service_native"`
		PersonalServiceNative410 []nativeMenu             `json:"personal_service_native_410"`
		PersonalService          []map[string]interface{} `json:"personal_service"`
	} `json:"return"`
}

type FaceAuthLoginParamRes struct {
	Return struct {
		ErrorCode          string `json:"error_code"`
		ErrorMsg           string `json:"error_msg"`
		IfActiveSuccess    string `json:"if_active_success"`
		CstNo              string `json:"cstNo"`
		CstName            string `json:"cstName"`
		CertType           string `json:"certType"`
		CertID             string `json:"certId"`
		CertCode           string `json:"certCode"`
		IdValidDate        string `json:"idValidDate"`
		IdStartDate        string `json:"idStartDate"`
		FaceAuthScore      string `json:"faceAuthScore"`
		FaceLiveness       string `json:"faceLiveness"`
		FaceSecAuthEnable  string `json:"faceSecAuthEnable"`
		FaceAuthTimesLimit string `json:"faceAuthTimesLimit"`
		FaceAuthUrl        string `json:"faceAuthUrl"`
	} `json:"return"`
}

type SelectedAcc struct {
	AccNo    string `json:"accNo"`
	AccType  string `json:"accType"`
	CurCode  string `json:"curCode"`
	CashFlag string `json:"cashFlag"`
}

type Acc struct {
	AccountName     string `json:"accountName"`
	AccType         string `json:"accType"`
	AccNo           string `json:"accNo"`
	Alias           string `json:"alias"`
	CBranchName     string `json:"cBranchName"`
	CBranchCode     string `json:"cBranchCode"`
	CCurrency       string `json:"cCurrency"`
	CBank           string `json:"cBank"`
	CABISBranchProv string `json:"cABISBranchProv"`
	CBranchProv     string `json:"cBranchProv"`
	CCashFlag       string `json:"cCashFlag"`
	CIsDefaultDid   string `json:"cIsDefaultDid"`
	SRegChannel     string `json:"sRegChannel"`
	HidFlag         string `json:"hidFlag"`
}

type Row struct {
	ATxnIn       string `json:"aTxnIn"`
	ATxnOut      string `json:"aTxnOut"`
	TrnDate      string `json:"trnDate"`
	TrnTime      string `json:"trnTime"`
	Comment      string `json:"comment"`
	ShortComment string `json:"shortComment"`
	LongComment  string `json:"longComment"`
	Type         string `json:"type"`
	Channel      string `json:"channel"`
	TrnCstName   string `json:"trnCstName"`
	TrnAccNo     string `json:"trnAccNo"`
	Balance      string `json:"balance"`
	Index        string `json:"index"`
}

type InitQueryBillRes struct {
	Return struct {
		ErrorCode       string      `json:"error_code"`
		ErrorMsg        string      `json:"error_msg"`
		JumpFrom        string      `json:"jumpFrom"`
		AlertWinFlag    string      `json:"alertWinFlag"`
		MiniProgramFlag string      `json:"miniProgramFlag"`
		FilterQueryFlag string      `json:"filterQueryFlag"`
		ReverseEnable   string      `json:"reverseEnable"`
		SelectedAcc     SelectedAcc `json:"selectedAcc"`
		IsReverse       string      `json:"isReverse"`
		StartDate       string      `json:"startDate"`
		EndDate         string      `json:"endDate"`
		DayBeforeWeek   string      `json:"dayBeforeWeek"`
		Today           string      `json:"today"`
		KeyNext         string      `json:"keyNext"` // 拉去下一页的关键参数,不是"0"表示还有下一页
		TrnCommList     []struct {
			TrnComm string `json:"trnComm"`
		} `json:"trnCommList"`
		AccList      []Acc  `json:"accList"`
		IsFirst      string `json:"isFirst"`
		CurrencyRows []struct {
			CurCode  string `json:"curCode"`
			CashFlag string `json:"cashFlag"`
		} `json:"currencyRows"`
		Rows []Row `json:"rows"`
	} `json:"return"`
}

type QueryBillRes struct {
	Return struct {
		ErrorCode     string      `json:"error_code"`
		ErrorMsg      string      `json:"error_msg"`
		SelectedAcc   SelectedAcc `json:"selectedAcc"`
		ReverseEnable string      `json:"reverseEnable"`
		IsReverse     string      `json:"isReverse"`
		StartDate     string      `json:"startDate"`
		EndDate       string      `json:"endDate"`
		KeyNext       string      `json:"keyNext"` // 拉去下一页的关键参数,不是"0"表示还有下一页
		IsFirst       string      `json:"isFirst"`
		Rows          []Row       `json:"rows"`
	} `json:"return"`
}
