package ABC

import (
	"awesome/utils"
	"awesome/utils/log2"
	"compress/gzip"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/go-http-utils/headers"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
)

func (w *WorkGroup) GetDataCollectConfig() {
	req, _ := http.NewRequest("GET", clickUrl+"/dataCollectionConfig?appKey="+appKey, nil)
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set(headers.UserAgent, w.getUserAgent2())
	resp, err := w.Do(req)
	if err != nil {
		log2.Errorf("GetDataCollectConfig err = %+v", err)
		return
	}
	defer resp.Body.Close()
	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return
		}
	}
	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		return
	}

	fmt.Println("GetDataCollectConfig resp -> \r\n" + string(respBody))
}


func (w *WorkGroup) CollectData(data *CollectData) {
	v := url.Values{}
	v.Set("appKey", appKey)
	reqData, _ := json.MarshalIndent(data, "", "  ")
	reqData, _ = utils.GZipCompress(reqData)
	v.Set("reqData", base64.StdEncoding.EncodeToString(reqData))
	v.Set("type", "1")
	body := v.Encode()
	body = strings.ReplaceAll(body, "+", "%20")
	req, _ := http.NewRequest("POST", clickUrl+"/collectedData", strings.NewReader(body))
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set(headers.UserAgent, w.getUserAgent2())
	resp, err := w.Do(req)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	// 如果是gzip需要解压
	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		return
	}

	fmt.Println("collectData -> " + string(respBody))
}
