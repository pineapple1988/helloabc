package ABC

import (
	"awesome/utils"
	"awesome/utils/log2"
	"compress/gzip"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"github.com/go-http-utils/headers"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

func (w *WorkGroup) post(u string, query *map[string]string, header *map[string]string, body interface{}, needEncrypt bool) []byte {
	myUrl, err := url.Parse(u)
	if err != nil {
		log2.Errorf("post url.Parse url=%s error=%+v", u, err)
		return nil
	}
	myQuery := myUrl.Query()
	// 添加公共query
	myQuery.Set("app", "ebank")
	myQuery.Set("o", "i")
	// 添加自定义query
	for key, value := range *query {
		myQuery.Set(key, value)
	}
	myUrl.RawQuery = myQuery.Encode()

	var postBody []byte
	switch body.(type) {
	case []byte:
		postBody = body.([]byte)
	case string:
		postBody = []byte(strings.ReplaceAll(body.(string), "+", "%20"))
		//fmt.Println(string(postBody))
	}

	if needEncrypt {
		// 进行aes加密
		postBody = utils.AesCBCEncryptWithPkcs7Padding(postBody, w.Acc.Tls.clientKey, w.Acc.Tls.clientIv)
	}

	postStr := base64.StdEncoding.EncodeToString(postBody)

	sign := ""
	if needEncrypt {
		hmacSha1 := hmac.New(sha1.New, w.Acc.Tls.clientHmacKey)
		hmacSha1.Write([]byte(postStr))
		sign = base64.StdEncoding.EncodeToString(hmacSha1.Sum(nil))
	}

	w.postURLFull = append(w.postURLFull, myUrl.String())
	w.PostURL = append(w.PostURL, myUrl.Scheme + "://" + myUrl.Host + myUrl.Path)

	addrs, err := net.LookupHost(myUrl.String())
	if err != nil {
		log2.Errorf("post net.LookupHost url=%s, error=%+v", myUrl.String(), err)
	} else {
		w.ServerIp = append(w.ServerIp, addrs[0])
	}

	req, err := http.NewRequest("POST", myUrl.String(), strings.NewReader(postStr))
	if err != nil {
		log2.Errorf("post http.NewRequest url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	// 添加公共header
	req.Header.Set(headers.UserAgent, w.getUserAgent())
	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.AcceptEncoding, "gzip")
	// 添加自定义header
	for key, value := range *header {
		req.Header.Set(key, value)
	}
	// 添加header
	if w.Acc.Tls.sessionId != "" {
		req.Header.Set(headerXEmpCookie, w.getXEmpCookie())
	}
	if w.redisId != "" {
		req.Header.Set(headerXEmpRedis, w.redisId)
	}
	if sign != "" {
		req.Header.Set(headerXEMPSignature, sign)
	}

	resp, err := w.Do(req)
	if err != nil {
		log2.Errorf("post w.Do url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	// 获取新的redisId
	if redisId := resp.Header.Get(headerSetEmpRedis); redisId != "" {
		w.redisId = redisId
	}

	// 如果是gzip需要解压
	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			log2.Errorf("post gzip.NewReader url=%s, error=%+v", myUrl.String(), err)
			return nil
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		log2.Errorf("post ioutil.ReadAll url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	_ = resp.Body.Close()

	encrypted, _ := strconv.ParseBool(resp.Header.Get(headerXEmpEncrypted))
	if encrypted {
		respBody, err = base64.StdEncoding.DecodeString(string(respBody))
		if err != nil {
			log2.Errorf("post base64 Decode respBody url=%s, error=%+v", myUrl.String(), err)
			return nil
		}
		// 解密操作
		respBody = utils.AesCBCDecryptWithPkcs7Unpadding(respBody, w.Acc.Tls.serverKey, w.Acc.Tls.serverIv)

	}

	return respBody
}

// 握手
func (w *WorkGroup) HandShake() bool {
	w.Acc.Tls.clientHelloBody = nil
	w.Acc.Tls.serverHelloBody = nil
	w.Acc.Tls.clientKeyExBody = nil
	w.Acc.Tls.serverKeyExBody = nil

	ret := false
	if len(w.Acc.Tls.ServerRSAPubKey) > 0 {
		ret = w.Acc.Tls.clientHelloAndKeyExchange(w)
	} else {
		if w.Acc.Tls.clientHelloRequest(w) {
			ret = w.Acc.Tls.sendClientKeyExchange(w)
		}
	}
	w.Acc.Save()

	return ret
}

func (w *WorkGroup) GetDescVersion() {
	body := `content={"app":"mbap","platform":"iphone","type":"common1","version":"237"}`

	fmt.Println("GetDescVersion req -> \r\n" + body)

	resp := w.post(phoneUrl+"/offline_s/getDescVersion",
		&map[string]string{}, &map[string]string{}, body, true)
	log2.Info("GetDescVersion resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))
}

func (w *WorkGroup) GetRecommendProduct() {
	body := ""

	resp := w.post(phoneUrl+"/ebank_s/get_recommended_product_410",
		&map[string]string{
			"sessionFlush": "0",
			"mobileNo":     w.Acc.PhoneNumber,
		}, &map[string]string{}, body, true)

	log2.Info("GetRecommendProduct resp >>>>>>>>>>>>>> ")
	log2.InfoJson(string(resp))
}

// 进入登陆界面
func (w *WorkGroup) GetUI() {
	v := url.Values{}

	mobileNo := ""
	randomNum := ""
	if w.Acc.ActiveState == "1" {
		mobileNo = w.Acc.PhoneNumber
		randomNum = w.Acc.RandomNum
	}
	v.Set("activeState", w.Acc.ActiveState)
	v.Set("mobileNo", mobileNo)
	v.Set("interface_type", "get_ui")
	v.Set("agent", "iphone")
	v.Set("otaVersion", bundleShortVersion)
	v.Set("randomNum", randomNum)
	v.Set("maxlat", "0")
	v.Set("p", "1")
	v.Set("maxlong", "0")
	v.Set("minlong", "0")
	v.Set("sw", "180")
	v.Set("sh", "196")
	v.Set("version", bundleShortVersion)
	v.Set("logo", "0")
	v.Set("minlat", "0")

	body := v.Encode()

	fmt.Println("GetUI req -> \r\n" + body)

	resp := w.post(phoneUrl+"/ebank_s/getui",
		&map[string]string{}, &map[string]string{}, body, true)

	res := &GetUIRes{}
	_ = json.Unmarshal(resp, res)

	w.Acc.ActiveState = res.Return.ActiveState
	if res.Return.ActiveState != "1" {
		log2.Infof("更新了RandomNum %s", res.Return.RandomNum)
		w.Acc.RandomNum = res.Return.RandomNum
		w.randomKey = res.Return.Key
	}
	log2.Info("GetUI resp >>>>>>>>>>>>>>>>")
	log2.InfoJson(string(resp))
}

// 获取一次加密密码的key
func (w *WorkGroup) GetDynamicKey() ([]byte, []byte) {
	onceRnc := w.Acc.Tls.createOnceRNC()
	// base64 + url encode
	v := url.Values{}
	v.Set("clientrandom", base64.StdEncoding.EncodeToString(onceRnc))
	body := v.Encode()
	resp := w.post(phoneUrl+"/user/dynamickey",
		&map[string]string{}, &map[string]string{}, body, true)

	key := &dynamicKey{}
	if err := xml.Unmarshal(resp, key); err != nil {
		log2.Errorf("GetDynamicKey xml.Unmarshal error=%+v", err)
		return nil, nil
	}

	if len(key.ServerRandom) > 0 {
		label := []byte(TLS_ONCE_SECRET_CONST)
		rns, _ := base64.StdEncoding.DecodeString(key.ServerRandom)
		seed := append(onceRnc, rns...)
		keyIv := w.Acc.Tls.hmacMD5SHA1XOR(w.Acc.Tls.pms2, label, seed, 48)
		return w.Acc.Tls.getAesKey(keyIv), w.Acc.Tls.getAesIv(keyIv)
	}

	return nil, nil
}

// 登陆
// 首次登陆会返回需要手机端发送的短信
func (w *WorkGroup) Login(onceAesKey, onceAesIv []byte) (bool, string) {
	// 加密密码
	enPwd := utils.AesCBCEncryptWithPkcs7Padding([]byte(w.Acc.LoginPwd), onceAesKey, onceAesIv)
	v := url.Values{}

	needImToken := "false"
	clientVersion := w.Acc.ClientVersion
	wholeMenuVersion := w.Acc.WholeMenuVersion
	if w.Acc.ActiveState != "1" {
		needImToken = "true"
		clientVersion = "100"
		v.Set("isCleanSession", "Y")
		wholeMenuVersion = ""
	}

	v.Set("needImToken", needImToken)
	v.Set("mobileNo", w.Acc.PhoneNumber)
	v.Set("seedFlag", "0")
	v.Set("loginType", "3")
	v.Set("phoneCheckedErr", "")
	v.Set("ewp_login_app", "登录")
	v.Set("activeState", w.Acc.ActiveState)
	v.Set("interface_type", "flag_login")
	v.Set("lbsStr", " & & & & ")
	v.Set("stokenSignMsg", w.getStokenSignMsg())
	v.Set("deviceToken", w.Acc.DeviceToken)
	v.Set("client_version", clientVersion)
	v.Set("password", base64.StdEncoding.EncodeToString(enPwd))
	v.Set("mobile", w.Acc.PhoneNumber)
	v.Set("wholeMenuVersion", wholeMenuVersion)
	v.Set("ua", "ip")
	v.Set("device_type", w.Acc.Model)
	v.Set("lbsAddress", "")
	v.Set("device_info", w.Acc.UUID)
	v.Set("randomNum", w.Acc.RandomNum)
	v.Set("maxlat", "0")
	v.Set("p", "1")
	v.Set("maxlong", "0")
	v.Set("minlong", "0")
	v.Set("sw", "180")
	v.Set("sh", "196")
	v.Set("version", bundleShortVersion)
	v.Set("logo", "0")
	v.Set("agent", "iphone")
	v.Set("minlat", "0")

	body := v.Encode()

	fmt.Println("login req -> \r\n" + body)
	resp := w.post(phoneUrl+"/phone_s/login",
		&map[string]string{}, &map[string]string{
			headerXEmpEigenvalue: w.getXEmpEigenvalue(),
		}, body, true)

	log2.Info("login resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))

	if needImToken == "false" {
		res := &LoginRes{}
		_ = json.Unmarshal(resp, res)

		if res.Return.NewWholeMenuVersion != "" {
			w.Acc.WholeMenuVersion = res.Return.NewWholeMenuVersion
		}
		if res.Return.NewVersion != "" {
			w.Acc.ClientVersion = res.Return.NewVersion
		}
		// 如果获取到用户名字了，那就登陆成功了
		if res.Return.UserInfo.UserName != "" {
			w.Acc.Save()
			return true, ""
		}
	} else {
		// 首次登陆需要发送短信,返回需要发送的短信
		res := &GetUIRes{}
		_ = json.Unmarshal(resp, res)

		w.faceAuthLoginFlag = res.Return.FaceAuthLoginFlag
		w.newMobileFlag = res.Return.NewMobileFlag

		if res.Return.IsActivate == "false" {
			// 生成需要发送的短信
			keyIv, _ := base64.StdEncoding.DecodeString(w.randomKey)

			key := w.Acc.Tls.getAesKey(keyIv)
			iv := w.Acc.Tls.getAesIv(keyIv)

			inData := []byte(w.Acc.PhoneNumber + "|" + w.Acc.RandomNum)
			enData := utils.AesCBCEncryptWithPkcs7Padding(inData, key, iv)

			msg := "MBAPACTIVATE#" + base64.StdEncoding.EncodeToString(enData)
			return false, msg
		}
	}

	return false, ""
}

// 获取刷脸参数
func (w *WorkGroup) GetFaceAuthLoginParam() *FaceAuthLoginParamRes {
	v := url.Values{}
	v.Set("mobileNo", w.Acc.PhoneNumber)
	v.Set("randomNum", w.Acc.RandomNum)
	v.Set("newMobileFlag", "0")

	body := v.Encode()

	fmt.Println("GetFaceAuthLoginParam req -> \r\n" + body)
	resp := w.post(phoneUrl+"/ebank_s/face_auth_login_param_get",
		&map[string]string{}, &map[string]string{
			headerXEmpEigenvalue: w.getXEmpEigenvalue(),
		}, body, true)

	log2.Info("GetFaceAuthLoginParam resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))

	res := &FaceAuthLoginParamRes{}
	_ = json.Unmarshal(resp, res)

	return res
}

// 初始化查询，会返回第一张卡最近一周的账单(第一页)
// 需先使用这个才能使用按时间查询
func (w *WorkGroup) InitBillQuery() *InitQueryBillRes {
	v := url.Values{}
	v.Set("deviceToken", w.Acc.DeviceToken)
	v.Set("mobileNo", w.Acc.PhoneNumber)
	v.Set("interface_type", "flag_app_s")
	v.Set("device_type", w.Acc.Model)
	v.Set("id", "detail_qry_new")
	v.Set("activeState", "1")
	v.Set("device_info", w.Acc.UUID)
	v.Set("randomNum", w.Acc.RandomNum)
	v.Set("maxlat", "0")
	v.Set("p", "1")
	v.Set("maxlong", "0")
	v.Set("minlong", "0")
	v.Set("sw", "180")
	v.Set("sh", "196")
	v.Set("version", bundleShortVersion)
	v.Set("logo", "0")
	v.Set("agent", "iphone")
	v.Set("minlat", "0")

	body := v.Encode()

	fmt.Println("InitBillQuery req -> \r\n" + body)
	resp := w.post(phoneUrl+"/app_s/run",
		&map[string]string{}, &map[string]string{}, body, true)

	log2.Info("InitBillQuery resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))
	res := &InitQueryBillRes{}
	_ = json.Unmarshal(resp, res)

	return res
}

// 按照时间获取订单的第一页 最长时间间隔为一年
// start 	 eg. 20190508
// end   	 eg. 20191119
// fromIndex eg. 1 // 这个是卡的索引，InitBillQuery会返回有记账卡
func (w *WorkGroup) QueryBillByDate(fromIndex, start, end string) *QueryBillRes {
	v := url.Values{}
	v.Set("fromIndex", fromIndex)
	v.Set("interface_type", "flag_app_s")
	v.Set("dSt", start)
	v.Set("isReverse", "1")
	v.Set("id", "detail_qry_new")
	v.Set("curIndex", "1")
	v.Set("step", "02")
	v.Set("dEnd", end)
	v.Set("maxlat", "0")
	v.Set("p", "1")
	v.Set("maxlong", "0")
	v.Set("minlong", "0")
	v.Set("sw", "180")
	v.Set("sh", "196")
	v.Set("version", bundleShortVersion)
	v.Set("logo", "0")
	v.Set("agent", "iphone")
	v.Set("minlat", "0")

	body := v.Encode()

	fmt.Println("QueryBillByDate req -> \r\n" + body)
	resp := w.post(phoneUrl+"/app_s/run",
		&map[string]string{}, &map[string]string{}, body, true)

	log2.Info("QueryBillByDate resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))
	res := &QueryBillRes{}
	_ = json.Unmarshal(resp, res)

	return res
}

// 账单翻页 keyNext为上次拉单返回
func (w *WorkGroup) QueryBillNext(keyNext string) *QueryBillRes {
	v := url.Values{}
	v.Set("id", "detail_qry_new")
	v.Set("sKeyNext", keyNext)
	v.Set("step", "03")
	v.Set("interface_type", "flag_app_s")
	v.Set("maxlat", "0")
	v.Set("p", "1")
	v.Set("maxlong", "0")
	v.Set("minlong", "0")
	v.Set("sw", "180")
	v.Set("sh", "196")
	v.Set("version", bundleShortVersion)
	v.Set("logo", "0")
	v.Set("agent", "iphone")
	v.Set("minlat", "0")

	body := v.Encode()

	fmt.Println("QueryBillNext req -> \r\n" + body)
	resp := w.post(phoneUrl+"/app_s/run",
		&map[string]string{}, &map[string]string{}, body, true)

	log2.Info("QueryBillNext resp >>>>>>>>>>>>")
	log2.InfoJson(string(resp))
	res := &QueryBillRes{}
	_ = json.Unmarshal(resp, res)

	return res
}
