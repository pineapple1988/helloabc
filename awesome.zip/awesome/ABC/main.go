package ABC

import (
	"awesome/github.com/tjfoc/gmsm/sm3"
	"awesome/utils"
	"bytes"
	"crypto/md5"
	"encoding/base64"
	"fmt"
	uuid "github.com/satori/go.uuid"
	"net/http"
	"net/http/cookiejar"
	"strings"
	"time"
)

type Account struct {
	PhoneNumber      string `json:"phoneNumber"`
	CardNo           string `json:"cardNo"`
	LoginPwd         string `json:"loginPwd"`
	PayPwd           string `json:"payPwd"`
	UUID             string `json:"uuid"`
	DeviceSerial     string `json:"deviceSerial"`
	DeviceToken      string `json:"deviceToken"`
	Model            string `json:"model"`
	RandomNum        string `json:"randomNum"`
	ClientVersion    string `json:"clientVersion"`
	WholeMenuVersion string `json:"wholeMenuVersion"`
	ActiveState      string `json:"activeState"`
	Tls              TLS    `json:"tls"`
}

const (
	phoneUrl             = "https://phone.abchina.com/nmbap"
	clickUrl             = "https://click.abchina.com/apm"
	bundleShortVersion   = "4.1.0"
	bundleVersion        = "4.1.1"
	headerXEmpCookie     = "X-Emp-Cookie"
	headerXEmpRedis      = "X-Emp-Redis"
	headerSetEmpRedis    = "Set-Emp-Redis"
	headerXEmpEigenvalue = "X-Emp-Eigenvalue"
	headerXEMPSignature  = "X-EMP-Signature"
	headerXEmpEncrypted  = "X-Emp-Encrypted"
	sm2X                 = "704C1947C010C0F4DD95A9597DCE73CEB900870F804E5CB1E751B20F478BA4B5"
	sm2Y                 = "D521BCB53A75EB8FC249AFC31D08E2E6B978E02A2D4C69B0CE2E9727963D151D"
	appKey               = "0cf637b656843e4f411b80613807309a5907a0e4"
)

func NewAccount(phoneNumber, loginPwd, payPwd string) *Account {
	a := &Account{
		PhoneNumber: phoneNumber,
		LoginPwd:    loginPwd,
		PayPwd:      payPwd,
		Model:       utils.NewModel(),
		UUID:        strings.ToUpper(uuid.NewV4().String()),
		Tls:         TLS{},
	}
	a.ClientVersion = "10500"
	a.WholeMenuVersion = "603"
	a.ActiveState = ""
	a.DeviceSerial = strings.ToUpper(uuid.NewV4().String()) + "iPhone"
	a.DeviceToken = a.genDeviceToken()

	return a
}

func (a *Account) genDeviceToken() string {
	digest := sm3.Sm3Sum([]byte(a.DeviceSerial))
	dd := make([]byte, 0x80)
	copy(dd, digest)
	digest = sm3.Sm3Sum(dd)
	return fmt.Sprintf("%x", digest)
}

func (a *Account) Save() {
	path := "./bin/" + a.PhoneNumber + ".json"
	utils.SaveJson2File(path, a)
}

type WorkGroup struct {
	http.Client
	Acc *Account
	randomKey         string
	newMobileFlag     string
	faceAuthLoginFlag string
	redisId           string
	postURLFull       []string
	PostURL           []string
	ServerIp          []string
}

func New(acc *Account) *WorkGroup {
	w := &WorkGroup{
		Acc: acc,
	}
	jar, _ := cookiejar.New(nil)
	//u, _ := url.Parse("http://127.0.0.1:8888")
	w.Client = http.Client{
		Transport: &http.Transport{
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			//DisableKeepAlives:   true,
		},
		Timeout: time.Second * 10,
		Jar:     jar,
	}
	return w
}

func (w *WorkGroup) getStokenSignMsg() string {
	// 生成sm4 key
	key := utils.RandBytes(16)
	// sm2 加密 sm4 key
	enSM2 := utils.SM2Encrypt(key, sm2X, sm2Y)
	// sm4 需要加密的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x10, 0x08, 0x00, 0x20})         // 固定
	buffer.Write(sm3.Sm3Sum([]byte(w.Acc.DeviceSerial))) // sm3数据结果长度0x20
	buffer.Write([]byte{0x10, 0x01, 0x00, 0x0B})         // 固定
	buffer.Write([]byte(w.Acc.PhoneNumber))              // 电话号码长度0xB

	enSM4 := utils.SM4ECBEncrypt(buffer.Bytes(), key)

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x02, 0x00, 0x00,
	})
	buffer.Write(enSM4)
	mac := sm3.Sm3Sum(buffer.Bytes())

	buffer.Reset()
	buffer.Write([]byte{0x31, 0x31})
	buffer.Write(mac[0x1c:])
	buffer.Write([]byte{0x00, 0xC4})
	buffer.Write(enSM2)
	buffer.Write([]byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
		0x02, 0x00, 0x00,
	})
	buffer.Write(enSM4)

	return base64.StdEncoding.EncodeToString(buffer.Bytes())
}

func (w *WorkGroup) getUserAgent() string {
	return fmt.Sprintf("bankabc %s rv:%s (iPhone; iOS 12.4.2; zh_CN)", bundleShortVersion, bundleVersion)
}

func (w *WorkGroup) getUserAgent2() string {
	return fmt.Sprintf("BankABCPro/%s CFNetwork/897.15 Darwin/18.7.0", bundleVersion)
}

func (w *WorkGroup) getXEmpEigenvalue() string {
	md5DigestData := md5.Sum([]byte(w.Acc.UUID))
	return base64.StdEncoding.EncodeToString(md5DigestData[:])
}

func (w *WorkGroup) getXEmpCookie() string {
	return fmt.Sprintf("_session_id=%s", w.Acc.Tls.sessionId)
}
