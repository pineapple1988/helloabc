package unionpay

import (
	"awesome/tools"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"

	"github.com/go-http-utils/headers"
)

func (w *Wallet) addBaseHeaders() *http.Header {
	header := &http.Header{
		"nextdataDeviceId": {w.DeviceID},
		"requestId":        {tools.NewUUID()},
		"urid":             {w.URID},
		"dfpSessionId":     {w.DFPSessionID},
		"language":         {"zh_CN"},
		"cityCd":           {"310000"}, // 上海
	}
	if w.gray != "" {
		header.Set("gray", w.gray)
	}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.UserAgent, "iPhone CHSP")
	return header
}

func (w *Wallet) sysInit() (*sysInitResp, []byte) {
	respObj := &sysInitResp{}

	// rsa加密3des key
	tripleDesKey := tools.RandBytes(24)
	enTripleDesKey, _ := tools.RSAEncrypt(tripleDesKey, sysInitRsaPub)

	// 3des 加密vid
	VID := "0000"
	if w.VID != "" {
		VID = w.VID
	}
	enVID, err := tools.TripleDESECBEncrypt([]byte(VID), tripleDesKey)
	if err != nil {
		w.log.Errorf("SysInit 3DES加密错误: %+v.", err)
		return respObj, nil
	}

	query := &url.Values{
		"currentKeyNo":  {"2"},
		"osName":        {"ios"},
		"clientVersion": {clientVersion},
		"encryptedTk":   {fmt.Sprintf("%X", enTripleDesKey)},
		"encryptedVid":  {fmt.Sprintf("%X", enVID)},
		"maxKeyNo":      {"3"},
	}

	header := w.addBaseHeaders()
	header.Set(headers.ContentType, "application/json")

	resp, err := tools.DoHTTPGet(w.c, urlSysInit, query, header)
	if err != nil {
		w.log.Errorf("sysInit DoHTTPGet出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return respObj, nil
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		w.log.Errorf("sysInit json.Unmarshal err=%+v resp=%+v", err, hex.Dump(resp))
	}

	return respObj, tripleDesKey
}

func (w *Wallet) infoCollect() {
	roll := fmt.Sprintf("%f,%f,%f", -0.65+tools.RandFloat(0.2), -0.65+tools.RandFloat(0.2), 0.45+tools.RandFloat(0.2))

	tango := fmt.Sprintf("%f,%f,%f", float32(tools.RandIntn(20))+tools.RandFloat(1)+1,
		float32(tools.RandIntn(20))+tools.RandFloat(1)+25,
		float32(tools.RandIntn(20))+tools.RandFloat(1)-10)
	acceleration := fmt.Sprintf("%f,%f,%f", tools.RandFloat(0.1), tools.RandFloat(0.1), tools.RandFloat(0.1))
	firstOpen := "false"
	if w.FirstOpen {
		firstOpen = "true"
	}

	if w.InjectAttr == "" {
		w.InjectAttr = fmt.Sprintf("%s%d", tools.RandString(32), tools.TimestampEx())
	}
	info := map[string]string{
		"3003":       "0", // isJailBreak
		"3015":       w.BatteryLevel,
		"3027":       "",
		"3039":       "false",
		"3011":       cfBundleVersion,
		"3023":       "0",
		"3035":       fmt.Sprintf("%d", w.TotalMemorySize),
		"3031":       roll, // 设备旋转速度 x,y,z
		"3008":       w.SystemVersion,
		"3004":       tools.ScreenPt(w.Model),
		"3016":       "zh_CN",
		"3012":       w.SystemVersion,
		"3024":       cfBundleID,
		"3036":       "[\n  \"192.168.0.1\"\n]", //  DNSs
		"3020":       "460",
		"3032":       "false",
		"3040":       firstOpen,
		"3009":       "zh-Hans-CN",
		"3005":       "iPhone",
		"3017":       "Local Time Zone (Asia/Shanghai (GMT+8) offset 28800)",
		"3029":       tango,
		"3001":       w.UUID,
		"3013":       fmt.Sprintf("%d", w.TotalDiskSize-w.AvailableDiskSize),
		"3025":       tools.TimeFmtEx0(), //"20210125182114079"
		"3037":       "WiFi",
		"3021":       w.CarrierCode,
		"3033":       w.SystemStartDate,
		"3041":       "2",
		"devType":    "D003",
		"3006":       w.OwnerName,
		"3018":       w.En0IPV6,
		"3002":       w.IDFV,
		"3014":       fmt.Sprintf("%d", w.AvailableDiskSize),
		"3026":       updtDeviceVersion,
		"3038":       "",
		"3010":       cfBundleID,
		"3022":       "",
		"3034":       w.ScreenBrightness,
		"injectAttr": w.InjectAttr,
		"lastSid":    w.DFPSessionID,
		"3042":       "2",
		"3030":       acceleration,
		"3007":       "iOS",
		"3019":       w.CarrierName,
	}

	fmt.Println(info)
}
