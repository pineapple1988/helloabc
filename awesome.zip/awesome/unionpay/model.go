package unionpay

type sysInitResp struct {
	Resp string `json:"resp"`
	Msg string `json:"msg"`
	Params struct {
		EncryptedVid string `json:"encryptedVid"`
		EncryptedCk string `json:"encryptedCk"`
		Sid string `json:"sid"`
		Gray string `json:"gray"`
		RespCode string `json:"respCode"`
		RespMsg string `json:"respMsg"`
	} `json:"params"`
}
