package unionpay

import (
	"awesome/tools"
	"encoding/hex"
	"fmt"
	"testing"
)

func TestRsa(t *testing.T) {
	fmt.Println(hex.Dump(sysInitRsaPub.N.Bytes()))
}

func TestAes(t *testing.T) {
	ttt := tools.TimestampEx2()
	str1 := fmt.Sprintf("%d", ttt)
	str2 := fmt.Sprintf("%f", float64(ttt)/1000000)
	fmt.Println(str1)
	fmt.Println(str2)
}
