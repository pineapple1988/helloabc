package unionpay

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"crypto/tls"
	"encoding/hex"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"time"
)

// Wallet 云闪付
type Wallet struct {
	c   *http.Client `json:"-"`
	log *log2.MyLog  `json:"-"`

	Account  string `json:"account"`
	LoginPwd string `json:"loginPwd"`
	PayPwd   string `json:"payPwd"`

	// 设备信息
	Model             string `json:"model"`
	OwnerName         string `json:"ownerName"`
	SystemVersion     string `json:"systemVersion"`
	SystemStartDate   string `json:"systemStartDate"`
	TotalMemorySize   int64  `json:"totalMemorySize"`
	TotalDiskSize     int64  `json:"totalDiskSize"`
	AvailableDiskSize int64  `json:"availableDiskSize"`
	BatteryLevel      string `json:"batteryLevel"`
	ScreenBrightness  string `json:"screenBrightness"`
	CarrierName       string `json:"carrierName"`
	CarrierCode       string `json:"carrierCode"`
	En0IPV6           string `json:"en0IPV6"`
	DeviceID          string `json:"deviceID"`
	URID              string `json:"URID"`
	DFPSessionID      string `json:"DFPSessionID"`
	VID               string `json:"VID"`
	SID               string `json:"SID"`
	UUID              string `json:"uuid"`
	IDFV              string `json:"idfv"`
	InjectAttr        string `json:"injectAttr"`
	FirstOpen         bool   `json:"firstOpen"`
	UpdateTime        uint32 `json:"updateTime"`
	RebootTime        uint32 `json:"rebootTime"`
	gray              string `json:"-"`
	desKey            []byte `json:"-"`
}

// New 创建一个新的账号
func New(account, loginPwd, payPwd string) *Wallet {
	w := &Wallet{
		Account:  account,
		LoginPwd: loginPwd,
		PayPwd:   payPwd,
	}
	w.FirstOpen = true
	w.Model = tools.NewModel()
	w.OwnerName = tools.NewOwnerName()
	w.SystemVersion = tools.NewSysVersion()
	w.TotalMemorySize = tools.PhysicalMemory(w.Model) - int64(tools.RandBetween(20*1024*1024, 200*1024*1024))
	w.TotalDiskSize = tools.NewDiskSpace(w.Model) - int64(tools.RandBetween(1*1024*1024*1024, 4*1024*1024*1024))
	w.CarrierName = tools.CarrierByPhoneNum(account)
	w.CarrierCode = tools.CarrierCode(w.CarrierName)
	w.UUID = tools.NewUUIDUpper()
	w.IDFV = tools.NewUUIDUpper()
	w.En0IPV6 = tools.NewIPV6()

	w.Save()
	return w
}

// Save 保存账号信息
func (w *Wallet) Save() {
	path := "./unionpay/bin/" + w.Account + ".json"
	tools.SaveJSON2File(path, w)
}

// NewHTTPClient 创建新的client 每个账号一个
func (w *Wallet) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	//u, _ := url.Parse("http://127.0.0.1:8888")
	//u, _ := url.Parse("http://192.168.137.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// Login 登陆操作
func (w *Wallet) Login() base.LoginResultCode {
	// 每次登陆都重新创建一个新的
	w.c = w.NewHTTPClient()
	// log
	w.log = &log2.MyLog{
		Prefix: fmt.Sprintf("[UnionPay][%s]", w.Account),
	}

	// 一些设备信息的随机
	if tools.Timestamp()-w.UpdateTime > 86400 {
		w.ScreenBrightness = fmt.Sprintf("%f", 0.4+tools.RandFloat(0.5))
		w.BatteryLevel = fmt.Sprintf("%f", float64(tools.RandBetween(43, 98))/100.00)
		if w.AvailableDiskSize != 0 {
			if tools.RandInt()%2 == 0 {
				w.AvailableDiskSize = w.AvailableDiskSize + int64(tools.RandBetween(2*1024*1024, 500*1024*1024))
			} else {
				w.AvailableDiskSize = w.AvailableDiskSize - int64(tools.RandBetween(2*1024*1024, 500*1024*1024))
			}
		} else {
			w.AvailableDiskSize = w.TotalDiskSize - int64(tools.RandBetween(2*1024*1024*1024, 6*1024*1024*1024))
		}
		w.UpdateTime = tools.Timestamp()
	}
	// 系统重启时间
	r := tools.RandInt() % 30
	if tools.Timestamp()-w.RebootTime > uint32(r*86400) {
		w.SystemStartDate = fmt.Sprintf("%f", float64(tools.TimestampEx2())/1000000)
		w.RebootTime = tools.Timestamp()
	}

	// 生成key
	sysInitResp, tripleDesKey := w.sysInit()
	if tripleDesKey == nil || sysInitResp.Resp != "00" {

	}
	w.gray = sysInitResp.Params.Gray

	w.SID = sysInitResp.Params.Sid

	ck, _ := hex.DecodeString(sysInitResp.Params.EncryptedCk)
	ck, err := tools.TripleDESECBDecrypt(ck, tripleDesKey)
	if err != nil {
		w.log.Errorf("SysInit解密DESKey错误: %+v.", err)
		return base.LoginResultFail
	}
	w.desKey, err = hex.DecodeString(string(ck))

	if err != nil {
		w.log.Errorf("SysInit转换DESKey错误: %+v.", err)
		return base.LoginResultFail
	}
	vid, _ := hex.DecodeString(sysInitResp.Params.EncryptedVid)
	vid, err = tools.TripleDESECBDecrypt(vid, w.desKey)
	if err != nil {
		w.log.Errorf("SysInit解密VID错误: %+v.", err)
		return base.LoginResultFail
	}
	w.VID = string(vid)

	return base.LoginResultSuccess
}
