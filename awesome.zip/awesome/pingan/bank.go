package pingan

import (
	"awesome/tools"
	"awesome/tools/base"
	"crypto/md5"
	"crypto/sha1"
	"crypto/tls"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"strconv"
	"time"
)

// Bank 平安银行
type Bank struct {
	Account       string       `json:"account"`     // 账号，手机号
	Password      string       `json:"password"`    // 登陆密码
	PayPassword   string       `json:"payPassword"` // 支付密码
	HardwareInfo  HardwareInfo `json:"hardwareInfo"`
	http          *http.Client
	jar           *cookiejar.Jar
	LaunchTime    string `json:"launchTime"` // 13位时间戳
	IDFV          string `json:"IDFV"`       // identifierForVendor
	TDUDID        string `json:"TDUDID"`     // TalkingData DeviceID
	DeviceID      string `json:"deviceID"`   // PAB DeviceID
	XRequestIndex int    `json:"xRequestIndex"`
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	WIFIName      string `json:"wifiName"`      // wifi名字
	WIFIMac       string `json:"wifiMac"`       // wifiMac地址
	Model         string `json:"model"`         // 设备类型
	Carrier       string `json:"carrier"`       // 运营商
	CarrierCode   string `json:"carrierCode"`   // 运营商code
	DeviceName    string `json:"deviceName"`    // 设备名称  iPhone7
	OwnerName     string `json:"ownerName"`     // 设备用户名 jj的 iPhone
	en0Ipv4       string // wifi本地地址
	brightness    string // 屏幕亮度
}

// New 创建一个新账号
func New(account, password, payPassword string) (*Bank, error) {
	b := &Bank{}

	b.Account = account
	b.Password = password
	b.PayPassword = payPassword
	b.IDFV = tools.NewUUIDUpper()
	b.TDUDID = fmt.Sprintf("h%x", md5.Sum([]byte(b.IDFV)))
	b.DeviceID = fmt.Sprintf("AUUID_%x", sha1.Sum([]byte(b.TDUDID)))

	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.WIFIMac = tools.NewMacAddress()
	b.HardwareInfo.WIFIName = tools.NewWifiName(b.HardwareInfo.WIFIMac)
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.CarrierCode = "460" + tools.CarrierCode(b.HardwareInfo.Carrier)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()

	// 保存一下
	b.save()

	return b, nil
}

func (b *Bank) save() {
	path := "./bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// Login 登陆
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.jar, _ = cookiejar.New(nil)
	b.http = &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     b.jar,
	}

	b.LaunchTime = strconv.FormatInt(tools.TimestampEx(), 10)
	b.XRequestIndex = 0

	b.generateBindToken()

	return base.LoginResultSuccess
}
