package pingan

const (
	urlGetValidCode      = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-core.get-validCode.do"
	urlInitConfig        = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-login-web.initConfig.do"
	urlGenerateBindToken = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-login-web.generateBindToken.do"
)

const (
	cfBundleShortVersion = "4.38.1"
	xAladdinVersion      = "4.3.0"
	xPluginVersion       = "6.0.31"
)

const (
	httpEncryptRSAPub = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCQaS8FRZGtEGUYqnRB5MQbc7OUK8N42ONu20nlwhaCIWggP7YSdZLYJqRDqnZgbxNTsClwy0qEl1iAji6xwRAlKDYyFVCnXjGwrTGKyBV2KIJbT88iVkoBDChauom8-k-s6_RlFQbEW8t3D1cY-ZlbdARE73izzRAjSEHrQnOHMQIDAQAB"
)
