package pingan

type baseResp struct {
	ResponseCode  string `json:"responseCode"`
	IsDisplayCode string `json:"isDisplayCode"`
}

type getValidCodeResp struct {
	baseResp
}

type initConfigResp struct {
	baseResp
	ConfigInfo string `json:"configInfo"`
}

type generateBindTokenResp struct {
	baseResp
	BindToken string `json:"bindToken"`
}

type userPwdLoginResp struct {
	baseResp
	AesBecifNo             string `json:"aesBecifNo"`
	BankType               string `json:"bankType"`
	Bflag                  string `json:"bflag"`
	Bflag4                 string `json:"bflag4"`
	BrcpSessionTicket      string `json:"brcpSessionTicket"`
	CertificateType        string `json:"certificateType"`
	ClientSafeToolsLevel   string `json:"clientSafeToolsLevel"`
	EncryBecifNo           string `json:"encryBecifNo"`
	EncryMid               string `json:"encryMid"`
	IsBindDevice           string `json:"isBindDevice"`
	IsFrequentlyUsedDevice string `json:"isFrequentlyUsedDevice"`
	LicenseFlag            string `json:"licenseFlag"`
	MergeAccountFlag       string `json:"mergeAccountFlag"`
	Mid                    string `json:"mid"`
	OpenTools              string `json:"openTools"`
	SetTool                string `json:"setTool"`
	Sl                     string `json:"sl"`
	ToaModifyFlag          string `json:"toaModifyFlag"`
	Token                  string `json:"token"`
	Uflag                  string `json:"uflag"`
	Uflag4                 string `json:"uflag4"`
	UserType               string `json:"userType"`
}
