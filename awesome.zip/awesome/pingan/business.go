package pingan

import (
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"compress/gzip"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"

	"github.com/go-http-utils/headers"
)

func (b *Bank) userAgent() string {
	return fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 %s AladdinHybrid/4.3.0 (PAEBank %s) subContracting/AppStore deviceId/%s UnionPay/1.0 PABANK deviceType/1 networkState/WIFI  device-dpr/2 device-dr/%d*%d", strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_"), b.HardwareInfo.DeviceName, cfBundleShortVersion, b.DeviceID, tools.ScreenHeightPt(b.HardwareInfo.Model), tools.ScreenWidthPt(b.HardwareInfo.Model))
}

func (b *Bank) addBaseQuery(query *url.Values) *url.Values {
	query.Set("channelId", "netbank")
	query.Set("subContracting", "AppStore")
	return query
}

func (b *Bank) addBaseHeader(header *http.Header) *http.Header {
	header.Set(headers.Accept, "*/*")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	header.Set("bank-mobile-brand", "Apple")
	header.Set("bank-mobile-model", b.HardwareInfo.Model)
	header.Set("X-Aladdin-Version", xAladdinVersion)
	header.Set("X-Plugin-Version", xPluginVersion)
	header.Set("X-App-Version", cfBundleShortVersion)
	header.Set("X-Plugin-Name", "member")
	return header
}

func (b *Bank) doHTTP(method, u string, querys *url.Values, headers *http.Header, body []byte) []byte {
	url0, err := url.Parse(u)
	if err != nil {
		log2.Errorf("doHTTP url.Parse url=%s error=%+v", u, err)
		return nil
	}
	query0 := url0.Query()
	// 添加query
	if querys != nil {
		for key, value := range *querys {
			if value == nil {
				continue
			}
			for _, item := range value {
				query0.Add(key, item)
			}
		}
	}
	url0.RawQuery = query0.Encode()

	req, err := http.NewRequest(method, url0.String(), bytes.NewReader(body))
	if err != nil {
		log2.Errorf("doHTTP http.NewRequest method=%s, url=%s, error=%+v", method, url0.String(), err)
		return nil
	}
	// 添加header
	if headers != nil {
		for key, value := range *headers {
			if value == nil {
				continue
			}
			for _, item := range value {
				headers.Add(key, item)
			}
		}
	}

	resp, err := b.http.Do(req)
	if err != nil {
		log2.Errorf("doHTTP b.http.Do url=%s, error=%+v", url0.String(), err)
		return nil
	}

	defer resp.Body.Close()

	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			log2.Errorf("doHTTP gzip.NewReader url=%s, error=%+v", url0.String(), err)
			return nil
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		log2.Errorf("doHTTP ioutil.ReadAll url=%s, error=%+v", url0.String(), err)
		return nil
	}

	return respBody
}

// http get
func (b *Bank) doHTTPGET(u string, query *url.Values, header *http.Header) []byte {
	return b.doHTTP("GET", u, query, header, nil)
}

// http post
func (b *Bank) doHTTPPOST(u string, query *url.Values, header *http.Header, body []byte) []byte {
	return b.doHTTP("POST", u, query, header, body)
}

func (b *Bank) getValidCode() *getValidCodeResp {
	query := &url.Values{}

	header := b.addBaseHeader(&http.Header{})
	header.Set(headers.Accept, "application/json")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=utf-8")

	form := &url.Values{}
	form.Set("deviceId", b.DeviceID)
	form.Set("channelId", "netbank")
	form.Set("deviceType", "ios")
	form.Set("type", "1")
	form.Set("appVersion", "2.0")
	form.Set("scene", "1")
	form.Set("subContracting", "AppStore")
	req := form.Encode()

	resp := b.doHTTPPOST(urlGetValidCode, query, header, []byte(req))
	if resp == nil {
		log2.Error("getValidCode doHTTPPOST resp == nil")
		return nil
	}
	log2.Info("getValidCode resp >>>>>>>>")
	log2.InfoJSON(string(resp))
	respObj := &getValidCodeResp{}
	if err := json.Unmarshal(resp, respObj); err != nil {
		log2.Errorf("getValidCode resp=\r\n%s \r\nerror=%+v", hex.Dump(resp), err)
		return nil
	}

	return respObj
}

func (b *Bank) initConfig() *initConfigResp {
	query := b.addBaseQuery(&url.Values{})

	header := b.addBaseHeader(&http.Header{})
	header.Set(headers.Accept, "application/json")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=utf-8")

	resp := b.doHTTPGET(urlInitConfig, query, header)
	if resp == nil {
		log2.Error("initConfig doHTTPPOST resp == nil")
		return nil
	}
	log2.Info("initConfig resp >>>>>>>>")
	log2.InfoJSON(string(resp))
	respObj := &initConfigResp{}
	if err := json.Unmarshal(resp, respObj); err != nil {
		log2.Errorf("initConfig resp=\r\n%s \r\nerror=%+v", hex.Dump(resp), err)
		return nil
	}

	return respObj
}

func (b *Bank) generateBindToken() *generateBindTokenResp {
	query := b.addBaseQuery(&url.Values{})
	query.Set("deviceId", b.DeviceID)

	header := b.addBaseHeader(&http.Header{})
	header.Set(headers.Accept, "application/json")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=utf-8")

	resp := b.doHTTPGET(urlGetValidCode, query, header)
	if resp == nil {
		log2.Error("generateBindToken doHTTPPOST resp == nil")
		return nil
	}
	log2.Info("generateBindToken resp >>>>>>>>")
	log2.InfoJSON(string(resp))
	respObj := &generateBindTokenResp{}
	if err := json.Unmarshal(resp, respObj); err != nil {
		log2.Errorf("generateBindToken resp=\r\n%s \r\nerror=%+v", hex.Dump(resp), err)
		return nil
	}

	return respObj
}

func (b *Bank) userPwdLogin() *userPwdLoginResp {
	query := b.addBaseQuery(&url.Values{})
	query.Set("deviceId", b.DeviceID)

	header := b.addBaseHeader(&http.Header{})
	header.Set(headers.Accept, "application/json")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=utf-8")

	form := &url.Values{}
	form.Set("deviceId", b.DeviceID)
	form.Set("channelId", "netbank")
	form.Set("deviceType", "ios")
	form.Set("type", "1")
	form.Set("appVersion", "2.0")
	form.Set("scene", "1")
	form.Set("subContracting", "AppStore")
	req := form.Encode()

	resp := b.doHTTPPOST(urlGetValidCode, query, header, []byte(req))
	if resp == nil {
		log2.Error("userPwdLogin doHTTPPOST resp == nil")
		return nil
	}
	log2.Info("userPwdLogin resp >>>>>>>>")
	log2.InfoJSON(string(resp))
	respObj := &userPwdLoginResp{}
	if err := json.Unmarshal(resp, respObj); err != nil {
		log2.Errorf("userPwdLogin resp=\r\n%s \r\nerror=%+v", hex.Dump(resp), err)
		return nil
	}

	return respObj
}
