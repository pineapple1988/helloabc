package bocom

import (
	"awesome/tools"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-http-utils/headers"
	"net/http"
	"net/url"
	"strings"
)

func (b *Bank) addBaseHeader(header *http.Header) *http.Header {
	header.Set(headers.Accept, "*/*")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "gzip,deflate")
	return header
}

func (b *Bank) genGUID() (string, error) {
	type guidReq struct {
		Filed1 int32
		Filed2 int32
		Filed3 int32
		Filed4 int32
		Filed5 string
		Filed6 string
		Filed7 string
		Filed8 string
		Filed9 struct {
			Field0 int32
			Filed1 int32
			Filed2 int32
			Filed3 int32
		}
		Filed10 string
		Filed11 string
		Filed12 int32
		Filed13 string
		Filed14 string
		Filed15 string
	}
	type req struct {
		Req guidReq
	}
	reqData, err := tmfMarshal(&req{
		Req: guidReq{
			Filed1: 3,
			Filed2: 3,
			Filed3: 301,
			Filed4: 6177,
			Filed5: "",
			Filed6: tools.NewUUIDUpper(),
			Filed7: tools.NewUUIDUpper(),
			Filed8: "",
			Filed9: struct {
				Field0 int32
				Filed1 int32
				Filed2 int32
				Filed3 int32
			}{
				Filed1: 4,
				Filed2: 0,
				Filed3: 2,
			},
			Filed10: b.HardwareInfo.Model,
			Filed11: b.HardwareInfo.SystemVersion,
			Filed12: 1,
			Filed13: "",
			Filed14: "",
			Filed15: "",
		},
	})
	if err != nil {
		return "", err
	}

	//fmt.Println(hex.Dump(reqData))

	csshark := &csShark{
		SeqNo:  b.nextSeqNo(),
		Field2: 0,
		Fin: sharkFin{
			Field1:      1,
			Field2:      0,
			GUID:        b.GUID,
			Field4:      "",
			SessionID:   b.sessionID,
			BuildNumber: 4,
			Field7:      14,
			AccountID:   0,
			Field9:      0,
			Field10:     "",
			VTicket: vidTicket{
				Kind:   0,
				Ticket: b.VTicket,
			},
		},
	}
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       3,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  nil,
			ReqDataType: 0,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return "", err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return "", err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return "", err
	}
	type guidRes struct {
		GUID string
	}
	if len(scshark.Sashimis) >= 1 {
		guid := &guidRes{}
		err = tmfUnmarshal(scshark.Sashimis[0].RspData, guid)
		if err != nil {
			return "", err
		}
		return guid.GUID, nil
	}
	return "", nil
}

func (b *Bank) genVTicket() (string, error) {
	// 固定的
	reqData := []byte{
		0x00, 0x02, 0x1D, 0x00, 0x00, 0x24, 0x0A, 0x0A, 0x0C, 0x1C, 0x2C, 0x3C, 0x46, 0x00, 0x56, 0x00,
		0x66, 0x00, 0x76, 0x00, 0x8A, 0x1C, 0x2C, 0x3C, 0x0B, 0x96, 0x00, 0xA6, 0x00, 0xBC, 0xC6, 0x00,
		0xD6, 0x00, 0xE6, 0x00, 0x0B, 0x0B, 0x16, 0x00, 0x26, 0x00,
	}
	reqHeader := []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00} // 空头部
	csshark := &csShark{
		SeqNo:  b.nextSeqNo(),
		Field2: 0,
		Fin: sharkFin{
			Field1:      1,
			Field2:      0,
			GUID:        b.GUID,
			Field4:      "",
			SessionID:   b.sessionID,
			BuildNumber: 4,
			Field7:      14,
			AccountID:   0,
			Field9:      0,
			Field10:     "",
			VTicket: vidTicket{
				Kind:   0,
				Ticket: b.VTicket,
			},
		},
	}
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       5010,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 0,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return "", err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return "", err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return "", err
	}
	type vTicketResp struct {
		Kind   int32
		Ticket []byte
	}
	type vTicketRespCtx struct {
		Ticket string
	}
	if len(scshark.Sashimis) >= 1 {
		v := &vTicketResp{}
		err = tmfUnmarshal(scshark.Sashimis[0].RspData, v)
		if err != nil {
			return "", err
		}

		vv := &vTicketRespCtx{}
		err := tmfUnmarshal(v.Ticket, vv)
		if err != nil {
			return "", err
		}
		return vv.Ticket, nil
	}
	return "", nil
}

func (b *Bank) genDiviceID() (string, error) {
	reqData, err := tmfMarshal(&vidTicket{
		Kind:   2,
		Ticket: b.VTicket,
	})
	if err != nil {
		return "", err
	}

	reqHeader := []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00} // 空头部
	csshark := &csShark{
		SeqNo:  b.nextSeqNo(),
		Field2: 0,
		Fin: sharkFin{
			Field1:      1,
			Field2:      0,
			GUID:        b.GUID,
			Field4:      "",
			SessionID:   b.sessionID,
			BuildNumber: 4,
			Field7:      14,
			AccountID:   0,
			Field9:      0,
			Field10:     "",
			VTicket: vidTicket{
				Kind:   2,
				Ticket: b.VTicket,
			},
		},
	}
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       5011,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 0,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return "", err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return "", err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return "", err
	}
	type diviceIDResp struct {
		Kind     int32
		DiviceID string
	}
	if len(scshark.Sashimis) >= 1 {
		d := &diviceIDResp{}
		err = tmfUnmarshal(scshark.Sashimis[0].RspData, d)
		if err != nil {
			return "", err
		}

		return d.DiviceID, nil
	}
	return "", nil
}

func (b *Bank) initialization() error {
	reqData1 := []byte(b.basePairs(&url.Values{
		"tranCode": {"SC0201"},
	}))
	reqHeader1 := b.genHeader("SC0201")

	reqData2 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"pageCode":       {"SYP0001"},
		"processCode":    {"TP0004"},
		"targetPageCode": {""},
	}))
	reqHeader2 := b.genHeader("TP0004")

	reqData3 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"flows":          {""},
		"pageCode":       {"SYP0001"},
		"processCode":    {"TP0001"},
		"targetPageCode": {""},
	}))
	reqHeader3 := b.genHeader("TP0001")

	reqData4 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"pageCode":       {""},
		"processCode":    {"CU0007"},
		"queryFlag":      {"recharge_unable_version"},
		"targetPageCode": {""},
	}))
	reqHeader4 := b.genHeader("CU0007")

	reqData5 := []byte(b.basePairs(&url.Values{
		"processCode": {"MB0702"},
	}))
	reqHeader5 := b.genHeader("MB0702")

	reqData6 := []byte(b.basePairs(&url.Values{
		"processCode": {"MB0002"},
	}))
	reqHeader6 := b.genHeader("MB0002")

	reqData7 := []byte(b.basePairs(&url.Values{
		"processCode": {"SY0033"},
		"tranCode":    {"SY0033"},
	}))
	reqHeader7 := b.genHeader("SY0033")

	reqData8 := []byte(b.basePairs(&url.Values{
		"alias":       {""},
		"processCode": {"SY1018"},
	}))
	reqHeader8 := b.genHeader("SY1018")

	reqData9 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"NAC2001":        {"NAC2001"},
		"processCode":    {"ZY0003"},
		"targetPageCode": {"NAC2001"},
	}))
	reqHeader9 := b.genHeader("ZY0003")

	reqData10 := []byte(b.basePairs(&url.Values{
		"flag":        {"1"},
		"processCode": {"SY0034"},
		"srcPageCode": {"NWM0001"},
	}))
	reqHeader10 := b.genHeader("SY0034")

	reqData11 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"pageCode":       {""},
		"processCode":    {"ME0009"},
		"targetPageCode": {""},
		"tranCode":       {"ME0009"},
	}))
	reqHeader11 := b.genHeader("ME0009")

	reqData12 := []byte(b.basePairs(&url.Values{
		"customerNo":    {""},
		"isClearUnread": {"0"},
		"page":          {"1"},
		"pageSize":      {"1000"},
		"processCode":   {"ME0016"},
		"tranCode":      {"ME0016"},
	}))
	reqHeader12 := b.genHeader("ME0016")

	reqData13 := []byte(b.basePairs(&url.Values{
		"hashs":       {b.Hashs},
		"processCode": {"MB0303"},
	}))
	reqHeader13 := b.genHeader("MB0303")

	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData1,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader1,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData2,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader2,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData3,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader3,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData4,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader4,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData5,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader5,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData6,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader6,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData7,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader7,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData8,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader8,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData9,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader9,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData10,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader10,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData11,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader11,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData12,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader12,
			ReqDataType: 1,
		}, {
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData13,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader13,
			ReqDataType: 1,
		},
	}

	postData, err := b.genPostData(csshark)
	if err != nil {
		return err
	}

	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
		if s.SeqNo == 13 {
			mb0303 := &mb0303Resp{}
			if err := json.Unmarshal(s.RspData, mb0303); err != nil {
				return err
			}
			// 更新hashs
			if len(mb0303.RSPBODY.PicList) >= 1 {
				pic := mb0303.RSPBODY.PicList[0]
				b.Hashs = fmt.Sprintf("%s,%s,%s,%s%s", pic.PicHashCode, pic.BeginDate, pic.EndDate, sharkDownURL,
					pic.ManageURL)
			}
			b.mSessionId = mb0303.RSPHEAD.MSessionID
		}
	}
	//2 14
	type item struct {
		Filed1 string
		Filed2 int32
		Filed3 int32
	}
	type second struct {
		Filed1 int32
		Filed2 int32
		Filed3 int32
		Filed4 int32
		Filed5 []item
	}
	reqData14, err := tmfMarshal(&second{
		Filed1: 1,
		Filed2: 0,
		Filed3: 1,
		Filed4: 0,
		Filed5: []item{
			{
				Filed1: "static",
				Filed2: 0,
				Filed3: 4585,
			}, {
				Filed1: "life",
				Filed2: 0,
				Filed3: 4562,
			}, {
				Filed1: "loan_home",
				Filed2: 0,
				Filed3: 4350,
			}, {
				Filed1: "HP",
				Filed2: 0,
				Filed3: 4347,
			}, {
				Filed1: "transfer",
				Filed2: 0,
				Filed3: 4395,
			}, {
				Filed1: "login",
				Filed2: 0,
				Filed3: 4557,
			},
		},
	})
	if err != nil {
		return err
	}
	reqHeader14 := []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00} // 空头部
	csshark = b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       5001,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData14,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader14,
			ReqDataType: 0,
		},
	}
	postData, err = b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err = tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err = b.parseRspData(resp)
	if err != nil {
		return err
	}

	//b.Info(hex.Dump(scshark.Sashimis[0].RspData))
	//3 15
	reqData15 := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"pageCode":       {"SYP0001"},
		"processCode":    {"TP0004"},
		"targetPageCode": {""},
	}))
	reqHeader15 := b.genHeader("TP0004")
	csshark = b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData15,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader15,
			ReqDataType: 1,
		},
	}
	postData, err = b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err = tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err = b.parseRspData(resp)
	if err != nil {
		return err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
	}
	return nil
}

func (b *Bank) tp0004() error {
	//4 16
	reqData := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"pageCode":       {"SYP0001"},
		"processCode":    {"TP0004"},
		"targetPageCode": {""},
	}))
	reqHeader := b.genHeader("TP0004")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
	}

	return nil
}

func (b *Bank) tp0002() error {
	// 5 17
	reqData := []byte(b.basePairs(&url.Values{
		"alias":          {""},
		"deviceId":       {b.UUID},
		"flows":          {""},
		"pageCode":       {"SYP0001"},
		"processCode":    {"TP0002"},
		"targetPageCode": {""},
	}))
	reqHeader := b.genHeader("TP0002")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
	}

	return nil
}

func (b *Bank) ps0006() error {
	// 6 18
	values := &url.Values{}
	values.Set("MSessionId", b.mSessionId)
	values.Set("clientIP", b.clientIP)
	values.Set("contractNo", b.ContractNO)
	values.Set("ecifNo", "")
	values.Set("mlds_model", b.HardwareInfo.DeviceName)
	values.Set("mlds_version", b.HardwareInfo.SystemVersion)
	values.Set("native", "iOS")
	values.Set("processCode", "PS0005")

	reqData := []byte(strings.ReplaceAll(values.Encode(), "+", "%20"))
	reqHeader := b.genHeader("PS0005")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
	}
	//7 19
	type item struct {
		Filed1 string
		Filed2 int32
		Filed3 int32
	}
	type second struct {
		Filed1 int32
		Filed2 int32
		Filed3 int32
		Filed4 int32
		Filed5 []item
	}
	reqData19, err := tmfMarshal(&second{
		Filed1: 0,
		Filed2: 0,
		Filed3: 1,
		Filed4: 0,
		Filed5: []item{
			{
				Filed1: "login",
				Filed2: 0,
				Filed3: 4557,
			}, {
				Filed1: "static",
				Filed2: 0,
				Filed3: 4585,
			},
		},
	})
	if err != nil {
		return err
	}
	reqHeader19 := []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00} // 空头部
	csshark = b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       5001,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData19,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader19,
			ReqDataType: 0,
		},
	}
	postData, err = b.genPostData(csshark)
	if err != nil {
		return err
	}
	resp, err = tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return err
	}
	scshark, err = b.parseRspData(resp)
	if err != nil {
		return err
	}
	return nil
}

// 返回一个publicKey
func (b *Bank) mb1995() (*mb1995Resp, error) {
	// 8 20
	reqData := []byte(b.basePairs(&url.Values{
		"processCode": {"MB1995"},
	}))
	reqHeader := b.genHeader("MB1995")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return nil, err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return nil, err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return nil, err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
		mb1995R := &mb1995Resp{}
		if err := json.Unmarshal(s.RspData, mb1995R); err != nil {
			return nil, err
		}
		return mb1995R, nil
	}
	return nil, errors.New("mb1995没有返回数据")
}

func (b *Bank) mb0000(pubKey string) (*mb0000Resp, error) {
	// 登陆包
	// 9 21
	// 加密登陆密码
	enPwd, err := b.passwordDoSomething(b.LoginPwd, pubKey)
	if err != nil {
		return nil, err
	}
	reqData := []byte(b.basePairs(&url.Values{
		"IMEI":           {"13131312123113132"},
		"alias":          {b.Account},
		"cardDateLost":   {"0"},
		"changeUserFlag": {"0"},
		"fivePointLost":  {"0"},
		"method":         {""},
		"ninePageCode":   {"NLG0001"},
		"pageCode":       {"NLG0001"},
		"paramTrackCode": {"MB0000"},
		"password":       {enPwd},
		"processCode":    {"MB0000"},
		"targetPageCode": {"NLG0001"},
	}))
	reqHeader := b.genHeader("MB0000")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return nil, err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return nil, err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return nil, err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
		mb0000R := &mb0000Resp{}
		if err := json.Unmarshal(s.RspData, mb0000R); err != nil {
			return nil, err
		}
		return mb0000R, nil
	}
	return nil, errors.New("mb0000没有返回数据")
}

// 查询卡号
func (b *Bank) ac0000() (*ac0000Resp, error) {
	reqData := []byte(b.basePairs(&url.Values{
		"accountType":    {"1"},
		"cardDateLost":   {"0"},
		"fivePointLost":  {"0"},
		"flag":           {"10"},
		"lossFlag":       {"1"},
		"method":         {""},
		"ninePageCode":   {"NAC0002"},
		"pageCode":       {"NAC0002"},
		"processCode":    {"AC0000"},
		"qryFaceflag":    {"1"},
		"queryBalance":   {"0"},
		"targetPageCode": {"NAC0002"},
	}))
	reqHeader := b.genHeader("AC0000")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return nil, err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return nil, err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return nil, err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
		ac0000R := &ac0000Resp{}
		if err := json.Unmarshal(s.RspData, ac0000R); err != nil {
			return nil, err
		}
		return ac0000R, nil
	}
	return nil, errors.New("ac0000没有返回数据")
}

// 账单列表
func (b *Bank) ac0005(cardNO, beginDate, endDate, page string) (*ac0005Resp, error) {
	reqData := []byte(b.basePairs(&url.Values{
		"DCFlag":                {""},
		"accName":               {""},
		"accNo":                 {""},
		"account":               {cardNO},
		"bankName":              {"false"},
		"beginDate":             {beginDate},
		"blanceFlag":            {"0"},
		"changeColorflag":       {"true"},
		"endDate":               {endDate},
		"leftTextFlag":          {"true"},
		"monthValue":            {""},
		"beginRecord":           {""},
		"cardDateLost":          {"0"},
		"code":                  {"0005"},
		"currency":              {"CNY"},
		"dateFlag":              {"0"},
		"fivePointLost":         {"0"},
		"lastPage":              {""},
		"method":                {""},
		"month":                 {""},
		"ninePageCode":          {"NAC0002"},
		"page":                  {page},
		"pageCode":              {"NAC0002"},
		"pageSize":              {"20"},
		"processCode":           {"AC0005"},
		"remark":                {""},
		"summaryInput":          {""},
		"targetPageCode":        {"NAC0002"},
		"tradeAccountNameInput": {""},
		"tradeBank":             {""},
		"tradeBankFlag":         {""},
		"tradeBankNameInput":    {""},
		"tradePlace":            {""},
		"tradeWay":              {""},
	}))
	reqHeader := b.genHeader("AC0005")
	csshark := b.genShark()
	csshark.Sashimis = []csSashimi{
		{
			CmdID:       0,
			SeqNo:       b.nextSashimiSeqNo(),
			Field3:      0,
			ReqData:     reqData,
			Push:        clientPush{ID: 0},
			ReqHeaders:  reqHeader,
			ReqDataType: 1,
		},
	}
	postData, err := b.genPostData(csshark)
	if err != nil {
		return nil, err
	}
	resp, err := tools.DoHTTPPostForm(b.Client, sharkCMDURL, nil, b.addBaseHeader(&http.Header{}), postData)
	if err != nil {
		return nil, err
	}
	scshark, err := b.parseRspData(resp)
	if err != nil {
		return nil, err
	}
	for _, s := range scshark.Sashimis {
		b.InfoJson(fmt.Sprintf("seq = %d", s.SeqNo), string(s.RspData))
		ac0005R := &ac0005Resp{}
		if err := json.Unmarshal(s.RspData, ac0005R); err != nil {
			return nil, err
		}
		return ac0005R, nil
	}
	return nil, errors.New("ac0005没有返回数据")
}
