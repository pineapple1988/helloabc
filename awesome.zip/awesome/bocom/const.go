package bocom

const (
	// BCMServerConfigProdEx.plist
	sharkCMDSM2PublicKeyX = "B7EFBA8BC1C3FDB1F433CA1A483B8878083FDCF99426655A7C44D2005A56026D"
	sharkCMDSM2PublicKeyY = "A1D476AD20C2EB7E5F2A82A2499969BB4AC76292F067A8F0DC9E652B156F6CCF"
	sharkCMDProductKey    = "app-87wnhc41qu"
	sharkCMDURL           = "http://mbank.95559.com.cn:30013"
	sharkDownURL          = "https://mbank.95559.com.cn:8888/mobs"
	cfBundleVersion       = "4.0.2"
)
