package bocom

import (
	"awesome/tools"
	"awesome/tools/base"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
)

// 交通银行
type Bank struct {
	Account          string         `json:"account"`  // 账号，手机号
	LoginPwd         string         `json:"loginPwd"` // 登陆密码
	PayPwd           string         `json:"payPwd"`   // 支付密码
	HardwareInfo     HardwareInfo   `json:"hardwareInfo"`
	GUID             string         `json:"GUID"`
	UUID             string         `json:"UUID"`
	DeviceID         string         `json:"deviceId"`
	VTicket          string         `json:"vTicket"`
	Hashs            string         `json:"hashs"`
	EcifNO           string         `json:"ecifNo"`
	ContractNO       string         `json:"contractNo"`
	Client           *http.Client   `json:"-"`
	Jar              *cookiejar.Jar `json:"-"`
	sm4Key           []byte
	clientIP         string
	seqNO            int32
	sashimiSeqNo     int32
	mSessionId       string
	sessionID        string
	sessionStartTime int32
	expTime          int32
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	Model         string `json:"model"`         // 设备类型
	ScreenSize    string `json:"screenSize"`    // 分辨率
	Carrier       string `json:"carrier"`       // 运营商
	DeviceName    string `json:"deviceName"`    // 设备名称  iPhone 7
	OwnerName     string `json:"ownerName"`     // 设备用户名 jj的 iPhone
	KernelVersion string `json:"kernelVersion"` // 内核版本
	//CarrierCode   string `json:"carrierCode"`   // 运营商code
	//En0Ipv4       string `json:"en0Ipv4"`       // wifi本地地址
	//Brightness    string `json:"-"`             // 屏幕亮度
}

// 创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:      account,
		LoginPwd:     loginPwd,
		PayPwd:       payPwd,
		HardwareInfo: HardwareInfo{},
	}
	b.UUID = tools.NewUUIDUpper()

	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.ScreenSize = tools.ScreenPx(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()
	b.HardwareInfo.KernelVersion = tools.KernelVersion(b.HardwareInfo.SystemVersion)

	return b
}

func (b *Bank) Save() {
	path := "./bocom/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////生成一些需要的东西////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

func (b *Bank) userAgent() string {
	return fmt.Sprintf("Bocom/%s CFNetwork/1120 Darwin/%s", cfBundleVersion, b.HardwareInfo.KernelVersion)
}

func (b *Bank) nextSeqNo() int32 {
	b.seqNO += 1
	return b.seqNO
}

func (b *Bank) nextSashimiSeqNo() int32 {
	b.sashimiSeqNo += 1
	return b.sashimiSeqNo
}

func (b *Bank) basePairs(values *url.Values) string {
	values.Add("MSessionId", b.mSessionId)
	values.Add("clientIP", b.clientIP)
	values.Add("clientVersion", fmt.Sprintf("IP-UMP-%s-000000", cfBundleVersion))
	values.Add("contractNo", b.ContractNO)
	values.Add("diviceId", b.DeviceID)
	values.Add("ecifNo", b.EcifNO)
	values.Add("isWap", "0")
	values.Add("mlds_model", b.HardwareInfo.DeviceName)
	values.Add("mlds_version", b.HardwareInfo.SystemVersion)
	values.Add("native", "iOS")

	if values == nil {
		return ""
	}
	var buf strings.Builder
	keys := make([]string, 0, len(*values))
	for k := range *values {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		vs := (*values)[k]
		keyEscaped := url.PathEscape(k)
		for _, v := range vs {
			if buf.Len() > 0 {
				buf.WriteByte('&')
			}
			buf.WriteString(keyEscaped)
			buf.WriteByte('=')
			buf.WriteString(url.PathEscape(v))
		}
	}
	return buf.String()
}

func (b *Bank) genShark() *csShark {
	return &csShark{
		SeqNo:  b.nextSeqNo(),
		Field2: 0,
		Fin: sharkFin{
			Field1:      1,
			Field2:      0,
			GUID:        b.GUID,
			Field4:      "",
			SessionID:   b.sessionID,
			BuildNumber: 4,
			Field7:      14,
			AccountID:   0,
			Field9:      0,
			Field10:     "",
			VTicket: vidTicket{
				Kind:   2,
				Ticket: b.VTicket,
			},
		},
	}
}

func (b *Bank) genHeader(cmd string) []byte {
	headerData, _ := tmfMarshal(&csHeader{
		Headers: map[string]string{
			"Content-Type": "application/x-www-form-urlencoded; charset=utf-8; application/json",
		},
		Cookies: nil,
		Queries: nil,
		Cmd:     cmd,
	})

	return headerData
}

func (b *Bank) genSM4Key() []byte {
	key := make([]byte, 0x10)
	for i := 0; i < len(key); i++ {
		key[i] = byte(tools.RandInt()%0x5f + 0x20)
	}
	return key
}

func (b *Bank) passwordDoSomething(in, pubKey string) (string, error) {
	// 生成32位随机数作为aes256 key
	aesKey := tools.RandBytes(32)
	// 加密密码
	enPwd, err := tools.AESECBEncrypt([]byte(in), aesKey)
	if err != nil {
		return "", err
	}
	// 解析rsa key
	pub, err := base64.StdEncoding.DecodeString(pubKey)
	if err != nil {
		return "", err
	}
	pubP, err := x509.ParsePKIXPublicKey(pub)
	if err != nil {
		return "", err
	}

	enKey, err := tools.RSAEncrypt(aesKey, pubP.(*rsa.PublicKey))
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%X %X", enPwd, enKey), nil
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////逻辑业务////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

func (b *Bank) Login() base.LoginResultCode {
	b.Jar, _ = cookiejar.New(nil)
	b.Client = &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     b.Jar,
	}

	b.clientIP = "192.168.2." + strconv.Itoa(int(tools.RandInt()%127))

	// 生成GUID
	if b.GUID == "" {
		guid, err := b.genGUID()
		if guid != "" {
			// 更新guid
			b.GUID = guid
			b.Infof("更新GUID = %s", guid)
		} else {
			// 更新guid失败
			b.Errorf("更新GUID失败 err=%+v", err)
			return base.LoginResultFail
		}
	}
	// 生成vTicket
	if b.VTicket == "" {
		ticket, err := b.genVTicket()
		if ticket != "" {
			b.VTicket = ticket
			b.Infof("更新VTicket = %s", ticket)
		} else {
			b.Errorf("更新ticket失败 err=%+v", err)
			return base.LoginResultFail
		}
	}
	// 生成diviceid
	if b.DeviceID == "" {
		diviceID, err := b.genDiviceID()
		if diviceID != "" {
			b.DeviceID = diviceID
			b.Infof("更新DeviceID = %s", diviceID)
		} else {
			b.Errorf("更新DeviceID失败 err=%+v", err)
			return base.LoginResultFail
		}
	}

	err := b.initialization()
	if err != nil {
		b.Errorf("初始化返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	err = b.tp0004()
	if err != nil {
		b.Errorf("tp0004返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	err = b.tp0002()
	if err != nil {
		b.Errorf("tp0002返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	err = b.ps0006()
	if err != nil {
		b.Errorf("ps0006返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	mb1995, err := b.mb1995()
	if err != nil {
		b.Errorf("mb1995返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	if mb1995.RSPBODY.PublicKey == "" {
		b.Errorf("mb1995没有返回publicKey code=%s, msg=%s", mb1995.RSPHEAD.ERRORCODE, mb1995.RSPHEAD.ERRORMESSAGE)
		return base.LoginResultFail
	}

	mb0000, err := b.mb0000(mb1995.RSPBODY.PublicKey)
	if err != nil {
		b.Errorf("mb0000返回了错误 err=%+v", err)
		return base.LoginResultFail
	}
	if mb0000.RSPBODY.ContractNo == "" {
		b.Errorf("mb0000没有返回用户id code=%s, msg=%s", mb0000.RSPHEAD.ERRORCODE, mb0000.RSPHEAD.ERRORMESSAGE)
		return base.LoginResultFail
	}

	b.ContractNO = mb0000.RSPBODY.ContractNo
	b.EcifNO = mb0000.RSPBODY.EcifNo

	return base.LoginResultSuccess
}

// 查询当前卡列表
func (b *Bank) CardList() *ac0000Resp {
	ac0000, err := b.ac0000()
	if err != nil {
		b.Errorf("ac0000返回了错误 err=%+v", err)
		return nil
	}
	if len(ac0000.RSPBODY.MyAccountList) <= 0 {
		b.Errorf("ac0000没有查询到账号 code=%s, msg=%s", ac0000.RSPHEAD.ERRORCODE, ac0000.RSPHEAD.ERRORMESSAGE)
		return nil
	}

	return ac0000
}

// 查询账单
// page 从1开始
// beginData eg 20191201
// endDate eg 20191228 时间跨度最长为2年
// cardNo 卡号
func (b *Bank) BillList(page int, beginData, endData, cardNo string) *ac0005Resp {
	ac0005, err := b.ac0005(cardNo, beginData, endData, strconv.Itoa(page))
	if err != nil {
		b.Errorf("ac0005返回了错误 err=%+v", err)
		return nil
	}
	if ac0005.RSPHEAD.TRANSUCCESS != "1" {
		b.Errorf("ac0005查询账单失败 code=%s, msg=%s", ac0005.RSPHEAD.ERRORCODE, ac0005.RSPHEAD.ERRORMESSAGE)
		return nil
	}

	return ac0005
}
