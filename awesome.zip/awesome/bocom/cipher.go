package bocom

import (
	"awesome/tools"
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"reflect"
)

/////////////////////////////////////////序列化///////////////////////////////////////////////
type buffer struct {
	p      []byte
	reader *bytes.Reader
}

func newBuffer(data []byte) *buffer {
	return &buffer{
		reader: bytes.NewReader(data),
	}
}

func int64ToBytes(i int64) []byte {
	buf := make([]byte, 8)
	binary.BigEndian.PutUint64(buf, uint64(i))
	return buf
}

func bytesToInt64(buf []byte) int64 {
	return int64(binary.BigEndian.Uint64(buf))
}

func int32ToBytes(i int32) []byte {
	buf := make([]byte, 4)
	binary.BigEndian.PutUint32(buf, uint32(i))
	return buf
}

func bytesToInt32(buf []byte) int32 {
	return int32(binary.BigEndian.Uint32(buf))
}

func int16ToBytes(i int16) []byte {
	buf := make([]byte, 2)
	binary.BigEndian.PutUint16(buf, uint16(i))
	return buf
}

func bytesToInt16(buf []byte) int16 {
	return int16(binary.BigEndian.Uint16(buf))
}

func (buf *buffer) writeByte(data byte, index int) {
	if data > 0 {
		if index > 0xe {
			buf.p = append(buf.p, 0xf0)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index))
		}
		buf.p = append(buf.p, data)
	} else {
		if index > 0xe {
			buf.p = append(buf.p, byte(0xfc))
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|0xc))
		}
	}
}

func (buf *buffer) writeInt16(data int16, index int) {
	if data&0x007f == data {
		buf.writeByte(byte(data), index)
	} else {
		if index > 0xe {
			buf.p = append(buf.p, 0xf1)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|1))
		}
		buf.p = append(buf.p, int16ToBytes(data)...)
	}
}

func (buf *buffer) writeInt32(data int32, index int) {
	if data&0x00007fff == data {
		buf.writeInt16(int16(data), index)
	} else {
		if index > 0xe {
			buf.p = append(buf.p, 0xf2)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|2))
		}
		buf.p = append(buf.p, int32ToBytes(data)...)
	}
}

func (buf *buffer) writeInt64(data int64, index int) {
	if data&0x000000007fffffff == data {
		buf.writeInt32(int32(data), index)
	} else {
		if index > 0xe {
			buf.p = append(buf.p, 0xf3)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|3))
		}
		buf.p = append(buf.p, int64ToBytes(data)...)
	}
}

func (buf *buffer) writeString(data string, index int) {
	if len(data) >= 0x100 {
		if index > 0xe {
			buf.p = append(buf.p, 0xf7)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|0x7))
		}
		buf.p = append(buf.p, int32ToBytes(int32(len(data)))...)
		buf.p = append(buf.p, []byte(data)...)
	} else {
		if index > 0xe {
			buf.p = append(buf.p, byte(0xf6))
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|0x6))
		}
		buf.p = append(buf.p, byte(len(data)))
		buf.p = append(buf.p, data...)
	}
}

// 序列化map
func (buf *buffer) writeMap(data map[string]string, index int) {
	if index > 0xe {
		buf.p = append(buf.p, 0xf8)
		buf.p = append(buf.p, byte(index))
	} else {
		buf.p = append(buf.p, byte(0x10*index|0x8))
	}
	buf.writeInt32(int32(len(data)), 0)
	for k, v := range data {
		buf.writeString(k, 0)
		buf.writeString(v, 1)
	}
}

// 序列化vector<char>
func (buf *buffer) writeBytes(data []byte, index int) {
	if index > 0xe {
		buf.p = append(buf.p, 0xfd)
		buf.p = append(buf.p, byte(index))
	} else {
		buf.p = append(buf.p, byte(0x10*index|0xd))
	}
	buf.p = append(buf.p, 0x0)
	buf.writeInt32(int32(len(data)), 0)
	buf.p = append(buf.p, data...)
}

// 序列化成员对象Object
func (buf *buffer) writeObject(data interface{}, index int) error {
	if index >= 0 {
		if index > 0xe {
			buf.p = append(buf.p, 0xfa)
			buf.p = append(buf.p, byte(index))
		} else {
			buf.p = append(buf.p, byte(0x10*index|0xa))
		}
	}
	getValue := reflect.ValueOf(data).Elem()
	// 获取方法字段
	for i := 0; i < getValue.NumField(); i++ {
		//field := getType.Field(i)
		value := getValue.Field(i)
		//fmt.Printf("%s: %Head = %Head\n", field.Name, field.Type, value)
		switch value.Kind() {
		case reflect.Int16, reflect.Int32, reflect.Int64:
			buf.writeInt64(value.Int(), i)
		case reflect.Uint16, reflect.Uint32, reflect.Uint64:
			buf.writeInt64(int64(value.Uint()), i)
		case reflect.String:
			buf.writeString(value.String(), i)
		case reflect.Map:
			buf.writeMap(value.Interface().(map[string]string), i)
		case reflect.Slice:
			switch value.Type().Elem().Kind() {
			case reflect.Uint8:
				buf.writeBytes(value.Bytes(), i)
			case reflect.Struct:
				if i > 0xe {
					buf.p = append(buf.p, 0xf9)
					buf.p = append(buf.p, byte(i))
				} else {
					buf.p = append(buf.p, byte(0x10*i|0x9))
				}
				buf.writeInt32(int32(value.Len()), 0)
				for j := 0; j < value.Len(); j++ {
					err := buf.writeObject(value.Index(j).Addr().Interface(), 0)
					if err != nil {
						return nil
					}
				}
			default:
				return errors.New("不知道的Slice成员字段类型，无法序列化")
			}
		case reflect.Struct: // 这里是递归掉用了
			err := buf.writeObject(value.Addr().Interface(), i)
			if err != nil {
				return err
			}
		default:
			fmt.Printf("不知道的字段类型，无法序列化 %+v", value.Kind())
			return errors.New("不知道的字段类型，无法序列化")
		}
	}

	if index >= 0 {
		buf.p = append(buf.p, 0xb)
	}

	return nil
}

func (buf *buffer) checkIndex(index int, t byte) error {
	// 校验index
	if index > 0xe {
		i, err := buf.reader.ReadByte()
		if err != nil {
			return err
		}

		if int(i) != index {
			return errors.New("index校验失败")
		}
	} else {
		if int(t>>4) != index {
			return errors.New("index校验失败")
		}
	}

	return nil
}

func (buf *buffer) readInt64(index int) (int64, error) {
	t, err := buf.reader.ReadByte()
	if err != nil {
		return 0, err
	}

	if err := buf.checkIndex(index, t); err != nil {
		return 0, err
	}

	switch t & 0xf {
	case 0: // byte
		res, err := buf.reader.ReadByte()
		if err != nil {
			return 0, err
		}
		return int64(res), nil
	case 1: // int16
		res := make([]byte, 0x2)
		_, err := buf.reader.Read(res)
		if err != nil {
			return 0, err
		}
		return int64(bytesToInt16(res)), nil
	case 2: // int32
		res := make([]byte, 0x4)
		_, err := buf.reader.Read(res)
		if err != nil {
			return 0, err
		}
		return int64(bytesToInt32(res)), nil
	case 3: // int64
		res := make([]byte, 0x8)
		_, err := buf.reader.Read(res)
		if err != nil {
			return 0, err
		}
		return bytesToInt64(res), nil
	case 0xc: // byte 而且值为0
		return 0, nil
	default:
		return 0, errors.New("不是整数类型的字段")
	}
}

func (buf *buffer) readString(index int) (string, error) {
	t, err := buf.reader.ReadByte()
	if err != nil {
		return "", err
	}

	if err := buf.checkIndex(index, t); err != nil {
		return "", err
	}

	switch t & 0xf {
	case 0x6: // 长度小于0x100
		dataLen, err := buf.reader.ReadByte()
		if err != nil {
			return "", err
		}
		var data []byte
		if dataLen > 0 {
			data = make([]byte, dataLen)
			_, err = buf.reader.Read(data)
			if err != nil {
				return "", err
			}
		}
		return string(data), nil
	case 0x7: // 长度大于等于0x100
		dataLen := make([]byte, 0x4)
		_, err = buf.reader.Read(dataLen)
		if err != nil {
			return "", err
		}
		var data []byte
		if bytesToInt32(dataLen) > 0 {
			data = make([]byte, bytesToInt32(dataLen))
			_, err = buf.reader.Read(data)
			if err != nil {
				return "", err
			}
		}
		return string(data), nil
	default:
		return "", errors.New("不是字符串类型的字段")
	}
}

func (buf *buffer) readMap(index int) (map[string]string, error) {
	t, err := buf.reader.ReadByte()
	if err != nil {
		return nil, err
	}

	if err := buf.checkIndex(index, t); err != nil {
		return nil, err
	}
	switch t & 0xf {
	case 0x8:
		mapLen, err := buf.readInt64(0)
		if err != nil {
			return nil, err
		}
		res := make(map[string]string, mapLen)
		for i := 0; i < int(mapLen); i++ {
			k, err := buf.readString(0)
			if err != nil {
				return nil, err
			}
			v, err := buf.readString(1)
			if err != nil {
				return nil, err
			}
			res[k] = v
		}

		return res, nil
	default:
		return nil, errors.New("不是map类型的字段")
	}
}

func (buf *buffer) readBytes(index int) ([]byte, error) {
	t, err := buf.reader.ReadByte()
	if err != nil {
		return nil, err
	}

	if err := buf.checkIndex(index, t); err != nil {
		return nil, err
	}

	switch t & 0xf {
	case 0xd:
		b, err := buf.reader.ReadByte()
		if err != nil {
			return nil, err
		}
		if b != 0 {
			return nil, errors.New("[]byte长度前面第一个字节不是0x00")
		}
		// 读出长度
		aryLen, err := buf.readInt64(0)
		if err != nil {
			return nil, err
		}
		var res []byte
		if aryLen > 0 {
			// 申请空间读出数据
			res = make([]byte, aryLen)
			_, err = buf.reader.Read(res)
			if err != nil {
				return nil, err
			}
		}
		return res, nil
	default:
		return nil, errors.New("不是[]byte类型的字段")
	}
}

func (buf *buffer) readObject(v interface{}, index int) error {
	t := byte(0xA)
	var err error
	if index >= 0 {
		t, err = buf.reader.ReadByte()
		if err != nil {
			return err
		}
		if err := buf.checkIndex(index, t); err != nil {
			return err
		}
	}

	switch t & 0xf {
	case 0xA:
		getValue := reflect.ValueOf(v).Elem()
		// 获取方法字段
		for i := 0; i < getValue.NumField(); i++ {
			//field := getType.Field(i)
			value := getValue.Field(i)
			//fmt.Printf("%s: %Head = %Head\n", field.Name, field.Type, value)
			switch value.Kind() {
			case reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint16, reflect.Uint32, reflect.Uint64:
				i, err := buf.readInt64(i)
				if err != nil {
					return err
				}
				value.SetInt(i)
			case reflect.String:
				s, err := buf.readString(i)
				if err != nil {
					return err
				}
				value.SetString(s)
			case reflect.Slice:
				switch value.Type().Elem().Kind() {
				case reflect.Uint8:
					b, err := buf.readBytes(i)
					if err != nil {
						return err
					}
					value.SetBytes(b)
				case reflect.Struct:
					a, err := buf.reader.ReadByte()
					if err != nil {
						return err
					}

					if err := buf.checkIndex(i, a); err != nil {
						return err
					}

					switch a & 0xf {
					case 0x9:
						aryLen, err := buf.readInt64(0)
						if err != nil {
							return err
						}

						if aryLen == 0 {
							return nil
						}

						// 创建对象
						s := reflect.New(value.Type()).Elem()
						// 创建slice
						s1 := reflect.MakeSlice(value.Type(), int(aryLen), int(aryLen))
						// 将对象与slice绑定
						s.Set(s1)
						for j := 0; j < int(aryLen); j++ {
							err := buf.readObject(s.Index(j).Addr().Interface(), 0)
							if err != nil {
								return err
							}
						}
						// 将值转换上去
						value.Set(s)
						return nil
					default:
						return errors.New("不是Array类型的字段")
					}
				default:
					panic("不知道的Slice成员字段类型，无法序列化")
				}
			case reflect.Struct: // 这里是递归掉用了
				err := buf.readObject(value.Addr().Interface(), i)
				if err != nil {
					return err
				}
			default:
				fmt.Printf("不知道的字段类型，无法序列化 %+v", value.Kind())
				panic("不知道的字段类型，无法序列化")
			}
		}

		// 读完object了校验结尾
		if index >= 0 {
			end, err := buf.reader.ReadByte()
			if err != nil {
				return err
			}
			if end != 0xb {
				return errors.New("读取Object类型数据校验结尾不是0xB")
			}
		}

		return nil
	default:
		return errors.New("不是Object类型的字段")
	}
}

func tmfMarshal(v interface{}) ([]byte, error) {
	buf := &buffer{}
	err := buf.writeObject(v, -1)
	return buf.p, err
}

func tmfUnmarshal(data []byte, v interface{}) error {
	buf := newBuffer(data)
	return buf.readObject(v, -1)
}

//////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////客户端上传包////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

type vidTicket struct {
	Kind   int32
	Ticket string
}

type sharkFin struct {
	Field1      int32 // 没看见使用
	Field2      int32 // 没看见使用
	GUID        string
	Field4      string // 没看见使用
	SessionID   string
	BuildNumber int32
	Field7      int32 // 没看见使用
	AccountID   int64
	Field9      int32  // 没看见使用
	Field10     string // 没看见使用
	VTicket     vidTicket
}

type clientPush struct {
	ID int64
}

type csSashimi struct {
	CmdID       int32
	SeqNo       int32
	Field3      int32
	ReqData     []byte
	Push        clientPush
	ReqHeaders  []byte // <- csHeader序列化
	ReqDataType int32
}

type csSharkHead struct {
	LastSashimiSeqNo int32
	SessionID        string
	Field3           int32
	Field4           string
	Field5           int32
	SeqNo            int32
	Field7           int32
}

type csHeader struct {
	Headers map[string]string
	Cookies map[string]string
	Queries map[string]string
	Cmd     string
}

type csShark struct {
	SeqNo    int32
	Field2   int32 // 没看见使用
	Fin      sharkFin
	Sashimis []csSashimi
}

type csSecret struct {
	Kind       int32  // 只看见初始化为0
	EnData     []byte // <- sm2加密encodeKey
	ProductKey string // 固定值
	HasEncrypt int32  // 表示encodeKey加密完成
}

type csSharkSkin struct {
	Head   csSharkHead
	Secret []byte // <- csSecret序列化
	Shark  []byte // <- csShark序列化
}

func (b *Bank) genPostData(shark *csShark) ([]byte, error) {
	curTime := tools.Timestamp()
	if int32(curTime)-b.sessionStartTime >= b.expTime || b.sm4Key == nil {
		b.sm4Key = b.genSM4Key()
		b.sessionID = ""
		//b.sm4Key = []byte("OK0LDH;,p;): HT2")
	}

	if shark == nil {
		return nil, errors.New("传入参数不能为nil")
	}

	var secret *csSecret
	if b.sessionID == "" {
		// 需要上 secret
		// sm2 加密sm4Key
		enKey, err := tools.SM2Encrypt(b.sm4Key, sharkCMDSM2PublicKeyX, sharkCMDSM2PublicKeyY)
		if err != nil {
			return nil, err
		}
		//enKey = []byte{
		//	0x04, 0xAE, 0xE3, 0xF9, 0xA5, 0x2A, 0xB2, 0x19, 0x8C, 0xE6, 0x8E, 0xC7, 0xC1, 0xB3, 0x4B, 0xBE, 0x05,
		//	0x21, 0x01, 0xB5, 0x97, 0x5D, 0x06, 0x24, 0xD4, 0x87, 0xCB, 0xB2, 0xE2, 0x47, 0xA3, 0x22, 0x6E,
		//	0x93, 0x05, 0xED, 0x3D, 0x63, 0x2A, 0xED, 0x02, 0x50, 0x3B, 0x85, 0xE9, 0xD7, 0x44, 0x82, 0x4D,
		//	0xF6, 0xD0, 0x0F, 0x23, 0xC2, 0x3B, 0x38, 0xD8, 0x0F, 0x8B, 0x5E, 0x38, 0x20, 0xAD, 0xEB, 0xCC,
		//	0x91, 0xC5, 0x93, 0x9F, 0xC6, 0xAA, 0xF4, 0x40, 0x1F, 0x98, 0x1E, 0xF0, 0x52, 0xE5, 0xF6, 0xA3,
		//	0xBD, 0x06, 0x01, 0x9B, 0x32, 0xEA, 0x31, 0x6B, 0x9B, 0x41, 0x31, 0x13, 0x78, 0x34, 0x55, 0x22,
		//	0xE5, 0xC3, 0x82, 0x1E, 0x0B, 0xCA, 0x35, 0x8F, 0x9C, 0xF2, 0x05, 0xF4, 0x79, 0x21, 0xE1, 0x44,
		//}

		secret = &csSecret{
			Kind:       0,
			EnData:     enKey[1:],
			ProductKey: sharkCMDProductKey,
			HasEncrypt: 1,
		}
	}

	// 3次序列化
	var secretB []byte
	var sharkB []byte
	var err error
	if secret != nil {
		secretB, err = tmfMarshal(secret)
		//fmt.Println(hex.Dump(secretB))
		if err != nil {
			return nil, err
		}
	}

	sharkB, err = tmfMarshal(shark)
	//fmt.Println(hex.Dump(sharkB))
	if err != nil {
		return nil, err
	}
	// zlib 压缩
	sharkZ, err := tools.ZLibCompress(sharkB)
	if err != nil {
		return nil, err
	}
	// sm4加密
	sharkE, err := tools.SM4ECBEncrypt(sharkZ, b.sm4Key)
	if err != nil {
		return nil, err
	}
	// 再次序列化
	return tmfMarshal(&csSharkSkin{
		Head: csSharkHead{
			LastSashimiSeqNo: 20,
			SessionID:        b.sessionID,
			Field3:           0,
			Field4:           "",
			Field5:           2,
			SeqNo:            shark.SeqNo,
			Field7:           0,
		},
		Secret: secretB,
		Shark:  sharkE,
	})
}

//////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////服务器返回包////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

type scSharkHead struct {
	Flag     int32
	RetCode  int32
	Field3   int32
	RefSeqNO int32
}

type scSecret struct {
	SessionID string
	ExpTime   int32 // 过期时间，过期后要重新生成sm4Key
}

type serverPush struct {
	ID     int64
	Field2 string
}

type scHeader struct {
	Headers map[string]string
	State   int32
}

type scSashimi struct {
	CmdID             int32
	Field2            int32
	SeqNo             int32
	AccessLayerCode   int32
	BusinessLayerCode int32
	RspData           []byte
	Push              serverPush
	RspHeaders        []byte // <- scHeader
	Field9            int32
	Field10           string
}

type scShark struct {
	Field1   int32
	Field2   int32
	Sashimis []scSashimi
}

type scSharkSkin struct {
	Head   scSharkHead
	Secret []byte // <- scSecret序列化
	Shark  []byte // <- scShark序列化
}

func (b *Bank) parseRspData(rspData []byte) (*scShark, error) {
	skin := &scSharkSkin{}
	err := tmfUnmarshal(rspData, skin)
	if err != nil {
		return nil, err
	}
	if skin.Head.RetCode != 0 {
		return nil, fmt.Errorf("返回失败retCode=%d", skin.Head.RetCode)
	}

	secret := &scSecret{}
	if skin.Secret != nil {
		err = tmfUnmarshal(skin.Secret, secret)
		if err != nil {
			return nil, err
		}
	}

	// 更新sessionID
	b.Infof("返回 refSeqNO=%d sessionID=%s", skin.Head.RefSeqNO, secret.SessionID)
	if b.sessionID == "" && secret.SessionID != "" {
		b.Infof("更新了 refSeqNO=%d sessionID=%s", skin.Head.RefSeqNO, secret.SessionID)
		b.sessionID = secret.SessionID
		b.expTime = secret.ExpTime
		b.sessionStartTime = int32(tools.Timestamp())
	}

	// 解密
	sharkD, err := tools.SM4ECBDecrypt(skin.Shark, b.sm4Key)
	if err != nil {
		return nil, err
	}
	sharkZ := sharkD
	//fmt.Println(hex.Dump(sharkD))
	if sharkD[0] == 0x78 && sharkD[1] == 0x9c {
		// 解压
		sharkZ, err = tools.ZLibUncompress(sharkD)
		if err != nil {
			return nil, err
		}
	}

	// 反序列化
	shark := &scShark{}
	err = tmfUnmarshal(sharkZ, shark)

	return shark, err
}
