package bocom

type mb0303Resp struct {
	RSPBODY struct {
		SafeInputVersion interface{} `json:"SafeInputVersion"`
		UserAgent        string      `json:"User-Agent"`
		ClientIP         string      `json:"clientIP"`
		ClientVersion    string      `json:"clientVersion"`
		Cmd              string      `json:"cmd"`
		Commender        string      `json:"commender"`
		ContractNo       string      `json:"contractNo"`
		DiviceID         string      `json:"diviceId"`
		EcifNo           string      `json:"ecifNo"`
		Hashs            string      `json:"hashs"`
		IsWap            string      `json:"isWap"`
		Locale           string      `json:"locale"`
		MldsModel        string      `json:"mlds_model"`
		MldsVersion      string      `json:"mlds_version"`
		Native           string      `json:"native"`
		PicList          []struct {
			BeginDate   string `json:"beginDate"`
			EndDate     string `json:"endDate"`
			ManageTitle string `json:"manageTitle"`
			ManageURL   string `json:"manageUrl"`
			PicBase     string `json:"picBase"`
			PicHashCode string `json:"picHashCode"`
			PicName     string `json:"picName"`
			PicStat     string `json:"picStat"`
			Title       string `json:"title"`
		} `json:"picList"`
		ProcessCode string      `json:"processCode"`
		ReturnVal   interface{} `json:"returnVal"`
		Status      string      `json:"status"`
		Step        string      `json:"step"`
		XChannel    string      `json:"x-channel"`
	} `json:"RSP_BODY"`
	RSPHEAD struct {
		MSessionID   string `json:"MSessionId"`
		TRANSUCCESS  string `json:"TRAN_SUCCESS"`
		ERRORCODE    string `json:"ERROR_CODE"`
		ERRORMESSAGE string `json:"ERROR_MESSAGE"`
	} `json:"RSP_HEAD"`
}

type mb1995Resp struct {
	RSPBODY struct {
		DiviceID      string      `json:"diviceId"`
		EcifNo        string      `json:"ecifNo"`
		IsWap         string      `json:"isWap"`
		ContractNo    string      `json:"contractNo"`
		UserAgent     string      `json:"User-Agent"`
		PublicKey     string      `json:"publicKey"`
		ClientVersion string      `json:"clientVersion"`
		Locale        string      `json:"locale"`
		MldsModel     string      `json:"mlds_model"`
		Native        string      `json:"native"`
		ProcessCode   string      `json:"processCode"`
		MldsVersion   string      `json:"mlds_version"`
		ClientIP      string      `json:"clientIP"`
		XChannel      string      `json:"x-channel"`
		Step          string      `json:"step"`
		Cmd           string      `json:"cmd"`
		Commender     interface{} `json:"commender"`
		Status        string      `json:"status"`
	} `json:"RSP_BODY"`
	RSPHEAD struct {
		TRANSUCCESS  string `json:"TRAN_SUCCESS"`
		MSessionID   string `json:"MSessionId"`
		ERRORCODE    string `json:"ERROR_CODE"`
		ERRORMESSAGE string `json:"ERROR_MESSAGE"`
	} `json:"RSP_HEAD"`
}

type mb0000Resp struct {
	RSPBODY struct {
		ECIFRole          string      `json:"ECIFRole"`
		IMEI              string      `json:"IMEI"`
		UserAgent         string      `json:"User-Agent"`
		Alias             string      `json:"alias"`
		Birthday          string      `json:"birthday"`
		CardDateLost      string      `json:"cardDateLost"`
		ChangeUserFlag    string      `json:"changeUserFlag"`
		CheckInfo         string      `json:"checkInfo"`
		ClientIP          string      `json:"clientIP"`
		ClientVersion     string      `json:"clientVersion"`
		Cmd               string      `json:"cmd"`
		Commender         interface{} `json:"commender"`
		ContractNo        string      `json:"contractNo"`
		DiviceID          string      `json:"diviceId"`
		EcifNo            string      `json:"ecifNo"`
		EnglishName       string      `json:"englishName"`
		FirstFlag         string      `json:"firstFlag"`
		FivePointLost     string      `json:"fivePointLost"`
		IsFaceIDUser      bool        `json:"isFaceIdUser"`
		IsOtherBankUser   string      `json:"isOtherBankUser"`
		IsPayWhiteUser    bool        `json:"isPayWhiteUser"`
		IsWap             string      `json:"isWap"`
		IsWhiteUser       bool        `json:"isWhiteUser"`
		LastLogonDatetime string      `json:"lastLogonDatetime"`
		Locale            string      `json:"locale"`
		LoginPhoneNumber  string      `json:"loginPhoneNumber"`
		LogonTimes        int         `json:"logonTimes"`
		Method            string      `json:"method"`
		MldsModel         string      `json:"mlds_model"`
		MldsVersion       string      `json:"mlds_version"`
		MobileNo          string      `json:"mobileNo"`
		Name              string      `json:"name"`
		Native            string      `json:"native"`
		NinePageCode      string      `json:"ninePageCode"`
		PageCode          string      `json:"pageCode"`
		ParamTrackCode    string      `json:"paramTrackCode"`
		Password          string      `json:"password"`
		ProcessCode       string      `json:"processCode"`
		RealNameFlag      string      `json:"realNameFlag"`
		Status            string      `json:"status"`
		Step              string      `json:"step"`
		TargetPageCode    string      `json:"targetPageCode"`
		TimeTip           string      `json:"timeTip"`
		UserCode          interface{} `json:"userCode"`
		XChannel          string      `json:"x-channel"`
	} `json:"RSP_BODY"`
	RSPHEAD struct {
		MSessionID   string `json:"MSessionId"`
		TRANSUCCESS  string `json:"TRAN_SUCCESS"`
		ERRORCODE    string `json:"ERROR_CODE"`
		ERRORMESSAGE string `json:"ERROR_MESSAGE"`
	} `json:"RSP_HEAD"`
}

type ac0000Resp struct {
	RSPBODY struct {
		UserAgent     string      `json:"User-Agent"`
		AccountType   string      `json:"accountType"`
		CardDateLost  string      `json:"cardDateLost"`
		CifID         string      `json:"cifId"`
		ClientIP      string      `json:"clientIP"`
		ClientVersion string      `json:"clientVersion"`
		Cmd           string      `json:"cmd"`
		Commender     interface{} `json:"commender"`
		ContractNo    string      `json:"contractNo"`
		CusName       string      `json:"cusName"`
		DiviceID      string      `json:"diviceId"`
		EcifNo        string      `json:"ecifNo"`
		FinancialFlag string      `json:"financialFlag"`
		FivePointLost string      `json:"fivePointLost"`
		Flag          string      `json:"flag"`
		IsWap         string      `json:"isWap"`
		Locale        string      `json:"locale"`
		LossFlag      string      `json:"lossFlag"`
		Method        string      `json:"method"`
		MldsModel     string      `json:"mlds_model"`
		MldsVersion   string      `json:"mlds_version"`
		MyAccountList []struct {
			Account     string      `json:"account"`
			AccountFlag string      `json:"accountFlag"`
			AgrDte      interface{} `json:"agrDte"`
			Alias       string      `json:"alias"`
			AvaBalXjd   interface{} `json:"avaBalXjd"`
			BalanceList []struct {
				AccBalance     string      `json:"accBalance"`
				AccBalanceC    string      `json:"accBalanceC"`
				AccBalanceH    string      `json:"accBalanceH"`
				AccUseBalanceC string      `json:"accUseBalanceC"`
				AccUseBalanceH string      `json:"accUseBalanceH"`
				Currency       string      `json:"currency"`
				Value          interface{} `json:"value"`
			} `json:"balanceList"`
			CardStt         string      `json:"cardStt"`
			CardType        string      `json:"cardType"`
			CertNo          string      `json:"certNo"`
			CertTpye        string      `json:"certTpye"`
			CoreCustomer    string      `json:"coreCustomer"`
			CxcAvaAmt       string      `json:"cxcAvaAmt"`
			CxcFlag         string      `json:"cxcFlag"`
			CxcTotAmt       string      `json:"cxcTotAmt"`
			Empower         int         `json:"empower"`
			FaceFlag        string      `json:"faceFlag"`
			HldName         string      `json:"hldName"`
			HqbAvaAmt       string      `json:"hqbAvaAmt"`
			HqbFlag         string      `json:"hqbFlag"`
			HqbHavShr       string      `json:"hqbHavShr"`
			IsBenren        string      `json:"isBenren"`
			IsJiaohang      string      `json:"isJiaohang"`
			IsSelfFlag      string      `json:"isSelfFlag"`
			OneCardMobileNo string      `json:"oneCardMobileNo"`
			Type            string      `json:"type"`
			UserOrgName     string      `json:"userOrgName"`
			XjdFlag         interface{} `json:"xjdFlag"`
		} `json:"myAccountList"`
		Native            string `json:"native"`
		NinePageCode      string `json:"ninePageCode"`
		PageCode          string `json:"pageCode"`
		ProcessCode       string `json:"processCode"`
		QryFaceflag       string `json:"qryFaceflag"`
		QueryBalance      string `json:"queryBalance"`
		Status            string `json:"status"`
		Step              string `json:"step"`
		TargetPageCode    string `json:"targetPageCode"`
		XChannel          string `json:"x-channel"`
		XValidationConfig string `json:"x-validation-config"`
	} `json:"RSP_BODY"`
	RSPHEAD struct {
		MSessionID   string `json:"MSessionId"`
		TRANSUCCESS  string `json:"TRAN_SUCCESS"`
		ERRORCODE    string `json:"ERROR_CODE"`
		ERRORMESSAGE string `json:"ERROR_MESSAGE"`
	} `json:"RSP_HEAD"`
}

type ac0005Resp struct {
	RSPBODY struct {
		CSum               float64 `json:"CSum"`
		DCFlag             string  `json:"DCFlag"`
		DSum               float32 `json:"DSum"`
		UserAgent          string  `json:"User-Agent"`
		AccName            string  `json:"accName"`
		AccNo              string  `json:"accNo"`
		Account            string  `json:"account"`
		AccountDetailsList []struct {
			Amount     string `json:"amount"`
			Balance    string `json:"balance"`
			DcFlg      string `json:"dcFlg"`
			DealTime   string `json:"dealTime"`
			DealType   string `json:"dealType"`
			OnLoanFlag string `json:"onLoanFlag"`
			OppAc      string `json:"oppAc"`
			OppAcNme   string `json:"oppAcNme"`
			OppBnkNme  string `json:"oppBnkNme"`
			Remark     string `json:"remark"`
			TxnBrpla   string `json:"txnBrpla"`
			WebTime    string `json:"webTime"`
		} `json:"accountDetailsList"`
		BankName        string      `json:"bankName"`
		BeginDate       string      `json:"beginDate"`
		BeginRecord     string      `json:"beginRecord"`
		BlanceFlag      string      `json:"blanceFlag"`
		CardDateLost    string      `json:"cardDateLost"`
		ChangeColorflag string      `json:"changeColorflag"`
		ClientIP        string      `json:"clientIP"`
		ClientVersion   string      `json:"clientVersion"`
		Cmd             string      `json:"cmd"`
		Code            string      `json:"code"`
		Commender       interface{} `json:"commender"`
		ContractNo      string      `json:"contractNo"`
		Currency        string      `json:"currency"`
		CurrentPage     string      `json:"currentPage"`
		DateFlag        string      `json:"dateFlag"`
		DiviceID        string      `json:"diviceId"`
		EcifNo          string      `json:"ecifNo"`
		EndDate         string      `json:"endDate"`
		EndFlag         string      `json:"endFlag"`
		FivePointLost   string      `json:"fivePointLost"`
		GtSix           bool        `json:"gtSix"`
		IsWap           string      `json:"isWap"`
		LastPage        string      `json:"lastPage"`
		LeftTextFlag    string      `json:"leftTextFlag"`
		Locale          string      `json:"locale"`
		Method          string      `json:"method"`
		MldsModel       string      `json:"mlds_model"`
		MldsVersion     string      `json:"mlds_version"`
		Month           string      `json:"month"`
		MonthValue      string      `json:"monthValue"`
		Native          string      `json:"native"`
		NinePageCode    string      `json:"ninePageCode"`
		Page            struct {
			LastPage string `json:"lastPage"`
			Page     string `json:"page"`
			PageSize string `json:"pageSize"`
		} `json:"page"`
		PageCode              string `json:"pageCode"`
		PageSize              string `json:"pageSize"`
		ProcessCode           string `json:"processCode"`
		Remark                string `json:"remark"`
		Status                string `json:"status"`
		Step                  string `json:"step"`
		SummaryInput          string `json:"summaryInput"`
		TargetPageCode        string `json:"targetPageCode"`
		TotalTran             int    `json:"totalTran"`
		TradeAccountNameInput string `json:"tradeAccountNameInput"`
		TradeBank             string `json:"tradeBank"`
		TradeBankFlag         string `json:"tradeBankFlag"`
		TradeBankNameInput    string `json:"tradeBankNameInput"`
		TradePlace            string `json:"tradePlace"`
		TradeWay              string `json:"tradeWay"`
		XChannel              string `json:"x-channel"`
		XValidationConfig     string `json:"x-validation-config"`
	} `json:"RSP_BODY"`
	RSPHEAD struct {
		MSessionID   string `json:"MSessionId"`
		TRANSUCCESS  string `json:"TRAN_SUCCESS"`
		ERRORCODE    string `json:"ERROR_CODE"`
		ERRORMESSAGE string `json:"ERROR_MESSAGE"`
	} `json:"RSP_HEAD"`
}
