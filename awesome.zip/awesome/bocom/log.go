package bocom

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os"
)

const (
	infoPrefix  = "[INFO ] - "
	errorPrefix = "[ERROR] - "
	DEBUG       = true
)

var (
	logInfo  = log.New(os.Stdout, infoPrefix, log.LstdFlags|log.Lmicroseconds)
	logError = log.New(os.Stdout, errorPrefix, log.LstdFlags|log.Lmicroseconds|log.Lshortfile)
)

// Info 普通日志
func (b *Bank) Info(log string) {
	_ = logInfo.Output(2, fmt.Sprintf("[BOCOM][%s] %s", b.Account, log))
}

// Infof 普通日志
func (b *Bank) Infof(logFmt string, logs ...interface{}) {
	_ = logInfo.Output(2, fmt.Sprintf("[BOCOM][%s] %s", b.Account, fmt.Sprintf(logFmt, logs...)))
}

func (b *Bank) InfoJson(prefix, log string) {
	var dst bytes.Buffer

	if DEBUG {
		// 这样会进行排序
		obj := &map[string]interface{}{}
		_ = json.Unmarshal([]byte(log), obj)
		objM, _ := json.Marshal(obj)
		log = string(objM)
	}

	if err := json.Indent(&dst, []byte(log), "", "\t"); err != nil {
		b.Errorf("json.Indent err = %+v", err)
	}

	log = fmt.Sprintf("[BOCOM][%s] %s%s", b.Account, prefix, dst.String())
	_ = logInfo.Output(2, log)
}

// Error 错误日志
func (b *Bank) Error(log string) {
	_ = logError.Output(2, fmt.Sprintf("[BOCOM][%s] %s", b.Account, log))
}

// Errorf 错误日志
func (b *Bank) Errorf(logFmt string, logs ...interface{}) {
	_ = logError.Output(2, fmt.Sprintf("[BOCOM][%s] %s", b.Account, fmt.Sprintf(logFmt, logs...)))
}
