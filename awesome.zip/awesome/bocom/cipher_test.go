package bocom

import (
	"awesome/tools"
	"encoding/hex"
	"errors"
	"fmt"
	"net/url"
	"testing"
)

func tmfPrint(data []byte) {
	//data = append([]byte{0xa}, data...)
	//data = append(data, 0xb)
	buf := newBuffer(data)
	fmt.Println("打印开始")
	err := buf.printObject(0)
	if err != nil {
		fmt.Print(err)
	} else {
		fmt.Println("打印结束")
	}
}

func (buf *buffer) printObject(index int) error {
	prif := ""
	for i := 0; i < index; i++ {
		prif = prif + "\t"
	}
	for {
		if buf.reader.Len() <= 0 {
			break
		}

		b, err := buf.reader.ReadByte()

		if err != nil {
			return err
		}
		if b == 0xb {
			// object结尾
			break
		}
		// 获取index
		i := b >> 4
		if i == 0xf {
			i, err = buf.reader.ReadByte()
			if err != nil {
				return err
			}
		}
		fmt.Printf("%s%d: ", prif, i)
		switch b & 0xf {
		case 0: // byte
			res, err := buf.reader.ReadByte()
			if err != nil {
				return err
			}
			fmt.Println(fmt.Sprintf("type=int8     %d", res))
		case 1: // int16
			res := make([]byte, 0x2)
			_, err := buf.reader.Read(res)
			if err != nil {
				return err
			}
			fmt.Println(fmt.Sprintf("type=int16    %d", bytesToInt16(res)))
		case 2: // int32
			res := make([]byte, 0x4)
			_, err := buf.reader.Read(res)
			if err != nil {
				return err
			}
			fmt.Println(fmt.Sprintf("type=int32    %d", bytesToInt32(res)))
		case 3: // int64
			res := make([]byte, 0x8)
			_, err := buf.reader.Read(res)
			if err != nil {
				return err
			}
			fmt.Println(fmt.Sprintf("type=int64    %d", bytesToInt64(res)))
		case 0xc: // byte 而且值为0
			fmt.Println(fmt.Sprintf("type=int      %d", 0))
		case 0x6: // 长度小于0x100
			dataLen, err := buf.reader.ReadByte()
			if err != nil {
				return err
			}
			var data []byte
			if dataLen > 0 {
				data = make([]byte, dataLen)
				_, err = buf.reader.Read(data)
				if err != nil {
					return err
				}
			}
			fmt.Println(fmt.Sprintf("type=string   %s", string(data)))
		case 0x7: // 长度大于等于0x100
			dataLen := make([]byte, 0x4)
			_, err = buf.reader.Read(dataLen)
			if err != nil {
				return err
			}
			data := make([]byte, bytesToInt32(dataLen))
			_, err = buf.reader.Read(data)
			if err != nil {
				return err
			}
			fmt.Println(fmt.Sprintf("type=string   %s", string(data)))
		case 0x8:
			mapLen, err := buf.readInt64(0)
			if err != nil {
				return err
			}
			res := make(map[string]string, mapLen)
			for i := 0; i < int(mapLen); i++ {
				k, err := buf.readString(0)
				if err != nil {
					return err
				}
				v, err := buf.readString(1)
				if err != nil {
					return err
				}
				res[k] = v
			}
			fmt.Println(fmt.Sprintf("type=map      %+v", res))
		case 0xd:
			b, err := buf.reader.ReadByte()
			if err != nil {
				return err
			}
			if b != 0 {
				return errors.New("[]byte长度前面第一个字节不是0x00")
			}
			// 读出长度
			aryLen, err := buf.readInt64(0)
			if err != nil {
				return err
			}
			var res []byte
			if aryLen > 0 {
				// 申请空间读出数据
				res = make([]byte, aryLen)
				_, err = buf.reader.Read(res)
				if err != nil {
					return err
				}
			}
			fmt.Println("type=bytes")
			fmt.Println(hex.Dump(res))
		case 0xa:

			fmt.Println("{")
			err := buf.printObject(index + 1)
			if err != nil {
				return nil
			}
			fmt.Println(prif + "}")
		case 0x9:
			aryLen, err := buf.readInt64(0)
			if err != nil {
				return err
			}
			if aryLen == 0 {
				fmt.Println("type=array   []{}")
				continue
			}
			fmt.Println(fmt.Sprintf("type=array  [%d]{", aryLen))
			err = buf.printObject(index + 1)
			if err != nil {
				return err
			}
			fmt.Println(prif + "}")
		}
	}
	return nil
}

func TestPrint(t *testing.T) {
	data := []byte{
		0x02, 0x06, 0x43, 0xDE, 0xE7, 0x10, 0x01, 0x29, 0x00, 0x01, 0x0A, 0x01, 0x27, 0x13, 0x12, 0x06,
		0x43, 0xDE, 0xE6, 0x20, 0x01, 0x3C, 0x4C, 0x5D, 0x00, 0x00, 0x22, 0x06, 0x20, 0x30, 0x33, 0x30,
		0x33, 0x37, 0x37, 0x31, 0x39, 0x31, 0x32, 0x33, 0x30, 0x31, 0x35, 0x32, 0x33, 0x30, 0x32, 0x36,
		0x31, 0x33, 0x32, 0x34, 0x30, 0x31, 0x36, 0x32, 0x37, 0x34, 0x32, 0x39, 0x37, 0x6A, 0x0C, 0x16,
		0x03, 0x61, 0x62, 0x63, 0x0B, 0x7D, 0x00, 0x0C, 0x8C, 0x96, 0x00, 0x0B,
	}
	tmfPrint(data)
}

func TestSCShark(t *testing.T) {
	in := []byte{}
	sm4Key := []byte("%hjhNfo(dUn9S,&,")
	// 解密
	sharkD, _ := tools.SM4ECBDecrypt(in, sm4Key)
	// 解压
	sharkZ, _ := tools.ZLibUncompress(sharkD)
	tmfPrint(sharkZ)
}

func TestQuery(t *testing.T) {
	values, _ := url.ParseQuery("processCode=AC0005&MSessionId=4c8592faffffff8f1969f852261200b6&isWap=0&pageCode=NAC0002&targetPageCode=NAC0002&contractNo=2014239135&diviceId=03021912191254040020000078157601&method=&ninePageCode=NAC0002&fivePointLost=0&cardDateLost=0&account=6222623130003134315&month=&currency=CNY&page=2&pageSize=20&dateFlag=1&beginRecord=&lastPage=&DCFlag=&tradePlace=&tradeWay=&tradeBank=&tradeBankFlag=&accName=&accNo=&remark=&bankName=false&tradeBankNameInput=&tradeAccountNameInput=&summaryInput=&code=0005&monthValue=&beginDate=20190101&endDate=20191228&blanceFlag=0&changeColorflag=true&leftTextFlag=true&mlds_version=13.2.3&ecifNo=0115622129132498&native=iOS&clientIP=192.168.2.4&mlds_model=iPhone 7&clientVersion=IP-UMP-4.0.2-000000")
	fmt.Println(values.Encode())
}
