package radar

/*
#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshift-count-overflow"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbitwise-op-parentheses"
#endif

#include <string.h>
#include <stdio.h>
#include <stdint.h>

void appBitsCpy( uint8_t* Dest, int32_t DestBit, uint8_t* Src, int32_t SrcBit, int32_t BitCount )
{
	if( BitCount==0 ) return;

	// Special case - always at least one bit to copy,
	// a maximum of 2 bytes to read, 2 to write - only touch bytes that are actually used.
	if( BitCount <= 8 )
	{
		uint32_t DestIndex   = DestBit/8;
		uint32_t SrcIndex	   = SrcBit /8;
		uint32_t LastDest	   = ( DestBit+BitCount-1 )/8;
		uint32_t LastSrc	   = ( SrcBit +BitCount-1 )/8;
		uint32_t ShiftSrc    = SrcBit & 7;
		uint32_t ShiftDest   = DestBit & 7;
		uint32_t FirstMask   = 0xFF << ShiftDest;
		uint32_t LastMask    = 0xFE << ((DestBit + BitCount-1) & 7) ; // Pre-shifted left by 1.
		uint32_t Accu;

		if( SrcIndex == LastSrc )
			Accu = (Src[SrcIndex] >> ShiftSrc);
		else
			Accu =( (Src[SrcIndex] >> ShiftSrc) | (Src[LastSrc ] << (8-ShiftSrc)) );

		if( DestIndex == LastDest )
		{
			uint32_t MultiMask = FirstMask & ~LastMask;
			Dest[DestIndex] = ( ( Dest[DestIndex] & ~MultiMask ) | ((Accu << ShiftDest) & MultiMask) );
		}
		else
		{
			Dest[DestIndex] = (uint8_t)( ( Dest[DestIndex] & ~FirstMask ) | (( Accu << ShiftDest) & FirstMask) ) ;
			Dest[LastDest ] = (uint8_t)( ( Dest[LastDest ] & LastMask  )  | (( Accu >> (8-ShiftDest)) & ~LastMask) ) ;
		}

		return;
	}

	// Main copier, uses byte sized shifting. Minimum size is 9 bits, so at least 2 reads and 2 writes.
	uint32_t DestIndex	 = DestBit/8;
	uint32_t FirstSrcMask  = 0xFF << ( DestBit & 7);
	uint32_t LastDest		 = ( DestBit+BitCount )/8;
	uint32_t LastSrcMask   = 0xFF << ((DestBit + BitCount) & 7);
	uint32_t SrcIndex		 = SrcBit/8;
	uint32_t LastSrc		 = ( SrcBit+BitCount )/8;
	int32_t  ShiftCount    = (DestBit & 7) - (SrcBit & 7);
	int32_t  DestLoop      = LastDest-DestIndex;
	int32_t  SrcLoop       = LastSrc -SrcIndex;
	uint32_t FullLoop;
	uint32_t BitAccu;

	// Lead-in needs to read 1 or 2 source bytes depending on alignment.
	if( ShiftCount>=0 )
	{
		FullLoop  = (DestLoop>=SrcLoop) ? DestLoop : SrcLoop;
		BitAccu   = Src[SrcIndex] << ShiftCount;
		ShiftCount += 8; //prepare for the inner loop.
	}
	else
	{
		ShiftCount +=8; // turn shifts -7..-1 into +1..+7
		FullLoop  = (DestLoop>=SrcLoop-1) ? DestLoop : SrcLoop-1;
		BitAccu   = Src[SrcIndex] << ShiftCount;
		SrcIndex++;
		ShiftCount += 8; // Prepare for inner loop.
		BitAccu = ( ( (uint32_t)Src[SrcIndex] << ShiftCount ) + (BitAccu)) >> 8;
	}

	// Lead-in - first copy.
	Dest[DestIndex] = (uint8_t) (( BitAccu & FirstSrcMask) | ( Dest[DestIndex] &  ~FirstSrcMask ) );
	SrcIndex++;
	DestIndex++;

	// Fast inner loop.
	for(; FullLoop>1; FullLoop--)
	{   // ShiftCount ranges from 8 to 15 - all reads are relevant.
		BitAccu = (( (uint32_t)Src[SrcIndex] << ShiftCount ) + (BitAccu)) >> 8; // Copy in the new, discard the old.
		SrcIndex++;
		Dest[DestIndex] = (uint8_t) BitAccu;  // Copy low 8 bits.
		DestIndex++;
	}

	// Lead-out.
	if( LastSrcMask != 0xFF)
	{
		if ((uint32_t)(SrcBit+BitCount-1)/8 == SrcIndex ) // Last legal byte ?
		{
			BitAccu = ( ( (uint32_t)Src[SrcIndex] << ShiftCount ) + (BitAccu)) >> 8;
		}
		else
		{
			BitAccu = BitAccu >> 8;
		}

		Dest[DestIndex] = (uint8_t)( ( Dest[DestIndex] & LastSrcMask ) | (BitAccu & ~LastSrcMask) );
	}
}
*/
import "C"
import "errors"

// Table.
var gShift = [8]uint8{0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80}
var gMask = [8]uint8{0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f}

func Shift(cnt uint8) uint8 {
	return 1 << cnt
}

type fBitReader struct {
	buffer []byte
	num    int64
	pos    int64
	err    error
}

func NewFBitReader(src []byte, countBits int64) *fBitReader {
	reader := &fBitReader{
		buffer: src,
		num:    countBits,
		pos:    0,
	}

	if reader.num&7 > 0 {
		reader.buffer[reader.num>>3] &= gMask[reader.num&7]
	}

	return reader
}

func (f *fBitReader) ReadBit() uint8 {
	var bit uint8
	if !f.IsError() {
		localPos := f.pos
		localNum := f.num
		if localPos >= localNum {
			f.err = errors.New("pos >= num can't readBit")
		} else {
			bit = f.buffer[localPos>>3] & Shift(uint8(localPos&7))
			f.pos++
		}
	}
	return bit
}

func (f *fBitReader) ReadByte() uint8 {
	b := f.ReadBits(8)
	if len(b) > 0 {
		return b[0]
	} else {
		return 0
	}
}

func (f *fBitReader) ReadBits(lengthBits int64) []byte {
	if f.IsError() || f.pos+lengthBits >= f.num {
		if !f.IsError() {
			f.err = errors.New("pos+lengthBits > num can't ReadBits")
		}
		return nil
	}
	dest := make([]byte, (lengthBits+7)>>3)
	if lengthBits == 1 {
		dest[0] = 0
		if f.buffer[f.pos>>3]&Shift(uint8(f.pos&7)) != 0 {
			dest[0] |= 0x01
		}
		f.pos++
	} else if lengthBits != 0 {
		dest[((lengthBits+7)>>3)-1] = 0
		C.appBitsCpy((*C.uint8_t)(&dest[0]), C.int32_t(0), (*C.uint8_t)(&f.buffer[0]), C.int32_t(f.pos), C.int32_t(lengthBits))
		f.pos += lengthBits
	}

	return dest
}

func (f *fBitReader) ReadInt(valueMax uint32) uint32 {
	if f.err == nil {
		var value uint32
		var mask uint32
		localPos := f.pos
		localNum := f.num
		for mask = 1; (value+mask) < valueMax && mask != 0; mask, localPos = mask*2, localPos+1 {
			if localPos >= localNum {
				f.err = errors.New("pos >= num can't ReadInt")
				break
			}

			if (f.buffer[localPos>>3] & Shift(uint8(localPos&7))) != 0 {
				value |= mask
			}
		}

		f.pos = localPos
		return value
	}

	return 0
}

func (f *fBitReader) GetBitsLeft() int64 {
	return f.num - f.pos
}

func (f *fBitReader) AtEnd() bool {
	return f.err != nil || f.pos >= f.num-1
}

func (f *fBitReader) GetPosBits() int64 {
	return f.pos
}

func (f *fBitReader) GetNumBits() int64 {
	return f.num
}

func (f *fBitReader) IsError() bool {
	return f.err != nil
}
