package deserializer

type NetworkGUID int

func (n NetworkGUID) IsDynamic() bool {
	return n > 0 && n&1 == 0
}

func (n NetworkGUID) IsValid() bool {
	return n > 0
}

func (n NetworkGUID) IsStatic() bool {
	return n&1 != 0
}

func (n NetworkGUID) IsDefault() bool {
	return n == 1
}

func (n NetworkGUID) Value() int {
	return int(n)
}
