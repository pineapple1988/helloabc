package deserializer

type ExportFlags int

func (n ExportFlags) HasPath() bool {
	return 0 != (n & 1)
}

func (n ExportFlags) HasNetworkChecksum() bool {
	return 0 != (n & 0b100)
}

func (n ExportFlags) NoLoad() bool {
	return 0 != (n & 0b10)
}
