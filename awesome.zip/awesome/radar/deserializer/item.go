package deserializer

import "strings"

var category map[string]interface{}

func init() {
	category = map[string]interface{}{
		"Attach": map[string]interface{}{
			"Weapon": map[string]interface{}{
				"Lower": map[string]string{
					"AngledForeGrip": "grip",
					"Foregrip":       "grip",
				},
				"Magazine": map[string]map[string]string{
					"Extended": {
						"Large":       "Extended",
						"SniperRifle": "Extended",
					},
					"ExtendedQuickDraw": {
						"Large":       "Extended",
						"SniperRifle": "Extended",
					},
				},
				"Muzzle": map[string]interface{}{
					"Choke": "Choke",
					"Compensator": map[string]string{
						"Large":       "Compensator",
						"SniperRifle": "Compensator",
					},
					"FlashHider": map[string]string{
						"Large":       "FlashHider",
						"SniperRifle": "FlashHider",
					},
					"Suppressor": map[string]string{
						"Large":       "Suppressor",
						"SniperRifle": "Suppressor",
					},
				},
				"Stock": map[string]interface{}{
					"AR": "AR_Composite",
					"SniperRifle": map[string]string{
						"BulletLoops": "BulletLoops",
						"CheekPad":    "CheekPad",
					},
				},
				"Upper": map[string]string{
					"ACOG":  "4x",
					"CQBSS": "8x",
				},
			},
		},
		"Boost": "drink",
		"Heal": map[string]string{
			"FirstAid": "heal",
			"MedKit":   "heal",
		},
		"Weapon": map[string]string{
			"HK416":   "m416",
			"Kar98K":  "98k",
			"SCAR-L":  "scar",
			"AK47":    "ak",
			"SKS":     "sks",
			"Grenade": "grenade",
		},
		"Ammo": map[string]string{
			"556mm": "556",
			"762mm": "762",
		},
		"Armor": map[string]interface{}{
			"C": map[string]map[string]string{
				"01": {
					"Lv3": "armor3",
				},
			},
			"D": map[string]map[string]string{
				"01": {
					"Lv2": "armor2",
				},
			},
		},
		"Back": map[string]interface{}{
			"C": map[string]map[string]string{
				"01": {
					"Lv3": "bag3",
				},
				"02": {
					"Lv3": "bag3",
				},
			},
			"F": map[string]map[string]string{
				"01": {
					"Lv2": "bag2",
				},
				"02": {
					"Lv2": "bag2",
				},
			},
		},
		"Head": map[string]interface{}{
			"F": map[string]map[string]string{
				"01": {
					"Lv2": "helmet2",
				},
				"02": {
					"Lv2": "helmet2",
				},
			},
			"G": map[string]map[string]string{
				"01": {
					"Lv2": "helmet3",
				},
			},
		},
	}
}

func IsGood(description string) string {
	start := strings.Index(description, "Item_")
	if start == -1 {
		return ""
	}
	words := strings.Split(description[start+5:], "_")
	c := category
	for _, word := range words {
		sub := c[word]
		if sub == nil {
			return ""
		}
		switch sub.(type) {
		case string:
			return sub.(string)
		default:
			c = sub.(map[string]interface{})
		}
	}

	return ""
}
