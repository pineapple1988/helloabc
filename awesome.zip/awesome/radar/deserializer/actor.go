package deserializer

import (
	"awesome/radar/utils"
	"fmt"
	"log"
	"strings"
)

type Archetype int

const (
	Other                Archetype = 1
	GameState            Archetype = 2
	DroopedItemGroup     Archetype = 3
	Grenade              Archetype = 4
	TwoSeatBoat          Archetype = 5
	SixSeatBoat          Archetype = 6
	TwoSeatCar           Archetype = 7
	ThreeSeatCar         Archetype = 8
	FourSeatCar          Archetype = 9
	SixSeatCar           Archetype = 10
	Plane                Archetype = 11
	Player               Archetype = 12
	Parachute            Archetype = 13
	AirDrop              Archetype = 14
	PlayerState          Archetype = 15
	Team                 Archetype = 16
	DeathDropItemPackage Archetype = 17
	DroppedItem          Archetype = 18
	WeaponProcessor      Archetype = 19
	Weapon               Archetype = 20
)

func (ac Archetype) Name() string {
	switch ac {
	case Other:
		return "Other"
	case GameState:
		return "GameState"
	case DroopedItemGroup:
		return "DroopedItemGroup"
	case Grenade:
		return "Grenade"
	case TwoSeatBoat:
		return "TwoSeatBoat"
	case SixSeatBoat:
		return "SixSeatBoat"
	case TwoSeatCar:
		return "TwoSeatCar"
	case ThreeSeatCar:
		return "ThreeSeatCar"
	case FourSeatCar:
		return "FourSeatCar"
	case SixSeatCar:
		return "SixSeatCar"
	case Plane:
		return "Plane"
	case Player:
		return "Player"
	case Parachute:
		return "Parachute"
	case AirDrop:
		return "AirDrop"
	case PlayerState:
		return "PlayerState"
	case Team:
		return "Team"
	case DeathDropItemPackage:
		return "DeathDropItemPackage"
	case DroppedItem:
		return "DroppedItem"
	case WeaponProcessor:
		return "WeaponProcessor"
	case Weapon:
		return "Weapon"
	default:
		return ""
	}
}

func fromArchetype(archetype string) Archetype {
	log.Printf("archetype=[%s]", archetype)
	if strings.Contains(archetype, "Default__SurviveGameState") {
		return GameState
	} else if strings.Contains(archetype, "Default__BP_STExtraPlayer") {
		return Player
	} else if strings.Contains(archetype, "Default__BP_PlayerState") {
		return PlayerState
	} else if strings.Contains(archetype, "Default__BP_PlayerPawn") {
		return Player
	} else if strings.Contains(archetype, "DroppedItemGroup") {
		return DroopedItemGroup
	} else if strings.Contains(archetype, "Aircraft") {
		return Plane
	} else if strings.Contains(archetype, "Parachute") {
		return Parachute
	} else if strings.Contains(strings.ToLower(archetype), "bike") {
		return TwoSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "buggy") {
		return TwoSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "SideCar") {
		return TwoSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "dacia") {
		return FourSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "uaz") {
		return FourSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "pickup") {
		return FourSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "bus") {
		return SixSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "van") {
		return SixSeatCar
	} else if strings.Contains(strings.ToLower(archetype), "AquaRail") {
		return TwoSeatBoat
	} else if strings.Contains(strings.ToLower(archetype), "boat") {
		return SixSeatBoat
	} else if strings.Contains(strings.ToLower(archetype), "Carapackage") {
		return AirDrop
	} else if strings.Contains(strings.ToLower(archetype), "SmokeBomb") {
		return Grenade
	} else if strings.Contains(strings.ToLower(archetype), "Molotov") {
		return Grenade
	} else if strings.Contains(strings.ToLower(archetype), "Grenade") {
		return Grenade
	} else if strings.Contains(strings.ToLower(archetype), "FlashBang") {
		return Grenade
	} else if strings.Contains(strings.ToLower(archetype), "BigBomb") {
		return Grenade
	} else if strings.Contains(strings.ToLower(archetype), "DeathDropItemPackage") {
		return DeathDropItemPackage
	} else if strings.Contains(archetype, "DroppedItem") {
		return DroppedItem
	} else if strings.Contains(archetype, "Default__WeaponProcessor") {
		return WeaponProcessor
	} else if strings.Contains(archetype, "Weap") {
		return Weapon
	} else {
		return Other
	}
}

type Actor struct {
	NetGUID        NetworkGUID
	ArchetypeGUID  NetworkGUID
	Archetype      *NetGUIDCacheObject
	ChIndex        int
	Location       utils.Vector3
	Rotation       utils.Vector3
	Velocity       utils.Vector3
	Owner          NetworkGUID
	AttachParent   NetworkGUID
	AttachChildren map[NetworkGUID]NetworkGUID
	IsStatic       bool
	Type           Archetype
}

func NewActor(netGUID, archetypeGUID NetworkGUID, archetype *NetGUIDCacheObject, chIndex int) *Actor {
	Type := fromArchetype(archetype.PathName)

	return &Actor{
		NetGUID:        netGUID,
		ArchetypeGUID:  archetypeGUID,
		Archetype:      archetype,
		ChIndex:        chIndex,
		Type:           Type,
		AttachChildren: make(map[NetworkGUID]NetworkGUID),
	}
}

func (a *Actor) String() string {
	if a == nil {
		return ""
	}
	return fmt.Sprintf("Actor(NetGUID=%d,Location=%v,ArchetypeGUID=%d,Archetype=%v,ChIndex=%d,Type=%d,Rotation=%v,Velocity=%v,Owner=%d)",
		a.NetGUID, a.Location, a.ArchetypeGUID, a.Archetype, a.ChIndex, a.Type, a.Rotation, a.Velocity, a.Owner)
}

func (a *Actor) IsAPawn() bool {
	switch a.Type {
	case TwoSeatBoat,
		SixSeatBoat,
		TwoSeatCar,
		ThreeSeatCar,
		FourSeatCar,
		SixSeatCar,
		Plane,
		Player,
		Parachute:
		return true
	default:
		return false
	}
}

func (a *Actor) IsACharacter() bool {
	return a.Type == Player
}

func (a *Actor) IsVehicle() bool {
	return a.Type >= TwoSeatBoat && a.Type <= SixSeatCar
}
