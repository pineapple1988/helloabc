package deserializer

type Bunch struct {
	*Buffer
	BunchDataBits        int
	PacketID             int
	ChIndex              int
	ChType               int
	ChSequence           int
	Open                 bool
	Close                bool
	Dormant              bool
	IsReplicationPaused  bool
	Reliable             bool
	Partial              bool
	PartialInitial       bool
	PartialFinal         bool
	HasPackageMapExports bool
	HasMustBeMappedGUIDs bool
	Next                 *Bunch
}

func (bu *Bunch) DeepCopy(copyBits int) *Bunch {
	buf := bu.Buffer.DeepCopy(copyBits)

	bunch := &Bunch{
		BunchDataBits:        bu.BunchDataBits,
		PacketID:             bu.PacketID,
		ChIndex:              bu.ChIndex,
		ChType:               bu.ChType,
		ChSequence:           bu.ChSequence,
		Open:                 bu.Open,
		Close:                bu.Close,
		Dormant:              bu.Dormant,
		IsReplicationPaused:  bu.IsReplicationPaused,
		Reliable:             bu.Reliable,
		Partial:              bu.Partial,
		PartialInitial:       bu.PartialInitial,
		PartialFinal:         bu.PartialFinal,
		HasPackageMapExports: bu.HasPackageMapExports,
		HasMustBeMappedGUIDs: bu.HasMustBeMappedGUIDs,
	}

	bunch.Buffer = buf

	return bunch
}
