package deserializer

const (
	RELIABLE_BUFFER              = 256
	MAX_PACKETID                 = 16384
	MAX_CHANNELS                 = 10240
	MAX_CHSEQUENCE               = 4096
	MAX_BUNCH_HEADER_BITS        = 64
	NAME_SIZE                    = 1024
	MAX_NETWORKED_HARDCODED_NAME = 410

	ROLE_MAX = 4

	CHTYPE_NONE    = 0
	CHTYPE_CONTROL = 1
	CHTYPE_ACTOR   = 2
	CHTYPE_FILE    = 3
	CHTYPE_VOICE   = 4
	CHTYPE_MAX     = 8

	MAX_PACKET_SIZE = 512

	// control
	NMT_Hello               = 0
	NMT_Welcome             = 1
	NMT_Upgrade             = 2
	NMT_Challenge           = 3
	NMT_Netspeed            = 4
	NMT_Login               = 5
	NMT_Failure             = 6
	NMT_Join                = 9
	NMT_JoinSplit           = 10
	NMT_Skip                = 12
	NMT_Abort               = 13
	NMT_PCSwap              = 15
	NMT_ActorChannelFailure = 16
	NMT_DebugText           = 17
	NMT_NetGUIDAssign       = 18
	NMT_EncryptionAck       = 21
	NMT_BeaconWelcome       = 25
	NMT_BeaconJoin          = 26
	NMT_BeaconAssignGUID    = 27
	NMT_BeaconNetGUIDAck    = 28
)
