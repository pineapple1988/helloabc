package deserializer

import (
	"fmt"
	"log"
	"unicode"
)

type NetGUIDCacheObject struct {
	PathName           string
	OuterGUID          NetworkGUID
	networkChecksum    int
	bNoLoad            bool
	bIgnoreWhenMissing bool
	holdObj            interface{}
}

func (cacheObject *NetGUIDCacheObject) String() string {
	if cacheObject == nil {
		return "nil"
	}
	return fmt.Sprintf("{path='%s', outer[%d]}", cacheObject.PathName, cacheObject.OuterGUID)
}

type NetGUIDCache struct {
	ObjectLoop              map[NetworkGUID]*NetGUIDCacheObject
	IsExportingNetGUIDBunch bool
}

var GUIDCache *NetGUIDCache

func init() {
	GUIDCache = &NetGUIDCache{
		ObjectLoop:              make(map[NetworkGUID]*NetGUIDCacheObject),
		IsExportingNetGUIDBunch: false,
	}
}

func (cache *NetGUIDCache) OnGameStart() {
	cache.IsExportingNetGUIDBunch = false
	cache.ObjectLoop = make(map[NetworkGUID]*NetGUIDCacheObject)
}

func (cache *NetGUIDCache) OnGameOver() {
	cache.IsExportingNetGUIDBunch = false
	cache.ObjectLoop = make(map[NetworkGUID]*NetGUIDCacheObject)
}

func (cache *NetGUIDCache) Get(index int) *NetGUIDCacheObject {
	return cache.ObjectLoop[NetworkGUID(index)]
}

func (cache *NetGUIDCache) GetObjectFromNetGUID(netGUID NetworkGUID) *NetGUIDCacheObject {
	cacheObject := cache.ObjectLoop[netGUID]
	if cacheObject == nil {
		return nil
	}

	if isBlank(cacheObject.PathName) {
		return nil
	}
	return cacheObject
}

func (cache *NetGUIDCache) RegisterNetGUIDFromPathClient(netGUID NetworkGUID, pathName string, outerGUID NetworkGUID,
	networkChecksum int, bNoLoad bool, bIgnoreWhenMissing bool) {
	existingCacheObjectPtr := cache.ObjectLoop[netGUID]

	// If we find this guid, make sure nothing changes
	if existingCacheObjectPtr != nil {
		log.Printf("already register path!! original=%+v --------------> new=%d %s", existingCacheObjectPtr,
			netGUID, pathName)
		var bPathnameMismatch = false
		var bOuterMismatch = false
		if existingCacheObjectPtr.PathName != pathName {
			bPathnameMismatch = true
		}
		if existingCacheObjectPtr.OuterGUID != outerGUID {
			bOuterMismatch = true
		}

		if bPathnameMismatch || bOuterMismatch {
			log.Printf(",bPathnameMismatch:%t,bOuterMismatch:%t", bPathnameMismatch, bOuterMismatch)
		}
		return
	}

	// Register a new guid with this path
	cacheObject := &NetGUIDCacheObject{
		PathName:           pathName,
		OuterGUID:          outerGUID,
		networkChecksum:    networkChecksum,
		bNoLoad:            bNoLoad,
		bIgnoreWhenMissing: bIgnoreWhenMissing,
	}
	cache.ObjectLoop[netGUID] = cacheObject
	log.Printf("register path [%d] %+v", netGUID, cacheObject)
}

func (cache *NetGUIDCache) RegisterNetGUIDClient(netGUID NetworkGUID, obj interface{}) {
	existingCacheObjectPtr := cache.ObjectLoop[netGUID]

	// If we find this guid, make sure nothing changes
	if existingCacheObjectPtr != nil {
		//log.Printf("already register clien!! original=%+v --------------> new=%d obj %+v",
		//	actors[existingCacheObjectPtr.OuterGUID], NetGUID, obj)

		oldObj := existingCacheObjectPtr.holdObj
		if oldObj != nil && oldObj != obj {
			log.Printf("Reassigning netGUID %d", netGUID)
		}
		delete(cache.ObjectLoop, netGUID)
	}

	var cacheObject *NetGUIDCacheObject
	switch obj.(type) {
	case *NetGUIDCacheObject:
		cacheObject = &NetGUIDCacheObject{
			PathName:  obj.(*NetGUIDCacheObject).PathName,
			OuterGUID: netGUID,
		}
	case *Actor:
		cacheObject = &NetGUIDCacheObject{
			PathName:  obj.(*Actor).Archetype.PathName,
			OuterGUID: netGUID,
		}
	default:
		cacheObject = &NetGUIDCacheObject{
			PathName:  "",
			OuterGUID: netGUID,
		}
	}
	cache.ObjectLoop[netGUID] = cacheObject
	log.Printf("register obj:%+v", obj)
}

func isBlank(str string) bool {
	if len(str) <= 0 {
		return true
	}

	for _, c := range str {
		if !unicode.IsSpace(c) {
			return false
		}
	}

	return true
}
