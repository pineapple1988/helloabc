package deserializer

import (
	"awesome/radar/utils"
	"errors"
	"golang.org/x/text/encoding/unicode"
	"log"
	"math"
)

var gShift = [8]uint8{0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80}
var zeroByte byte = 0
var ShortRotationScale = 360.0 / 65535.0
var ByteRotationScale = 360.0 / 255.0

type ObjectPtr struct {
	key   NetworkGUID
	value *NetGUIDCacheObject
}

type Buffer struct {
	raw            []byte
	posBits        int
	localTotalBits int
	totalBits      int
	err            error
	nextBuffer     *Buffer
	last           *Buffer
	cur            *Buffer
}

func NewBuffer(raw []byte, bitSize int) *Buffer {
	buf := &Buffer{
		raw:            raw,
		posBits:        0,
		localTotalBits: bitSize,
		totalBits:      bitSize,
	}
	buf.cur = buf
	buf.last = buf

	return buf
}

func (b *Buffer) shallowCopy(maxTotalBits int) *Buffer {
	buf := &Buffer{
		raw:            b.raw,
		posBits:        b.posBits,
		localTotalBits: min(b.localTotalBits, maxTotalBits),
		totalBits:      min(b.localTotalBits, maxTotalBits),
	}
	buf.cur = buf
	buf.last = buf

	return buf
}

func (b *Buffer) IsError() bool {
	return b.err != nil
}

func (b *Buffer) DeepCopy(copyBits int) *Buffer {
	if copyBits > b.totalBits {
		log.Printf("deepCopy copyBits[%d] > totalBits[%d]", copyBits, b.totalBits)
		return nil
	}

	cpy := b.cur.shallowCopy(copyBits)
	for iter := b.cur.nextBuffer; iter != nil; iter = iter.nextBuffer {
		cpy.Append(iter.shallowCopy(copyBits - cpy.totalBits))
	}

	return cpy
}

func (b *Buffer) Append(buf *Buffer) *Buffer {
	b.last.nextBuffer = buf
	b.last = buf.last
	b.totalBits += buf.totalBits
	return b
}

func (b *Buffer) NotEnd() bool {
	return b.BitsLeft() > 0
}

func (b *Buffer) atEnd() bool {
	return b.BitsLeft() <= 0
}

func (b *Buffer) BitsLeft() int {
	return b.totalBits
}

func (b *Buffer) NumBytes() int {
	return (b.BitsLeft() + 7) >> 3
}

func (b *Buffer) readLocalBit() bool {
	bit := b.raw[b.posBits>>3] & gShift[b.posBits&0b0111]

	b.posBits++
	b.localTotalBits--

	return bit != zeroByte
}

func (b *Buffer) ReadBit() bool {
	if b.err != nil {
		return false
	}
	if b.cur.localTotalBits > 0 {
		b.totalBits--
		return b.cur.readLocalBit()
	} else if b.cur.nextBuffer != nil {
		for ; b.cur.nextBuffer != nil; {
			b.cur = b.cur.nextBuffer
			if b.cur.localTotalBits > 0 {
				b.totalBits--
				return b.cur.readLocalBit()
			}
		}
	}
	b.err = errors.New("index out of bounds")
	return false
}

func (b *Buffer) ReadByte() int {
	var value byte
	for i := 0; i < 8; i++ {
		if b.ReadBit() {
			value = value | gShift[i&0b0111]
		}
	}

	return int(value) & 0xff
}

func (b *Buffer) ReadBits(sizeBits int) []byte {
	value := make([]byte, (sizeBits+7)>>3)
	for i := 0; i < sizeBits; i++ {
		if b.ReadBit() {
			index := i >> 3
			value[index] = value[index] | gShift[i&0b0111]
		}
	}

	return value
}

func (b *Buffer) ReadBytes(sizeBytes int) []byte {
	return b.ReadBits(sizeBytes * 8)
}

func (b *Buffer) ReadInt(maxValue int) int {
	var mask = 1
	var value = 0
	for ; (value+mask) < maxValue && mask != 0; {
		if b.ReadBit() {
			value = value | mask
		}
		mask = mask << 1
	}

	return value
}

func (b *Buffer) ReadIntPacked() int {
	var value = 0
	var count = 0
	var more = 1
	for ; more != 0; {
		nextByte := b.ReadByte()         // Read next byte
		more = nextByte & 1              // Check 1 bit to see if there're more after this
		nextByte = nextByte >> 1         // Shift to get actual 7 bit value
		value += nextByte << (7 * count) // Add to total value
		count++
	}

	return value
}

func (b *Buffer) readInt8() int8 {
	return int8(b.ReadByte())
}

func (b *Buffer) ReadUInt8() uint8 {
	return uint8(b.ReadByte())
}

func (b *Buffer) ReadInt16() int16 {
	return int16(b.ReadUInt16())
}

func (b *Buffer) ReadUInt16() uint16 {
	var value = uint16(b.ReadByte())
	value = value | (uint16(b.ReadByte()) << 8)
	return value
}

func (b *Buffer) ReadInt32() int32 {
	return int32(b.ReadUInt32())
}

func (b *Buffer) ReadUInt32() uint32 {
	var value = uint32(b.ReadByte())
	value = value | (uint32(b.ReadByte()) << 8)
	value = value | (uint32(b.ReadByte()) << 16)
	value = value | (uint32(b.ReadByte()) << 24)
	return value
}

func (b *Buffer) readUInt64() uint64 {
	var value = uint64(b.ReadByte())
	value = value | (uint64(b.ReadByte()) << 8)
	value = value | (uint64(b.ReadByte()) << 16)
	value = value | (uint64(b.ReadByte()) << 24)
	value = value | (uint64(b.ReadByte()) << 32)
	value = value | (uint64(b.ReadByte()) << 40)
	value = value | (uint64(b.ReadByte()) << 48)
	value = value | (uint64(b.ReadByte()) << 56)
	return value
}

func (b *Buffer) readInt24() int {
	var value = b.ReadByte()
	value = value | (b.ReadByte() << 8)
	value = value | (b.ReadByte() << 16)
	return value
}

func (b *Buffer) ReadFloat() float32 {
	var value = uint32(b.ReadByte())
	value = value | (uint32(b.ReadByte()) << 8)
	value = value | (uint32(b.ReadByte()) << 16)
	value = value | (uint32(b.ReadByte()) << 24)
	return math.Float32frombits(value)
}

func (b *Buffer) ReadString() string {
	saveNum := b.ReadInt32()
	loadUCS2Char := saveNum < 0
	if loadUCS2Char {
		saveNum = -saveNum
	}
	if saveNum > NAME_SIZE {
		log.Fatal("ReadString out of bounds")
		return ""
	}
	if saveNum == 0 {
		return ""
	}

	if loadUCS2Char {
		decode := unicode.UTF16(unicode.LittleEndian, unicode.IgnoreBOM).NewDecoder()
		data, _ := decode.Bytes(b.ReadBytes(int(saveNum * 2)))
		//fmt.Println(hex.Dump(data))
		return string(data)
	} else {
		data := b.ReadBytes(int(saveNum))
		//fmt.Println(hex.Dump(data))
		return string(data[:len(data)-1])
	}
}

func (b *Buffer) ReadName() string {
	bHardcoded := b.ReadBit()
	if bHardcoded {
		nameIndex := b.ReadInt(MAX_NETWORKED_HARDCODED_NAME + 1)
		return Names[nameIndex]
	} else {
		inString := b.ReadString()
		b.ReadInt32()
		return inString
	}
}

func (b *Buffer) skipNetFieldExport() {
	flags := b.ReadUInt8()
	if flags == 1 {
		b.ReadIntPacked()
		b.ReadUInt32()
		b.ReadString()
		b.ReadString()
	}
}

func (b *Buffer) ReadObject() (NetworkGUID, *NetGUIDCacheObject) {
	netGUID := b.ReadNetworkGUID()
	var obj *NetGUIDCacheObject
	if !netGUID.IsValid() {
		return netGUID, obj
	}
	if netGUID.IsValid() && !netGUID.IsDefault() {
		obj = GUIDCache.GetObjectFromNetGUID(netGUID)
	}

	if netGUID.IsDefault() || GUIDCache.IsExportingNetGUIDBunch {
		exportFlags := ExportFlags(b.ReadUInt8())
		if exportFlags.HasPath() {
			outerGUID, _ := b.ReadObject()
			pathName := b.ReadString()
			networkChecksum := 0
			if exportFlags.HasNetworkChecksum() {
				networkChecksum = int(b.ReadUInt32())
			}
			//bIspackage := netGUID.IsStatic() && !pair.key.IsValid()

			if obj != nil {
				return netGUID, obj
			}

			if netGUID.IsDefault() {
				//assign guid
				return netGUID, obj
			}
			bIgnoreWhenMissing := exportFlags.NoLoad()
			// Register this path and outer guid combo with the net guid
			GUIDCache.RegisterNetGUIDFromPathClient(netGUID, pathName,
				outerGUID, networkChecksum, exportFlags.NoLoad(), bIgnoreWhenMissing)

			// Try again now that we've registered the path
			obj = GUIDCache.GetObjectFromNetGUID(netGUID)
		}
	}

	return netGUID, obj
}

func (b *Buffer) ReadNetworkGUID() NetworkGUID {
	return NetworkGUID(b.ReadIntPacked())
}

func (b *Buffer) ReadVector(scaleFactor int, maxBitsPerComponent int) utils.Vector3 {
	if scaleFactor == 0 {
		scaleFactor = 10
	}
	if maxBitsPerComponent == 0 {
		maxBitsPerComponent = 24
	}

	bits := b.ReadInt(maxBitsPerComponent)
	bias := 1 << (bits + 1)
	max := 1 << (bits + 2)

	x := float64(b.ReadInt(max)-bias) / float64(scaleFactor)
	y := float64(b.ReadInt(max)-bias) / float64(scaleFactor)
	z := float64(b.ReadInt(max)-bias) / float64(scaleFactor)
	return utils.Vector3{
		X: x,
		Y: y,
		Z: z,
	}
}

func (b *Buffer) ReadFixedVector(maxValue int, numBits int) utils.Vector3 {
	x := b.readFixedCompressedFloat(maxValue, numBits)
	y := b.readFixedCompressedFloat(maxValue, numBits)
	z := b.readFixedCompressedFloat(maxValue, numBits)
	return utils.Vector3{
		X: x,
		Y: y,
		Z: z,
	}
}

func (b *Buffer) readFixedCompressedFloat(maxValue, numBits int) float64 {
	maxBitValue := (1 << (numBits - 1)) - 1 // 0111 1111 - Max abs value we will serialize
	bias := 1 << (numBits - 1)              // 1000 0000 - Bias to pivot around (in order to support signed values)
	serIntMax := 1 << (numBits - 0)         // 1 0000 0000 - What we pass into SerializeInt
	//maxDelta := (1 << (numBits - 0)) - 1    // 1111 1111 - Max delta is
	delta := b.ReadInt(serIntMax)
	unscaledValue := float64(delta - bias)

	if maxValue > maxBitValue {
		invScale := float64(maxValue) / float64(maxBitValue)
		return unscaledValue * invScale
	} else {
		scale := float64(maxBitValue) / float64(maxValue)
		invScale := 1.0 / scale
		return unscaledValue * invScale
	}
}

func (b *Buffer) ReadRotationShort() utils.Vector3 {
	pitch := 0.0
	if b.ReadBit() {
		pitch = float64(b.ReadUInt16()) * ShortRotationScale
	}
	yaw := 0.0
	if b.ReadBit() {
		yaw = float64(b.ReadUInt16()) * ShortRotationScale
	}
	roll := 0.0
	if b.ReadBit() {
		roll = float64(b.ReadUInt16()) * ShortRotationScale
	}

	return utils.Vector3{
		X: pitch,
		Y: yaw,
		Z: roll,
	}
}

func (b *Buffer) ReadRotation() utils.Vector3 {
	pitch := 0.0
	if b.ReadBit() {
		pitch = float64(b.ReadUInt8()) * ByteRotationScale
	}
	yaw := 0.0
	if b.ReadBit() {
		yaw = float64(b.ReadUInt8()) * ByteRotationScale
	}
	roll := 0.0
	if b.ReadBit() {
		roll = float64(b.ReadUInt8()) * ByteRotationScale
	}

	return utils.Vector3{
		X: pitch,
		Y: yaw,
		Z: roll,
	}
}

func (b *Buffer) SkipBits(bits int) {
	decrease := min(b.cur.localTotalBits, bits)
	b.cur.localTotalBits -= decrease
	b.cur.posBits += decrease
	b.totalBits -= decrease
	bits -= decrease
	for ; bits > 0 && b.cur.nextBuffer != nil; {
		b.cur = b.cur.nextBuffer
		decrease = min(b.cur.localTotalBits, bits)
		b.cur.localTotalBits -= decrease
		b.cur.posBits += decrease
		b.totalBits -= decrease
		bits -= decrease
	}

	if bits > 0 {
		log.Printf("SkipBits out of bounds")
		b.err = errors.New("SkipBits out of bounds")
	}
}

func min(a, b int) int {
	if a >= b {
		return b
	} else {
		return a
	}
}
