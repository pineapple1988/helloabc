package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"encoding/hex"
	"fmt"
)

type gameStateCMD struct {
	TotalWarningDuration     float64
	ElapsedWarningDuration   float64
	TotalReleaseDuration     float64
	ElapsedReleaseDuration   float64
	RemainingTime            int
	MatchElapsedMinutes      int
	SafetyZonePosition       utils.Vector2
	SafetyZoneRadius         float64
	SafetyZoneBeginPosition  utils.Vector2
	SafetyZoneBeginRadius    float64
	PoisonGasWarningPosition utils.Vector2
	PoisonGasWarningRadius   float64
	RedZonePosition          utils.Vector2
	RedZoneRadius            float64
	NumJoinPlayers           int
	NumAlivePlayers          int
	NumAliveTeams            int
}

var GameStateCMD *gameStateCMD

func init() {
	GameStateCMD = &gameStateCMD{}
	GameStateCMD.TotalWarningDuration = 0
	GameStateCMD.ElapsedWarningDuration = 0
	GameStateCMD.TotalReleaseDuration = 0
	GameStateCMD.ElapsedReleaseDuration = 0
	GameStateCMD.RemainingTime = 0
	GameStateCMD.MatchElapsedMinutes = 0
	GameStateCMD.SafetyZonePosition = utils.Zero2()
	GameStateCMD.SafetyZoneRadius = 0
	GameStateCMD.SafetyZoneBeginPosition = utils.Zero2()
	GameStateCMD.SafetyZoneBeginRadius = 0
	GameStateCMD.PoisonGasWarningPosition = utils.Zero2()
	GameStateCMD.PoisonGasWarningRadius = 0
	GameStateCMD.RedZonePosition = utils.Zero2()
	GameStateCMD.RedZoneRadius = 0
	GameStateCMD.NumJoinPlayers = 0
	GameStateCMD.NumAlivePlayers = 0
	GameStateCMD.NumAliveTeams = 0
	utils.Register(GameStateCMD)
}

func (g *gameStateCMD) OnGameStart() {
}

func (g *gameStateCMD) OnGameOver() {
	g.TotalWarningDuration = 0
	g.ElapsedWarningDuration = 0
	g.TotalReleaseDuration = 0
	g.ElapsedReleaseDuration = 0
	g.RemainingTime = 0
	g.MatchElapsedMinutes = 0
	g.SafetyZonePosition = utils.Zero2()
	g.SafetyZoneRadius = 0
	g.SafetyZoneBeginPosition = utils.Zero2()
	g.SafetyZoneBeginRadius = 0
	g.PoisonGasWarningPosition = utils.Zero2()
	g.PoisonGasWarningRadius = 0
	g.RedZonePosition = utils.Zero2()
	g.RedZoneRadius = 0
	g.NumJoinPlayers = 0
	g.NumAlivePlayers = 0
	g.NumAliveTeams = 0
}

func GameStateCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {


	fmt.Printf("waitingHandle=%d\r\n", waitingHandle)
	oo := bunch.DeepCopy(bunch.BitsLeft())
	fmt.Println(hex.Dump(oo.ReadBits(oo.BitsLeft())))

	switch waitingHandle {
	case 16:
		bunch.ReadObject()
	case 17:
		bunch.ReadObject()
	case 18:
		bunch.ReadBit() // bReplicatedHasBegunPlay
	case 19:
		bunch.ReadFloat() // ReplicatedWorldTimeSeconds
	case 20:
		bunch.ReadName() // MatchState
	case 21:
		bunch.ReadInt32() // ElapsedTime
	case 22:
		bunch.ReadString() // MatchId
	case 23:
		//bunch.ReadString() // MatchShortGuid 有问题
	case 24:
		bunch.ReadBit() // bIsCustomGame
	case 25:
		bunch.ReadBit() // bIsWinnerZombieTeam
	case 26:
		bunch.ReadInt32() // NumTeams
	case 27:
		GameStateCMD.RemainingTime = int(bunch.ReadInt32())
	case 28:
		GameStateCMD.MatchElapsedMinutes = int(bunch.ReadInt32())
	case 29:
		bunch.ReadBit() // bTimerPaused
	case 30:
		GameStateCMD.NumJoinPlayers = int(bunch.ReadInt32())
	case 31:
		GameStateCMD.NumAlivePlayers = int(bunch.ReadInt32())
	case 32:
		bunch.ReadInt32() // NumAliveZombiePlayers
	case 33:
		GameStateCMD.NumAliveTeams = int(bunch.ReadInt32())
	case 34:
		bunch.ReadInt32() // NumStartPlayers
	case 35:
		bunch.ReadInt32() // NumStartTeams
	case 36:
		x := bunch.ReadFloat()
		y := bunch.ReadFloat()
		bunch.ReadFloat()
		GameStateCMD.SafetyZonePosition.X = float64(x)
		GameStateCMD.SafetyZonePosition.Y = float64(y)
	case 37:
		GameStateCMD.SafetyZoneRadius = float64(bunch.ReadFloat())
	case 38:
		x := bunch.ReadFloat()
		y := bunch.ReadFloat()
		bunch.ReadFloat()
		GameStateCMD.PoisonGasWarningPosition.X = float64(x)
		GameStateCMD.PoisonGasWarningPosition.Y = float64(y)
	case 39:
		GameStateCMD.PoisonGasWarningRadius = float64(bunch.ReadFloat())
	case 40:
		x := bunch.ReadFloat()
		y := bunch.ReadFloat()
		bunch.ReadFloat()
		GameStateCMD.RedZonePosition.X = float64(x)
		GameStateCMD.RedZonePosition.Y = float64(y)
	case 41:
		GameStateCMD.RedZoneRadius = float64(bunch.ReadFloat())
	case 42:
		GameStateCMD.TotalReleaseDuration = float64(bunch.ReadFloat())
	case 43:
		GameStateCMD.ElapsedReleaseDuration = float64(bunch.ReadFloat())
	case 44:
		GameStateCMD.TotalWarningDuration = float64(bunch.ReadFloat())
	case 45:
		GameStateCMD.ElapsedWarningDuration = float64(bunch.ReadFloat())
	case 46:
		bunch.ReadBit() // bIsGasRelease
	case 47:
		bunch.ReadBit() // bIsTeamMatch
	case 48:
		bunch.ReadBit() // bIsZombieMode
	case 49:
		x := bunch.ReadFloat()
		y := bunch.ReadFloat()
		bunch.ReadFloat()
		GameStateCMD.SafetyZoneBeginPosition.X = float64(x)
		GameStateCMD.SafetyZoneBeginPosition.Y = float64(y)
	case 50:
		GameStateCMD.SafetyZoneBeginRadius = float64(bunch.ReadFloat())
	case 51:
		bunch.ReadBit() // MatchStartType
	case 52:
		return false
	default:
		return false
	}
	return true
}
