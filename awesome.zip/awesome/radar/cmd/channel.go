package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"github.com/emirpasic/gods/maps/hashmap"
	"github.com/emirpasic/gods/sets/hashset"
	"log"
)

type Channel struct {
	ChIndex        int
	ChType         int
	Client         bool
	Dormant        bool
	Closing        bool
	InReliable     int
	InQueueFirst   *deserializer.Bunch
	InQueueLast    *deserializer.Bunch
	NumInRec       int
	InPartialBunch *deserializer.Bunch
}

func NewChannel(chIndex, chType int, client bool) *Channel {
	c := &Channel{}
	c.ChIndex = chIndex
	c.ChType = chType
	c.Client = client
	if client {
		c.InReliable = ChannelMgr.GlobalInReliable
	} else {
		c.InReliable = ChannelMgr.GlobalOutReliable
	}
	return c
}

type channelMgr struct {
	InChannels        *hashmap.Map
	OutChannels       *hashmap.Map
	ClosedInChannels  *hashset.Set
	ClosedOutChannels *hashset.Set
	GlobalOutReliable int
	GlobalInReliable  int
}

var ChannelMgr *channelMgr

func init() {
	ChannelMgr = &channelMgr{
		InChannels:        hashmap.New(),
		OutChannels:       hashmap.New(),
		ClosedInChannels:  hashset.New(),
		ClosedOutChannels: hashset.New(),
		GlobalInReliable:  -1,
		GlobalOutReliable: -1,
	}
	utils.Register(ChannelMgr)
}

func (cm *channelMgr) OnGameStart() {
}

func (cm *channelMgr) OnGameOver() {
	cm.InChannels = hashmap.New()
	cm.OutChannels = hashmap.New()
	cm.ClosedInChannels = hashset.New()
	cm.ClosedOutChannels = hashset.New()
	cm.GlobalInReliable = -1
	cm.GlobalOutReliable = -1
}

func (c *Channel) ReceiveNetGUIDBunch(bunch *deserializer.Bunch) {
	bHasRepLayoutExport := bunch.ReadBit()
	if bHasRepLayoutExport {
		log.Printf("ReceiveNetGUIDBunch bHasRepLayoutExport=%t", bHasRepLayoutExport)
		return
	}
	deserializer.GUIDCache.IsExportingNetGUIDBunch = true
	numGUIDsInBunch := bunch.ReadInt32()
	const MAX_GUID_COUNT = 2048
	if numGUIDsInBunch > MAX_GUID_COUNT {
		deserializer.GUIDCache.IsExportingNetGUIDBunch = false
		log.Fatalf("ReceiveNetGUIDBunch numGUIDsInBunch:%d > MAX_GUID_COUNT:%d", numGUIDsInBunch, MAX_GUID_COUNT)
		return
	}

	for i := int32(0); i < numGUIDsInBunch; i++ {
		bunch.ReadObject()
	}

	deserializer.GUIDCache.IsExportingNetGUIDBunch = false
}

func (c *Channel) ReceivedRawBunch(bunch *deserializer.Bunch, this interface{}) {
	if bunch.HasPackageMapExports {
		c.ReceiveNetGUIDBunch(bunch)
	}
	if bunch.Reliable && bunch.ChSequence <= c.InReliable {
		return
	}

	if c.Client {
		if ChannelMgr.GlobalInReliable < 0 {
			ChannelMgr.GlobalInReliable = bunch.ChSequence - 1
			c.InReliable = ChannelMgr.GlobalInReliable
		}
	} else {
		if ChannelMgr.GlobalOutReliable < 0 {
			ChannelMgr.GlobalOutReliable = bunch.ChSequence - 1
			c.InReliable = ChannelMgr.GlobalOutReliable
		}
	}

	if bunch.Reliable && bunch.ChSequence != c.InReliable+1 {
		if c.InQueueFirst == nil {
			c.InQueueFirst = bunch
			c.InQueueLast = bunch
		} else if bunch.ChSequence < c.InQueueFirst.ChSequence {
			bunch.Next = c.InQueueFirst
			c.InQueueFirst = bunch
		} else if bunch.ChSequence > c.InQueueLast.ChSequence {
			c.InQueueLast.Next = bunch
			c.InQueueLast = bunch
		} else {
			pre := c.InQueueFirst
			for ; pre != nil && pre.Next != nil && bunch.ChSequence > pre.Next.ChSequence; {
				pre = pre.Next
			}
			bunch.Next = pre.Next
			pre.Next = bunch
		}

		c.NumInRec++
		if c.NumInRec >= deserializer.RELIABLE_BUFFER {
			log.Fatal("UChannel::ReceivedRawBunch: Too many reliable messages queued up")
			return
		}
	} else {
		bDeleted := c.ReceivedNextBunch(bunch, this)
		if bDeleted {
			return
		}

		// Dispatch any waiting bunches.
		for ; c.InQueueFirst != nil; {
			if c.InQueueFirst.ChSequence != c.InReliable+1 {
				break
			}
			release := c.InQueueFirst
			c.InQueueFirst = c.InQueueFirst.Next
			c.NumInRec--
			bDeleted = c.ReceivedNextBunch(release, this)
			if bDeleted {
				return
			}
		}
	}
}

func (c *Channel) ReceivedNextBunch(bunch *deserializer.Bunch, this interface{}) bool {
	/*
	 * We received the next bunch. Basically at this point:
	 * -We know this is in order if reliable
	 * -We don't know if this is partial or not
	 * If it's not a partial bunch, or it completes a partial bunch, we can call ReceivedSequencedBunch to actually handle it
	 */
	if bunch.Reliable {
		c.InReliable = bunch.ChSequence // Reliables should be ordered properly at this point
	}

	handleBunch := bunch
	if bunch.Partial {
		handleBunch = nil
		if bunch.PartialInitial {
			// Create new InPartialBunch if this is the initial bunch of a new sequence.
			if c.InPartialBunch != nil {
				if !c.InPartialBunch.PartialFinal {
					if c.InPartialBunch.Reliable {
						// Unreliable partial trying to destroy reliable partial 1
						return false
						// We didn't complete the last partial bunch - this isn't fatal since they can be unreliable
					}
				}
				c.InPartialBunch = nil
			}

			c.InPartialBunch = bunch
			if !bunch.HasPackageMapExports && bunch.BitsLeft() > 0 {
				//if bunch.BitsLeft()%8 != 0 {
				//	log.Fatal("Received New partial bunch, But BitsLeft()%8 != 0")
				//}
				check(bunch.BitsLeft()%8 == 0)
			} else {
				log.Print("Received New partial bunch. It only contained NetGUIDs")
			}
		} else {
			/* Merge in next partial bunch to InPartialBunch if:
			 *	-We have a valid InPartialBunch
			 *	-The current InPartialBunch wasn't already complete
			 *  -ChSequence is next in partial sequence
			 *	-Reliability flag matches
			 */
			inPartialBunch := c.InPartialBunch
			if inPartialBunch != nil {
				bReliableSequencesMatches := bunch.ChSequence == inPartialBunch.ChSequence+1
				bUnreliableSequenceMatches := bReliableSequencesMatches || (bunch.ChSequence == inPartialBunch.ChSequence)
				bSequenceMatches := bUnreliableSequenceMatches
				if inPartialBunch.Reliable {
					bSequenceMatches = bReliableSequencesMatches
				}
				if !inPartialBunch.PartialFinal && bSequenceMatches && inPartialBunch.Reliable == bunch.Reliable {
					// Merge.
					if !bunch.HasPackageMapExports && bunch.NotEnd() {
						inPartialBunch.Append(bunch.Buffer)
					}

					// Only the final partial bunch should ever be non byte aligned. This is enforced during partial bunch creation
					// This is to ensure fast copies/appending of partial bunches. The final partial bunch may be non byte aligned.
					check(bunch.HasPackageMapExports || bunch.PartialFinal || bunch.BitsLeft()%8 == 0)

					// Advance the sequence of the current partial bunch so we know what to expect next
					inPartialBunch.ChSequence = bunch.ChSequence

					if bunch.PartialFinal {
						check(!bunch.HasPackageMapExports) // Shouldn't have these, they only go in initial partial export bunches
						handleBunch = inPartialBunch

						inPartialBunch.PartialFinal = true
						inPartialBunch.Close = bunch.Close
						inPartialBunch.Dormant = bunch.Dormant
						inPartialBunch.IsReplicationPaused = bunch.IsReplicationPaused
						inPartialBunch.HasMustBeMappedGUIDs = bunch.HasMustBeMappedGUIDs
					}
				} else {
					// Merge problem - delete InPartialBunch. This is mainly so that in the unlikely chance that ChSequence wraps around, we wont merge two completely separate partial bunches.
					if inPartialBunch.Reliable {
						log.Print("Unreliable partial trying to destroy reliable partial 2")
						return false
					}
					c.InPartialBunch = nil
				}
			}
		}

		const MAX_CONSTRUCTED_PARTIAL_SIZE_IN_BYTES = 8192 * 64
		if c.InPartialBunch != nil && c.InPartialBunch.NumBytes() > MAX_CONSTRUCTED_PARTIAL_SIZE_IN_BYTES {
			log.Print("Final partial bunch too large")
			return false
		}
	}
	if handleBunch != nil {
		// Remember the range.
		// In the case of a non partial, HandleBunch == radar.radar.struct.Bunch
		// In the case of a partial, HandleBunch should == InPartialBunch, and radar.radar.struct.Bunch should be the last bunch.

		// Receive it in sequence.
		return c.ReceivedSequencedBunch(handleBunch, this)
	}
	return false
}

func (c *Channel) ReceivedSequencedBunch(bunch *deserializer.Bunch, this interface{}) bool {
	if !c.Closing || bunch.Open {
		c.Closing = false
		switch this.(type) {
		case *ControlChannel:
			this.(*ControlChannel).ReceivedBunch(bunch)
		case *ActorChannel:
			this.(*ActorChannel).ReceivedBunch(bunch)
		}
	}
	// We have fully received the bunch, so process it.
	if bunch.Close {
		c.Dormant = bunch.Dormant
		c.Closing = true
		ChannelMgr.ClosedOutChannels.Add(c.ChIndex)
		c.InQueueFirst = nil
		c.InQueueLast = nil
		c.InPartialBunch = nil
		switch this.(type) {
		case *ControlChannel:
			this.(*ControlChannel).Close()
		case *ActorChannel:
			this.(*ActorChannel).Close()
		}
		return true
	}

	return false
}

func (c *Channel) ReceivedBunch(bunch *deserializer.Bunch) {
	log.Println("ReceivedBunch")
}

func (c *Channel) Close() {
	log.Println("Close")
}

func check(b bool) {
	if !b {
		log.Fatal("check error")
	}
}
