package cmd

import (
	"awesome/radar/deserializer"
	"log"
)

func WeaponCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 1:
		bunch.ReadBit() // bHidden
	case 2:
		bunch.ReadBit() // bReplicateMovement
	case 3:
		bunch.ReadBit() // bTearOff
	case 4:
		bunch.ReadInt(deserializer.ROLE_MAX) // role
	case 5:
		netGUID, obj := bunch.ReadObject()
		actor.Owner = 0
		if netGUID.IsValid() {
			actor.Owner = netGUID
		}

		log.Printf(" owner: [%d] %+v ---------> beOwned:%+v",
			netGUID, obj, actor)
	case 6:
		repMovement(bunch, actor)
	case 7:
		a, _ := bunch.ReadObject()
		var attachTo deserializer.NetworkGUID
		if a.IsValid() {
			ActorMgr.Actors[a].AttachChildren[actor.NetGUID] = actor.NetGUID
			attachTo = a
		}
		if actor.AttachParent != 0 {
			delete(ActorMgr.Actors[actor.AttachParent].AttachChildren, actor.NetGUID)
		}
		actor.AttachParent = attachTo
	case 8:
		bunch.ReadVector(100, 30) // locationOffset
		//if actor.Type == model.DroopedItemGroup {
		//	log.Printf("%+v locationOffset %+v", actor.Location, locationOffset)
		//}
		//log.Printf(",attachLocation %+v ----------> %+v", actor, locationOffset)
	case 9:
		bunch.ReadVector(100, 30)
	case 10:
		bunch.ReadRotationShort()
	case 11:
		bunch.ReadName() // attachSocket
	case 12:
		bunch.ReadObject() // attachComponnent, attachName
	case 13:
		bunch.ReadInt(deserializer.ROLE_MAX)
	case 14:
		bunch.ReadBit()
	case 15:
		bunch.ReadObject()
	// AWeaponProcessor
	case 16: // EquippedWeapons
		arraySize := bunch.ReadUInt16()
		equippedWeapons := ActorMgr.ActorHasWeapons[actor.Owner]
		if len(equippedWeapons) <= 0 {
			equippedWeapons = make([]int, arraySize)
		}
		index := bunch.ReadIntPacked()
		for ; index != 0; {
			netGUID, _ := bunch.ReadObject()
			equippedWeapons[index-1] = netGUID.Value()
			index = bunch.ReadIntPacked()
		}
		ActorMgr.ActorHasWeapons[actor.Owner] = equippedWeapons
	case 17: // CurrentWeaponIndex
		bunch.ReadInt32() //  currentWeaponIndex
	default:
		return false
	}
	return true
}
