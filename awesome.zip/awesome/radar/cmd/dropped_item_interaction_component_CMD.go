package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
)

var relativeLocation utils.Vector2
var relativeRotation utils.Vector3

func DroppedItemInteractionComponentCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 1:
		bunch.ReadBit() // bReplicates
	case 2:
		bunch.ReadBit() // isAlive
	case 3:
		bunch.ReadObject() // attachParent
	case 4:
		return false
	case 5:
		bunch.ReadName() // attachSocketName
	case 6:
		bunch.ReadBit() // bReplicatesAttachmentReference
	case 7:
		bunch.ReadBit() // bReplicatesAttachment
	case 8:
		bunch.ReadBit() // bAbsoluteLocation
	case 9:
		bunch.ReadBit() // bAbsoluteRotation
	case 10:
		bunch.ReadBit() // bAbsoluteScale
	case 11:
		bunch.ReadBit() // bVisible
	case 12:
		x := bunch.ReadFloat()
		y := bunch.ReadFloat()
		_ = bunch.ReadFloat()
		relativeLocation = utils.Vector2{
			X: float64(x),
			Y: float64(y),
		}
	case 13:
		relativeRotation = bunch.ReadRotationShort()
	case 14:
		// relativeScale3D
		bunch.ReadFloat()
		bunch.ReadFloat()
		bunch.ReadFloat()
	case 15:
		itemGUID, _ := bunch.ReadObject()
		loc := ActorMgr.DroppedItemLocation[itemGUID]
		if loc == nil {
			return true
		}
		ActorMgr.DroppedItemCompToItem[repObj.OuterGUID] = itemGUID
		loc.Location = relativeLocation
	default:
		return false
	}
	return true
}
