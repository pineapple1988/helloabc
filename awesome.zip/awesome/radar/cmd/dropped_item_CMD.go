package cmd

import (
	"awesome/radar/deserializer"
	"log"
)

func DroppedItemCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 16:
		itemGUID, item := bunch.ReadObject()
		ActorMgr.DroppedItemToItem[actor.NetGUID] = itemGUID
		log.Printf("%+v hasItem %d,%+v", actor, itemGUID, item)
	default:
		return false
	}

	return true
}
