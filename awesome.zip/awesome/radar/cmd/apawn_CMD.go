package cmd

import (
	"awesome/radar/deserializer"
	"log"
)

func APawnCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 1:
		if bunch.ReadBit() { // bHidden
			delete(ActorMgr.VisualActors, actor.NetGUID)
			log.Printf(",bHidden id=%v", actor)
		}
	case 2:
		if !bunch.ReadBit() { // bReplicateMovement
			if !actor.IsVehicle() {
				delete(ActorMgr.VisualActors, actor.NetGUID)
			}
			log.Printf(",!bReplicateMovement id=%v ", actor)
		}
	case 3:
		if bunch.ReadBit() { // bTearOff
			delete(ActorMgr.VisualActors, actor.NetGUID)
			log.Printf(",bTearOff id=%v ", actor)
		}
	case 4:
		role := bunch.ReadInt(deserializer.ROLE_MAX)
		log.Printf(",role = %d ", role)
	case 5:
		netGUID, obj := bunch.ReadObject()
		actor.Owner = 0
		if netGUID.IsValid() {
			actor.Owner = netGUID
		}
		log.Printf("owner: [%d] %+v ---------> beOwned:%+v", netGUID, obj, actor)
	case 6:
		repMovement(bunch, actor)
		switch actor.Type {
		case deserializer.AirDrop:
			ActorMgr.AirDropLocation[actor.NetGUID] = actor.Location
		case deserializer.Other:
		default:
			ActorMgr.VisualActors[actor.NetGUID] = actor
		}
	case 7:
		a, _ := bunch.ReadObject()
		var attachTo deserializer.NetworkGUID
		if a.IsValid() {
			if ActorMgr.Actors[a] != nil {
				ActorMgr.Actors[a].AttachChildren[actor.NetGUID] = actor.NetGUID
			}
			attachTo = a
		}
		if actor.AttachParent != 0 {
			aa, _ := ActorMgr.Actors[actor.AttachParent]
			if aa != nil {
				delete(aa.AttachChildren, actor.NetGUID)
			}
		}
		actor.AttachParent = attachTo
		//if actor.NetGUID == PlayerStateCMD.SelfID {
		//	SelfAttachTo = nil
		//	if attachTo != 0 {
		//		SelfAttachTo = channel.ActorMgr.Actors[actor.AttachParent]
		//	}
		//}
		log.Printf(",attachTo [%+v---------> %+v %+v %+v]",
			actor, a, deserializer.GUIDCache.GetObjectFromNetGUID(a), ActorMgr.Actors[a])
	case 8:
		locationOffset := bunch.ReadVector(100, 30)
		if actor.Type == deserializer.DroopedItemGroup {
			log.Printf("%+v locationOffset %+v", actor.Location, locationOffset)
		}
		log.Printf(",attachLocation %+v ----------> %+v", actor, locationOffset)
	default:
		return false
	}

	return true
}
