package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
)

type pair1 struct {
	A deserializer.NetworkGUID
	B deserializer.NetworkGUID
}

type playerStateCMD struct {
	PlayerNames    map[deserializer.NetworkGUID]string
	PlayerNumKills map[deserializer.NetworkGUID]int
	UniqueIDs      map[string]deserializer.NetworkGUID
	TeamNumbers    map[deserializer.NetworkGUID]int
	Attacks        []pair1
	SelfID         deserializer.NetworkGUID
	SelfStateID    deserializer.NetworkGUID
}

var PlayerStateCMD *playerStateCMD

func init() {
	PlayerStateCMD = &playerStateCMD{}
	PlayerStateCMD.PlayerNames = make(map[deserializer.NetworkGUID]string, 1)
	PlayerStateCMD.PlayerNumKills = make(map[deserializer.NetworkGUID]int)
	PlayerStateCMD.UniqueIDs = make(map[string]deserializer.NetworkGUID)
	PlayerStateCMD.TeamNumbers = make(map[deserializer.NetworkGUID]int)
	PlayerStateCMD.Attacks = []pair1{}
	PlayerStateCMD.SelfID = 0
	PlayerStateCMD.SelfStateID = 0
	utils.Register(PlayerStateCMD)
}

func (player *playerStateCMD) OnGameStart() {
}

func (player *playerStateCMD) OnGameOver() {
	player.PlayerNames = make(map[deserializer.NetworkGUID]string, 1)
	player.PlayerNumKills = make(map[deserializer.NetworkGUID]int)
	player.UniqueIDs = make(map[string]deserializer.NetworkGUID)
	player.TeamNumbers = make(map[deserializer.NetworkGUID]int)
	player.Attacks = []pair1{}
	player.SelfID = 0
	player.SelfStateID = 0
}

func PlayerStateCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 1:
		bunch.ReadBit() // bHidden
	case 2:
		bunch.ReadBit() // bReplicateMovement
	case 3:
		bunch.ReadBit() // bTearOff
	case 4:
		bunch.ReadInt(deserializer.ROLE_MAX) // role
	case 5:
		bunch.ReadObject() // ownerGUID, owner
	case 7:
		bunch.ReadObject() // a, obj
	case 13:
		bunch.ReadInt(deserializer.ROLE_MAX) // role
	case 16:
		bunch.ReadFloat() // score
	case 17:
		bunch.ReadByte() // ping
	case 18:
		name := bunch.ReadString()
		PlayerStateCMD.PlayerNames[actor.NetGUID] = name
	case 19:
		bunch.ReadInt32() // PlayerID
	case 20:
		bunch.ReadBit() // bFromPreviousLevel
	case 21:
		bunch.ReadBit() // isABot
	case 22:
		bunch.ReadBit() // bIsInactive
	case 23:
		bunch.ReadBit() // bIsSpectator
	case 24:
		bunch.ReadBit() // bOnlySpectator
	case 25:
		bunch.ReadInt32() // StartTime
	case 26:
		uniqueID := ""
		if bunch.ReadInt32() > 0 {
			uniqueID = bunch.ReadString()
		}
		PlayerStateCMD.UniqueIDs[uniqueID] = actor.NetGUID
	case 27: // indicate player's death
		bunch.ReadInt32() // Ranking
	case 28:
		bunch.ReadString() // AccountID
	case 29:
		//fmt.Println(hex.Dump(bunch.ReadBits(bunch.BitsLeft())))
		bunch.ReadString() // ReportToken
	case 30:
		return false
	case 31:
		bunch.ReadInt(4) // ObserverAuthorityType
	case 32:
		teamNumber := bunch.ReadInt(100)
		PlayerStateCMD.TeamNumbers[actor.NetGUID] = teamNumber
	case 33:
		bunch.ReadBit() // bIsZombie
	case 34:
		bunch.ReadFloat() // scoreByDamage
	case 35:
		bunch.ReadFloat() // ScoreByKill
	case 36:
		bunch.ReadFloat() // ScoreByRanking
	case 37:
		bunch.ReadFloat() // ScoreFactor
	case 38:
		numKills := bunch.ReadInt32()
		PlayerStateCMD.PlayerNumKills[actor.NetGUID] = int(numKills)
	case 39:
		bunch.ReadFloat()                          // TotalMovedDistanceMeter
		PlayerStateCMD.SelfStateID = actor.NetGUID // only self will get this update
	case 40:
		bunch.ReadFloat() // TotalGivenDamages
	case 41:
		bunch.ReadFloat() // LongestDistanceKill
	case 42:
		bunch.ReadInt32() // HeadShots
	case 43: //ReplicatedEquipableItems
		return false
	case 44:
		bunch.ReadBit() // bIsInAircraft
	case 45:
		bunch.ReadFloat() // lastHitTime
	case 46:
		currentAttackerPlayerNetId := bunch.ReadString()
		PlayerStateCMD.Attacks = append(PlayerStateCMD.Attacks, pair1{
			A: PlayerStateCMD.UniqueIDs[currentAttackerPlayerNetId],
			B: actor.NetGUID,
		})
	default:
		return false
	}

	return true
}
