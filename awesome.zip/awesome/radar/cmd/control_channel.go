package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"log"
)

type ControlChannel struct {
	Channel
}

func NewControlChannel(chIndex int, client bool) *ControlChannel {
	return &ControlChannel{
		Channel: *NewChannel(chIndex, deserializer.CHTYPE_CONTROL, client),
	}
}

func (cc *ControlChannel) ReceivedBunch(bunch *deserializer.Bunch) {
	messageType := bunch.ReadUInt8()
	log.Printf("receive ControlChannel messageType=%d", messageType)

	// 流程
	// NMT_Hello(发) ->
	// NMT_Challenge(收) ->
	// NMT_Login(发) ->
	// NMT_Welcome(收) ->  这里变成了NMT_DebugText
	// NMT_Netspeed(发)
	switch messageType {
	//case deserializer.NMT_Hello:
	//	isLittleEndian := bunch.ReadUInt8()
	//	localNetworkVersion := bunch.ReadUInt32()
	//	encryptionToken := bunch.ReadString()
	//	log.Printf("isLittleEndian=%d, localNetworkVersion=%d, encryptionToken=%s",
	//		isLittleEndian, localNetworkVersion, encryptionToken)
	//case deserializer.NMT_Welcome: // server tells Client they're ok'ed to load the server's level
	//	gameMap := bunch.ReadString()
	//	gameMode := bunch.ReadString()
	//	unknown := bunch.ReadString()
	//	utils.GameStart()
	//	log.Printf("Welcome To gameMap=%s, gameMode=%s unknown=%s",
	//		gameMap, gameMode, unknown)
	//case deserializer.NMT_Challenge:
	//	challenge := bunch.ReadString()
	//	log.Printf("challenge=%s", challenge)
	//case deserializer.NMT_Netspeed:
	//	// 这个是收到NMT_Welcome后才发送的
	//	currentNetSpeed := bunch.ReadUInt32()
	//	log.Printf("currentNetSpeed=%d", currentNetSpeed)
	//case deserializer.NMT_Login:
	//	clientResponse := bunch.ReadString()
	//	log.Printf("clientResponse=%s", clientResponse)
	case deserializer.NMT_DebugText:
		bunch.ReadString() // DSAppVersion
		bunch.ReadByte()
		gameMap := bunch.ReadString()
		gameMode := bunch.ReadString()
		utils.GameStart()
		log.Printf("Welcome To gameMap=%s, gameMode=%s",
			gameMap, gameMode)
	}
}

func (cc *ControlChannel) Close() {
	log.Println("Game over")
	utils.GameOver()
}
