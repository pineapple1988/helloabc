package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"log"
)

type teamCMD struct {
	Team map[string]string
}

var TeamCMD *teamCMD

func init() {
	TeamCMD = &teamCMD{}
	TeamCMD.Team = make(map[string]string)
	utils.Register(TeamCMD)
}

func (t *teamCMD) OnGameStart() {
}

func (t *teamCMD) OnGameOver() {
	t.Team = make(map[string]string)
}

func TeamCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 5:
		netGUID, obj := bunch.ReadObject()
		actor.Owner = 0
		if netGUID.IsValid() {
			actor.Owner = netGUID
		}

		log.Printf(" owner: [%d] %+v ---------> beOwned:%+v",
			netGUID, obj, actor)
	case 16:
		bunch.ReadVector(100, 30) // playerLocation
	case 17:
		bunch.ReadRotationShort() // playerRotation
	case 18:
		playerName := bunch.ReadString()
		TeamCMD.Team[playerName] = playerName
	default:
		return false
	}

	return true
}
