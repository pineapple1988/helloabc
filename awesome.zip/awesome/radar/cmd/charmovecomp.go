package cmd

import (
	"awesome/radar/deserializer"
	"encoding/hex"
	"fmt"
	"log"
)

// MoveAntiCheatComponent
func MoveAntiCheatComponent(bunch *deserializer.Bunch) {
	repIndex := bunch.ReadInt(8) // 这个是正确的
	payloadBits := bunch.ReadIntPacked()
	rpcPayload := bunch.DeepCopy(payloadBits)

	//log.Printf("MoveAntiCheatComponent repIndex=%d, payloadBits=%d, left=%d", repIndex, payloadBits, bunch.BitsLeft())
	//oo := rpcPayload.DeepCopy(rpcPayload.BitsLeft())
	//fmt.Println(hex.Dump(oo.ReadBits(oo.BitsLeft())))

	bunch.SkipBits(payloadBits)
	switch repIndex {
	case 4:
		if rpcPayload.ReadBit() {
			rpcPayload.ReadFloat()
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadFloat()
		}
		if rpcPayload.ReadBit() {
			clientLoc := rpcPayload.ReadVector(100, 30)
			SelfCoords.X = clientLoc.X
			SelfCoords.Y = clientLoc.Y
			log.Printf("MoveAntiCheatComponent SelfCoords=%+v\r\n", clientLoc)
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadFloat()
		}
	case 7:

	}
}

// CharMoveComp
func CharMoveComp(bunch *deserializer.Bunch) {
	repIndex := bunch.ReadInt(32) // 这个是正确的
	payloadBits := bunch.ReadIntPacked()
	rpcPayload := bunch.DeepCopy(payloadBits)

	log.Printf("CharMoveComp repIndex=%d, payloadBits=%d, left=%d", repIndex, payloadBits, bunch.BitsLeft())
	oo := rpcPayload.DeepCopy(rpcPayload.BitsLeft())
	fmt.Println(hex.Dump(oo.ReadBits(oo.BitsLeft())))

	bunch.SkipBits(payloadBits)
	switch repIndex {
	//// case 10,21,23,24: 直接全处理了
	default:
		//void ServerMove(float TimeStamp, const struct FVector_NetQuantize10& InAccel, const struct FVector_NetQuantize100& ClientLoc, unsigned char CompressedMoveFlags, unsigned char ClientRoll, uint32_t View, class UPrimitiveComponent* ClientMovementBase, const struct FName& ClientBaseBoneName, unsigned char ClientMovementMode);
		//void ServerMoveDual(float TimeStamp0, const struct FVector_NetQuantize10& InAccel0, unsigned char PendingFlags, uint32_t View0, float TimeStamp, const struct FVector_NetQuantize10& InAccel, const struct FVector_NetQuantize100& ClientLoc, unsigned char NewFlags, unsigned char ClientRoll, uint32_t View, class UPrimitiveComponent* ClientMovementBase, const struct FName& ClientBaseBoneName, unsigned char ClientMovementMode);
		if rpcPayload.ReadBit() {
			rpcPayload.ReadFloat() // timeStamp0
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadVector(10, 24) // inAccel0
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadUInt8() // PendingFlags
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadUInt32() // view0
		}

		if rpcPayload.ReadBit() {
			rpcPayload.ReadFloat() // timeStamp
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadVector(10, 24) // inAccel
		}
		if rpcPayload.ReadBit() {
			clientLoc := rpcPayload.ReadVector(100, 30)
			SelfCoords.X = clientLoc.X
			SelfCoords.Y = clientLoc.Y
			log.Printf("CharMoveComp SelfCoords=%+v", clientLoc)
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadUInt8() // NewFlags
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadUInt8() // ClientRoll
		}
		if rpcPayload.ReadBit() {
			rpcPayload.ReadUInt32() // View
			//SelfDirection = float64(view>>16) * deserializer.ShortRotationScale
			//log.Printf("CharMoveComp SelfDirection=%+v", SelfDirection)
		}
	}
}
