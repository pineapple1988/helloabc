package cmd

import (
	"awesome/radar/deserializer"
)

type REPCMD int

const (
	DynamicArray         REPCMD = 0  //0 Dynamic array
	Return               REPCMD = 1  //1 Return from array REPCMD = or end of stream
	Property             REPCMD = 2  //2 Generic property
	PropertyBool         REPCMD = 3  //3
	PropertyFloat        REPCMD = 4  //4
	PropertyInt          REPCMD = 5  //5
	PropertyByte         REPCMD = 6  //6
	PropertyName         REPCMD = 7  //7
	PropertyObject       REPCMD = 8  //8
	PropertyUInt32       REPCMD = 9  //9
	PropertyVector       REPCMD = 10 //10
	PropertyRotator      REPCMD = 11 //11
	PropertyPlane        REPCMD = 12 //12
	PropertyVector100    REPCMD = 13 //13
	PropertyNetId        REPCMD = 14 //14
	RepMovement          REPCMD = 15 //15
	PropertyVectorNormal REPCMD = 16 //16
	PropertyVector10     REPCMD = 17 //17
	PropertyVectorQ      REPCMD = 18 //18
	PropertyString       REPCMD = 19 //19
	PropertyUInt64       REPCMD = 20 //20
)

func repMovement(bunch *deserializer.Bunch, actor *deserializer.Actor) {
	_ = bunch.ReadBit() // bSimulatedPhysicSleep
	bRepPhysics := bunch.ReadBit()
	if actor.IsAPawn() {
		actor.Location = bunch.ReadVector(100, 30)
	} else {
		actor.Location = bunch.ReadVector(1, 24)
	}

	if actor.IsACharacter() {
		actor.Rotation = bunch.ReadRotationShort()
	} else {
		actor.Rotation = bunch.ReadRotation()
	}

	actor.Velocity = bunch.ReadVector(1, 24)
	if bRepPhysics {
		bunch.ReadVector(1, 24)
	}
}

type cmdProcessor func(actor *deserializer.Actor, bunch *deserializer.Bunch, object *deserializer.NetGUIDCacheObject, n int, m map[string]interface{}) bool

var Processors map[string]cmdProcessor

func init() {
	Processors = map[string]cmdProcessor{
		deserializer.GameState.Name():        GameStateCMDProcess,
		deserializer.Player.Name():           ActorCMDProcess,
		deserializer.PlayerState.Name():      PlayerStateCMDProcess,
		deserializer.DroppedItem.Name():      DroppedItemCMDProcess,
		deserializer.Team.Name():             TeamCMDProcess,
		"DroppedItemInteractionComponent":    DroppedItemInteractionComponentCMDProcess,
		"DroppedItemGroupRootComponent":      DroppedItemGroupRootComponentCMDProcess,
		deserializer.WeaponProcessor.Name():  WeaponCMDProcess,
		deserializer.Other.Name():            APawnCMDProcess,
		deserializer.DroopedItemGroup.Name(): APawnCMDProcess,
		deserializer.Grenade.Name():          APawnCMDProcess,
		deserializer.TwoSeatBoat.Name():      APawnCMDProcess,
		deserializer.SixSeatBoat.Name():      APawnCMDProcess,
		deserializer.TwoSeatCar.Name():       APawnCMDProcess,
		deserializer.ThreeSeatCar.Name():     APawnCMDProcess,
		deserializer.FourSeatCar.Name():      APawnCMDProcess,
		deserializer.SixSeatCar.Name():       APawnCMDProcess,
		deserializer.Plane.Name():            APawnCMDProcess,
		deserializer.Parachute.Name():        APawnCMDProcess,
		deserializer.AirDrop.Name():          APawnCMDProcess,
	}
}
