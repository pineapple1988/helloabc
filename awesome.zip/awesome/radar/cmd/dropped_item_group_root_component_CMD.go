package cmd

import (
	"awesome/radar/deserializer"
)

func DroppedItemGroupRootComponentCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 4:
		arraySize := bunch.ReadUInt16()
		comps := ActorMgr.DroppedItemGroup[actor.NetGUID]
		newOne := len(comps) <= 0
		index := bunch.ReadIntPacked()
		var toRemove, toAdd []deserializer.NetworkGUID
		for ; index != 0; {
			i := index - 1
			netGUID, _ := bunch.ReadObject()
			if newOne {
				comps = append(comps, netGUID)
			} else {
				// remove index
				toRemove = append(toRemove, comps[i])
				comps[i] = netGUID
				toAdd = append(toAdd, netGUID)
			}
			index = bunch.ReadIntPacked()
		}

		for i := int(arraySize); i < len(comps); i-- {
			toRemove = append(toRemove, comps[i])
			comps = append(comps[:i], comps[i+1:]...)
		}
		toRemove = append(toRemove, toAdd...)
		ActorMgr.DroppedItemGroup[actor.NetGUID] = comps
		for _, removedComp := range toRemove {
			delete(ActorMgr.DroppedItemLocation, ActorMgr.DroppedItemCompToItem[removedComp])
		}
	default:
		return false
	}
	return true
}
