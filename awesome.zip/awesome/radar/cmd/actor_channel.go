package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"fmt"
	"log"
)

type pair0 struct {
	Location  utils.Vector2
	ShortName string
}

type actorMgr struct {
	Actors                map[deserializer.NetworkGUID]*deserializer.Actor
	VisualActors          map[deserializer.NetworkGUID]*deserializer.Actor
	AirDropLocation       map[deserializer.NetworkGUID]utils.Vector3
	DroppedItemToItem     map[deserializer.NetworkGUID]deserializer.NetworkGUID
	DroppedItemGroup      map[deserializer.NetworkGUID][]deserializer.NetworkGUID
	DroppedItemCompToItem map[deserializer.NetworkGUID]deserializer.NetworkGUID
	DroppedItemLocation   map[deserializer.NetworkGUID]*pair0
	CorpseLocation        map[deserializer.NetworkGUID]utils.Vector3
	ActorHasWeapons       map[deserializer.NetworkGUID][]int
	Weapons               map[int]*deserializer.Actor
}

var ActorMgr *actorMgr

func init() {
	ActorMgr = &actorMgr{}
	ActorMgr.Actors = make(map[deserializer.NetworkGUID]*deserializer.Actor)
	ActorMgr.VisualActors = make(map[deserializer.NetworkGUID]*deserializer.Actor)
	ActorMgr.AirDropLocation = make(map[deserializer.NetworkGUID]utils.Vector3)
	ActorMgr.DroppedItemToItem = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	ActorMgr.DroppedItemGroup = make(map[deserializer.NetworkGUID][]deserializer.NetworkGUID)
	ActorMgr.DroppedItemCompToItem = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	ActorMgr.DroppedItemLocation = make(map[deserializer.NetworkGUID]*pair0)
	ActorMgr.CorpseLocation = make(map[deserializer.NetworkGUID]utils.Vector3)
	ActorMgr.ActorHasWeapons = make(map[deserializer.NetworkGUID][]int)
	ActorMgr.Weapons = make(map[int]*deserializer.Actor)
	utils.Register(ActorMgr)
}

func (am *actorMgr) OnGameStart() {
}

func (am *actorMgr) OnGameOver() {
	am.Actors = make(map[deserializer.NetworkGUID]*deserializer.Actor)
	am.VisualActors = make(map[deserializer.NetworkGUID]*deserializer.Actor)
	am.AirDropLocation = make(map[deserializer.NetworkGUID]utils.Vector3)
	am.DroppedItemToItem = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	am.DroppedItemGroup = make(map[deserializer.NetworkGUID][]deserializer.NetworkGUID)
	am.DroppedItemCompToItem = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	am.DroppedItemLocation = make(map[deserializer.NetworkGUID]*pair0)
	am.CorpseLocation = make(map[deserializer.NetworkGUID]utils.Vector3)
	am.ActorHasWeapons = make(map[deserializer.NetworkGUID][]int)
	am.Weapons = make(map[int]*deserializer.Actor)
}

type ActorChannel struct {
	Channel
	actor *deserializer.Actor
}

func NewActorChannel(chIndex int, client bool) *ActorChannel {
	return &ActorChannel{
		Channel: *NewChannel(chIndex, deserializer.CHTYPE_ACTOR, client),
	}
}

func (ac *ActorChannel) ReceivedBunch(bunch *deserializer.Bunch) {
	if ac.Client && bunch.HasMustBeMappedGUIDs {
		numMustBeMappedGUIDs := bunch.ReadUInt16()
		for i := uint16(0); i < numMustBeMappedGUIDs; i++ {
			bunch.ReadNetworkGUID()
		}
	}

	ac.ProcessBunch(bunch)
}

func (ac *ActorChannel) Close() {
	if ac.actor != nil {
		if ac.Client {
			delete(ActorMgr.Actors, ac.actor.NetGUID)
			delete(ActorMgr.VisualActors, ac.actor.NetGUID)
		}
		ac.actor = nil
	}
}

func (ac *ActorChannel) SerializeActor(bunch *deserializer.Bunch) {
	netGUID, newActor := bunch.ReadObject()
	if netGUID.IsDynamic() {
		archetypeNetGUID, archetype := bunch.ReadObject()
		if archetypeNetGUID.IsValid() && archetype == nil {
			existingCacheObjectPtr := deserializer.GUIDCache.ObjectLoop[archetypeNetGUID]
			if existingCacheObjectPtr != nil {
				log.Printf("Unresolved Archetype GUID. Path: %s, NetGUID: %d",
					existingCacheObjectPtr.PathName, archetypeNetGUID)
			} else {
				log.Printf("Unresolved Archetype GUID. Guid not registered!, NetGUID: %d",
					archetypeNetGUID)
			}
		}
		bSerializeLocation := bunch.ReadBit()
		location := utils.Zero3()
		if bSerializeLocation {
			location = bunch.ReadVector(10, 24)
		}
		bSerializeRotation := bunch.ReadBit()
		rotation := utils.Zero3()
		if bSerializeRotation {
			rotation = bunch.ReadVector(10, 24)
		}
		bSerializeScale := bunch.ReadBit()
		_ = utils.Zero3() // scale
		if bSerializeScale {
			_ = bunch.ReadVector(10, 24)
		}
		bSerializeVelocity := bunch.ReadBit()
		velocity := utils.Zero3()
		if bSerializeVelocity {
			velocity = bunch.ReadVector(10, 24)
		}
		if ac.actor == nil && archetype != nil {
			_actor := deserializer.NewActor(netGUID, archetypeNetGUID, archetype, ac.ChIndex)
			_actor.Location = location
			_actor.Rotation = rotation
			_actor.Velocity = velocity
			deserializer.GUIDCache.RegisterNetGUIDClient(_actor.NetGUID, _actor)
			ac.actor = _actor
			if ac.Client {
				ActorMgr.Actors[netGUID] = _actor
				switch _actor.Type {
				case deserializer.Weapon:
					ActorMgr.Weapons[netGUID.Value()] = _actor
				case deserializer.AirDrop:
					ActorMgr.AirDropLocation[netGUID] = location
				case deserializer.DeathDropItemPackage:
					ActorMgr.CorpseLocation[netGUID] = location
				default:
				}
			}
			log.Printf("spawn %+v", ac.actor)
		}
		log.Printf(",[%d] spawn:%+v,%+v,%+v; actor:%+v",
			netGUID, location, rotation, velocity, ac.actor)
	} else {
		if newActor == nil {
			return
		}

		ac.actor = deserializer.NewActor(netGUID, newActor.OuterGUID, newActor, ac.ChIndex)
		ac.actor.IsStatic = true
	}
}

func (ac *ActorChannel) ProcessBunch(bunch *deserializer.Bunch) {
	if ac.Client && ac.actor == nil {
		if !bunch.Open {
			return
		}
		ac.SerializeActor(bunch)
		if ac.actor == nil {
			return
		}
	}

	if !ac.Client && ac.actor == nil {
		var clientChannel interface{}
		clientChannel, _ = ChannelMgr.InChannels.Get(ac.ChIndex)
		if clientChannel == nil {
			return
		}
		ac.actor = clientChannel.(*ActorChannel).actor
		if ac.actor == nil {
			return
		}
	}
	if ac.actor.Type == deserializer.DroppedItem && bunch.BitsLeft() == 0 {
		delete(ActorMgr.DroppedItemLocation, ac.actor.NetGUID)
	}

	for ; bunch.NotEnd(); {
		// header
		bHasRepLayout := bunch.ReadBit()
		bIsActor := bunch.ReadBit()
		var repObj *deserializer.NetGUIDCacheObject
		if bIsActor {
			repObj = &deserializer.NetGUIDCacheObject{
				PathName:  ac.actor.Type.Name(),
				OuterGUID: ac.actor.NetGUID,
			}
		} else {
			netGUID, _subObj := bunch.ReadObject() // SubObject, SubObjectNetGUID
			if !ac.Client {
				if _subObj == nil { // The server should never need to create sub objects
					continue
				}
				repObj = _subObj
				log.Printf("%+v hasSubObj %+v", ac.actor, repObj)
			} else {
				bStablyNamed := bunch.ReadBit()
				if bStablyNamed { // If this is a stably named sub-object, we shouldn't need to create it
					if _subObj == nil {
						continue
					}
					repObj = _subObj
				} else {
					classGUID, classObj := bunch.ReadObject() // SubOjbectClass, SubObjectClassNetGUID
					if classObj != nil && (ac.actor.Type == deserializer.DroopedItemGroup || ac.actor.Type == deserializer.DroppedItem) {
						sn := deserializer.IsGood(classObj.PathName)
						if sn != "" {
							ActorMgr.DroppedItemLocation[netGUID] = &pair0{
								Location: utils.Vector2{
									X: ac.actor.Location.X,
									Y: ac.actor.Location.Y,
								},
								ShortName: sn,
							}
						}
					}
					log.Printf("subObjClass:%d %s classObj:%+v",
						ac.actor.NetGUID, ac.actor.Archetype.PathName, classObj)
					if !classGUID.IsValid() || classObj == nil {
						continue
					}

					subObj := &deserializer.NetGUIDCacheObject{
						PathName:  classObj.PathName,
						OuterGUID: classGUID,
					}
					deserializer.GUIDCache.RegisterNetGUIDClient(netGUID, subObj)
					repObj = deserializer.GUIDCache.GetObjectFromNetGUID(netGUID)
				}
			}
		}
		numPayloadBits := bunch.ReadIntPacked()
		if numPayloadBits < 0 || numPayloadBits > bunch.BitsLeft() {
			log.Printf("NumPayloadBits=%d > bunch.bitsLeft()=%d",
				numPayloadBits, bunch.BitsLeft())
			return
		}
		if numPayloadBits == 0 {
			continue
		}

		outPayload := bunch.DeepCopy(numPayloadBits)
		log.Printf("bHasRepLayout=%t, actor[%d] archetype=%+v",
			bHasRepLayout, ac.actor.NetGUID, ac.actor.Archetype)
		if bHasRepLayout {
			if !ac.Client { // Server shouldn't receive properties.
				return
			}
			if ac.actor.Type == deserializer.DroopedItemGroup && repObj.PathName == "RootComponent" {
				repObj = &deserializer.NetGUIDCacheObject{
					PathName:  "DroppedItemGroupRootComponent",
					OuterGUID: repObj.OuterGUID,
				}
			}
			RepLayoutBunch(outPayload, repObj, ac.actor)
		}
		if !ac.Client && repObj.PathName == "MoveAntiCheatComponent" {
			PlayerStateCMD.SelfID = ac.actor.NetGUID
			for ; outPayload.NotEnd(); {
				MoveAntiCheatComponent(outPayload)
			}
		}
		// 这个里面的数据没找到可用的坐标
		//if !ac.Client && repObj.PathName == "CharMoveComp" {
		//	PlayerStateCMD.SelfID = ac.actor.NetGUID
		//	for ; outPayload.NotEnd(); {
		//		CharMoveComp(outPayload)
		//	}
		//}

		bunch.SkipBits(numPayloadBits)
		if bunch.IsError() {
			return
		}
	}
}

func RepLayoutBunch(bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject, actor *deserializer.Actor) {
	cmdProcessor := Processors[repObj.PathName]
	if cmdProcessor == nil {
		return
	}

	fmt.Printf("bDoChecksum=%+v\r\n", bunch.ReadBit())
	waitingHandle := bunch.ReadIntPacked()
	data := make(map[string]interface{})
	for ; waitingHandle > 0 && cmdProcessor(actor, bunch, repObj, waitingHandle, data) && bunch.NotEnd(); {
		waitingHandle = bunch.ReadIntPacked()
	}
}
