package cmd

import (
	"awesome/radar/deserializer"
	"awesome/radar/utils"
	"log"
)

var SelfCoords utils.Vector2
var SelfAttachTo *deserializer.Actor

type actorCMD struct {
	ActorWithPlayerState map[deserializer.NetworkGUID]deserializer.NetworkGUID
	PlayerStateToActor   map[deserializer.NetworkGUID]deserializer.NetworkGUID
	ActorHealth          map[deserializer.NetworkGUID]float32
}

var ActorCMD *actorCMD

func init() {
	ActorCMD = &actorCMD{}
	utils.Register(ActorCMD)
}

func (a *actorCMD) OnGameStart() {
	a.ActorWithPlayerState = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	a.PlayerStateToActor = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	a.ActorHealth = make(map[deserializer.NetworkGUID]float32)
}

func (a *actorCMD) OnGameOver() {
	a.ActorWithPlayerState = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	a.PlayerStateToActor = make(map[deserializer.NetworkGUID]deserializer.NetworkGUID)
	a.ActorHealth = make(map[deserializer.NetworkGUID]float32)
}

func ActorCMDProcess(actor *deserializer.Actor, bunch *deserializer.Bunch, repObj *deserializer.NetGUIDCacheObject,
	waitingHandle int, data map[string]interface{}) bool {
	switch waitingHandle {
	case 1:
		if bunch.ReadBit() { // bHidden
			delete(ActorMgr.VisualActors, actor.NetGUID)
			log.Printf(",bHidden id=%v", actor)
		}
	case 2:
		if !bunch.ReadBit() { // bReplicateMovement
			if !actor.IsVehicle() {
				delete(ActorMgr.VisualActors, actor.NetGUID)
			}
			log.Printf(",!bReplicateMovement id=%v ", actor)
		}
	case 3:
		if bunch.ReadBit() { // bTearOff
			delete(ActorMgr.VisualActors, actor.NetGUID)
			log.Printf(",bTearOff id=%v ", actor)
		}
	case 4:
		role := bunch.ReadInt(deserializer.ROLE_MAX)
		log.Printf(",role = %d ", role)
	case 5:
		netGUID, obj := bunch.ReadObject()
		actor.Owner = 0
		if netGUID.IsValid() {
			actor.Owner = netGUID
		}
		log.Printf("owner: [%d] %+v ---------> beOwned:%+v", netGUID, obj, actor)
	case 6:
		repMovement(bunch, actor)
		switch actor.Type {
		case deserializer.AirDrop:
			ActorMgr.AirDropLocation[actor.NetGUID] = actor.Location
		case deserializer.Other:
		default:
			ActorMgr.VisualActors[actor.NetGUID] = actor
		}
	case 7:
		a, _ := bunch.ReadObject()
		var attachTo deserializer.NetworkGUID
		if a.IsValid() {
			ActorMgr.Actors[a].AttachChildren[actor.NetGUID] = actor.NetGUID
			attachTo = a
		}
		if actor.AttachParent != 0 {
			delete(ActorMgr.Actors[actor.AttachParent].AttachChildren, actor.NetGUID)
		}
		actor.AttachParent = attachTo
		if actor.NetGUID == PlayerStateCMD.SelfID {
			SelfAttachTo = nil
			if attachTo != 0 {
				SelfAttachTo = ActorMgr.Actors[actor.AttachParent]
			}
		}
		log.Printf(",attachTo [%+v---------> %+v %+v %+v",
			actor, a, deserializer.GUIDCache.GetObjectFromNetGUID(a), ActorMgr.Actors[a])
	case 8:
		locationOffset := bunch.ReadVector(100, 30)
		if actor.Type == deserializer.DroopedItemGroup {
			log.Printf("%+v locationOffset %+v", actor.Location, locationOffset)
		}
		log.Printf(",attachLocation %+v ----------> %+v", actor, locationOffset)
	case 9:
		bunch.ReadVector(100, 30)
	case 10:
		bunch.ReadRotationShort()
	case 11:
		bunch.ReadName() // attachSocket
	case 12:
		bunch.ReadObject() // attachComponnent, attachName
	case 13:
		bunch.ReadInt(deserializer.ROLE_MAX)
	case 14:
		bunch.ReadBit()
	case 15:
		bunch.ReadObject()
	case 16:
		playerStateGUID, _ := bunch.ReadObject() // playerState
		if playerStateGUID.IsValid() {
			ActorCMD.ActorWithPlayerState[actor.NetGUID] = playerStateGUID
			ActorCMD.PlayerStateToActor[playerStateGUID] = actor.NetGUID
		}
	// RemoteViewPitch 2
	case 17:
		_ = float64(bunch.ReadUInt16()) * deserializer.ShortRotationScale // //pitch
	case 18:
		bunch.ReadObject()
	// ACharacter
	case 19:
		bunch.ReadObject()
	case 20:
		bunch.ReadName()
	case 21:
		bunch.ReadVector(100, 30)
	case 22:
		bunch.ReadRotationShort()
	case 23:
		bunch.ReadBit()
	case 24:
		bunch.ReadBit()
	case 25:
		bunch.ReadBit()
	case 26:
		bunch.ReadFloat()
	case 27:
		bunch.ReadFloat()
	case 28:
		bunch.ReadByte()
	case 29:
		bunch.ReadBit()
	case 30:
		bunch.ReadFloat()
	case 31:
		bunch.ReadInt32()
	//struct FRepRootMotionMontage RepRootMotion;
	case 32:
		bunch.ReadBit()
	case 33:
		bunch.ReadObject()
	case 34:
		bunch.ReadFloat()
	case 35:
		bunch.ReadVector(100, 30)
	case 36:
		bunch.ReadRotationShort()
	case 37:
		bunch.ReadObject()
	case 38:
		bunch.ReadName()
	case 39:
		bunch.ReadBit()
	case 40:
		bunch.ReadBit()
	// player
	case 41:
		bunch.ReadBit()          // bHasAdditiveSources
		bunch.ReadBit()          // bHasOverrideSources
		bunch.ReadVector(10, 24) // lastPreAdditiveVelocity
		bunch.ReadBit()          // bIsAdditiveVelocityApplied
		bunch.ReadUInt8()        // flags
	case 42:
		bunch.ReadVector(10, 24)
	case 43:
		bunch.ReadVector(10, 24)
	// AMutableCharacter
	case 44:
		_ = bunch.ReadUInt16() // arrayNum
		index := bunch.ReadIntPacked()
		for ; index != 0; {
			bunch.ReadUInt8()
			index = bunch.ReadIntPacked()
		}
	// ATslCharacter
	case 45:
		bunch.ReadInt(8)
	case 46:
		bunch.ReadInt32()
	case 47:
		bunch.ReadFloat()
	case 48:
		bunch.ReadObject()
	case 49:
		bunch.ReadObject()
	case 50:
		bunch.ReadByte()
	case 51:
		bunch.ReadBit()
	case 52:
		bunch.ReadBit()
	case 53:
		bunch.ReadBit()
	case 54:
		bunch.ReadBit()
	case 55:
		bunch.ReadObject() // id, team
	case 56:
		bunch.ReadFloat()
	case 57:
		bunch.ReadObject()
	case 58:
		bunch.ReadObject()
	case 59:
		bunch.ReadVector(1, 20)
	case 60:
		bunch.ReadVector(1, 20)
	case 61:
		bunch.ReadName()
	case 62:
		bunch.ReadFloat()
	case 63:
		bunch.ReadByte()
	case 64:
		bunch.ReadByte()
	case 65:
		bunch.ReadBit()
	case 66:
		bunch.ReadBit()
	case 67:
		bunch.ReadBit()
	case 68:
		bunch.ReadByte()
	case 69:
		bunch.ReadName()
	case 70:
		bunch.ReadFloat()
		bunch.ReadFloat()
		bunch.ReadFloat()
	case 71:
		bunch.ReadInt(3)
	case 72:
		bunch.ReadFloat()
	case 73:
		bunch.ReadBit()
	case 74:
		bunch.ReadBit()
	case 75:
		bunch.ReadBit()
	case 76:
		bunch.ReadBit()
	case 77:
		bunch.ReadBit()
	case 78:
		bunch.ReadBit()
	case 79:
		bunch.ReadBit()
	case 80:
		bunch.ReadBit()
	case 81:
		bunch.ReadBit()
	case 82:
		bunch.ReadBit()
	case 83:
		bunch.ReadBit()
	case 84:
		bunch.ReadBit()
	case 85:
		bunch.ReadBit()
	case 86:
		bunch.ReadBit()
	case 87:
		bunch.ReadBit()
	case 88:
		bunch.ReadBit()
	case 89:
		bunch.ReadRotationShort() //propertyRotator()
	case 90:
		bunch.ReadFixedVector(1, 16)
	case 91:
		bunch.ReadObject()
	case 92:
		bunch.ReadBit()
	case 93:
		bunch.ReadBit()
	case 94:
		health := bunch.ReadFloat()
		ActorCMD.ActorHealth[actor.NetGUID] = health
	case 95:
		bunch.ReadFloat()
	case 96:
		bunch.ReadFloat()
	case 97:
		bunch.ReadFloat()
	case 98:
		bunch.ReadFloat()
	case 99:
		bunch.ReadFloat()
	case 100:
		bunch.ReadInt(8)
	case 101:
		bunch.ReadObject()
	case 102:
		bunch.ReadBit()
	case 103:
		bunch.ReadInt(4)
	case 104:
		bunch.ReadBit()
	case 105:
		bunch.ReadBit()
	case 106:
		bunch.ReadBit()
	default:
		return false
	}
	return true
}
