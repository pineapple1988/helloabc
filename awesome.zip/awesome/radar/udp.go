package radar

import (
	"encoding/hex"
	"fmt"
	"log"
)

func parseUDPRecv(payload []byte) {
	if len(payload) > 0 {
		lastByte := payload[len(payload)-1]
		if lastByte != 0 {
			bitSize := (len(payload) * 8) - 1
			for ; lastByte&0x80 == 0; {
				lastByte *= 2
				bitSize--
			}
			reader := NewFBitReader(payload, int64(bitSize))
			if reader.GetBitsLeft() > 0 {
				ReceivedPacket(reader)
			}
		}
	}
}

const (
	MAX_PACKETID   = 16384
	MAX_CHANNELS   = 10240
	MAX_CHSEQUENCE = 4096

	CHTYPE_None    = 0 // Invalid type.
	CHTYPE_Control = 1 // Connection control.
	CHTYPE_Actor   = 2 // Actor-update channel.
	// todo: Remove and reassign number to CHTYPE_Voice (breaks net compatibility)
	CHTYPE_File  = 3 // Binary file transfer.
	CHTYPE_Voice = 4 // VoIP data channel
	CHTYPE_MAX   = 8 // Maximum.
)

type fInBunch struct {
	packetID              int32 // Note this must stay as first member variable in FInBunch for FInBunch(FInBunch, bool) to work
	chIndex               int32
	chType                int32
	chSequence            int32
	bOpen                 bool
	bClose                bool
	bDormant              bool // Close, but go dormant
	bIsReplicationPaused  bool // Replication on this channel is being paused by the server
	bReliable             bool
	bPartial              bool // Not a complete bunch
	bPartialInitial       bool // The first bunch of a partial bunch
	bPartialFinal         bool // The final bunch of a partial bunch
	bHasPackageMapExports bool // This bunch has networkGUID name/id pairs
	bHasMustBeMappedGUIDs bool // This bunch has guids that must be mapped before we can process this bunch
	reader                *fBitReader
}

func (ib *fInBunch) ToString() string {
	return fmt.Sprintf("FInBunch: \r\n") +
		fmt.Sprintf("\tChannel[%d] \r\n", ib.chIndex) +
		fmt.Sprintf("\tChSequence: %d \r\n", ib.chSequence) +
		fmt.Sprintf("\tChType: %d \r\n", ib.chType) +
		fmt.Sprintf("\tNumBits: %d \r\n", ib.reader.GetNumBits()) +
		fmt.Sprintf("\tPacketId: %d \r\n", ib.packetID) +
		fmt.Sprintf("\tbOpen: %v \r\n", ib.bOpen) +
		fmt.Sprintf("\tbClose: %t \r\n", ib.bClose) +
		fmt.Sprintf("\tbDormant: %t \r\n", ib.bDormant) +
		fmt.Sprintf("\tbIsReplicationPaused: %t \r\n", ib.bIsReplicationPaused) +
		fmt.Sprintf("\tbReliable: %t \r\n", ib.bReliable) +
		fmt.Sprintf("\tbPartial: %t//%t//%t \r\n", ib.bPartial, ib.bPartialInitial, ib.bPartialFinal) +
		fmt.Sprintf("\tbHasPackageMapExports: %t", ib.bHasPackageMapExports)
}

func ReceivedPacket(reader *fBitReader) {
	if reader.IsError() {
		log.Println("Packet too small")
		return
	}

	if reader.ReadBit() != 0 {
		// handshake
		return
	}

	// 读取packetId
	packetID := int32(reader.ReadInt(MAX_PACKETID))

	for ; !reader.AtEnd(); {
		// Parse the bunch.
		//startPos := reader.GetPosBits()
		//log.Printf("parse the bunch startPos=%d", startPos)
		isAck := reader.ReadBit()
		if reader.IsError() {
			log.Println("Bunch missing ack flag")
			return
		}

		// process the brunch
		if isAck != 0 {
			ackPacketID := reader.ReadInt(MAX_PACKETID)
			if reader.IsError() {
				log.Println("Bunch missing ack")
				return
			}
			bHasServerFrameTime := reader.ReadBit()
			log.Printf("packetID=%d ackPacketID=%d bHasServerFrameTime=%d", packetID, ackPacketID, bHasServerFrameTime)
			for {
				flag := reader.ReadByte()
				if reader.IsError() {
					log.Println("Read all ack byte error ")
					return
				}
				if flag&1 == 0 {
					break
				}
			}
		} else {
			bunch := &fInBunch{}
			incomingStartPos := reader.GetPosBits()
			bControl := reader.ReadBit() != 0
			bunch.packetID = packetID
			if bControl {
				bunch.bOpen = reader.ReadBit() != 0
				bunch.bClose = reader.ReadBit() != 0
			}
			if bunch.bClose {
				bunch.bDormant = reader.ReadBit() != 0
			}
			bunch.bIsReplicationPaused = reader.ReadBit() != 0
			bunch.bReliable = reader.ReadBit() != 0
			bunch.chIndex = int32(reader.ReadInt(MAX_CHANNELS))
			bunch.bHasPackageMapExports = reader.ReadBit() != 0
			bunch.bHasMustBeMappedGUIDs = reader.ReadBit() != 0
			bunch.bPartial = reader.ReadBit() != 0
			if bunch.bReliable {
				bunch.chSequence = int32(reader.ReadInt(MAX_CHSEQUENCE))
			} else if bunch.bPartial {
				bunch.chSequence = packetID
			} else {
				bunch.chSequence = 0
			}

			if bunch.bPartial {
				bunch.bPartialInitial = reader.ReadBit() != 0
				bunch.bPartialFinal = reader.ReadBit() != 0
			}

			if bunch.bReliable || bunch.bOpen {
				bunch.chType = int32(reader.ReadInt(CHTYPE_MAX))
			}
			// 这里本身是ue4设置的，这里直接写死了
			bunchDataBits := reader.ReadInt(0x1000)
			headerPos := reader.GetPosBits()
			if reader.IsError() {
				log.Println("Bunch header overflowed")
				return
			}

			if bunchDataBits > 0 {
				bunchData := reader.ReadBits(int64(bunchDataBits))
				if reader.IsError() {
					log.Printf("Bunch data overflowed (%d %d+%d/%d)", incomingStartPos, headerPos, bunchDataBits, reader.GetNumBits())
					return
				}
				//fmt.Println(hex.Dump(bunchData))
				if bunchData != nil {
					bunch.reader = NewFBitReader(bunchData, int64(bunchDataBits))
					log.Println("bunch -> \r\n" + bunch.ToString() + "\r\n" + hex.Dump(bunchData))
				}
			}
		}
	}
}
