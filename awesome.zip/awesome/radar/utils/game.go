package utils

type GameListener interface {
	OnGameStart()
	OnGameOver()
}

var gameListeners []GameListener

func Register(listener GameListener) {
	gameListeners = append(gameListeners, listener)
}

var gameStarted = false

func GameStart() {
	println("New Game on")
	gameStarted = true
	for _, l := range gameListeners {
		l.OnGameStart()
	}
}

func GameOver() {
	gameStarted = false
	for _, l := range gameListeners {
		l.OnGameOver()
	}
}