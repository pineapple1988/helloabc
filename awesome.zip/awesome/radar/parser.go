package radar

import (
	"awesome/radar/cmd"
	"awesome/radar/deserializer"
	"log"
)

func ProcRawPacket(payload []byte, client bool) {
	if len(payload) <= 0 {
		return
	}
	lastByte := payload[len(payload)-1]
	if lastByte == 0 {
		return
	}
	bitSize := (len(payload) * 8) - 1
	for ; lastByte&0x80 == 0; {
		lastByte *= 2
		bitSize--
	}
	bitSize-- // 去掉最后一位1 标识位
	reader := deserializer.NewBuffer(payload, bitSize)
	if reader.ReadBit() {
		log.Println("handshake")
		return
	}
	if !client {
		reader.SkipBits(32)
	}
	packetID := reader.ReadInt(deserializer.MAX_PACKETID)
	for ; reader.NotEnd(); {
		isAck := reader.ReadBit()
		if isAck {
			ackPacketID := reader.ReadInt(deserializer.MAX_PACKETID)
			if ackPacketID == -1 {
				return
			}

			bHasServerFrameTime := reader.ReadBit()
			remoteInKBytesPerSecond := reader.ReadIntPacked()
			log.Printf("packetID=%d ackPacketID=%d bHasServerFrameTime=%t, remoteInKBytesPerSecond=%d", packetID,
				ackPacketID, bHasServerFrameTime, remoteInKBytesPerSecond)
			continue
		}

		bControl := reader.ReadBit()
		var bOpen = false
		var bClose = false
		var bDormant = false
		if bControl {
			bOpen = reader.ReadBit()
			bClose = reader.ReadBit()
			if bClose {
				bDormant = reader.ReadBit()
			}
		}
		var bIsReplicationPaused = reader.ReadBit()
		var bReliable = reader.ReadBit()
		var chIndex = reader.ReadInt(deserializer.MAX_CHANNELS)
		var bHasPackageMapExports = reader.ReadBit()
		var bHasMustBeMappedGUIDs = reader.ReadBit()
		var bPartial = reader.ReadBit()
		var chSequence = 0
		if bReliable {
			chSequence = reader.ReadInt(deserializer.MAX_CHSEQUENCE)
		} else if bPartial {
			chSequence = packetID
		}
		var bPartialInitial = false
		var bPartialFinal = false
		if bPartial {
			bPartialInitial = reader.ReadBit()
			bPartialFinal = reader.ReadBit()
		}
		var chType = deserializer.CHTYPE_NONE
		if bReliable || bOpen {
			chType = reader.ReadInt(deserializer.CHTYPE_MAX)
		}
		if reader.IsError() {
			return
		}
		check(chType <= 4)

		var bunchDataBits = reader.ReadInt(deserializer.MAX_PACKET_SIZE * 8)
		var pre = reader.BitsLeft()
		if bunchDataBits > pre {
			return
		}

		channels := cmd.ChannelMgr.OutChannels
		if client {
			channels = cmd.ChannelMgr.InChannels
		}
		closedChannels := cmd.ChannelMgr.ClosedOutChannels
		if client {
			closedChannels = cmd.ChannelMgr.ClosedInChannels
		}
		_, in := channels.Get(chIndex)
		c0, _ := channels.Get(0)
		if (chIndex != 0 || chType != deserializer.CHTYPE_CONTROL) && !in {
			// Can't handle other channels until control channel exists.
			if client && c0 == nil {
				log.Printf("ReceivedPacket: Received non-control bunch before control channel was created. ChIndex: %d, ChType: %d",
					chIndex, chType)
				return
			}
		}
		// ignore control channel close if it hasn't been opened yet
		if chIndex == 0 && c0 == nil && bClose && chType == deserializer.CHTYPE_CONTROL {
			log.Println("ReceivedPacket: Received control channel close before open")
			return
		}
		ci, _ := channels.Get(chIndex)
		if !bReliable && ci == nil {
			// Unreliable bunches that open channels should be bOpen && (bClose || bPartial)
			validUnreliableOpen := bOpen && (bClose || bPartial)
			if !validUnreliableOpen {
				reader.SkipBits(bunchDataBits)
				continue
			}
		}
		log.Printf("receive packageID=%d,chIndex=%d,chSequence=%d,chType=%d,bunchDataBits=%d,bReliable=%t,bOpen=%t,bClose=%t,bPartial=%t,bPartialIntial=%t,bPartialFinal=%t",
			packetID, chIndex, chSequence, chType, bunchDataBits, bReliable, bOpen, bClose, bPartial, bPartialInitial, bPartialFinal)

		if ci == nil {
			switch chType {
			case deserializer.CHTYPE_CONTROL:
				channels.Put(chIndex, cmd.NewControlChannel(chIndex, client))
			case deserializer.CHTYPE_VOICE, deserializer.CHTYPE_FILE:
				log.Println("CHTYPE_VOICE or CHTYPE_FILE ignore")
			default:
				log.Printf("create chIndex=%d,chSequence=%d,chType=%d",
					chIndex, chSequence, chType)
				if chType == deserializer.CHTYPE_NONE {
					log.Printf("%d lost the first actor creation bunch. just create as we need it.",
						chSequence)
				}
				cmd.ChannelMgr.InChannels.Put(chIndex, cmd.NewActorChannel(chIndex, true))
				cmd.ChannelMgr.OutChannels.Put(chIndex, cmd.NewActorChannel(chIndex, false))
			}
		}

		if closedChannels.Contains(chIndex) {
			log.Printf("reuse channel %d", chIndex)
		}

		ci, _ = channels.Get(chIndex)
		if ci != nil {
			ciChType := 0
			switch ci.(type) {
			case *cmd.ControlChannel:
				ciChType = ci.(*cmd.ControlChannel).ChType
			case *cmd.ActorChannel:
				ciChType = ci.(*cmd.ActorChannel).ChType
			}
			check(chType == deserializer.CHTYPE_NONE || chType == ciChType)
			log.Printf("->Channel[%d]", chIndex)
			buf := reader.DeepCopy(bunchDataBits)
			bunch := &deserializer.Bunch{
				BunchDataBits:        bunchDataBits,
				PacketID:             packetID,
				ChIndex:              chIndex,
				ChType:               chType,
				ChSequence:           chSequence,
				Open:                 bOpen,
				Close:                bClose,
				Dormant:              bDormant,
				IsReplicationPaused:  bIsReplicationPaused,
				Reliable:             bReliable,
				Partial:              bPartial,
				PartialInitial:       bPartialInitial,
				PartialFinal:         bPartialFinal,
				HasPackageMapExports: bHasPackageMapExports,
				HasMustBeMappedGUIDs: bHasMustBeMappedGUIDs,
			}
			bunch.Buffer = buf
			switch ci.(type) {
			case *cmd.ControlChannel:
				ci.(*cmd.ControlChannel).ReceivedRawBunch(bunch, ci)
			case *cmd.ActorChannel:
				ci.(*cmd.ActorChannel).ReceivedRawBunch(bunch, ci)
			}
		} else {
			log.Println("ignore")
		}
		reader.SkipBits(bunchDataBits)
		check(reader.BitsLeft()+bunchDataBits == pre)
	}
}

func check(b bool) {
	if !b {
		log.Fatal("check error")
	}
}
