package qichacha

import (
	"awesome/tools"
	"encoding/json"
	"fmt"
	"github.com/go-http-utils/headers"
	"net/http"
	"net/url"
)

func (q *QiChacha) addBaseHeader() *http.Header {
	return &http.Header{
		headers.UserAgent:      {q.userAgent()},
		headers.Accept:         {"*/*"},
		headers.AcceptEncoding: {"gzip"},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		"_app_channel":         {"ios"},
	}
}

func (q *QiChacha) getAccessToken() *getAccessTokenResp {
	respObj := &getAccessTokenResp{}

	header := q.addBaseHeader()

	hash, ts := q.sign()

	form := &url.Values{
		"appId":      {appID},
		"deviceId":   {q.DeviceID},
		"deviceType": {"iOS"},
		"os":         {q.SystemVersion},
		"sign":       {hash},
		"timestamp":  {ts},
		"version":    {appVersion},
	}

	resp, err := tools.DoHTTPPostForm(q.c, urlGetAccessToken, nil, header, []byte(form.Encode()))
	if err != nil {
		q.logger.Errorf("getAccessToken DoHTTPPostForm 出现错误 err=%+v", err)
		return respObj
	}

	q.logger.Info("getAccessToken >>>>>>>>> \r\n" + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		q.logger.Errorf("getAccessToken json.Unmarshal 出现错误 err=%+v", err)
	}

	return respObj
}

func (q *QiChacha) refreshToken() *refreshTokenResp {
	respObj := &refreshTokenResp{}

	header := q.addBaseHeader()

	hash, ts := q.sign()

	form := &url.Values{
		"appId":        {appID},
		"refreshToken": {q.RefreshToken},
		"sign":         {hash},
		"timestamp":    {ts},
	}

	resp, err := tools.DoHTTPPostForm(q.c, urlRefreshToken, nil, header, []byte(form.Encode()))
	if err != nil {
		q.logger.Errorf("refreshToken DoHTTPPostForm 出现错误 err=%+v", err)
		return respObj
	}

	q.logger.Info("refreshToken >>>>>>>>> \r\n" + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		q.logger.Errorf("refreshToken json.Unmarshal 出现错误 err=%+v", err)
	}

	return respObj
}

func (q *QiChacha) login() *loginResp {
	respObj := &loginResp{}

	header := q.addBaseHeader()
	header.Set(headers.Authorization, fmt.Sprintf("%s %s", q.TokenType, q.AccessToken))

	hash, ts := q.sign()
	form := &url.Values{
		"account":           {q.Account},
		"accountType":       {"1"},
		"deviceToken":       {q.DeviceToken},
		"identifyCode":      {""},
		"internationalCode": {"+86"},
		"loginType":         {"2"},
		"password":          {q.getPassword()},
		"sign":              {hash},
		"timestamp":         {ts},
	}

	resp, err := tools.DoHTTPPostForm(q.c, urlLogin, nil, header, []byte(form.Encode()))
	if err != nil {
		q.logger.Errorf("login DoHTTPPostForm 出现错误 err=%+v", err)
		return respObj
	}

	q.logger.Info("login >>>>>>>>> \r\n" + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		q.logger.Errorf("login json.Unmarshal 出现错误 err=%+v", err)
	}

	return respObj
}
