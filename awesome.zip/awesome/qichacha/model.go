package qichacha

type getAccessTokenResp struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
	Result  struct {
		AccessToken  string `json:"access_token"`
		TokenType    string `json:"token_type"`
		ExpiresIn    int    `json:"expires_in"`
		RefreshToken string `json:"refresh_token"`
	} `json:"result"`
}

type refreshTokenResp struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
	Result  struct {
		AccessToken string `json:"access_token"`
		TokenType   string `json:"token_type"`
		ExpiresIn   int    `json:"expires_in"`
	} `json:"result"`
}

type loginResp struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
	Result  struct {
		UserInfo struct {
			UID            string `json:"uid"`
			GUID           string `json:"guid"`
			ParentGUID     string `json:"parent_guid"`
			Name           string `json:"name"`
			Nickname       string `json:"nickname"`
			Prefix         string `json:"_prefix"`
			Phone          string `json:"phone"`
			Email          string `json:"email"`
			Groupid        string `json:"groupid"`
			AccessGroupID  string `json:"access_group_id"`
			Qqopenid       string `json:"qqopenid"`
			Qqunionid      string `json:"qqunionid"`
			Sinaid         string `json:"sinaid"`
			Weixinid       string `json:"weixinid"`
			Unionid        string `json:"unionid"`
			Hwopenid       string `json:"hwopenid"`
			UserType       string `json:"user_type"`
			Sex            string `json:"sex"`
			Faceimg        string `json:"faceimg"`
			IsComment      string `json:"is_comment"`
			DeviceToken    string `json:"device_token"`
			InviteCode     string `json:"invite_code"`
			MyInviteCode   string `json:"my_invite_code"`
			LastLoginTime  string `json:"last_login_time"`
			LastLoginIP    string `json:"last_login_ip"`
			RegistTime     string `json:"regist_time"`
			RegistIP       string `json:"regist_ip"`
			LastRemindTime string `json:"last_remind_time"`
			IsActive       string `json:"is_active"`
			Points         string `json:"points"`
			WorkMode       string `json:"work_mode"`
			ClientType     string `json:"client_type"`
			Status         string `json:"status"`
			MsgSwitch      string `json:"msg_switch"`
			IsVIP          bool   `json:"isVIP"`
			IsSVIP         bool   `json:"isSVIP"`
			VipStartDate   string `json:"vipStartDate"`
			VipEndDate     string `json:"vipEndDate"`
			BalanceID      string `json:"balanceId"`
			Balance        string `json:"balance"`
			OrderCount     int    `json:"orderCount"`
			Info           struct {
				SnsStatus        int    `json:"sns_status"`
				IsVest           int    `json:"is_vest"`
				MsgSwitch        string `json:"msg_switch"`
				SnsIsInblacklist string `json:"sns_is_inblacklist"`
				CompanyName      string `json:"company_name"`
				CompanyKeyno     string `json:"company_keyno"`
				Status           int    `json:"status"`
				RealName         string `json:"real_name"`
				AuthStatus       string `json:"authStatus"`
			} `json:"info"`
			FunctionConfig []interface{} `json:"functionConfig"`
			CacheMail      string        `json:"cacheMail"`
			IsShowEntrance bool          `json:"is_showEntrance"`
			IsTeamUser     bool          `json:"isTeamUser"`
		} `json:"userInfo"`
		Token struct {
			AccessToken  string `json:"access_token"`
			TokenType    string `json:"token_type"`
			ExpiresIn    int    `json:"expires_in"`
			RefreshToken string `json:"refresh_token"`
		} `json:"token"`
	} `json:"result"`
}
