package qichacha

const (
	urlGetAccessToken = "https://appv4.qichacha.net/app/v1/admin/getAccessToken"
	urlRefreshToken   = "https://appv4.qichacha.net/app/v1/admin/refreshToken"
	urlLogin          = "https://appv4.qichacha.net/app/v1/admin/login"
)

const (
	appID      = "isoh89bvsoivbiuqw0hcbowipbc9032h"
	appVersion = "13.5.0"
	signSalt   = "fiu92nudv9wqwas0a9pvn0asn093qwtu0gasnfash"
)
