package qichacha

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"crypto/md5"
	"crypto/tls"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"time"
)

// QiChacha 企查查
type QiChacha struct {
	Account  string `json:"account"`  // 账号，手机号
	LoginPwd string `json:"loginPwd"` // 登陆密码

	AccessToken   string `json:"accessToken"`
	TokenType     string `json:"tokenType"`
	DeviceID      string `json:"deviceID"`
	RefreshToken  string `json:"refreshToken"`
	ExpiresIn     uint32 `json:"expiresIn"`
	TokenTime     uint32 `json:"tokenTime"`
	DeviceToken   string `json:"deviceToken"` // Apple 远程推送设备token
	SystemVersion string `json:"systemVersion"`

	c      *http.Client
	logger *log2.MyLog
}

func New(account, loginPwd string) *QiChacha {
	b := &QiChacha{
		Account:  account,
		LoginPwd: loginPwd,
	}
	b.DeviceID = fmt.Sprintf("%x%08x", md5.Sum([]byte(tools.NewUUID())), tools.RandInt31())
	b.DeviceToken = tools.RandHexString(64)
	b.SystemVersion = tools.NewSysVersion()
	return b
}

// NewHTTPClient 创建新的client
func (q *QiChacha) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	//u, _ := url.Parse("http://192.168.137.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

func (q *QiChacha) Save() {
	path := "./qichacha/bin/" + q.Account + ".json"
	tools.SaveJSON2File(path, q)
}

func (q *QiChacha) userAgent() string {
	return fmt.Sprintf("QiChaCha/%s (iPhone; iOS %s; Scale/2.00)", appVersion, q.SystemVersion)
}

func (q *QiChacha) sign() (string, string) {
	ts := fmt.Sprintf("%d000", tools.Timestamp())
	ts = "1595856294000"
	hash := md5.Sum([]byte(fmt.Sprintf("%s%s%s", q.DeviceID, ts, signSalt)))
	return fmt.Sprintf("%x", hash), ts
}

func (q *QiChacha) getPassword() string {
	hash := md5.Sum([]byte(fmt.Sprintf("DHX_password:%s", q.LoginPwd)))
	return fmt.Sprintf("%x", md5.Sum([]byte(fmt.Sprintf("DHX_password:%x", hash))))
}

// Login 登录操作
func (q *QiChacha) Login() base.LoginResultCode {
	// 创建一个新的
	q.c = q.NewHTTPClient()
	// 日志
	q.logger = &log2.MyLog{Prefix: fmt.Sprintf("[QICHACHA][%s]", q.Account)}

	// 还没有token,需要获取token，就是注册的意思
	if q.AccessToken == "" {
		tokenResp := q.getAccessToken()
		if tokenResp.Status != 201 || tokenResp.Result.AccessToken == "" {
			q.logger.Errorf("设备注册失败，没有获取到token")
			return base.LoginResultFail
		}
		q.AccessToken = tokenResp.Result.AccessToken
		q.TokenType = tokenResp.Result.TokenType
		q.ExpiresIn = uint32(tokenResp.Result.ExpiresIn)
		q.RefreshToken = tokenResp.Result.RefreshToken
		q.TokenTime = tools.Timestamp()
	}

	// 需要更新token
	if q.TokenTime+q.ExpiresIn < tools.Timestamp() {
		refreshResp := q.refreshToken()
		if refreshResp.Status != 201 || refreshResp.Result.AccessToken == "" {
			q.logger.Errorf("设备注册失败，没有获取到token")
			return base.LoginResultFail
		}
		q.AccessToken = refreshResp.Result.AccessToken
		q.TokenType = refreshResp.Result.TokenType
		q.ExpiresIn = uint32(refreshResp.Result.ExpiresIn)
		q.TokenTime = tools.Timestamp()
	}

	loginResp := q.login()
	if loginResp.Status != 201 {
		q.logger.Errorf("登陆失败")
		return base.LoginResultFail
	}
	q.AccessToken = loginResp.Result.Token.AccessToken
	q.TokenType = loginResp.Result.Token.TokenType
	q.ExpiresIn = uint32(loginResp.Result.Token.ExpiresIn)
	q.RefreshToken = loginResp.Result.Token.RefreshToken
	q.TokenTime = tools.Timestamp()

	return base.LoginResultSuccess
}
