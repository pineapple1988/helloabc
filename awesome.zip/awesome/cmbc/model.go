package cmbc

///////////////////////////////////////////
////////////////////请求///////////////////
///////////////////////////////////////////

type baseReq struct {
	TransID string `json:"TransId"`
}

type widget struct {
	WidgetID   string `json:"widgetId"`
	WidgetData struct {
		ClientVersion string `json:"clientVersion"`
		CustID        string `json:"custId"`
	} `json:"widgetData"`
}
type widgetListReq struct {
	baseReq
	OsType        string `json:"osType"`
	ClientVersion string `json:"clientVersion"`
	AppExt        string `json:"appExt"`
	WidgetData    struct {
		Request struct {
			Body struct {
				WidgetList []widget `json:"widgetList"`
			} `json:"body"`
		} `json:"request"`
	} `json:"widgetData"`
}

type needImageVerifyCodeReq struct {
	baseReq
	Value string `json:"Value"`
	UUID  string `json:"IDFV"`
	Type  string `json:"type"`
}

type clientLoginNewOpReq struct {
	baseReq
	Platform         string `json:"Platform"`
	DeviceType       string `json:"DeviceType"`
	DeviceModel      string `json:"DeviceModel"`
	DeviceDigest     string `json:"DeviceDigest"`
	Lac              string `json:"lac"`
	IDFA             string `json:"idfa"`
	ImageCoder       string `json:"ImageCoder"`
	Telephone        string `json:"telephone"`
	YQKEY            string `json:"YQKEY"`
	SSID             string `json:"ssid"`
	ApplePaySupport  string `json:"ApplePaySupport"`
	Latitude         string `json:"latitude"`
	NetType          string `json:"netType"`
	VerifyCode       string `json:"VerifyCode"`
	Cid              string `json:"cid"`
	UUID             string `json:"UUID"`
	ClientVersion    string `json:"clientVersion"`
	Longitude        string `json:"longitude"`
	DeviceVersion    string `json:"DeviceVersion"`
	DeviceSysVersion string `json:"deviceSysVersion"`
	AppId            string `json:"appId"`
	VersionType      string `json:"versionType"`
	OSType           string `json:"ostype"`
	Isp              string `json:"isp"`
	CmbcOtpCheck     string `json:"CmbcOtpCheck"`
	AppExt           string `json:"appExt"`
	IsBreakOut       string `json:"isBreakOut"`
	BiometryType     string `json:"biometryType"`
	Password         string `json:"password"`
	DeviceInfo       string `json:"DeviceInfo"`
	ClientId1        string `json:"clientId1"`
}

type clientParam struct {
	AppKeyVersion    string `json:"appkey_version"`
	OSType           string `json:"os_type"`
	InitDevInfo      string `json:"initDevInfo"`
	InitRequestToken string `json:"initRequestToken"`
}

type initLoginSafetyFaceReq struct {
	baseReq
	IsSignTrustDevice string `json:"isSignTrustDevice"`
	DeviceId          string `json:"deviceId"`
	ClientParam       string `json:"clientParam"` // clientParam struct
}

type checkSignPwdLoginMainReq struct {
	baseReq
	DeviceId          string `json:"deviceId"`
	IsSignTrustDevice string `json:"isSignTrustDevice"`
	VerifyData        struct {
		VerifyToken     string `json:"verifyToken"`
		SecToolSelected string `json:"secToolSelected"`
		FACEVerifyData  struct {
			EncryptStr struct {
				CryptType  string `json:"cryptType"`
				CryptKey   string `json:"cryptKey"`
				ResultMsg  string `json:"resultMsg"`
				PhotoSeqNo string `json:"photoSeqNo"`
				Version    string `json:"version"`
				ReturnCode string `json:"returnCode"`
				CamType    string `json:"camType"`
			} `json:"encryptStr"`
			ImgBase64 string `json:"imgBase64"`
		} `json:"FACEVerifyData"`
		SMSCode string `json:"SMSCode"`
	} `json:"verifyData"`
	ClientParam string `json:"clientParam"` // clientParam struct
}

type cardListReq struct {
	baseReq
	CardType string `json:"cardType"`
}

type billReq struct {
	baseReq
	QueryBeginDate string `json:"queryBeginDate"`
	QueryEndDate   string `json:"queryEndDate"`
	AccountType    string `json:"accountType"`
	SonAccount     string `json:"sonAccount"`
	OrderFlag      string `json:"orderFlag"`
	ReStartId      int    `json:"reStartId"`
	DebCreInd      string `json:"debCreInd"`
	OpenDate       string `json:"openDate"`
	CardType       string `json:"cardType"`
	AccountSeq     string `json:"accountSeq"`
	MamFlag        string `json:"mamFlag"`
	Account        string `json:"account"`
	PageSize       int    `json:"pageSize"`
}

type userIsSignPCPReq struct {
	baseReq
	UrlDate     string `json:"urldate"`
	CallbackKey string `json:"callbackKey"`
	AccFlag     string `json:"accFlag"`
}

type payeeUNPSCrtOrderOpReq struct {
	baseReq
	UrlDate      string `json:"urldate"`
	CallbackKey  string `json:"callbackKey"`
	TransAccount string `json:"transAccount"`
	TransAmt     string `json:"transAmt"`
}

type qryOrderInfoOpReq struct {
	baseReq
	SkFlag       string `json:"skFlag"`
	UrlDate      string `json:"urldate"`
	CallbackKey  string `json:"callbackKey"`
	TransAccount string `json:"transAccount"`
}

type transferIntruteReq struct {
	baseReq
	TransferType string `json:"transferType"`
}

type getAcctListReq struct {
	baseReq
	Type       string `json:"type"`
	IsAuthAcct string `json:"isAuthAcct"`
}

type queryBankInfoByCardReq struct {
	baseReq
	PayeeAccountName string `json:"payeeaccountName"`
	PayeeAccountNo   string `json:"payeeaccountNo"`
}

type loadAccountNoBinBankintelligenceFourReq struct {
	baseReq
	PayeeAccountNo   string `json:"payeeaccountNo"`
	PayeeBankName    string `json:"payeeBankName"`
	PayeeAccountName string `json:"payeeaccountName"`
	PayeePathBank    string `json:"payeePathbank"`
	TransferMode     string `json:"transferMode"`
	CityCode         string `json:"citycode"`
	SmallBankType    string `json:"smallBankType"`
	AmountValue      string `json:"amountValue"`
	PayerAccountNo   string `json:"payeraccountNo"`
}

type checkTransferLimitFourReq struct {
	baseReq
	TranAmount string `json:"tranAmount"`
}

type transferPreNewReq struct {
	baseReq
	CdtrBranchId       string `json:"CdtrbranchId"`
	CdtrAcctName       string `json:"CdtrAcctName"`
	CdtrAcctNo         string `json:"CdtrAcctNo"`
	TransUsing         string `json:"transusing"`
	TransferMode       string `json:"transferMode"`
	TransAccount       string `json:"transAccount"`
	RandomNum          string `json:"randomNum"`
	SttlmAmt           string `json:"SttlmAmt"`
	BankDistinction    string `json:"bankDistinction"`
	CustLimitCheckFlag string `json:"custLimitCheckFlag"`
}

type transferMainReq struct {
	baseReq
	IsChoosePrivateProblem string `json:"isChoosePrivateProblem"`
	TransToken             string `json:"transToken"`
	VerifyData             struct {
		VerifyToken     string `json:"verifyToken"`
		PWDEncrypt      string `json:"PWDEncrypt"`
		SecToolSelected string `json:"secToolSelected"`
		SMSCode         string `json:"SMSCode"`
	} `json:"verifyData"`
}

type getAdBannerReq struct {
	baseReq
	TRAN_SCENE string `json:"TRAN_SCENE"`
}

///////////////////////////////////////////
////////////////////返回///////////////////
///////////////////////////////////////////

type baseResp struct {
	Msg          string `json:"MSG"`
	Status       string `json:"STATUS"`
	ResponseCode string `json:"ResponseCode"`
	ResponseMsg  string `json:"ResponseMsg"`
	CallbackKey  string `json:"callbackKey"`
}

type needImageVerifyResp struct {
	baseResp
	FailCount            int    `json:"failCount"`
	ReturnCode           string `json:"returnCode"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	NeedVerify           string `json:"needVerify"`
}

type randomResp struct {
	baseResp
	RandomCode string `json:"randomCode"`
}

type clientLoginNewOpResp struct {
	YQKEYJSON string `json:"YQKEYJSON"` // clientLoginNewOpRespYQKEY struct
}

type clientLoginNewOpRespYQKEY struct {
	baseResp
	YQKEY                     string `json:"YQKEY"`
	SendMessageStatus         string `json:"SendMessageStatus"`
	IsShowSignTrustDevice     string `json:"isShowSignTrustDevice"`
	SceneId                   string `json:"sceneId"`
	ShowGestureLoginDialogSts string `json:"showGestureLoginDialogSts"`
	SYQKEY                    string `json:"SYQKEY"`
	ACCOUNT                   string `json:"ACCOUNT"`
	Password                  string `json:"password"`
	CustBackLog               string `json:"custBackLog"`
	StartTime                 string `json:"startTime"`
	STARTDATE                 string `json:"STARTDATE"`
	UserId                    string `json:"userId"`
	HasBlueToothUB            string `json:"hasBlueToothUB"`
	Feature                   string `json:"feature"`
	REMAINDAYS                string `json:"REMAINDAYS"`
	DseErrorPage              string `json:"dse_errorPage"`
	BPPMICROCUSTFLAG          string `json:"BPP_MICROCUSTFLAG"`
	LoginCount                int    `json:"loginCount"`
	DseReplyPage              string `json:"dse_replyPage"`
	DeviceModel               string `json:"DeviceModel"`
	DsePageId                 string `json:"dse_pageId"`
	SignedMicroFlag           string `json:"signedMicroFlag"`
	LognTime                  string `json:"lognTime"`
	TransScene                string `json:"transScene"`
	DseSessionId              string `json:"dse_sessionId"`
	TokenList                 []struct {
		Token string `json:"token"`
		Name  string `json:"name"`
	} `json:"tokenList"`
	CustName               string `json:"custName"`
	CERTSTATE              string `json:"CERTSTATE"`
	BttIsOperation         bool   `json:"btt_isOperation"`
	InitPassword           string `json:"InitPassword"`
	Port                   string `json:"port"`
	Sex                    string `json:"sex"`
	DseOperationName       string `json:"dse_operationName"`
	CERTISSUER             string `json:"CERTISSUER"`
	DseErrorFlag           bool   `json:"dse_ErrorFlag"`
	DseParentContextName   string `json:"dse_parentContextName"`
	FaceSetInfo            string `json:"faceSetInfo"`
	TransId                string `json:"TransId"`
	OVERENDDATE            string `json:"OVERENDDATE"`
	DseErrorMessages       string `json:"dse_errorMessages"`
	REMINDUPDATEFLAG       string `json:"REMINDUPDATEFLAG"`
	KEYID                  string `json:"KEYID"`
	CustType               string `json:"custType"`
	ENDDATE                string `json:"ENDDATE"`
	BlueToothVendor        string `json:"blueToothVendor"`
	FingerPrintSetInfo     string `json:"fingerPrintSetInfo"`
	CustId                 string `json:"custId"`
	IdCard                 string `json:"idCard"`
	IsInvalidHandsPwd      string `json:"isInvalidHandsPwd"`
	CERTCAISSUER           string `json:"CERTCAISSUER"`
	TRANSASSOCIATESEQUENCE string `json:"TRANS_ASSOCIATE_SEQUENCE"`
	RealNameType           string `json:"realnameType"`
	DseApplicationId       string `json:"dse_applicationId"`
	DseProcessorId         string `json:"dse_processorId"`
	Ip                     string `json:"ip"`
	DeviceBindStatus       string `json:"DeviceBindStatus"`
	CustInfo               string `json:"custInfo"`
	SERIALNO               string `json:"SERIALNO"`
	//MicroCifList           []string `json:"microCifList"`
	UniqueIDTNO        string `json:"uniqueIDTNO"`
	OrganNo            string `json:"organNo"`
	EbankExitEventName string `json:"ebank_exitEventName"`
	Sequence           string `json:"sequence"`
	IsOpenHandsPwd     string `json:"isOpenHandsPwd"`
	CERTDN             string `json:"CERTDN"`
	Telephone          string `json:"telephone"`
	DseProcessorState  string `json:"dse_processorState"`
}

type initLoginSafetyFaceResp struct {
	baseResp
	SecureVerify struct {
		TransAmount      string `json:"transAmount"`
		TransType        string `json:"transType"`
		TransDetail      string `json:"transDetail"`
		TransAccountType string `json:"transAccountType"`
		TransAccount     string `json:"transAccount"`
		VerifyToken      string `json:"verifyToken"`
		SecTools         string `json:"secTools"`
	} `json:"secureVerify"`
}

type encryptResp struct {
	ClientEncryptData string `json:"CLIENT_ENCRYPT_DATA"`
}

type applyFaceResp struct {
	baseResp
	FACEData string `json:"FACEData"`
	IDNo     string `json:"IDNo"`
	SN       string `json:"SN"`
}

type applySmsResp struct {
	baseResp
	Phone string `json:"phone"`
}

type applyPwdResp struct {
	baseResp
	PWDData              string `json:"PWDData"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
}

type checkSignPwdLoginMainResp struct {
	baseResp
	Retry                string `json:"retry"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	UkeyAuthToken        string `json:"ukeyAuthToken"`
	SuccessJumpType      string `json:"successJumpType"`
	SuccessJumpTo        string `json:"successJumpTo"`
	LOGINJSON            string `json:"LOGINJSON"`
}

type detail struct {
	CurrencyTypeCode string `json:"currencyTypeCode"`
	PeriodFlag       string `json:"periodFlag"`
	PrdName          string `json:"prdName"`
	CurrencyType     string `json:"currencyType"`
	AcctAmount       string `json:"acctAmount"`
}
type transDetail struct {
	SerialNo  string `json:"serialNo"` // 0001
	CashFlag  string `json:"cashFlag"`
	CurrName  string `json:"currName"`
	AcctSonNo string `json:"acctSonNo"`
	CurrCode  string `json:"currCode"`
	OpenDate  string `json:"openDate"` // 20190604
}
type bankAcc struct {
	AccountName         string        `json:"accountName"`     // 李三
	AccountTypeName     string        `json:"accountTypeName"` // 借记卡
	AccountKind         string        `json:"accountKind"`
	AccountType         string        `json:"accountType"` // 1
	Account             string        `json:"account"`     // 6226220639628279
	AcctFaceId          string        `json:"acctFaceId"`
	AliasName           string        `json:"aliasName"`
	AvailableBalance    string        `json:"availableBalance"` // 194.680000000
	OpenOrgName         string        `json:"openOrgName"`
	OpenOrg             string        `json:"openOrg"`
	JOINTTYPE           string        `json:"JOINT_TYPE"`
	DetailList          []detail      `json:"detailList"`
	TransDetailNeedList []transDetail `json:"transDetailNeedList"`
}

type accListResp struct {
	baseResp
	IsEncryptForRespData bool      `json:"isEncryptForRespData"`
	AcctList             []bankAcc `json:"acctList"`
}

type bill struct {
	Summary               string `json:"summary"`               // 备注
	TxnNum                string `json:"txnNum"`                // 账单号        31000201911300095606708
	Balance               string `json:"balance"`               // 余额，这个有时不太准确
	TransAmount           string `json:"transAmount"`           // 转账金额 	 0.01
	TransTime             string `json:"transTime"`             // 转账时间 	 20191130231158
	ReciprocalAccount     string `json:"reciprocalAccount"`     // 转账时收钱账号 6228480329628098371
	OpenBankName          string `json:"openBankName"`          // 转账时收钱银行 中国农业银行
	ReciprocalAccountName string `json:"reciprocalAccountName"` // 转账时收钱姓名 李四
	IncomeExpensesType    string `json:"incomeExpensesType"`    // 判断进还是出的 "0"是出
	TheMonthDetailIsNull  string `json:"theMonthDetailIsNull"`
}

type billListResp struct {
	baseResp
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	Id                   string `json:"id"`
	EndFlag              string `json:"endFlag"`
	ReStartId            int    `json:"reStartId"`
	ReStartBeginDate     string `json:"reStartBeginDate"`
	ReStartEndDate       string `json:"reStartEndDate"`
	List                 []bill `json:"list"`
}

type userIsSignPCPResp struct {
	baseResp
	SmallPayVerify       string `json:"smallPayVerify"`
	PlusButonFuncValue   string `json:"plusButonFuncValue"`
	SignAcctCount        int    `json:"signAcctCount"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	DetailsFuncValue     string `json:"detailsFuncValue"`
	SignVerify           string `json:"signVerify"`
	SmallpayAmt          string `json:"smallpayAmt"`
	LIMITMONTH           int    `json:"LIMIT_MONTH"`
	PageSwitch           string `json:"pageSwitch"`
	SmallPayStatus       string `json:"smallPayStatus"`
	SmallPayDayAmt       string `json:"smallpayDayAmt"`
	IsEleAccount         string `json:"isEleAccount"`
	LIMITDAY             string `json:"LIMIT_DAY"`
	SignCardNo           string `json:"signCardNo"`
	LIMITONCE            string `json:"LIMIT_ONCE"`
	Telephone            string `json:"telephone"`
	IsSignPCP            bool   `json:"isSignPCP"`
	IsSupportEleAccount  string `json:"isSupportEleAccount"`
	// signAccList
	// list
}

type payeeUNPSCrtOrderOpResp struct {
	baseResp
	IsEncryptForRespData  bool   `json:"isEncryptForRespData"`
	PromptlyCorpPayOutSeq string `json:"promptlyCorpPay_outSeq"`
	TransAccount          string `json:"transAccount"`
}

type qryOrderInfoOpResp struct {
	baseResp
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	TranDate             string `json:"tranDate"`
	DraweePartyName      string `json:"draweePartyName"`
	CheckVerify          string `json:"checkVerify"`
	VerifyWay            string `json:"verifyWay"`
	MENUID               string `json:"MENU_ID"`
	SalOrderId           string `json:"salOrderId"`
	PayeeAccName         string `json:"payeeAccName"`
	VoucherNo            string `json:"voucherNo"`
	TransStatus          string `json:"transStatus"`
	DraweeAccNo          string `json:"draweeAccNo"`
	OrderNo              string `json:"orderNo"`
	TranAmount           string `json:"tranAmount"`
	OrderAmount          string `json:"orderAmount"`
	ResponseInfo         string `json:"ResponseInfo"`
	MENUIDjf             string `json:"MENU_ID_jf"`
	IsFirstTrade         string `json:"isFirstTrade"`
	MessageInfo          string `json:"messageInfo"`
}

type keepSessionResp struct {
	IsLogin string `json:"isLogin"`
}

type transferIntruteResp struct {
	baseResp
	TransferStatus       string `json:"transferStatus"`
	WishTransferStatus   string `json:"wishTransferStatus"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	TransToken           string `json:"transToken"`
}

type getAcctResp struct {
	baseResp
	AccList []struct {
		ACCT_NAME       string `json:"ACCT_NAME"`
		ACCT_NO         string `json:"ACCT_NO"`
		ACCT_SORT       string `json:"ACCT_SORT"`
		ACCT_OPEN_DT    string `json:"ACCT_OPEN_DT"`
		ACCT_ALIAS      string `json:"ACCT_ALIAS"`
		ACCT_OPEN_SBRCH string `json:"ACCT_OPEN_SBRCH"`
		ACCT_OPEN_BRCH  string `json:"ACCT_OPEN_BRCH"`
		CardType        string `json:"cardType"`
		ACCT_TYPE       string `json:"ACCT_TYPE"`
		ACCT_VIP        string `json:"ACCT_VIP"`
	} `json:"accList"`
	IsEncryptForRespData bool `json:"isEncryptForRespData"`
	AvailList            []struct {
		MainAccount string `json:"mainAccount"`
		List        []struct {
			AvailBalance string `json:"availBalance"`
			CashFlag     string `json:"cashFlag"`
			CurrCode     string `json:"currCode"`
		} `json:"list"`
	} `json:"availList"`
	CustName string `json:"custName"`
	// visaList
	// AuthAcctList
}

type queryBankInfoByCardResp struct {
	baseResp
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	ASSO_ID              string `json:"ASSO_ID"`
	ASSO_BANK_CODE       string `json:"ASSO_BANK_CODE"`
	ASSO_ACCT            string `json:"ASSO_ACCT"`
	ASSO_ALIAS           string `json:"ASSO_ALIAS"`
	ASSO_TYPE            string `json:"ASSO_TYPE"`
	ASSO_NAME            string `json:"ASSO_NAME"`
	ASSO_IMG             string `json:"ASSO_IMG"`
	ASSO_TEL             string `json:"ASSO_TEL"`
	ASSO_ACCT_TYPE       string `json:"ASSO_ACCT_TYPE"`
	ASSO_EXPR_FLAG       string `json:"ASSO_EXPR_FLAG"`
	ASSO_BANK_NAME       string `json:"ASSO_BANK_NAME"`
	BankIcon             string `json:"bankIcon"`
	BankDistinction      string `json:"bankDistinction"`
	BANK_NAME            string `json:"BANK_NAME"`
	TransferAvailLimit   string `json:"transferAvailLimit"`
	SAFEFLAG             string `json:"SAFEFLAG"`
}

type loadAccountNoBinBankintelligenceFourResp struct {
	baseResp
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	IntelligencePath     string `json:"intelligencePath"`
}

type transferPreNewResp struct {
	baseResp
	SkipPrivateProblem   string `json:"skipPrivateProblem"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	SecureVerify         struct {
		TransAmount      string `json:"transAmount"`
		TransType        string `json:"transType"`
		VerifyToken      string `json:"verifyToken"`
		TransDetail      string `json:"transDetail"`
		TransAccountType string `json:"transAccountType"`
		TransAccount     string `json:"transAccount"`
		SecTools         string `json:"secTools"`
	} `json:"secureVerify"`
}

type transferMainResp struct {
	baseResp
	SuccessJumpType      string `json:"successJumpType"`
	NeedSkip             string `json:"needSkip"`
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	TRPATH               string `json:"TRPATH"`
	IsVillageBankFlag    bool   `json:"isVillageBankFlag"`
	BigFlagNext          string `json:"BigFlagNext"`
	ResponseCode         string `json:"ResponseCode"`
	Retry                string `json:"retry"`
	SuccessJumpTo        string `json:"successJumpTo"`
}

type speBookDetailQryOpFourResp struct {
	baseResp
	TransferStatus       string `json:"transferStatus"` // "0" -> 交易已发出等待确认 "1" -> 表示成功，其他是失败 "2" -> 账号、户名不符 bocomm errcode:[IE0321]
	IsEncryptForRespData bool   `json:"isEncryptForRespData"`
	Busistat             string `json:"busistat"`
	StatusCN             string `json:"statusCN"`
	TR_RETU_MESG         string `json:"TR_RETU_MESG"` // 这个是失败信息
}
