package cmbc

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"bytes"
	"crypto/sha1"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"strconv"
	"strings"
	"time"

	"github.com/shopspring/decimal"
)

// Bank 民生银行
type Bank struct {
	Account             string       `json:"account"`  // 账号，手机号
	EnLoginPwd          string       `json:"loginPwd"` // 加密的登陆密码
	EnPayPwd            string       `json:"payPwd"`   // 加密的支付密码
	IDFV                string       `json:"IDFV"`
	IDFA                string       `json:"IDFA"`
	APNSToken           string       `json:"APNSToken"`
	UniqueIDTNO         string       `json:"uniqueIDTNO"`
	LastLoginTime       string       `json:"lastLoginTime"`
	Feature             string       `json:"feature"`
	CustType            string       `json:"custType"`
	HardwareInfo        HardwareInfo `json:"hardwareInfo"`
	client              *http.Client
	jar                 *cookiejar.Jar
	loginAesKey         string
	loginAfterKey       []byte
	userID              string
	verifyToken         string
	sn                  string
	photoSeqNo          string
	enImage             []byte
	transferToken       string
	transferVerifyToken string
	logger              *log2.MyLog
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	WIFIName      string `json:"wifiName"`      // wifi名字
	WIFIMac       string `json:"wifiMac"`       // wifiMac地址
	Model         string `json:"model"`         // 设备类型
	ScreenSize    string `json:"screenSize"`    // 分辨率
	Carrier       string `json:"carrier"`       // 运营商
	CarrierCode   string `json:"carrierCode"`   // 运营商code
	DeviceName    string `json:"deviceName"`    // 设备名称  iPhone7
	OwnerName     string `json:"ownerName"`     // 设备用户名 jj的 iPhone
	En0Ipv4       string `json:"en0Ipv4"`       // wifi本地地址
	Brightness    string `json:"-"`             // 屏幕亮度
}

// New 民生银行创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:      account,
		EnLoginPwd:   loginPwd, // 如果要加密需要更改
		EnPayPwd:     payPwd,   // 如果要加密需要更改
		HardwareInfo: HardwareInfo{},
	}
	b.IDFV = strings.ToUpper(tools.NewUUID())
	b.IDFA = strings.ToUpper(tools.NewUUID())
	b.CustType = "100"
	b.APNSToken = fmt.Sprintf("%x", tools.RandBytes(16))
	b.HardwareInfo.En0Ipv4 = tools.NewIPV4()
	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.WIFIMac = tools.NewMacAddress()
	b.HardwareInfo.WIFIName = tools.NewWifiName(b.HardwareInfo.WIFIMac)
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.ScreenSize = tools.ScreenPx(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.CarrierCode = "460" + tools.CarrierCode(b.HardwareInfo.Carrier)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()

	b.Save()
	return b
}

// Save 需要服务端来实现，用来存储账号信息
func (b *Bank) Save() {
	path := "./cmbc/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (b *Bank) NewHTTPClient() (*http.Client, *cookiejar.Jar) {
	jarN, _ := cookiejar.New(nil)

	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     jarN,
	}, jarN
}

// LoginPwd 需要服务端来实现，对密码进行解密操作
func (b *Bank) LoginPwd() string {
	return b.EnLoginPwd
}

// PayPwd 需要服务端来实现，对密码进行解密操作
func (b *Bank) PayPwd() string {
	return b.EnPayPwd
}

// Login 登录操作
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.client, b.jar = b.NewHTTPClient()
	// 日志
	b.logger = &log2.MyLog{Prefix: fmt.Sprintf("[CMBC][%s]", b.Account)}
	// 各种数据
	b.HardwareInfo.Brightness = fmt.Sprintf("%.2f", rand.Float32())
	// 开始登陆流程
	//if b.UniqueIDTNO != "" {
	//	w := make([]widget, 2)
	//	w[0].WidgetId = "PayeeWidget"
	//	w[0].WidgetData.ClientVersion = cfBundleShortVersion
	//	w[0].WidgetData.CustId = b.UniqueIDTNO
	//	w[1].WidgetId = "TransferNewWidget"
	//	w[1].WidgetData.ClientVersion = cfBundleShortVersion
	//	w[1].WidgetData.CustId = b.UniqueIDTNO
	//	b.widgetList(w)
	//}

	b.serahHotSpot()
	needVerify := b.needImageVerifyCode()
	if needVerify == nil {
		b.logger.Error("Login needImageVerifyCode resp=nil")
		return base.LoginResultFail
	}
	if v, err := strconv.ParseBool(needVerify.NeedVerify); err != nil || v {
		// 需要去获取图片验证码或者是返回错误了，不能继续往下面走了
		b.logger.Errorf("Login needImageVerifyCode resp=%+v", needVerify)
		return base.LoginResultFail
	}

	serverRandom := b.cmbcRandom()
	if serverRandom == "" {
		b.logger.Error("Login cmbcRandom 获取随机数出现错误")
		return base.LoginResultFail
	}

	loginResp := b.login(serverRandom)
	if loginResp.ResponseCode != respCodeSuccess || loginResp.Status != respStatusSuccess {
		b.logger.Errorf("Login login 登陆失败 resp=%+v", loginResp)
		if loginResp != nil && loginResp.ResponseCode == "4000" {
			return base.LoginResultFailWrongPwd
		}
		return base.LoginResultFail
	}

	if loginResp.SendMessageStatus == "0" || loginResp.SendMessageStatus == "" {
		// 首次登陆需要验证
		// 设为常用设备
		// 		认证方式:人脸识别，蓝牙u宝，扫码认证(柜台给一次性二维码)
		//		短信验证日累积限额5w,人脸认证日累计限额20w
		// 设为可信设备
		// 		认证方式:蓝牙u宝，扫码认证
		// 		短信验证日累积限额10w,人脸认证日累计限额50w
		// 人脸认证动作:眨眼，张嘴，点头，抬头，左摇，右摇
		userID := b.sendMes()
		if userID == "" {
			b.logger.Error("首次登陆|没有获取到userId")
			return base.LoginResultFail
		}
		b.userID = userID
		b.queryTrustText()
		initLoginResp := b.initLoginSafetyFace(userID)
		if initLoginResp.ResponseCode != respCodeSuccess || initLoginResp.Status != respStatusSuccess || !strings.Contains(initLoginResp.SecureVerify.SecTools, "FACE+SMS") {
			b.logger.Errorf("Login initLoginSafetyFace 返回失败 resp=%+v", initLoginResp)
			return base.LoginResultFail
		}
		b.verifyToken = initLoginResp.SecureVerify.VerifyToken
		// 有刷脸加短信验证码认证,请求刷脸
		faceResp := b.applyForFACE()
		if faceResp.ResponseCode != respCodeSuccess || faceResp.Status != respStatusSuccess {
			b.logger.Errorf("Login applyForFACE 返回失败 resp=%+v", faceResp)
			return base.LoginResultFail
		}
		b.sn = faceResp.SN

		return base.LoginResultFailNeedImage
	}

	if loginResp.SYQKEY != "" && loginResp.LognTime != "" {
		b.loginSuccess(loginResp)
		return base.LoginResultSuccess
	}

	return base.LoginResultFail
}

// LoginVerifyImage 登陆验证刷脸
// 第一张图片 image_env     头肩正面照 不要有多余动作  图片像素大小 480*640(宽*高)
// 第二张图片 image_action  眨眼                   图片像素大小 296*296(宽*高)
// 第三张图片 image_action  张嘴                   图片像素大小 296*296(宽*高)
// 第四张图片 image_best    正面 不要有多余动作       图片像素大小 296*296(宽*高)
// 图片大小也可不固定大小，但是大小最好不要超过80kb
func (b *Bank) LoginVerifyImage(imageEnv, imageAction1, imageAction2, imageBest []byte) base.LoginResultCode {
	// 准备刷脸数据
	b.photoSeqNo = b.genPhotoSeqNo()

	imageBuffer := bytes.NewBuffer([]byte{})
	imageBuffer.Write([]byte{0x9f, 0xb8, 0x32, 0xde, 0x00, 0x00, 0x00, 0x01})

	// 所有图片要求必须是jpg格式
	// 第一张图片 image_env 图片像素大小 480*640(宽*高) 头肩正面照 不要有多余动作
	//imageEnv, _ := ioutil.ReadFile("./bin/img_env.jpg")
	imageBuffer.Write([]byte{0x01})
	_ = binary.Write(imageBuffer, binary.BigEndian, int32(len(imageEnv)))
	imageBuffer.Write(imageEnv)
	// 第二张图片 image_action_blink 图片像素大小 296*296(宽*高) 眨眼
	//blink, _ := ioutil.ReadFile("./bin/img_action_blink.jpg")
	imageBuffer.Write([]byte{0x02})
	_ = binary.Write(imageBuffer, binary.BigEndian, int32(len(imageAction1)))
	imageBuffer.Write(imageAction1)
	// 第三张图片 img_action_mouse 图片像素大小 296*296(宽*高) 张嘴
	//mouse, _ := ioutil.ReadFile("./bin/img_action_mouse.jpg")
	imageBuffer.Write([]byte{0x03})
	_ = binary.Write(imageBuffer, binary.BigEndian, int32(len(imageAction2)))
	imageBuffer.Write(imageAction2)
	// 第四张图片 img_best 图片像素大小 296*296(宽*高) 正面 不要有多余动作
	//imageBest, _ := ioutil.ReadFile("./bin/img_best.jpg")
	imageBuffer.Write([]byte{0x04})
	_ = binary.Write(imageBuffer, binary.BigEndian, int32(len(imageBest)))
	imageBuffer.Write(imageBest)
	// 算出图片加密key
	keyBuffer := make([]byte, len(b.photoSeqNo)+0x53)
	keyBuffer0 := fmt.Sprintf("%s|%s|", b.photoSeqNo, b.sn)
	copy(keyBuffer, keyBuffer0)
	copy(keyBuffer[len(keyBuffer0):], imageSalt)
	key := sha1.Sum(keyBuffer)
	//对图片进行加密
	b.enImage, _ = tools.AESECBEncrypt(imageBuffer.Bytes(), key[:0x10])

	smsResp := b.applyForSMS()
	if smsResp == nil || smsResp.ResponseCode != respCodeSuccess || smsResp.Status != respStatusSuccess {
		b.logger.Errorf("LoginVerifyImage applyForSMS 返回失败 resp=%+v", smsResp)
		return base.LoginResultFail
	}
	// 发送短信成功了，需要去获取短信
	return base.LoginResultFailNeedSms
}

// LoginVerifySMS 登陆验证短信
func (b *Bank) LoginVerifySMS(code string) base.LoginResultCode {
	b.logger.Info("获取到短信 -> " + code)
	b.logger.Info("loginAesKey ->" + b.loginAesKey)

	checkResp := b.checkSignPwdLoginMain(b.userID, b.verifyToken, b.sn, b.photoSeqNo, base64.StdEncoding.EncodeToString(b.enImage), code)

	if checkResp == nil || checkResp.ResponseCode != respCodeSuccess || checkResp.Status != respStatusSuccess || checkResp.LOGINJSON == "" {
		b.logger.Error("LoginVerifySMS checkSignPwdLoginMain 返回失败")
		if checkResp != nil {
			if checkResp.ResponseCode == "SMSErr" {
				return base.LoginResultFailWrongSms
			} else if strings.Contains(checkResp.ResponseCode, "FACEErr") {
				return base.LoginResultFailWrongFace
			}
		}
		return base.LoginResultFail
	}
	loginResp := &clientLoginNewOpRespYQKEY{}
	// 需要去解析返回的数据
	dData, err := b.decryptRespHex(checkResp.LOGINJSON, []byte(b.loginAesKey))
	if err != nil {
		b.logger.Errorf("LoginVerifySMS decryptRespHex 返回失败 err=%+v", err)
		return base.LoginResultFail
	}

	if err := json.Unmarshal(dData, loginResp); err != nil {
		b.logger.Errorf("LoginVerifySMS json.Unmarshal 返回失败 err=%+v, data=\r\n%s\r\n", err, hex.Dump(dData))
		return base.LoginResultFail
	}
	b.loginSuccess(loginResp)
	return base.LoginResultSuccess
}

// CardList 查询当前卡列表
func (b *Bank) CardList() *accListResp {
	b.queryTransitionControl()
	b.cmbcGetCustContainsAcctType()
	return b.queryCustAcctByCardTypeForListNew()
}

// BillList 查询账单
func (b *Bank) BillList(index int, beginData, endData string, cardAccount, cardType, serialNO, openDate string) *billListResp {
	return b.queryCustAcctTransDetailByAccountForListNew(index, beginData, endData, cardAccount, cardType, serialNO, openDate)
	//b.queryCustAcctTransDetailByAccountForListNew(1, "20191101", "20191209",
	//	"6226220639628279", "1", "0001", "20190604")
	//b.queryCustAcctTransDetailByAccountForListNew(21, "20191101", "20191209",
	//	"6226220639628279", "1", "0001", "20190604")
}

// KeepSession 维持链接 1分钟一次
func (b *Bank) KeepSession() bool {
	res := b.keepSession()
	if res != nil {
		isLogin, _ := strconv.ParseBool(res.IsLogin)
		return isLogin
	}
	return false
}

// Transfer 转账
func (b *Bank) Transfer(srcCardNo, destCardNo, destName, remark string, amount decimal.Decimal) base.TransferResultCode {
	b.queryTransferControl()

	intrute := b.transferIntrute()
	if intrute == nil || intrute.TransToken == "" {
		b.logger.Error(">>>>>>>>>>>没有获取到TransferToken")
		return base.TransferResultFail
	}
	b.transferToken = intrute.TransToken

	if !b.KeepSession() {
		return base.TransferResultFailNotLogin
	}

	// 获取账号信息，可以拿到余额等信息
	b.getAcctList()

	time.Sleep(time.Duration(rand.Int31n(5000)+1000) * time.Millisecond)

	bankInfo := b.queryBankInfoByCard(destName, destCardNo)
	if bankInfo == nil || bankInfo.BANK_NAME == "" || bankInfo.BankDistinction == "" {
		b.logger.Error(">>>>>>>>>>>没有获取到对方银行卡信息")
		return base.TransferResultFail
	}

	b.loadAccountNoBinBankintelligenceFour(amount.StringFixed(2), srcCardNo, destCardNo, destName, bankInfo.BANK_NAME, bankInfo.BankDistinction)
	b.checkTransferLimitFour(amount.StringFixed(2))
	transferPre := b.transferPreNew(amount.StringFixed(2), srcCardNo, destName, destCardNo, bankInfo.BankDistinction, remark)
	if transferPre == nil || transferPre.SecureVerify.VerifyToken == "" || !strings.Contains(transferPre.SecureVerify.SecTools, "SMS+PWD") {
		b.logger.Error(">>>>>>>>>>>没有获取到TransferVerifyToken或者验证工具没有SMS+PWD")
		return base.TransferResultFail
	}
	b.transferVerifyToken = transferPre.SecureVerify.VerifyToken

	smsResp := b.applyForSMS002()
	if smsResp == nil || smsResp.ResponseCode != respCodeSuccess || smsResp.Status != respStatusSuccess {
		b.logger.Error(">>>>>>>>>>>发送短信验证码失败")
		return base.TransferResultFail
	}
	// 发送短信成功了，需要去获取短信
	return base.TransferResultFailNeedSms
}

// TransferVerifySMS 转账验证短信
func (b *Bank) TransferVerifySMS(code string) base.TransferResultCode {
	b.logger.Info(">>>>>>>>>>>获取到smsCode " + code)
	pwdResp := b.applyForPWD002()
	if pwdResp == nil || pwdResp.PWDData == "" {
		b.logger.Error(">>>>>>>>>>>没有获取到加密密码随机数")
		return base.TransferResultFail
	}

	// 随机等待一个时间是输入密码的时间
	time.Sleep(time.Duration(rand.Int31n(2000)+500) * time.Millisecond)

	mainResp := b.transferMain(b.transferToken, code, b.transferVerifyToken, pwdResp.PWDData)
	if mainResp == nil || mainResp.ResponseCode != respCodeSuccess || mainResp.Status != respStatusSuccess || mainResp.SuccessJumpTo == "" {
		b.logger.Error(">>>>>>>>>>>transferMain 返回失败")
		if mainResp != nil {
			switch mainResp.ResponseCode {
			case "PWDErr":
				return base.TransferResultFailWrongPwd
			case "SMSErr":
				return base.TransferResultFailWrongSms
			default:
				return base.TransferResultFail
			}
		}

		return base.TransferResultFail // 提交转账业务出现错误
	}

	// 等待一段时间去查询转账结果
	time.Sleep(time.Duration(rand.Int31n(2000)+1500) * time.Millisecond)

	resultResp := b.speBookDetailQryOpFour()
	if resultResp == nil {
		b.logger.Error(">>>>>>>>>>>speBookDetailQryOpFour 返回失败")
		return base.TransferResultFail
	}

	var res base.TransferResultCode
	switch resultResp.TransferStatus {
	case "1":
		res = base.TransferResultSuccess
	case "2":
		res = base.TransferResultFailWrongAccount
	default:
		res = base.TransferResultUnknown
	}

	b.getTransRecorde()
	b.getAdBanner()

	return res
}

//// CreateQRCode 生成二维码，如果需要设置金额 amount eg 500.00
//func (b *Bank) CreateQRCode(acct, amount string) string {
//	// 判断用户是否已经签约民生付扫码
//	isSign := b.getUserIsSignPCP()
//	if isSign == nil {
//		b.logger.Error("getUserIsSignPCP 出现错误")
//		return ""
//	}
//
//	if !isSign.IsSignPCP {
//		b.logger.Error(">>>>>>>>>>>账户未签约民生扫码付")
//		return ""
//	}
//
//	orderResp := b.payeeUNPSCrtOrderOp(acct, amount)
//	if orderResp == nil {
//		b.logger.Error(">>>>>>>>>>>payeeUNPSCrtOrderOp 出现错误")
//		return ""
//	}
//
//	return orderResp.PromptlyCorpPayOutSeq
//}
//
//// QueryQRCodeScan 轮训查询二维码是否被扫描 5 秒一次
//func (b *Bank) QueryQRCodeScan(acct string) *qryOrderInfoOpResp {
//	return b.qryOrderInfoOp(acct)
//}
