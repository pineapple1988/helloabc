package cmbc

import (
	"awesome/tools"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/go-http-utils/headers"
	"net/http"
	"net/url"
)

func (b *Bank) userAgent() string {
	return fmt.Sprintf("CMBCPersonBank/%s (iPhone; iOS %s; Scale/2.00)", cfBundleShortVersion, b.HardwareInfo.SystemVersion)
}
func (b *Bank) addBaseQuery(values *url.Values) *url.Values {
	values.Set("appExt", "1")
	values.Set("mobileType", "iPhone")
	values.Set("funcMenuId", "")
	values.Set("clientVersion", cfBundleShortVersion)
	values.Set("ostype", "iphone")
	values.Set("deviceSysVersion", "ios"+b.HardwareInfo.SystemVersion)
	values.Set("devNo", b.HardwareInfo.Model)
	values.Set("custType", b.CustType)
	values.Set("appId", "1")
	values.Set("versionType", "1")
	if len(b.Feature) > 0 {
		values.Set("feature", b.Feature)
	}
	values.Set("cityCode", "1101") // 默认1101（北京）
	values.Set("bd61_lastLoginTime", b.LastLoginTime)
	values.Set("signedMicroFlag", "0")
	values.Set("latitude", defaultLat) // 默认地理位置是北京故宫
	values.Set("longitude", defaultLong)
	return values
}

func (b *Bank) addBaseHeader(header *http.Header) *http.Header {
	header.Set(headers.Accept, "*/*")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	return header
}

// http get
func (b *Bank) doHTTPGet(u string, query *url.Values, header *http.Header) ([]byte, error) {
	return tools.DoHTTPGet(b.client, u, query, header)
}

// http post
func (b *Bank) doHTTPost(u string, query *url.Values, header *http.Header, body []byte) ([]byte, error) {
	return tools.DoHTTPPost(b.client, u, query, header, body)
}

// cmbc的封装
func (b *Bank) doCMBCHTTPPost005(u string, query *url.Values, header *http.Header, aesKey []byte, body []byte) ([]byte, error) {
	// RSA 加密AES Key
	body1, _ := tools.RSAEncrypt(aesKey, mb8002PubKey)
	// AES CBC 加密数据
	body = tools.AESCBCEncrypt(body, aesKey, cmbcAesIV)
	// 拼接body
	reqBody := "005" + fmt.Sprintf("%X", body1) + fmt.Sprintf("%X", body)
	return tools.DoHTTPPost(b.client, u, query, header, []byte(reqBody))
}

func (b *Bank) doCMBCHTTPPost006(u string, query *url.Values, header *http.Header, aesKey []byte, body []byte) ([]byte, error) {
	// AES CBC 加密数据
	body = tools.AESCBCEncrypt(body, aesKey, cmbcAesIV)
	// 拼接body
	reqBody := "006" + fmt.Sprintf("%X", body)
	return tools.DoHTTPPost(b.client, u, query, header, []byte(reqBody))
}

func (b *Bank) doCMBCHTTPPost002(u string, query *url.Values, header *http.Header, aesKey []byte, body []byte) ([]byte, error) {
	// AES CBC 加密数据
	body = tools.AESCBCEncrypt(body, aesKey, cmbcAesIV)
	// 拼接body
	reqBody := "002" + fmt.Sprintf("%X", body)
	return tools.DoHTTPPost(b.client, u, query, header, []byte(reqBody))
}

//
//  ======================下面开始是业务==================
//

//func (acc *BankCMBC) widgetList(w []widget) {
//	post := acc.doCMBCHTTPPost006
//	key := acc.loginAfterKey
//	if len(key) <= 0 {
//		key = []byte(acc.genAesKey())
//		post = acc.doCMBCHTTPPost002
//	}
//
//	req := &widgetListReq{
//		baseReq:       baseReq{TransId: "cmbc.WidgetList"},
//		OsType:        "iphone",
//		ClientVersion: cfBundleShortVersion,
//		AppExt:        "1",
//	}
//	req.WidgetData.Request.Body.WidgetList = w
//
//	resp := post(urlTransservlet, acc.addBaseQuery(&url.Values{}), acc.addBaseHeader(&http.Header{
//		headers.ContentType: []string{"application/json"},
//	}), key, req)
//
//	fmt.Println(hex.Dump(resp))
//
//	respObj := &encryptResp{}
//	_ = json.Unmarshal(resp, respObj)
//
//	if len(respObj.ClientEncryptData) > 0 {
//		// 需要解密
//		dData := acc.decryptRespHex(respObj.ClientEncryptData, key)
//		widgetData, _ := base64.StdEncoding.DecodeString(string(dData))
//		b.logger.Info("widgetList resp >>>>>>>>")
//		b.logger.InfoJson(string(widgetData))
//	}
//}

func (b *Bank) serahHotSpot() {
	resp, err := b.doHTTPGet(urlSerahHotSpot, b.addBaseQuery(&url.Values{}), b.addBaseHeader(&http.Header{}))
	if err != nil {
		b.logger.Errorf("serahHotSpot err=%+v", err)
		return
	}
	b.logger.InfoJSON(">>>>>>>>serahHotSpot<<<<<<<<<<\r\n", string(resp))
}

// 检测要不要图片验证码 todo...还没测试到需要图片验证码的
func (b *Bank) needImageVerifyCode() *needImageVerifyResp {
	respObj := &needImageVerifyResp{}

	req, _ := json.Marshal(&needImageVerifyCodeReq{
		baseReq: baseReq{TransID: "needImageVerifyCode"},
		Value:   b.Account,
		UUID:    b.IDFV,
		Type:    "phoneNo",
	})

	resp, err := b.doHTTPost(urlTransservlet, b.addBaseQuery(&url.Values{}), b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), req)
	if err != nil {
		b.logger.Errorf("needImageVerifyCode doHTTPost err=%+v", err)
		return respObj
	}

	b.logger.InfoJSON(">>>>>>>>needImageVerifyCode<<<<<<<<<<\r\n", string(resp))

	_ = json.Unmarshal(resp, respObj)
	return respObj
}

// 获取加密密码用随机数
func (b *Bank) cmbcRandom() string {
	resp, err := b.doHTTPGet(urlCmbcRondom, b.addBaseQuery(&url.Values{}), b.addBaseHeader(&http.Header{}))
	if err != nil {
		b.logger.Errorf("cmbcRandom err=%+v", err)
		return ""
	}
	b.logger.InfoJSON(">>>>>>>>cmbcRandom<<<<<<<<<<\r\n", string(resp))
	respObj := &randomResp{}
	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("cmbcRandom json.Unmarshal err=%+v", err)
		return ""
	}

	return respObj.RandomCode
}

// 登陆
func (b *Bank) login(serverRandom string) *clientLoginNewOpRespYQKEY {
	respObj := &clientLoginNewOpRespYQKEY{}

	b.loginAesKey = b.genAesKey()
	ePassword := b.enPassword(b.LoginPwd(), serverRandom)

	req, _ := json.Marshal(&clientLoginNewOpReq{
		baseReq:          baseReq{TransID: "cmbc.ClientLoginNewOp"},
		Platform:         "iPhone",
		DeviceType:       "01",
		DeviceModel:      b.HardwareInfo.Model,
		DeviceDigest:     b.getDeviceDigest(),
		Lac:              "",
		IDFA:             b.IDFA,
		ImageCoder:       "code",
		Telephone:        b.Account,
		YQKEY:            b.loginAesKey,
		SSID:             "",
		ApplePaySupport:  "1",
		Latitude:         defaultLat,
		NetType:          "wifi",
		VerifyCode:       b.IDFV,
		Cid:              "",
		UUID:             b.IDFV,
		ClientVersion:    cfBundleShortVersion,
		Longitude:        defaultLong,
		DeviceVersion:    b.HardwareInfo.SystemVersion,
		DeviceSysVersion: "ios" + b.HardwareInfo.SystemVersion,
		AppId:            "1",
		VersionType:      "1",
		OSType:           "iphone",
		Isp:              b.HardwareInfo.Carrier,
		CmbcOtpCheck:     "0",
		AppExt:           "1",
		IsBreakOut:       "0",
		BiometryType:     "1",
		Password:         ePassword,
		DeviceInfo:       fmt.Sprintf("%s|%s|iOS%s", b.IDFV, "iPhone", b.HardwareInfo.SystemVersion),
		ClientId1:        b.APNSToken,
	})

	resp, err := b.doCMBCHTTPPost005(urlLogin, b.addBaseQuery(&url.Values{}), b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), []byte(b.loginAesKey), req)
	if err != nil {
		b.logger.Errorf("login doCMBCHTTPPost005 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>login1<<<<<<<<<<\r\n %s", string(resp))
	respObj2 := &clientLoginNewOpResp{}
	if err := json.Unmarshal(resp, respObj2); err != nil {
		b.logger.Errorf("login json.Unmarshal1 resp=\r\n%s \r\nerror=%+v", hex.Dump(resp), err)
		return respObj
	}
	if len(respObj2.YQKEYJSON) > 0 {
		yqkeyJSON, err := b.decryptRespHex(respObj2.YQKEYJSON, []byte(b.loginAesKey))
		if err != nil {
			b.logger.Errorf("login decryptRespHex resp=\r\n%s \r\nerr=%+v", hex.Dump(resp), err)
			return respObj
		}
		b.logger.InfoJSON(">>>>>>>>login2<<<<<<<<<<\r\n", string(yqkeyJSON))
		err = json.Unmarshal(yqkeyJSON, respObj)
		if err != nil {
			b.logger.Errorf("login json.Unmarshal2 resp=\r\n%s \r\nerror=%+v", hex.Dump(yqkeyJSON), err)
		}
	}
	return respObj
}

// 获取到userId
func (b *Bank) sendMes() string {
	header := b.addBaseHeader(&http.Header{})
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	resp, err := b.doHTTPGet(urlSendmes, b.addBaseQuery(&url.Values{}), header)
	if err != nil {
		b.logger.Errorf("sendMes 获取userId出错 err=%+v", err)
		return ""
	}
	if resp != nil {
		return b.extractUserID(string(resp))
	}

	return ""
}

func (b *Bank) queryTrustText() {
	_, _ = b.doHTTPost(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/json;charset=UTF-8"},
	}), []byte(`{"TransId":"cmbc.queryTrustText"}`))
	//b.logger.InfoJson(">>>>>>>>queryTrustText<<<<<<<<<<\r\n", string(resp))
}

// 初始化验证
func (b *Bank) initLoginSafetyFace(userID string) *initLoginSafetyFaceResp {
	respObj := &initLoginSafetyFaceResp{}

	param, _ := json.Marshal(&clientParam{
		AppKeyVersion:    "01",
		OSType:           "ios",
		InitDevInfo:      b.initDevInfo(),
		InitRequestToken: b.initRequestToken(userID),
	})

	req, _ := json.Marshal(&initLoginSafetyFaceReq{
		baseReq:           baseReq{TransID: "cmbc.initLoginSafetyFace"},
		IsSignTrustDevice: "0",
		DeviceId:          b.getDeviceID(),
		ClientParam:       string(param),
	})

	resp, err := b.doCMBCHTTPPost005(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), []byte(b.loginAesKey), req)
	if err != nil {
		b.logger.Errorf("initLoginSafetyFace doCMBCHTTPPost005 err=%+v", err)
		return respObj
	}

	b.logger.InfoJSON(">>>>>>>>initLoginSafetyFace<<<<<<<<<<\r\n", string(resp))
	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("initLoginSafetyFace json.Unmarshal err=%+v", err)
		return respObj
	}

	return respObj
}

// 开始刷脸
func (b *Bank) applyForFACE() *applyFaceResp {
	respObj := &applyFaceResp{}

	req, _ := json.Marshal(&baseReq{
		TransID: "ApplyForFACE",
	})

	resp, err := b.doCMBCHTTPPost005(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), []byte(b.loginAesKey), req)
	if err != nil {
		b.logger.Errorf("applyForFACE doCMBCHTTPPost005 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, []byte(b.loginAesKey), respObj)
	if err != nil {
		b.logger.Errorf("applyForFACE decryptResp1 err=%+v", err)
	}
	b.logger.Infof(">>>>>>>>applyForFACE<<<<<<<<<<\r\n %+v", respObj)
	return respObj
}

// 发送短信005
func (b *Bank) applyForSMS() *applySmsResp {
	respObj := &applySmsResp{}

	req, _ := json.Marshal(&baseReq{
		TransID: "ApplyForSMS",
	})

	resp, err := b.doCMBCHTTPPost005(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), []byte(b.loginAesKey), req)
	if err != nil {
		b.logger.Errorf("applyForSMS doCMBCHTTPPost005 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, []byte(b.loginAesKey), respObj)
	if err != nil {
		b.logger.Errorf("applyForSMS decryptResp1 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>applyForSMS<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 发送短信002
func (b *Bank) applyForSMS002() *applySmsResp {
	respObj := &applySmsResp{}

	req, _ := json.Marshal(&baseReq{
		TransID: "ApplyForSMS",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("applyForSMS002 doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, b.loginAfterKey, respObj)
	if err != nil {
		b.logger.Errorf("applyForSMS002 decryptResp1 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>applyForSMS002<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 获取转账密码加密的随机数
func (b *Bank) applyForPWD002() *applyPwdResp {
	respObj := &applyPwdResp{}

	req, _ := json.Marshal(&baseReq{TransID: "ApplyForPWD"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("applyForPWD002 doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, b.loginAfterKey, respObj)
	if err != nil {
		b.logger.Errorf("applyForPWD002 decryptResp1 err=%+v", err)
	}
	b.logger.Infof(">>>>>>>>applyForPWD002<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 提交验证信息
func (b *Bank) checkSignPwdLoginMain(userID string, verifyToken, sn, photoSeqNo, image, sms string) *checkSignPwdLoginMainResp {
	respObj := &checkSignPwdLoginMainResp{}

	param, _ := json.Marshal(&clientParam{
		AppKeyVersion:    "01",
		OSType:           "ios",
		InitDevInfo:      b.initDevInfo(),
		InitRequestToken: b.initRequestToken(userID),
	})
	check := &checkSignPwdLoginMainReq{
		baseReq:           baseReq{TransID: "CommonSafe.CheckSignPwdLoginMain"},
		DeviceId:          b.getDeviceID(),
		IsSignTrustDevice: "0",
		ClientParam:       string(param),
	}
	check.VerifyData.VerifyToken = verifyToken
	check.VerifyData.SecToolSelected = "FACE+SMS"
	check.VerifyData.FACEVerifyData.EncryptStr.CryptType = "3"
	check.VerifyData.FACEVerifyData.EncryptStr.CryptKey = sn
	check.VerifyData.FACEVerifyData.EncryptStr.ResultMsg = "成功"
	check.VerifyData.FACEVerifyData.EncryptStr.PhotoSeqNo = photoSeqNo
	check.VerifyData.FACEVerifyData.EncryptStr.Version = "v2.4.3"
	check.VerifyData.FACEVerifyData.EncryptStr.ReturnCode = "0"
	check.VerifyData.FACEVerifyData.EncryptStr.CamType = ""
	check.VerifyData.FACEVerifyData.ImgBase64 = image
	check.VerifyData.SMSCode = sms

	req, _ := json.Marshal(check)

	// b.logger.Infof(">>>>>>>>checkSignPwdLoginMain req<<<<<<<<<<\r\n %s", string(req))

	resp, err := b.doCMBCHTTPPost005(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), []byte(b.loginAesKey), req)
	if err != nil {
		b.logger.Errorf("checkSignPwdLoginMain doCMBCHTTPPost005 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, []byte(b.loginAesKey), respObj)
	if err != nil {
		b.logger.Errorf("checkSignPwdLoginMain decryptResp1 err=%+v", err)
	}
	b.logger.Infof(">>>>>>>>checkSignPwdLoginMain<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

func (b *Bank) searchCustPropertyInfo() {
	req, _ := json.Marshal(&baseReq{TransID: "cmbc.searchCustPropertyInfo"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("searchCustPropertyInfo doCMBCHTTPPost002 err=%+v", err)
		return
	}

	propertyInfo, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("searchCustPropertyInfo decryptResp2NoUnmarshal err=%+v", err)
		return
	}
	b.logger.InfoJSON(">>>>>>>>searchCustPropertyInfo<<<<<<<<<<\r\n", propertyInfo)
}

func (b *Bank) searchMonthlyBillNew() {
	req, _ := json.Marshal(&baseReq{TransID: "Cmbc.searchMonthlyBillNew"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("searchMonthlyBillNew doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dData, err := b.decryptResp1NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("searchMonthlyBillNew decryptResp1 err=%+v", err)
		return
	}
	b.logger.InfoJSON(">>>>>>>>searchMonthlyBillNew<<<<<<<<<<\r\n", string(dData))
}

//func (acc *BankCMBC) queryAccountNumAndLevel() {
//	resp := acc.doCMBCHTTPPost002(urlTransservlet, acc.addBaseQuery(&url.Values{}),
//		acc.addBaseHeader(&http.Header{
//			headers.ContentType: []string{"application/x-www-form-urlencoded"},
//		}), acc.loginAfterKey, `{"TransId":"queryAccountNumAndLevel"}`)
//	respObj := &encryptResp{}
//	_ = json.Unmarshal(resp, respObj)
//
//	if len(respObj.ClientEncryptData) > 0 {
//		// 需要解密
//		dData := acc.decryptRespHex(respObj.ClientEncryptData, acc.loginAfterKey)
//		propertyInfo, _ := base64.StdEncoding.DecodeString(string(dData))
//
//		b.logger.Info("queryAccountNumAndLevel resp >>>>>>>>")
//		b.logger.InfoJson(string(propertyInfo))
//	}
//}
//
//
func (b *Bank) queryTransitionControl() {
	req, _ := json.Marshal(&baseReq{TransID: "queryTransitionControl"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("queryTransitionControl doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dStr, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("queryTransitionControl decryptResp2NoUnmarshal err=%+v", err)
	}
	b.logger.InfoJSON(">>>>>>>>queryTransitionControl<<<<<<<<<<\r\n", dStr)
}

func (b *Bank) cmbcGetCustContainsAcctType() {
	req, _ := json.Marshal(&baseReq{TransID: "cmbcGetCustContainsAcctType"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("cmbcGetCustContainsAcctType doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dStr, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("cmbcGetCustContainsAcctType decryptResp2NoUnmarshal err=%+v", err)
	}

	b.logger.InfoJSON(">>>>>>>>cmbcGetCustContainsAcctType<<<<<<<<<<\r\n", dStr)
}

// 获取卡号列表
func (b *Bank) queryCustAcctByCardTypeForListNew() *accListResp {
	respObj := &accListResp{}

	req, _ := json.Marshal(&cardListReq{
		baseReq:  baseReq{TransID: "queryCustAcctByCardTypeForListNew"},
		CardType: "10",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("queryCustAcctByCardTypeForListNew doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("queryCustAcctByCardTypeForListNew decryptResp2 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>queryCustAcctByCardTypeForListNew<<<<<<<<<<\r\n %+v", respObj)
	return respObj
}

// 获取账单
// beginData endData 开始和结束时间 一般写一个月 比如 (20191001,20191031)
// 如果查当月 比如今天是20191129，那就是(20191101,20191129)
// reStartID 为拉单开始的index 从1开始 往下拉单为上次返回的账单数量加上之前数量
// 比如开始为1，拉单返回20个账单，下次开始就为21 reStartId 在拉单中也有返回
// account 为卡号
// accountType serialNo openDate 在获取卡号列表的时候都是会返回的
func (b *Bank) queryCustAcctTransDetailByAccountForListNew(reStartID int, beginData, endData, account, accountType, serialNo, openDate string) *billListResp {
	respObj := &billListResp{}

	req, _ := json.Marshal(&billReq{
		baseReq:        baseReq{TransID: "queryCustAcctTransDetailByAccountForListNew"},
		QueryBeginDate: beginData,
		QueryEndDate:   endData,
		AccountType:    accountType,
		SonAccount:     serialNo,
		OrderFlag:      "1",
		ReStartId:      reStartID,
		DebCreInd:      "0",
		OpenDate:       openDate,
		CardType:       accountType,
		AccountSeq:     serialNo,
		MamFlag:        "0",
		Account:        account,
		PageSize:       20,
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("queryCustAcctTransDetailByAccountForListNew doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("queryCustAcctTransDetailByAccountForListNew decryptResp2 err=%+v", err)
	}
	b.logger.Infof(">>>>>>>>queryCustAcctTransDetailByAccountForListNew<<<<<<<<<<\r\n %+v", respObj)
	return respObj
}

// 判断用户是否已经签约民生付扫码
func (b *Bank) getUserIsSignPCP() *userIsSignPCPResp {
	respObj := &userIsSignPCPResp{}

	req, _ := json.Marshal(&userIsSignPCPReq{
		baseReq:     baseReq{TransID: "Cmbc.getUserIsSignPCP"},
		UrlDate:     timeFmt(),
		CallbackKey: generateRandom(20),
		AccFlag:     "payee",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"text/plain;charset=UTF-8"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("getUserIsSignPCP doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("getUserIsSignPCP decryptResp2 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>getUserIsSignPCP<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 创建二维码
func (b *Bank) payeeUNPSCrtOrderOp(transAcc, transAmt string) *payeeUNPSCrtOrderOpResp {
	respObj := &payeeUNPSCrtOrderOpResp{}

	req, _ := json.Marshal(&payeeUNPSCrtOrderOpReq{
		baseReq:      baseReq{TransID: "cmbc.CTCPayeeUNPSCrtOrderOp"},
		TransAccount: transAcc,
		TransAmt:     transAmt,
		UrlDate:      timeFmt(),
		CallbackKey:  generateRandom(20),
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"text/plain;charset=UTF-8"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("payeeUNPSCrtOrderOp doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("payeeUNPSCrtOrderOp decryptResp2 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>payeeUNPSCrtOrderOp<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 轮训二维码是否被扫描
func (b *Bank) qryOrderInfoOp(transAcc string) *qryOrderInfoOpResp {
	respObj := &qryOrderInfoOpResp{}

	req, _ := json.Marshal(&qryOrderInfoOpReq{
		baseReq:      baseReq{TransID: "cmbc.UNPSQryOrderInfoOp"},
		SkFlag:       "1",
		TransAccount: transAcc,
		UrlDate:      timeFmt(),
		CallbackKey:  generateRandom(20),
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"text/plain;charset=UTF-8"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("qryOrderInfoOp doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("qryOrderInfoOp decryptResp2 err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>qryOrderInfoOp<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// keepSession 1分钟一次
func (b *Bank) keepSession() *keepSessionResp {
	respObj := &keepSessionResp{}

	resp, err := b.doHTTPGet(urlKeepSession, b.addBaseQuery(&url.Values{}), b.addBaseHeader(&http.Header{}))
	if err != nil {
		b.logger.Errorf("keepSession err=%+v", err)
		return respObj
	}
	b.logger.InfoJSON(">>>>>>>>keepSession<<<<<<<<<<\r\n", string(resp))
	_ = json.Unmarshal(resp, respObj)
	return respObj
}

/////////////////////////////////////////////////////////////////////////
//////////////////////////////////转账业务////////////////////////////////
/////////////////////////////////////////////////////////////////////////

func (b *Bank) queryTransferControl() {
	req, _ := json.Marshal(&baseReq{TransID: "Cmbc.QueryTransferControl"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("queryTransferControl doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dStr, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("queryTransferControl decryptResp2NoUnmarshal err=%+v", err)
	}

	b.logger.Infof(">>>>>>>>queryTransferControl<<<<<<<<<<\r\n %+v", dStr)
}

// 获取到transToken
func (b *Bank) transferIntrute() *transferIntruteResp {
	respObj := &transferIntruteResp{}

	req, _ := json.Marshal(&transferIntruteReq{
		baseReq:      baseReq{TransID: "cmbc.transferIntrute"},
		TransferType: "1",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("transferIntrute doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("transferIntrute decryptResp2 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>qryOrderInfoOp<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 获取账户信息
func (b *Bank) getAcctList() *getAcctResp {
	respObj := &getAcctResp{}

	req, _ := json.Marshal(&getAcctListReq{
		baseReq:    baseReq{TransID: "cmbc.getAcctList"},
		Type:       "1",
		IsAuthAcct: "1",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("getAcctList doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("getAcctList decryptResp2 err=%+v", err)
		return respObj
	}
	b.logger.Infof("getAcctList >>>>> %+v", respObj)

	return respObj
}

// 查询银行信息
func (b *Bank) queryBankInfoByCard(destName, destAccount string) *queryBankInfoByCardResp {
	respObj := &queryBankInfoByCardResp{}

	req, _ := json.Marshal(&queryBankInfoByCardReq{
		baseReq:          baseReq{TransID: "cmbc.queryBankInfoByCard"},
		PayeeAccountName: destName,
		PayeeAccountNo:   destAccount,
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("queryBankInfoByCard doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("queryBankInfoByCard decryptResp2 err=%+v", err)
		return respObj
	}
	b.logger.Infof(">>>>>>>>queryBankInfoByCard<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

func (b *Bank) loadAccountNoBinBankintelligenceFour(amount, srcAccount, destAccount, destName, destBankName, destBankCode string) *loadAccountNoBinBankintelligenceFourResp {
	respObj := &loadAccountNoBinBankintelligenceFourResp{}

	req, _ := json.Marshal(&loadAccountNoBinBankintelligenceFourReq{
		baseReq:          baseReq{TransID: "loadAccountNoBinBankintelligenceFour"},
		PayeeAccountNo:   destAccount,
		PayeeAccountName: destName,
		PayeeBankName:    destBankName,
		PayeePathBank:    "",
		SmallBankType:    destBankCode,
		TransferMode:     "1",
		CityCode:         "",
		AmountValue:      amount,
		PayerAccountNo:   srcAccount,
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("loadAccountNoBinBankintelligenceFour doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("loadAccountNoBinBankintelligenceFour decryptResp2 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>loadAccountNoBinBankintelligenceFour<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 检查是否限额
func (b *Bank) checkTransferLimitFour(amount string) *baseResp {
	respObj := &baseResp{}

	req, _ := json.Marshal(&checkTransferLimitFourReq{
		baseReq:    baseReq{TransID: "Cmbc.checkTransferLimitFour"},
		TranAmount: amount,
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("checkTransferLimitFour doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("checkTransferLimitFour decryptResp2 err=%+v", err)
		return respObj
	}

	b.logger.Infof("checkTransferLimitFour >>>>>>> %+v", respObj)

	return respObj
}

// 提交转账信息
func (b *Bank) transferPreNew(amount, srcAccount, destName, destAccount, destBankCode, remark string) *transferPreNewResp {
	if remark == "" {
		remark = "手机转账"
	}

	respObj := &transferPreNewResp{}

	req, _ := json.Marshal(&transferPreNewReq{
		baseReq:            baseReq{TransID: "Cmbc.TransferPreNew"},
		CdtrBranchId:       "",
		CdtrAcctName:       destName,
		CdtrAcctNo:         destAccount,
		TransUsing:         remark,
		TransferMode:       "1",
		TransAccount:       srcAccount,
		RandomNum:          "",
		SttlmAmt:           amount,
		BankDistinction:    destBankCode,
		CustLimitCheckFlag: "0",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("transferPreNew doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("transferPreNew decryptResp2 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>checkTransferLimitFour<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 提交密码等数据 这个银行没有返回账单号，很奇葩
func (b *Bank) transferMain(transToken, smsCode, verifyToken, pwdData string) *transferMainResp {
	respObj := &transferMainResp{}

	reqObj := &transferMainReq{}
	reqObj.TransID = "Cmbc.TransferMain"
	reqObj.IsChoosePrivateProblem = "0"
	reqObj.TransToken = transToken
	reqObj.VerifyData.VerifyToken = verifyToken
	reqObj.VerifyData.SecToolSelected = "SMS+PWD"
	reqObj.VerifyData.PWDEncrypt = b.enPassword(b.PayPwd(), pwdData)
	reqObj.VerifyData.SMSCode = smsCode

	req, _ := json.Marshal(reqObj)

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, b.addBaseQuery(&url.Values{}),
		b.addBaseHeader(&http.Header{
			headers.ContentType: []string{"application/x-www-form-urlencoded"},
		}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("transferMain doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp1(resp, b.loginAfterKey, respObj)
	if err != nil {
		b.logger.Errorf("transferMain decryptResp1 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>transferMain<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 查询转账结果
func (b *Bank) speBookDetailQryOpFour() *speBookDetailQryOpFourResp {
	respObj := &speBookDetailQryOpFourResp{}

	req, _ := json.Marshal(&baseReq{TransID: "cmbc.SPEBookDetailQryOpFour"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("speBookDetailQryOpFour doCMBCHTTPPost002 err=%+v", err)
		return respObj
	}

	err = b.decryptResp2(resp, respObj)
	if err != nil {
		b.logger.Errorf("speBookDetailQryOpFour decryptResp2 err=%+v", err)
		return respObj
	}

	b.logger.Infof(">>>>>>>>speBookDetailQryOpFour<<<<<<<<<<\r\n %+v", respObj)

	return respObj
}

// 这后面的两个包已经与转账无关了
func (b *Bank) getTransRecorde() {
	req, _ := json.Marshal(&baseReq{TransID: "cmbc.getTransRecorde"})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("getTransRecorde doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dStr, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("getTransRecorde decryptResp2NoUnmarshal err=%+v", err)
		return
	}

	b.logger.InfoJSON(">>>>>>>>getTransRecorde<<<<<<<<<<\r\n", dStr)
}

// 获取广告
func (b *Bank) getAdBanner() {
	req, _ := json.Marshal(&getAdBannerReq{
		baseReq:    baseReq{TransID: "cmbc.getAdBanner"},
		TRAN_SCENE: "transfer",
	})

	resp, err := b.doCMBCHTTPPost002(urlTransservlet, &url.Values{
		"isNewClientFour": []string{"1"},
	}, b.addBaseHeader(&http.Header{
		headers.ContentType: []string{"application/x-www-form-urlencoded"},
	}), b.loginAfterKey, req)
	if err != nil {
		b.logger.Errorf("getAdBanner doCMBCHTTPPost002 err=%+v", err)
		return
	}

	dStr, err := b.decryptResp2NoUnmarshal(resp)
	if err != nil {
		b.logger.Errorf("getAdBanner decryptResp2NoUnmarshal err=%+v", err)
		return
	}

	b.logger.InfoJSON(">>>>>>>>getAdBanner<<<<<<<<<<\r\n", dStr)
}
