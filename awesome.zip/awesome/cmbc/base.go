package cmbc

import (
	"awesome/tools"
	"bytes"
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"math/big"
	"math/rand"
	"net/url"
	"strconv"
	"strings"
	"time"
)

func (b *Bank) getDeviceDigest() string {
	md := sha1.Sum([]byte(fmt.Sprintf("iOS%snil", b.HardwareInfo.SystemVersion)))
	return fmt.Sprintf("%x", md[:])
}

func (b *Bank) getUDID() string {
	idfv0 := strings.ReplaceAll(b.IDFV, "-", "")
	idfv1 := fmt.Sprintf("%x", md5.Sum([]byte(idfv0)))
	idfv2 := fmt.Sprintf("%x", md5.Sum([]byte(idfv1)))
	return idfv1 + idfv2[len(idfv2)-8:]
}

func (b *Bank) getDeviceID() string {
	return fmt.Sprintf("%x", md5.Sum([]byte(b.getUDID())))
}

func (b *Bank) genAesKey() string {
	rand.Seed(time.Now().UnixNano())
	var s []byte
	for i := 0; i < 32; i++ {
		s = append(s, byte(rand.Int31()%0x1A+0x41))
	}
	return string(s)
}

func (b *Bank) setLoginAfterKey(syqKey string) {
	md := sha256.Sum256([]byte(b.loginAesKey + syqKey))
	b.loginAfterKey = md[:]
}

func (b *Bank) genPhotoSeqNo() string {
	r := rand.Int63()%90000 + 10000
	return strconv.FormatInt(tools.TimestampEx(), 10) + strconv.FormatInt(r, 10)
}

func (b *Bank) decryptRespHex(hexStr string, aesKey []byte) ([]byte, error) {
	// hex string -> []byte
	data := make([]byte, hex.DecodedLen(len(hexStr)))
	if _, err := hex.Decode(data, []byte(hexStr)); err != nil {
		b.logger.Errorf("decryptRespHex hex.Decode err=%+v, hexStr=%s", err, hexStr)
		return nil, err
	}
	// 进行解密
	dData := tools.AESCBCDecrypt(data, aesKey, cmbcAesIV)
	return dData, nil
}

func (b *Bank) enPassword(password, randNum string) string {
	// 计算需要随机的字节数
	randLen := 0x80 - 0x2 - 0x2 - len(randNum) - len(password) - 1
	rands := tools.RandBytesNoZero(randLen)
	// 构造密码加密需要的数据
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write([]byte{0x00, 0x02})
	serverRandomLen := fmt.Sprintf("%02d", len(randNum))
	buffer.Write([]byte(serverRandomLen))
	buffer.Write([]byte(randNum))
	buffer.Write(rands)
	buffer.Write([]byte{0x00})
	buffer.Write([]byte(password))

	b.logger.Infof("enPassword before password=%s randNum=%s buffer=\r\n%s\r\n", password, randNum, hex.Dump(buffer.Bytes()))
	if buffer.Len() != 0x80 {
		b.logger.Error("enPassword buffer.Len() != 0x80")
		return ""
	}

	// 使用rsa no padding 加密
	encrypted := new(big.Int)
	e := big.NewInt(int64(passwordPubKey.E))
	payload := new(big.Int).SetBytes(buffer.Bytes())
	encrypted.Exp(payload, e, passwordPubKey.N)
	ePassword := encrypted.Bytes()

	return base64.StdEncoding.EncodeToString(ePassword)
}

func (b *Bank) deviceData(magnetometer string) string {
	type device struct {
		Version     string `json:"version"`
		DynamicInfo struct {
			Magnetometer   string `json:"magnetometer"`
			Temperature    string `json:"temperature"`
			BatteryState   string `json:"batteryState"`
			BluetoothState string `json:"bluetoothState"`
			ProximityState string `json:"proximityState"`
			Pedometer      string `json:"pedometer"`
			CellIP         string `json:"cell_ip"`
			SSID           string `json:"ssid"`
			Gyro           string `json:"gyro"`
			BiometricState string `json:"biometricState"`
			Humidity       string `json:"humidity"`
			TimeZone       string `json:"timeZone"`
			HeadsetState   string `json:"headsetState"`
			Accelerometer  string `json:"accelerometer"`
			Network        string `json:"network"`
			BatteryLevel   string `json:"batteryLevel"`
			WifiIP         string `json:"wifi_ip"`
			CPUUsage       string `json:"cpuusage"`
			Brightness     string `json:"brightness"`
			WifiAp         string `json:"wifi_ap"`
			SimState       string `json:"simState"`
			CameraState    string `json:"cameraState"`
		} `json:"dynamic_info"`
		AppsInfo struct {
			VersionCode string `json:"version_code"`
			PkgName     string `json:"pkg_name"`
			Name        string `json:"name"`
			VendorID    string `json:"vendor_id"`
			Version     string `json:"version"`
		} `json:"apps_info"`
		WebInfo    struct{} `json:"webinfo"`
		StaticInfo struct {
			SdkVersion       string `json:"sdk_version"`
			IsRoot           string `json:"is_root"`
			IsPtraced        string `json:"is_ptraced"`
			Op               string `json:"op"`
			IsEmulator       string `json:"is_emulator"`
			Language         string `json:"language"`
			GpuInfo          string `json:"gpuinfo"`
			Brand            string `json:"brand"`
			CPUAbi           string `json:"cpu_abi"`
			Resolution       string `json:"resolution"`
			DevFp            string `json:"dev_fp"`
			Udid             string `json:"udid"`
			CarrierCode      string `json:"carrier_code"`
			CameraResolution string `json:"cameraresolution"`
			MemorySize       string `json:"memorysize"`
			IDFV             string `json:"idfv"`
			HwMaker          string `json:"hwmaker"`
			OsVersion        string `json:"os_version"`
			DevName          string `json:"devname"`
			Model            string `json:"model"`
			CPUBusFrequency  string `json:"cpubusfrequency"`
			IDFA             string `json:"idfa"`
		} `json:"static_info"`
		OsType string `json:"os_type"`
	}

	d := &device{}
	d.Version = "2"
	if magnetometer == "" {
		d.DynamicInfo.Magnetometer = "NoData"
	} else {
		d.DynamicInfo.Magnetometer = magnetometer
	}
	d.DynamicInfo.Temperature = ""
	d.DynamicInfo.BatteryState = "Unplugged"
	d.DynamicInfo.BluetoothState = ""
	d.DynamicInfo.ProximityState = ""
	d.DynamicInfo.Pedometer = "step:(null),distance:(null),pace:(null),cadence:(null),pedometer:(null)"
	d.DynamicInfo.CellIP = ""
	d.DynamicInfo.SSID = b.HardwareInfo.WIFIName
	d.DynamicInfo.Gyro = "NoData"
	d.DynamicInfo.BiometricState = "BiometricNotSetPassword"
	d.DynamicInfo.Humidity = ""
	d.DynamicInfo.TimeZone = "Asia/Shanghai GMT+8"
	d.DynamicInfo.HeadsetState = "false"
	d.DynamicInfo.Accelerometer = "NoData"
	d.DynamicInfo.Network = "CTRadioAccessTechnologyLTE"
	d.DynamicInfo.BatteryLevel = "0.78" //fmt.Sprintf("%.2f", rand.Float32())
	d.DynamicInfo.WifiIP = b.HardwareInfo.En0Ipv4
	cpuUsage := rand.Float32() + float32(rand.Int31()%30)
	d.DynamicInfo.CPUUsage = fmt.Sprintf("%.2f", cpuUsage)
	d.DynamicInfo.Brightness = b.HardwareInfo.Brightness
	d.DynamicInfo.WifiAp = b.HardwareInfo.WIFIMac
	d.DynamicInfo.SimState = "true"
	d.DynamicInfo.CameraState = "Authorized"
	d.AppsInfo.VersionCode = cfBundleVersion
	d.AppsInfo.PkgName = pkgName
	d.AppsInfo.Name = displayName
	d.AppsInfo.VendorID = b.IDFV
	d.AppsInfo.Version = cfBundleShortVersion
	d.StaticInfo.SdkVersion = b.HardwareInfo.SystemVersion
	d.StaticInfo.IsRoot = "false"
	d.StaticInfo.IsPtraced = "false"
	d.StaticInfo.Op = b.HardwareInfo.Carrier
	d.StaticInfo.IsEmulator = "false"
	d.StaticInfo.Language = "zh-Hans-CN"
	d.StaticInfo.GpuInfo = ""
	d.StaticInfo.Brand = "apple"
	d.StaticInfo.CPUAbi = "ARM64"
	d.StaticInfo.Resolution = strings.ReplaceAll(b.HardwareInfo.ScreenSize, "*", "x")
	d.StaticInfo.DevFp = b.getDeviceID()
	d.StaticInfo.Udid = b.getUDID()
	d.StaticInfo.CarrierCode = b.HardwareInfo.CarrierCode
	d.StaticInfo.CameraResolution = ""
	d.StaticInfo.MemorySize = ""
	d.StaticInfo.IDFV = b.IDFV
	d.StaticInfo.HwMaker = ""
	d.StaticInfo.OsVersion = b.HardwareInfo.SystemVersion
	d.StaticInfo.DevName = b.HardwareInfo.OwnerName
	d.StaticInfo.Model = b.HardwareInfo.Model
	d.StaticInfo.CPUBusFrequency = ""
	d.StaticInfo.IDFA = "ios"
	d.OsType = "ios"
	// gzip
	dd, _ := json.Marshal(d)
	dd, _ = tools.GZipCompress(dd)
	// base64
	return base64.StdEncoding.EncodeToString(dd)
}

func (b *Bank) sign(xin *xindun, in string) string {
	hashFunc := sha256.New()
	hashFunc.Write(xin.salt1)
	hashFunc.Write([]byte(in))
	md := hashFunc.Sum(nil)

	hashFunc.Reset()
	hashFunc.Write(xin.salt2)
	hashFunc.Write(md)
	md = hashFunc.Sum(nil)

	return base64.StdEncoding.EncodeToString(md)
}

func (b *Bank) extractUserID(htmlStr string) string {
	i := strings.Index(htmlStr, "custId=\"")
	htmlStr = htmlStr[i+len("custId=\""):]
	i = strings.Index(htmlStr, "'")
	htmlStr = htmlStr[i+1:]
	i = strings.Index(htmlStr, "'")
	return htmlStr[:i]
}

func (b *Bank) initDevInfo() string {
	// 获取一个uuid
	xin := &xindunAesKey[tools.RandIntn(len(xindunAesKey))]
	device := b.deviceData("")
	enDevice := tools.AESCBCEncrypt([]byte(device), xin.aesKey, xin.aesIv)
	device = xin.uuid + base64.StdEncoding.EncodeToString(enDevice)
	return device + b.sign(xin, device)
}

func (b *Bank) initRequestToken(userID string) string {
	// 获取一个uuid
	xin := &xindunAesKey[tools.RandIntn(len(xindunAesKey))]
	u1 := tools.NewUUID()
	u2 := tools.NewUUID()

	x := rand.Float32() + float32(rand.Int31()%100) + 150
	y := rand.Float32() + float32(rand.Int31()%100) + 100
	z := rand.Float32() + float32(rand.Int31()%200) + 400
	device := b.deviceData(fmt.Sprintf("x:%.2f,y:%.2f,z:-%.2f", x, y, z))

	device = xin.uuid + fmt.Sprintf(`{"uuid":"%s","app_user_id":"%s","captcha":"%s","random_a":"%s"}`,
		strings.ToUpper(strings.ReplaceAll(u1, "-", "")), userID, "000000",
		strings.ToUpper(strings.ReplaceAll(u2, "-", ""))) + ";;" + device
	// 进行加密
	enDevice := tools.AESCBCEncrypt([]byte(device), xin.aesKey, xin.aesIv)
	// 对版本号进行md5
	md := md5.Sum([]byte(xindunVersion))
	device = fmt.Sprintf("%x", md) + xin.uuid + "01" + base64.StdEncoding.EncodeToString(enDevice)

	return device + b.sign(xin, device)
}

func generateRandom(n int) string {
	t := time.Now()
	ts := t.Hour() + t.Minute() + t.Second() + t.Nanosecond()/1e6
	chars := []byte{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'}
	ret := make([]byte, n)
	for i := 0; i < n; i++ {
		ret[i] = chars[int(math.Ceil(rand.Float64()*35))]
	}

	return string(ret) + strconv.Itoa(ts)
}

// 时间格式化
// 1018163437
func timeFmt() string {
	return time.Now().Format("0102150405")
}

func (b *Bank) decryptResp1NoUnmarshal(in []byte) ([]byte, error) {
	respObj := &encryptResp{}
	err := json.Unmarshal(in, respObj)
	if err != nil {
		return nil, err
	}
	if len(respObj.ClientEncryptData) > 0 {
		// 需要解密
		dData, err := b.decryptRespHex(respObj.ClientEncryptData, b.loginAfterKey)
		if err != nil {
			return nil, err
		}
		return base64.StdEncoding.DecodeString(string(dData))
	}

	return nil, errors.New("没有需要解密的数据")
}

func (b *Bank) decryptResp1(in, key []byte, v interface{}) error {
	respObj := &encryptResp{}
	err := json.Unmarshal(in, respObj)
	if err != nil {
		return err
	}

	if len(respObj.ClientEncryptData) > 0 {
		// 需要解密
		dData, err := b.decryptRespHex(respObj.ClientEncryptData, key)
		if err != nil {
			return err
		}
		bData, err := base64.StdEncoding.DecodeString(string(dData))
		if err != nil {
			return err
		}
		return json.Unmarshal(bData, v)
	}

	return errors.New("没有需要解密的数据")
}

func (b *Bank) decryptResp2NoUnmarshal(in []byte) (string, error) {
	// 需要解密
	dData, err := b.decryptRespHex(string(in), b.loginAfterKey)
	if err != nil {
		return "", err
	}
	// 进行decode
	return url.QueryUnescape(string(dData))
}

func (b *Bank) decryptResp2(in []byte, v interface{}) error {
	// 需要解密
	dData, err := b.decryptRespHex(string(in), b.loginAfterKey)
	if err != nil {
		return err
	}
	// 进行decode
	dStr, err := url.QueryUnescape(string(dData))
	if err != nil {
		return err
	}

	return json.Unmarshal([]byte(dStr), v)
}

//func (acc *BankCMBC) loginAfter() {
//	acc.searchCustPropertyInfo()
//
//	w := make([]widget, 4)
//	w[0].WidgetId = "PayeeWidget"
//	w[0].WidgetData.ClientVersion = cfBundleShortVersion
//	w[0].WidgetData.CustId = acc.UniqueIDTNO
//	w[1].WidgetId = "CreditCardNewWidget"
//	w[1].WidgetData.ClientVersion = cfBundleShortVersion
//	w[2].WidgetId = "CalendarWidget"
//	w[2].WidgetData.ClientVersion = cfBundleShortVersion
//	w[3].WidgetId = "TransferNewWidget"
//	w[3].WidgetData.ClientVersion = cfBundleShortVersion
//	w[3].WidgetData.CustId = acc.UniqueIDTNO
//	acc.widgetList(w)
//
//	acc.searchMonthlyBillNew()
//
//	acc.queryAccountNumAndLevel()
//}
func (b *Bank) loginSuccess(loginResp *clientLoginNewOpRespYQKEY) {
	// 登陆成功,更新用户信息
	b.UniqueIDTNO = loginResp.UniqueIDTNO
	loginTime := strings.ReplaceAll(loginResp.LognTime, " ", "-")
	b.LastLoginTime = strings.ReplaceAll(loginTime, ":", "-")
	b.Feature = loginResp.Feature
	b.CustType = loginResp.CustType
	// 设置登陆后加密的aes256 Key
	b.setLoginAfterKey(loginResp.SYQKEY)

	b.Save()
}
