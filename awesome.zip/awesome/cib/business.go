package cib

import (
	"awesome/tools"
	"bytes"
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/twmb/murmur3"
	"math/rand"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/go-http-utils/headers"
)

func (b *Bank) postHTTPData(u string, req, res interface{}) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		b.logger.Errorf("postHTTPData序列化请求数据错误: %+v.", err)
		return "", err
	}

	//b.logger.Infof("postHTTPData, url: %s, req body: %s.", u, string(arr))

	r, err := http.NewRequest("POST", u, bytes.NewReader(arr))
	if err != nil {
		b.logger.Errorf("postHTTPData创建http请求错误: %+v.", err)
		return "", err
	}

	// header
	r.Header.Add(headers.UserAgent, fmt.Sprintf("CIBMobileBank-prod/%s (iPhone; iOS %s; Scale/2.00)", cfBundleShortVersion, b.HardwareInfo.SystemVersion))
	r.Header.Add(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.Accept, "*/*")
	r.Header.Add(headers.ContentType, "application/json")
	r.Header.Add("formdev", "IOS")
	r.Header.Add("viewfrom", "2")
	r.Header.Add("channel", "208")
	r.Header.Add("terminaltype", "01")
	r.Header.Add("ua", fmt.Sprintf("%s,iOS,%s", b.HardwareInfo.Model, cfBundleShortVersion))

	// token
	if b.token != "" {
		r.Header.Set("formtoken", b.token)
	}
	// dfp
	if b.DFP != "" {
		r.Header.Add("bsfit-deviceid", b.DFP)
	}
	// handleid
	r.Header.Add("handleid", b.getHandleID())
	// reqid 5.0.19
	r.Header.Add("reqid", tools.NewUUIDUpper())

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf("postHTTPData http操作错误: %+v.", err)
		return "", err
	}

	//b.logger.Infof("postHTTPData, url: %s, res body: %s.", u, body)

	if res != nil {
		if err := json.Unmarshal([]byte(body), res); err != nil {
			b.logger.Errorf("postHTTPData反序列化响应数据错误: %+v.", err)
			return "", err
		}
	}

	return body, nil
}

func (b *Bank) postData(u string, req, res interface{}) (string, error) {
	return b.postEncData(u, req, res, true)
}

func (b *Bank) postEncData(u string, req, res interface{}, decrypt bool) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		b.logger.Errorf("postEncData序列化请求数据错误: %+v.", err)
		return "", err
	}

	b.logger.Infof("postEncData, url: %s, req JSON: %s.", u, string(arr))

	// 计算mac
	mac := fmt.Sprintf("%s%s", string(arr), b.salt)
	mac = fmt.Sprintf("%x", sha1.Sum([]byte(mac)))

	// 加密数据
	key := []byte(b.aesKey)
	arr = tools.AESCBCEncrypt(arr, key, key)
	if arr == nil {
		b.logger.Error("postEncData加密请求数据错误")
		return "", errors.New("aes加密出现错误")
	}

	reqData := map[string]interface{}{
		"mac":  mac,
		"data": base64.StdEncoding.EncodeToString(arr),
	}

	body := ""

	if decrypt {
		var resData struct {
			Data string `json:"data"`
		}

		body, err = b.postHTTPData(u, &reqData, &resData)
		if err != nil {
			return "", err
		}

		arr, err := base64.StdEncoding.DecodeString(resData.Data)
		if err != nil {
			b.logger.Errorf("postEncData解码返回数据错误: %+v", err)
			return "", err
		}

		arr = tools.AESCBCDecrypt(arr, key, key)

		body = string(arr)
		// b.logger.Infof("postEncData解密返回数据: %s.", body)

	} else {
		body, err = b.postHTTPData(u, &reqData, nil)
		if err != nil {
			return "", err
		}
	}

	b.logger.Infof("postEncData, url: %s, resp : %s", u, body)

	if res != nil {
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			b.logger.Errorf("反序列化解密数据错误: %+v.", err)
			return "", nil
		}
	}

	return body, nil
}

func (b *Bank) getHTTPData(u string) (string, error) {

	b.logger.Infof("getHTTPData, url: %s", u)

	r, err := http.NewRequest("GET", u, nil)
	if err != nil {
		b.logger.Errorf("getHTTPData创建http请求错误: %+v.", err)
		return "", err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")

	// dfp
	if b.DFP != "" {
		r.AddCookie(&http.Cookie{
			Name:  "BSFIT_DEVICEID",
			Value: b.DFP,
		})
	}

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf("getHTTPData http操作错误: %+v.", err)
		return "", err
	}

	b.logger.Infof("getHTTPData, url: %s, res body: %s.", u, body)

	return body, nil
}

func (b *Bank) addBaseReq(req *map[string]interface{}) {
	(*req)["appVerCode"] = appVerCode
	(*req)["appVersion"] = cfBundleShortVersion
	(*req)["channel"] = "208"
	(*req)["devPlat"] = "IOS"
	(*req)["theme"] = "0"
}

func (b *Bank) downloadFrms() string {
	req, _ := http.NewRequest("GET", urlDownloadFrms, nil)
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	req.Header.Add("Connection", "keep-alive")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 /sa-sdk-ios/sensors-verify/bigdata.cib.com.cn?ebank_mobile  cib-ebank/newland/%s/20/t-d UnionPay/1.0 CIB",
		sysVer, cfBundleShortVersion))
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")

	// dfp
	if b.DFP != "" {
		req.Header.Add(headers.Cookie, "BSFIT_DEVICEID="+b.DFP)
		req.Header.Add(headers.Cookie, "BSFIT_EXPIRATION="+b.DFPExpire)
	}

	resp, err := tools.DoHTTPReq(b.client, req)
	if err != nil || resp == "" {
		b.logger.Errorf("downloadFrms DoHTTPGet 出现错误 err=%+v resp=%+v", err, resp)
		return ""
	}

	b.logger.Info("downloadFrms resp >>>>>>>>" + resp)

	return resp
}

func (b *Bank) generateJsonp(algID string) *generateRes {
	iosMapping := map[string]string{
		"model":           "k3LE",
		"networkType":     "Swlw",
		"packageName":     "VQFA",
		"totalMemory":     "oUvy",
		"totalSystem":     "bxIT",
		"cellularIP":      "PneH",
		"resolution":      "9_vV",
		"IDFA":            "bA0Q",
		"brightness":      "qm7W",
		"IDFV":            "sxWp",
		"startupTime":     "oA3w",
		"wifiList":        "wXg4",
		"version":         "XKTz",
		"appVersion":      "wfQn",
		"battery":         "89Fw",
		"rooted":          "UqMW",
		"activeTime":      "R7of",
		"carrier":         "WANY",
		"language":        "pO8w",
		"sdkVersion":      "Vkrm",
		"fork":            "jQx6",
		"appCache":        "9PRr",
		"contactsHash":    "kClR",
		"isVPN":           "G0rn",
		"isProxy":         "m6C7",
		"coordinates":     "Kavb",
		"appList":         "nt7F",
		"account":         "mvIR",
		"userAgent":       "0aew",
		"availableSystem": "H6Rg",
	}

	// wapSmartID 计算
	str1 := fmt.Sprintf("32~~~~2~~~~%d;%d~~~~-480~~~~unknown~~~~iPhone~~~~5~~~~Arial;Arial Hebrew;Arial Rounded MT Bold;Courier;Courier New;Georgia;Helvetica;Helvetica Neue;Palatino;Times;Times New Roman;Trebuchet MS;Verdana",
		tools.ScreenHeightPt(b.HardwareInfo.Model),
		tools.ScreenWidthPt(b.HardwareInfo.Model))
	str2 := fmt.Sprintf("zh-CN~~~%d;%d~~~Mozilla5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit605.1.15 (KHTML, like Gecko) Mobile15E148 sa-sdk-iossensors-verifybigdata.cib.com.cnebank_mobile  cib-ebanknewland%s20t-d UnionPay1.0 CIB~~~1~~~1~~~1~~~unknown~~~0~~~false~~~false~~~false~~~false",
		tools.ScreenHeightPt(b.HardwareInfo.Model),
		tools.ScreenWidthPt(b.HardwareInfo.Model),
		strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_"),
		cfBundleShortVersion)

	mm3 := murmur3.SeedNew128(31, 31)
	_, _ = mm3.Write([]byte(str1))
	md1 := mm3.Sum(nil)
	mm3 = murmur3.SeedNew128(31, 31)
	_, _ = mm3.Write([]byte(str2))
	md2 := mm3.Sum(nil)

	wapSmartID := fmt.Sprintf("%x%x", md1[8:], md2[8:])

	// 计算hash
	ownerMD := md5.Sum([]byte(b.HardwareInfo.OwnerName))
	info := map[string]string{
		"account":         fmt.Sprintf("%x", ownerMD[4:12]),
		"appCache":        fmt.Sprintf("%d.0000", b.AppCache+tools.RandIntn(20000)),
		"appVersion":      cfBundleShortVersion,
		"availableSystem": fmt.Sprintf("%d", b.HardwareInfo.AvailableSystemSpace-tools.RandIntn(200000)),
		"battery":         b.HardwareInfo.Battery,
		"brightness":      b.HardwareInfo.Brightness,
		"carrier":         b.HardwareInfo.Carrier,
		"cellularIP":      b.HardwareInfo.CellularIP,
		"custID":          "123",
		"isCheat":         "0",
		"isDebugger":      "0",
		"isMoreOpen":      "0",
		"isProxy":         "0",
		"isVPN":           "0",
		"language":        "[zh_CN-中文（中国大陆）]",
		"model":           b.HardwareInfo.Model,
		"networkType":     "WiFi",
		"packageName":     pkgName,
		"platform":        "IOS",
		"resolution":      fmt.Sprintf("[%s]", strings.ReplaceAll(b.HardwareInfo.ScreenSize, "*", "-")),
		"rooted":          "0",
		"sdkVersion":      "4.5.3",
		"startupTime":     b.SystemStartTime,
		"totalMemory":     b.HardwareInfo.TotalMemory,
		"totalSystem":     b.HardwareInfo.TotalSystemSpace,
		"version":         b.HardwareInfo.SystemVersion,
		"wapSmartID":      wapSmartID,
	}
	if b.IDFV != "" {
		info["IDFV"] = b.IDFV
	}

	keys := make([]string, 0)
	for k := range info {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	str := ""
	query := ""
	for _, k := range keys {
		str = fmt.Sprintf("%s%s%s", str, k, info[k])
		value := url.QueryEscape(info[k])
		if v, ok := iosMapping[k]; ok {
			query = query + "&" + v + "=" + value
		} else {
			query = query + "&" + k + "=" + value
		}
	}

	s := ""
	count := 0
	for _, ch := range str {
		s = fmt.Sprintf("%c", ch) + s
		count++
	}

	st := []rune(s)
	if count%2 == 0 {
		s = string(append(st[count/2:], st[:count/2]...))
	} else {
		s = string(append(append(st[count/2+1:], st[count/2:count/2+1]...), st[:count/2]...))
	}

	f := 0
	st = []rune(s)
	if count%3 == 0 {
		f = count / 3
	} else {
		f = count/3 + 1
	}

	if count > 3 {
		s = string(append(append(st[f:2*f], st[2*f:]...), st[:f]...))
	}

	b64Encoder := base64.NewEncoding("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_").WithPadding(base64.NoPadding)

	s256 := sha256.New()
	s256.Write([]byte(s))
	md := s256.Sum(nil)
	mdStr := b64Encoder.EncodeToString(md)

	st = []rune(mdStr)
	count = len(st)
	if count%2 == 0 {
		s = string(append(st[count/2:], st[:count/2]...))
	} else {
		s = string(append(append(st[count/2+1:], st[count/2:count/2+1]...), st[:count/2]...))
	}

	s256 = sha256.New()
	s256.Write([]byte(s))
	md = s256.Sum(nil)
	mdStr = b64Encoder.EncodeToString(md)

	// 开始生成query
	query = "algID=" + algID + "&hashCode=" + mdStr + query + "&timestamp=" + fmt.Sprintf("%d", tools.TimestampEx())

	req, _ := http.NewRequest("GET", urlGenerateJsonp+"?"+query, nil)
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	req.Header.Add("Connection", "keep-alive")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 /sa-sdk-ios/sensors-verify/bigdata.cib.com.cn?ebank_mobile  cib-ebank/newland/%s/20/t-d UnionPay/1.0 CIB",
		sysVer, cfBundleShortVersion))
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")

	// dfp
	if b.DFP != "" {
		req.Header.Add(headers.Cookie, "BSFIT_DEVICEID="+b.DFP)
		req.Header.Add(headers.Cookie, "BSFIT_EXPIRATION="+b.DFPExpire)
	}

	resObj := &generateRes{}

	body, err := tools.DoHTTPReq(b.client, req)
	if err != nil {
		b.logger.Errorf("generateJsonp http操作错误: %+v.", err)
		return resObj
	}

	strBody := string(body)
	strBody = strings.ReplaceAll(strBody, "callbackFunction('", "")
	strBody = strings.ReplaceAll(strBody, "')", "")

	b.logger.Infof("generateJsonp, res body: %s.", body)

	_ = json.Unmarshal([]byte(strBody), resObj)

	return resObj
}

func (b *Bank) keyHandle() (*keyHandleRes, error) {
	b.aesKey = tools.RandHexString(16)
	b.salt = tools.RandHexString(8)
	keyStr := encAESKey([]byte(fmt.Sprintf("16%s%s%s", b.aesKey, b.salt, tools.RandHexString(102))))

	req := map[string]interface{}{
		"key_str":    keyStr,
		"key_type":   "AES_KEY",
		"key_length": "128",
		//"key_id":     b.HandleID + tools.TimeFmtEx0(),
	}
	//if b.HandleID != "" {
	//	req["key_id"] = b.HandleID
	//}
	b.addBaseReq(&req)

	res := keyHandleRes{}
	if _, err := b.postHTTPData(urlKeyHandle, &req, &res); err != nil {
		b.logger.Errorf("keyHandle请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryPrivacyProtocol() (*queryPrivacyProtocolRes, error) {
	req := map[string]interface{}{
		"protocolVersion": b.ProtocolVersion,
	}
	b.addBaseReq(&req)

	res := queryPrivacyProtocolRes{}
	if _, err := b.postData(urlQueryPrivacyProtocol, &req, &res); err != nil {
		b.logger.Errorf("queryPrivacyProtocol请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) agreePrivacyProtocol(protocolVersion, innerCode string) (*agreePrivacyProtocolRes, error) {
	req := map[string]interface{}{
		"protocolVersion": protocolVersion,
		"devSN":           b.UUID,
		"innerCode":       innerCode,
	}
	b.addBaseReq(&req)

	res := agreePrivacyProtocolRes{}
	if _, err := b.postData(urlAgreePrivacyProtocol, &req, &res); err != nil {
		b.logger.Errorf("agreePrivacyProtocol请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) deviceInnerCode() (*deviceInnerCodeRes, error) {
	req := map[string]interface{}{}
	b.addBaseReq(&req)

	res := deviceInnerCodeRes{}
	if _, err := b.postData(urlDeviceInnerCode, &req, &res); err != nil {
		b.logger.Errorf("deviceInnerCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryUserByMisty() (*queryUserByMistyRes, error) {
	req := map[string]interface{}{
		"uamName": b.Account,
	}
	b.addBaseReq(&req)

	res := queryUserByMistyRes{}
	if _, err := b.postData(urlQueryUserByMisty, &req, &res); err != nil {
		b.logger.Errorf("queryUseByMisty请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryUserByUniauthID() (*queryUserByUniauthIDRes, error) {
	req := map[string]interface{}{
		"uniauthId": b.UniauthID,
	}
	b.addBaseReq(&req)

	res := queryUserByUniauthIDRes{}
	if _, err := b.postData(urlQueryUserByUniauthID, &req, &res); err != nil {
		b.logger.Errorf("queryUseByUniauthID请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) getEncryptPK() (*getEncryptPKRes, error) {
	req := map[string]interface{}{}
	b.addBaseReq(&req)

	res := getEncryptPKRes{}
	if _, err := b.postData(urlGetEncryptPK, &req, &res); err != nil {
		b.logger.Errorf("getEncryptPK请求错误: %+v.", err)
		return nil, err
	}

	// 成功设置key
	if res.Status == 200 {
		b.rsaPublicKey = res.Data.RSAPublicKey
		b.sm2KeyX = res.Data.SM2PublicKeyX
		b.sm2KeyY = res.Data.SM2PublicKeyY
	}

	return &res, nil
}

func (b *Bank) comitLoginInfo() (*comitLoginInfoRes, error) {
	factor := b.UniauthID[2:10]
	ba := bytes.NewBuffer([]byte{})
	_ = binary.Write(ba, binary.BigEndian, int16(len(b.LoginPwd())+len(factor)+4))
	ba.Write([]byte(fmt.Sprintf("%.2d", len(b.LoginPwd()))))
	ba.Write([]byte(b.LoginPwd()))
	ba.Write([]byte(fmt.Sprintf("%.2d", len(factor))))
	ba.Write([]byte(factor))

	data := ba.Bytes()

	cnt := 0x40 - len(data)
	for i := 0; i < cnt; i++ {
		data = append(data, byte(tools.RandBetween(1, 255)))
	}

	pwd, err := encSM2(data, b.sm2KeyX, b.sm2KeyY)
	if err != nil {
		b.logger.Errorf("[comitLoginInfo]加密登录密码错误: %+v.", err)
		return nil, err
	}

	req := map[string]interface{}{
		"mobileType":    strings.ReplaceAll(b.HardwareInfo.DeviceName, " ", ""), //iPhone7
		"genDevId":      b.UUID,
		"agent":         "iOS" + b.HardwareInfo.SystemVersion,
		"latitude":      "",
		"devSN":         b.UUID,
		"loginPhoneNo":  "",
		"faceId":        "",
		"clientVersion": cfBundleShortVersion,
		"uniauthId":     b.UniauthID,
		"longitude":     "",
		"geoType":       "2",
		"macAddr":       "",
		"devName":       b.HardwareInfo.OwnerName,
		"uamPwd":        pwd,
		"terminalType":  "01",
		"ipAddr":        "",
		"isRoot":        "02",
	}
	b.addBaseReq(&req)

	res := comitLoginInfoRes{}
	if _, err := b.postData(urlComitLoginInfo, &req, &res); err != nil {
		b.logger.Errorf("comitLoginInfo请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) getToken() (*getTokenRes, error) {
	req := map[string]interface{}{}
	// b.addBaseReq(&req)

	res := getTokenRes{}
	if _, err := b.postData(urlGetToken, &req, &res); err != nil {
		b.logger.Errorf("getToken请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) mobiles() (*mobilesRes, error) {
	req := map[string]interface{}{
		"uniauthId": b.UniauthID,
		"bizType":   "login",
	}
	// b.addBaseReq(&req)

	res := mobilesRes{}
	if _, err := b.postData(urlMobiles, &req, &res); err != nil {
		b.logger.Errorf("mobiles请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) sendOperSmsCode(index int) (*sendOperSmsCodeRes, error) {
	req := map[string]interface{}{
		"mobile":      b.Account,
		"mobileIndex": index,
	}
	// b.addBaseReq(&req)

	res := sendOperSmsCodeRes{}
	if _, err := b.postData(urlSendOperSmsCode, &req, &res); err != nil {
		b.logger.Errorf("sendOperSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) verifyOperSmsCode(code string) (*verifyOperSmsCodeRes, error) {
	req := map[string]interface{}{
		"mobile":  b.Account,
		"smsCode": code,
	}
	// b.addBaseReq(&req)

	res := verifyOperSmsCodeRes{}
	if _, err := b.postData(urlVerifyOperSmsCode, &req, &res); err != nil {
		b.logger.Errorf("verifyOperSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) custLogin(bind bool) (*custLoginRes, error) {
	req := map[string]interface{}{}
	if bind {
		req["insteadCompage"] = "4"
	}
	b.addBaseReq(&req)

	res := custLoginRes{}
	if _, err := b.postData(urlCustLogin, &req, &res); err != nil {
		b.logger.Errorf("custLogin请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) getAccountsByURL() (*getAccountsByURLRes, error) {
	req := map[string]interface{}{
		"url": "/card-manager/card-list",
	}
	res := getAccountsByURLRes{}
	if _, err := b.postData(urlGetAccountsByURL, &req, &res); err != nil {
		b.logger.Errorf("getAccountsByURL请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryBalance(index int) (*queryBalanceRes, error) {
	req := map[string]interface{}{
		"indexArr": []int{index},
	}

	res := queryBalanceRes{}
	if _, err := b.postData(urlQueryBalance, &req, &res); err != nil {
		b.logger.Errorf("queryBalance请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryTransListByPage(accountIndex int, startDate, endDate string, page int) (*queryTransListByPageRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
		"seqence":      "001",
		"payWay":       "2",
		"tradeType":    "2",
		"minAmount":    "",
		"maxAmount":    "",
		"beginDate":    startDate,
		"endDate":      endDate,
		"startIndex":   page,
		"pageSize":     10,
	}

	res := queryTransListByPageRes{}
	if _, err := b.postData(urlQueryTransListByPage, &req, &res); err != nil {
		b.logger.Errorf("queryTransListByPage请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////二维码////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
func (b *Bank) scanCodePay() (*scanCodePayRes, error) {
	req := map[string]interface{}{
		"uniauthId": b.UniauthID,
	}
	b.addBaseReq(&req)

	res := scanCodePayRes{}
	if _, err := b.postData(urlScanCodePay, &req, &res); err != nil {
		b.logger.Errorf("scanCodePay请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) mobileAccess(cardNo, certNo string) (string, error) {
	query := fmt.Sprintf("phoneNo=%s&type=receipt&cardNo=%s&phoneSim=*&certNo=%s&authed=1&riskInfo=%s,1,no,no,no,no",
		b.Account, cardNo, certNo, b.UUID2)
	signature := fmt.Sprintf("%X", md5.Sum([]byte(query)))
	// 进行rsa加密的
	query = fmt.Sprintf("%s&signature=%s", query, encAESKey([]byte(signature)))

	qrcodeHtml, err := b.getHTTPData(urlMobileAccess + "?" + query)
	if err != nil {
		b.logger.Errorf("mobileAccess请求错误: %+v.", err)
		return "", err
	}

	return qrcodeHtml, nil
}

func (b *Bank) cardInfoVerify() (*cardVerifyRes, error) {

	r, err := http.NewRequest("POST", urlCardInfoVerify, nil)
	if err != nil {
		b.logger.Errorf(" cardInfoVerify 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))

	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "application/json")
	//r.Header.Add(headers.Referer, mobileAccessHtml)

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" cardInfoVerify http操作错误: %+v.", err)
		return nil, err
	}

	b.logger.Infof(" cardInfoVerify, url: %s, res body: %s.", urlCardInfoVerify, body)

	res := &cardVerifyRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}

	return res, nil
}

func (b *Bank) setAmount(money, remark string) (string, error) {
	// 进入设置金额界面
	r, err := http.NewRequest("GET", urlGoSetAmount, nil)
	if err != nil {
		b.logger.Errorf(" setAmount 创建http请求错误: %+v.", err)
		return "", err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	//r.Header.Add(headers.Referer, refer)

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" setAmount http操作错误: %+v.", err)
		return "", err
	}
	b.logger.Infof(" setAmount, url: %s, res body: %s.", urlGoSetAmount, body)
	time.Sleep(time.Duration(rand.Int31n(1000)+500) * time.Millisecond)

	// post 设置金额
	form := url.Values{}
	form.Set("amount", money)
	form.Set("payeeContent", remark)
	r, err = http.NewRequest("POST", urlEnsureAmount, strings.NewReader(form.Encode()))
	if err != nil {
		b.logger.Errorf(" setAmount 创建http请求错误: %+v.", err)
		return "", err
	}

	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.Accept, "application/json")
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	r.Header.Add(headers.Referer, urlGoSetAmount)

	body, err = tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" setAmount http操作错误: %+v.", err)
		return "", err
	}
	b.logger.Infof(" setAmount, url: %s, res body: %s.", urlEnsureAmount, body)
	time.Sleep(time.Duration(rand.Int31n(1000)+500) * time.Millisecond)

	// 准备返回
	r, err = http.NewRequest("GET", urlGoBack, nil)
	if err != nil {
		b.logger.Errorf(" setAmount 创建http请求错误: %+v.", err)
		return "", err
	}
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.Referer, urlGoSetAmount)

	body, err = tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" setAmount http操作错误: %+v.", err)
		return "", err
	}
	b.logger.Infof(" setAmount, url: %s, res body: %s.", urlGoBack, body)
	//time.Sleep(time.Duration(rand.Int31n(1000)+500) * time.Millisecond)
	//
	//// 解析获取二维码html
	//uuu := stringMix(body, "<a href=\"", "\">")
	//if uuu == "" {
	//	b.logger.Error(" setAmount 获取生成的二维码网址出错")
	//	return "", cibError
	//}
	//
	//r, cibError = http.NewRequest("GET", uuu, nil)
	//if cibError != nil {
	//	b.logger.Errorf(" setAmount 创建http请求错误: %+v.", cibError)
	//	return "", cibError
	//}
	//r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
	//	sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.IBootVersion, cfBundleShortVersion, apptag))
	//r.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	//r.Header.Add(headers.AcceptLanguage, "zh-cn")
	//r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	//r.Header.Add(headers.Referer, urlGoSetAmount)
	//
	//body, cibError = tools.DoHTTP(b.http, r)
	//if cibError != nil {
	//	b.logger.Errorf(" setAmount http操作错误: %+v.", cibError)
	//	return "", cibError
	//}
	//b.logger.Debugf(" setAmount, url: %s, res body: %s.", uuu, body)

	return body, nil
}

func (b *Bank) cardVerify(index string) (*cardVerifyRes, error) {
	query := url.Values{}
	query.Set("cardIndex", index)
	r, err := http.NewRequest("POST", urlCardVerify, strings.NewReader(query.Encode()))
	if err != nil {
		b.logger.Errorf(" cardVerify 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "application/json")
	//r.Header.Add(headers.Referer, mobileAccessHtml)

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" cardVerify http操作错误: %+v.", err)
		return nil, err
	}

	b.logger.Infof(" cardVerify, url: %s, res body: %s.", urlCardVerify, body)

	res := &cardVerifyRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}

	return res, nil
}

func (b *Bank) toAgreement() (string, error) {
	query := url.Values{}
	query.Set("agreementTag", "tiedCard")
	r, err := http.NewRequest("POST", urlToAgreement, strings.NewReader(query.Encode()))
	if err != nil {
		b.logger.Errorf(" toAgreement 创建http请求错误: %+v.", err)
		return "", err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" toAgreement http操作错误: %+v.", err)
		return "", err
	}

	b.logger.Infof(" toAgreement, url: %s, res body: %s.", urlToAgreement, body)

	return body, nil
}

// 又是一个绑卡校验
func (b *Bank) tiedCardCheck() (*tiedCardCheckRes, error) {
	r, err := http.NewRequest("POST", urlTiedCardCheck, nil)
	if err != nil {
		b.logger.Errorf(" tiedCardCheck 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "application/json")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" tiedCardCheck http操作错误: %+v.", err)
		return nil, err
	}
	b.logger.Infof(" tiedCardCheck, url: %s, res body: %s.", urlTiedCardCheck, body)
	res := &tiedCardCheckRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}
	return res, nil
}

// 准备开始加密取款密码的
func (b *Bank) encrypt() (*encryptRes, error) {
	query := url.Values{}
	query.Set("_", strconv.FormatInt(tools.TimestampEx(), 10))
	r, err := http.NewRequest("GET", urlEncrypt+"?"+query.Encode(), nil)
	if err != nil {
		b.logger.Errorf(" encrypt 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.Accept, "application/json")
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" encrypt http操作错误: %+v.", err)
		return nil, err
	}
	b.logger.Infof(" encrypt, url: %s, res body: %s.", urlEncrypt, body)
	res := &encryptRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}
	return res, nil
}

// 检查支付密码是否正确
func (b *Bank) checkPassword() (*cardVerifyRes, error) {
	query := url.Values{}
	query.Set("password", "")
	r, err := http.NewRequest("POST", urlCheckPassword, strings.NewReader(query.Encode()))
	if err != nil {
		b.logger.Errorf(" checkPassword 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "application/json")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" checkPassword http操作错误: %+v.", err)
		return nil, err
	}
	b.logger.Infof(" checkPassword, url: %s, res body: %s.", urlCheckPassword, body)
	res := &cardVerifyRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}
	return res, nil
}

// 发送短信
func (b *Bank) sendValidateCode() (*sendValidateCodeRes, error) {
	query := url.Values{}
	query.Set("type", "unBizSms")
	r, err := http.NewRequest("POST", urlSendValidateCode, strings.NewReader(query.Encode()))
	if err != nil {
		b.logger.Errorf(" sendValidateCode 创建http请求错误: %+v.", err)
		return nil, err
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.Accept, "application/json")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf(" sendValidateCode http操作错误: %+v.", err)
		return nil, err
	}
	b.logger.Infof(" sendValidateCode, url: %s, res body: %s.", urlSendValidateCode, body)
	res := &sendValidateCodeRes{}
	if err := json.Unmarshal([]byte(body), res); err != nil {
		return nil, err
	}
	return res, nil
}

// 验证短信，toSuccess

///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////转账/////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
func (b *Bank) getFrmsNo() (*getFrmsNoRes, error) {
	req := map[string]interface{}{}
	// b.addBaseReq(&req)

	res := getFrmsNoRes{}
	if _, err := b.postData(urlGetFrmsNo, &req, &res); err != nil {
		b.logger.Errorf("getFrmsNo请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) cardSelection(accountIndex int, frmsNo string) (*cardSelectionRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
		"frmsNo":       frmsNo,
	}
	// b.addBaseReq(&req)

	res := cardSelectionRes{}
	if _, err := b.postData(urlCardSelection, &req, &res); err != nil {
		b.logger.Errorf("cardSelection请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) getBankByCardNo(account string) (*getBankByCardNoRes, error) {
	req := map[string]interface{}{
		"acctNo": account,
	}
	//b.addBaseReq(&req)

	res := getBankByCardNoRes{}
	if _, err := b.postData(urlGetBankByCardNo, &req, &res); err != nil {
		b.logger.Errorf("getBankByCardNo请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) canSuperTransfer(bankCode string) (*canSuperTransferRes, error) {
	req := map[string]interface{}{
		"bankCode": bankCode,
	}
	//b.addBaseReq(&req)

	res := canSuperTransferRes{}
	if _, err := b.postData(urlCanSuperTransfer, &req, &res); err != nil {
		b.logger.Errorf("canSuperTransfer请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) cussentAccountQuery() (*cussentAccountQueryRes, error) {
	req := map[string]interface{}{}
	b.addBaseReq(&req)

	res := cussentAccountQueryRes{}
	if _, err := b.postData(urlCussentAccountQuery, &req, &res); err != nil {
		b.logger.Errorf("cussentAccountQuery请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) transferNextStep(frmsNo, account, name, bankCode, bankNo, bankName string) (*transferNextStepRes, error) {
	req := map[string]interface{}{
		"frmsNo":           frmsNo,
		"toAccNo":          account,
		"toAccName":        name,
		"toBankCode":       bankCode,
		"toNativeBankNo":   b.toNativeBankNo,
		"toNativeBankName": b.toNativeBankName,
		"toRtBankNo":       bankNo,
		// "toRtBankName":     bankName,
		// "toCityCode":       b.toCityCode,
		"childFlag": 0,
	}
	// b.addBaseReq(&req)

	res := transferNextStepRes{}
	if _, err := b.postData(urlTransferNextStep, &req, &res); err != nil {
		b.logger.Errorf("transferNextStep请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryAcclmt(accountIndex int) (*queryAcclmtRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
		"transferFlag": 0,
	}
	//b.addBaseReq(&req)

	res := queryAcclmtRes{}
	if _, err := b.postData(urlQueryAcclmt, &req, &res); err != nil {
		b.logger.Errorf("queryAcclmt请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryRemarks() (*queryRemarksRes, error) {
	req := map[string]interface{}{}
	b.addBaseReq(&req)

	res := queryRemarksRes{}
	if _, err := b.postData(urlQueryRemarks, &req, &res); err != nil {
		b.logger.Errorf("queryRemarks请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) todayToTaCount(accountIndex int, account string) (*todayToTaCountRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
		"toAcctNo":     account,
	}
	// b.addBaseReq(&req)

	res := todayToTaCountRes{}
	if _, err := b.postData(urlTodayToTaCount, &req, &res); err != nil {
		b.logger.Errorf("todayToTaCount请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) beforeTransfer(frmsNo, amount, bankNo, bankName, comment string) (*beforeTransferRes, error) {
	if comment == "" {
		comment = "转账"
	}
	req := map[string]interface{}{
		"frmsNo":           frmsNo,
		"amount":           amount,
		"toNativeBankNo":   b.toNativeBankNo,
		"toNativeBankName": b.toNativeBankName,
		"toRtBankNo":       bankNo,
		// "toRtBankName":     bankName,
		// "toCityCode":       b.toCityCode,
		"note":        comment,
		"prisonBreak": "02", // "01" 越狱  "02" 未越狱
	}
	// b.addBaseReq(&req)

	res := beforeTransferRes{}
	if _, err := b.postData(urlBeforeTransfer, &req, &res); err != nil {
		b.logger.Errorf("beforeTransfer请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) queryFrmsSign(accountIndex int) (*queryFrmsSignRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
	}
	// b.addBaseReq(&req)

	res := queryFrmsSignRes{}
	if _, err := b.postData(urlQueryFrmsSign, &req, &res); err != nil {
		b.logger.Errorf("queryFrmsSign请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) confirmTransfer(frmsNo string) (*confirmTransferRes, error) {
	req := map[string]interface{}{
		"frmsNo":       frmsNo,
		"transferMode": 1, // 1 实时到账 2 下一工作日前到账 3 次日提交
	}
	if !b.isSmallBank {
		req["transferMode"] = 1
	} else {
		req["transferMode"] = 2
	}
	// b.addBaseReq(&req)

	res := confirmTransferRes{}
	if _, err := b.postData(urlConfirmTransfer, &req, &res); err != nil {
		b.logger.Errorf("confirmTransfer请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) checkFaceRecognition(frmsNo string, data []byte) (*checkFaceRecognitionRes, error) {
	// 先压缩
	//data = compressImageWithMaxLength(data, 30700)

	faceMD := md5.Sum(data)
	otherData := fmt.Sprintf("%x%s", faceMD, b.aesKey)
	otherStr := ""
	for i := 0; i < len(otherData); i++ {
		if (i & 1) != 0 {
			otherStr += otherData[i : i+1]
		}
	}
	otherStr = otherStr + b.salt
	otherMD := sha1.Sum([]byte(otherStr))
	data = append(data, otherMD[:]...)
	data = append(data, []byte{0xec, 0xb8, 0xff, 0xd9}...)

	// 这个数据由手机端提供
	str := fmt.Sprintf("%ddata:image/jpeg;base64,%s", tools.Timestamp(), "ywLOdLaJekcCePEau15dSgho1FhRpWzH3q8ZJ7KZoasBvhWK4cgaKk/RA1g+DgkM3KOj6DYkeUNcySe/17QYSp9CKHeBJBX8IPzbW0R1wxoemqC1QOg+KP0yaUCAyAiyP1bhA7d1GqVeYu21xrD3h2IQkKB6gC295GQZhhGektfj0ZYJX8LXyDm8Rc6BTZDy1LqOv8V9qpUzxexxixdVBXzORBur8ytg5t2cwwNqclj9UeEL3gzMSYM4D/6j86m8brO/KEbzsrFPFA3s1Z6dX+juN7Nk35xELZth8FLTlGksxRz6rWEw1Hxqmj+BA6NL5Giaqp/X1FJmFIpXSUHopnK3aAg7uD22VOri1pQesS6Eo0qACgQtnLg3T7yHM2VNWROGxGtgVKQkMVHO3E4HstsSEcqgIFfbLf5RqQcRzUjgRlBQ00A+bSNh2ZIArA38jpYX4f3BIWNASVwHUo3zu+rAarDGgQjVX5DjXGHg/QfhiZr0mPMTBCVXHdaJQ0OZyYIXi6F4rpQ5YMi089Hvf4spCSdCWNqlM1K5mTWJ/cCVf5BkBzis0hv5LJ1tAn3eEXubJHDthDNGLMWmP9GvK5HVLrFgz4nchmEFBzukIgZ7uHRmeqPTPN0DPIAgwJhSYjs1ITtgTRqHYTahn+HCMg6sCFBNBNIdZsBzZZDxaA5ffN9qQW382naC7sM0p8tAHM1Jy7Ox6PaGCcIPhdlgk63ija/unbq3/FnHeOl71stpm0ZW/1nsGTVfRUtO18rWIhdCV9Go5b1Zpd5sFmMWPDR0fBhm/PG2zzG8G5baETFlbypmBZuKQnfYI29vz4GEEZ3lJMPvdhtVq8Pox8bhZMPoNA2EYtu7oeO1rrKrwtRaxIfjVMMp5xmWYlcAqIHo01Th1pUdz4j8F4Qs+rD6Hzxrjj8sJvqojOV8xoY/eE+PIGiH5VQEcZFMUhDmDnYG/WT5w7hS6CEEni/QhvaCUYqdiGArlv7x547QzvJVTIlWT/qcCtU5kOAWqpvEM/D6fkFavAvjfrfunn1cWNKSsFJ2mZASf+b7x0TUrPeO53ddACBZu4tmuwNpXZwGsLymQq2OaSPzZa4QYE1aw5dGmJoV6SSkiWriQOYTqzouOmsCK2ewMSX13NnCUDCiC8CGOJi76cMPXzkObyLtFY2UOPJXbTVqG9fRlsIK+8K19zazzpGPhGGC4yie0dF7a5IWZZlVr1Q9VVYRtKUV8nxCSRvigVBTGNC6PCu7HBs92r2R8+Nqusm9mBawFFF21x45ZVysm8CiFT4twKA8MlHBkpndlYPCoQPDmKyiOpqdwpwP0YvWJil1XFNeb2y5B1Hp+8ca73sofZ9z2SujtPNTD7ZlNWr+FznBfYC1lNBTPNc+vFY5mPKHMhIzQJccWHlLWxsZWyJmCBhxzVQ7oJqeEq7Dw8uhGaMiJSnoz3+SVRkOa1WEJIcn1byPtM9wZBNo3VAEMleqOtrJORpanBAondeYI/59hxkb0jCcbYxVVvsmtgKDg+GJd4eFFfzM2kog1tajPZosuClz4dCVDTJzKGdz61hoylkuhzJSjkWQEfPlpTn0haBGaAjloqH9vcRQQKhWFZmelCWntoJWPvP62iEb8siDY3i0WpAR/zVPSqMDkMFo8zSSvpC5dQ4ZFLIPCaq8GFMDFIAmWvzi2GnOm835QH8k2CwN5cBlmdOZ5MLw6UORmta/Ee55EZ0Pe9aWKp2CAqCZ6cpXtARIX2EZ2wRo/9JH0XldwGWU15B9nLqaapYQ4NvDhDu3wrXysWi7Nv4ATmcIAnqXYOJQk/gmHZLFJAcPmgxYPC/APLmrFenA/5hPIefNc6TgpjnVXE8xSPVJGbyflBHwNKVpVJfaE3zoR0YA0+WwVHPAbpVGvcBIibW/nt98pzKopVEfGt9Z+27sUj3TrYPNV3RHotgBocAVZug2dkzuCZ8BzWSskNicXl4ZNoFozUfM/Cm0HL9zoCGs4sHRd3qG+x9x9EBVnuMVU3AhimcSPrQrwA6f+I687aEmfAbTLebHiDLMybQtF+bpwMPNzxqwNNwJaow57GSS5JRWFsR1QhzFwJwbg1mpPWZZ2CXrds0ZdQz04u+ZtzuMqNqsdbxm/pwsIudJ5wZGDB7dWtSigxLxLQoPMwvJQ9u7P+WVXxPbxfbZi65baVQEH8Mc7zbl76qI7O2Ffl7lYH4wqoE/xb2m/NWEgVwFaYeTj2JZ7o2lyGLmHySfvAbPvXA1GW5uxXEoAF2ol85RRYYVoQBh3gamtkAzlyN3mCrBPVlwC7W7zhe2aqyLh9pNsR/1be1QtmqxHRkVZ/hTXz9iJVRVVvocWqiOqLINmJgBQyLG7rWneBvlybgRDpJk111tW/w9Jdk6Lrp5ZdIA0UIMcv/8e0aCl5V74FUuMcgx0EuqJH06c992IKXEgZz5xpVLUKUsyHTeupQ7ngAFTDfSye60kPxjnqmIlcKLzVQ0h2brhnMwuDc2E7A0ZHSX7fu/N3U0iRyDodXr8KPXqFgYCziOQRc9qk23lcpXmu7Otg95v/OAFj7oGKoFPY+M4BzA2M/nxawEwr0ntGau1Qg4I0tRr04JGpJnUa/Tcvn7lkfC/FmnTvcXNnxw3RJZLZCYTnenNRh/bFo/W6lXS0D79nbFWzGm+pi902kjFt4RIjcxAaiNrLnWCV28kCiO5iksD8jCO8ZCbOm6mZo2WkBeZsTwX1AO5pqWVhY/7EZImThY0ah+3KAZa7jB0CSXWi7KgeHPXnaRpTshsZdtEqj5kOBnFm/d2CMk/nHIxCmPw/+uaN/0ISqVWKMIEUjrdS1RYeXGv3sIfSIoUnw5mz6K6jMg8IK9uUgz7kLTGZVsRrxFshSkjqhuzJkZLtemYmBwsRCNLw8iYLpCpQgNBTFosKdcf3r/RURP1QdACJjdnyGZPjcqjS92gDsRNiG0TsDL7CJW00+SBr7/Oqc4OCGfLObEXpca/avskgvXHSnPSaNZy6mkTyzL6brN7qCJdXtkEHPLUDUFJ3iadcn67TSbVrOV+fghUw8jHws85b0K8sQL41jiJe2dxvgoqKhjCglXnsFBy5hbjFOvrx+AsF6yQSIPl5gQXskZY8P4dHD8vu5/g1GJ0RAOP2Kv5SF1dUHjRa1pUK9MrGsTYkaujJrWEGTKPVwhg2HDY0SpEvyn6nKlJ0DBIKBP+9xZ5H/tJr3n7G0nIPEKhvh/sElONCsTkzfJr6KY7232uOZ2Mff8zQFo7zx6y4OGkrHJIHj/2gEg4hHupUlRzxAwxh5S7MTrT06wcqljOYOdlPMZiaFclgzJM7u+gcI76MVX5F8stBNmCRyjB8UiyWtmCA3l4NksjEyc6/4NjXvkAa5tMyBWtANjTM6D7M5avkYD6yS9p4YyTngzLCNbGUkPMymmV0kzEdUQnaPCA0M9YWkwJlKbfnygRWu5uvvndVHaT+6PeHGeWIo40vKyFhca4SVw+okOE3JffkKOvRQwY/tA/BVRpoikKpHP7+qAZyFIp6Zod/6FHUab0+tP6yYM0FOjzPRZz1UaH6CbSoL4YkSbqgC8HuWmkoFyDeO6comXySbe5Rqbyf96C5AMobRPBifMfAS6ku01tyhuqZpMkNoeF71JPBVrG3FEPhx75s+8CSkQ19WuRy+RxgATbXRTCukhPuGOfJylntH4aV2JEhoMSV7QUHovG7JEK2og/ZNQYICEc/q8a3DQTM0meo4yZAmJmvXKvseB5aCp148X7ZG0oQN0SjpYjOxRQOQtBPolgT8TZg7oZUeXBfZajN2BISEtP7EsM54xE3zmOULQ4ivO/l9naL6ZJvumyVA+fuWjPWIIZYSsR8D539Ye6Q9Q0zgRXH8qeY4aUusMvAa8Ls3Qm+znLO2JBcBjHceQjyK8Cl5XzWuDKLNNkw23iits90u7mB2TE2dtMZcVLKFwTouY5sdRqS4gpPdYssGn9ONkguSw7tDIZNNDOTAuVTy9DbeOwBQqHvr2eYQSWBS5Goo+L0bb0h8fvUnKRLo8RuEA3v+QuGQuNqCInghceFSb+q4bXCWdzlVwvdSfKswq1WjLJRVCxo4qu19A+urT+MIuMDlhObk2SJttErzjiZ2RDAA9HUaEd3EdwVcJpHQ2a3iH6ZFl+WZRxymsHJVo0ZL3WI5KKBi7HNoEK+uuoAF9x02P9d65cIBh/lto3m5K0vlbSuO47b/lpIQbCzELvhrHMocHvY0MV9Tzn1tLsL0SOIU8R2nVLuy0gHxRk0FykgEjhcfV9pGsPX47sQijPUk9r/X0kXY7fQ2FcT989UCqGHyENuq9VYr+rQF2f3QV6Xkn+vX35qIf4RX3JECqrdRvjnSdg1IKrG5U4p2ziJcj/kKtkUTnAvYDSaHkZu0xnT5lgOjk6HbVn8OqibVVGhzJmc+HPv2Fsx98GTLP85LEtsDDdcVHx5jg5t1nkPeA2SV9N/6RTq9EF/nqOV/YZTNLdJ1Hz+VAIKoFsMXv/8sB0a5xwj4p5JZu4EX8kw7fxRbWtzPKBttLSjHhA0+NWmfIxY+rom+fIc+h+45DBWWzmi6KeyA+iUVzHTjqqpyquOCnemDMd6NmVhQ37ZWavMIQhhhaHYWOSxOFYndDF2w1XGnyzQLnyEjhftYfh9yfBT/TDFnFl4TwnOzA9OIfJQFdbHGXWRhS1eHBOrdSndYjPsIg2Rr5YxLczjNiCg5mFXDhRrCdn/R268GdK+eGS5afi8Wc4sKqorG/3B1SScdVZFGZDKtB3PByBDUUnZBT780/NZchPjaeZkzAd1iFWbgLAHdt+d6oHzBdJldT3ns0sVokenQVxvHsNh5bD6Hsu6TG+ZdNjlPaayOhNWHl9yQGOsNOJZlEPLaiM8/SyafEHuL9eZzfC+wuQVJDDgfzsvA6brWupgxRWB8/VFHSZt6YUzY3ccI2EeRzggpNvSWNa9lwLTM/eIZRcK8mgXJRXTGeY7ml/rBVmy0yAvxR3pwOkfkvrFf0SW2tJ+CI4SyV2yIHmYcZ7gIuEMo27Bkzd1Vfd3QnlKFaIjQoEeVR/09ZuCmVLHReSoP/S7eM0qY7kY4iiOHdl+J4shMwfV6McjXyMJvTJp2nz1EFkvD8sFvHv20h9Vq3DNH3rhL/1EowBklTZx2dhoZn0YD0BMgz4yj1mZ10kX5EGV81TLgdPQFEdJnU3TJyFrue0HaKOf3UAiBBzPPogp9VEws4zEd3xbtl8wKfHRATVhK07QRzfCLWdveWguhe3oVA6KUN34OU4fodgMr3ke3wXX7fU04HdJwWmqPXetuHtK5KlRN9FZAOw75+odOFEOgw88eNqvb2t182qkAicEnMAQcB9ead1ebQfwYjocqEV+fEXzJiY1gnKounQ+F3CbAeiVoDSbTQJIy8JmNzGZzJGI53RdHfYKtcLxfM9C1RwaeV27v8BB2vuzmgyQCb9gQN1RQTSAm7f5CaiT/V4aKNrx8NfLeuWU6i9AX6arYn2OTcrpK2KyZRklVQmx18yOPvycrbRVDkn69Fb7/HyiTXi33sl26iNqtJnQP6B3FdlqQNTwUM2usCFqezYrXhlsPBE+QdJ7CdxShBnaeNJqILDp4eH3q/SD2vII4jaGf2CzYof43F1g/HmpNRtVcHnudQZrP/9MCGVzIHeO+TeN2MXW6UCi/Rs5BFmQkhuLKEH0XmGVhNPEX843gY0TadgImrHzuDUFTdh8uuzTs8jiV3FEzYVsxVnxUZJSS7wqcR0hrUj/v4jcoYUTdwjh3+UM2gHWIeFx1U6WfPlJ8RZEtYaAlx3qjsZgish6PZQifKmzuQnCimnfHk1EfNyG6l1bq9zc1BNdpzWz5utUjpxNedh2NpA47keYBGPZBQymCaAbGC6RItairbNYsiBniRTE2UU3u+AgSDRkdMWGiJ5KTG2Yc6d7/Kswxo7E+pn0YIdoo1EqL7DHJTLKHhvnHEYNiEj1bCeyAv8iByDPgrFXDdNCCqyAABYuN1BaNDxIGOCTEG0vAYmSH3Lv22zDaXLPlfM+AD2I7HD5+JNS0hQdni9J8/Pgchj4gbtOT+/ySaljF6KVhLdVL6VPgoXi0BRf+nL6hN79EJHDHMMzm5tOwfE2ESP4vjVdavYl5NkQdAR3GZGsQYEDNZSS0jMWA526TvNuce2oUStfSBLNljghJSqCMWSmaI5jBsTBQ1ZA4Ztn95pslYwsYXCQcfU2C+r0NHHgKtuq5pZ4Lhx56sIj/UVcho2jrCZO8qXLGIueowqCFIyERb9YhC6tfAfuivOL1GKepbE4LYD/7aOOAAfqVCWaeyGA1ohTqNCSxBTMvgSnDtmDAnXUCydGHvzQdMvxHaXs5wsURgvPM58cdMtIBOmmuem2g6cqx/geWxr/aR7d5CErHQbtQXDTDNRdebhAI8bycGhBQMR4+EIAQyxb1zzNIGm7CbVQjhdSJvCprppDCEFj8qWgozrPM+NjsbcQRt4URD2SxJGxNasFMVL4CRbvLIGpQyd0NmDiqc06LksR0gt1dqoZctUV/yyXWP6DtL8dEqOjNG79eQs6gSRaQfHLFWrYgzQKrOuLrzmaFl8GWSQHxcMwdXZvQugNxAe8c3y/aW3J8vjOjy/4CvtpnndB8o1yf50szV0eoJ/mr6JPbiBF6zDOaHa8RPia8bUdfZmmF2vHcL6xpZGUrySPf8y86dJuHKoMqiyXCstPnJCCj/+R6ELj7I4FIUxF13Kylir/Hq7W6j97iJGTvACVWj82+WSqScGRcKW0YDtlx3QdUrAL8CwQEx3OZgWdD2xMwjjOp9HnZtvipztWz1H/HPCDEuKN0q2esjliL9Ey474QyGy59tScvdUnJnX5wjfd0qvrFlSU/jQurjEE/sAXKWaFlvq+eEKz9KRyewOwMQUoudRXOpMegt3usHt7IfvEJUQNp+V+5AafsbUrxjvwq42Nmb7Im17q+mtlq09fSaeVQg2WijoHv9osDE1bW1uphBibb9/Eyhc6AF220WlJQQ9YiRORGic0CZDeH/gZP3bBT1NuLI+j01RL9RpEN+LfhTm1940cerc+Ed0ED78hf7UXrTWC8o6uAXgWZt2HwkNo4oiKbhmrDvoCaQZ0T/Pn1IJ/ZEcxQ9srpxu6enTGQLqgsVyOYvM0bA+c98ny8ED3ewalJd01mywY0oLcYrDAA5WwJ/+q9hIIeUNmm4Fk0DZ5Tf9pFVkYlcjNKKZjdjmBINcUF/UPkbthOC8upJi35m1oEAmNgk7sFmbYm6DDIk0snd47Hjzip/BB3Liau/xOq+vVZBefcrQp4ClwKQdPhetkUrb6TURSaG01DzYKpEsHSxf1e7k28ayve9pTeKsQX31+sRaAJ00L3O9Ifh3HJhseVv7SQokxQ1u4nK1QnDc5fcVBps5NygjoJpLHeOvwtkbpB/LChQDkOENstPEBUKDNqtH+WvzL5cd5sutLm+mv6vqzBrDhik4Aa6J4txy2EkFWTjVP62UXi9YrpVa9WOCmAlERiBVg+3edizH7CeEyif0aAy1Y33vds5btzTkuO9O1TjKB9EZq4xzl7hZNtEbIVI6HXNpLKTZL9q3Is1zBnY9GuJGQ8o7uuFJdJ26zatV6BSizCW5HhgaXRm9Q3k3763LgrT82NQTAReml1M2EQYwSnYrZLC6pX9wVZ0MBcfEoFdrlGmg7gjBurEyPPfG4e6B7MI6LjWqUl4d6R9uwWklgHF8yPVdSukt06y+twGqP8U+/OvNfDp1WiDgRr5+lWj+kGtzSBQlSfJZjiXJG5U+QD/heAwSjjyXu5yJW6MUbMZEFjsgnY61lJwuQbQG216AfJeBM9OeKSwomOVhay1ot4cKHDgw9JUqP4OenHW2m6ykC36jXJ76EzeE09xbAmDEFji1XNly6j/JBHCauRZ7hfMyuBV0mPp8/S4/Q8Wm5x+z43GXvfvlhlrdJfNbnuOwlZYtGrGYET50450INL4huCzclo8bS8IdFfYMR19n026MSwuezJU2sa+g6piR0JfiSNIhPVybSENQxdSEoehxax8OZeHnM2DU/udR12ofVXfKkED1dC/sDE3AKc469sAl4DMKOdzMsFODvi/EzRD5dRiE2BTSEix26qNcpjM5GbymirdJwc38HGdjda7bdsUlWC0GRbu26OYkRKerWLOXnqAYpgJxjK0OEjgbi821qPffp/Z/7AiXYXjSSGHP5tidJWYyUd+pvVo++NTE82Q8a8Ofdw4GEIFUk7gjyCPKXBJ91KuGxdEvVgn1QBmpM6ijPLwJUGK3hGrCxq5AYiY0x/0Vo5cBlg7E3oRCOnNochCGmrAUl+eY1PW8rnrh5mK70sMORtqakSIf1wBv9vpGrBcvSwkHSwn6iTsa5OI64XjvtRvrtdfkH6qWGS+nHItJs7/3nj1xWue4zuCRBs9PzA9ui51spRFdeq9gUiHF4PCABkVygIOc1dNjrLndnEMXUNvIisf7IsNpkNsBSvDy3BuGjk/ynII8rDtNslUqA64afzRtRY3txVemL7BgV6q7RU+aiVa3EV/wNVNmC/+ZPO4nB47v7OSgIWP7UfoNGnG1fy81mhvTkOl6k9jxJzq/O/FfYA0c4Fbf9qpubOXoDUmRPbyfYroIsrNHDCWIQdRthmRMt7RdV1sPbeGNEJiJXuWz7othtWNyjQL0iw15rthlbQZ9OTTgqkmmNyE2u7pxdej5zIxKzudjx6UkE51n9NUCurB8rIPT9/kSzctRjs/ABk4vOoRBMEnlZdeFFmGBtufmLJek95/JveeaVS/uqwX5Is82T/hKTHmbq6EHhpef4/I3fwPTk4nlPmtwqPV2d2RkjTBF7oYjTDeqGCQDK0cijqKZ61xnJoU9+LgFjrnl34uLEEhqsaxNEVelM+/w8SnzdQ0VlSr4AOZnIzox1uGFCsS5KQCzPsVGQjL+CkgeJpQXWHENW7GEWIJHcvXIB5X+ermrC1FFv2h+kiDQxkLJrPO3RXuOGqfJcgPzfJmEs4arV8x1I+jx93RXKxCB7EFExXLINMRWk92Fs9n5dhHVkZugWuc7Nv8MQDqeJ0sy+J01kEGvx4bf9ypGmWZM1Yk+ylR0mApUws2deerm7Kl7YmGRfUQWu8M/kv9nCwcQMk21XM/CNnuSdnui9IHOHXMBqNGue03Qr3r0aNxaYh0ARAstt9eOFH2FlZoRL+yHKqpPMB2CgBjKBzswrQTk2vJC6KbV8V9guJmtxs0A2J5yBUfbe5WeBeWHQoM2yuAwmrJBl6sYhj+/JDz8k34dP+T6Dz0EUnCVyaUCLLkIrHik6Dp6gk6z/fc6jMq1Xt1R2AoQVBBb743m40bcyOILi4MCS0iAfw2jvBy2XIcCV9Cid/lzGMlbmi0xzD0/aAnOXeqGOySmx7QVp+8AapBU8o2Mn2pqCqZ/RtRLXLVIbpMgddx0mYTtGR946RbDjMebJ+ILMEzb8TLKLVcIiBhNYSvLiiLEBgecyRdPUQHCjC4CAYPWaeYE99ZS0xfEPB3mFgVwsbUn2srLzaddK2+t1520ZEpDnmafHhZJ/laiClRK7OPJQr9wwU6QjKcA85zD9SxzKAJI9bUJLvTNTZSnnl2QS2rCVn/tdW+UboTUDDPWjFJCNYcqQ4okwdlU8xoZSfZlN4oSKOSwpn6EhaC4CIlI84z4FZ7nUqPxezJdswmKbddL+iZIYd/twmxlqwRUkfhVEe1ajDZz3WFsy4mRKJICKovPXm1OPi2NPLFKhMO2ioCf1ruPd5uaEwDS0x+jGkInCoWor/Fh9X7q9a0mAlZZ5AOZvNLIh6VD/IFr1g5h937tZsKEgm9aK4DeTo9cI0l+uq1rf6FgWFKQ06pOoOhPXCbGcB3/91wmM1G8bo28M8lN7QMYZphsqGVu1vKTkZ8+40rAiNbbYiRuZjurdNZpJqERfOEA+dX65G9TIY2qK27koMRD4JN3W2lKRQ9kog6NQKccTsDdXoBWXyaBMqmFM6XVPzmJdiBOYFP6zs/d3Otu2UhHlSKs8fleGF1Tt2sYmefPrQfl8CKBeVUtyRNRwMUKKnmHHO5HwMrD8gfQEG4HIpYIDkj89UtzdQjz1IQW82aHsiHIU/6O7T92ZXzuO+O4c+3kO4qsyis035YjoGnBeUjJAWsVYKhP2wnyTMa8CUXC6rlExEg15euWdzFmoeqUOvdstkEtovXDge5FN2zLE0+UlqITSul4ma6WygoT3lmHSUvWUNdqO/ia1c2mflvHroag4e9it06CzCpLlNaDZGWDBRRyakA1xHoQWH/ZJMDpnxkqNGSs3rITWsXLC2O3qFNPnKES4K2k+zUNsZscLwc66BOBnc//kUn8Dl3uxe1gHnwdRMiG0gMeFnC0T83+xQDUhtzYokWiKUR/J5gnH547ihSUQyOG7uK0D5jsR/vUBzCmVVQvCs6nKFxYc7Z3yjJJE9MuFVRZdnYLEI50vF26a64a91zrLTCxvedZ5rHcTK/2+yrsloQqQOuCtyCn/RmYs4j6BznAlP0tbHFVzhHTRVQx+brtUWiV6Lpo/tG/gHLU19S9KF+uVc2e50WjdfAVvRIJonYZjrV9DwNzi6N6OZqZ+e4Q5dr+jJzEsniiNuW7kPMv6/FkCialfESgPmcVgV88qOJoxzUFN+1TID5SJ7muttnBcZvrp2lQRnPirafdvBWJCM3TE1Tjjo59VWQhgOAtvedx712ChRTTyHGCQmP8Zs2XgkcWBuYVQfwibTV6EugVjSBSbXbZyVgrfoJMhNqF67R/CHsgyB5rasLPDdlfPG8fo+wnP8QjM4fzgpWDbc84S9+PQYEDzPIONs3AizgVxkrtgbZvvI4P/5xMHwvhvsrY8ep6v9E+yZCpEKKiFmvHeUBoYEoE+ycxw9K/5ixhphSBxVbgQsk/QN7GazEKLkCkjBDJ/9UstTmEkylTy9Lms0nJ7V0iOyptu+ddjNPP0eM2IAh3koZ4hQDkDfjjIfMtb04sWhbvs8rYGcv4/eAld2x556iU8+KJqJiWmhgAhipPqbcprkJt5moe0RCMIk+I/p0jVBKxkiP7hpDfjMLfUQdYJLH69kAdBDekpqYulOpukKqAatfPrGx5uJEp6cmTmlYzVSQlga/OMJJ3UrSljEYHFae8czQgTarCiL5S5swIlRgk6Zi9bVeMQUd1XldMbGDadQs0R150yQKVvrorOndWms6UZ5NdUSiTHGxV+U/A2lKE4VyDWvHTuUtW22LwWEICnR6ODCovUk/YerAjJ9JIDh9BkoxrPp4dY+Kj836uwhrPsKGtThq5vnxfLNh1/3KiGsAxZcTAOvlwsoof0kxLotCjk12EABaIaTibrmZJ4ydWllsfr4gljnurXuk2r8VDSvInF2DttazqO8c3l+6wcapngM0KT1dc6xUaZ9XtmxK1vMI98uz/pruf4hJfj1JF3sMVbLfXCeyux5GSZ3lN8tZbHyfmLlovGuSPwACnINSIMwBpZNrbJMZqOahe2tQB0xpDLBJe9T3DXm/wEBLepMFJBPChupWMzFMsRVzD20NXA5i0LwznREPKVlL35ZHn0NdtY0ESZ5fqDzUfHplooM0JdtdJ/9wlEtcjQLc54Jb1z3lXZ//NrVWeJdNj3pClhHJSkm3bVoyQyu1FuFHF+Hz50VqJ7OSg6SygVVTkl7yfMrV/FkxgfrpQRCqbfVPQZeqmDnMr2/zXKXA0hG7I5yAWtVuOedM5ExBh/5ND4zIv217b7RqviahRD/j/SxdajGFyWu9EF2yW3NObeRNiI2vs7eaulVXbfN7WMYFvVA+ljGJu5vkijpLIEfZfXHIoDyikLL8VPMSBXJsw9RZg/qxn2cLgAn8Bvpo29Gdjw4ZvpgD+zIB5XZrluZUqy9y4oI5nbCGm6W34qJiWXTmcVftoZYcmyUj4eP4YUwPitN7ZxnKfztTYeMYyDm8hTFBMl4j16aII/4RI0csjePrL67IlzR9L37x2nwGLP581ovWuzTfM835s/+nwKbibpIge+BrfFsPlJKKPFTfm9qhc+R0i2rEI6CB8Q9ocFM7TBbervYL4lg++KswmCbmCTENSUP6+vnL3B46bMenPg9PPv98Dky/ySxztqoYgE0nQLvJ5h9RTrYroJ1Tak0lUKqkpW7HFBrmNj1PEtoFFvJ2sFLkJIdIhYiHeqvqhRaQ9G4/7tnTl8xBRRsUwPpx0iLMBPW3sebKS7E1HHmwtN0Qa/7swZvsXg/AeYqaJiy7j2rrkbUHFhnTo1oVpShsUmIy9mKMicT8zbSZo3lGneRyFqUaeb/9cyEj78kQTRgjxMY5zhqc05Gpj/xNi4u4rsHTWJlp/5ekwaSwmjmuvnoxlGQo5y6KpBlPGuLe8UJ8qqfVN19srAk1rDIMmop2YptFfg+k4IUVvE2Iii/EXe8IZ7qZ0fOKDRaG4Si4PYFedc3tB7jBt7Dr6VdktXmHKKohrWXZhTXejETnEtx+nErkRZwzrj7CI9e8e9Rm/uQEjU+AKN97A/Pziza+SFPWhVOEwZC1zjxWZOfj9ujMbbxrFKz6fNO4vSk/P29q1L/vXlHaGLy7U5J1eSYovpWuy4CyWA1PFLQ8hmcG/1NJeP3fKsyjjHU16Zod103j6XaMGDjMIf0zyjkCOy4kbbmtmcCIsfguL2T2SMaAq8ZOWDTcJKY3e/b0PFy9KnuvE2wMJ8uQKqzgp4+70MsW2Q+l+E24m9Th4zqF5N1SZXu3puS0aZ+0kFBjy84pCDGMHMmEHt6IpD9Gk+k7DdTxNnyx91haDkQmL30UMxjEfesi/j0wzmblAyl2HG93YmClAqPNUojH7ufZR2f6WFjoVGhWgGtQUMJ2wX2LH4+9ud0lWFZJTZVNixIgaSycD7M0oEtoAIa2cBEXhYV77N15Y5TAuTBKOpxaSQx2/34g4KS6nP/9hnNnW+Y8BMKtRWCKpWubyq3hRv5bVtm3pSuiFmoCE1LCRu76nXr/4pJygVDRb5o4rj6Wq2i+3GPwYfbfU1XQtSzyNfBGP+4rp3OJ+35RLvjp7UOQOsKJ7YnbTe+Wd4lZtLi1oGGbeZW8RR2mtali+UCgwBnF/MAdwvIj1W/hr2qEjpzTFxe5JgPRgSQ6RghuEXxPR6D8n3TivTOTM31UtCm6Eld5FpuFFJ3R0g3S1MeYIU8wG7M0hDrgLniZ6cAJwREh2xUfZI9+GjGy7Z7gWP4j+Z4mc3e1cI3avzhlWedp4a5lKVMcnfU3mR1Uf85YGobPilaWQPaH1zVl7HBjNdXvGVu1AAC+vESRj6ynd7bp/lp0mXZ4cvwXjAJpTSR7CosICq+/ax6kKTWnYK2TbqIQW+LNQsHr3VxZ4v+9Jns5NkYOmvn4aijV52Y5IZMCTanz/UNuYh2OJwC0aJ55NRqWqKfVSnZ57LpkjckiHVbTQzPPF41PTwU3IudAPCchXpHmDwMrK51jGyhMRtA++ZgHbRHsEAYg8pvXfhm/lG7pPo3lYJyc5aEuoz2iZch6lw9R7+8z71KZq3Goeh7Rmf6zhP2RjJXcU6gfigkGh31AmLMlObiufRn0EKSAP5FYEzbLLudqNbgqtABu2LhInY3ifVErTv2SivfYfzpaELWzmxzD21f0S+pA3SbgKC3oTDL0SfjgDarnUEr2ZkiWB9ert05vMRHcVVlhRJ/KJGcwTzCLD3XwOgNgUytI0chvxqykvoJUH74lR8Yv5C4Js38ZTWH/sR1FBGD55i2CdP8eBiCUZwp/Q2RFUtXkbXAh0gNKKEzolLVBrLapJQgJhOBAOE2bWkOvfYSxAJgS3dc8dvENfNEuq5xOCXwdkzYFi4CqDQeWW8nO319shojhsqLRzx2xRZUJ3XIu09A7B0+dWgFrTXqTGl5HkX8ya9prOq+HPIK5hFpnZfdUMymo89zSyMRxjS6CnLrPfDgXbWlG9d4xF0ItjkpgBWOzQv1qatbq73FptRo5iwzOMROWnd2PpCUqXapQ0h/eKgbT5PAwfU21I9XFVW69p0sz7hOFuEAVhsxQBt4IdAQDfQCan4rBs7ohmCB9OfhLS5Nw98DyCaM5MwMvLbAurl3LU3W9f1abwpmU7ll0Vy8N3FUpVMITXME/O0Ey7nIOlXVkt0+GJRloujHQ7LEfrCCZsJZr7azHY/I93ijlgmLzhoXT8AcVPDDztKZ4Teamp+fH7AoHUaNdvD3D3pEsn6JIdqBL47bA/tpHxiyRCpRrVwhh+iOPwyFGr7pjrRKHkfwlNmJNwuocvn3xIJr6ZmI2YXkT5y7GBXLl8LRMvaNz2vSL+96AyJsCGl3dNRMDjjSFidA5qtnuAdV9fsOhlHPRtMK5/AmOiScIlcDVz7CMU8RQZoXXKkGM/jdwltZuYoqtuqhP6y+zMq/EO3yrCszGk06SsEaRbnhItfsCLUAmvkziweBtgd5sHc/KNGouKmxcokXupfG83aYvGd9E8qdTM99pxmhlWUa5lSveepRUDWFk2ccL9C5jNqgVrMSV0UMS/V0HUwv+Z+N1/S9S07sZZSBQjH5+4VV98c1VG62YbTjoS3c+UFVYz+s0VaecINJ//moGDCNkYx6eYpqng3H6Mn+Hh7ia6jmxjxz/Sb7RRs/qW59HFOn5R6/M11321DWE4Q8f8jZuAYfjn9U81kc+AIvdKtW2+DfavjHTZDE0v3fWjJ+sF37+RZkkzpWCWc8UnBWgVThIDYRSAHX86ofLdiJhLug5+nbTsUkUaSixdnTLZhvEdXJshmEkMB9ZwZE+3Ry7JyFbpGM5u+ak5EMuAJ1YUeDqkHwGYYCTul8muOfiq7V7DYVVtmdZO8/vjB4Q1r2mNzMVzo4cOumWT7h8vPMDM9RdQLwk/bMbUXC+0pKqem8LofBYHG963Iu0Dqs/+p5J068L6QYzh0Tesx66XN9ntfJkPDJgPhsu6El50Qb/155bq/qzF8Geaaxifgxf3P/Ppg+u0WGvLcD4t1mvAkZ9HycQbEt1hhbwLO7fJzqUNGxzfoPFRI3a7M7h2e1/eYD7yleEZ9GHBpsNvz7hZIzn6jkjnC+ubUoXs8asDq30fa/m8jgoXz24LPR4FDusN9lFnkGiX7XEqMOJRBUxF4/gzdzRBa2Bjih2N44YHibvRi/s1bRhm6nYzSDszN30eVTB0XHQuwRdd5VepKUvfdH6SxMPf+954UYq7Z+xsG/dWeN30Mz9gZfcHNeUqVhxtKfQvartQb7Yss28BsMU9jdT0RX4He7sNZuSj85JJ024oWg91FMEUQgvVcGiABaXVdxMRL/qt65mvlSNv7PoIf90YOgbHGtwyKTyHYxcNycdfRXXQIFphINzSfZ6Z74Z+iyt60Khfmxawub1ISFKBL0BaS9kJ1ZxT0JsBperpGqrrLzl1+7ZHShbn2PEILDwyM6kryP615tt6FeZzJwDUTzukVny26bMzNE4ESRFkOvgIa21AR8jSLGEHKCrettCkjcc4ch+CasmtgRJO8IR6tzzSm7INKo0DtCvpQIpVMED49MSrTKh8PZ95FVq6HypRWkOhB5XavDTxc0QcMHA5qciMEFB0oBguK2q2LCeehPV9rDJM18K6ydA8eT2l6B6lksAKnccCw7QRxqJHVqtMifn5qVvBVufy7UFiy9dNAmUkdNsUiSNf7lklmyKSDaDxDe38gGgGrvHQ9+8Rmh6W4CHbskTM7qYSVPb8ZrLZMr5L3MAeasN2MYUU2IqVzXAE3POLqAcpFCO/Avz4VOgbYf3Z2ZnPPdFX4s2Mc777RIUZ2hVZ8giEIMM4zCAG1HZeraHmQxBg8lJqbrRtC3O9xC19Qne6m9sXtYPrXkBNZenmkzZrcGruylW2btgch2ztY6gXyhpH6sMuiNRmBZifZ3iBnhZEnbQFA41IIQ316SzOxApwafXYslDLJvm++R0Dq2PjwhLsbsfT+aqTGYT9H5dgXYmEKdsjCkkY4eA7PH+l2d91HyCrft7jn1mMIN3KPXG78ImonM1kdoXYIkwa7R+MPOd/rx0q8GYaGiaAfMegXC//OPqxRWaRouZIJYDCudSa9sxVPcqc+AHyNLdDUCu6ABljVToeMbWFpxr6YYBvks0hLBNYQ8ir1FJYFhVF70Mktqo+wnwFdiy3Wo+ACllKgp2FUAEYgznJ8Z/MXiNd8lnCbXbHwq1vgJ50v9r/PT19QKFtjACfLzi8VOA7PSN7prQDjJ8GNtvllHt4I3dGzgCEfcHw5MTxxfjdebzH4aaAeVFa3gFlW2P6fR6nRsNS88j0f6nze0xe3TIv1LyzzxuXgXAUatAX/Z6LW4WPKGHW3MkFaMp1lu/i+2GfDwekld6qUX76I/9IWATFnSofZPaex71y5+xRwIvaUZLpIIBQkWtVcGkA5ouuwHyiS3BpovgYQ4/3NNWMdmXhV9c83UmEbAop1QVLSdisApXxbF9FaIvQrUsN1XZKBUeVq2uwE/NVCPrR5ByGXPcmxyKr6TUZ6fuGn7QN4oZAoYskcHfazE6e0P3yao4p5T6fV6YU3EEBSma1n8vtYewdEF3ovVVONJr5v+O1813kLP+WUIB6HSI96EMDRXE6sVCuO0YpO/xYegtVI3zZBalvFSlsPcSO7y3yXDOxnQsc81xqyZPqzvSgDscoW9hGaYGYLkPBYoX/eLr6c5CNH0l6LnTrhu4bE/qqsMXJE8W8xA+UysI3Ej5Lp3v5jlcsBio9i1EM7nLPqPVSwObfijkD86Jn5xqzzKJcydeUI4LAJlbmQfLrI4Zji5MnmZMqC5LUVzWcoJasRsMxLZ3taTuPRSZeWM/rDBNXyxkhwKmHmAZCgn45tTseHMowvPPC0wwzv1/HcJQUO0hMPsGRazq1zD+nAJ4GDP/u/8nfpbO00THB/OzOYUuE5pk/I1qWGGhpeAd307g9ufb8Fvrr4vsa/fXhXMj4Cw2pTjhfcdDrtT5gY8c6KuKBt6bSanUUtbkSq1xY3S1sLGx5nK5YZgkc3IwH7kAhlB2Y6xVrYVP3+tna0+MtcUq6MMRPsKv7O8p4Bxj60iuqKPdX4aPWk02cu10XJSoE7wYw8sBgA7D17eaovaMBxBXC2aQaHLdUt+9ttpxztfyFQRknyDm5FiwEuR3Vrwvz6wFTFHgfYZVm8PcaGMsf7ilcy/TW4LU6asfQlJ7b1erRIaYidQjuuyaTjiv4EYilVagDLFfXimEaxq0yU394a94vxG6eRQamyZnr5YAxaBTuVIcf5Ijm/lacyLmANysLr/YUvGjaw48h8KUZjkpr3qOz9dUmztCYU05cVO3Z7owd+h+aXXIseJrPt9sIbsuRZgBCWOlw6c3RBo7iEhkGMcQVh0ty8juheLvbwrorXMdlcB+7GtNpGL+P8FQwdq6YjY2S8ZT1+NenVtjY+D0xD78jtHllqrpINlLXS5F1h3/3m7VKIbDcqMisyQ6YPdc3T/O0pm4ycr8iRcdtR98ah3z8GMsHW4rvtIu8WkpWsX7Vz32G1P+/4Dt525jHpX6o4XU5jJ6LRMJ+8DP1pDIttB09JaCYaLBXrcYFdDCdQH0h/c5GXcq++rJOj+sDejTrcPUevHAvcvoq/F+kfg8egyPTG7rC50a/h7nzCcaZClJ108U+vVDFwST6ONlOArqnQcaLkzA0E36jr0SKbDhUWIyss842dDsI6Z1Joib9y5pHg8r7nBaopelu6EZ/9KjXIfSBsQ2QQeEkvMqgaEed7VtVcPle7cmFtwFWJ+F0ZI0x69qRNETs7os8XNuf/5wwgy0U93NQMTW3mbjFq5m/SQxduYPBE2zMjNUirWTnfbKMkwM4LzcC0MQYdfJMTRrspdFHbKJMC/WaeEhjB9TTa78KEOOXJbhE7pf8AMiYgEjegc7wjhfGhoo4DmacXxqI0/3zH5/BgBWz3lAtS64QAVXmVHfgLXKrGs3E1CC1wFjzcGq5vc01OvH1IKOSyq9fBmX85E66Y/I5e2tPfAmJ5JHD6uLfej1P7FcJVLxMUu03HlrDnQI4WqVQxY5hdn/59f2xAts4Lx1HE2wLpdpByp9WMMdocHYvjI2CdF2xo9yy8kLB0omlvd/POFuEQoZIzNPW1jxcvptt4L4Hg6hFjIqQdM739zcx8MvuAnqgg+mNT2FMo73BtT99/iyGdUHxzn8avVfUll/5Qxf0uw91bBcNAHmvL5k+QH7ZFfajtoODDMW6kPW4v4DeaCwdvnidqsC6Ud0czEjNdm5l40eiGBBoO4J2gDereYfLriSGNOhCy1HVEo3Ly0ilsTxikTrkrSs4bX/FlJg++QtDuGGzuOAaRb0iE2+xg14Y6aOUvB7rDcCwQicsBsTSnQA+6OmIymxQG+D+Yr/gDK/KYwtpYUmQq5iicGv7SmGSyD8zyM9etxKNqs31ilmqvHmrfAqby3XVJ3kfWu9CPhhJ0sTcBncaC9U6TDaoakRwPFMHIuk0U2PaHExJz8pxHdNE34K4I0qI6vuLTiupqHo7KG7RyjNzV4Zl4SM7FDakeWpc6q4IMJYcZ0KHZC72Q/gSMlUjp404GZJacPB6v9zwVZqfY64JLAZKlTsiuRnDtlCH9osvuuilmd+bWvedX90SEG+ks/31oqWPK0b1TJxJ9P+pBTZJ/KEa+SnvVFaGdroDOvgj/jAeEtIYWwP9QRyWLTEhLsSKZVHnTx1md6FvPbsYx/n3JBJxuHa5bZ+SXbsYDruIy1io4LWj9wKyxSE/jWa+/0i8KOtOJ+pEaaqIgJ8GmZaCkMxTckFpFMoh1l5v9ZHux77g2yeUQDCgnLXCgimD3arsBtJ53Vl2JFSBsIVVM/nsTCI54xDJ4a3WbsDXk3aoffzTHYaVQFuG6uXuwj74T/o4Mj4qPreDQTD5QF8oQh+76q5+akFYNY5tvhE8Dja0F7d3P/hhkUmNrcvs3ZIZT9jD6+Vk7M3zEot2130dEoDSJX/NGaBqWMmiCQrHO/g/HDT5pjsf5PnKcRIL0nXywwUl8JRdsfj1xyb2kqYqBNlO9WthpDUQEw0KYYsJsnSfdzpti7+XHqSVOl1wjHXSe+XivmApHDmmprEKxyIbXhxwTqU9lhVPgxkjux71hu3p8bbFY5Eh7SuvKElEhhfR4j5qPBpzvQTxL1FXFGGviLUTII3kH+EPTbb2+QMHUMb0/kegVYbph1T2cv/MMWnjYz6H2Gs2V+JariNkukqFPfsWGV88kjbOk6qx5pw/EMLCEvZHS5bS+JlnNpR7fXmuVaKN0Ml3G7UJJtuILMl6Gm2U5lVAjdEsOVsaKxVQR8bWDeiHyZu9l4LcyDKNCeLqNLeS1YZAWPY5gf7jnVzTSmpHMNzrUhu2s3hES/Z3/6Zi8nwMtiH8aoGQWaBPjWMvdfafHPn26e/R2O/8brWpbzIUu3ovM13c6Pkj+MCkbnmfBsY43V757+vbBpItCDEF6GDy6JfsyshstRrohckBAZ4VB4VX/8sc6ukiZlBGDd3RcXNGVDX2Yor0KQI7BL5d88p/ji237p60AY1EFSTVK/8UYyiUst/nh9N7aM7Oh+2sdFT3YbDBeS7bjh5Un6J3TV/P7Q6pIsShbzw6QeWeuBljXoqR3Z4XdOASxLM3h8nlMxgK+olmPuB9HeY+Sc0HgfXShOFOxGlx8EFuuNKCZwAGWuzvFLumIVmyZtPFJ1lyaRIdFccQr+52NdAM4iB3meev0bLMCyZ28c73q8SkuN7i5vuug3gN1BjJEmXXaI3XFwL5afOQLfGJ437bC9KmHdx1LNtKnFVW7kLXVt0KfXgccQ6AYH7QNyXXyG+jUaViO5cd+xKMKcmCHaMsE4CqMVgAuCqnn3NF3eBTElT+SHIYwDRGiCkJV1ssF1lGGF2Q7ShPElXGhNFbWPQh7v/rS5SIh67ymklYbuFcbgIzvozox0cBF0Ip/pg17Eo7cNgYvS6DGqFWBDIxBns+RGCXmXlp79C7kyUuXUxPPyj3ip0O6zsuYcSxW9VRuFxEMAqEqZjYJjgb6sEX9+Q+HbB52v5pjEbjHFnjYrUnNvrdYeh3G3Ta1n5MSUnXctnSMypliasaSOKn9ZAmVGB4wrdoHrceslvlXszPNm0okRiWhQdn1/FyLeyfvTqutgXoWO3GCBVD6tTpc8xgHbqpFBdB+b0bZLdhfwquOmSxY0LzV4sYP8olwbz+7E2DAfB8qkUdB2IcwYUdCLzVvqavZyz3B7ckA4/qdeYcz+6jlIojYhBjSLNzV8Jcr3FyAuFyJXrOchFd0Jb/htjbvGc3FhDbqLoQBqHW0Xsfy+MUDpBYkYnILsN9fy/M8/aBUy4fVOHzEXaPm99u/aP0umWSvmXqQdhhDjDf+e1PNXnzJm4O6ZM3MOXloc9OdCj7u0Be0X/OecSYwKwd2DpuoF/y9L0p/MtzBg7qui7sWrxt7Cr8VoKMSw5Ja13iAuHQLFnWQbuxaNZZLhtRQ3ORD8s1ifn950kguAxqjNEx5/zsLs8oovz+Nm0u9HbxhYSglccDCIinc68gQiyq9WN9GkjQYikl1TzLZRRcxwPcS92cUEZIUi/2IKvMteCCufUOPkuI6QdKvgPrpGFR1j+Q+bc8bns2XFtXYnc+xDeyX7NPOmL4ftWzvtK2Qpw/cAL3OjBXEjZdsgUskCdavbXjuwg6/52dfNhoYA4OxtsXbV+IO7Z26WDdxnBEeGmxJHqXl7X4GRS1FjQjpSfzTjPqeUzW1LLApuN1zJtWHC9mWvcccNaldy2+Yd0KsjBjWcjK/AgdGGrzNy5gXioV6lDg4Peo2/QXkF2zb+yes5v8301uwvhpO8YUtraFFD4wAUQvwawUl1Jz8tbCQqNjy5FeCYdIBdyNE/6QJE3cLekIzzQagLTwijvBzGqHrDfUSlLJRHZffppjNDSIyB9UHvlJkeXssfhHnrHBnN2oPo5X7B/iSHOjQfUNxNTQALruLwnQnyM2p7vroSinPzZJTYxwqWsIhG0+d9wku8JnnhHd1AF9Pl0dOagyiuK17u8LVvYLevR9YJwvJuQ7hxirUlMZaixCRKFPlSwv3xzL7+YopiEdy9RpwmmYaeTu2iBgN8Y75VPoGK+iRdhNhh0coOZlsBXfS8ZbL0J2ZqkE4+1JVU38tAk6chXZoXbphormQrM61uXd5uPVBeWvUlU9KGXKi5bKXsFxnsnv20rMOH5RI8IpSAQhnEy8/Cw5PiEoNwtQCBANWcR78L+VNbGsNutBcbvndyd0qDUvYfORRbkHqZA/zb1xjle9oiWO8+LNWpX1Y/Bu4jXJAcJ9wGAAS2/n8LHglb+eu/xKJHhQowTZSYjfHBoImXjITNf935d1W+m2ckVBG8u8YHgjoQdY93Do4dZw/LGF23hs+k96vRzGtS+k4Ecpgyms+C3xQbwmsoUkEgIImDykCKhtdVnmNhUsSGjOcG+vt9nIYttkLtzwsKZYzthIkAuFk0BVZGRA9jCVSOF/QEwbgOAt95eJzA8mWIb14XgZcfY/49ZyNU5sZuP/G6+mJp++OOr2E/KdYkP+B4VdYaRONBIxYUq9D+6mcdKEtW2/j6Nh6valQ/h0glkGS+OWlwLMHTZfGxoQEZXVQgS9730M3eX6+6jNUsfK7Jr7Jk9fHeyIm3PKieMeuUjvDsJ8mITAzx3a2gzfTuZoUKBJbI/AnyOWOP9XJXErnYVSRr7KcgtnfLQ1ei/B45qYPymBqCLObJn+BVKSgd9F8CiP0HDG34FyBsXbBzs/3bWHRJQpUq4POuQoRgN54Ghuti8j62DmaJyIHfNBdO6T/5veLzVZRbinCvGwedXNspLNHskL+S/v6WZR0J6TRpAjLyml5BpdMg1zavV8PICh5U96NffpsJw3k3wk3g9aoKYJHCK93B75LtVj7ok+1k6ObPSJzp1qIOMTTgw9mlkKg8q/MIPNOvHD829Wha8EkkQYDIvxuNPwek952023YEWDoQi2AvBV6q5uCdaQMeLzkXMUTUdUoHqkeEG9hVKljyulIVHZQHlU6EGMLiem4qUO2S03x4f/x2+IFsCUvTJPd65VkmmlqaQuT4XVg9D8SvfatCPiVHticHSZOx6s7R+gHdykgh4AFSHV4ijBMzmCN6yQBOhXLXDWo7YMN7dhJXZF/xKFbE8tY6sS23zWcoyYs5x5mqK+u8s2Z8X2rliXbvkOxd6AuxUMElY/JqAc9j3nuznAlbOT7fMQQkMdD7VynTTJesny8v0QGl4k4VFa3rNH/jV0ZYqU16bA78UOx1Xi+zb5vE4UPyGtS/2/cyn5//RNKfg7rICIXKAM7kscVNW0N1Ev0+4oiL+SFTZE85DqQpIoC445JmhZhaoYd/SCZNDT+XJ6SbbL/ooWnPWKhW47vJ8rR3PJzmFsuFcxQu3mm/pNfa0UuNYFj8LfRWznOQZR8xYGdH+Hf1xMXIblBF40L7PleGS7lVizJTb7XHBVd9PAyQSyHf0tC65lOJ24VAOnjk8WB/pTFFhO4oafZZVFOtSxQMCkSxgxsDyKsSiEETHs1/fmH0ImmVKP1Gt+V8weCEOYxKfbnNv2KbTFb5dcEutZuIwK7zHulMPHWbX9mBAeMuaFibb0/cUxCM2mYKDx2QTA0VwC+CaTTIp8VHRJrDzJCUBw9k92wy2Y0Tt2LLzzKXNeKqvyjfi3MFLJlI+dM5jTxRzlBrYGOVfBPtJww5+/P8to+Pugs6gPTQZrRTdhYACXvr3kfzorYj2+tW7IwQ8Q4JZBx+7JNhsU73zFzJ7vkZodXBPNHjQJKo/n3gWo/iAgvKCixmGwg0183LpiwKqZ5WfxD35xYkJk77Vgp1zczD8lnUuYshLZQzZBfNiQJwg8uvqwyZPiMJRcdhIwwEJQAayrbLfV4/+55oYGZrdmZjTyadJVsemZnzonPrgB0n0YCBawLucok3848ep0RgT/rV5VglF9JgBNm8BY/1yHY58JkGADs7W5NtiJhPuW6gZWwOYlwPm9d2sDx3tnZxKLeZYkB4UKizQGDqeKW2XyAd7UYwv3FnYD+/dn61yAez6WzWy1Tx6R+ZCCGwgCDAw/u6Q9W8MyglNjvhxUKIkmU+HhkWR/bN/oqXnevMER6rJn8M9HtsvQ7KAAFr5zv1ag/fdFlynOzRDhX9nzEZpAes59xvWvZqFSgkyKdjw5eTF+vKXXuhcv37crAWzR2fgn+Dg/c7o4/Cp4qbPtyBS9weliW9s2EqIxtghArGiyDLWDSVe8AiXLJ6dM9YU+++Y8op7318etFJk3MlKJ02Fw3hQSkk+HmpmXlWQ3n/NUmotHQXbFNs3Q0e5C9I8tVUHAGG4fl8bDTvGM+8CzQEQw6BmqIW1BJtWsQwsLzSaAL1s+GsHmLV1rLeghr7Vc7NoeHvLz9ZH5lF1zcXSZqroNKakQQeIrM2zPVnVf2LDIShDFmTwNM8iAMbmo/qJaqq9j1OMoZY+X/W19DVnwiPyhql5ijs4SEkpzFIMca0QtRm8ZC1G0GRXIo7twT/MdGWDFteWxei8LNOpBQjJNoKmDrQa3q0m911fRnjdzYPCHbQjO7Nj1gNYpG1K4mUPvZjDrqo+KPVwDq5vpoEP6cX4FFIT244XqTDT6nv9YYFLaAT9FnAWS+KnuxHcG2LLhVY45lpNmK4Pz/oSVhYahdo7DVvQMTSBszlYq990A+sElqOd3VDbWF11y1KV+H0aCk9vzctKTj+R01EGWbYxKYS8jm8ICAyO92+F5YXZVAfTGkNQT961par+75brO70VLJD76kNKb2p4CbfAsaggjWdEryz5zWn8VoRIKzSU0gkeKyZluL5EADzY8wcrRGas5cxZnJ7gGMw9TO07m7TwVCARAVLzI4fZJOE+KtTvHYD9AGZoAtVIuf43xvatnrh2cdSSoZqam6ptSaI8HFk/HcEs414huwo00xqlYBbtV1VyNnKlFQoe76mWgRN7MbNoNZ0UTSxuIsBrqXV7G/DHOP9pq1457N0XtZ39qPM3h6ws4/wVrJtxYiQkMro8q69z0eYr2ZPyKXhjgT/Clo/SwEwjj5dd4J1Hr29PKSB82DHMLUHtd2kE6gMqJ5fZaATHQuFLgXaaJ/lpi2Nxe/bfInoHWO+4Tgyn0MXwvJrwW5Ig37pOh/o4eS8S4al6Tki0L6nb3NrPhk5WdWnl5UFaYww8FlH8CqCOfyxe4ZDKf5wfvDDBXBxVGHSGJUYtE+09tpC8yRWQIp0PtanpvzTgpYIdeOzp9wIazp6NS+WtchmMtB3tuMhqJ436qXRmwHans+Gdnnfh7/M5W5RI5WqIv42p5/fTrV6sW3iYGboEdvp6XBElG5pRY9uZlo2Ck70I9wgkhWyYVmJ8mRKQxPPh8rmq48wuFxl80eokXxhR3jhNjtSwapKfCFqNgoQVW+4jak97mT0MO91op+iUyBlFDstSRcdn0D4UKXmMeSZTcE3d/G0GDNEJQnaZNoQsaSSSRtLmLLHk78SZtrHw2E6GmjARr4ZTtPuko+KoBCDtoDDYnGGcPRgXyQMYTM6YuLNVbgu7ptj9mFhJX7UYlpnzCJI09oUGy8b29rRbHl+QWJxRiCAAeignS+PL1Za27aa5xb1dBk/oGv6HbcIrF7/irmxRzeAfiyQI9AuoR7kujqqYDXzpJqh/nvw9zuui0uQ6fD9dYYq8CCqMo7m6pxgcU7FNzKJwNDpOIpYzL3+wyb7bzPO4ZNfkwv5AOIpQ2LmD62rwA2JMYUj1LXCJmn5a/wcPPicJ4zVGBS+uG5P6LsoIpnxY4hwkEYH8BHSouFGz1M9edn7wEJTnKMKvvP+bn4R0WthA9HwbHBVuCKC0RYJ8i9xoKu+L5RsEE86sT7vUQFubD/pzpR8yClY5KqP9q8h6M31D1n937PsssJbwdiiuAl6mGJ2clAMAnu/FkbbGdXQtSkbuqjMuf++iWiagfpMkLgZZwXwkMiLH0cMe09AlfDVYhx4XU2f+3mda+BOJszhOx0Pvfj+bSYmvrBe95HU869totJK+GaW5DEVcu3Ff1gFz7qX3xcEud+IG2M+KEjUv52uTdGS7uIft1qjU/wyD3Ttrz8ig9c2PnaikbSdgJISIXcrV1Dh+blPIkcQnoEA47ywQHIsH1l9AstGfN667vrCXWB+mzdaJQiQ9R8OsgB7v3J9HmF/X8+dlNPGp226vBH95DeDOJsuK52ehx/OzSZAwu8U03BaHKDBITLSC941fSXR1/XX4dzWF9dFT3C8k5ZKHojrDTf0nAqMKppxr1bb1j3lFeScLLy83YDvml6dZm12lctZv+AkPsGoS8OlLpxkWMOl6JTnDJYFJLXeyBhQEgqv9wVe8sCRSObs4BWDphAujf7orQOdTBBXgznxohGBMt6PzpAHGOPFAM6OYLQcJf9c/5OoxvfuOnKQ+xDiaatYkC6E0boJefPAqcepbvKYV/Y1g1rHbUOkyl+3DMIafEgjMOL0UF5+3IXnirlbKjEo1SfftIWWKh92kWhuT8DvagU4cIJxwXG8ats6Lab3rJjlBCYqOYaAPGfoGcUl72V+2b6xOR5FPXkrRKgV9AncOFn58UHsmJl2G0FZ/ZfB1J4vE5HAgPv/FnURezZYBkGYOrDkUdiceR2Jq8hiVV+2Flt7KFDDhLhXQJEHOZK/tDN/usP0H+VmEjGQh1nFpF5NwEoElBsG02pQQJrenrwjIDOfFfucOp+PmC7KXO/SN4vGK2x2vJhc80tjcLZdiaOPDMMEi+gQYgxGcKRIUdKJZGNIQtsrpuWg2nOkgkV2rPHuiiuTYU/1rHkJ76vZIpFsVK+kgr/O12ievsKMHYNIRrCGyjoR8UFZLKvbm7+AzWo7neug6bagR9tu9Nb9xFoGTQl1Ixz20fjITaJNRLpPZKCqpwFCBEILPa8cuyEJmcZEXumqchXcSf2lDVQBMXBOswD6Cd7fO2WGeuScX0Ld6MlVSs9YT0+btHS3kYCvTHhp2vOcBbMRDvkFipKAN7rF/RBDWbAbk3kB8vXfAVxJCYT6LTEt4ox2KshQOIATXF0Hv2jbMZ7U2qbkryqBmC+JVnP0wXeKiLaO8GROE9HcClbkRivIHYKlSmtN8x69dFcu5SRPODbHPbjjPNU7x2M4cUt56HZ+sv9MORRu4DS9n9UjPHI7Lg+nEDe68MA3P0fnfGJlGUsodLBZQpEfWrS3fnc5VS9RigOsoJMaDISd14DTqpkPKyccijUCadCeWs8AvXcjnHnAvjksdkMpBuw65bjcb5cTQrycONGFIjJuIqJfYib503tU7wsmEd7/giuOcrb7ZZLgl6DSQXHyQpZ8gvV1rbjxhaUZzdiJiWi3EqXGjmLUUtw4v6NlG0J6l7EhZziWX4xA9vdYJJ8jF705Q591KJFDH4XmMi6hgc+9ZKpCp9GPBqKVlBWeDYpZ4veaAjRI3l6NYH6nLbFuKnjCAdqzVsq7Fmo+QKNGPuCoGVuK6BeLMfOw5MOMgW6hwaPzY07tJGGbgZC6AAGOK577/sBtOi1gBbuDiIwwaHUkqWMWeZzbnIyFcrDrzRDIYSA2Rt14SxpVVV7DrSNXXnYFI0b/aeQkePr6M7JkXg0R43wJf9MN/u5SVYaJtxcVv92r1pc83U+62V7I7tHzhiaxqfOyfegrs8iqBFJG9EQpnHMDmWpduqJqStL0z0aQch4mAkfzz2eHx4F54sxHwNvc8S9YSCOY949lX70d+hX+uuNxmnqVhCjZN+J/W1w0ejCi9vOMAzZj+4Mz++/BdZ7j6uWn6Gf5eJtEOl5qP0G13SH5ydwXfER+eDLg5E3KSO9pUdCK9bPbkfZYLGxer4oT0pFRZpcZCfbMZCqsk62EH4mRHL+zkinLmfO2Ub5pz1CY3nxgEqXnY38VfEISpHr8UCsJO5VH0HGc1nJgVVPyPAVjgj8fprTotIe5fZHll0HW9yOUMqEx9YPA2WBTShoe9GKj+V8BdoIpHKwrqB5yFBtF51Fz4PaBlM9c9ppapYj/ct9wwGCh+ipfjqy15crSLu2kn6vkYwVAi3Tbo6b1LfbFTh9J3jKuAg4i1BAGglHa1/mPSnttABz7gN5TTeYclfen3lXn7E67N/Q4DzDZxj/3IKkwnsSCVar9/H4z9jvrDWZYTnBAPetsJheISF77eejBP7lD2B8lHfhw2v5c0WBc9k0dni9Rg2lO63VFA+OsqS0Pg7Q254MN1v+FPTfKv2k8cHywCXcH4D1Zk2KaGAZogUwf4pA8gr5IsmRA04SZNgYAaBxTTvSrfM8z352fPtBN7f2cBeRIa6B8t/rbPm0kQ2+61UGFARCvklAFsS32MIuu+f9XhDrflIarHEYRg+BKqJR3jalZwdy8OvmO+ukKHA2yZa181bJYhWiEE9fMUvbLJk7pSUGGyWdbKwcJlpot33p5xEQEZ/q/idRdw/L0Vzw4xe8xtVU5h1ik83tVEKq1ouksfTOEiPtIOqCodAHaYtuSdYy1F+2e1RoVMc9A0pRQNSr7PBUZIkrKcgd9F+v2woiQlIRvFeZSePIWkU0vpm48EVp0HQTHWsOo+h2mHPs+dprJC+kOAHshf6xpF37lN27YVNCv5M7JUq9M2YCYpSPv8q2cXOcT+Kzu32rLIRSTeF4wbAJBogx+qJbz1p66BJCOpQpOOSeN3BqfQuF06DRHEp8+fc3W7Nv7oKYbbbM20fPIn3+h7zX3O2ZPtHgAjc4J8/sWp4HRCQXisT3/it9IspdXkajkNbMdnSojBOSh3HOqERWWs52VVCYG6K7fHFKKaJsMBPUuPYtUJuhu0eMvJQbDeCytv6zz7zcSW0ko7nL0mK5SL1+wNGHX8t+iWV6CvbdJUA6ltLzmCT5bRQXo1efwKTRUmzSg7SrB9dTw97zm4L584kcZD0aUwJZSd5vQwAHG70psvqJXjSWOMrD/uQ3O94O1QdRNUBfpqxg4YpBTe6mAYgEgq54YkbiDnXDWK4Chi7HOfgrVgZNET67hgwVusqD6NfmrYxvNotL8zV6FwgqfNdWFtA/CnjRN8mVLhdDwtFvDmGZBiChDtiFdVc97unyFhrtFOlZjOdUWc4CCHZvC9JF/OFXCoxlFjMNzTzW1DEhHoZeqaVST7hqfLws5zJeBR9eM2vL7i/Vc9OvXwz8Y7pONBqP28eenXL4Am1rGINT1n+JgMM4TCrPBSAX6xsLbzx6FdUcKw7LNljetNxEA/REGWTQ3SzHl6pldUt2HvWf6K8CwtSk61ExGW8gVRXt+vEgKPLqmKS0/Ls8v6ZWV1XSS1BssTDqTgepfp3w9WUbkhrLCtxvjbhwnjf1t0j1+F/SQ90eeOx4K0eFCZB+WIsU4UoBKswupMukoNOXVoGnyI0ynUZK3gmfDKhkPPAv18eeooGybW7y3dgi05VcS9wOVZqtFlMLLkj/oRqP2TUN+Vmjt1NDBVFVP2Ysw1ITr5y0LJ6bG6IHI+M1lUcon5XUpG6KF9Gb2LEoiAO20YGFR6z6Yaj50b6a0Cm69y2Vh6XDCchempn262iNa++vAeWgxrE6yh1+r5seOXdC6TwnA2VzDYb8zqqmZKatnIQk7gvP3FpmVoE2vLxHW6/CEhBpChyD1jmZgyeuyUFjODetBC23/xViNuKCkRWR/facJWDpQV1j1QDoE6k6k8D/mXIE2pYWMeWiYI8Hx+UJhUfed9+PbRfzFYlvdCT2HnSLxfPYyHJ6XPrJEfrDrlnv3G4EWpnN/snweHV21kFSunZCaj0ZIBsYclpnPKG24is/CIojyZOeHPUHm8ugsR6XGiOuKwqHhjQ6Xteql9aUaf2s9qPJIqbxIiH1ln1C6Wcx8k09nWUQAxJ1ZdaAGC2c1qcwmmcn0sCb+I1XPdNkkHlGxZn0svMOrYxLMFOtcpnccrOfilF9Gv7+4UuP0O8u3zEzOsJ8mjljMLkEkhiVF9U89gjtMPW39a/Lg0yaxx6E5WDX8VtxXi48ueZ+op9Zh0FTvfL4BTg3JuiAbgAHcxJAwa+Sk2HLlq2TcWgktVioxx/DrtDhIIl6PFN02hpExu0j3I+/ndJUHbLl21YKc7cE4ww7mwTjKxKFvt5N4gFPMZbpLcmgowcHo4TUjL6+kgvlla8LraEYDS2C0qO4UEQ7rzRTD1TuGwS2QS2/rbbJLn702LT+v5/+7JSZhYRNR7SISsdtuWW0gIeEMTJJQeGwoCijGC7SzNWZXpXhbzYhkk/RmMK8z3oUfZ6DjPb19ygnVqTZoF9HeDe71n56tHFiIlex3j0mtHoVuWFM1G4EOLaR5R6JyhZKab0Zo+UboWbWTQS0sG1CQWDtEVLUTk+DS7PMr91VBXikq5ev1xwxC5Lh7g1zQeJOKCHPJ7qUAR0Jb3J6KulH9azMPuGKO30mk7gQjWNFa/ZwyjP0Y50/5P+ImLEnRPLmlq+n3OAalVRGi3gs5Z43F2m3kvvPDNzVB3iYGMCFgMec5qlBIGtq41KooMLLHXlSxqnktYEKVmQOxzVkd0pE+yXVgrNOu2mzygjNCVFUA9hAk1m4zJiaJqmwRlhSN1QRjDk7iIbyz/lHogCYDfjbdlF3gWAC5oVwGAfxSGeVnb5uyDjC23hBV8MEhiCoKUp7ebnfeyyiKAq42mj1LcboFlMcsWu5IILjy6kBrvHa1fX4Zuo139SYU3QLCmd2iAGl0O4Yz6UKdiKuEx31gk3o/F228EPhVq5BR3PBWmE+KL/C10GqRnVLCCh4VcXjA3Nji/Cr+eT2vw/u0KzTNg2yTj66d8xKc8+7cTLkW/X+fqz4XtBkaxLcV1bntPRHf7F7utDMrjIqBFh9cLAWjBvB5/cZ2mDZa2Tg1CBKMsU86AJvv3Sv8ARhrVTmfGRF+maAEc+IUTMvPLCNs/8NLKTY30VSGyVkqh6Ff8osPQtyK9Eeb7NVUJKywX+QoyylOqCbYE++9stKep37hjPgwufuzz0vqNhWsoxWZ8rpxs769++peO3szdT0RwG1pxYQIMEpaFMrWf6niyenxoePpz3BIFRdQL0cgytiEcMB2qQ+zhSDwpePYdVznamjI+PErTCMuv0OM2DNfTLC140QKGBpztu9xuvKEm3lIWw8SeJxdDRF81frebcQvXta1DftqCYOnZGIlNi5m7guUw6oH4GWGifp7jWgUKk5wh/Hjl91yW0xCSEVZI2uVnIqeR21VQ+nQleICBJ1HWOzV+PElLiyygM/t6/E/F8BeXwAhkcIg4uRnT3fvcWlOohbQbF+tP0b1lzrqrbSPU5VOvFkMo4y5dtwKOnEK8shM4DrCJepdp1BHQiHLpcIGIJd6RoSUoHVBxZl9VcGLQ3sN21en9e83/yFZsPEC9JSWEABMLjTE1aFnAoUU5rNfFNopcPNpoFVFf1nXbZ0UJ8af6NMuheJvlhMrSZKG11eEHoDwjkuuCSDPhmsIQUkQVA7q7L6ojTJIdAT/iJg8nCsigR5Vw9RBqHlW0S0KmtRl8dae0bXmR50wbn9X8gYO3obQXSYvIj8sCENBwGuV4hCFkFnh/uRzTOTuXc4BLqTXDwZjBer9ivpnAiY36Z9/Se+AjpkwRf6v5hcB7/qiBphl8WGSv+ks0RaAP5yRNDqB1CuPUx+Pywei33lXD6gqEWXyEms4BhQHelLi3xYdQ/W2Bmg2lX11kpPrwIYz6PqlimGIJ31H29D1z0IUa/6d69qrM4W+tgDkZ9CvUsUsmcxegKktthjeAPWaKULZAbWrxVocvfcdz8qLX4REHz6GWoF2BOqMPZSI1irwWlzLHMxBa3UW1i+Uk15uTxAW+06Xms/QMIiDI0zTmSg9zHv561kVgSgN1sD9i1VApH59XKSK4St+x/ZjnarTHahAtQEcu8dFRiXJqWTLAtU2zzmRRh6PcafNrWlGg5BPSB55DuSTVnix/Zh34Ukuqx106h9dqlqImyyusIk9qLWuzqpSllzWn6PJNzKB3F56ozv9oO1+fXWMTTTGPfyHzA8taunlZzhkGEz1KU9vcbGscTUq7xuAtl8V/KXKFK+1wbSxms1Ue6N7fVeM9zHpVWizija3+7Yw3JUAuJj7mIHLX89h+9gs4LpejRx1tJw+HerDe4Q91D4+o4/V83MRr/MFRVkqylh7+Z1fPrVHmsso4Fth9jc1Ly2p4V99Vvc0MXcmgviBLx9WM2ENmL3lD7p2be4cLKO5ztO6s7wePCQQvGJzhbrNUReFEuL5ESmm5F15nlP5MRuWexYOzahMEhlVskNkYGwGG/bhWy8TjNraQBxIw0eD05GsXfnDr5zgTqTzS/8yOaTnj5dlm2NJmEJNHEdy/sR0Uu/c1vxuIrDLjLPkbwPQBeQ8N/IER/xITp0wMKFQoLwK/j6Yu5InTW0x+iXp4erEBFQ8Wvh6IHnGZbdhCbQvzl+ZM/yzI/i+N+/pMaXor9yHvhfv0MzZbCByeopINAsevgC2JyrxhQJhZTvMsl8u785kMyZwbKF5puB7iSQ0EnqnKHCg9a/JO4GOUGcQGu8UbtV1c32he/sx/DWBFVlhDVQMEAkgU/Z8q36AgUdn8zIk5v0bVNtZP5lmKvr+uOlgiXRH2i/YCzbHRJIG8wNsFipLh73dZuJv5pKe8syqEKFPh7r4Or2JgPRwJad2JSTjFAU6O5pvNoPEWpNtyl4hX3ZNwVQNhwpxAiMm6krb5ah2cer9CwpxOhxuozOnEaRDyzGexHHng8cY0zchc1BR2OZLwBzYF23xdE6O9ThL44IuC3vYtJzq8b9f9GJYeqHaa12KJrlUIHn1EFK8I9/4LFtQMhDpUpvRawvxY3zHwgx1gGMDE4WbbSpDSGwPOqxx2CADF+Q/o23D/HwRLg8PmQ00XTa/VUl7xbbvpEIZbld5xdMoJjIkZXcd0xk3XFNo4aZ0PgoSbUmQ/HUORTJJhqdF08faxuBNERiM3zAVqrW24pU0FjPkwVqDBQQOgb1clMlGdduJqoIwr1GYj04TLcZojwKX8E6dt5dsfhYZilge5cJbPGieEUUozV1mxe1FbGO3ppHcc13rE9Na7dj851PJhVrdZkQXKEeCzaF4iZuMZMRJYmyPaCVAawfHsuvyo9UhMfMrIc0r0/KzPj5SZB56B4goZz0FTtCEALk6sEoL0I5pwSSpqndChyMoMXWN6euWNXfwyLLicYReZ/BkGjXQAv0yWv3yqsVyPSy7SVQ/3C+OldA0EDOyw2tQ7vyd7FEtWg++8KDgbqyWZicBqLrvn7IUKKWZKPBRCycryi4RInDz4dpI+uNX6QBt+yI5+j1gPgtr6zSTnLMvyEyPZkeODtdwrjPdKb4fwbl47Py32hVYao9V0KiCnPDzaedAP52agqlJZFsJPopRKquzWqYLd1Kbl2IB5aZbi+kgiNUqQV3TFIVE0UsB5fl7MfpQNtQ3lJyfsyGJ8be3yz0C/3TYIbr3+ZVx6ysZ3McDgqy+4jnRFi5Vq2A+T3fCoGZ1FIYdre81OIJe3oebYa7JA0dqNsZ36lFoNbjFiw/gTLNPKpHhUdj/6TxFVDjHWJ8qBzucWrTpAa4T5t3vs/FKYJVYnChSL5DAGm646GkBLgLd8PtdIIVIpTF4T+RgTE/1GxzhXcqDKP7y2iiceHIjM7AeaV5D4eULmprbbCiZaWpmTURdbMk+abyRNXXx1O5d2T8/WWIYefIU1cN4W5IVg8ejzs80jJp8r6dpI4pdDSwPFC021q23YXH98GNroRix9fynu1z+8Gr1wmaRR0RV+AqXONNR4h7ATA6CgNCxfersjXyIqQ1AbV6xhAMcMmtvaD4x+mEuga0jkOVbTeIYBIwSYrLXnf58uL34NSFvziobAm17RULYCFdHvHehBW5/TxMYJszMM+DFipCyKArd7tG3w9Oj0LomMCiZvVQCvN0BQmoBIoAR9eUx9RIF07bZqx4OMv9a6ERMBVF6TY1Qmssx7CayyVuoZ5gnjmVhGfk9MPkQe3fm/KgilV5GYdC6g59F1EYdV2lG1WY5bP26Gx04/uMMCGoBLSVLUyOcMKdOOKhWg4YocgwlD/oSw7F/JhRN5R/1ZGQV3SD1MWrZJhmcoNcWkcsNIcaVDBfQrf6R0pm5+A424r7NJKsHxscvAkPUlLbhiLrhjoc++C1MqR7LKWnmomLWFZPaUpEZOIwLfzghZS/P3uLXeCsDHlgi3ZTOXWSmwWUzL0r0sKcGhBe0MjP2tOcev3wthtKkxcZK21Vv7ODFwCzyFlijm0KZNTogmKbcmQ6Ray1lzPFt8NCIwUKEvwtywEi/gNPmreTJakqD+z0f6Je+nJZt+7FLIlEEviTggpRPhPiHDu4JFEM//c51J42mjBz4uizn6WHG0IHmCAvyEyNkguYtDCzmeKg+4zDUehFiDa+54cPKZ5nPsZ1AIlHq9mTuwIKxhv5uEaMQQRRmWR01Q6V+0sWkwr7EVKDF7VbAYVqudQsSfPBY59omf8VEMc3PtPPdmpF2tt7+C+haQWnul9UtESFAHhZDh80foDPy3fhazlDD+Bk8zpXcWE3wmY86KMY1Oe9VYtL62gXSsuAYuimOGy11aBZI5S+LXmzC7eyhn7RI00sxxi+fNzjfiaFA2K+UacvAoR92OE9XGttWBGUc69E55td0F6vzApHWJ5+PZoH+jW6Gk44jG35QzZZSWdrZMD4XWmEt6YyDZdGMmNrUU77mJeubAWk9ji4c/k/ZABBP6AMP5uGi80IqWNGlNQQtFHzRPjKJhvXDl1y1BCpJ+O/AARZFaVUIZu4EDtAvX7es+fzNRI6r5e8fO4wxdZrCzl1i1UIbKGPaZ9f/a1dk36O2dZdc9Rng1OEfUsKRN7QL1RJkJYv9o5ba0o0BKyxOpEGjL3w8v6X1wlZYZ+6KMqZF5u8zGQAB5pUpem5Hx26GyeEIXSEdvvtYOx1c4lpWfhT6Fbdrp2Law/Exi3NrfusLdakY8NEGb4Tqt0Ou1wTQt5hB7tflv655CQ7/W9jeX3b3XfPxOE+xJEkKUq/07uZHnGYouhygI24TF8r5qmgrJYnHiWmfiayyizHIBYXkw+tF6AlOX5LkiZ3ESXsv+pWdbrnipK8FmVs3wKDXN8R65GcyTqkmwhHwzlmUpERn2ZVwRYSycZxbyMP0yN3DDGLe5kJWuFMyXJN7wj5CWopX7gYEmd5nL4RgFwdcJFXyyI8dKVBWCuK+JFJJo6m6oAUzroIT5jBwHC2rEHJzxXUOSnfNG7Jvw0CtuWYzk7RQ0dn/9cjynZkZcYMtCY5RFtZJiSwAwSiwNQYj/j+Syrj7ZcbB1b/U8j4MoPia2RXSzGSQN2YHnudXhk9YHCd/ZAZYFY18yu65GG+0dNIYFy74r0thvDQDzkvk3EgF7eFYDQpMLg9GT1EP+XYdPxq3/FT++lOkqHVsu8D6IKCKVTVEIRpJBYvw/1IEPLbAkhItp0W0g7aiIlxJFSwA4K/scb8K5wxTF5fLxg8lpO/fJfWhu4FSdqb2pEdMYvF0Pb+ViOiOucWnFGME6xe4ccZvzkg9m756G0WetHDnJD2lrTyKSP6ak14QzUmFlEMByTpxuTTE6Fil+dI9nSnkxH5Ro35ndZylQLCJMvTIr1eBe2QlnNq4NfhRG3gZDXkj+1PEEPnRR9DoRVZ6ejILNLSYY6ZrnH06wkT4bzjowCZflxkJrRiv2Imjzhs4WbRs6PUrPo72hbYtlOuzT9qrUgVHFZv3T65l/SEkIR+Ij8KmIYZ/oZfkQnt4OpE7qcnrQSKGyeXvUsfhAJdbHnwa4y6Syjsuwi6lJlICnB7bNF1dFDypnGawTxoG1oZP/q9i+8E2rDqVd2l4GCBOur9wnpTy+LxqGNa7Svbt0aTssM8Zn+P+Z4Nz6XylOGcQXMokQNCWNFiZtGqX8nHIaDY9XgcOZ9BBH4k6Et7uy2+t5LTXj9tqZJEmrZjYYAH5wsxZtEl7M/CgKRO5dUJGovx90b+pUe+8gzWX8p7d9j3YcIcCAn+ua5xPJwTgZZ+BQReV4vTKNL2eDVVs264eaWf8aOkwiQu6SMCUphAdAFDAfELMaHKuWrdkVyYl3AcYUksJuSw+uBjK9NCYMv603vNbBmLbQU5AXEZ8ul8t9eg4eoFJiBX69V+xqT9Vi5qDZGe+JyOtnoyFz5RuprYjtR2vnMpyDbd+k1pEJJEULIL/+Q2Prx6TunmJnJkvhZqHFgJLzirQv5lvll0pOoyufaXhdFsSGhQmPF/T/abyaf7tKPDpT8QFzU12I4wbfM3BuyA5frQ3o8oAkqHsw8Bne2PCzI2Jfs0BCsbnYSUeW9MKfeubJc/e69TCXvBxcpEPpEy85/5Q0s7A4vcbpOXs1gpH3eJY+KGcwyFImWhUKBu31SmhIxoHduAXtiOF3lPjACC/ZICA1X4f/6ZzPth2lGDDUPwNUZ9C91wcP2SqmtEXN3JP01sV9shUFICEwVAhK4mIo6T45oFWWv8TK0f8MEwpkjq9aflQV78qnFddtWVQyHy3z6MNQkgjuhH9DUDH40W7beul0yto61+Xr7UDRHBQWyUT47OhZRRLl9iJQVLRPh1xxM/YTCcf3Vnb5GpjhwNA4LOtV8Yim2HgDonGqAouFne3/UTsErdftNFJOgVp0HTdfXLl1Sp4fHVFlsq//Gbrl9ZJbPUeSbPIH72x1XxtAS8aVHpWz68UlGkxDNZ/GTMmzlktxdBepFUdRbdsDtBqXftuEnhTZrR7tvXpDia4eyKl3XSYax3RFEab3GcfLmcMP2vvCkhm09gC2KMCO8LG/uSwoxDvrlwoP6mApDRsIgZ6kMTHiXlzEy7BjeOcPD2kWPskVo+lx3odesOY2LuYsY8w4eR86Y7V3ucrrMORl6fb3kzIVzZaiYCUG6OfxhyvdJ+IE7XnLSw/orek51eSr1C5OdNOaEuVpqMjpkvcSq/841f/DoyiHfZnbMhRS+rvAIW692l+j5FpOVACdx+iEi8wnb5NBVtUx3M0iY5Dq+9gJLX9mFBVRMklVORNgNOS8NXEpNtPzVRc+RqXmjCpeR4yx6n+DfDgfzrLet8JeHzemNqbVKyLI6dFeKYG8/LdEywql4N8Y5Jx8y/HGsxan3agrU09o5wyPrEQB2AkXV+0fHVzwzNyGGAsWHZgNzesgZqwkIUhM/5ivf+2xPSCAZSSFG4DclEO5FNHK8JCPzu4Qbrj7h4Q0S9/MwsLtAswtaQLHtQPiMv2F6jTd4OBOHwtFgI25fbVnlmETjnZ1dlixI8jvTyQLNUuc/hYXT5I5BsH5iaabquEEtq/PcTa2+IpVz6oIpG2OXHnG9nIiZY5iUZ39iSm9/hgOu4MejggCZefzZvnOJSWTMW4d8ag0ZFvjPmhfBfiwOSK23GpTgrgY66YHMM9J3dp28z6OUGW2vooUzzJd2JfpHmjaAUtaMVLqyQXgAp2q+hkRn/e+sMv7JDh56Yg88FxeK6vrSEd+Ioy4oZdlTFV2GY4MHGaZdTwMIY24BAhsOc4Z+2ng79mEUP8t3vsO4qQohZetUTRJ9m4DKv+V+x/6qh8pSpQNHchDJClAbxAmjeWuJmK8Xb+8mHzzMdHwmWxjV7neqNu/iAgI/3NKnAotthvrYwdA+FATVtnf2sCCk7Aa8/WS4QmS525Y/OEuX7aoPcM/M3rvkUrzp4Kc/QaM22vcaRNgN56IFuYq9dtj6SCQN5rhCkf/aqkTlSkaKCXQwFNG9sDdHd24APZhktOsyqaDYLn+gNL/f3o+vRpwULXjnhrrqCuhRiPaBJMxJEiLkCtPUa7bUyFKgyJ1tq08J9KE8gQtTTjb/IsJ3ns+Yh9f0tuMebfn1jJZVVfOsShGYt5OZGV+PSiCjLQ/k9fb41bSu4GAd6DJZlhse3HUcldIwn1CStQMqz9+ESuOjBEtupL8+RjYg2QtVXx+kDPdsRKP2oEOrNHZ9j47IbpbemBl8ZG2/6GozsyGtTVOdnBQ8+gAXMs3goTsKoJ5fUCX4i8/ig2a75iHeujEF9j0sVI5w89t5pe52eDnpn4n2ofw4plr0BjjDT54UZiJAsBDNc89gtiD9boSGwI6F6lB84NVsj270KEfFOMp4lNZqR1HzjKHHCommna6DE9wKtNWR8eDuC/gwiUfObeLqRQ7Cwe32Ykjx9CE8wRr85NmN/IfNu08KLs7qgrKoEXP+H/HL1Lg5rktYqyrIn7+6PoHm7osIGqNEio8AZnMujMT5tX3nrHkNcZP7BneCbTZBmOb6EcqfuQt/ah7o+wBfE1vEeB6qk+JlgfcDFLRSR3pAnyPpHEw3F9/fYury0tw1npIKquahVkIiRjCBxQjQ6Uq0VVDOx1RQsU3y43VlgBmgIq0bQ43gPEY1mxIb1NJa2nzesnYsXHv36f1QqDNV6RXDt2elNqUnBHh+K3A76HQB91stj17zYK9O2fW/HqUww269+epV7csD6OhNqLLHLL00XOUogreaXwka90GDFuf/V6OugkZ1HUznci/TBtQc5w6okUqf08fiqR0+J0Qc+SUgvCncgdDh06NqH3qIwY7agCoLFlgrXCBtInOqaOK+rqvkRTQO+5FEpVUSqv4KjZW8NgXM7ZxZX71c2MCKk+5cpthBelHpg0Nz9QxBOeaMkH7PWcG4kYU2PyGStYKXosYZr3ESNQbN6mGnGQdklE1b+4+TmRijVZQWSRS4lUJ7emqSnAdTMOU4xns7GaDvSdjdpxqWzabWxIq8P5M6Xa/27wlhYSyDcJ5SqcXlz6pwb1Iv7xTtkTNYXE75uIO4WWts6HDVyxpupW9SwfO+rRdVcvda3EYkQcPmGXbV+A5+7q8ykXO3MatOQctd9oPmWbJ9ebM0Qp+adf/ueJ7QGMzbQ1b7RRpLiDFCm1+ajjcBZ8CSwrDXGy3mRqXVhhPlQyZqShzi+CoY+o3XSjFy+v0mTIiALqsiIO7a11vaCJcdCDfHLkVGAbOgAxiP0dwkr8ht/LcgqII4BmiFvaxitoDpM/aEIDV1BP1VfDKKc6VknkyBMhtbxahIQZVEk4Z0bzblErxOkLd0ya6kQit3LlPNJFkIqW6ak5hPyoiEvwrE6CACBf4HwmZB/LbDi3UhHmQNd9QSU+TWr1U+4lAModca6heahBeqnPF5c0pk9jaifJHTJuLKOMBQ/HMNEo6QlRv/LiG5j4XpNfWvtyquYNeZeX7hH8kL5yLu5nWwphxakHS5hcdxJ8QuM6/ySDz9BYNHnHgC2LMLD3BpygyrefrXJg9tJO3bKMdOj183vtrXyo+xJW/zg7+Lw6V6bmmB4cO0kOHI8qUEtOCA+dAXiJroA7vBcvxrYFuUr29Wj2SDKkqkVXS+lk5ZEZJcsd/W+6i2NEWpoFxJToXgXMCeN0UQa1J2eTSj6kiYoG7YkvLajO0B7X38sYRRT/4lxtJoM2NN121VLQeaQ4iD+hZo2JZLT9Uww5oKWy3Ar8QUcbFWgl7WFjLwajF4Lie7qRO9K40pNFfGMqRK0IbClc/YGNDdax/0LKc/Vtc/QJb4tJ1HvKEFXZ+SO+VqM6jQKmca+2oFXzoKjJysDWrqUbI5jhl0R+gb1K/OUqQ89RTsL9TWE3hF4BiZOAF9OE2goh7d4hqy5YkV3pGVzKJubK+CNNRx1b3iLDB/xy4xXTc9bdssojV1JDPTvxzlMBxahd1NfiDfd8SKtDerygwpHXEnEXLAk/PsHt+Ifms3UYvEImqkLYSrCWMq8F4n+zf9OdMvJtrHAImPz5EpHP1NJ0CFcowhCO4fTd1Y/7KJeKmmbade02YTNX3jrSSmENLIc56wT0g4+pU+Hj8GlGSNvh4A6JLyW+142bDoxx2N9vZENJAdUolANoPiMDwxE8Ks+GgWQSScu9/XtmMoXjkmiO0mjgEat2QYxcElWuX//lq70kxDOUV9n/TaO8jDnlkdMNj7VrZGuZ/qcNV+/5Ro046eFpw+DnmzI2OCz7QftmE4DNNsY2iA/osnERY1vGuDXOwLMUXqxfqzVNb0QJRYuqtBMsqaklvSFypgX5vCQEFaLdEo9vJgOxUBZt0UakMJ1Tqsr5W5iD2/690NeNj7OR2GHN9lyM1z3jnGVbTH1OhP1PMDmHZeSttwUdwCxTUUNlVdC8heMZGzNH1c79IiNIv+vWR926SYQl7nXrfkCIJB1KZBtPmDXAW4O0Tl+kJuQwel3iSqdSmzy4ISg7EGYhTAbfaw0Q4OljOAckL3zbQqOAPTRQ72Y1D4QdC6kA0z3OxEF3PwFi2ByRZE2fGTKvpsupgfm/7wJp3mnhz8n1vrKZKY37wBgyl5pE+NwlyJTQMnVkmfHvLer+7IT0aM57RXIjpcE6zhWkLC/Wc5ora+Eu0GwPux+9jYbk/nVCWNGzdxNJuLhcBf70uW0E8D3N3fJJoKOKhN+TLaXCllJKbf7hfRL/+/zfr7FKh+ujILTHu12LsNbpfYbSPz0x/xkzta8GGikzfgm9J6a2hyKHxYLgRfOmQX5o7Cxa8MLxkOOUlDKkGSO+adJc8JNN6JivsuY1SonC6TBNCI+GLqao1Kt4ItF6IbBaVcoZdtaGKwRN3wvwAOJasCN8KqMGkB0HubG2L0W3EMlt1IVhpIp1psWUaw5HiFvRt+Wt1M7PG79K+WjcC8oHct1UzWRhFBJOK9577KMFUYsP7KI2WR3z0l7w1ZZhoMsjlwjK4faUEMnHOBAxTh/bFZlziFJAqCZjyUzyFX8ZjYw5kR7TjVlmGINqEdGmkmAfhIILZc+I3fVe9dIwm+7CkYs98XNMLDqzW0m16NB/dSsOdi2BRHBdH+5hgpNq3hiOybP6PUfrowT6ZYBP+DmTKH0nqBOIpJ6Bg1PjpnDzpiJuJSs6K7Qa3Hg0DvLsr1s4Lmt8wG9Rkeq8j+P9cM5doV2NYQoe6HqE2cCx1TT+SI+QNo/PawioDxLBrCR4K96L1Rp4ziWC8hpenYujjBYQGg/a6Mrm7TGncuITUzuyL8sQgQhBW0GwgBj2OyokQpWtotbRlMN5BK5gYFHJCdbLE0hVPmCOhvM/WSLNaLE4P2yGf9PiP5FUR1g27d0wdx2lAoewzmtUwi1ufa14ME8/rX3LWq1GDX0qaOJtH9CyDyzypU1RlJwtem2GiFX1HN4fOuzofS9hg98hdOE13mmMriXEJolKY2iDteqf43DUveRNMI6BwK4tcyo2xajdzs0v+A0jVIoF0MA32vgwkOLtuPprk6pkslgXQNb1qfOQ4fxfCMlg5GooE5uB/zXNmbitu76mJcWtI9wKIo9o+HSke691dXvq+ReUIFKqhzydfPSJ8B/Ep2JpvINpes7P98oObOYWEnJL3i7TMy2QasthLdf6Dfv8PsXuA6plNcoSlf4Jx64nRFzH6YIWbd/9CDKbubINopBCzyFClNnIiyUq8HTLbVoLox4b6yx2e7oxOhX7BMC4gGDn5KD0a+hPAof5MPE27J0GGZ8x8bx/a6Uj2ZP7yBh6r08/nB8sROyUWZXebGhQtMNMgytvZQ9gimB5D2n9zIho64/Ix9tgzcwa1WXH/Tj1NIB7B1iv3CHt4uKnqaheFCPfpluLWD+m96YzLTxfctorJxrzr+dgJLkpHqejkx2eRd/GYQOSm33Pd423BPAYgPRWH7HAUkXpbNesk2680I+u4IZhWDPOKuFLzyMbUKjPR14T+zR+SB96IdzE02RK2eoEBhGskA+FNLs4aed+11CzILJOfdc9P9yz3ZOq3CMI6d6oYwssNUW6LpvoKgN9Yv7jjfLLCYvELyULcfI3VwcrsLiSidWRtK3IQqYyhW5NThJZbGhqEdgSPYRwSSDygKr0pBPIJaNr4OgRvtgcbdByd59hsXasDuOj4NW5U4cC6YVjAhnmztaxxzDMR0G3wI5x/2CUCU3pQUJvBLVnzrySNezK0bCpq3LXEyvbs9jx05SGkM7Fc0ebjvTa4sce1isxrIwKv5x4v5wI9we4Zn3DVIQNDPEJ1WYUwzixncvA2WhiMyoJMtOk9FkuwCmM+eXrZhN7NbA0jla0pXo2EiERMFYhDq7G8a0Ua32e9YQ3g5xIwS9Z4BPOjMnl8ww75xVUQ9bYcmwqk8VvVz/IPVsTA69wHyJq7te1NLLaLYRIr2JkJFzIlPj5RbnNXAEbybrXvECpbcK88MccyLKYMSXW6WueWMpjaZRVInJeOrD3leVMLQp4PKooFF0u5coldYBSE9+C4559SiJN8ZnZe6bv/TZxYdxvMqkNDoUWWHOcgv+eSyo6cVPIoyhQmU6A5xmbxQdWsSccsZTZGng73cLHRq5V+jA4v+jJ4fdB9FBsHfXn7kPtSL8kPlRe8CW12ghUtE4B+onRjhIlCoeVxTmKijJyGQEQcoGJ0E6GkV63w4ABKrTqYqYsw9OXaNUy6NDJF3V4RqOff/Vnr4h/n2fb/XPxYuvZJ6UGjEjHn3VjBLPsEpUXglMeXLoZdlBQEOnq/miQLijmPPnKuztDxOxgjsADvYBwcIkYHscOka9GCv2bltBXOZqycRmCabAO5NEVfjNJ2aLcMlGDiuo7UgRVx5B26PDsRs2mBB4Qob86eyRXckN/7BkmESJdhvbax9NV901d1osEnR/JnlJD24DAkNxiKzW8zyWX//Q1KoCOEafbDFolAzx484tBK0NlBg35nF49jqDwpraL/tzxM/buhj/WuStqs361RnB8XagSH4+lIQy+Aps5C71ALKmR5+RpCMcAC2bHeWpU08QtcVLtisGa0un2YW90T/x846GnMhcQ1Lpr7vxXX6qYhh1k7oKrYUJA3onQvnwS1LIe4G0RJkOC41T+qokWW4E3adKVrvxFpMGyZOyYfRa4AQGdOY+sm2ffIcyEtv+3+lOOOV0bb7liip0yZwRLPflqnYu7RG71qPNprrqERNgihSfdu43ADR719au8/KnEMzMlwsADajmKeW8cFZiyhNLolCv8sLnKPMSOuGtIQNxW0NWQAJ/H6+sAMcWH715K7uTztizhbl21koWD4H3Fj5zGwLwZrkn8kwU0zuZFk920Lcf0xslW2QEIJ2kG0miHCqeObU+mcG5YwGMF2KjlBMFmvOZoImC6fqf5Z3aJh43KekZkMJsIaBi1M1IPpV7smOcd9FiIJg0QFuyd2d5eBsZkonnFofYpMyfU3KXl8UIwGI/RobY706jHEDF9zD2AdqJ2pjWCNpPppHnmiRVCVaahLvubojGRkIJxT5dFc8Rd9pETUrB/g0g/7+n15BQHA+3lcjX1m9TIwSFWCSHde9B9KYgX8kp4vCGJM5cZtJjrwwr0unr6/6e6vJNz4J4kgmAKLjV5KzahZboII26TohMmRccqOe5MAxSeH0YBJQg3rCnOOBO26PHWZRS+OIGJL6baIic/Pd9sW1fyALOu9hS6Ahs1BgrRsqX6HFI9U7PyVFB+WKUf/wwGApkswKuv16ZqP6FsMohW/2HNKp7MEfgfqWYZj1zkghRCd5OO1qicQD4uEQF7VPa/O4R0ZXqB4ZlvZzzuE4OfZbihZYjrpOQAjt0A5JicXikUanP92ZQsdCO3BffYfXPMu/rRPluaBnEhj3XAlnt3/G/t5bLGr9wmgycHQflS7Nc0JJVwlPmp7W6tvV2MbLF9rEGlsjUQHI1x97JYIkP7AdNpE/iUSZykPVX+J5kZgK7EcDihWOaub6PyLqtVZhkwBbSiItJEFNyx0GvglmWztvpkZ2uiCmStLsJc7O9QRg7Y7kpZINr0XBu9unVkMSyqzRJbyGXuCSmrWAIinvVY3m3RgNsV6Vf/NUzwklR1lrh71p5CtOO3KpL0tdOq+/MTZS+XvqfDhGN/9hBWaymkhgd+Esd78WNyZIymv7Zl2CZ8CNQIEcHEmZhow/xtypwnJ1WTOxYl+ZVHxKhwFa0da8cgFfA0E4Qo/t3zd3+cNydWVyKvUw/9/6GJpE9U6xg0s9LYgk6JIwcB8k2NN61LVl0rWVoi8bDE4klHfiSCwvKNVfJfJigadBzXRojrDQ2Ff+OATC6j3/YhUOmNLB2u9GvkPCrHrB25Ekqz/Pe5Iz+7mAgAlsT8DxyUCE1c6ZWSLTxl/zPSYQvVCrl8YnxElLGwR0uBcHCqeKr2hkFPwfFLVeQ/UQJjsi8PWhlkSp0SXnt4gXHPU4sDNJfFarRf9VZyw72b1gz9I7a0/E1DGXJXqh6sar1wmlwDu3B9+tz6nHRx7vTm6Ok6Ib3nRCaUCH07WFZFP+hHxUBlW3o+jWWp+E48tl8EwlXDDdgqRM72MS8vtFoV/DjiqbAxZ7p39G1Qak/gLwHNTDd4BYIZ5N8fCvVeQARP1pHadx3vsE56bjzsKkwGMmb7F4gD3Ti7ria6levq4JWDpp0tPaY9okPidEuC1ydFxUSTSNhFfAcASZtbDjdVnCfywH/0iUQYW+N0IiD0DwO+xLfC2ldpKlWmEsw251+oi8lLPeNVEjRY2eW0+WyqpFCwf6uuiosdhwoswnDfW5KDQf12qxdnlcla6MO0k+xy7QecmtytZvlzPaIof8YHx+/MF/U2/ZdiMS5p3aJP9KxYegupbPTHPBs79me1Cg8nxWfvRmjVVe+cLIxyUcKvuS4XgUf+emhncVETn8zDeZ4D2H5FzpeLZs2jPLq46iWEe1XadQANySNyod8GmdtLhmejnechLuyUZoXv9Uzcu11K5n4YIFBv5KeYZwzUONf0aNbvm9BxZkZNVnlVdXhXgpakCFpsjsiBrxxdORQ/hDHMJphoMkg3jbqXFCI8IFS0I/kDk5lxtWnVCq9wO7utsyayh8W+AWhWM4SOcjoVS6Sp8LjxO/mLJnR+FVoblfz1NWftB9VOgV7q7310EWHxte6+/hEEn9vjTILsGQSJUCzFt46tWQnpEERWgH+d1J3yzTCPjncspWqEqH8KtibEPwrqpSyabcs2D9WfPiUctB8gw62VUUOMCjqF7c2evvWWlb9HeLGjMQ3byMDM7prp7z9Yo19/GeGlRxugJkfFNe8u1yG31zvgfHsxyfBF5K3O+fWnT6JJhIFxU8EmGgxCjgK5VHsaG4cIh5Xb0EaR3yC8BjSrdEGuzAyoj5ytK6HOc3oJa1m8JYdyeBYWVhXefxQRgde4JtDq6FBbdnEHXk9NE91AtKeaKTCJl2OEqGjQOKn6reLyvixqBD/E6K8imzCqXogHdJ4Ih0xY7zQK0zbrPSN5fYHs6gZ1f5hGHDtOkJa0tCYuU+lPhZL+UNA59vl6Wnnht6z7+8OduaCs4KoQHsC+fuxsKCWzLEA49xMBrZqnsHf+jK2SqKBCVNScBTD10uEHHAFOmgmwyAMyUiIcbbfK/qdZ0HVxt8a8JxKQAefayrQ4zY/ydmgxwUKlsKExBj9kyZqOWObfiQtqHU8V0KqcKyNPs15s48onYQ/WGbOBO1EcwlLCGip2nqriWicETYt15qhNwUbxp8zNNLWN97vtr2n2ICyfU/EyqqZM5ubBsj/xIrgf347YYvNwkRVBtDx/O4JH9NvFP1e98PmJ0gVungqQa2se8DyKN1GgwPvw2XChrVLqWh7AGXCO2XZNDsft9jg2OzCX+DX3YqePkGtD91F7KQVQvuRTSMAyvoRNmIJLGX8wWR7oh9e4EDGutomfdYMDmWwemh5oKqdPLLTqDc/ZPhoNBPV5+84mG5aus6HumG+mNyAqUMovKEeMDu8sMk9MeXX+GspKe1zsfSvE+3XLedUnkZZ3paM31GzGx9NqgAklXAReSzNiKR71q/6mQ5P0NYy5P91O7NwByAsmF0BuINCe3JNN388v8m/RLqLJX1SpxdjcBzg3RMwEW1qcvvSKejKwK4IlvVnKcLPc5YF0vN4woiM2zBI0NrGKaI9UFAzdSUnWwF3ZiHjsmevxUutJ+SpsiCMBMTGEhl1vJGRtZTXSA4K+FIaOSA7soBsedMfeoJFZLtpFlQOmBK45AkqRRvHvUDmMeqjA24KJy9zyA6rPc6RvMp9prGdJ1gTIoWqODImb8rhTokYol3q7IYn2L4NXzlAyq6JnbwtXKSdQ18pmGGU9ui4GNi8YKNjGSXR/ZQKNvs8BHmz7zIQyGzGs1wREfqw7MNxh1VosxqCXs8AGrfek5q5wvsYzQHSXEYGA6/dWDKi6Pjp/evYBNbbdHVXo4Xw9OVMToQUuWVylFqfeBX1nalcoDG8mfc7c+9qJVX2vdEzPyT4p9B/C7BBnNVGlcgG247DAX79+Er0B5ytcJzNi9sD0hqzQnSF800+Bcf/4KAk0PDhkZdcrE7jyKSR0Qz0d6bNBsiBzLahWpBv3cknzY1guea2jgyy5yx/3nMWzmc3msG3zBchk1Md4B7FOsn5EP6I4FZ6K8nzxyoBT4F2jzbqD9iU7h++RxnSHh5nkw/JwaSz94kBzkmj7rEyvgv5DGh/IBpClfzsS4PRk6Yy1XOpcvxP7ryPztpM7cgRRm+CydvysEp5fzRBHkiYDd4DwCcXootnTkhJkBVtusdxR3WNhF2i8L0Ppy+ZWHiVBA2ZFxzpTraT32J2j4eTtg5cRZ6ALjgLAgUe/CKxbIiwNgvcWKeJfhS/1oAPaclqmPirXEJT8dcql1x0C/2q+AdUMf5RJrC9uHZSvXrMCp05PQHtiUEvVsSjRWAA2L3RkuWADoYTL7mMjKlkj9xzeDJgF74eLaUIwQoBmB4rMhAB4LRaHgD8ZJ07vbkEnBGUx/N73/CPOt6vj+ARiNb6oklo5zwhEZgZWgmQmjbNOB8Bu6yGu4m5msQhEOHQ6RpUyLZX9qUFTuWxWDNrBlM5jDaa0F0IlxvTSNY6OGoohWXCRh41uILjyCUvucVy3B0g1MCvGYvowoeoVXSK1sDlonb4lTzgonjzYYkFiwBSJNvgquGwaaSQLWvHw0kgO8ULrNBooQZ0xWl7lVdPM88B8x+Je1CYRSeZ/++DrmVtH3RjuHer4N8Y0xeUmXdS6yxVwPGCPoc1pVOY2HfMx1OBZRZJTh5AlrszdlP6uEtPi9+n10L5Sbd8bxjNk7xmagr1S9UfISd50tdOhMO29XkAHLZn8Aw+2RVGG53B0k0kdBpf7wNjMKHKc/lDujQ8n6bT+89M5Tk41P00BAuNUwGSBN9/R8o4NGpbUUN3tUr99/YdL8lLLXFm7sAIKrJ95wc+LrFQ8SXfjtT+HCplSV+YSo4nmpXlKQAH5sEITqcguZpoTyCymNKkf6LV46Oon2lTAi67jJsE+HO9XUtpwL7/u89Phima+NutOe1pwWTRhMEFQurW8SIWr55bCXuFkLzLGBQyxRWw2ktuXeu/iO92RvhhARGNUjbuW2qFFhXrhrxNeOzVz13IUnWT8lkeIV4+Y7zWyiJmvq/NKD+PqaV9aY6IQtV5W4EXGrFqRY0zoF34kYYeHRQOnoMK1npud2Hgpwds/p36u8V8Gh7r+vbP422cNW7qdpEQirMnPtd0E2ft2A7vVGsMr1A0WnbD+qi4r9Y77JhyicRVlM6BG9h2ZM4OVtrwRs1ASdBhSJr8h3LaIqu8Fkv9hSjPhX2jReX9GTrR1P9g57xEzNuvZjFTOFEzQBIlczpoNUsEztIDzEyzTRgm5VUpwAQX24SrB6VDkB3pbKYIsYP71jlSICEPSG7Y1GjTL822qeu20m4AtZKriBC4k/b3+r3Jbj2Mkoc4CAI6EV7kWC9vM1ChgLB9gtoeFnwW2Wcp3kI/JMEceU+JRxMuj7NTJJqPJqN7Cisx04KFaSnrYXQzyB3vsJsWb3FT9Mv/m6FAGB7qC8ErJrjsFC6Nr3SqAJ77Rtx4/mPs9Qf4OthdnskjaAo6Y4/TVnU2rn28aMkAJiFNLejMkz15L+oyUngn2iv2P2MpNl4c3SgGxlziGFYh9H77BPhM6sjeqlJ21sB9YeRWisndOzDS/Z5ycsBn2YS+fJ7kEyjtt/QAeqaCWYVkYzXTfvhe0A8hrZOp8OsNEJOGkC6pqTOT78k9DuRUlRofPcRa6dFvHXCVGFnHFNySZzq5w3pS9EMWIm7HvV993rTwwiGhotDfk62ybQuPAh4c3Qx6dS4hJabW1S/t8kw1WOxh0obPT4+OCEvaplglCdDS0+Y8hQggv1Vh2Z90Dbc/8VQ+omELwrixbkWcD/12ThJcpMYwgX+AuRXNPJZQ6JtlqCQs5mP8Nmvl5haO2xqqjLy8CXETadoJvwb3Qxj8SdxXlswprnzNez+vBrOl8jdIsu4062aA+mYZ5i8RjLJHf0Ciyt6pXWv8S5911HmcUYh+0lVu5EWMwHAVLct6ZzajHkujYz+znWELaFlcZl87V+4JMQ4CkZVsPNVUJ68dMC3c2u9+1v9dLGjNBfn2pEODoS6EkbZny1ghfK8sbqIVBS7zNzCtSrYYmb8KCuaxrWrZZDhcZuLCQxLGlO76R2HZMfXclA8f0e0i+rQR/l9eS77psn8ZD3SD5ZiQeQ/0dpKOihUVzKaQRknctYRe3PzcUAuL2+dfg7IXcwy0NFY44x2V68hYFgZdnF9zN5qMtPUDpYdIzJsToSuNtZjY6emforzi/FCM7eoOM7cSsu3aQ3R8VFWwZKftxqtMLZU1jJixRbwuH0FOz0WIBPJOiXhtFEx9m4qBxdqlC/wbfYdymQvsCHwqd+x0gyKwCqBkdzXzonml9n7nDGHkEuakgkJUHph0nw2+V5i2E+N0Q4Y2364JN0LVQrWW5UlX7ahbKRABP+K5eZlIdpMgtwEI7LtyTZeUoeexhFgao/kkMJJEw7eiTG+EaVm7w3nuEuSKfZZH/5CFXZouMLONBS0lc5PnLokCyfTmT19bmXFNh36Do4vWpvqP1kxcX5sNyevmdXtvF7hxoIU82IvKITN+a6uctjDWOXuk5WeMffLka+Y00o1o1Ams2KLC0LDNyJzhJLU8+DodvvDiKpCC3kWv/ShU5Lw9XQUv3zCinf4IIB0riH0B4MiqiACm+zKYtvsrAWdTnCW6aNMT9m7k5ACjKSp0qRss19xnLi1YSnsKc17SsFU3knifnUM0j3+ZJ2gmNtxma9OeEcplrkjM3OJAQlnbcHfA33ApoTsv/PxlO4YtbfsXTy84BgmZZVbPTKFwFdGfIqsMpPZMjWM2IWiVSdh5063z6UFDJDcz1MTzTnncZAh7qipB2QEp4vDP8WxSJ2UUkmXZ0lqMs5mTBGwdjsJHNnzTsBRg1g3nRt8PKXgtzEscJiiOkuq3fLY0Whx3+9pNMxZNkf1QhQORMjVzIZ+lPuoGIAnMUeSFxIkHvlVPc6T6w1rX0vuIuaDIFya/Y+dV7ooKkfah9hEXZlhQ3uOek2KyZNSl5zoLl2/+KFwlvj2pBrWEQyjOwVIG/KfreSm6hRD51b22Db9a3uBMRJtKN/JK8HRkVt0vv+eEKKDAm0evUIF4ZVa3ffk4CO25TFV608G7OfsdraKno4gG+UTpC2okl2jDkpt7bO1Dx0Qu3ajxpzX+wP3VFn4gRctJ3plrShRjnCSDRexl4M4Q8QmuOZuiD76bOS0gwLnuCfHH86oMXJxCgud9ZtLGrZU4yhQKi+flm4XadL+5uTtEYn5KxbYHjrt3vbCK3Vbb1aHz2MesnvRu2woOU+Eh1fcfqvVHwq1GJIO9Tmkm2vM+5aUAyaa4pkyvD6KFv1zezeXl2mAgN0W0G6EYeN8hY6wAavQi+1PFPOjH90+KgAK8oTuP7bG/LGSBHwLqUJiLM5YthR3vvY+2/N9zChGfB3JXkkh8wRy+E8RgZ6SobYsyzpZB2BdEFU8p1a92cOOlYLv1SC88KRI4pLvGbhYcL5+pYpFdvfCQyEmN+o/ywt9ZScw6sU55gh2pN5uqgT7EsG92QpZF7xw5sapJTTizgvQX2uMYTUzIKpHGPPHvHyYVgqx3lep92bAkjuHauAoBwv8WldokACW61c93nAH9/E+R6crMY3xt1seKta0z0oTUrI1+FY4hqHEN2knkeYJiH4OnunPpl72qFFGd1OXjFXDU8IS+OQX8hII3VUtQuOYRmsEEeF6e1w0ewE0+uibIwA7Ljv1Mxq5RuMXk1yAWhz98oO0uM2z+Gp4eYZCGZn2KPdlyhACExg0WjYvDTO1OIoQllSWVzIIHC4DymfZa4BQUabs35o3uuRP5VbLimn4trlRqoIlBIufSzFOR0RT1TfIakx92cJK5AqJ8EFDAJGXw/i09fXAGS7+rwkFagjW9EV8jVFwlmZv9HpWpnLLIrJZmztCRoaer19XkmffThzdSXPBwy62qQGyWbVCEVmr6mp/bfmwcfLb0z0JBN1CH53T0lGc9Gc+bapmzs2GIMD5YROc9MbEgLsqij8FNmYXDQQSPY8FA0dOtJkC43HQUOiqvK2w1iJKGN1BqpHLt845TGFryppzYPEiOIZUnO9uk04tvjEzYP6AoHCj0Xx/yoxJ+Z9AJvRv14yiWJXMAW7nPEQqF6kcQaVYREnsuT7vopO1b6ckhs/IBdswRb8kd4Rx5TxtFv10R9rG0IFOJT1Vju9RJlj+mJSfoFAgzXRvKLUlEtmEgRiCVdtWcwBl2yYyMv+BxR1kCzA1Z5PohNPhC8f4a+BK+DCn6WNnwU+mh9EBevpYE5Q8BIhjjNBr2PH3WJKiiuqCsaQGef3URRyI+W8vD5rjlyljgH9XtfnTcYKlZRjDTw2HecmUlqcL3T1mbY8n4tMhN4Cfn/2zzLAreTI6w1x4aFLevDpskiQCiyuV6rTN78Bi9P4gOcNTh3DC5akRqRg84G+UKYh+NIG3y4Zrm82othloYPbINOYKmT2B+QHA/qpQ9OmRbylYHWqOAz+M7rq0ik9qeXi/M+9dewJSnVgWCKASctJk3daE0Z95xqLAcOhCPIVUBPn9FtBXU6LsrwU5ZQmp/r1C2YX/uqESYGvFyOOJqvvtRBvXCZtbkBhWR1bVPbqXDERyYLGK3mUTau78gYzHPrBiKKPypWM/rjmpMQ/xLOXf14zNuw4dQ94XD9dReAGqJ71Uu4v/+2xYrv3t/AP+8fdX6efdOmheI75IVJ7Hr2bK7lQWluqfoG2CDDOW2j1xgLp2939YSfcQUFI8/YBh4xmBOxZdvMhzz+ZRejrBbtnlaeHceaixyzYdwbaHalRrr0SVYUdkK3CDIiYBN+gWql429D4x4//V1ieTEX6tIR1nOchUEq0F2oevk/fFf7/ms6Lf4FkIUEswafNBmbJzbyXQm4qqv7sSV8NiWB+B7XgDkdzcGvemPQN6tRZYVGlCjTCqcWF/4U6cddR5lJGqJ3YWc+XcX8Pivwp0DLKW8bPcGbCdwvbfsV7eRl4KMEcX2+8ooFJ1qhpl9MtgaAirJgMRyFrDY2MZQZsP4Ezi2ufUFMHaMwMzoaOlY9PC8B6+pYCR57GCkW7mJZUd/LFyqP3au4BMvAVPs6TwX4X2yYGuIqmoPabWDVzEizNs3OwRV9PAeQ6/TCOzTS+eS8p7zucuoiLb0KxILYDbH/6PtLyLhnTJgGWzTqn5Xr7Uh47q6hO+3dpb0RsESHh6EcnFbXV7yae+tcBILmqa6UpsNuCqFXZtZZ9FbNDs2pocFBBVH1voYdk4Gex0+EX+tv8M5zyx8hJh0kY22RJ4NQxDsoJvR8tBsJVwmCALV7P1bPwhqIEdQLyIp4+hMUKNMy1YrcR6QW/hfU/bHhwiiKw2/rNL7yw4+gdPUKLqzb6hu7JI3ZCwpSw0Cm8h/gsWmd9t/wVWhxFwrqYxpoV1PwqF4wzYFox6O+TIasMEF9LLL1vaBMpFcDWmV0BIJvRoiRzB7XnwRyt7TCX0/YMjTXQ8x+tqdhUftM2DFkKeTAzrK8ZJnbmlu+HTr3Nl67Ac1OxB/EP2kdr9WmiTo1NkyRJOM/xgCK1mHxXALgQ96Evb0HD0OnrlXfunrR8UnXjbVkDZYAlfWJhXVq78a8RK9IZB9nfqapBfJ4U2cmXIZNUFpIbxdq2yxHDXApToQ7Lpjlqcq8lcFtxSF1qFLzI1mmUZEFTXRe9OJ4VxyHBNAjrgzaekuHXO7r0LzNUGC3bsUM1C6Mg3wCEnkD9ROGOprusn7pUA3BQtXNZOeQwwij3L33quseiYkpOjU16pnu0lrpbHwC123xCJr88j/C84xunJ6kY+CTnMniYKc2v9LXm4ny/O78e+XKKqGIN4apf5DdePj8UlTzYmz2vsPpV6Dp/Rem9f04n61TF/6DlPw9rcN+t2lOxcYxAX4pmFB3uKmpFoNKBRekcl33QiLFkSDaFtOuQ66JPXLjkHg3ULypwRhKAKCxZQ39IC0qaC2ywSHPJAzvkc98k6ch8gTeWN7X7CCD4nC2wlJRcU9cB2Gj9ie2ybqtzQLW9zzn1FZF99+zilSZr3Ao9limWI3qhHReO+6fnwxK5bMZsSfSLrT72QsLT436J7NPMxqrHSUIrIa1ks3psO7sacM+Se5zwqgKZ8ljaNZj/V/IBgznlpQrGhGRlBO0KQkEyhOmPwdwJxQdqFc7qZKF9sei7JFRqTLLPTKZ1dg4eTnioah39sxbqZ9KF+ZMLr6EkmELDUQtRwJf/G7t+eggnHOZvsX4XxIffC8rhwVrju0pw7GmQvx0d34c3Ec1MptFb/h9JlP/KfWjLewtjImoxvIbPwsVsFwET1J7+hZvd9vXOU333D15RW+/7h3BusaPWhVgTxcZwfDsxvNqfIoTNTzjsR/NOjTC0kOFJmRx8syZvLITeMCBdZvB55vPA0FmqJCHuBjqUFLO97WoCVJb6KrjJvse7607v8DVTz12jvRcE9yw21a9cRuVKn/NvYTCnpK6wKHAFguGphIUnHTY0Hcj6zfpA03+KMLuUBwdaJ1aQGm55YCkcERhK7FMvYr6naqZ46lkd6qM7UhkGmfDgQNNe4/nEGj4cjKmMavqY1nwVDDSxCjjKY8ZLN+K3kwsRCZEvXWBJrUmu47L6jfCTH8HoCOmIMb58VmI+psKU4ZY2L/L/uUmyn3FYrrUHToXi+jcMOo74biTnuUD8Vbxv9VuR6m+/S3FCZqXRLYHofxt++1jN9xT6Rtn79HX+rFL0WkZ0zWd2yFJzJ8oH9HEVy/81+jeWmY5Ay65AZYUAlFlMMaUWQIHxCoHqUN8h1Z/tOUHogOTZ3empbqCvi8y1hKAwn6X2VfVEGWhtTcuBhdUcpjGcIUMBmT8ecAkgBlOeIX9BChTul/hl3CEwGQVXD8e2CAXj6aqZpu4uYdBwewlUCmlhyMacShLW1Ja3ul23BwougcBxsAgclxPFYPSAy/35lBzTkbdvoAsACTWA1Ai2aDUHUlgDBrj6l+LycMGwaWFe0ZhQvL//aFj0/mUBj3RCqYQai94691m5RU9jb6ec15cC1j+hS4aIeospjyA31d4Gsh5XalGxWPWzjHDJFxGEGIQJfgmrIHgW4lJ5xRjY0mAVg9bVFuU4d3Rvzs57HP4CtGoiO6c6yzxhB7+3BShZWkny4I1NLTzJj7RzlAJEuNgE8JmxXhTulu6c8Om58EsEymwZpX+mlmGte0xi+VgWpFBw3xlfFyOARh3uKdPQCNjSY0eYZ/b8CgrUJXRAO+h1oM+nQ027UIaIfEPbxo2ByMs819hBYV0kJpYHwj3HTlTiZ4giVKE2Fqv45HS3zig33ru88x4mnXkCz5j+6bEWVJLpkgvKMEdAQoHQosVn2LDwxEW0Ctjjj4J5dEekXPRR1tf73KP8rwAS3f84HF3AdXckTydU/yURGOiAuornirRqBAm06wWZSLLtcNzU6oNw77qTogbanwuWuMv0mIPUAmS+ALZ759Xu8yOdjp07h0ykZB5NQPMJ22skkWifF7j1HqGODvS0xz9i0203EJ0lWBP29BJy0THvWAOcdWYv8FqaGJW7VfzfX3XL/cr52SXMTWu1rZ5qHauVX/jYnxsqeFhcTADSGGjBvzvKgvPV3fSuqfDyR9lBreTS2iuhJuXtT/acM9op0Z94ESPQjBv2BO811x95ZoML1WpPqeiwxaKSYuo37fzMc0pSvqyj6HpxP1FM5H736v/+42AxzJVDJO4xtmGeja/ViW7hqcXjnnDbErs4ITsLIKxHfpVBvBM0nu44QwQ+fjjWzED76kzAQxfKHYJqEi1H82AYWb//pg30yqNzhbMMJ6+bwO6KMkSWuE7YwVll0n55WIUV4r9pxc4GVhjaeim2LC+AxMICWfPYKkY40glxYU7OWgHFWRR4JTKogkqvQlLWiH7bryVPpKJ3rc+NQc3E1X7hkv/nOaXO83zyJXsXLMRh4/ppKfmU+dEDIDK7lCxvnNu2J0m9c1XEl6lcK7at0VEpOMcLRtn1I52wWLZdmn13yvqLT9zO1t9ozkfxBIyvYnJV3uLvq5GLn98xqQjooJBb/oyvyJfMeUWxP1NalxudO8iCYCSP2au7UuzQRdZx8KQyCY46Y28nufAFRU8Vzf4o460MYweuGJzCBd9lS6lsiTaw0c2PU/L7STib6sCZjlmHPquH6PAXKOq1BhFkcNKCW/CaqyTi5wTHrSOYqprYmDFn7TsuVKApzO8DJFuyPT/aaC7+ES9ajByttGLANcfbAfdUHI3QCZKnnh8Qv/hFxodwNTL76iG4OfQmJ198u9LqvDDQvt3nibxWshLyW9TDkWzXMWCdzeMVx/3+ZfQj4lVCAlmK/C3hSkIrqdrOMGYYaOuDZjnXC1fOd+EU7ady/2Op56cu+yLtlDsQknx5MnLsrvFDquxWr4OiXuaUcJOPcQuIHvN2z05O9R1kyrrWBUrDs0iX8yQOBOV9JrnLuVIpA/UX70J9v7CzWiXAoQg6+Uot4ZknuNAh7j1PmAj0RpENKWD0zU7pSQOcwVNEYZYU15fcLGJ6yCviunl8NVPSr6ErS1pAGOsLiDIuTcffFIFcSU7+qgaTZCKefGVdwfjvQCe5bbPtOFZJRJLsaVm7YGhnpwJyqrzXEPW87Tr/cdYLjC+IP4/7buPd8qK1qJLzqov8kZp/CcXti1TzL4uuaWDu8oOjxPf7GZelgVoGEB3I5Mptz/rfwFhnRqTmnInHWPptLVQEvbDAHir1dbPBvNcueneeBx8s1zyvEAmiSeFZZGXgyR4Ld5CBKE4UikQBDDgDlGEZhlcfRbrgAgnoBVDuQLgw2nFaIiWTqpAF9M+zwvBcSpevbfQHBkEjP8YhPqLPfRNNXyXo487Pl4f7BakqUs5LzjvlnwSjzJHw7pxWM2XCws/gfP859TLbofN3Z+ZVxKIjuqgtjt6c9R/IZCh6CLtmMC6+GdNbcfVByBaHBXph0d88+FYcYqFMjS7XLs0TEVscJE2ygI2dUwxCKEWpWcy9wufBfqPbpMw/PYGWBSizkjqgsCHRF2MfJyMthqGKlnDT2/bBKJmA+KjGw0C30oUDB/msRKxcBGmdUMVVI1IHKrpHhykkX5Jgx3Bw3B95h3qoWp0e6Np1aTVh0z81jaLpE8jxyJEDIybFZxrbEUmdk9keIajCHtiz3j4AlLjUqdhIUb6PJ8cQNt9b6UXzOVAnN5pj3+QXc+4f1SPD4iUg2AfmXtiahhHGu7mBUDd6gYDim/U01Zf7cB3PSNyv1GHUqLbXliPnFbEI5/s/sRZDg3qeLoZ9ZyDqu9YE62H6c9oNl4UWT1T799qmCQ3DdrDYO1SqJlmYRxjsIV1a0Ze/+E5jnxGq+oY87YxcG8r0Z6bG7zoUJbjIJ3jwyqSUxmi6aszvqOGMYwbJohWIWVN3i5b89uscKM+HYq1Xr9CWWBrVZcWkDQ02rUXyoiJ0L3C/cnuntrvRaUdAigTthXf7UYf0jAYu7yj4YIjOjxi1xHF0E3Ecx05ag7VDsBeEKfNawURc8g7P2bO7qKFwYmUunHXXacJsMd7V1VSZ5x8hmKiAJ8gNer7+kS6EPIGgqeg7iZ/UB8x8AeHtxgDDMu2+9oiU0sYBmbhYGc4rJIn5dDbFbdL9sowTwJZ+V3OrxMkgZBpPH580yApB3s0cnW3Ke0YkRFrvV+ZpR66ISPKonQcqRGcbg7BCionfxXr0lgEFuRRan8X3nAext7EsDk0eSynVwt1Ur7RDrE5GLLi+ltIlvSN6j2ws625ZKjRKhN16SsyDi9J9ircY/M9Hqa8w40HtptI4XiSh1VseoAOBdDEapRipS1+QOMrT2gE69oTTOkHjnURNHymjAyLCLMcbrmn0/OFtt8f+kiFrw5XTG9X6F1MV+9AyWTGms8Q2+vPz728T2nQ1UK0BIJImr8Bv7vhFEwn+gLQMB7TVYuJM2xhb0UjxF+uzo49+bu2/5DGGp75LCJZsRuXCthMZcaU8jWGs7Yta8RamFXbuKZROQO2TiVtO4UeK0emvcIxamXn+nfxZmAdVaxX9GvHh4ZSji9lAswg0K/HX2oleDzSkjyosxNX+0nsxxWbXWWUutOXK1SjEtuaFnTtBRIZNLfEh3JXZH/Apa+VZCBRAMujmlieFyWpwiGYehWCBMO3KPj2NRtwJYXz06PTSz6UJRLwNBNMbzvc8WKdPo4ogMxCZBAh9MwRbx1POmOue7cuJa3VdpHHu3jgVnGLd+u25kxNPEkmONPWyUdZv4Vx7YsNNoi/0x8aBjRBgJVrf+BF+D+07IzGFyyPrf83iaV/bY7hPsVrzGrVtu4MNNuvgrizwVWjMoTOEqd6SVRukFuQohFJ0eOu24Fo7VZdziS6RtMBPh28ZGmfEb62THsBdZsstdL8518CdKt2nYN85sdT38PkAjZkPOi43szF4Kz0bcGlZAnJI6GpmeON+QoHbyK9E/m4F1la6klLCdTYPt+pF6ACXf02RXHEzzunsK4mHNfTzMtOTKYeyWgGMIdqonW5qZEKFbr/4rzMRnmuiKgF0EuEGjbsVnHiOtcANkuYHBUte35zV2R0netpY15agaJ1x2CNaPJxvRj3yt3HeWvqPe/1Fzx4IEG73w7kZKsZw3UjKql/vBIS4fLZgtGIBRr6j4dcivFO/rdJ5YYJR+i5QtBdT+ZVkArM8N3TUQoghny2fGdPLmu2lKgZw8fwovbIcR+Jz7kiCC8UiE2BUsZ8JimEy65rsFszk3xn5UXSsQXce0vNJpqL7Txq7fM2ScAYVRlefC0a38IeOb6JJiS/0GDnRSVS328h8c7S+3/RCiPiLRfO1got4yieIkwigNP1klAMFIsJSj3ytyW6d7hIJ0i+xMr4bUdnxQS+ilC6w2JP1RDescm47gbtK9rvrsZoylkcwQ1HJ7CIpgh+FjGTrxD5G6a/2fAHGIlqE8qPppGGrNqnnu30+3sFoDOeC30/DuIZavJmK9UDoIgIPuKh7qiUYlQuWCtJivmpcLMSBUAqXCQIE2lj1AYRVxs4kTi+NHcFZXoQGkzaU7d6nsKCKMg+EWY3SthE6rBjks/21xJhuvLz2m8tRIGrRi6cv3Dj1AF8YAf1ele+nI/ZJZdj9uejwYUHemOiicpRXKs/s5g0wn1/nwfxkmtNhD0rZePBwTpFG1OGXq+hv31aeuCGfGhWBL+gQAzKJqv/ROuAkiSIlho659YWb01zGUoEKV5EHMaSTQ5ddWk84qpbhN6pHLluWq4H91tsw+IXL+V6hYpW97KOBeCYKEbEH4nKq/zyKRUhvzKsWoYqPNMlPjiwuJcgrh8+3/23hd44mf7Rnz602cZWaIRX9UoHPN94ZQFdNfetU3xCiUXqhLLEoW0zzDVJhfhpoGl4B2Kl3Tb9xJJY2wuIhpmzsUy1YO/GdwWtjzk7Cvpn5XgF6SgQhOzFwNdenczli9t/OCFJVSQM9iBcPI7OaStdTuUGTOOv4CC1yVU7eOEq7Iw5bXa/3YuvD9pMShliL52lhW78eLcOoaxR3y0DZBvGihDU3L0F5VYIVBJ77tMUZ500csKgzPimQMQH/hxxZhftQgUZzSbhAVHP1zfx9pVcDJk7kap8xaOaP3KAzJgx+EPuIiUSbNhYWAhjV1MpmrLGGfsrXmt8uuEX1F19+mAyvxDegQrtKLCDeI+pCaHi6PBVlMHI5K8T3MNw7k7c/2oLT4NZOxqiAgWKyKCpOos4thFNpagHYty4amP/PxLL/v79iRETPjQhJiHdjTMy1Oh0e+UAdqNlx/O5iSSxL6jT5wxME2n7YZxRd8BXJDKtMO/IWa8eGbvucucBbmdxLOwZC2PWzcxk48t82Sjn3KmCaX2eWeZfac8rM+3c1SCNLAyw6f5RmVSXKNHB4gT/Rd1OBnbjvbLdE5h+zDT6jLJFXiUQrOIq4qRPxq4rsvZ+8Olp7ln6IxOIaSbefpbrcebeMQ/eNB9H3RtFr6MTutovTYq0Pyk5yS3lAfmLt+RuWaohmrqhMs55s6Wxwe6IWuJUmbAM0iW3N1057c4/zbHNuncnFK4j+7oJ0+AiQFLcQMB4aWmVoOniR7W82ICSbo8DS4ZofUL2Ua15CFG4r0eMycVnw2CwXY2qAiX21b9K3omF6GMoOrQLOYsm4OEZzSBGYvqZr9V+4jwwR4epXDgplnHC8WJw3yHgv5puE8xYgiQNAsl2BqWFm24ZhpnxX5BDgEAR7FwGOJBFe9lJdN1uWLY2gQm++p0Qd6BMijtkxqKhIYSUsA1Hq7+9pxn20XW/TFUO1OQSoL0mm8d4iG4IeXEOILuTnqZZevvm1f7uSno2gerD5Xw/hdeek9Cgz/CW9GEH2iXQ4PR8KaR0n0Q2F5oRD1ICsE2/MHnejElObl4SZsu3UWBI9QM22aCIv+iC8+hgTnWWv1O2QHfuoOftG74pSdT55Ss8yP3hAX2roBTYOBdIEnFjhLd+3RcNt+Q6tKXf/92DSArehPbyiUdDlhlbndEh56QtR38z1vLybxnAvWgM6dO809tGtU/2nfpB9w4IdabdzGfhUO/UK1QIkKtYhYLA3iqpwTsM9nu3la1n5cNxODevpvlAEPuZhdjag5K47WrLu/8IdoxBNS22/8wHuRc7DXyxc8KuBe6019mSxmkY+ZsaQBzoNwAPl0hfb9JrjkthhcxoIQHOjvVtyVSbFQ76fH60yqPTqWG7gOd5BKIygYZRkpJZjYonVF3is2pWHVPzSSY9qDE3YbKg7ew4MHM1f/efd1UIDR0bJ+KeiSSE9hSbmA5KX8ijSxA76iEw0EMW/ePQcMvxqFv4D9/8dKeVoADf31SXzKGUHOgCGrF2fO9W9N/KKQUPe2dDb4KxUvVNXlBmp0f8CnyP4OVl6IYIiCPb1y34BuE4Zsf39bx11v0Vb/56oFEZq5WJAAIcXlOFm38wNcT4k5TK0L31PIbPBGjhEBv95O0w0gqXY4d1/Zz5WVkowF8Zt0u3eWYUxUWcEee/Dzgq2kUGe0/JkQ9MZdKS27NJu6f4P9qFPVKF785gqqh3SR4gBxCr4dLtwSwN3PiGWaDxXW6vq0SpBmRrqzYJ1jvOIh1zkeNbt5m0O/PQmx3ARinK/DuzfagnnVPdYrpt4wvKJOL7OsKW4zDuVZ+E8KBJrTBpCX9nEoL56CdJdT99WOtUaOqhWjmXoT8ki2SRBhNpJ0c6MxTAZDb/cOiLj1Ozn48LN2dookFNcA1iteG99zVVxtZt1v5DCTbNxMsmyS5ntmaC00PLBr4UgH3cV0L8eG8Fl65Tl8T1n0uoBYrd5bLJnMz/6qNEZhBNtiiCA8jI9JVF7nfyB8SUXeeCY+11U84wE9w6xPqQRc96B7kC9c4EX2D8Qf2hP45HwIq+Ct3+8a5+vihKFASTTsZEQegqQ9z3d8kxD8YtDAtJP/Hn1alIzyEubFqEvKwcWydBlj4kBx5FuofsKeCLxeQFHmeaV0gp4RhufPhUgujiuUizqhXY6zIKEl6Inozf/vyQivv7wQXF/gDUBgBFhjq0JVXc5R7vxpjOFt4ecJreAO6qNC0czEh9KGWvUWla3ndwdUTHxQn/+bUO6tPZDIvzl/6h3ZJEKlnGCDMvwAI9Io9bPNY1ULXYqq7XFDHsgndAyKlt6/Hj8Udf9F+M2BMfcUfaZ/9QcOoWWbLL2HD5s+Zz1bsDSoGn3scZqGJztt2+0b6iuKg3ordKrrQj7sSq5sERRwCxxb3eBtCxZatliD9a7q5O8yRzvX8WUdNN0QYP1eyrjuyzONPzxWh5GXZiqOc+OYo/jvGn0ylnYJT2jvv4tyhfa2HPaii95gIiGy8Hk69EUF2Is10Ib4/wyFvOZS0zEHxI/cn9PyB9emxQnJvia/mmgNIaeD+2mL6Qnr8ZTHRbF8YImMiEZ1Rf1Cme+WhyqM8vMOXlVNTHW5W6yO8n3GcxcClu8Qfzg9jxestotV5JiWb73hnhsig8OAtMUDlZtIpwUfD5LIZsFbugjXSQLLIH2hmGNZqNpLtk90qldRkgZgzbrR18yS626IMri2GcjnupBDeEFLMo981j+cPS2cm+RxseZGy6cBRzBi2SZrnJW/aWxhxSWbyeLts+9eYxK4kRzwacP7evj9ocz/OGMexbq+h0FzaWDBCjft850N2AxRGsWsSefRlJdfCjybK8zbrz1G4k4ujb0yWuQyySNXJqn5sqndBksvG/Iggaxlsk6k3AXFSPwnDnPROXe5TE/gFWwPjS3Q8PDdAJ/me6Z3Hg66HFLbCbxr1Iz6wNnJn5L3Tt4D4Zh2bjStOZpWTFwke2nD0ih8o+CgINHZ4lt3HxZo3Ckzhw47G53kCmbBvrdb4phbNjnDj9XuuBZgGldXGx4NKYic0x8R3/NAEuTWC5fcrrWx5XatfKqeRS2zccsP6ZWjd/dy/BYUWX7lsgXOLBvhTHHLJ5cQlPnIGIXcXolWHzlQ3RjjH0P3oRpX4DGrLm1hE4UMSp4m9CxD93WUW3rc4JQsRbriOtHC+KVUsxoSgDCHhDMCb+vevMS6e4/dYJ9sHlAPCKnQ0b9jJ8/cp8EexT45t/MenWgLc3IwMeNb2xNrK4myQmHIvCW13Hjmd5sQ1F1ulPcTvtOfxkPasEtxbYMEVJkwnJPJ1B5rWTlUPo8Gtabm1IhoSC5mAHaeHgznWHUh7mWJqPUsq5U5wqsHi7OzvMKAOr/kUJ6+AlOlPfcPqkwBQu/QvSFDofllGOpYV9Ik5WVgvZrjqOhUL04Rf2RokWyqgRoYBLfmtkmygpWgV4QJz85OM1FgMuN4KmiV+Oe/sGDKRHVUdC/pIfLguo/U8u7Q4SURiTrd14hFWLw+Xrhq20bPBvP+mA2E2TBjL0jCeNJfBqV969cZ+1mutvyLd1tAR7CIi8W+hfY2mGthfyBUoMhwaXwzh1y+Xhdf04h0p4I45MVPvX7LZXYr97NgUi/m/pYfRj+cBtAOynTU/q5jzABXZscNjzBW2gr20WDhW286rTVgkBBNAs5bagOJnX7WHHLA6pWJaxswpUEpIsW0Vp7TDKWpBAtb8UC+JLyi5sOd4PHbRZYyULYfhM57AeYG73TQmMd0ZhQJQyoFes8zztx5k/KuhXfjIJv2IULyqOoqhn2Do1eJL09J399S639hISikjEdFY0RqN83wAAtjQB1SzdJDuKeV81YORxp7iMWm/lb7TEqlV/7KR+WTJNeB8bjqT4Kd1c/uy7QmKu48LTCIMDPCqBENs6Z6DXIXu+XjvhqGxdi8WAa8JDwlCTKFMeB/K/+QOLKC//5JCj56kK/YOuxjSFs5BZyRCOikiBMJoZ7etONqmo+drDnOzuozu8DQJ/pZpsd7ovWGjE9TK3trgDPtwyaIcDUeywPUZ0+uPrphUYojAMp6LrdXdka5kgV1nQkw/+fqeBm/1sDtPhFqS+dkXHO/wIBddy4RB1bj/KPWCGBM38wTumGRH6jXUXeSwBJ+0qK1fnprZ0jZpQ4jcE0TMAEukRfm2wEne7Vn8tkCBhy8hnI//3Vcj2uhRMlY/3ilIZckoiNTAcoy7jPnn24oexUkodUXb+1bQEARIqLPbHXx5cCd8Hoard6RfdJUF3wtJ9lByB280Ww31fWpfhA8Gw3ay3Nig0p3BFZtrQlzMhaT/rnWnQ0AJpFiRkeZ38R9Xv9U6PzLsxSEJLBCD/6v9tLe2jbuf6n27/T/4QNDG4coIhzqEiPE5wP6+sXDFWb3LTQZ9Ma50IWZa5Lud+hV3FI15jFMq7aUByb68luZI9JrS1G17lvJjcj+Fj/+uThk/cxnHkeEOvUb2IGxlrpufCihtBvuaX2rFDbep/juqgTm9Zq3vLPvCGSUBWjkktBsYRVvSUZs76uIjDor5mFMddiONv6U2p7T1/9lYjem3SNDvA9Ku2JkYD5wbdB45hxcNOKup7M25kHB9TfVJkFi+tsER/QBdvPKVPi+sdyvtaWZhKujdZeZHD4fMruwjcUyVCUNdfclg8jO7M57/UVwyAtG823Szywh7S2mNS23oNpZdWLsHF8vvO/dNPHn8El1o713TKILir3jPSmR7TjY+D/u3IhVRBapI4i6KGXNpBLkPiiHUqbj+g1Ct/Vo44LtLq3MyVBHgzVf3Lh/PwMGtiFQQNXb85D/TuHoD5qUUnO5H2aN+NgL86iQKIiNdHXIA6EnO1MH26hnBmzOp2bNS3EykyuVCA2POTsnjbODcz5HjYUXl04AI8Uf7/SSiKA9EFeuPfcN5UiYE/Hxy3YkdPsmowbI5338NXoUEiTMj/HdxxW7BbCMTIPp6FJOk+YVB7LFTqLL57bZTs0lSHsLJ16JttAFen76HDyO9h4d5l0Iy2mkr/lt+lOo9Q8JksndPDW6tuUuW2RNCUC5nYR4nYjxuxD5H24NxdxF98sxldDI6dFaY/XzqIOxWwAbKktETBilqKZhIRLp7DGMHiBDh7lWDVYUTslmIl0PZjLysOkCcuMYZ1G34Hvl2o3Z6jZaWVg+yG0qDkBZ03Ej/5J1BitvLFmTqS/T5gc0IL5lJWsY+NA76Q74x+xSwH1LEZTS+TqXaQCjnZfCLmBJX+OPsYS8EV4Y9a057PvntvE2nqXKsaZ6BmRuGrJlrxLenAxuJNBqBNlXEc1Y5Ed0res2GmA3OPuTRWoampNOieomBYGWeFM9g23qEwGpj5qEs5IZOaO7QQdss+HuT1kbUSnEFuBJnrjVVAvU+qorfkbu5HVpbCKPBWqTc33I53pk2ngpLXWXIgotuNTE+BrWO3MifutxS60xNu1nEEVKSkPutm5pIkNljDznGrqfIjlgEXXPO8/kiRFXSmRwF+mb6qGuWfQDFz2cp/t5aqnomFzBTjC3QLeiaONcY6RSlWSMGpSaOoIvPwa9pVbUGzx7t6udm4jJlNpxBd/N2APjLshclr/TuJ34+D7fuIge02SND1wLzfS5RtxhzzdHGgeAvxf3C4hUREfDu+QrxDa5pI3o7vmCf+xKGL6l5iE4MDJivBIfe1dKIWHwuGWNnTlXqc2sY5y9Q758Flgg5WFw1CToaBCAeLBSnSPQbgLp4LEZQIHlljnwll/GKEDQ3RCA0GUVYhnXX8Pf6P3u/Lg7wT35ZfqJgPVwDSMwnCL3BTQ3B6rRKzBNS3d6F1NxdFx2+X6OIdHHzW8VTEvLkP8BzF6Sz7pgopurgUQZWP5y3932gDnKzQV2/U0hN9dAAlS5xkTqyBHBJc+JSisIRQ0gPqAtffof5zce7Bv6b6FFiC5b2Bk9D/Gyt5oZeNXuGptQTt+1iDA+ePHrIDDCPDD4HG5HDv5jkwSnMLzzcVKUkFxF/3mFq+iCteh2lWdh/T8YEVtcHkHzRJXw+7gNufFybx9nxDlgV+j5ipenLyVME0pwwJ2i55tUVq1U/mj8b7yP6vnnu6LGl5HSDzxFoYaKmksZP8N1u3BVO2YV4GCl9j6i9qrkGsapq5bIn0Ozsng+R3TwpZNSxXKLxaH9PdrfE0c4oSt1WOmuvCe2C4pvAv458OOL5hbEmqW/X1bIqJP5856Q9zEMvjSeWv8IX3nvWSIHBuBht9CxGB0+yyq3z7UkQiQ4FF+Ot+p/FSX5/5cqwLvW7gA4KdXE+4x1c8WA+veD/2nyqPaNPZHlXb5Ce1xQkk3I9KRjnmT/wnCit1pjTK88RGRJZmHzcxbHMBcl6yLX7yGWUg9f9o9B4B5LqTP1v/UeFM4TjdrTrU/DEOJJwA+jt7EDBwKXBdkChzGTKARBhBMlXT8Zh1eo/J8z78uUl9Un/dAWBg+lg9/0YWjcsrqcvdvNrjgz20ouEJ1NS43MvtHEGMaAlpb+JUZq+lcwaTqPmOmunC/hmanjdGuZHuzw2ftvAKBGt0+q5L2s7BCqKM5guEgggTT9n+fuLuKozZ3heCkXBlXQexa4i6wkMDl3WH6zGo1cxxPTe+kQlFXIxO7IAcPkbKLCbqq2zwBqRkfp4OxnbC9W6OvWTUUOaajmwqwHBkCMn8ASknPFjYuuP48cbJXpIQuy2/7G36PJwKYQ4EsbAkhWhPecEaLMU/YO1LGwDNGrWeIBYYYwj+aAKvngA4Qzy+pw3U3G+LKDVvzaBcJyVxqdx1chlkyObvaIzR83J8iQ/FGgWO9zZSpOhvEpaEbF/ZmU3CNAf7AB3+IGwwHCCu87SaellRM05+m8VMKo9qOgaJ/heHJmgSjWFBdRmsX4gTF6vv8TNdawp89uZeYVDH1QomRoHBxkX5DAQilgUGHvya9PS1ZIFLwsysVqghVpbaSxuiqVmhOI5u5FkMK+9PvmtZ3YQC9fFjUZpt2K8uStP/f+r09KkW7S1f9c+chcERgiNuEX0LYAb+bUdr3Anv5OY6Gz0yrW5HDf35oJMcu5f1MAcBpcxOLaLIH+28hsjFQiOq+EjBgpiIWMJDRn6whDkaLmNUZ9dPRqaR9KYp7akW2PJUO9JGYHA291DdogFztGTxmOXjAPVD7CDOwi1J9mOE12yYgCQw4+Ii19iZVhtNiALcD6Jind7fcKwQcS/9Ofjy3lZLEZ2OX6LqUrhL3Uf4GoqdiNP+Tlh7+bbtNnCQSmoBtWnrQyqTNwcinGB6hHmO5FZibWOkT+ksHqLCBM9v4RMAjlgAHYE103k/InE3owjbZyBRyOTqKq+w2YXbMfhmFysa1PYPb+Mt2otC4T7ErKCu+Jl1D//5U0sik2siHu2o4kGIm3tKfLRGoycEqQIQKnoU/+YrlnxA2x7kMCL/pCZmFoOtARcue3uxQJEcyec4Jvd/MWrNjYtVMD//bjID9BIMJaYIYIlIC5T3V9Id4iB1KKUkP29T9VW+go3KszY82YTZggkdK7cRVRnU1/rusefKHudWq4TwnjQpSaNeK8yzzaSNf+14ACvlZnU51+I3TAEMPFWqsC35NbFRvbOGLWH7zwj7YKtAq/tVKACU25w3bvZggFXOy7UZf2xCgrOsYeJ2KPBj+iKX3NOokbwiUBs5iXhmCA5YkZokfVaqovppThotajouCBNl55J90DLS5tOV6fcYevLu8z7O8pOFEeBLBkLIS0zHtetKf4JO6ksGVrdZTPKcCNK6rbCCm3arvLSZDE8D1ty31/LR+330vL7LTddcvXV0hBFksAS/9BpoKDkXDt0mdKy4RZMqIyy0Q+o3uVkSEx6uXeQnjuVwaNCIasu0r34LrBvfDn8VpcRnL781IERBy4k5n1MU1OhQkZ36tbN8lWOUujAyJBUCpxA5eiGzt0rTg/AkPCRf3wylJDOytRnGxMVAipbr6CIBr2vv+WkXvhb8ytBxaAj9RslHGcrkJ6T8BYlyg9hgCocvX6oUT7OHndWvVFmUl7sCUPSeVOks0w52Xv1g+KZRXWaOPnUVwif6gasJiR00S4/Q0EtEPX88hSJz5COUuFLM2wJWRm1Mzf7BaLQlN+HbsMouhshtKz8Wv+4ONso38ZaXFTGx+xfRslC3EAQSZrdc/5xXWqolLKyu2j//xJOOd2MJGntITaHu1x3gzZUHbGLIBe2eIxey7DA5Te2fqCK0fodI9cVNpqvjiUV4+b4Pbgn3ZK+vldZkpiKk8VjvBpzo5RDnwHUDSBgorafivqMaiKSGQAsyOBusjO4+ZGbU2IHUf8Y5RLgczX4xM7fY3T6nhK/B1mc7QUkb1RFXXYHikUU5PyGrCQ1SJg8uxa2TK2olEA4tmsYtWUEfyaPHMWt9qY5oTewtRX2140T0UFcUQ/rYoatJpP5S0R1ofFJCCVZSqV5WKJC2MRw57v9/kL43PBNMKRKLcpNaR+0zySMInDCRmoqWMga9EwR7p4cVTeFRoFEvfGyJZ6G/Mpy7gIMVKuA8j5281aDi6TILYTaIH296GGjkxNGeuZQfpF5E1gVJpuIZ/ycU8yl69pYu8YMBDjgEFGFzcxq1SuheOu1vzEA74GpFp0Oh9UlBRYhTke5yI1DyRc0R9V84t/xKut1xqf6aaLK6P3qYnhF4vL6EHA498kZR0OC1djXZpwfeSTaDOT2IbTZ6t8SNJnctipfQloROQ+pjOol0boOu+7QOo07u41rnu4egR6N97z6/rtcMakSIptjsjFOAtGPfjz8ojZpCgYq4h/S4NdYfgHQqg3mqFQJAD975RK8d8CKfRBF28ONEzc3QmAfoWn2P928E/+vWQDK9jx0iWPwexdEIYuKcVkV4rzdvLwmw235aNUdV+iRyam19fwWaTaKy1YM+IjNXmowyQ7//b3w5ri7iSsC68jO+VPw94+L5XkeWofxyuJkAm1FmQxCtflVwFcZa69HsN4wJvwhG/f8Z74NhDEHOCpEuoO11D+rySK4J5vYG7yfA/Uzp4iFhU4L/EV3hV0BGpIDVukK3HECi5/wdAiaJyaZKNNZPufonDPnZpQA/gs4Jj8SFxDPpZCE3Uo9nmxxGMqODIBXxpjd0bcoRj60Lh5BpYJDPnLWZo57mfR2Fky+2QPpQNKod8db0u0tQZcALVf3MZIBTViYdHiUydoELIDu3t4pL/othGEgUBKDDdYtB5xcNpiiqn9dvOvG7LT4eVM3bHY7V6JwqibW09z9TFMX+ymtbClH1Av78yMa52C633tOqXMuXZ1PVzhm6ITIcTP49pQJPRae0uUpytz9Jv1N0MePy3ed1c6X8gK8cxFJSNwgAOIh2N7mmv7s9v9XIrWwn/errYyzkdxlZP7XGzVQV+3gAvP8K5MDBQ7CsEzHgzMpexjn3LNmq9TGNKNS/IMwIdpIRUN3m3Vd/tv+LcvmL+yShCA7ZFa3etmZTLp6ZzBdxlG0MITzAOIFYWt7rVUn00iIIetabkaPT1ivMz4+OAemJQ+iBgmJqQNMmB6Ssj9VbMlSrTBLXlS9N1B/ml/wQYxz9yRNCkKazvWKoUXwNIn56mSKSXhsWFgWqutanzjh2v4FlZ1eNh16ainHpTU0cUnI0M8/Gx7cotda2c0vEMRjRL5vyFU1Tm98EZEwtySAhT6a82xQyzQIHRdR7qdq5oDgAUQ9zkql79CR5Y5+BiU4nwNpamIWVnBLXAJoxR4zZh0UVQFGe6j1VISEh+MXYySxT/DQKyCp5ukn3SRRThlHPzNGgvzC9eeLSoSjBqteBRsDA0+oteYbU/IG+lSuVk1LJ2tNsz2y5QRwTkY/biTFZkV9/QGiFdhHdsCoz/6jVxt2w3i4xklhUjkFV8i6l+4jSgq/3EjhD4Z+2H/+fZWiUqFX03JQw2uqxOp9yI08mnAsX7qnmzonIqfZhgTc8yh1Ix/FzdtsC5PjDUMwjwQj3ov1ytle1rk6ORv7T4YZPvswynETU1FysNYifbiqUy07qfeDyYuN9JycxFKeAUxdt2aAc51ENVw5cxI0hL2W5/wpjj29S2yISaSw/fHfdwP0Fe4xox0M+kOZ12P5knMro9sy9hp09A3y16uoh4uXusJ7hzur95pGIr9x9D8sObS99LLhQkKyEu7On7ySUVZ0H1iWlYtPMn2QryIhymZbOr5DtQqUFcbs+nCWI6mGWmLozKGhC3c4CMKkJfpATWIzHB9SDh3ha9Z0M1Zr4HVHjJq03VyZO87RgNE5MukQzkcttonU3T4yQxF7GR+gwMHPqnZovktQ3VqKBAOKZ4qjekIwCioZjgzlrOK6JtVLmEdb6MQzE8X2prPS2feHSXWDQw20NbSYepmRT/+ey1oBQPkHL9MsSwfWkLNSvUEBN22qduWVkPnqdvMtFwoLMDmrUAvCf1i4+ZqsOHiEC/ptuuWYK5PQfeBaEZxZ04ihAaToIiLwBBj+rSWIzXqDDCZB4bhoyqrBtcDoGB7IU82ESmN0jz3WFRDIUSTp4sSvNdLiS4z/0Vfs1mOl+ZPh++X/TnL8bGJfzE9c3XPFcL20xaKlHypL1Zy9lHQdS1u/cwve1uZG/YPE7SIdYYJJ8jjbR09a9Ar5VKJwsa6APLI/IzsOduzFudZqWzL49mnPnXDKi1P72BFKJRMcW7BsRpIvC72Pr3cE7Q7GQP6CZUojVt+XTCIJ9R+NxpCJT+mXD3tohzX+Ze6E2hoEQMYxROe1GaJIIuzD44RcVUcStzR/o1XH+Cy6ffcpU+It2vADCZ0oTXGgke437E6AiMJ+R14KoKmWAuLgpH8kC7JtRXsoK7hI8iRuyDdjRIlGXDgSfbj/5K/PdkQp+p3gaN07ADdSUt+U7uD6e15drqKPgNtGm4ZXnCbDg/fxdmjGKIZsj6EqtvLGZRH6kkVAi6pfN2vea5baiGtkSPzIFfs8N83RQBdhYr/tDKQUFaejJcOX7QMgWvIm5J7ODgivsXT85vI5PylikYRrzoY/7c76xM7a3qv0Oij5r/MmKEyX9qhGsQ2PPY3d9iCksNm8QFTSlXH+9KR35Lc4aWez8UDRs1OcUYyvXfbuPwd2sVH+zvX6sBhqaYTw/p+kdTIr/JupE2w077XWe7+FZU9qsCTV2+DgDmJSeGK/6glvGm1mJ5PYDUFLYY3KzHnQo95D+D55iPeixbpCCIo10m9mRtiBIRDhXgt4f5E0vThg0QYm2BgznZogaGq1Oxh4TxU/cC/wuchAeNAG5JCQADUsXATvatkgI50IpULkfYdWn8+8FaNcryfsvhRX/3AujhegyTQiVJOimdhefoFkeCEdJeTpVIPLlF8jqw73PNUjSVECxLqn+pJptLoRiNKxPXc34+WVUjmGwZhgW8DoNw3XkMgFpvYBoWP0qKQTuSs0MatGdwerfybtR7+ebFhsjZXhSTbU/KIHHonkjNdbB/d2Bb1HdTcOty/Q3qhhqPB/vZQp8+Tbi0RnAKDm1/eotgmyHQ0Kg/P6s0+SxbFdcyKMBY+hMFpOsup1PUtQxXFIjDOTp+4KVHzxOBUv+bx9mmGhAz1XxGWs0ISaiozkgtr5v/x5njtodw7olj/wxdN25w+X0kUW/MMJSeO3b2dSzBivSmAQTV+wXq4/WzUMdjwMoOlOYxZlXt/ersjwbltEyno2e5+Yc2q0Mdn4qJqI4oFctyCxXihfGOBvMLeDMRrNGez+riYomGnx/3QgyTkr4kXaHuiImva2zbH/eUWcss3NcqzVEdq0vSqWx39AP246a9C7sVvi5xJA8UF6fmhLyQ9KpiKUFOeyttpKRBgN/dFw/fDGmWKtGGNnSasTU/Pl+1VqgpNv/CmgzzJDY8d9CEMzESsWcN6QG6Iv/BU+rlC+b6VfdFqme1M1l7O2+WiozHkIeS1QWmqltvRusYd171k05ZlJPgNrjzGD4tofnDX3zPHYBW/asn+72gqIf9NPWoTuv03DvNnV2yGxN42tK990HLcM4vNLxBsgP7lAtVrbzPMO32ot2JHg0/qch3Clc1TsnbvhxvIVDN2fBxPaxUWYidluPNF8gkBEYOEpCFR3YpKm9hChT8sC/AQMJPqxyG5VcaS9xNWRlBNN0A2iG09Wr04C5vH7EGR9AcLQua99hyMgynSnKiiQhmmR5eUk0vDc0+hIsHBambgYJNgHAAbT+xRN3BjvxbnyFdWLnArlLPZRhOlofHLCjVAjOx+bk51Vw7bw4eLc1IxlD9P/TGSaQVMkVpe92bxIuZ7T5ID0/J0rF7rYSx6iGzXTH+99UtbYLzgVblMmNGsXqYoBViAriAXNuy/4fnW6OFgurue3passhMyR4mCzs48oB3eTtt+EbmGgTJW/qzgE11HQD8XJNMPWraDhT7wDMoh5xKLAOZNQDQVsfSZl8HvfXJa70XV1/FF48OcbHnBX1IAFwL+E2mJ1pLkV9VcvXyQt1AZcZVb8tX0ww5Sa4TN57Vy3uSBTpOXBMNyCAhj/JIlv02VZPXJVq1rS7LtqbPNsyWdHpNwEA3Z8RfG/pPhZ6kkmxc3i0FFhIhsqLj4+TmxG2s1y010W8GWvawbhACgvL5Ti2FXxYy1RFFdrch5K4fp1SK56O9WI1rT/oNx0LYzTbMU0vdfGFxfwGw0JbfvhNzoMmj8Z+SthX2gPPu6JpVMayMXmAT03yiCA6bz6Q8OeKfi2buldcr2SgIt1ALbTZ7DYd5YOyWoXIHxf6Y4wymFoKaljEMACGi8nYGAP1vs/TfT0rNjjJeAuZIA3KUgtUOisJTp9oj/y07ZjF6ibtMcZQd0ANrZAjvV3GYZqIeCOR2gIxnBLodv8jb1XIiM7YxpSGPwWPtVPrPKOx5x2hzl/MUgE/EuXicKY9ftZ5jo8cEcs+ABRb+cbiQsdyXbPUrxZ/XlrFGmWL7H8w4sdtzJwDbVIr1eyPzBd/H5goSSVfCy+pr0Z/edttNN+SzknIL5P1ycViKoHuYgo/CH/TF/MJxiSIxAuQfXWYShuEXFg9bsF+TJtIbgiof6HtC4Xb2xgwaC9FO2tk5GUd3MYXBsObgQ1CbfIHpk5LRcSVFFqAP84u0BtGnDvTaGrajp6hHcs+Np9vVHyg5i6cUHtC6gJZ7VSM1aG31x/wAZEFiqDyuoYolYpyOtF9ThdlTLoHbaddo5UzSndmSWR5uQXlmvvVOOHvNKUqcxI727Fv8JCW/rdL1uqK9OP/rUczKpRpm0QWYg2tb01w85QuEvU4T9sFsZ/0DAz754mloQr+60a/eiTTolMT1pHH8I9ueU9hVV3aCeKUdFl3YKZkCsPkfigkttZ1tePCNMBRmU5ZUtWGiLesZyuG/Wu1lxbakNjV7xZe71fvDrjeSWutdyX/uhJ+u9GbyIctbBj58RKHTulRwt1mOWz1JBEZ/PiUO8j5BG20qnW2R7SGR1sJ8D8yg54Xm2dr2NRUdyS4mPiGPIORxTLS9oLR1ol/66r/T+nJP6a7jgzxoZu1oT4ucefRrIvHOmwYK48BD5BNLQWczGvfG4jc5NrMeppH1rQWOF4Kip3izHlQB9nTFaz6ET6hjPlrVV9bkbJyPeRCUAhduXnX5SOu2belOpa/ctqXzAtd3fIPaeJ0oMLWbxMzCJFqV6P2tSDzoV/PEKmULxZME4sjqzSxH1IkN2ZuCsYG/kVei8BB59g5qNJgD7eV7Ugb82f/5brDZNqGmg5zawMPPgJSpu2wmZ6D992v+qwNZ1Zc4iX6CbnVbS8ILifIg6fl1CdhImBoY0QpLtAuSBtrC1WZw7B4dcJnbmUKpwZgzBWKmNVDlayNrU/SZCZkuMZOdfkM59P3YIRNYc6fDdxeMTvtWIEwFlEZvduXEVw0TX0oGEuMd7pydAhDmgUsm5ec2MJdPgyGMMv3xv6FabxcOiBt/sDGdXWxdh7IYW6FsDjhYGEQUINMv8St2H04X0h/JbGPKXKsuye6kUiuTwC305QF57Gth3+doWR3iuFxztcNCxS27k1YQRdCuZe+1aMxh0cvsLaRJcxA0+YKnyYbOJmhrxj3Ot29kx0PoIdytxU5UVCUIfEXRgSlgcLU36OzIu+KdOTLHgUdIatNU5fAy2tJLUQHYeGjyFWyMGsTYajlzIRujjVRMN+Gr0LDyYBGi/8d+240WTWPIH3zprvTLAA3GioOc+F2Sd/ExC9zNl7fgvIlzxlpwuz83acSwbcE96eTa3Fo+fYSzLoUT5ofaEiwhI8X40lVGnNVz35OnPREcwGnR0CGJkxnM3UW9sHqBcpHbxhRXeWzg5NkXZAslmNgvqmT8s3W+sNZ8bnzsy6/mqzqOCUVcfLIWY7jXAIMDFSgXyf3ukqJZlFbUw3FXLjNb8NHE+NV7bQSsS+7pjVIgvU0tWW79zatLybU9F3oCxKrszotnGffdbmwsN1z349ANr4xxflm0TMu5isiO6YDvQAY01shzZUKqcNnaPcFZkn/gYgrSlRSIsVsZpMumzrdu5hCLTejZ7tU86WrQCesRfbfBN52HOaVnenkucYf3N9nDmN9x/X4fuIC6sRUPxh22y0MsRhYPJe9MoiZmo0GNYy2QXbeEIQl6d77NK7x7mar8+YAWbahIKY6HGHZL4IUF0H3c1R2W3fiRtxadffK6u8M9DlHveAPH3+VxX9Dts0Pg6w/lAfuHgMJF9nwxfFU4Zb9Zm7A/f+DaMZRZhMHJCyRCmS5vyvVLXmlDDH0/Vzvm/2hXMKqj5oxDATPf49GLEZ3ZSxiRKjmVcO11HifRFHGc4RMw/ukVPKp2alwv6iD0VkSte7VofVZSPT/y662PYOqyrboSxXIBtHrWXa+hsGRzNGt8QXwYGtMN+bnZfl8+rHmeivMBHOVYK/qcSVtnz4vTLQd3ImhgwlBr5s+M3GB1HqcqwDQNAd1AA5G6IIoJW7Ygj7EYy+1opBk/GWC+2jzhzKPNtB666IToQ097OTH2MT7cEVvoEpZKPjHdDpe0Gbsxxl8Sn8rA2e922lNWLn9Kms4cXihQpWvGusbIgNFms36aClhBdbhtpDe/gLxDtwOeLSa+R0abrri640Falp8cVJhNM6sTd1yC+RYBzjsbmuREcIgriLEc9WtXhgg3WdWVo5/o5HPFDSd5v5r7W6D9vUqNTmgWZr6RRnFK9DHAOrsvCdQueLU/aeqFt46x7WIrBpHlqK+QeclVHeIOV3yXf7Chc+imKoU4BpmgYn0D4TuaHtKTG19YFC8J65UYuUfo28/miahjFMSsvWzXqZjc+wPw1cG+hvDoIW5dEZlIfHN4ip/cSYeNxU9eZNFLaT7Qdd6udGQ+GrFml4rsd9lNyzcWFs2P8THFVwDPXTQv2pNDqGZM9XsuLR2jCGHtrZk1lRhln2MOtYFFRv+1Yh4muEsAsJdQhQuikG53BRqGrCnGlpvvb4hzMqeYL7iLww3YnSs8zxKvAm1gPRwHynw/kdQz1GPaLH0FZn03T6cpsbIEKulTBY0Maer2aGYTFSIuJvyuDsNPB+WEbcJHMayNegd9smpKYSwhjf/gLWNNe65IuuE4xWqCzA6UxhMdnaDmeP870axgtOCOJVZvWWFkS2ukVMuJOL3MJLBxYCING3dBXCDVmE7/1IyeTvvvf1CWQzzc77SgLfqHShmozrCVaTvr94smgwjgW2j51BW2iwRLVymAwp4OBGdNMWM+a/txye2T9iGWfnIGdMyqOhy9VHC7he9ST0VkCGFe7UMl25JCB2UNrl+2VrYRI24VkBX6oMSu96V9e/s7ywoNMvmxcawtPWVC8ghbQ17hMuUJGblvr55RvmvvUCUgEon9/okfs8gatdxVcTDciPmnoa7RNyxNTDC2NO+kB4lWTM4QPHzLRXH9BgcyyvfBStsnYGiMAVXw28ZhcFtx5c91OH6VZ/RymmzKWeLhd0e9amFAeevyWNTHpSJVGGmhObKEFMofYXUG/YIN/dQFKioQlaw+yIemWCyjYElHi6bMnDdt694ZRH+bNQesAgWsflGs5Q8HkjZxBEkinNKkvlaQme5rS/IEAvsB+8x8M29Umqxyy3UC756YPg2quKP9GCPH3o/LGDCteC3bwlWCYuG1dGaKKziCKABvXflQalb7eUp+/IT09mi/rDZn+FCH9tLA+Q/GwP2YgrfMEAFoLgG+ftxpT6pOOHVxSNRTug1mMM1u9sc/ZMLWwn/vXSgif2p0E5fqp4YH6IAEmcsUuXvNABeTW0h6FR1IOfzTNwizvWzxtuB8W+vABkNuqKmRdCxsuhUrYbP9Zq4rS3eyCBl1y+SQ+hB3zqaXktKkiOKZj3tFRyzSm9reQR78n5Lq4KZ4vb32362ePYpn76koV1VXjK8ZMdkB4GvCjOVhM3JZX/4VD1wV2SI7FwKsT5WEHnbe2b8vLW+i5B1jz3RMSsJj9DzQehupImz+XCCGzZqyoWB7e2Y8QZND4Cjh/oNX0euh8gyqX2GUa+dmZBqtiKF1LoouP0wVdryjRu65oX4rhlOsW6cs3Y3oR7ncEcNhdReaPo7JBukuoVhpA6Oka5H+Ma1Ja5HG3lRV8GwuN+RMYgnSfKuAM9DGMYoIwvHK4nC/iWXukuWKPTqDNWwBQyhYZwnbWIf80aZG1SpegrU+7Fc7Ko6akN8Yk6QQMLaMXgJNFqfWkNn6pQ/SA5QcYc5cE8FM/Jo5JVoleFFx28wCdjeZjbhiZ0Dh67kzb4M1aRX1N0bnZuIPoq1BoP6dJSN1CKDiH85Q/lDVVlEjBeZQul2YGOCvVJx9UOG2RRATnlCW4BtC7sxFQqXmaMB3UQQMy+pHvODQjWVdX7lV2pI3AZ1hha+9fvwGJ6qYBGZkFDCAZZogQ2I6iw8yfIIVgDfH8RquP94T206dz4nzt5u1Ar5V8np6W4QPq/C+xgKa472JQQpAmZQin3oZw+q2YtUi3CHjvgCKTNuMn4kXkuBjp6PoW2ZNbycVse6zWn+rKNY2LSS+CMLKZH35BJc87vLT1JnoLvoX8YJj4b6JFsQ4oGduC/+uROJIX0deN03xLTWBXnBTRWCkXf3TtXk1OeFxVC0IKSiFj8VL3g4sR/hsKu3OWSrsiQ90TeJlH1utomShDuGoQLnPGyYvMxd6sJsZAm6yaSZ8AR1B0g2/dEF8Qo5InPYF6Wdo8athzembWYzsiWQx5L1+RGwuHpSGm3fIu/mpD+vn2IBiuVIuOAIM5Pn70SR5CrW9OYMW6C1bqN2bk+eeo9z9H6UhwYsy3U2Y90moSru/JhXRfLB7mcNU3xi1QR8PtNkPsLEDuV/Txe3pU8DorQZzqQPZhSKmWK9DGMO6chFQe6SIAdvxGmmo3YM0J75semYAaRDTPdXuy2EKyAk+vxrcIPplPjTUrdrqtoyMXEz7tgAlCwxP1YV7YO/m9bFTTKRLUKLDDy5POyRVhOeqKIJTi+pp64QizfcS7V0GJT1l/FEjmkEBMpk03Fj8nq6xTU8ePqUlIdqA5vHVHRIL40nR+GJNpLWMASF/eSB86oZF6dl7BIKCABZYnIutpO4FUF8DwBheMGVAR2cVPV2U2fC9UkX1jbmf/4fMBXvp2hAf4C55pRqS3NhwzN3WOsgqMLd+fNCsXVpH+1IjudZutFLozFAIWdPvQQm3K5DxzM1zLx8gRHusYh55CsMBy0s/6sEGsYlDu7kbQU7Tzui/qz7KZw8qGi7W2kHpBaMteaM7zZk7a/qdxuAlo+fvw1yhn3Wu4jVzp15nAqZ2tN/HtAZipTjB1hTRzSUrD7ME8JECYFZ2hbxsN5s/zMc+tx8UW3/KtnPhCn6RBcCoSerDMveWEF/gBliPSIzeA3V0eNKIk1Sy6bup0ZDxA2cChZvcAubWUOwSyMBgUpQq2yzf3FSd1JlzMOQydHVKtb2yBmiDhIeJtpGMF1Iaih2bzwZG03BfL2kYl/nKyghgzzpMewAit94HkHEmhf/Ocb1Lmxolu2W29TOg8kej8j6in4zLSaFhYKIXTKq35kHaoTAMCNlbGnjCu7dlGblyK2gMDZf0tLJEBG3c9uCJGGeNGrxXBVL6HzRBIEmp1MTdxGT3kKBmpSHQChZ7uKZk1bHWbYZcnW9zpIAtiHysUWKbeN8UDWiJeZyX8IcrjitIHs13IsNmhN77/Jn71v8EVvDCSaiJsiAjh1l3p901/NqEO+gtaM2aHnEk705mYxGdCbsT5G6Kxs4HPpegi3aOr7UEpqc2fzf4GG33RuDcuF8ZEHAMUsdTi9soddvcArvywH7a0avhx2hMTDk9lrnK6Nc1SYuhE+Oc3IjfcJMVUZX05/+kJv55bx9JqnL5TbVpnXn/thjFkihLKe/EPhO68fP1k6/o+Rf1h8lCDwHzSe4MA2ust2bCrMfyqLrL+uz4zOP6Htd5Mb+qd9QliC3s5ad3OyH9hDBmJvd5+Bc6ShTRzEqfd19WxxfSXH1e/1pB6V4+jv+nDEOVcC3UZjGOrD3a2R3Y8FiFPwtl0w42MHrrOR26C4Bmu/IEVRLl8hnryiMZ55IzPGV0rO0qxEOU3pF/rCyGGOSwEQh7pa+poTdodU9G64P58S5eZho0KAo57zLOEA8gPnL96jmt8Dq+qhiFsnw33PSeKu+SmDCi6zNYQ6wnXTCL3Ru65Ey3VdoYeoinmHCIvP261c+KtnEh6ilqJYHH6Uv3L1VtqXF3OQ3hdeQAJyrfh3IcU3P8bzykmaUFxYUVA+hbLHE3Qsx/h2379FOgOjSlx4E2u78BTNEVvyW54DkS1tUKFJ1HqrGM1ILAoBEepscJBUfbteYJivaw/Lop9ayF7J+min5XBNF7pgY5u5OsIcMTOEK6rnEecIe4usx+xhlTfUfBydbXy5FtzeBJupERUYT60YtEmpA7iTAH9NoyUqARpIlt5KR2BcNA6iyuM2c/5PWllSauPYgQMqxyaFztvkLT13267xJfqe0KsfWz7faM0aNM1nzAJYQMXQ09i27Az/SgaSXsDtdW9zulsjR1Q741mLPQ+wfcfn77IuzoaTYR9mPQT9Vm1uMrLjZtXFRP2m/oXw/8FtaPDWNp1bkXeFzcyoGvty9Ra3HdL51Ss6X/gc2eOpVBHphGTpHGQyLdKqiNXKo0wmYFRhLitc5D9uBHpsJQftoxu/yaPhs5If7QXL5u3UbiQfiW/xo9PlJWjuE3F+zEirPhFHGRYqgx1YOji/mIgNbnNkFfKHcgjj7VMeO5x/JBr54Movv2LOJCu4BrebGIntjw5C3ZJnep/7kVfQjafWNmnbFCg0KNJTxeWJdAbPecEVPFVCSlCY1JXZ3DZnOCuc5J3bvgHf2dhbTIYfS7TAbLGJSWyULX1CfzJZlGNCYrkv/LrVmpQCsy5TKqO5RRmoLNoCnOmU8JoTegwQpEEmMhAPmLHYSZyZSUk7hnZ1v5iPE50R55cCiS+yd0BG9u8dpRwfhhKcGmsr2rxQoMKBnqt48u/39e2bI7NSs+tX4sk4bY4CEdCcbCPBbsFyLhjZezk+MiAR9iIYsgC9VGtXGNecGGo1xsIkMP1T8/zP7yHLSoH6/gucdvFGDa/e1/PZQmT+rtT2Aq0Yk8527jzwdAcPJ19kfzDjgu9Kkz67ISdvprDnKHdJcVZmBRirZecJgz46ittbez7AzLOKeBOri60r7kPm3qEnKrPBc/SDCgS/1WBm50qusP21yyDqEe4lO2YoX4J7hEo2lSdrwxzKaaSMGVAHi3v09klBQWf95KK1FUTsRT4N0OeWi5FyHmiNIBTvDS63uPSpiEXvfAejt1/ERY1jBC24EtJKgmxyNAb9rtI/hSkQJJQyku658RRyOYQxdKx8TXoGgSpsO1NKobx+EeXiJeoaByZFHE7d9oVXEp7+DQI6PYUEh/2JwfiD6ZAsoyIieYeWchn7cOdGYLIqpMRNrI21XVw2pf+ZnCPqiMaMhbwhaKUP3K2miRBmLZ/labOA2ilu6xhEzRw8+ZojG/CIC7iQzjzabKLGcAjSbwB92UdpA1K86FAFDtNf4zJ7O2KejBCG2Yg9PMFw8gOVI77J9fHzHB8rL9iDFBycu3DwaJl3fNTJH9d3qT3uXfP4/SqVkvUMEht1siBwtN0lWryCXkmDi/jyOcH0FZBX/ud9th69VsdhsF2lCkxEHSQ5x59MTS0OVeUVURgSjdcRzJGyE4/193szZvvb85+c9u0dXbu2E9zA77nZndQo17dUrjMLi4WyYwUzxe3zFhlUgQupMZetSBsVcORZYu1eH2TMhRDZawzlFu0jWao+cb+mk+XCYvG1N3V71HMFQwDmBkt6EDfXrvc6i46NqfvVNGrD3lQpot1vG7DvPs3Ayge6MBvwrnkNFXnJ0PQbiiCr11eVaHfWyXdRvdTokqxc9j5Jx6hkri1m2iJWvc4hUgiYxG9VAFIlfcs1hQnsl+YwtajgbRugFzJKD+ZeAiVo8OYyiz9o91Dr7yoOfJuYCgxpvI6L0Rgy7jhRoGPawFoEm0qGOq5VlFBZmY8f6nkKFRJS6b9lv9uBcgT5/Whw7hbSwnrCsmmqZWPBvAh/9p6Hm6VUn7XPtb854Y22hEc5PhQAu7XM0U0GLINXInUiUBVA1iJP43MEHc5QQU6H5QZxEUZPG3a2vo5ojBPFmPYqpZbycG1EXAQi4jrgAj1qWDBbifN+ueGVTJ1/mBtDtp8B45tzZyA4VS/ZPxxcR8i08K0uwACNKu+NmwEPJHm/TKZ8+4rGnfie2jUlOTzFtO5OW57BimEEsawOOZGl45+NZzm/RquqLc9wNPcFQzubV8rZp3hJrCdg9m2AT+14+s6mFMn1qenCBs77yDERWy+ixtMMljf+npPLCvOZFWk4gtljWP5AoBnYddBmO09CYeOL8tMEaGZbp2Znv8xOfSU5ThrTItP/Gmw3VPCmuNv0hz2D6HNFY1qgsFfsMIjVrZZrxwxL4NZnYSSYFrtlyL8uWnOZxRLaqH47/X41xcFnr1mxDIMei8TwjA8oe//59vJVpskSKKffGO/kOvsYocTzlSozSrQgnFRe4RyNK8QXyQfR210PEsMFVao9ZKEMQb/HV3eaiu+SKf5Ys6RobV1KUt2Pb27HZD2APE8mbwGKPSzp4PFbBp89OTszZVj92590YobHjAmwlTnHFOglaR+UY/TJaoF4NhKCDHQJK00fBsRH/aXASH8WssCa5DZ05CphKvKMK/k68y3lAy8W7qLiXabzn3pVPol/9W+4iG4dfVtej4IOBJq6xWybb+deLtmoqou9KTDs6Yt1FuS1YsSvlLDb6msgtheGMUYLpDXUwUzQrsOOXicoOC6LaR/m8TVa07HOQD8z8yY9tmBtCEv+aZ+DO9tDKzB/HgICjCdxOk1gzwekCA8JX0WyCWAfaaCqOUG5NbVp8r5K814vUeeTQ7s7Od5jDOYBk3Xpl3Yf04Svirpt4sIdFrtaQQXXKNkEfR/MGMVeWuybtxie1hQ6jyO/hB3nwN0shaz4nylsbUY7H9nw8YZOISNc1lT0dsBKHV2waEe5dHphmE4xS6nGvs0Q+4g8Lc/7PDKbiwL+DS6rMfQc73fei56Ey+mxrwgCA/FZ0GN1dDsbK7HF3GA9fRkAwHB6wqNfJ9h3zQX37C0fOpI1YRS6Y79+FH/tv2N/NOipTRVtbcP2Dv3GjG/hjZH00ZIWeWjN4xHmkMscc2WNApWtw6RRTRnU7dQCIjToAaWywvHvm0bRqnr1OPIJTwluzKC4DwvNWlP3PyjTYQOpbK7RYng8yPuQy0rv8UDxNfClLR/BdhS9MXSKTcwxtqsSL3TJWPQ5Uo+W1YaAbA2x6JEYMOXA2eA8jEQ/lliE62DzVBtY1eCzeP23i7rxv+g6CABaPS9RBW28BLFGIJmtuVnZYixJVQsQa1a2IufPTqI3IXZ0Qc2GD2oUHxyFk0k6bIboohxK/oHNxX30WC3dpmwo2Bj0C5FBPkH5edzhIkWRQIPkajQNe1sXuSRWrZqrySXiRCOmw90JKSkxMcWq/GOGHs1Www2wozG/BIUzhQ+PcOmb/+72wZD9aKoGp8h/hPlPFgFiyciS86tAsfnxDIqeQ86IF3SCxc48WDhOgrZBYM7PvJhGnuI1+m0VmozkMpSLHou9yo/2k+HKxEQcq3D2rl9gsQhaYpv+FTFFQlaAb3FociUl3M0hL/U/krt6EUD4JQB/PnSg93jDQzOZY4K4z3la+IkwqsVmMYvQ7o92olt7dl4dru6cMDOe88uNOlzXY0/ftsx3WPZjlbDIYa/wSZe4gJVM7cRlmwgagn+4oAwrAq3P3GxxR4y4jPn8UB+s4vfaafp4aNQ30cuPyvb9FsULYTL1TYsY6Za1gnKUYXDdatOTVoC1tmHa72b2R2iPPHSZE4E/zSODvUn6LIJJyZS0VGM1GQr7pTTb3Zamoh2p9npfUI7b2xOA3cdPfEG649ZFTPGN84Qa1eRvAI+DD5Nhqgj2LpEFPDZAl8ef8lNs7E6QRLqurjMBUxJ+M/sTRexCGVkU4nvRNT+Ko1H5OCVGEqeGKmOyjJQVk5FxQJ8aiB6XApnfeVpgBozKgbGNAfqq+LV+RQ1z4vWu8wVfhAOchxLmnFAketglc/P9UOmQUXTlcm9UjKd6ybF2ibdWzVNpzrpWuEFIUSUsby6/ZTZnSkycV5sJ935eGLivQTsKVnLI37VjS2L0wZ1VKB9RGyHY4dQ2M0VKI4UpFBM3SMctGIDzawuLbOcvnC+K8x/rIhBVLHnw/hEXB4IURogJnbY10UXuxXEZwHvO+8RyyBK5OmbM5Kft5/3S7V7N5XdzdFyrSgJ80Ph4Uj3jL3ZApAqLbzbwrPpE5uP+rd1n4Cw5XDnWNbuf1ivEgLp6hjzMMpKiIr/R8scLRRaceohVnNTKhf+4sdxOCAZ1NP1bq8RZEgSlJs16qhecc6OSx4xBhIajXGOdwRj7sPlDVJhIK6FVi7DVWmNyJZZcUzyHDmfUq24rNWcNCIE23CFi8yeQNas//5cpkkTFThvasaFz4+hQK3aKQcsAWAcYKw/H2bVrAvXYG4YAZtWRpGxdG0plERqE2mRPMFmQ4NOi66XVcUKF50A/cIeZrHm44MCRHhp71UQLUA/t+IKU7NB/8MQmuBl12PnK++uTljs7a+T0hE36BQnNOUHevS+ptSIfSKKlZ3V5hQbCN84t60FO0vfDZ9ZiI5Sy/6jbopxH2Anb4dJU7H506FToAwIQcwnljUF2jFKoSbCEPgCe8sX75UMFbqcA88HdrDseLOKfIAGnpLizrYqxkrR3gYlKp4qW2WWEGkVxzcqtuN9Ka1sSgJWyNhiMh+iBZ9t35kGjOdFNF6LYkgcoAUpEC45SiMoBuP5fTEh06CRjsxWk/Ekd6XEp1+088Tnb5t1H8XbUUAav9kuaiwvN7VkI9cL8tuKbD7SDSx05JhhjAASnXS2p035XzdSAF9ERpD+TvwPVUFDgpvKdd3pmNBzvm47iPEwvvNCQ4YfNKktppkHotjnUN5nXzXYS9VtrTx9l+vKaU9RwZKztmO/sEIJC/YKc0jYmdVoq0l8uFsc6VFQms2kULYZVhopMvdYezTs+CzzXOAR7GROonbLjoz6vUDENkXgUyOvyjd5cK0nKKV6OzafXipd+liP+D7Cb1Yr0a8qtxEGvDe8Xs/dF+dwQnfgh5umrCPX4v7fz6bCZT039YMxSa9RuvqzUPheSyYQ8o+2BVw7F83SuFs1oB3dC5tdiBBhg/GjCYylczJH7qSiODeMESn8UbTpQLsreBhAqmrUTmRGLCVjYR6B+cRvXlpve/kU/gNFRydN0OgqRBsuqz62gUvMej+8FiUu9rfTe2v6KkMunu6dsHoQJtSRQSN8zxO40RmwMcvjKlOtdekI2TdSA+rf/pQ7Y0kwdnqSBaMgepPJ5a0f6OKViFAGH3VOMb3u2colRf2QJY41wQaNgS4yHgSQDvEL2DiNxJLdtyI060CRzF6/yLmMwSWmXNUYcWYUTgvZcm+EMRXS8EmmGBMuefSVm/EjN0yYLCTd00lbEVNbF3CUOUXRNhbDa52JNzDrBxHTTTtANgKQEYdva3oJVsIpm7L8ciHOR2Tp3NbIzptVKKVNG4j0rJ0IAk65z6zjD9+Vca9Q2VVWGxm5Mt32lVfTl2ZpZXuJC7BxMz+gAXaisw7cufCLQ3glZExrxm1Yt0kQZQ1zayMe8l/y3lC0zx51M9JGE2lb6NuL9T/09QhCnvKfeGA09dH3K+LyPnoHtp/oX4icpDNZomFkUYsWYHI/70h5JAoSeT8NFA1IPwEwDDOLHopSIcSs58LTMCqIDK51aXnNKA86ZWgB8LpLyK01+eivSoHFfzD1/0ress/2xe3Y/0XNkVDf5R0rh5T7155k36Vfyf2pfweaghooB8+7+VOGG9Pn4pOaa3lGkW4U0Tko0Zw64FPSy1ZUp1Z1eJ8285qHFp3STsi9jOSHs5wyf4hB9Wfg6FmTRlsLUUE7ntTw/tunIxgzIGwDjOHMvUrp5yR5fkuDhHsyNGSof8uCRPT41NmHtCDUE+LoGBJUfT7vBeFJVazX1MKVvcBZCHicBi5dsx3Tvw58jG7xd+lIyIhADMFHAxM97jdMc7ee7mlrabXyPudBVxY+5Guu/zYyH+V5WsdtLvGgc5OvnXFLbz5pE0ITcjcPV9Tt4I+fk/oCTfOHjxbh4d1HfD4I//LhOyeV+wKU2tu1UrqiK1g+lI488ZR5MUC4g7vBTbPlSbwdjWoB/iukoVIHoux0VrZCncLroGF9TXrtztIA1EjdufqZ8bBluLkO0YZy0ordA+YWqrIIkEH4SAFtfBO1El7k2BtJWbKFaYalFbrLVb7xTyMJlBzs2aQEeGdw6nk3If6vKtywcxBSHuXVrXLoMJmYwFfH8ltywJKmu4fNI6yz4O9CberjY/dU30mNFwKS002ttuINj+At+N9vm4zZgPIET7T74AuHyB81kiKxY99i3u3kSYlNET/uSEFD6CLInTGHNnA8AaO2SCUUtcxyYaUearJhfX5yn5IQYt2tTUq1VUE0FI7Iy4ANwXRQ9omabK5AyUuy1mYYO+QeRlslbCzl9yjGSyH/fm2asS1olFLMdMzOUtKcGPi+K+IoKKkL1JjErFIfuYAoYwCHJInRisPKiFqvKQHf9lZ7eY916iTEdCikjfs3wDEj/eBW73QUlkn8nUWQot1RQvs07qstg/B45NdzW4eVGRAiCUbOjYKfJV06bAyYW34F571p134+itGO/QMWqqmD1w9rwHznP5vuz/RDhaQOkLr8DgByIICIu1wiU8cAU0XM98e9FeMLf54YFox2GQKTAt+iXoVn6GL9AVk2sKZFYIjyaSyA4kV+7VLqLp9eynvOZb+jZ1kiKqW8ybfuVQdsYeeaukW/76tf10GqzGW09bW4VnpYjOH+d8J/LqxP1JVtuXZSBtu78rwXgTIoNTu771BD6qbLBrwEHcdeWWSjd84l7WcNJ0gMayEnS7qBhSgD0jeEUZVe/y51qaK2p/xtRp2EJi9DREwdRkYXzSuvSyijyB5yAH9LGjH3glbC6N0VD1icqze6VxBGSFErzlruU3eqAxpPIrkc98y5V760F+1pyKKqVAZyMrL85+xs2SHrs2dVtk5zBEJJNpK6hKsLtO7eH8Tgih2DQWvoV4w20KhtvIfG/Ve4bNgzqyI7+nqb7gn41L2hdb8zgDPWOMzWHMOt1+LtYN6mTf6EChkABfGT2HQYgorchBMdlWq9xGwBQR6liq/3WO5Z5jq69dQjUJ3hlY7+C3kU72jLjOqj9Ayy6X3vAgpYBKOUS4lwjAm7wGE/Ql509O9Oz5YTN+9Imy/Aw86bkSH5OfY8zrTZnRJbErkr2KHETuF8hS65qPM7uCU3O07cjdZb/kYRHbiJBesf2DW4efTeGqhvUUI1hMIDQca9jM1RQmpxHMZG1VLH7NtDWudEX6uUD49G4iu6TJa8hG0U2eG6QceB3yNR/NYB64iZZSue7tOJTTdimfUVDTLXCiuCmFHwyN5F0wEqBPOCTHTI6JEO2wR7dxwgeNhSF+uWDALK6tEBqOYuy6KQBex6AQbOXX1vnOH8ponCOWb6Cg614ENAa9HVdZ7xFxbHoVWQEb//xB//C6GXPXaetHXHSKRmTNwO3D7TnIaUKUyimD2odbDj4u+WTAX+aa3Cda5y3La3lBbgziU0GZwpV+tMNrOfjXgRofb4BdFL53p35dHt0XAThFLRNALaQ/qFcyQkz5VbwbUsdtktnPbk0HPltOu/yWT/wNsYz0T1P+/4tk4W0CySe/FQ+tPfmHs+r4eWiJuJCqMjhBAQLpOmzaGtOQKOLIIuSu/WT6oTl0b+EoAHijJuJklEwj88hBiG9kDfpuw5ejxt7n4GUz/9t/btwTaUcG5zUt4BfchKfZ325lgzfRckqKgyXG8lRRZAGm5lezmgmWI58dJHNinWkQoHuPZUPxAEf2ypSZhxF1I7SUeSK4WkNc92+b/WjpJeCCOXiDR/Pcm84a/YbkX0/+T3aed8Oab+mD/n9oOoP66yaUqce4OXGHALZkU7Gbo36pIQvVhCBpGo/phlSQAiG1gyBX/iF0Q8LXYvaw7BYO8tsdgdDCCaQ8gvAzTPmDQpFN30YtNAd6UaoTkAQcjTY+5DMgQazOfUaztosEL4hWAb3WaC2EU89PmLKycVIcBdSI1NUm/5tHxmuUz+aGlPMqGlemcVQetF7NdoenXGhgVl4Mn2ydP1iUQnF4hyIONq9I/b8LgN70FWNCKK/JtHEDFK9+v8jjbMCkwm92TnoQnmj/DnNlggAKWL2DarHe3cZ0m2tKOIxDJj1d2k+F9bDzcmlzDNcIj6mp4aWPCFVW4c5sJ4heN241pJRajR5sc+vTDKtZwzL1J9EJmI9kCTk7fiD0ZBj7YtYkZ28syyEFTyOeTO8rOs8t0ubpB3KRdjk60wy+lGZtvCortNmOEjSqQYfxnrUzhwUJ83RBWdqdI0LHqfKwfYOScPlmzgJ75cgL9qJM+ChART993CZxR/2iBuS1EmkBHQ6QCWSwxRAU/pz0vcfD8mLCdctSb4SPO99KPB053rUFJhH8BN/vir9edUJyLg49biXKM/yDhrR+kN4RzgGtI7fZSZpo5bYt2lwg6nUqx6mG/ueh1lgTKIfpXL2uppYdfSk+QT5XoMWX6riaremG57pXa10T4jvAgM9bP6MBpueWjnnSQnEBKRmXGP87wzhYcc/4Zx+75svTQe7lXakLj/LleuD4O1RUELOQuTHXc1g9zp7r5CclhsYSWOKDSdW3tk1guGsUVsiYoNxhp65Vp97bgxAi0aT7Pp8Q3OPZhOfsg44tf+4aIL8PsZkxfJBGiD6VksyqmoLdgGkKcRiWP8sl8FaKxxykTAmhMNUlQXYXgYuxnJwLTnSscCROOf78Lrt+R1X02bxRDzC5PRlzIhCAPpWE9O1ok3Vt9bW5kt1k/XpuppQDq5qCv0m1NbWXKZx6k6ePL6eTR2gq6mkBEf/qpz8KQWiD6o0jLT7OHH4brl24u+cB9Mp6r4BlGE2OI14nQTwtKojWumAA+F4/0E9dlc5jdaS8iT1wR3RX2wUAekiV4zeaayItvpSDFtUdAmtQXOF9KGatvf7LP3eYTD19294b8rdKEc0ub3B4xikgNqFH6P4sdio6IBkuM4NFDQ9py59MN4MAc3kFd2O8sJ1REtsLCbr3KeDhj2SdZN+pocTYUoThUXLcIKZZ8Yz0LtzHF3aQ8OXnuFTgwcNV+TlcR8TlRv9navQct6r2Gypm4LDru7Twb6WFXL1gJSElDnQUNKP17SL5F6YqjzvsevHzNa41Rf0ICXuyHQjlgpfJT/tm23onCyXbGwtN69IGGj1xfPQVnfSUn8IXNdTIRYaTGKa5chMxYtHk+4c+IN/O8NC1jSt4MrwFhLb65lu6aVZs43aeGjsvJUGzqbBOC/a55QxWBN+4jzyTe6oD+Pzam+8cgmk8gb4Q+syog/W+PMCoitmHUrHGMJM4gJ+dteTt1Q2255KwjyXkJDXuKd8DByL/mJrVMB6EL4iHeu0OeOTCWdEwAAIInmyMU0cDEHixP7aGw7ca+7DC9C1ut9AtON9sUCfq28VPxERh7lxcaZqGDCHphcSSlqPUoYVRYQbTDVi9bdWyK4GsojQkw6qxISlgzugoGrpCSBAPkIIgrrUSDEsdJjY+04O54spPXLAahacRmmY1OGaYMsmokHm50oFsyhaAXrWBhszvQWXCXpRGY8zfkKZrypTb3dJT1nEaUIVxKRAm3Ds+MGWN9MT3nwoUcrey8D6P7UEipOEgoPCk8n+k7iHzzSoeXh3U/jbEynuM7hOYgTOrFyIBJ7gCRn7dYNL7LPA1eM0CHiefycERmczeWljYdrP50N8nBb1uZ/tkl16RwbS+X15j10m9oEC0Lr1SZ89//3nafMO0FQUMOuKuiiwf9tr7rjlGSbdZrnD1BasVFzujGlLXBjk66hAOeLF6xEO9Houti1ktSFpCTA9CKkaWHqYM6rNnH5OYScW+Y34qU8gbyjndlVlXqqwTJbD7jmyCYHvnQHn1OueZ/qcuQqOa5nWhmnRg+PV45lh9tGaJkO/4DYH89EMFrhgF9jmq6Y+bCsKMYgsmOUXIgsBPlB9auIAtGIxCznT/D7VAjcJkvHrE8ADbXuw6t4IkFeDLk+7brmRk0gfySi6EAVchziTji31rkDkS2fWQ0QeIiONPtEkTytohqpnifp9QbvW/UzFVdNUxheFhqwPF8YmxwSQp4Yp0yMnrDHxs0SpGOrcAIEOdAAKXHuPA4OAx9IKYdcO8euqIomi7oe5FrL5JLa+YSIsKtvb8a7m6cQlQl/RD/QUxZ5zMSb2W93M7n09nT3OBT/DIi9xbn7kVY4n7dfTKATTQrbl1xHHgmSvBN6NlL+LlTbMQATx/Nv0d+fq/DgXGFQA4Wt+k01iLAr06f6aaHMnT2Lros7oGUh7mVQvOU9FYtphEDcFvaoOYip7T+SpATj1y6ghblmq+eOSgLgKpwaoJ6KEP4trWD9acA/5Xur78G6BkrHoaDvOhOXQcdEK9YJGiBZcEa2kRk9gBlcB46MtBfkFAHMaTgMdynfDsnOnC+6NERcYrya1BK0mftg1GYOWDJP3mW9dpjH2XHI1T2mf4+hBpWZdkKfFcuFAf3j7DnqWyaWe6H8OdeqmI5/wlBwT3Gl8aODQlnGooKH22TRq4c/varqCczsO1AeM33d5lwecxJoRKMEUH5bay7smtI+YFc7ZFPtbjfRquZjXoFDqopG/iH08Pq+xFeDRLlPwRUzlttNN12i1/4u4VjF1PqNox5ZSaBlyXJGSVxq/b+OMmWeb/mkT+S/SM9H15Reqxa7AXX16R4waI+z3jv8IhFZ4bLAnQHQex1rif0fvvn9h59dmlr3XKRVR9hjIjBcVx9znN9hGhbPGsteGjnrOaopSeDeIdMQpPgKOXP/2vpHnVPU4LMJthlor8iFns9ApJgCqsmFqxOk95HSwWA7KcpUktpLZ1/d/fVoRZAPz0lG1VImguvsXj0E1mHEMw+yKYhULYYAt13UVYmsJAf2elLZoOAlUhBnqvSbRi3e1R54Gq5sYaL3IfgJ4HzyMwydMH4j7UXKsW9Nircsse0vtyQbKNqnV+ECb/fBdU/35d9Wu5IntTxHpYbVr8OEH7b3opJ+lQg6FQ7YyF3g5coWS4y1mHemjg1CSZOrSGVXA1R47jczjD5mtgMPw6GdayNg0Dm9VJ4/LB1bR61RyWDRQQVcsaWUeIbfOV2X5rY8DhsI2bwSheNpHH1UbxHDtd6RUD1bDgo2SraoPfDutqEce1KC20Q/SBuXNrPa2UxEa1LhUqtnQvNtNDm6inXCPdRKq7B2dITTVTzwvbdHKsvgwZmb88ITnlqJ62GsUYHfOfXgK6ipk84rRD7P1RcEqDqLwoY5Uj2PlNNhT8OVtudIOh6kGvYwjSRXz08JSqm/DPOD0mf1d71pNfQFtzqZSdwO3OuGKBsq2tnSNU7VdZq5Wzs3aReU7h1GfU+0HfmaNgUNijh/1WiFOpS8qry2kezo79ikXI/DWkbOS4wBmr70AMXMfqiOVHbIilpi9MK89Tm8vet7Eq52oRCmTuQvcwBYtZP1xh+C33ZT/UduDQjWvr1V1LlgCTqVavJxyKatuXT1INh5tzBXDfKfXN3RztYboNJ9nEv1TX1helwx2MbLcgDlMTP0uPkpiVnJURUINdPfGpPPJTp7H96WhMoCNOh3fVVslEOA8+szoyFXfS0ntv8C++RaTeIq1RKiqWg1CgyHfMLQxZ94Z7f8BiRAtJ4GOo9yMw3bCpKlD+bw/6j5/8Usp0m6F9R8rk20tcoxITYVJhKHZeDy304zE2yK+3s7pGHwbrde755nznyAvHCIWMA43neCpPmRmb3UD6KPWmYlS1uvjVyWScwma5v3aglkOYIbQwwxTPmOhMKRCP0/lYllCzsDJ1opodDEJ7TnokNCeHjLbd7hC40DhekLFuzg6j0VrXg+etXMxk9rx5BHs5HzFGWjegK0pZNk2iirtS4OpxeVwxAxoxJBr2gL4YmyWeFa87eyZJQexBnvLNFfCr6tARiHe6eMczoXv6UHXwW0i+dsRelsUwb/f7TCEi3o7xpeP+lRPo7klc/do9PacG+LiBq5mSZeNrkKf/CoANlnjN9ZCIVrohk0Y+zPYrELJMOjH+8GfTmV2xVE7fvLxCN+Hy3gfqbl1utbp2oSwRHUICEVR/uhe30P0qJHlfMiQuwxQB6gLm5mNkFHEbGCqPY3cFFvpEq7KxjFFrg72/4QLLoqqx8eKyMELIstYz88fyJooXUq2xZ8QFFB5JRvW2V86tZ0R6o6qZ8qBVVDVLcfu1ghq6D8yH28+BSbfIJOwR0Rc6hBaTAP3MTxCGXA54A8uAKilYsg9PJRYzvpVNOmHP0I0Sxbjjy2ZG2k1A+G86I8GrfogHUJclB3N8uFTIip1obQWjRGlThnzBM2SrhRR1bwkY3pT+kdMoR9jfgnrdxG30mXN81d8Yr26Gwn4g2tAE8gBlE/CGa970bzbTioVsQwIv9j3cK4KdWrrgcPSdAcHJXQWEbjjBaaE4V1+9hAoOwVuqdJ1MHenwPiqhJ0utfIkxJ10/B6gwZKCUtrcPolYEvJsPx/55Q73hzQyOtpaYbjAToNN5TPN5yxIPy142qvEIHapZKAPvjPbQIRjpCoSD4HA4XvtzyJguNNDlV6fjVEo3gvzm5oMb8yZ8L6Zd/mU4EMbvUIyeGMkM+NLK1PhzS6d24JSc1ZjbyPphR2Qg3pTutgI1iUgh+iCxOmyVKidzH1AFoGID5sQwxbjgGzC3Jn6lop105g1BKRdQ5X4JyuISVypD/QUAxCMB75aBraf188HIEjc0zuTv2jaBsPv4oFbNxFIJD2BaKcB3f9MDeti2bpdKWzoG4BFSv0ZyKdM1GzM/mtxj5NwE0XqQ82NPU7EKKH+sUWjUNUP0h4HunyKW0hVr/FIpvlElkwW2iyVcsmP+JsB54yWlkeVTzSpk6/gxH56xU9souhy2fQ+mBvKCGWCLVnzhjs+zdHg90kMUP4M8MfqD1K6U3iSuiYZMdTj+cNjGGK202q72zPxH/0rahxzwyo0pvqeYpJ/MCuVVzOoBOP2QLaVgFmAPxZrviKH+6KGFUv+HC2LQj/3zVCGEhFQ5lF7FYI1iV81hUHfgKyYR12K5jJVxZ+a/ikUh13hKRPuFKSq3BV0WFMHN95qHcQR5D7bDIyBF2PyGAnt28c/i/UsXIC1/vWZoVjamPVSFBTo0LnoewKFXwvMON+JLZlzXRqtDO4PSFAaqXlyhNTOCAkjadw0gS/51XeZBEo+jbHwEuo54YvxKrNpBSZJUdzHDg8ujQArRkewTwzqA6S09egw9w5MqBGAFUr3ZWFd6SR+LoExP6NKRw6+bEDiBKjJ/6NbXdwP8ZN1qOgTYyTHAaAHnQIxA+KzPOXJoNEXzLQu95Ozd9C8eYRBiPHKp6U2P3qVY70+slSGCXsyk40RInZvmmvGKA2hiAAW1TyH7hsiM29hfylwSmjXWYhQ+F319pW+b+2uDN7kS8F33w0cnvbOhW4seO8cgam0odKAZQTi27vCyL/hDq0XsGOVbJe1tgthJsgL2ViLpCiP/J4DWW339vQf6KuEIC138Cpsu1oETtjSfVP58/zFKwJG5y0FQn4btOptSGp76UK3xR3jluSHreTlCJct5v4KQp+lJUT+BuEqel0qnJbltz1Q/U0xr3GWOmwerymlz/CRMZH+jhJ4mBrG3HUDqRTJAi35pvgCwZlS9TF/2ca0vBO9Grr8VtUhfM8uAFR3XDcCjD69EQQRcvtpJqPgouZRGXYJZwSK9qEmLB+vYW7aGdR+XnD0Vi+V4HK/WhmO7jaTV1rzW4tmI3eNysBu83ICfdC3IHfFmGmGxAofu2Z6TICd3FDP/FSAWM14T8oscc6Q00nfEkvmmrRfqHJ14j0J/uGKtLRzBsk2DLHVqm/HUlZxKfHYSKSO/30TCl7+CBi5cwuvrKKFnUir4gSAddeVyUH5kj8R2kxprqMbl+OV8vbYr4mgLItW/1+X0fNMJIdWJeIjmWB6BXKBTCcohMQQOeQkQWJEus23LVnvmeV3AJXYhh+VMNpUnAgNfek0GypdY9H4WHo7GWIeyeZ6y6ivy9ufF5hh6yoPdmShTiH75FZW9nBc8JCp5O2xRWYLDgPbDIRr0ygkqWrrhUdomPaF5BMw+IuHGP96FwpK07F21GdIeJ4ZkxfEfEgIOxFkLnTJnoazoxx6QgFXaRcbZjtR88N4cUfE8N/EuyS7DbbEwEttSMKPsImnIucylzWXsuT4auTOt1dnP9lnQRNhp2oUz41Sttvc4gVLSUh/BVDbIO87fgXIcIU+rHyAitV6e7tn6nfpF/9v3v2afbjHJggHoZyPTIA8x22sDDVGHZubejFaMUaPAI5R4ed4+WyA3nMMo6sjgzD5oKjFemy4kDWULZ9WvOf58vLNk7aUQI2sjS4n2jYMvYDWZfo9T6IWDd/7xhFmR+08EpbKOVKQS15HPJCSilIzMTBNYpij60wKabtIO5dHtpcc1Kvd2TP2QM9qS/I+dfDV6rk8wp6QwVpERvjepKCZu2YmTRY1bhFelw2i/wyhwVjOmA6/lSUII2J24R6hxulTXpxbLtgan9w54TjoknQJdnriODPH3NaJPtFOs6I9EQq+F+33v5TBD7QERVS2OdA7ECr3+SvmasFYJl2MY6E4OzLmdIS4x0+F9IFn0vPbzlBKiQ0vXZVeRhbOiPKTTQ/Vy7Xj5aJceRxqjhci5J3N2TTOAYH9K24YFeEyJkhnNukWXnML57klPsJ1maDZCu/LYhSUlhut9pZIwDZZqWQfko3Qno3kZzsYPCPSxCCRxRmq4gT9C2mTGeNrH44aful47U08jsKcyk4JfyKJyjquMJer57Zc03xW+QHZbYO+i7AGYNb+c8TeuQXSc+RU1xz+1JESL1dwTp5tkKRO7FlWlmlJ/1JX/Rq0yru4ChrA6vXkZ62BeW7AXlCah7KSSfCDRcrPbcuJ7B7yiQzX6+YR7keUvmiQBuonsVrqqdzYrv5toJqWFLkPKEXr6hRyCmhAGqHxAyPI1SzPgcnfj3i76vy4NtnfqJeeugbMHqfceUkxvZVETTXon5W67bP64p/8IgBR49vOu7ZDJ84GepHoLTH18xFg4cLOwBQGWaMS5XwyZidOpQOek2hUXzwBNRa4kMrw5ppc0+glJKgzfUIa0jCmZ7WmkEP7oQxvI9VLskm4fTxeD33Y0F3cSrDdL520jYnOGRzoaGKoCabfayljEApdIpDtGBrgD64K9CImBlLHvg8vorUnSlLm6Sb7tNZ6N51x8uwqd7FrmnHljq9PP/lEEob7jR4DLtFjxx9XIpMO4AxIE6xDglJdHd6j7+89U16IMlRpWMCbGCtFEtwAf+B5BqIBaM4waovMMvaX+jbnxcp40YsXcAzyF2krxq5uwaeixzejMb7e+c7jswW7EOovsyc2Ye07ia02TWoV5mJAZR+MZg4/tdZjcz6CBQaXdmDt9sMwBypBOz9QKxbmVVLaZWU5kg1AAC1dKkeazLd3nx879d4hH2OmIpCxXPNlVcXyyDPePRUNA05DeVZNnnOpQ0H5zM++e8lA5/C6BmfggLHqb5KdQuMrtGOKyI288APex6wfDuYX4cEK1p3zWef6aGv+2nWvQHAxpDiqTuHtzkXZcCBTM9BEDyq5pROMNr2Os1LWKT+9BN0VqOo3KlVRuZu05kEW7F0cdzTNWGd52tHsrhkUSLfJQfiFuvSOoq9PfLL6+4MryH7nfkzKUYFD+Pa1GX5offfFT+dD8AU7hdKIh6GKL57v3ThhBqWWF8vybTwY51ORe2u0Xpq5Ux9qFuMUKUgbgbdh7QcivX4TXr3k+1N+IkzJFvcyq8hC8Oh+6uACPZOT4m4hrxD9A5P1I6xwOCpDM5EwTs2F1HbPUE0glt9u4hAk9AH467kfXK2xcwDeWziOhnQ2rx8YTZn14XXJYIXEgJPAo08L0zYKhIBXQJt2dh7Osv0AKFsVkW0bFEO/qt5BTdat+7vk771i/MYODIoutb8ZKE3BJoLeXA6YN7z+IVRUC+GPiuWs4McAzZxyHF3RnIfVqncyNWxufbpXZRkXhpsUlr4krhhvS7PdW8OmtAn39TrGCLxpEo1nWrnmNMetOwm/MdFqBoIILBxgrssmkd2yn9DIsJofRlvnS2WZwYSQslZcP4Dtle7FlKa2rD8A3kDkSSGNCpZBp1fB6vKAYBhDICh/XwDrYmZDvByk9VKp6VXPw5vlMLFlIsjkZKQlZUEXc0tcS8/iIxgLB0bUkwHHqLHzcpW8WqInBHVozZqDVuv75zNJKVTQKSPTic8kQ4PBXdbFG96wQFPrIVlXTKZnfhGzB83px4Mq4drclVsYO9Os6lTdzdQEUq6XkI7p+clFdT7NL3mGn/8lpVP9Q2McT1LRip9ScJj1CJ1vkRn+1tHL5814jKziXfELimu+1Va4RGZqagvfm86Rt2fTjeIScg4Pn4h4pyJkmTIsxlwmvYtBSkaJzLKNJEt/+//dpDMAWXMVLpvYEfWWLBFT5pssL5lGQTiX6NuyLnG+Vlt+2URI24x0WJ7zCrct3pwohdLxnqtNgunPZnTGEjDcg8e7k1sZ7i5SZKNKrhvAUuCBRVa/ntFmZjECaQT5OCgBY08q0st5kIWruM/zVcQGK67UW9U4/KlqW4Bhm2oKQe0vUM/yaIkOUi1+a/KLX/6xSUQciVkl6GG35OwE/mdFXFfm54DNXkkfdRvCYBwDkf28ozBjxG1u8w2Utwsjf/XaeSwyQVho5s0Wl6+PGCcMlc6l/lGwr3cGRr8bF9k802irUxAek8/i3BefdWDCpoYtvSRFeLZy710u2jna7c/sgggJPMJHsILhR5OqsMLYs/ZtRMq9NT9L8xkEUYYuMF6LrJxUEXJi5XXcqPh6iumxgoRNV3ri5aBL2GVT8v4yJN7p7MyQNAJVbZupTG7Qfcys9+0mFTgNpTFh1qNkFKeuOZs16jxC6BA7s895pSCanxDg529FoPFbF5dMk5UgDxX64V/BrtHTJDI4Ca9kfhhp3zCVWPn6mSMIqTk3v7Nx53ggADX2xnRQkICLQS80bpTHEFh2OFlkHTbXB9Wizx9Nz16b4YTue9DbUKEGH4mVKXXAw96zbcBlcgCraBic2USE4jKcWzfq2LVTc8HQ2ES7bc26YTR6QoTtnxnZI2t7yL9Pd9ysiG4Hh4AXuVBUu6wbCsGVwsxDG5DsHOZiV2MJbooPQcJ5n8vrS4TDcyOGtQzCYI1VquB+tYcE5QC1s7rXH8vejSDJ4IbcBmAXwZEs/v8AWr2CqTzZR18DQ6qJO6Gx67jpgtYrynlYPoEFDc5z0ZHNXjOUrDjSGPSPdhsjC0xRfVxkecLf0y1Gdxk+bbPyZU8c9UK8rhGBhCduUCh6pbDUmT312NrEEERrFpzZIZCtGj8pCnjEIQHs0Qrjcrd0rfvhLcDXzpQvaG+r2PNGBOBwA9jS1JY0ACCChvtEWNA6o1a5VemUa0B3LhCbSgpN+3BRQllwTwzWjN0n5ew6LcpdD4TiFXb0jM59uzpetdla7cXdCh9BacM2dlPZ9XvSUT1z7NT6VYHsUYe8UIV8/K2DJaMnp1lblKTS37fa+7WzvIfDUrBEPj8NVPqVFG79IXtaMDozIoJKmlK8QQmXSQ+YW6Al19lCJPL7VvD7BZlaekjQdVTQoXuqLMgBA/CFOsrBRg98pgBSrI9ZRZpmioNe84NlI8jD3jEv4T5lxZWZzR6c9WwhQlgtKFZaokue+xdv7/na0KryucvT1SmoiSiZBUNFby6LVR76foX/v/y1LU/K7VG0W4jGE8eKXKfHAI5JOIpGuokhGF2GbR3Z1s+461y6SxG8XmhKjUU5fKemBQu9CZD53Kr6zsOfiG7EyTuy5XVJcJhTK7ipeEAGntvI55MZqnhOLZzfHT8TN3ZQBIalTVhed7WPuEiQA8+yKc6VP7OEWim0q5mC1BiShYu+Ih8etFLnTh1suy3IRXYbZ77VZGSFl9/B3Uv0L0tLQ1FFUhrmWhmRcauXhyGGepj7FG3z/r7Q3C1+S1Xjdmb3TV0eBqKQ2lSdEE5L6HQoB6PjD6zzxD8DJ9fsVPQWoOwa3vS2Gn0f9jk5u5vfCQcL5Ven0F8uwne6pExm361EGJ2IxW0J6EnC0H9kx+2R8ngsywUMhGKf+NVlJ4QPp4Fj/K9+ZG+X2VYxSIb6O2MERKfCxOAonSz9h/mlLzA0NIWIwZR5DACwO7eiXQM71oBy9eC1bFPU0GTYb2h3neik17UnF/WWlouJ66TQAjo9XCFCOZjQ3BdwAyfnZiZtrM+8p/2NlJrWq2R7V0WUHSiHppr1v4fw0B7WJneubBWb1VxO6MxaFbMI3JV6lRTQANZ/k6e3RMLMvC4aiWFUN5GSkda4BZelefeVC9ADeZh1SBSURFXteTFJYVGyLDzVBr+ljE5HgUzBU18M00qSVKzws5bMyHJagAP1vqTw9IvSa5RTWZlLE/qayV+iP0Wd6SmwoohFWTCV7zx2ayVrtM2bge0WMiwUYQ1xIn/O9EcipFm0V2rShKBrX/VEAPq5Tgfl6tf2RYzTcnRuwbAN6B8Ri8K70cJYe5gZ0hs0kstbjJQWCLln51yGMY7EfZHrdQuqXNblRQHeoWFXRLwoAMmDDsHLv9VYe5ei7c1X1uCnM/j1ELF34g5F5gLs6qEz3KkoKrkEqAzD72d/u86AvJ1KXGsJlDIO8f1OLQUiUhfl+xkGy7oJgVw02+bSB5SE7XPkEF12Rv0Ct9L2CDo8DQ+NhN9mg0r6ElAz5nEsHwJ3NjmrzSuOSU81ngSx291Q7wP9J2l5CrwHr6L3cid+R9asY//8/qLL8+ZMJKENwJRtzio+dc3xKv4Bcu51VRZa8RS0eN8v9hLyV1oVc4crWCLw+tmr3BSbbe8ud00r67LtnCIQWyRmu1hMcjGRM9MlOS2evmC/hSx2m5ms2p+EI/q7e935rUE+irTJYfmOhBaPwR+H4CvTq38aoIayl33XYm3venDA0o7ofiMtEBMw1TMOIVkHo6gBBaoajuGQ3O5QVs6I4/DUjQiClyAwbtnq6g3Q5imS3qXw7j5z5VaQgGK2sMXjiwBB4utYnEFb3pbJHVbhtq8Qq9Yd3FqpyAWLr0scJOhOJUfpY0EwsK+rJ9lpZmR49D/ovC9u58s3m7CW4PP0+NyfDVgc4attcYciK3uC2yHfqtkEFufKc4sJglLr0i61aVC+ybb5ixpc7YuuO+iYP5B7k4c34X64A9FzmnvkklnlOK0iAcxHZF8Of89942WAYPA+Xw3z94eVdiBsgojIw1pVMXVN8MzvitfZbULT8kxo46i0vRmy0glSxRrcu7IgjtqJc4OYGiY1iixr5sTr8RO3rc8cVJdtkYETuMpEuAWT/oRxSYByzhmk+paMSMCJB7dp7QtW1igpbmAEVvOpu+rRa4nOhMLG0R+SEWiOmrxCTTpsthuPYI/lLdOv0jQc5I0ITIbrLavf8KOa2LjuRQWKYKtW8z5L9zcNgrVSuqZJj3XT4G7QYqr+yQRE4a0Kbps5am3sPfHqews30W79HJjOHvb+dl0AgN+El3pDvf8YHzaw1ssUoE87NP+BMJA+lo8CsXTpEqP/n28vhhTPRJmqhGd4+H4uVwDDwexRj31p8ujNo1AY6cZ978lxQtMlYeMwDYR3BnGmWfFz3PHke/FxzZKbDSbBmpg9Ki16tyJcWNu+4w1IjZogjtpXYtez/h6sHw+SRHyoArPTicQfIefMy3+PN0+Jo5TpghKOOIDHZKugggfOp86xNq29Hge/Fhl3ldpIVlrRyBitrGM2vYw34Afy5FlYvGE/sNehNXa387ka6kWeWKeRTI62gLnXDgeFr70UpYnJxt/EvPU0Q+WEP4QNVICQZjvJyrry8KqkRwL19EVHcvtOnyzOoG+6dQRvo4+kDWJoN1FVXjXG5/R0fW/E2jrExsaVX1+kd7Hg+JsiDE39v3QkdaRU06HuyBlRKw50pnMQX7IQKQLUFz08GrEhqa2hgVImBJXp1pVx0zWjTv5KTgx7N+phQobKz7XkTeDv8exNddUg6zHD7w4AznZQTBGq8HTHafB276P+2Py/dCId2Df4n05bZ8jrqIjQGwj/OJcLvQn7V2dOubb+tTHhMJPhrhv5zHj771ywRCPrVSYyjTAEhRfjczROo/2qLG7PpQt6iH7O7fUibJRa5LpGRDuhdqtX6GFXVoF62DLAqyb8Or2LK9giq04OqboPO/8PyVC/Oe1QVEYmWgnWg6WvgfuqE8wa1ngGIrUC/Rk9kB8/BR8pHc0LsSYfDaSz6skKmNycwGkGr+dF+orQ07QCOEgbq0BSbGj1ohoMG1H8lKraLtxxi980v8sqM7gDqyhFJCi8Zufdzp7ztqHD/gG9fGwwVyf785E6v1ctUNWj339kGG3fFQ65gnXwNx8mcuK93VlfwMD4gUsfHEx0uz6ITcITwm6/w9qJxOXSTRXpYSzqQ6G+/W3xseIjUAFZSMMja8kdj//tdhh1Q/jq4J3ev/tvmTGMIN1+I3/V6CvH/QSVXHzbbN58/anFAmh0VzMFBkl1bT9B77rXhG6oQf3EhM4bgvhdmtZJopoEYxXvKkQr4xhu6WP6KeVcMHIxUgPx4JYRl2lrXAM4qu95w3QKCsuqY6Z2vAz8fTXArtp/pTqXhwwgjDPwbSFjIANZfZxN2QGHxyF7VUteW7QXIpMDlXzzuHzq12+ihuk9iCeMpMnp+YI3PZ1hvtR6DZOEToe39O57Fl9qQ9j+KFMYwY6Eg5iQ4Qf/9b86QsTpuMG8Du688/4pKvwWcb/LTTfzyk2R+Y5AJb/BmuUWDTs6ui0Ltd0vV6LJNwVJp3Q+s0YBziF6RMwkp0RwFzksnxYQCIxoOf8wMP4XfVKvloU+4Ouw3YZCwRc/oj3eKbENKfdERCBHN8dFfmQTtff0FGqLlLqtUjw+Xt1uY5fkXa8x6UJuNSo1pmo98CuZGpH9UBFfP1vJxpX275m9v950Z1jKz1e5kg2xMALMh/kbqyKm6xmDt+HS6QE3WQ8ze6Sc4lGdPBhxB3wHK1bYLg3E2q1/Lknot6vilb161t2wO7fXsxKPQ+HBvZYLe4DI9UV5stY6LUADremxyJxNzVMdEXhYifhG4T0tOtUkjqirybCnXW1orXGnOtkoue3VUA+Ibe5yax+mYuNLipMOs/DghvzZHYsw8RxVfik2cb/KyYOB7VOISjGOPvlSC9De80iKKaYi4SE0s1z0T/Gpn2LIh4BhdHDbNgm+hW2EDXC2xqd0FS3ii9Am3piP9oq0lxaFTRG4RUM33YtM0ztupkKJtFI058w/KO7Cm+7hPtp7ZgJr2kb6IBwZZxwS+3SkgcbM3PKIK3sD76oJIHtbNKveRk464g79HbeVd8aRvIVVJFXNlCMNGMxbug0v0k+vSUr8hA1rvIsAvvd9Zc2J0K1vPyHtHK1amhUATqDou/fw5jlNi5YhHmXeOmURsRpKgoiVcyVmt3g2dN7hHkV8QOxZk2W46mEoogCx0WXZmvfhMcT4sS42+Zq3UUujvqC9ZQ0/1WbvDex/fizJBSk4ei0ptRy1ZJKjwTYlukvkifme+NNeI/AKifLlPIpl8uoDfl1Ehb/jy0tnpKkwO6c/clW8LPD1lD6GHV/pNJv+YyrUGpVXcBgth5bAPobG5ZoPxatrAV7QBeZuQbGN80Lk8wt9nu5agF8bm/MSQHc6IoddEgq/n0nrRgvwEHJPypjZcHpItg+Cu5gLJ+xVOpMJiUliVqbyvjeCzDwJJ1qwRjyw3i0NyVt+Q4poPWn5VLiySEijQrRUPxuX9O2q6GZK4vUwvJs1FDL8jsTSRHa9D3vNrnxUKYdALBjRTEFqTaVpbk72iYkMTH/SFcAu1WwL+vyROJQVVIaAMbC0BwHIJs2j/lvdwNlrBs3/4Tw9FnGkaCia4Jpt4EpSsueXB5Qjg/oCLC0SEk9BiDO79qdfWPfuFambMDjbkNWgtLaRESnIDCi0dz/przZ1cgsr0BcffgdBcqAQTNNRKBRtdiwXtSxqjlehQnfn4r3XLdVv7USQqBDE1Ml8ocX9jwGWxwa9ewYit8D0uWOmgARo2zE+3CNLlQCIC2yjeYj/2c/cmAiGNsTzI9GRYl6p26EuA1qTM10HiqMH3bJRcp/UOj4t/8UrvAXXzqW9rfi2boogXqWhIW6nwPZsznKvbXLOPxN/TVRRt8FYOgQ1srs/pReEUlT6LHm+1/EFB2eutsjX0ny1xRASulMQ2DrLrD4TzpGX0YQ/dbYiX6uvFi3h1HNYlIX6PjbTe7gOhhxROPvoQhqLkadddtgK4+T8wKZgB7dxuPOyDlrjf5SjvgCNaJs691he1o+oKZO0wrw9ylSMPAuNWXJ9KifYecd76mxU6zB5tF5zYhtb5zS58XYpyCkqLx8rKJjEeUZCc7cr8aFB7BHt5wGmQaxT6rEibvLnfQU24+N7jGHall4VrNzgPbDqq35T6wrXzE3BoPIbVm9ifWFh3YP4bsjv8O0SQqKHsozViGNLaa2gPJbhTDwgYRrffJ3U8l9Bl0vOD81baG4ULQzBk1lHyhoU+rSgvtbPKXV7WUfS9Lt9wa/lw4HJxPc0JsqnRMSiCOjhdZ+cbsp9NuusACnbOCI+gAKid2q28tNpS4BiWNBu4MdyFa2DqDZhseEqlAxBOlgRE2XszLjbcUSsCpx6ZnbqwVu7a77ATUA4m/oqYKQI4nhxuzwyRHETu2+HQlUYJWXmcElpqPBtjceknaBKUyPSYJur/52+i4w+kESQzwze1QRC/yLFQO4J+t5u1KVx8tmoI0/CN5+v241zWxsZqOAt+N2Q5EpjVZo9GSHXTsCII9SHrSkcEViNJxLWeE0S0Eq6nk+rmEcFpYJXE39L3W0zroHhAek/CMpg5py3QDTwp0qnn49FDlh0a9BhWXWpzDeRYT9woycM2IZpSAnNV5TfpNK4i8n9mPX5e8mE+lbaTU463rpEfFJRTERJ14SlH7yPaUMDTuwsudWdxRmBwdhdq2jWAeecKXxzTJ+BcHklc8qeRWb7GRrdEXp9CVx4K/cC5C5ilEzARWZtz7oicICmYRaJ+Aq+yhkTi5E+/Ke3YcfmXv1YAIco577bIpIxIECVyupT9p/gQUZf1+6WJrbAUmQN4ZjZW+JyKfrBt0oLOan9Si31jn+nnu8OfXGzK0nfcPQZnZxxrLOTw8GexNOiwnBNXtD2cxJ08JFlmEVcRebKahlpgBdcOpLDAElqwoQTavK4wLsJTKJ8MkYXcyFevs7/lvP6JQNsl2kjoTCCQZfkMv6pU2aarkFJU0kCZqm4upP5fHnchuDsv3K1xKIwhaG/7Dp42U8RboQLlkQgbVIH0t+zGkE+i0NggY68R5foBlUTDOBWE2cFMZ50YCFMxJedDQ1WCJdylZo18cEsT//ggxEQgQAyEVKTT410NA3EjW7k4uNHkg012DMMwS2JARoM/ToBzeV985CtFz5jCI+XyqDZof+LMu1aCH4UPQe8wXm8nggtT0OaKjrN/0m8gKYUxglIpWCcmlHCRZ5b59mMRtock3ifIf5xX4RSXSr6ZenlHz6zcmLcU/HJJwAopGq1XSsEIMO+qudpY2sK9rorNJVszEi/SZO4aOX++RYRmQevaVAIzxHg6Rf10+Cc3XkD8oqFCQzbyABRZk4FNcLHkK8f/UQjOOQlYCubQzjK0uI6mf09Uly/dkn/LwTbH6mGfzMgN4HdcOB1/pThhZTdUfdfAHaTi0BCEl4qoYRJ5tmXmu1rHgr/ppOrR6hD1qMT0TbAN9nRhhLX8XV93YkHopsK3ocWDBVR5DiefaDTq4fOpkZ6mapsgK6Xr3L74SDXrzVb5+yoOIvNKZ5JQVAVPp1C5oWlNAfvnkWLiTJTcvPTOvFCSTAcbJ+uudD5J/cm4fbcqzUMQ5+bsBBzMhdOJg7K/tbsgvqJxjxZlQkqj3VME9V/6tsMeDZEC5bYEGj36fGXtx5Tgy7Kp58BfCNYr37CFaKJHklZEiEV//76atdydmzJEWlbdxms0CRKNBHDtK1fEqJOHJBUBeAYDPZBneonLfXGR/iMlHPFzreZXFjm6c6FllzzL8aZZLKzOpDREK4IBkv0XcBllEAeyaXux4rg3CXPudXEAK+cZcUivV7zwfXCrqNUVflJWAUQmAagXK4zbtoKHJmCVMJLJ8QsyAn74HPbmp8ik8+vzsWfmIPfV59J3G2RGte+IVt85mb9pDNGMWleuJWnNH8EoQweZM2cef7qF4kz/+78qtlLwSGLVMu3U53DLPzxKx/hKuanxkFLyyKC2OOtVevfpMW9jIYppEPe0SIe6EOdq3P2t3tQCCSUNP0fp9RRnAxUpDdKHjYdW8BmetfaF4A9gecF3U4tMGiRW+3dBnyugjXxaXiiHFfyKOE1okGjSSr666dxrUUhTgJStKr0U88Fv/+XOwNw/1BQMEYl/KkA16Oyo8z71WHCPNwg2t8x09xe9x2BYjND5063I+hFvfyW9pSULffRWutBV7d79sXEePJlFPx/PDDl9oNpaSZ4ohIswosHKn2Z1sSzds9t13iR85tF09u1HNArEE2COpqjTCQG/gTxZd9kNbAASUWnGvi/HpmzkmQDAy+eovu8eAEAe302zND32811MhJ4Xy8fo4WXdK2kSdBOZyn0f2Dzws2PyXVo5HJ3iA6HFQjT2Dg4+BqHprfW8klwxAJxNDWEJep+Q4wiiIUlmI5O3AwzARWHja0NP/9BtTFBND12duihHxllyNnliVuUJpExnHlbZHFrIH4sWCdMlGOL7y9UhTA+J9c1X9cDpN29NVLeIOZ/w0d/ORfXh5JhZgIGSYShy2duPu/b6KxjBpzmfmRVAJbYswDubVQt3Y0Nmdbomhil09VwTPdlQVDeiWiEeOna+xt377GzQ0kPkqhIXoi/dzyB3HwzZmcdc7tl6gwGXa4rIajU47Xsywu4lk6Ud4pJzRh8LVTO2cjqCAdGt0PzxNbDX2Dftr5PCBHVmhbXnzAbiXFepCoBNtnpbmYx+crF47FH6dd+PDJdG0wHDdfIgC+IoKyghE5owO8SG9Dgvx2d++D0Pq+TpcMGu4DVdsw4UHVFOKa1kjT0nk2FNMleBBQitEFbFO5cGnmtLcgar7xqdJPUx8pEGFNF97QE+403nM832H++63JPF+llqLY+/yGl73pNUvX6nyCVRFKc1le96FR7/kaA8Bo9dwmMSuQJf3TKLGuswJZ5yD30Ywnhee7Xcu6W6/A2wYUh8ksuFOSz9iT/9t1tY0i+3TAiDet0wn4tEBg6bZeRxM2b++4Y9v5jdElkIOMj6kJlWdztfWkkMlXjVoCadEoG2pXWE/13mTZ2qEKsiCCAZ8g7N7vWCP79QEw3yWsMDnbxBRADI2hG1CSo8lC/aQTuHYRqqDaqz+9BhsYycab+mEotkrG6SKfSSC+pXyT2M8nqeMgZ7rdSf/9DhXHn+OMk5d/qV5X8b6JpHjKvmnhKiKyn/tIKomfkU3h042K2oYsSk8N+pbtVVAYDVSvMwKD2BYjwCRAFHtgp7PybVJWC7lK4oA+GNoY4FI4YRK7BpdV3NALdDMFHhvDuvE6W56KsrtnW1iTs7SuZ2treSu1tyxVr9salqiHShEImM5HDb4J/a9rjRfUfwDro+C48fQKP/gkduMwulnBQfs4uXE4LQUVXRknG2bCz+5cbBUJY5YjnAujMt7EB6NuOMGgRfbK6CFJHLYnPMyhbgH7Do61rmvWGWDAzMlslT2uB8UEsR6kj113C48I0rtFh0HUkzrUL7vvRwyP6jXjXiC4UI8k0yUoBMnbJcUOd5/yz/b57eUOqvtXhymYkoaGW2loY9XRnL/G/K8nVPybz0GRGdeFkRjc92nV8yyAeSaPHhrddlKiMjxLcR7HBFrmkKVLtjxnr9dur8AKG13RpsZxf+AtokEPsFvkhTizaORDLOEfPGpqH2aeywJIv6mjbFFM+R9u/jxf+026VfeCUER9FpqDprpgKOVcxYx1mRNGnLHbmzmzw6ws/IHRGfqc//08yCSD3LJmlpd9/EGjipG+YN6rvT9bplMZK/matKqro8vs2zLkfjpGfs6o0lmwj3PL39CvylGzoPHLUoTmzjssfV3Ky7ib/8+U5drK6VZXqbqcTArLodw3toAsOSPRpg1h7B84B/mLLV1mEhrqgo8SOS91My1dh0fWaYnng82GFSju/siPka1zvjniXvrzzpBxbH/zVcj82mMSfhWK809nOhFLhUOcDyAChdBnhP9lAxCe6YlFdK0kmAwlpT93MA87hHI1V6tjLNQ8MISv4hae+q98KsV5rq0sQ54edUkZhDRCfuBhiahduyM7+uR5pINK8+LbGKv3QQCGNXWUZ8wvDqMhFPNrdm+3fsa/IdEgUc5AlBskO5DtrjDgIrXRbDi9A6yYp/RQB5iv2vTbK6zzxzym0mxpwtRMTKsIBJ5BcEKA8lhkHDt+YXLN76tDlGcnH7aj6sauasl5UeplGWOZCLkTrx4Fp+ZJjnwlRtC9pg+od+cXVVcE3L9h6I9NUAluJ6MwDtpyI6k2USWtAH4mFhdKfp/f+hYFR954vGLundniSYu1zxeRnfEefs8vkzZ5FYKgOD26CgeADqlixFwAaSfbMv2OVbqhD/6JFkrzbia+r4Bfv/af6iMiPveoIXqRAWsiNf4aUr0jFE8EmZdm+GfPzE19hkQu+LeyeFaIaPBnVcdlHj0G56jObCkyokLn9BvFeqJpLjUR3II9fpxPu3Hg17ILgoJ2r+IqxaneiG4Ic4XZVF4vPdrFIqMO8n8oEfG0DHcj8c8qYRTK2LV0F8eKxC1Eo4AN5SVZbl0m1jdwvz84km/ABdD3Gvy9VJIJoGCwis35TyqsTSgNUXWdjCcpuJnIVSAm38lPIHNy8Wpwcy/zYKLq2uq8fvjkbXcrWVKOuLTid7nmR6KhcHuvDX2SkXliZBQB9tmIreWOirmuY2wf/y5g+jjKI/vIkOIIQSBJ0ozmZGE8SSz43TK1JZ4jYVEjUTxule4hxcU/CgvL/j009wGl45Y/dXgf/W8IzO9mHfw5zoVFCvHXxIVoq2CLdToQDVWOHiwZqoXCk1znL+3BHse90o7CoMJO8cfieapFIWxXZAgBdRgjd8j29YMRnyKaQeyshTVBItMzIqv1NhsyC1Z/5Wwxj/2+Wo91bshLZZ7He3qmIQNPt6Zd0yLp1z7typO7GIgg8aJc/QqXiTkya/LET0kqc0S3ey020X2nL/5gaiCZe4UNgC68W+7er+Folxge7x7PC7pWmfH9Twb/Cw0O0Hs4e55WJaBhBj+DK/zaf6BILCGro+dfYPQ12jWBaOnjMRVy7E1doUiCuCOZkjKQgi3lzB0hh36QU3mqa1Zf/Et5TiJ2YpaIxBtOUZQrlxkoNo0MUef8GYv1bcp/E3MPZvVOK2Gilz4D/pjR+zzZS9QJL55F7ABYoiFXrWAoPFehnOa2FWzAt4M+aGtH2DBGyOZQA9hoDPJhBp5RQK9dbwp9bo6DNlEgJeu2sqnuh/cOE4VCNNNyobh0S9Qi02gLaO/dO3V4Ekpbz/dTp/UL9q1CfAxAP+1jLk/9RS2K2k5EuugtOchbSdtjuD1o4Z4EtBa3hUolkb6L/L0ipH51y9ILOgP+AugSxKIgEMPHnwkWIhkvE+54vzJq10Ny1uPO12Q6kkKAJ6rYNquckNwM6enwNhn9sVQ1tClFAWWagT543ruOZUmT7xZ8AoI9k8Swreo9CpEaXacXJ1JIIj/S98cs1j9u12Xl3hGAnvx//nCqCkZyyej9ql6Vq1HvSM4GOKqAjGZnKgolMEuTEO5EEQDSXLFi4tgPqQ17Mo//1oCc6p+XwihbuMrXk37kyQO3LmcyUPN0Dh8GtQS4MqaAKFsJ1DBN0LiNVNLpJc1z4g3jJ93e2rBJz9qhV5qaSYLzbarfLtHMPq5UXk5+xndzE8+VQ8djol8l1mJ8GbsTN1rVTLx9kztznf5+e8lD2q7PJc3wKTQpKfo6DCEfEti7Vj4+LRGqoF7ex6pRvPsUn9CKcQhKNShAUUIyBvepjs/VsvjY2bTa4rg2DIpnFHb+TRy7KNrW74wWvFTpl6wpF0xsGxg511nwKSumOOUQrR1+q578C9LM3ct5DsmgY1Aj+b3y0cl47R/mrhTi50sdSdTjtrOhuh+Yv+RRedZ8qU0PDd6XaemxpWbAvfaH3GKBkVebAx+yGHWT6GEDEdabjed2goyMdOwogE+82bQWh1E8gG3NV+6fPUQMuxpBE37AHI6o4q+Epz21KP/4wpAu98rkB5sND36XnOYVCW/1NKyIH4LR6jsoLRZGOT21D5gZfScDqR8QVZPUe0eeFWxT5DiZ0owzD4fHsSCkD99mZY+jFl/E6JbVHmdWtLQAQXfjXt9FPT9wF1OZFGwy1QTkBZeN+DlARDSJnYdun1psl/GU7S1UeBa3bn0kTWJqNyeuR9qU4BHQE+i05ePTl1MXpRRraITsA7TgKqw4yaf0xhP3sdQPY58FlZNWBp9tECCAJK+l6DMGx1eCwpItBBN3uevoNr9zpmoTVaDYtTrpNmYc4+YmWQ4Zgeb6Ds9xWvzOMB7La7BiprWG+YBBko2qSRBEjpssiwdtZEgnCte+7aBq0eKuzxD/dTeh6ctYddMkAE4IyawRxdEq70qg2/eM5S2XZTc1oKoXhWAISOtGEb5ZRYQGcIwxTwEvlMj528MtqHoKnZCnIuiCw6pm19mWw32fzEJbMXYZPhKhBBOLsIxXXfm/Fu+TTtAHF3J2+34btAivPe8fI1Ce3Z5C0WOnN5sj4BT1a3qCHreeZbLsWefDzOTkvwZYSaroUiE5+t1gt34OTe/a7E5PeJVy92H62CBRAHCfRc0zYXqFOToEbouD0IhoOAEgzHbYcCAng8J82vC5trTRvSRCPtyeqILm1n1EPUnsZ1RaZCJHhmhJZqCvghgLyCqbQ/sR+WbgmJSTzXldlngU/pdRAQ88iEYKJnITO10neMfjzlyB1EttdZTb/g6YKFmx/F2d1OELkTz5aHN+Y2v6lc7fT+s7m7En/ZhmgLu94CI3IAk9rlykTLsBg/FYp5WAWqQSUL7iStSyKhBu7T4LoG8n6rsV5tawXR+ZplEtHIuOMfJ9cGOFmRE9NO9lqJL3NDTI0ZN3vrbucXMHFEPKdlFreONJ3VxX8dlblFThEiutwETJ+5ZL2T294kaIIp3L8YTFkhSnLG9VzqyK1xItxR1ytxlaVsF+VlfC4ejYVoLcLO2DWOg40foTo+I4MiAsNzmLQ9UKOE2zkfdbHyHfPH+e8NCpmz1/p+tH0gICmmKr6x2gojKGwm1gsUZBG503EZOgUUD/pA+/ZVPKecF7+0rP/YblyyYC7qXIessfnS+XhKY83ZFHWqyA801vqtbdiP3k8z/8++xcAvJuH/LLmyLNMHia6n5HjOD6BqOSOMuL0kQVAGbRiXQZEefl156GDDaZ+SEnqZaEdWsO9Qffq3cBfFnqpf1Ly1ENRyK5ejkkZjn2o4b4tDdVeunnGiJCsFHcFrXwFlnsMyG5TMFJNWOhKbSYacr79tO6PtDbyAW2G5gk96DiurpXj6xeRmVC+46Q6x7DasfhtmAWsSNOAIvawK9xfJls60c2BWkC8jrYxSAEyDIzXxu+34yRZCO2bDuYRhWQeSY/3IGMts6xTOnzw47NXJFIg2ToVdoBluYQtc61bfgI0qnVtQBEyyiBrPvRbY3asEiznX/lW0WePPy6y7Huk6hp9iFVp6YBl5dXMhsMHN/vqKs/8PB7aL0ISGbjELsMwT673w22lDSwAiJqpifGyn3Q0tlH2qZYjb7wr7MZAngq4oSrUW/cNtlnRTqacSvIbIwBsdEI6wh/DPDnvXYUkc9Z/FF6Wsmc/QXIIxohJj25PjW/nwwEpuzrD6LF1/USdpWE+gjhcbO3VPxAQqi3OPU3Ie/elS0BvIajGwUlj+7Wrxk3iBadL2Ufwrh39JqibBNV1cQr4ftokYJFGFMUEok8TBvL/hOiZeX54VD2R8H4urn80F5n0tcAfiNBVTaWvzXZ0ghMhiRUiIUN89zdpzVCsxvpjQjWLT38ACb8XRl3F++6HaDjyGymTrCum1lzanhcSqbZTh7WQPVrOQ/KASke5XQuRGvgd0EOP8UrsUT/6ZDwz2Db1g2QkoUnILyb3X4PUdiZFz7i7ywyalLH7fftG3qa9zpgehqkL8/VJCl+f/yMChR6Nh97woxLLrEGxcODPDw0V4IZz7LURGvLk3i3mzkyTu1QtbFUwg8liEfR/ahVmCtoQL01XOEN2pVh2iFRtV/nB8H3xtdahB3bKZJ4a6ytKpNk6dH3ulxyd3t5bAKRhG2A0Y7Boj6vA3xQ2ieuIndEgY13ByYezBB4GAlRD3oHpwbI7+4bQ2RbEusD4Msmxn+0ivyigRHa43kk7VDTj2BV6S5U6Bj+lK2xh4sqqaJvCVmN8Yb4ZuSYfFze4+QGSilsNWQfw1rdV7m2LAeKd8DGXXuvwIAyqrKVM37KHhJjS0JgNjUrAMA4Y4JRUuKjf8CpiCFyLEiJtqFeLOv9KAMdgfTb4KJsaym8xoV2bBD8FVPqKJ5zkatalIPiEQabPobBfvmBm3Fj72yLSESTaZ2WZYBOM06ZptfM1eH8vvezcxSMk2IDtM32EJDFs+klruBv1B0yLWHkmwpIlhSnXPmMUVsE0/cpvQ9diMcp8/oJvpoliA1HpkRvwS+bi/NR9GkI1BDw/gSK0MjRc1UPHj8ZYdIg6x6zh8H7luzcOVAFCAXM8CAkdeafk5pthBWtPJvVnowaXSFMxulL3VCeWNmBeYgJya1Gk/HqKPtR+TQ+kEktpQHpuA9UCod1jRjKDB1xUG2G2t38citgBGBJpstq0Ha/0uVel5Sin9V9OA0ABxF+x5jLG/R1KP/8FIn5UVhuTiazXyZma6AETe8e48HsMNE0IFEHBbwKnsi6riSs3o9adf7fZ3iQ/tEh4nn7ZTkNapIEmJ4XhBzaTRfNa2O+ltXWmLx14UyHRUffSyJ/w7Rbv02phzP0VBjaeIAGAcStt5slbFG2gxA3Zr3ydKT3PHQH6o5+UDcqDt4XQUe82OO6o6cJ721j+sxPBlQp5amy9fobtUyPkQxj6UB/p1pyU7JygpgySi0S8jEtRPmx6LO09rfDI9Ajok/LigDvD/Wi9lgg0LcGbn/peS3Aa0k2ILGoLGZphwRQnaMXYvI7E8jC753Wdz4WGUGFCyyrdjYCxVi59sUCHD5KdYeSw8pMNoIOCMseP+wVtO8oGmTZWt+T4IO4mdG1RxR6Wff8dl70VAjqTMD3URPcdlPpz8FtHCfvT1ZxJNBEanNgLxKJEdrBz3ILlcSWW/vRFDjeM60FZBfCE3k7W5ToZdjZ3pWMluvfCiksyqyt7dNjFc+z9XGg8X/wopkZd8AMKCEZfarr93p2fJk4H5zuZbJN0KXoZQx/coDN+ThuqtQRZzKtYuJdMQbKtt5sUlUhsB+79sdInVgpXpcDl8NpEvz/pJWXTPt8RyH1Y2HDsLfimjYmWCWDN0OfgZD4yacKtiVPSkg+7X3hg9wAXvsJbPzs6T6IM2n8l1+9EGzeZlYxLgwDkNOOJ8reGfeAP+htzHkCbOFU2xXLZYaC5FP37ddjW5tEBEiRlCX/uVYFbC/EnD2ViTWI8UU2beJT44gJbLLE+GKkY9mK/aUxy+Frbv8lcbtUK50vBt5AXWjIUYV9+k7XyF+vm6da60k5xMP+f7VSY9Se2CdSnjDzFpwMxaMv3R1YYuM0WVifZAaCn2J+vlpKnYxtWoLHanlCowXvY6Zsr7W6NyU7yEs0sRuEIXAWLJlAknbYhRE/9Z9iTKcJIqSzj+6sQyRjMLgjPOoqgeeDHgLG58tFE59hlyS5OQt/cg2N897xb936lptv6t5+LoH/0F5/4zzsTh+MVTRsbykRVhvy7+z2byWB7QfEWlJUV8GkM7T7BVsM5boY9Ogp9krBEnqbjCOXoEX7G+gMasJlDlg1gi6p29i7T0xCbN1TNkd0oIOPSlH1S4YivdPortmqZUxwgQ4W/GaaWpXc4T3w3KZwrBjkRSlbIHWVbq9iudZWyKLVzFbFIfTqtGyYKf4n0Nu7HRycPwpHI32Y0cdsmqyXLX0C10kr5yw3mzpLfCg8a8wftHio4zx/TVpvgk4Ohz2phSx94sYS2jaLfvswibhvN9ccMnEGsbtI8hmvWpqiIx57+4tjiPTk8jCMzYQ7h8aZjy/XbIg/95wpXrNcsE+FiGuMxVTJYaNQwXT1mfeJfxGo0L1lRIqQKu90vBnlwi8K8Y52oqsC3fid42RdIwhSlZo2QAhdaxj8CDLuUv+0ls8jwSzQqIjeWrUkKyCmgl9PNpwoBPcCK3JcTNzCrMQ61k8iBTETRjSsi7ruNYBGgal0ifzIb4g/NbUBSv+UKzZYunAKOlTH8AcH5xoQRyV/grv0w1tCJLgczIXohaRcQMtTtPmJL+zGkJ66I2hNqvNMzrMTZHjaQXZlLnsM7ujS8ydBU5jyiPgkm2YwmodJBKjhRs7ZPVztQPIFye0snreJTpK/TpZsXlWxmpJZznaQOZpStITNyKCWFoMdHIp8T+H9CT5nJVvS8HXeA0uTNZH72jSTlDbbHFEs/1ML9EK5uhImD9HaLapahbs3Ebir452uC+J1aZ5BsA5LgEjdIZsp35SvzHsxYfbL3ObHmzfC0JIQ9q4PJ/L3tSPefODQjKOuZNxybMFS0SLObdExUU6AULoQAfB9J5/k7UJg4bcixknZkLbMPrGV1FY0zPnmiB4o8wggA56dWnyecfRVBBATKXHdff1zQ0b+tF9okUAoZvR4gvTHeGgmJUZtNc5+pZTEfy2H+LhkAulTNKa8sKIAE3+LMDz6Get4yHepPQyibD0MNi3dDXQbIrOD6+U2AuLL0ROXvJMCu7yDcr8FqqtwER6QiiFkYLRc6l3v2oJ8+taljfsQH3NYYtBJKbUU6vt9c4rrF6XB29MA+cs9DU24PZjLCnTtOLYlrprugrYUKt7fJspsgQHfCapRjQpwGX0OptAmsudu8JMSBzRO1VesTBjMg7GkCQ+Ql2BnVndbLSKvu5PM7GVjcuG/sXxLVDqXyODlnk3CBpgDyCX5WDTErJHWW0YR8rkLY91Ana840ceCuqlP6dL+WtXzz4Ga3s7GSPmGDqtd7JaVQsB9+EGPp6fcR7JWEipHbW+SFd5qI3Zux8TXuyFYZj/jewjxGi0W/wm16bKap/QJzAVMxBsqL7TFuSAJ3xLRfX3EWdEx7B1ttdvb6Q9aG32EiX/ovBqkUP7cZEnHI6sXbhcQrALFSzM48rTPpF1yeI842GOqaT8CfyEvMuRYOFArbZnpOguqVH9Dm2mA6jHZDuM/tvO5Z8iwmWIfk3jDBiqM5GfPWtqjTsqqwbPK3XRPACEuthfonQaynWYqr295p82FQHH1IYf7YwnGTBOCW/EsYSWDWDMGCXvjocvynJo8zenYcnHsdFKxmbGk0/bdrzlNjSDWgU3GxoVbXxacXkhfiuX3Bsrly3OrSK1wlolU1DD/rx0ajZbyGqgnpg/xCqenqaZ2eMJ/r/MyMTJxjXUArv9Bpjd5potkldmD8NBr6VR5P06IzQ+IJ0hiEfo0Qx1mdGKoIdr8BLNitrrIOtyRDZHMD1hhrNEkpeoYGXBLsibZ4k3W6IswrODCSu7BBDk1Jl2OqycrkgjfHPxkjMDizZs+jPJgysuy51o+suiAKcMMPms6Z1NlN15GiL9OUqEx5iOfIzTh+KL8nSxnbOQwtT6mvzCZJuXwNegGLij4+fh1L8F4Bibhh0wtbO5qDSR5KjPIXkOFUv0FBLIb5NZSeZWR99grMz5p8DWelRRjY6GAKdCVw8kMuBybeszS7k6CQSpq0xwAFDezJRI+VcIe4+Hi5hlg+0hywXW6cFo5+t4r8zHmDT7QyjRTcxH7KvKn34MxMB5yCXJGyyxYgMAA77PCO70pd+akanS97wsbX7IiLZ+0xmlOEJS3qUHcvrvlpNleIMizWQ01hdIvVRHbYN1VbmL2fndcoPhFb2kGsmd1a+NJeyzKwBiv+DIGn6A5kvMZNtwm8ZMFoJb+kiq5j1cGrRgvzx/pN56/AB7kpVL2Iv8k4GF7pYETrzDs9jlKOMriEo62vCTAXDG1LaYY3TUT8b4NtkrtUu7uvK7A7+K5CUlCgjDmI1FZJL/JmSgUCa82ayxG4vYSvXxB6h7yvxXU23OV8cRvolZfwwbSqXFIkaDkGjixvk/4RyQ89QEt7HdApoLTXQFadgyGo5CtxboCfGJjg4xT7axDzBfahP3NV7F2fDiq4GH5lWdgXhAlh5Zx8WHV69ZIh9kh2e7Ag9m4+Indf7qD9DznDufhWP3Y8huEyGBKzlPvGZmuXbzsiCAqgzeEfOBbgojHYk+PiedKKlMxWYCaiqXMOF1m3XU89F95C8kSBgCPkk8J2MZ0nzdDNbCOR2+/ZJj4FpSRoTi0zOATdF22NW+OzL7G5hXvunHKIuPne527ZLv3cTBfT1YCexQ9DKE/tlwUG9RfcokiZUPtbWOkwv5kYxoDh0bdntdJAGDjS4ehXqFgqG/yELHXDdQrvtLfT5uCmBOxmW3BxBQbU1tOgtFUqm76kagrxXHDwsrg125RIOgN47D+Eggd/XJ9DExHk+1+nd6CEQi3iuJv3lvnqvqAj6MeRXZxU3xxseekobiS9QV2tzMrkIR25kfHURnq35fNZMUHM2DpOojKviexNMRbnBCw4yK31MFR3lAeFX38JvwT4J9qvrjFKazi4Og3ztPslXRWcgtHooozgRZtv85RDUztBGoTHX5m+FoSn/Um8x1OosELYXQ7hZKuCUsFNZF9RFTjMpkk6MaCQPALPYV6wG8Upan4Tk3HUD/JHZRAQDds9+9n0z9YdxaJt0Bu4twXYJRI6a2ivafZMrMuJXyjCq0isci1uFH3/PQn7vm4KiPjSB3Bos3zhAqEO1YcEe+ZkS4zXZJV03NHoC2hXImu0MlN4IhrKzHZcgYRR+nQEt3OEWCBDN/3Y9VOXLuSRCccNDwXaP80mDodjtxBAZ+j4BkNkBaJVFMecQ4SYfC4oQIkSGo7a9mgnbCJyS9JEFLhwUfyA2r7eLcll9KHg26lHEThpdJIM39DWy2zjmYFDXTjeSCmTOf3Ey9R5MOjB7DAmEc0Yfua6uOd21i12S/iBksw/auZf7ZFfVjpkbr8HruREmDeEl15q9FFi1LAGEm4ACA+oKlMhVPbHX8MqWMYv8dGt3IhQ/eqjNfFatbeeAicYu9bMnwMTChL3hMPiEEdg/TX8Dxbf6x+59z+/DI3aaRlcFu6wqzQjzP3D6a2dhhWRyUmzSxu+afMrh+Tfr3UOhPzss+AmYGsaw5xnjmvZy1m1JdnvyV/+bVFL5xYkwwuC24zNlmIeM8hk1XUwHnx1WilpQYptAkIOou4ARF8TvE2l/5lh8+PHf116QtMA9QkVGXsLwncXvwrXA3PlwoaJTr+6+f2N9Yz7UUGXbNXEe9o8o7hKv3/NdW6LFkCECtBjJGVmP650o5Psmhg6obcsYqHzenNjPYTcPrLnpX164cPj5zOb6fKlqdJetmGvSlNJMRJLxQSYo0mmfOkIiEJp9w4g+dVefo9G0TtQiKktFtuyqKfAGL3Xf8pd+kHgkykyyPh+nXLGVam4o79Cz8nWYjE1zvczuGbpW0M3e5AFGMrKk1w3FZK7yWsnthjaQwfCbpkhP2Clp04fX8Sy4p8/T/65kV9kvqjFT6ygS/2TzwOnPqKHF926Y2J+n58ahB2G7IoRVVl4bpudHeuLnvnEZ0zJzrtvqRROo4U8iee43RWU6qqOURX2LQO0mXj7IDywDbJ7KM8S8Lus0FVTw/eyUv0QHC2m274MWWAXUwfjWSTcHa9l4mHBNAMiZsSTW/PubvrE8wG/vlbbabivsXhq33EDsL0mdmoo0bKJmOdLf4OIPo5ShkGpVg6ymMYh/X1tyX0/PEKn/zcjaYS4yD31zc3M5/SKkWupvid9anDPgafnpsV1YYd6onVDkYHiE36/ZfODIOsVqK+Dr9hBMGmFDZalozyKSQ80Zg0aQoL85PTdbTN1YvBvMQ0+8wzoIhl49MoL/HmiaakiOkUlsDYvWpEXMwiS6ks0x6wTjdln/68JoUWcCfPzEmWLUficDS+60HXWnK80w2E9F4kWuYpTihN3nzfvknoET/8xao4V3JXr+8tBpMtfQM549DWHTES/xWVJ4c/NGuNGfUn7tSPVpCoNIu3QkElmwVL6T/1XLfdG/xM6OP7e0ca/0vjTJpFGYPjSV46mlqfAoVJr6ZDT2o6Z9phAL2ZuaknXKJJu2ekQ+Ta0D7QPBL8hfFUbjF0qVZgshQCPnvzoK1ngi3VL1qKUNVs/fLxy60BNYpAQiCYyF9iGZCik4P9IafacYVBhLfuMSC7FbylGf1KCVtTzuIn4It384OLt/spLwsp7bqf8N6NYlE3aMQ10NWNWO/v/IyGH1HaMcQMiYDM8SeVCA6srAGG6IHbGlP1JOgeeTlsCHJb4Ipw3Szjx4JDY+kIi63rp0nEQ0Bv2Wnm9eHmWLVfw7Ok8QBzd/8fewKjj6CqFWTCeGjB5lKkdGrqt0Nn91C6t7jETKZNkqby0eQq1bHJaPiDxqJPbRjNTkI4/ubwUzbiTTVdOXZqsXGwqAm3NEMJarUzEITWhOUZWDSJgl4VohEAOnrrfEQ6mv/0JmEBDjbNQB7vdxCfjHQozFs8Zj0b/8pVYf7p95ED4TvPM873yu0VZcY3n0mmVc9VzJ6ShYRzI4blWHTbn7ldSJ4lMBuyEJK8qLmDPT3uCa01Jc+LVs615tgnBElstX3u2a3Q3F9QhQdHtSt+rZ8x1UkxJcQHC99JacNu+hFpQ/SMAAxm4ZABpzGBvncoeb8i1kt5ipMvU5ARmvg+ACGCqsymcwcLwtt8jNtC74oFUnUqjNF2SGT8XFUhQlTf8NawpldUmuU+uza9ZBesQMp5vzdnzjoiPCtEAgmk4JPhDjRJy3CJu9jVxtIOq2WxOkx2IRdkuGN2TSdwxfC+w7gMqObafUmewe7XZtfaJDivqhcO4ihXCYBeXFW9g+Zrr980fOIQmn5BkteortmA99IWIl2o180qq4RHlhxWQ2L/ave/BT4O4XqqqjDPJ21meEfHnARBasICmPIG52rAg7yqHYlIYb8WtELiUB06QQOH4u9t8BC0n/hiO+p+MlUpqHkipJc6FTBeINV0xukhQOVW/6ffVgRT+79Xem0QVeBSUMKmNmiI97jnwuqq9sg5iyz6FoTGssYDFRUFd+RSnIx2qvFKKyGSQkDuFGyP7Fp6Z+/iK7SRGmzfTe5sq5Dm38D9aGfOTV5oPyoSAgl3xzl0/CiF94puuLoNMkLQNqnuG6Fdi9u7EtJ0XOAsgisyd7gC0qlCzyyQ10kPZ/9dVpvCbocNlGMESMel0eTasMHy2+QVWTp4Yr9RukGmSDy+vWAmBGH9nSyYNY5ADkcutW3C9yxbnuD9aDpkTaCxPBlMSXNV41J5orv3PhpVKdJMVIJJyhP1HtGJkaFemJv3wlQore2aS16aVf1/+W+85854YXCCBerkKxEN/xH0sbVl6dB5eeNWxR129v6QJM8ZHj82w9hXhDvxaXSkS6DyRRp3EcP7mFs8QNKm9KaqRIUxOtWiYTunkByDOCZ3J/5u+gKHnfz7TJ4rxwM3syZiKE3AqrBbghaz0ZDakUBlN3siqnrUQuCoSoUJtZ+63EtW6olxRZvkfsSw+FQ7EMsABQuED2GvZmHfBj2NdbMgMVVPG+gHK6hWAYS2sgfL10R6ELRv/3X7tRDdUwFXOFEtr7s2poxGBSsv3PNJdKzUnNz3j1HZKnSDT/hetEZ/AT9HDlNL/3Hlkb8rMU8WPOgOlSd0G16/Xo3XFZTownvYUxRkt0hsvwxyy2FP29plmHhxEEMPgeH0bz+OYqWBDKRO8jps9zx0Fk94tfvVdu8Tgg7bno8Y48UNVKiXwGeYJTbDz1BO9s70cMNlYnVB9fz0GFO9+q82x2hm9gE50iLGB4I0LXCxsRDapdxtyE24l76/vQN1r5I6FW0nlkqareedDootdZW43fhk6mbWzN7rm3kAUtLCnqYySF1h51KPMYfM56vZVFgZ0DdxDXdR7bvzLv91xWU/Ovfu7EbwqTj/u4LHQlVn9hclLkP+bNuEs98Fu+/comtJSEbwoxAludTvjNJbDx34AUL3bDtmAlvwLnAGaXRsZIzwQSBc2aj2ChggPYLDN/EsBfnFJT5GovVoCXlBVPsWlW4xAdC/5+IBB3O2b1RGSrEkTdNnd/r0LjdnyGTsfQLeyLEaVBUffoO6raYqvT6tqhn67ri/v+IihbrH7HcuNRFxubypiz6Rt3ereijbisMbHypiGcpHZvkEcXT6X4EqcLTGOwUaNtVkclpUCDRqob6XNuS6x4GZPC+07O0BVZRuXfbPBH9mFAmJyITFI+8pFaNpYDc/rzFJ5NIAypioTaoxkmpCPZ7Hta5sa2Z4Dqpl5ExXOa4r8/vAi+ej3cn4yVpyjGGIa7EnfjJ9kDKdjl8xE771M94krzRbCDHDLXVZCMipbhvETSqRC1jk2/jIuh/YfqGnyPRHcfHE2JkTetxGohdw2+J3YyUyaFdvDWbkl1V+7q/hbeyFufAaGGjSNGq18LaN6ir+CgZYqO6m9E54OcwkFa0BZwwMSmjMW8hLPj5uqrjHN2YUxVipl2SzymqsGtoPME1UYgH/KFamKJ07NJGLR+iY8xqcGZ3NS9CpiF/1jctGvl0UQJCdJX2iFOG7C3yP3ZvwPkD9miI67omdsfmtQmIifT2D7N2U7lbd3gMsuRncQXwZyJSerqGL1/ZuOsV41nPWBKQvCy5FwRd1FKBnPHSXfzk74YDdFnGnj1V4Hb+/c5r/FVZG8DfX8KdtIQV6kbHE7TgMuE7XSt8qGH7iRCjj+6M4UyzwcaBwvCNn7dzowKwwVV3Au8bmjAODu3PjjH3DAfLcy7ZzSHJPBaGRd/jS9JairOR7EQKLsELlvS0rZqI4gAfc0uiKIVbeeysL+RigcxL8fNYbyvkHfL99ZFfEbeNBiIRv5OUVt1CLLwuPd2I0SXV9ahw8gGBdJ5DXxmjdr3cYu+ydRA0UGPfwuC9WNfpnJtv7kdHDd7Iye1Kk7EXO7xfQW3S5ISDtQ9Il8pad0811PJwBmrzaEDcjUxIYMnvaU1imB1qW9JkQ6ZR4BJaKpsNcju8pBO7UaYFE+9ooi/RJoRdywEwi+Y91laJIiFhR6MjQBWr5mS2j++KK8sKa5cYCnj7M80Q4qMBq4Vx7ZnC8iqdUsfejzQLGIjh6QPXFTlhywEQn4DJ+jUf0Xz8dWCnpgAyDWVAuzyNpteqc7YJeX/nkOntlim0AK4oBR5zM6+rzGlj3d1hIOlXhjkViqjcQM5AXcZ40lMttX6oxXa59GEUdrE/fM0UJiru0FEhGe6Nmv72rxFrFMFPij4+KjX9Rm7T2KMPD3XnCs2ELktBXdjPooBGUS/h99m63qXmjQFxra9eNWpC+3ef5tNs5NOLZnVaISgcoSSLI5btQMtwG74j+Vplmic9oq8BR3WNYqae2w8klJfizsccMmLvc2XJA5Vqclr0WQ4uwZTqp+DNASYopDCCULobkb+bl+aobgQl0wna4WBlR5l086gE93rJUBCqX/B5G4iGrhE+IKwlVDaGVbzr+CLRsa8ExVAOcnNf1Ev9mQwktM07aZtgtbWTRuxwUM7tNxZYKLiChIhfp4vRjhzN7eA3WEeCgD1cVhkv27F1rP6KqHP4u2BylcwAG6J6KT8AvRUygEfyqCYdaiCazBCWBJjP31YlYpMFognpzskAXBQfYVYcZve02/k3HEoZ26a3ArI+NH248TCJYlSqQPtq0TCLuadyIB2/Haqw7pW6bQQi5Swq9jY7+h3oCf6zAm6H8K/vdSq66NQL0VYpEaVSL8f0KqkbMeJeze7dIvwubIQ+mLnDlI2JQdD9IpQ/A70wdz3wyRnp2pmKoqb9GTTq+ixaaTVGJnI/E9bodPX/b7vCTiXoBJTwkOqsUtf7kWQVucVu5EDgY0Sb6vskGxjx/1OC5OLa+Q7Nx246ydVByb7blka5QpX+jbLo9Vk9EsuTeZpBIBtwdh28IolhPsq6+zYuXuOnFnmaMEnsOTDQT9nC1qlwPVBOBp3LKZ1LvjmV6gpOpRJOKJhgcCejKzKKhgpM9TGvHuVuv+5am5nrxkE6y1V13k6HJurcuMeVznFlnwgInG/mVD6l8U39zFkkTJ4PYpppLNveErxT4D93NAlnYeU/kRfADnYVIVkvwVJRycM/DtZrGAxxByzF0HlJIzMv2+p+f6G6ca7Anky1R4uHhcqala1YxX/WHQmHtGPbn0eAOVzGvGMucyo7Hf+QaKxmU+p/aQemB7zCXJPQjyyf+9r+VPgSiDjWeZiDPzdgUcgqb5w6mTY2nnM9RRIQ6PWiXharTDfi3hmgE8/2rXUBcF4TIgJOzCMSjtcBN4yVDRGexR/nuxKCYe7ZhmP7Ez8ACa0pQTyiUs330fkO5N+hQaKo6SpIFYXB7dyQinWws1RhYaoYfNayTZnv74RLyJJGwCBYEFY62WHcyjJMy/SuTSYZKgi1hRnEEHpOQgsdY07tHnAc4unA8NXOaGJ+mRtvL4f76d+FAOwHnPhBvegholdz7ESnPLNKo2lUolOtqhBIMPJ6EndiIQMBXAjiLAaLy5tOGlu99+Kbx9/5HnE1CXkuU65jp7uO7oNDGwfLuS74lOACXt42N2FJ2319cno7qd8/cYHRHUr1iDBarItq3z199pf/Wy3HJXA3qQrprTAVn3ADax57/zxWnbeg/0dd4HGZUg4gYA7zzkQgnUfMEpCCAfNVlq8HrKjmQ/FzLhmTV6t143zDJbJj8FMXw+Br5ftKgMBxyJNhRVia8Gcu1eSyHDZROPLh1jas25NVwIqx+LT2zbUmlAjysimHM/g/yxx6NzAUTGfcyYXd4rIGURYxxJXuS9hfi/CQAgqG4Ra8ZkyGZDP1S2Rv9YNxveCystshpZ/yhPG7pL6EIsJvWhLjzt57vGnyu1zYigwrs8MXrun2Z0O3CS9X5IcKaZJXCHRk04IRm6uWVGK10WtlhMZM5lCLywBZUF6XMiC79AJMyVFa4JAdUnpF3RzXqUAer6eDgrjdcyY22/x7lJWZ2eEItDRXjHsgJCHZ9CF5gR7P9lOqEtgdas7H/o3WFcp7reyOoYI1sXAk6M8odfbGN51teN9moTJwazR7LEMC7rpfSppGZbF2w9kr8jKP9C88Ip+kIwaPEad97U2SkEi5Sb6Uby5zOegQ40dvHgPq+bJMCv24hfav9ffj8XYGzm+ueKjOznRbR+XoUDaz5ErvJ0Y0R/lct3f+8U1smFY+lBTlxIsKV8M27pFxpQ/I1/oA2R554N5G3xEMOt/HSy8tCMhDdYJkQ1vBWC6KMeWZYOQ/zB5Gcdp9FeC5CkKRBwGPx9eHOM66ckoBQyv8qZ1QwskcIMx+XKNfUB2UoR3Jb+lpJ0qFbp2pBodGgsPeekPwEr1TTzc0NZR0uvtch0QmWBEmLiR3VV4Jfc35rPn/w+VxWEGo+HnQXX4FbIAMuU4opu+9Sl/IYV6s4z5ySd5Hd7oYtnVQkDMNVzJJhQI3kl4dA3wncQ4GC2xLmcSbrKUKU6Y8KmQOGlBFKuJtDFAU49Y2/eAeQhTsozjGac2GU2hu1VhNWE4lPQnVq0+KkSBevhyJIgVtSojK23VQreSOM4W7FvnrvEtLEFnlIxcgFDu9xDwvLWg+FXLP+esAbmGS7KIpTtOok6qCSuSByc5Wipgg1DTiYQ3RoFgaOOs+gUWiSMg4V+9QObuJpjhlH3euoxr0A/Dw9y9FXeY8j9RFq+GmckZ1f8clETF7aRaa+4MasbE+vd/Id39HZwsHFZSUOCZUUjo11fW1xyXMvRBGhTuWRNzjkdAoftdiG+zGDRLlgXlH29kp4ZpECvzikUbmni9/THXOhIysZBkDpS6yPxn9tDXyQ/mcD7TDl8cSDV1VlaUY0vUxaCPKdfNuOAWh6ofjx0FZpR7+rjCA8YfHD13x0hxlcS0KXc4sX6BNRw5saqztZ8AKAdRvrRcfTDF1b3L7eTgW1CTRcSq8Lh0H2X7qbIMlRzVsVyj2viHHBLZW+mCoEDZYb2JPhxLX6f5oIqPe4QkYmGHOvQFi7O+vdUQE3HuQ0VnbepaX0IQL/4tmpRTNO9FVRBmVDRaPEFiLgnX9MyEoTnVrRrfVX1xS82gZFFwoTKQeXTtJa5T+syaGmWH6PA/4Qncv1RN2k074Qy3pTEzVNajC332gOSA4jCyvIJgD3FsbyJnp9Nhm47PRwuKz1t3OdGb5/Kgz3kAde6kZ6vUeASjopmSv9VrC7fldWWYc3aW8uTkw6STkiYGS8vhhRa7o9Jh48KN2y6o7P9HhbWN0jns2SuvB+bPZrl6EVDGM0efPnClUoVUT5ziOIKaV5CokvwlRvWL+SmKaGxviQ1hXXSk2e1w6S3lso7PfRImIaMRH+/cp8wh/e7qzvwKFZOjY4V2FCS1x+7G0xdtUQs3PzHprNYLA0P6dBIqcb6fp7Nm2OY/MRMMXxtEZ8SF6ByEKvAWWT9KyBkNji8UneXOoqJ/9vHm2Qnp31UEsWfjSTr28igWtGwoP35U3I1tpnRsJrXXX/S/Ls95LX8vhNZqs3Z4ovfnAiddXD53aFslff59vkZxqfi+7vL4yzAnlMPUFbCq/r4cwGHbl9JDAflSi4yffL8nR7NrBPYBq3I9KOk0/SIyh9s/vjNTH8z6tMVaTJOBkQ2gFwlCRVW9HqFKNfejtWSV7uzQ8d8f5Ec4i4QH6mHcj/hzOd4+kjaEc5QelmrVmw2M4Nlk/pqq09p3m7kUSmFOFYymxHNHfLPshDJNFEBwRQlTHjL6yFgHbnWRcLDmAE1k6/hR3GCQUJx8+ZEhNO58gsQFxVIrEXosv6IXvCFYdX7C55pkvSchGjWHZYS2hg9nS7Z83i/KrozSeowOqfnZq1bsd7dS6SrzccjnxXENy0PKPLQxAFDnBXF/rN67egWDHvJmCQTZQVWqrxFElBj+CoYWQiCzaL/kje+qhbEgKg+iJJU4r0+1a1k9q+URczEe2hGawx/YMNnuzk9z1D9Lbr1CaRw6fEkcdfNZ6GTACGT8M2hqlePGxNxziBXlnyPQ5lW5ubD0OQoJvY5pB+dILUrZ6JO2H9QjUISmCMVyEY5xl4KlyLbX3ZknvmlOKkpLfEFUgOVJbJGJWbWYxJ9+WTNuz4YJRGkF0Y8WWYI4yRVgUuzkTkDZ+rVQt6DJbAyZIQ+0YFHozsX90GZDlIsn92O3cfG7d3Pvo+mzSKBzBibdr3wq2tXUXAhla1OWtZAmnk+X6WK6ZkNTDfjkzF0fV4NUj/nJTzecs1ccF4rZN1zAzUWIv9lz6ZgQGeufAgk0SXRk+REUC+KVc5DmcgSGcGqVaR7eNHjgcvJOXZshmG5E1bn8YGgKgH3OzmzRi0KR4I/W2Tk//hV5vtuK3zU7FKyhjignIukf+ZsAXVipqe1VlXjIsCJb127/i1MnNgoyiWHslbiRJwmlyBwrqY8GTmNU7mri8f2FYzO01fgDlZ/YQP55IDpnwOuULnT0EU37RCxpPeLdEf6U+9N/ZtmmPe9enP3DPi8kXntZQ1xcN7Z3tZchl3CJIy+C94cZskR14ystsskZVrfvrjqgOS9vjYuUxsfZtWwVRNQPGlZTMSxRLbEeAPwAEeWgFbIZzyXvesdtseMVBl8u37tJ/hS8KEGc/knvNLmf4AwG0D2J1PpDUOXN/og0d0gZuHq82Fdz5bGfnyMEUz6CtoT4NNUHn9aqL79HUUV/DXX5ZuCdyJYr/twelOvh2C6L8lKUwaGqL2w5aPg4N32vnXytidpBjhUOZOKP69uEh8to8KTSX1zeIONQzuthvmRRVo+zG5EghydbjKqTopAhTvkfVtwTMe7REAjDdRKSLWRvMLE/0y4g4xJ8E1mjjoYsCo4zQ7RZcV0gqvL4NUp7hbueLaiJomNyP7XohHxpq33k9uDSjZuAVFtY14ulpnKmm0UtJfEzz4RqgiMuvOLRWijOJJlIniFZcxs/ytPJ8OEGN5qHSKKquQICvHBFasK4gfaslrrWR+r8r8GBSHAxyVrZ3eULvuTtrn6y7ek53yopqN9+iZVTh4c+FncwaDCNq9lQTg7cPHN5UL+t2MW4qZmTHK3lJlGw7sXJ5+qNp1aTwDfszIgeXgH+FxWzV7T08TazEMSkdvgP4yz9y5pcMtIH4n+xPsQtGRBpvsL/MWHKoZSi/SrOztZEdDMrTy+b/hIEwLJzyN/caW6jaWpVb9vFWjWbtA0GMVOCjUCwOLm+VygMXt3FCZDJyVXqruBoCQydVSk5rG+lsEKncKQCenLJkndUBoJ9cjYg8hfzyMXLtWEuJqugL3VLLs+DTaAVk0ODiToLZG56j0CmnmAP6ZUl2kJLxWeiMenF4RZeXhR4pFbFXf6ZOEpjKsf8imuxQz8Hlu4y1FuqidMYKMXF4Bz/Ypco3a4rnbSedKAk4UUU3PL00SS2gYBIltl1kXnjsUyJUI3OR8M/GuWo3j30F+nk3Ko6EmzqldomST1TqmOREsGqwCgmH17K5nk+RyC6PebT7Svms5J3vp7pas2Vdu30/LY87aHcQXmVnthi7rnfIqAJMpMDBsWGbX+r5J5pjxgR9+mwZMDA9jNHJfm0HSeUjewxds9XOUAEois0C/DfsXHKQf5LdMDXgKV57TD/TcR8lq6oV0NjibXXwGD1RffqaX402I8s1+MUQC0vOcsPBxPXe5MxSo0i2o/NWMk3KSdrWAcCO8M6f2caxhF3mH0lVNp4wkZeAKmd75FQ8Cp7p5kiM5MdDKanVaONPW0nJcTgm4YLaHL4UmavCTPSCaFsP4FGx0Ku/atSy/TwShfMZfOFPB60uvBJ2fuyFjLAZ5sRDljwlDM2NSnModrnGX37UHLQzYPHNGrPTQdl7toni+d+kzRKhViqgWFwqJbbWAJ7qSSIdR9lvmdPEpyfJqasdC9NtNNg5wrnhrBzX6vstbrbQJo21WuIbQM5SIMdwoGufe5fUlJIJPAR8XqnbeLirUsy4i/nJen70QFT4WanptWSpXFO5qyHthuWCcuU6ZwIreFqvTxRTYQhksJ7x9OomqY9VcHs4gVTvTQq6Aqru7QdbaF+GhWDuD3joVhvyAwWix/FTWwKJFNZtFDNyBXzuAIOc8C+W7NSnvKQDbFWbi2GXWu8+jVz3lonn85WwoyBzpKtKE1xSXSSbfkkwCvDm1PujuAhVZrnaObwSsqD+f7dlsBTGvHNUZt4fZK7zY3fvLfTJ2nhSVLsCYgd/kpiVob2y7CtZM10mG+iGrdHTXUqrlSVXZdl/lp/GEvrv4t1pTweeCQz/Jsp4IM/B1VsGcJUUtStgzLBGvM6OhKTG1vZ4fTpXviDz4w7FyuRpnW6IzFt0WyB3a2ATKYo7VAOeGu8EFwHqhlHfDW1TVR/lNGPJz8mMzUvn1xVH6U3t57PtwD3TBBVs4gMHtSs7ycy8fM4nDBDbDVjOC0TfKN6PiBokFcWklS63Ttl4BJe6Ox5vYsIgEVs66cGlnXD8I+zbh/Epy0iIrn/xtdzbPTKaJwyT5lEbN806aglTYMz08s68tQPYy6vFzEoLq3DfqQe6uenR+FEoG4RuoHOl+5s0Q9/ACE8JlW9Fs0dOTPaBYpoleD3zrNh3Tp+tvq5o9PlPUZ/8ByJKuL20LZqgh+7HLC/F2TAO2ASthpA4xzzU7TRWsTrPKlvoNmFTJ1DPUGXi5/h0DZPlz39HiJ+5aRGfpXNwXf9V4HMyUEPJMn9JNzUs6DOnQ0bTR9UHtv8eilXyVucOMLy3tf+uTLl2DrqIF3sCgMP76EoBNATPIyzBvIOf8moPeI9ZEVqn7Ll5/o7ia0rgrqit8SaucVvF/Vtdoh8YEZmHvHkHNas1Ci9vjzYJywC/IGVbe9y0ru1MgQ4PQVG/p7q5vrIme1zXTNFyy290z2hbneCrsOxLg8bePSkbGFja/YxSXJvMQ676AsbIK/EbKtevVAWpsljpSBT/xvy6R4W9yUiZuwwkVkEi4VEGjfDdBAuvKBDV2MT4STpj+KegbqovH7oYoFk6qEWN3ne99YyMaFvC/vOR0pluPsy45z/fWoKyFmz/6IwmoRolIQ1W2segJsxXK5ZKMf8F00Z7xIrlk/OEE9IqTdujQNfB7Zuo6olG0KTjyZ3zuKVXxPVeMhgMClx8ucxVoIsuiu6AMe3AN2l0Vs33BjTS23eV5wAPT1K1tQTJc37TixdyABEYVnzbkrX13+z3V9y0wFCr86aNWS2xtTIQQxpAi0wevKEXPdw4PyzE2UAQxelQHP2XFe6LO4StEfz1s26Mp4OoL+lsWnLkqJbiZLt7HUbMCs4KURTIirqFY0QQR07u+ia3Qnc4sgSB2Ir6/SRtCWiWGxHJxJdgQ5PmibECgbgK82+2nkyu1fFxQPMmmRKSvadB1cGI823Pw7cn8qxWcYkS2mcA4U7xUavK4ufVenU4KoH/UVZlcuWoFqGVQtoj6kgKJ8F+xtfK/+mOI2gT/bfOXOy5e16NXhUFINbHAy9k4YUTwPrVYPlWZjhE7gO6xloWUBe5/ABVr5h8Fmtp5iCYOsnmUNpq4FHNFMtnVY2E/xwPKQUkEk6UB2JyOIwmR1fJrGgV/ibBzhJRx4rZXBEo3tpdM8yp4kOCSUOb5MA1P157vgx2+S7mnGr+uR8fOzH6a9GxFFPTN+EwqDYooTEJRRufVVU0hOhhcn59psuE4p5m8tcl1bZu9JYkD0TqNO/4IQOkcpKfznFb9vXrA4StO2gME7u5qAzVUU/JdLtyVZMjvNkes/x5WJhAlzEunrzTRWcTGdfwGgcLtJpWeyOprXypVv3XYzOhqbMjEOELHCBksbo3kGwK3XviMPpXog9Q8WmguyS/MlAY5BLAMxLoR7uxDGvl3b+C23iQQ7e6afDFfqd2oGnKNeRux61IjhH8xnMJ3AgJTMLo1bJEH4HIcDDweBOh79+XosHLMycEfVY6japroyztlONczR2RsC2esAW7LxLk6+gOe06NtsiNnjt2ENYswwoymwNxcsRgEoBk7Z2gPZ0eFoWxO47hYN9kWwgRk5LO/UgnakEX3cRrd9ydl16+PQMCEtyh0TlwQGi4Di3UWko+TK1f5RmIQmNzvwmKwWUzzqw/UmxTGmzSsJ54TghadzZrSTknDM8yV4fwq183DnOqJ3MizNwPq4oxLIRwUJ+beJP6F5f1TAa4h+0QoD5zECa0NPUOgdgOnp6P6wcGYKMnAH1FDTVcW7xHFDis5/Gr7GXnbja7DccmvkRb3ud4aGO30Ycv4/i4qwgcn+f8kl/4IqoBk0MfQTj4Rnvrjx+4g/hFEoqI01dzaVyWRUVEXCZigQRXnBnhHGKsbms1yaVSekegR1taXNr6OxCbLAERMjp0X+fCn2h/P9vgdrFScow4T+kI3kEgIjxD+HYe40o8qxKtMjVpmyDikEV+1c9jMoUDR9ZeTTLE4KIz4MQEo69INPRdSEovMIqFERqz21CIU6ZCrhmElghMUVPiTQHNgtO4UbFu+o58r6GdYVr9j0Eq3b5tuxiN9MtORUd0lpNDoomxHTapc0GAGvIDW1/Zwa9zP1ipVCt3k8P7M7/D0tJLK60h6btFidcxxjxdTB4aTV3yCO+CNm2HxK9nB8APuVG3M475SEQ9JOMhTI+HGwSewJPyV7pIHMwkNm9hudrnM6cSzukSlpu/eBiexcbRrkXmf/vr1q1kFWQz1lLCOE6ncljTb33ec1v4if7A0sjgDaQEqgdQkUYNH1wMTFwRS3p3VLRI8Is+R14wUQzTPBXkVk2qEUbT1KdRUes3WfMoGFRBB3YOEw36NkoHtB18Rv6WcnWRJw57CC6UFk97dxBXdmLwC8kytiUvgGwcbCfR0nyHYZ9YK8CGPZv0NqWLortUWKzkGRFyHh+uCoNh6Xn1xcgKZNr7zKXS7IXr0eIypQY9XUrWA2IsYtf9iGRd6uyXvEK1fZO8tvDdBLuI7jpebxFAuh2VBDG7U+qU+fnHr4WKySLIzYAx/rnxxE5mWTgrnUQopKhUzdN5tFETv0VIwX+6c7omio0xjtyD1pjsr33gVGPjbKZAkXHbWdlZQYulVBf3BCxWXNAjnpR6Rdh9ZNp21wKdVW8HFDZCrPLSKFS3TfI/iBhGl1l4yZmirLYRunhM3m8v+NWk6ETh++g15ywTH9EUJWX51tewkvQNzh9aPuKTJ0wZLsJkWZhkheal8y5CBGl6TZ9dEooAI0XXG3IBZEslOFsxzYFK8k5kPKxQKvMMok3cFBcOtNExuMLDBPmKg2wza3v0/qvLkvSBJS4amM1mYciCeqU2lwIbl9156zkmi4mfckrUEwoZqzVdKWBzvMxTO3eXUkzCyQRSByanIk2xX8ezU+acTO+7HTBTKVrAzvSchtw2sw5fUHf7gV3mcn1d6GWW6GpbFZALxVs0kM4P8CGCDLRIgn6Mi2W55NTWlimOKmkbng0/zadi8l26pWnQRMzsn0AssjCIQ1uyETGdViNgjTBeocKLYAsK4tS3oXFtbi65vYsZ/LHpe/Fu1dCMg+fn0Pm4er2SE1ujB1uQSZ49RRyN7cClC79e01NFiOjm1PkqhinHOGwH8RFrljtpIO64v7G9dw+EFAD01/UVPh5l8qOi85siNH02SYLz4+IVzgaP9fgqDZkajfjaLwtJYVO3WDvz1VKRiLkyFxC2oXCnHZoX7Nu/GmNJ9LRJwGzqpjXu15zr5pgaYbdILYI4pcdBrACQ3KcT0Enrj1CAAJ8sHv/vXqtdcsoguoR1e1GZih2/RZ3EKq0gjRiZALd4I9sHIG2K5izT0R0JruinOcjboFIX0ClC/7lwnk/UPnhQiJ8eqpRnxr8k1h2n1nKDqxoRLYUJa2fudyE92d/56UgcY0soHg5M29uGPtLfYrwxqtTA/H9OuRPCRLblYEg9bSr3ceTf1eMiL71Cmhs20aYZOShxK1w6dp4rseHp1iylaBGwQFnkzfe/mmuUdd/dOBSOQVAK46d3B6stPjOHGpcrIezLmVVeUKOo9pR8FQ6jwio41ORBpwOdNlv+Pd2/USotMFfyK47poxlpgKOnR6e5F1Td+t4w35DLkTLLyjWcEDQojVEmh9gEnjhvGYKlLvedQKT5g4ytp3Tutp0IylfqnovDi0AX6VYYE6bwJRJ/DwBh6JKjMxL27nPtHp9tf2OgE23i56TQe3sbFAgzHpB7wtS3XOlWA+SJXou1rypj0/knJfrUlgOsIPk3nZixN9riMHtT6tMcko7kto9GboSAQshiTpBuGlqIUJ9rESjNZyMs9Yw+tYeUZ806PdviJJUgeFxK75xDTaGjds+bRk7F8iWNYWmE/tjFIEYsa+oib3U5Clyw2CrJkaXZhHKqZCUvOmiRPoeG7GMCSfFngLMUBgXokMvo4cRVZgKyOmAsGjnxqbKnCjP/Ga5iXwVUJ1pSLB2FaxgfcNBcVOyY3wAp3gDodr3hpRfw/j+J7Oc08g64mXLle5tLxfeuAc0qzDWO01VxsWvGaY/HqQqwJ0ZTY3rSTQGOyvTznFMgszOKPNLsnQFXbstN5LbJnrsERcS4/VntLaesaWcOXdG3V3JUe8KBQZDDUvwCMfpp5v6hKbSHadQ3gwdLFlEzLVDp5SXvM6AN4DupQeZR8LDmx4qByKN87hFpvl2WD9Y6m9LSNVUpztLruiqya+qc/L3QITMv3naWxNGKPVd5MIpOpbZ7CyPewCbSx6GdIm5gwmouQU0qhuUpT5chg3uCi5Ah8LytLwMjwl3dkKf0or4RvNFoj/RbqdhYs2hVq5ZMCkuQD8SFXddFAsvXUUFFXbcjscWa6lR69aQPXVN+z8wDB64/dJV+IqZARxsk4emRYenvWygl+7Azij40tdwQsu7MVNSlIPNcs/5hbCSEeA2H34S7mVM5EQQE5pgfKaJFGVsv1AdpGSy99/b9pLtDnLUIRq1dee5DjsiGpr0m2i6C5YIcXMrWLTAknFt02xRw+QsIN768YUaOnYE9J0cXKjayErFMjI9xbhjmUEHECM9TtgCf8Rn69MAetqSTSp98vCOoPEsDKE4wh8vEPp6wOFtN2eu5adnqVnk5Va0ph30x5TXmDg6RxnwnILYUDFgtPEwrKipunhaLXYoAsrM1SrBAKly0RD3WEs1b/hpgMYe4ZSatB6oQKOc8g07kna/cddFcfxWYI9YGJ+4S7xlcjM+871Au0OrucClI8u16L/QnhF6frw3tc+PoAAMEEQGy9YWc0hqkaoQEWzSMGJZfeWNieDMPa6nsovxC9hx/8gXw/JTkC0p4scTo/9VHLiKCEc77G6s8O8QBuycFsW78IGU1J8Qal90c6JT7rfQQSDy6TNAaqiXQ27x03FQT9UXZTJtPdt3uqy6WBRJZnBz58LbWB0nZmhxopQDNsVuK2zjM4mA3pi3RPcL+/r35uR3Nxfy8ex+y4SCUnlpjRIh0AqL6nCzlO26Vty4nunfkBCNn1DlWb4jam3OUI1MmTNzfpZx4cu/sgMC7A7SglGnIUmldm8cjzMbASKPCk/LQHiBgG+75gDu+mI+UME73ZyOqrcQyCGB1Ay2TZJ4AQcuPIsODdxcoxLfrxYBB+AL/Z5Bs4+HAK88sb+A5YIsfvx1ROBWhKnYkH+ZU6aOCHzfqpL9Qopu3p2ZM13JU9ff40QSvbAXj1ScW7GgOa44Jotp8MR6H6qz+hsNjVMQEJhEdt760dK1nU4NiV9wH9FBQx3y5JhxvVWOqdd4B0VVouain/Td8vgx0S7yYdFJuna1Moo+JcBBMayODA3Y1m1DC1qKF2LAk/zHqwN2ydzf4kesN71UqmNyXyWz7u+3eY/cHYSD8oCDLN17jz2a/Qibmxoi0Qln0XA5mmYehrHcXHVOlJh7G0De/5lmgCJ43F3P6FJlLiZiyq+5fUFVcprXv8ThQRgRRNmvLN0Dhe3xc8wgQblJ964yj74fZymeihZAzSog/S6kPJnTSvCCbSgfUsxNnJAaNnIn/6L2f6DC38Mu1SILY8/dss3BEihTVI5d+BY2RpwK8gzNQHbfyGnmM7Tp8dxPwzbNodyP2WQCCBQfmnAJxVWD1bVJyz0gSANpa/wM8XYkEJbRZPaXRYnA/fM2FvsLcUXg7d3pOdj/BA+hdrIqSLWCFS3QS3pY92Ar1U1OvlzIs410ca2Rk/JQ5Oko0XGTFsrU/uJ3DZ2npUh9PDYfAoVQpaoMdZlkLoR3TTrG6eEXGFAsxiSKa0lbjkJrdjZRXkEVW9XI1rQl8vO6EdCfi4Rp6TAg8qSRbiKLtVQ1YM8TYkXT42UG0YzuEDuhGhPF0N+3WWE4rQoP2SAfyHMWKwjCCAEdz8SKwSHjYzeTdraTFHH3332Y4d5cB1GFEtbAA2+0Fs7GHEKw+lBEraM6Rf90hC1DjCWD8Dby9CWujFbo6k2SxP3Az5THkoXVuIZLbBEhB8vnG8zmnNDx1LybOt92wZCjvPJrCrzyqiUnbIoXD0M7a6yjkPsGsOI6MrHpO9/ncWfg7a5z4euw3FDrLYdP3BEPJzpWB2Onod9peZaUffcBOsaMwNKRxU39UKXNow7T1LbMc1W9Gd601/WOEtr24I/xBXJ2oC5MoASLyh9K6qkEvT5MmzE2BiRKyio0LPcw1FqJ+G4/I9jEClM7QkelWCzzBHRzR4/pzHxkUNig2wxXjcDR1vojW+g2pUKkugY2Xuo/aDXbuLNLa0KlCgp2FpbDbePZ6fDnWP6jhGRRDrfNZ2Ei0DN5/NJ02z8bT+1w4YN3zGN20JNbpnfmz/rQgcFI9Ayqvath+5rsIYPbsWgvpxpsCCiIcReURiySWC+p6Mi2HzwYhRbSEOKYOluXe+qLmATv73wwxH4tUN5SpFboCfXgbAHdK16L033ZNf09MuNIR20aCOcA7SrLeuZmnblNsY6q3EIchIcqroiseQprBQ+umKMyO9wbgmebsFRsb8NMy5gQKxxh6T9E9+jMhrBxZ+48c8McEdxTXmf/a79CufL/uPpr7OZlSgX6Wc3ZYD2UKhJx39YkoS0SQ9QR4B8DkBHTu/MOzJ2zSBNZrdKjWebezX07mJYjt4LH5LhqNie1/vNNdcsqZFYbkqYqfQneqKkwuuKEutpAwwXgTK78cJIBjzKfyAcnfsGFGIe5WZOm+R9zgGkvcoYEqwx1JM2C10EUW5589vstlxeMnHu/p8Z1KzauXSNZBa0pVu7r+p/YTgjXz6RwtAR9trMzcxp7Ke7yr6MZ/tqdKsJa0sM+yO4vidqgSHbISxKlHm+8lXGWXwCt93Xnv1DMOdvqolqgmPwDBWiN6T88cWANM0T+hGZPwZOJ6nOqPFuTMwAoQC4XSNWfJIpfiLBIkPuvIK55LFHXyYlFMEiLIH7XiPcecFblB33QPYHaLUj9bWg3XaixQRC6JZz7sVcU03kbHveySSpNH1jDAf2Rzyw9hop5cObb5paFAIF1kQqSGldIenQeUKP+UWDOSZUQJxZjjqdfVDb4PbFcDA/zXYkP3mFepIXxgf1dRNS+//OCUWoRzRLR7VN/R9B0M+JgVxxw7VdCy0rumCx3/WVosPoeWqgjsNyy8CsPpiuW3eCnQHtxiTSTk3yphFoM7jBtEcZLfZicQKAL5m56VmBToee73ct/osNq1JrbXRW1hZDpL1pkR299R9M7C0YXMq5u8D1mT8eCqSf9lHE5FaX3oNddzfDuv8/A82Rk6VjyBYiQuXn8dIwRuGPVJNJPeGchNv8iT8iXSuV2MmwDTqz8RUGesXzDKAIUUMPtMsq5J4u7bV9B461LBewgCCzXR58vM0cYrL39y/JNwcGNUP0kanDqWFvBzWwZCOity1Ms63DDHp3Y0ghziiJTS4PSwoaMAo3zv2Tx1sYOZXOcNisj0Q0+RIiqM7j7ASOYbw+jTJocQk7LwRYPbE2HGbWfo8RO2OWquh4XbfcDYHpWCYtmcep0T5zoTSxesVJeibSmXL86c/6iLHYZUhJWI0ZAOsF9i140Lcz/B8MqadE/FEfJUQ1zAjVBRbJjNO/UcQDbYUdSzBIN0we/Shr4egaLxXiJqqP+pY7xE+2tO9lRj+Fchca5h8nBkJFNBoZgNOxjwQjbDaQ2rBTKwAK0v65iGCBNn2EF5C746M1eB8fCwzZnpJdn9qJ7TW7Hb4kTsCrhDMK916Krhnw18KDdgszE2vTJpIZbAenMmBvddEvpYKOKJ0o2PtmheDuKD5eB/HJtZKTITJVHfcAa84OmSDoOq1KtZNybAhlqMsn0VB7I9gKMTCSmBJMwBgdAH90aHeOS4eRrseYXKTwMluCSuLAWez4J4+dr02MsXdSJdQo10s7mFh5b25E7av6lteGoF0Xe+uUbpxDLTh9ULPGNThCumzIYVeg83EOPbV3E8kljZIr9/OTZ2UtmDjUjkqwCBu+CmoRFwXhzER4aVx8r5yUEzNpjoJfy7XKlZa0EUA/Nipqj3FAZxMqNz6EqpQl+D/r8wnEfDV6T5eXHWbDPNMjoFyDuQ1C34giQxP921d0csy4q/berqbeXVLf5PeYAOFqZ4SBqu9DCo0+wMyZYkUUHfcaMsM/6P0GMCk5fvh6HObzDOSVUbfGps3d/b1w9NC+2l4A5E+5vzoYH4mPGwXUNLGC9xfZ7BearA66oy5rLPRuUHazuO6eoO/PfO5M2VVwWQZkq+L9RrBgXZ0BYwzkEI8tHRb7k5KXYUr+b1WVnuRZm0zeilPWfcLWTeUZbD4oV6Jyr/6S7CUeSKdcySEG1SXuSL1coE1bsc9+GbHn6S95rmT5TFwyCf89uRZInYHToyRG72hjoANFNUGlfstGo09UsBoGHbBKadCQT2kAWHAeLcErht2Zk9QztS+KTByW59c7mZEwMQNRQ5uswkp5adBqcFFBkm68w2K1cdJMvX6pQZrRhJbxHj8iVxuoSpeRAqV/NhD/otdnMRFkGMqlOxm0ea9PDBojEnWRVR77qbGJgfy4ybKADwuPoIff+zfTZFSs7c6JFE9hvLlLJ+DG3dljZemkI2XEg8P8OmyH4obMM/EYoLa9Slz+eG0lTv6MeLKcgFIbzGXA+ACXKX44RIkhih5hoUUnYH8N7gw5Iwgzkt8A3xCUhXqNVLEaGyVGtO3lAoOlmC1AA0eCqJHf+36HyrkZndvt9p3gSGW7sNePVRTDIQdCTClOLtMzYzqDyWT+8e/aeIkXXCem4qJ/O/PQ3p29qzK1XxxGzzO3pZH/uTfEGl06LpCb+lt/TAIc8Q5Nn1e3pcRwbT77QGw9Dz/pOza8gGzGLMYQ84J7l6HzKm5D/7p9BObyHmPR8lBhoSJlQlzKrJYLRjBRDI04WlE7JmkyrHNFEMJx7ekGhangV2BudFxw2l4FHSZf5q9TQzpaMHiiaTCL3M2pqzFE6wWYOetDlToMNGxIUF1AVK3i/jaANJStcBVu8Uvscz8Kkcl7APwC5cA8OA5qhntUIjxHFhEXJcw3i/Xbg3koErYcsRabSXQG+KLlHxIITwUQo96PNlEJ/3j2D8sqp1s78CE3ZVlJZr0msBsA0a5Hv7gmMD/3SScXx8ZDFZdr66OoVuHndB4aKhLZepvsOcULykvBNBTe8Zgwr5GqYQHB/Gg2HsVYo1nSfps+rUrPldSTVBAYZrnrQTESiSCCNJtN7Dsf2x03VEk9a1gRjLAOBcu0OOdanGA4ZHShYjjyjxuUDUhBQVtudilAFAmFrG3KC36SyfEZrngFtmg+upyX8Mya1FpYK1ruRfGAsjFu6xCQfjOOqkyPiloomMTWdBpxPSI0PwaFXIiMlYaJgp3rEDZGpNMd8J4PYLxY6N8o8cQKEeJkjBlU32QPuf7cPtyDyTSbsQoCk0A0xfvYylPQm4o48CfgH7o7ywFerCsVehCAII6AmgEwL66j1TfJ0GsvULDHzKWHpjvxWUuds/ykdmDyfSoD9mYIPFdJlIYyOJd+REntnkQcsf3Ph/eEXGkAmM/Ag3QiThlNYIz+rXJhQ7iaaFtK1hiQLnKndwU3+J7kaB8z7s2wt2gRNVtAwEi+Xc3kQVHB8ZOP5AlN+xfwYWkNGESH8DuGPpoQxcOS5yEvUVxooBrvj/EGl8MBVryE7Ys2Hoa6MgrADqHLIT8ED1kYbE1JpBCN00p1RoUQJtXNuoXqJZILQGs4CinAzVvo1q8YJE/SbMZvBPAI4mV9c6t0xjWBsJibAYv3FzmmBiTAaMdzpkGBEHo5muP+zcBHqCERY+7t3/O/Mlqb6TC807peAoY28ISRtvlya+PgKYnGS7L6v+yRBsLawsjFeIZ4qw/zDOgSWJYj0SeXVKcS/J9hqO4I8RM0OxWLFpH3Ye233DC+YOtZGVSbx/MtAUadOYF9Y7VI8iMvLZMvv9M+6ehoqyoasPN4Lfc7QsOrjuG2VF6NoNkXApgydjydy7ssFropmYacFznGWlpXS6SaqdXeF3MEgo43wnYWsFlmQkrBMHo33Tgv137Szo0HlSIdRJpuDQl8SYX9XxTKUSEdftoG9UX0TtaEU9AkF+QVC33UL+U3Ci9hFyQqbBArt+TSe+eWfAHHQeCm7w4c2tRlI4a/Fa0s86qCyp5QBR8fYkxZu5F3fhBSDaYIWEoL7qoxodmrKgHmXQO2BC6aofPgj7IntOCZRtk9SXWFEURjNszEZlMl2knJbtS9x1lUuhMkmC1l9ITQ4D5FgwaDZJEUPXrxmRNE3SWyupmac81GnuzA9PMKW4f8i8snU6P7zwBZexIsKvHcVSC2/lWXGscxd8FjG5AkgpgVs6lvD+M5/mmioXxkutM1cemsKa2cvDDIPRjeq1xYq+uRcvcqMf/Hm7UQwfOfxkDd16eyooY0I0S88SOGai14DAl5p6Ln8U66612euzcnl/3Fg1hpO3BLPwYD08WO/H/60KNKBN/leJxHF1i8vXcqlIfwIEqgeIwdNfWW/JvtPlwQ/+j3bZhMmiq4MmhbeDjGcwejVoRWSc7oTTkZXZGHPJzwK+iYh5sJRsK4UDGg6kWq8dtnN8Fb3EuEpxXVjr76JvmQcgAB/b+xKRww8eQnzizSgS+HpF6w86vMiPtuJTdvJPl7mOE0i+apyl2jVy9chJ6PrXysTroEqAxkvVKpYhKaw5UR16E5HhK1wUc7sdKQe8CfPRl7o/teX5AtH8BuxjvazpSWrCmtn2AlsnuKA1qkL7P87w79pbC1RkpfE6G4ka9AIlJ95nLSYluJzJ+G71jQGf00D472UPKxMoygUL6YdlszKIXs1wI8svaccoq94U32Qa4LecsXi7LdEgFeipliT5Ocud2zPlNyGEeLYwa/WT/Gn7RH9PSTkMP2li4xPemQGtbm0BFIXdRUg+1BATiyxPE+Idg9mYRMhkuyr4G02j1vQXJwDmdyVvEGwB9ZCLbeO/3L/tnAOiq1y7A/c9JRMXEqXp11zgWnqbiFQDXYMbiQ9mSvVUIJAX7fBicKrw7e1wa1gtBqfgY1PGZlGAhD++TJG+5C7GAjf2wDoxVFbXsFKod8mhal3y9KyDXvSEjlQLECkb4gwFEG3ToZd60hPzVUgYTFuPGnRKLFNbFJbOITcHeoAopKG2AElnHC1gGmd/Ck/sI7Ea+31OjINY/U7Hzy60l9TAzP4GLwZ0eTTZBl2vX75trkpaXddi8FT004wHjaqT/DRg78+fuTW0s1Mh9icTk7QIHP4B5sTne0y0CU+gkZqOM4oqtmsmOdNp8fyhFzeXG6kfU0ADl1Cuia6H+7j1yzOHnrO0YMPdYvPaT9tCA82RLY8UXGqhHs6L0lki8sTjJsv+fcPEaW+uMwWuNMxZ6jYit77kVyMAIZTqQ5QReC7lpZeuhXOQqq7hgnrP9v8HIqUDSvK4BFVKxaZspLXd62seD1cRkl/wWtJIDX1F9VDY0n49rqR5Y1nVv9Gxhexpyi7XXsmjASX1npyo5kHGMyVfv37BeR/USH+7B6HRehP2tWV0+6ggYhtUecBrHw5IsWS8IdIyYKduJXKnAE1iDfdN7KS2ZYDoTPZlAxB7G+TM4Fy9nFfeMt6ZMVb8fnD3RpdoVS0hPmQPux4RQmwgh9HU4htFqrGzob7NLyuNaPDfxgl68dpEdAqnC66RGF/dQnSYUsijIYdhagWZsy4pBHQyjIx3Oeb5zefh0X3fI9tiC03ttSzTeTU2TsL4cttre0hGszbyRgeQinggIIToDLanHvnJW97G15xqzNiJiF+WGYRqkA8EVptN5tcIFfcoXJwBvIVMUVtTKAICb2AzhtBG4hLgQvwOMit27mkSOwaeSFvHoBiu6A2Cy9KnlZE0w72mbMJpI9WuE8bt4zxG6cRbZ2Hwj0kSbyGIBit0YyaQYUnHNf6fOventipA1PlSArjAhAOx+loB/cxUJ6yDQCmdUaWhKaVI34zq9/ck6pFcYG3tFF/JrXAGB10x0aHt8AZF5hlGFgiISAAb3KCjMAhK1HveHH6RiYSdKpJbgvSlyfiBD0CjElYBvwc+IyOgPRzNyVlMjOGITuSicSnzQOYNKxO1SPB9raPPDQyT/JU/F9UQM21Hr059P8m7rcoctpfQ5rcruCeNV2P7mOhrXNlYasoSfa8KK57cBhlLPuURNLcMvwe+E9l7opfjq+V8N2OUq7r9BZMQdGa59mOFQ6dvNDgLePiNI3xPvnBYQXHYiMKT97kowpjLAXbuxK5y5WS3VS0i7PjJ5/glYydVXJo/muLwnoR0GJi2Cm/8V2hIq3CGoW+65w0Ywukzlz8zN+ku8I2MEFGp7+vCTUxnKvGrs1axEjA5yuE9/zj8j8zbr0PCxMHNme71i+n42Dtkz+p0yvQrCSTifHz0jrA0JHGHlgt/evZveeCXE2NJr4nJZXcNMIAEmEOqO468/XKr3uRvpCg7sjdmh23U6RyAwTPMr7WKJ6AlHgw6pcsWS/U55WE8sXUGFJH503/5vJHI0bWD55YpwRzGKytm7E8Y8d7H0pVQZT0QBxHn4jqxFBBW/slCjVbesMVZVnDxIZdZ+w8+CLxxH2HXopBUeSw1SjGySSmNkseBN2b+PmOFT2kNoTAKwXzIS78f7HvKNnEywmEPbvTfUydxBCUA/OiYhHtBXOAyh8DTmlFqrkGRV2GXGKmodWR7j80wnqcXJqD7gUpJ8xBxrVdOx/YxpMV/SjDah/kuIfGiAnuSV2k2EvyA97f11iBxF/b9Sha4zH0LCl2mAJzzxffkEMtidSfnMIm10am9DSBSFZsZ9ffWlKfpaUqTq7Le13ZsNoaiZOSPBbQfcARgJKTkjlvrV6J21AQtPwtl1o0ZDDb6KZRvv3Sx0Y8Ijja/ZXnFHj9JEzQp7fYxbgc2F2Ab9rSP82ksYJrkLJa0SXTnRkyawGfB6NgY+IETN/QcyoetWEgFkdKwowrQVi5DQAy7TSzQmOdnEP4zbRaZnR5pK0dtArhFn4tt/G/tcmP9/cq2uiZ2UrOpkxdTLPxVUQR8wDaDxpQFuYgwdlpDLVB3ZPCChb0PJI1Ww8H+R0fP9J0ins+pKY71kGKe+iGnLtF+XqMLux7nUxVOXw8ZgN5hh4WAV8SpX7lAbRpkw0nJSokNqZUGgvEO4ck8R+Kq5d6J07vWgG7s8pKuJtmZvMVKINjat3/zel2HAtPTB4acAuw+wV/bticOIoixQ07rHeP79uhCKJAcHhVTmEYTH4ytn/phEccfdgAiFj9lw+QDjd/Qj8KZCvQvMZKcKC4EjKaLv/nItsGIQ+VMerGOsgE5UF0qYJFbIbGPyv4g9hOHeZFRjHIVyMpwJqnVYNDCBNsnv2VsnUIrk8j/rPq3dv6RUNekz25WW0k+dczWYnG9XDv/vQaJIPTDRyyG1Ewv3kqmi1eaKPR8BMCB3OqFfJni4iRlZPs4M72o2qxJVbC/EuuV1qQpcf2hYFcidXONAkqcsu7hZxNzeOcDyZ8FUzULe+N1iYZnsTT3JstD2sagacGmIGMD1FyzmSqiq0o84Ndwht/ro3VJQZCGwhJbgK/9sXvQjgse/uhXQYesaVCmXfMp/OTOf53kffBfQA/l4SavArR7uYK/QlKLgXXLbhXhEjDH1jDfiFeS1M5Vwmp+igcVuRm170N8ZQFRkCdB6d8ZDHEATbrt+4WruJuXc/R4a+gIw12oR1CAPc+SxgBHxXI+83Uiua4zgPHXOOn9urGWGbctWREePsKlGTAeq0gsPnt04RwA57euHgYM1CQcLpnS7k2wtUVAaRZ/wLI0V+/kU0M883SodONPnApAbqxqKr54eB6b4tjvC3xCr1j7CNtulV9LN8Wr9Q352R/QJ2XNERf+P+XfZ37ukLzTRAjgTUT/HWRS2rIm6BqDrrGcoEXiBh4NS1SSqvCANkdhnmbUrpQn2atbkrVjvm1vqNgIu7+aj+Q+lXYBX9wNUhIkYspxic3HZr1DkQ8F0JZ0zwqbNdLQKhOKicgJgtyaKIMdwvQa6ZdOktCUJ5Rp4TtrOXGRSiQhdwYbAAucCM1ESQ+kHsJUGO44rY+rzYCVc065neFZSenaX1D7deOVhSuKnwQ74gV7UiC5bCLE5gUepCJiaVZp50PSXQjf+GwtHQHDEXug7GkEvaRK8ILk3U90eE6zPs6tZMTnU0dVx6mU8Ya+IlaXCY1BFyE73BIJJCUJYnNnl1MqLcFx2GBLYKg55TqxmgxD3FEOK+BVfCKaSuNJx0UWkpCMFsv0GJSAXNWRwOXjULQD2k0hY8wjQ87SITPByXNYHOQ71SpqJGKNW0v/d6IWYYDRX7GCDnNqowHfkwkq1TSON0q0Umi34datQMpG/mdBDfpSumejFi5OXlubW6Papha1+VTJES/nDPoS1pojKmVJwweF96Xzqn7BvAseh/jU2xMaeDcSL3M/cRBuXJ9VU/iGlfuFN71PFgVuVienSGv03Rf2IbnYKbSPhb19pbvoqazuLFZ5roI83BHw9MmuR3RapnfgVZFhzJL07ZEjfkpcMN/+QzS/u41Yf5KJLPvO1HS/tHiOPSYKe+D92OK7ZdL12OUybPo/j8ku62aWTdcDZ0wNBVW9w8tRawtUqYco6+AxoUVhAnivHwFt/Hh1rFhmTyBYJptv0R/FhKbdxejdR6NPnC+RniU/RyfIL2g9CLLccsBImKgb63c5ehYhIoNmQzZ+Vaavxrh5hBL2ciRFBBGHpYjl9KA+glZ/Z8HdSGh5OyzdxlX3p6QKgiyzUINoRwxu1FTyJqmeqe6ah8KEkNerawnmVFZyNeY3cVpw3HOIpUbsTxNeIChrhf5IVAudBSLH74IHH7cG9cUCiDv458ymcTe7UOBLBekgz/nKkPhmMLX9mzqWjhz35FSWp17sDBTybskECpIsb2MbqfccFUjwMk5LBRSH2AzkG1IYRHvQfBoF9H7Gd5b9givEjc+vyPMACSy1NMQD8KqItBhhgkexUAmeQWClp9NiLpEyCIBSJi0y4/7fuPc5vuyxxFWz6nmDFFJIIqzB9uFYtt9fOHYXWv8yk+lACXEU72GRhRDbarpWp0D54zsxSKeqnG3Fv/Yi4AntQ/F/t/a5dBI6EzdpapNA0bdFp9b3wcXmLF9xnhvzEr23C3Td70h1k4uw4MAlKiijWH1bsYcgPIYHsa/m+DunsDtIi7XTbnxbBynFaeUrkf48LFxEmn4no8oeZ5BFO/rBXLVjUF7aEcgznB7A7v4bXbod/DeoB9Un8oUVZh5BDmjQ853cUhu2T7+qF/nyTmutR0+44gHLkechvgctA2giZyA+S7ycyeWkJGAnPjXW0fZQXwIx7W0ZLAZSSjXyhaLw6GehHBix317d1iZC5K7DdqaeFsRK9+ZAOw/tmHVT5yYIH6lGsMEKzU/5CyIdJGYEY1sBK/1YU/+7bgqcO354IRkHaKTKiBQEFm2C2lMW/695pUjvktgDyvkTIimiBewMKmjE2vNMv7U4eOjEpjp9NCFDGWnVzvxFkE+o8VnuTvRj+lypkN/cIlGS/YXj/df0I6W2WuvBRQ6UZdkKeTw7WamMF4tyESC2p91G/S6oqbiSYzvKkUQUg6dqHVveMqsZY/n/Nv+CFf8BpgdF7FjL8XQppzZ9LjjQtcokDD624qRWEO97LfqiNxa6nihC7fr9eKxiLayuZz9rT7O75dzfVLvqiWMlfaajBlStJ8AA1VLOPo1X+TLGsASAkWRc2hf6pRNuUQ4xUN57LSAt9FqI7WUiZL8Vw4agv8YK1SzUtFHKGN5HYkSZ7CvKYbztMeAl9V9s+PrutOXvRRnyBGyqcRNfOJXjFwpSaFvuD0t3uHnN3vySl7MYCSYhLwhvuZ1AG4EB2PeBYp0TbCTyFvySZso/fjYGde8DX8yMqumqYJnXSaapiU0nZWY8vdfRX+0z94aXReAzvDlLRglvpi0EKSwkbn95h5nPS/qwZB5GHWaCV2UyAhgYiZOQDxT2oTmG8HvKAruh+bmk99yDtzXGSoOZA3MalNsx3vUAFKxSDrYmcpNilBHuOV3Cyg60ng9Yzqgup/1Z7Ix6On7z3c877Zb2ZmQFO7uZTxhYC7Bbv5hTshW0eC1vO2qflMlrxqeliKe1cX4Urg8iv+/GZsVQOPRx4sPWt/ZDr9wylqG7atHGjzxUWa0Z0RsBhn2cp7jtNODp21XNxlcGtNTEzemDgcsSaoXlnTl8XAJMThJEC2Y3A89dyeaYM1ralvWwwZvE6l82CbMljVlBcaoKkd6VVN7DG9tkzolozLzXvD8tfBrayr+W3NNyEG5WRLI6Bq9cvqezhQYyS12o7tXWyfueTs2WkS1QfJVQTXv54nq1eHZvBSwvJe9UUnm939QBGmK1C40fw7XZ8JIfaZFyKXYR4FY8a4u7sO7H5QuXm5Zmm/T27YE0LgYJP4veKbIFUE6ADA34mhBWPpkb1uRGfjq+G64huSGJhztIsI/cQVQzZpEBtnQwMMQpp7IQ9KLxlpQBMpF8gwxTxm+BhVHy6r0YoBi2OTnR3riUH3BHEX6yCc45THhATMaVxsjV23RuHwF6P8Onp5iG+ZXiho1AHFUevGcRg20fUzLXm+jBXjhaVo/8JxQJcSF5nFEyifHhBJ+4cK+ZnbqlhnwcM51K+peXGwJ+eIB/x1F5uJR2KJmKPw3u0DCjqpP5NyuL83sfH2BjhIi02tbYyNUEAOij/QLlwMOuhob8xENLpBHmgBM9b3+VGn2u9T1omzJTyw9RcLOyqKOXkrkK84awY0dAFU+ISpVTwIpY3mwgiCwqKe70ReGWmC1XiOAbIOUR6R/SNDYV79Wcm9hBQgO/VA0gEDzqTQDTtSpeLk6yEh92v51M2MZXeny+GGQNFnknTRWJ4bkE/FHVAoNgWP5WbSu74ScWB+MNdMBKNf4CaCkRk6kSVvG58mjm6nIF6qirYAKdluzSuCzeo5MO5c7ejufR9IyxnF5ekmzDP2YNzop+tWd8VrGbMXTWXckg4ENneqRAui/g32KhZvcIzK3pF2Dx1Jq4RNMyn8cRvO+ox57U3SN9cEcssaxQhM2WpRf+Icsbm0tJmw/TgN2jssXPy2+nM5A3WGbFCiUOHbqAPufC0wzwvud1bj+MAfYb7Dnw5uyCLXkl4tccvvRQG0r2AaZHZoD33meR9/vi5VP8Z1zEVOzh7U/q5u4eSQFpf9Kg63Bk3Y2NmsrsKjdi2w+jXUeJwnIYAxzg0Un7zWZ9roDWnMNWfP2stGrjkw8L2XWdfW/pibrqKR3ZWslWgOmk3jIeRSab9DwDqLgpF84NLCR0+tvb39qHOaJAkNIJaDSt7xBjWHj/7vattwyr6v04Z7X2pgq4dbpYoxoThFNZdf6H/dnzuQW+XT5lF6e2X/fhDemnAuJ2T+eAYJvUF/TkGYcB+xwh7j3lbBBWcUQy04FFqQbkjor9dtStGAFiaqvgyf6KSuiBeBDsrvKZC8PogLIK6E9KAudJEJvZ1f7yMGvBCDNCZTXT/PrS2th+Eldrs+TpPYlnYB4MbD6yrYhO9tiAWKEe22alfjorX28bvxY71Z2ivvZE9b2M7NPbqrC2Fs1V9WQR3LqEF9Vu6RZczGXOwSGcEFahcfrFuMoj8obHI7/QPLN5d64tFxDDz0hng99RQL8aPTrak8uAyXRgUqEADY1SExcb3V1/eNOlY0ZH8vR+gLGBz7ab9PmZQvZr7E8H1kGGp++KAsloP/c2MBnofZITepdV7iWmxQOhNOpn7iSLCZ1gMWKauzPuczMrsmSqG+Z3CEqwpv0Kpe0fVckcDGkuDkLXydqbBuTnoD6YXaSYV8+DUfmvqk37W0meC399N404QbmFhI1R0/sRaPtoyWGzTrCudTTfFgRJp/h0oJTu/pRA2wVmXPI/JsOLm3u57dNu8G+yZEd2lMLe1BpBELeit4zKC1G5M8vhNgovwTZ/trRr61Peg2PTQ99NFvZSE+0A3bfUV2JjfohLZ/gq+RaaebsZWzV7xLNoOBa0k5Ll7hQydooCcLzwyiRVuwOX7kZ3ZN8uYpvvFK+ATtmmDtSDtwjVZngKkq+PQ9flIFrUFz1L0tRrotOsITMtnvTNkm/DseNmHEYcfKvSqP5emmgSdIf0kZDMvX+dLVvFRzb7T40C4CDAqyT4nHYhSPuI9jWOtiDtQNiStAGbbY11Z/nv0BLhwjkH2NAQYZO6V12HDyLBTZbCJShdjhawHQY3rbmoEBO15KqYKHAunK4VhGl4e3bhUxFIRarBDShTnn8FVI5tZBdNB1LTdPwPkofZJir7hRZIiZIUsNPJjxT7Gxs1L5Z7/uRZ/YbJPhr7fxv9ZbAhx3SfFZJuvvxWubyvApEfH3oSYtACCDpS53/29iu0yGFstMiXvWfFS7JexmxmciFGtcqQ3giwlZy4gd7z9ZCZTzXIzu0DUSu5CvUOhzuB8/SHqmKBz49yimzdUFd9LP47MKNwxILJpCNiX5rCVpoEaBK4Jjr5s2pJ2j6r1EZBfbIchZZSj4DN8JoD7oLIiqfNuHG7jm07KjYg9gSFKd08xlR6uv+A2WptYGcQl76/Mb8oLj/ONcQELrg2V0Ci6BJdeSFJB8Oz2XtgOeswWYTMh3Ef2W4Z0t+bVSpVqcde8nuYoEX9i7bwRwh2gOgYaxmMwu0l30JUkicCoGK69x1Lgt/xtFbX81ZAWDp1dkqdrDDRHuGd7Vxd/7Lc1cSmWLFFvNkszotBdc+rb8Tq1WWs2nXG2A6+mJKCkPb5ReoI5E2tLLubEpkBFZ+3WHvVSBhVnjL+H5a1ms2p3V231ppi7RdOb/39CSxtpZPqXGaznuAZltw9zPCWuHyS2KsExJz1KNrnpWan7LtppiFZ7kwegKnko5k//fOmofe9GB8bc2LT+ekmorDTbxX/snU+No5C7Dln1IU7BIIYKIPhTD6ecq9NkmMy5jCazvwpN4+CDSLYIgQ9aW37/0MWCXbhmKbu/0BJbYp8PUFtQsGGen70KGKVeeNNSwFwafQf6o8jy3m/SOOYU1ivVEfV//WRl+Sq/XGfVjGvvaCEVFpyLNy6bgP9RoHVcVKNesD7ycp02nS7bzBG1mlHB45/P/eMd8anjAZLDHAgjhVuSCu68LtWMw1dYAaAnhwUKPrU0Za+PaUWzdfIp2LUpFTmSEJGaZ9HkUKfQfWcuHeHbLQAF/5pOLwtgfbTZ0+AEhapKI7iBtvDTd/BrLBpaoFtp+7qKNp1mm8+s+TIWD2Ml9WZhMaSdxyhQkZcPOblHFIW7IIQWRnB5MX25nCxIziM5+MepQJ2y7t6wyyIFTyTm+4kHLZvzDu6OU8hR/pxmat7BZ/+Npkdi7wWy9JCRZgrepXjkej17bYDQ5wGr4kCs4rUWIqwcymexgvcWyVbusGjO7bR7IUKBRQztp/76uOyIjCEwg5h6zoOaRLw3udWSU2cVaLyzNgXpVpaky+zgwmFcoh31mzmAsPNGxpL3Tu6MumHzN3ofCSxcbMm4xxwU6IRBPqYrBLEL7KRNe3p09fYJy5UWNEq0IMHCRnWbnDFjtsq4TTIjs5bDkd6ts6C2pFJ+3AOGOWC4sLnVa40214W7VNY/0eR+mzgejhjGQlSLRBhWUsrbl021bRDhDq3Jot4Q3w3af3J/eso+0XR++a3VPaHpWpEZWkZ0evRr0axJyLj1RT3cq91r+03MKjL176ZmeBfaBf2AxtsbkzkuKfvZNbIPDUsAmQX0CLx7TRLJrSmoHPC3RdbCqzCiQoFAiMfcynPainQXlZKv13mfVyrWsvkev+AA3L9EISux2590PvXOi2Ev4riGPCuqS7avLVDbiClEFySjUNzctiF0bkwZEKoqCSEJxWjXOVPUrbtu7+xMp7r+7sMEtSBg0XdpDLeT+/N6Bs3Qtcik4AN+8b7yMaBvsMBDCuamFVzCmRm0g17wbRKabLldOd4CAg7zx17uZUfmbPHhS6zoBYS8PelzF+zdCaZITG73N15W1uxerrWVg8gabvjoDanSuBlo+3PS2pr67jS7vpE+tXqWXdRU9yxEkZxS/KhNGljPHCo+o0zAAX49eYzz7Lr2KhYNfnYI8ro8Z6X0Z+Slbf4Lh2S3ucDxYFyMOqf64dru4e8dzQoHJa7BmbbR9204gKzFE5J0swG8PLTc2y3boOF1bUpQgwZQt701LjE/Tvz8qRMtqLYsWl5uK/PACdKTLI1AvDtGIW/GeCYWPJU2vJKs8uYGmYlE4+EZBqODuTUJxRB1vRzuxptH4eaz9fMxqNtOrH13Q5OWxcSXmy3ufNrlAgfYzAntCO4Fws+OSF/I2vPO0aX5gZtdf64Yj9UwQYHqIxOe/KeVmjQslUXs78Ppe6i7eE3tDK9Tm60qf3W+2+UV7kf3XmO2oTXaKxkPEXAxoDQ5VSUMLvE5WfgqnnCAe4XOfWgbYdsHoTBUCfPBWlNJE7D36EmS0Ys2JmWb1Ot9J9L4Aiq6Trvm6HA+msOak5iQ1C3YqKpzkqwjM8eZfkpspUBwXmYjHm9AgWSYJ9t1Gr+tPaj3Y9gTSpqMBXTDzQUislPcCIalUYuveOc9okwHld20pDyVg9/aG14ofEIfqjWQxSoPSXhACQ1dxvsx2atGO2iyzcRu8szJCr3WqpqLj6AYXgJNRdXEvIwWu7vhRHzCqIU8V0dZVPq+BhF2iqcdQXqZhXvWKXlbPjrWEXRDOKSl2UUP5T1pu94lr9aGgTKiSeY04NKGtMB/d1Cq849VV0qg5ou9MPHPeYUZu1PYMw4pjEk2CGG1rUU3wNjKrw4pkFcmjtqk9A2UO9thRa5SUc15N+iviNs5YI9/Q+J6O0IMYgLcpnqG1kIjeLAOvb8iRDmvQMDqC56girTiixm+zmi2R1WWiLhTERnAIaH230ng5t2vTenbFwI2UCG6kmRDff8Dbsw3qyb8X1Hl7RhXgIty0EQMNnzF9Sq4VrfNCP/3FHSYslLfoOpYHnNMJ6esyPhLYrC9WVvXZZzsG4KSvHGtfp2Y3MK3eznSFN2S+5phnsGhqO6pqEAT6Lpppvbb4zJBZuJ0/qkGUDAuwkm4GrQDS6YlLR4AUOpr4YV6NVDH70HH++TAQlwdzq0WVwPZ6KhvWaQHeNH80HLIGWhK1ihnHoriQomHEuHeIT96xXmqeBIptUmx3yYgC8Q9ZAp+76/xJEdG/dOeL453RC0uQR7op5YMlniQLNAuEqZ+puZvX8aeCALePwnZBlnx9z6JePdR1iZ9szla2kMQkwrAvw5BoWC/0DbBkGAddxMo/QKjtibq+MgyytLkeuFAqzuzFTt9JCgqXM9fmXqQ24WGuNoypGLhj6KQKmky+5xReUy57jC46q7gaUeDw1ZtEqtjwkQeA1/4Tj4hlJ8xbLrScbEhcsMedkRYRmq4mp5Skg97YvdzCCN0+fQXvHeBHKc4DzpA6VrLrT4IrlMtDRFCDvXSnIVCW8X+guFrozzpL/m7fg3OIjhoVrJ2wjLNDZmoHCCztBVrtPy/NJqJY/p/Z2XltZU7aLNxyKq+QH7O3x1BIcESd3SZH86BCDtxmO0kZPskj5pUeG1SAe7lJur5AE+TCSysk5fDYEuSZFmUGbp23UI6VetQXrHmVQq0dQG28iqvj78yCiSDVDkTJrs+nsA/J3+bKpWjVQQ8ZYIp1hWAX6KyWdkhv7vCXwh0ZCCPFonbRwCTCj41gSZ3hKSJtqs8sMAEDeuI+hJ9yOXSIWD2AlbFR3NcpuoB7vxEblhaDblURiwkwj60MEfVUyx688ugRNGeL42VQuEjyO++zz7XtCh65AWuBMzSLBdX0RouAZszxs7gNQFlCmmmIV0ngO3naRlHb0YBuDT57uuSa+RTSbiJAvz314s3n2WP4p29NdbX0nyNwlvmI355GfEjXU8aKnlNMyC1zFCKBQZvFzRvtbPrUWXftITuxylD4idhiX7n2HXpxz2uuzuZhwSCNhHuonHDcYx4UcJOZwqoU8MECfj3lBD0kwxS2aT9CGuHMTqmxSA3aS42CVfwxDmHp5yUtuQe8Xs12zuQAHMdWfAP4QZv0/vySM/JzI0nlkWAgcxz0Nzd3vpqjzB8EJGyIuJPZfcRdU2y+MWrI/BMd1erXneOOw9gdlvf4YSN4FZO9EYk2uDBggjQR5ZLZy5Wwi/drJBgGS8IquDAs2A0TetS6Qm5tcBQRy+xYosq8UNmBvfGVN8LBqIaLf6fQOz9Z/YewV47WUZvyScbQWdt2357jLymsjMAnUe8OLh50+PERxVTPp+2aSPJ+bTafjv/rOVoE066IzYtfPuTcDTuiuyK2+jEUkeOMQir0VYXb/yv9eIAhM3QcFFhXV26kzZCuoParBxSuVG0MNn1ysR9lko3gK9QaiOLxz7wIZKPF6GybliQAEqUWI1gv+v0a6N//tfKXm3G7xkQ/mnRPAeL7J3UiXc+ou/tyjoYzn5JvWAcZsvTsxtyZCdA/MfD6Tm8imOq0lln6tA7DYIN+6swurgG81JJfT3CypQUAfzHyERCfnixe/w9V7DeKUDx8TBCEQLHLXHad6GRi0qlWBPY2+wN/fKBJ5fcRVJC+zyW27ljcLNNRZHdi87gWI9cEPKao5azCX/UCI9gxSmMXOm8QhlZnvDfsJVUiI/4huetR8hEQ+6GM8sxYbq3h7uy1FPclDfvobcYiQ0r+2KAiyQQLjnA4QaKTB7OvYqw1VZYUXDZMA4nDiYXFSl3SOwx+h6yxYGtBL5pZ6G8bRACi3adDZvxoVD4n8rT2LfMNSKtlbj2MvXKwjIH90acT7gTend9QxR8Ui35bJ3e9EHyuEU7okteVXylvVeGmrqH+Isjm/0FxSl+WF+l6OLlWYEsJd4a64McNp8MXsIU6nt64ziKd93QGqsuhbGmJfMSPEkivBeDoWeCww4lMV9AaSdVmmp2hZrjx7wOVrjXO82Lwg28CEDLLc0FeIh2BfHyqubTFgVJsN3MP98fgDb+fBVWfaTPdQ95beCKWkJQOiEDlMXIF5NZUaLftkjinv/h8MvOwRohlbg+Sw/J+ckpZt+4V6xW4vF5ItzNC122QTnBFqaP6/OC3IM2lvKJngA/uK8/sLYb8BeuDIle9ztEmWGwle+HgLMXKmW4z5bk1Pkimy7rzy7MgWD0ECCQDSUTUsOfUPkEUaKEjtnzJvi+VZcPgz7DTBhnQdj5bVXbxgIDlhQ+iUCnk7+S9PKRR/haBa9mUwF5YrxF8lwrIJFDFcfrJ3+uG1DWPRE/mZwUSaaBQHHDlRWBHpFt7TSi9ta5gU86WONefEhoFdt1wBogUNJDWsALIHT7jGgVIa+GJU/oSzAN2nc8LLPDW42t0T3hMvtOem8guG9kZr+4kavagii4O4gOGLN3icNCrwq6ueYTUZg2ddvAwaj5EaZxtTySiQ/Usm2iFqPNVq0hd3Gxmfh1x9XvmZcBjJFzmtkhfiayZlkh7prie26tNGiY92zEogDPvyrbJl3AUlvfs3gcCwfyTCUB1RANEyFQiciiKAsWkE4WZXrBZu0pCrZYJUZDzHQV7ei14ZuoY0kcxdDIcGDLn0XMX7uUT6iU3lVc+0Xjihl3oomYMlHLstg7BlFwpUQjmgObdZqdNCzYK6GdBBn6cu/CiwCxcCLAOChE9m7uwY5emSgtYFJo9+JcRCER28MQKaUwOVL3Kfu/8mj7LFUJAjPtJilFfPcnqfx5vkWKcADtzfkTAI6BcCVoFX3MbIRL4L7svnqcGsRuwL/CjoO7g13viEOQPUj6ROqTt4XKDE1K0WxYZv1B3WnGilvbXLuQ/d13rS2FxJhcz8+XYNVXum8JjVJ+vhRUmnR6Bzecl/WwdioTS+Dl7W50XttbD8Zk+wS98NtQmj99kllI7+M0UasTzjIDFGOndFW5IYYzoy+9pfGny1idLk43xJmXfF8Gl4gHhR6o50xA2HNbFo5CXQL/nUtv4YZEANN6jy+lXYq2PkgcHD5+jdgCcU2i7/ZtXl6IKnBmTF+318fUb+uLytwpjIf900fbWtiTAS878SF6crMXQVs+7QulrfC9v3UzOo9uTx3/fNqHnkc5uy5I4fozTEnDsZguRVQdI77kfEdVUWO+M9EYFG+8/vz4jS/PY5QPngJrHP1JGaV/t3wrNoMMnMmvM6epNtDnQdDmceM3yAPlbCnye0YbCSn0rjxMBgg6l1WvDYtGgiIRI0NuDpC0usg1kPO2yad7kliWEQPZXo3dUTazqENh/sUnJNEGccR81I04QoIfvcZK7fPAj+c2V3P+ihtbV1qmSNx8+1eBQqATSGRclwiCzWVebCZg+pUJ6qps/7G/2e3hsOthxL+/Bfg1oW2Ki26EjzO88XSfP74InhjytmeKeoXCA96DDp+7+8OsQ+MLz7Xd2TQMK4lDEEOduD0PK8DkqejQy+Ni+t3IqsqtGrTTd4+dNYTFqMFoN82vtdn7gtCRqPItd+63VtoDVm5B6fK5eYRQpENUh5pc3wGsTrfuksnM4lGaxf8TcNbgCIL3jDPqztwTDKVHKmted+yejcKcljMVFS/niMs6jKlRGPB8SWHH2onW+jk2CvWcys1davFMGYOr8S215IoekzmZ4a+ycB/Q9aXTY7gt7jGRlpQZv8OvNzwJTYeKr8rGNEIisKHYuIuoT1of85PgqbG+V081xdOCmUobexEGBLPeupVF0pEe7EapvuVoproeCSU4ySl0wliMDyR3fQoUtr2DdBjEwyGqY2YlX6Ezku+7wIegyVFQhJHfgpv0lAKFhDuMqAFEcuOLGaf2Gm8wBreKbF6NPECwrqF3pvI/hmwyPDsSQ5M29TZF83REnyVWpIybkGTipRWwvfYeLnf0VtqErbshAlv44LISGJBSlkmLdX4f3Ck+zeC3kux1Yjne8n4lgbUADNdm5x63u0InA1Pz5WQYkcJf1BczA/NLMsvyLJ36aqi1V01WPm2H47CKW5rfpj9buUBZtq440+6tWwKTEcH6zEeL5EHJdBtd8HN0cHek3jaMTHnfMbecNjxyHIgXj+zEuzpViOQJYfQX6PHIwgLIuJIZynWaCNXTxVx5r90cJ4uG7fGSgqk0jNbx7gOX/7cHPVVfZT2Nuk2oUkWe4a9PHgXCSQXUI/ZRQQed4sIxSx8QY9a+seFAa/KvttIvvKCMY7nJNg2NVcLtqpu//Ek0gRMWhUb9yQlND8BCzF5X/EWnAAti5YfxFzpliqraoKEqNQGhfjDQttvkzx/sC4kWO21+RYpWeNNbOL0P9Fgz/gXMYUZYDnnwKQORF+AXuejXDoLDqVo+etQFGxpaVqLaNiKdAsOaLx7Z8WG7lmS8WMkgaXGuwrFo1OSL4QmIF4tjJaxctfqZOt1ls24RNEror77q52vN5eomtiAxB5/YW32Z1WI8liSxb9e69YI8u1JpQyBGscgvqOZDbmUNURvEfQfw1Cd7ZwrzHM4FVqLvMoq9Qo4sN8t17sIn/gj0zHu6jOq4ZsxKeA2/X2pnPISSqsV/25z+e3V9xeDGNM+7LVU78lWpmGbPcD7nySfzbm6wAUDkJbyXKf9xPmjiEOgCFCwzSszRvyJyFxhjlURF8ktftKox1X/oU+GerdXkwTu5dStLKHOwoJp8nT3TwFpNsYkdfGy7twW0kJwSnAYtY5mYjqVWPzJoRcUqb3CCN2XXlvVU63FlSymClLWxzDiIGPnCXK8/ndiNYHcuGxkw0rES4HP1EsfBlSLuiD17psrUCVrkptvzV9ub4yZ+eb1kEANQoncQattSwYaLhxR1XZxKFY8+DnnT7dLN3FwdfbGLot1CMHmocJfFgo25h3Wi/WtOS2jvyQ57v5n8kpHoWSBZN9SPdv+U3YRvgYiE1U1mL3qPWtx27Xue5y2z/8IKBOOZQolfqgO43l9O+SzY9Nm9iahlP/kHRbMCWQdYaDYveC+hpEJZG/1o71T87e4oxC/AxIfakffQyx4CgiLMyZD3qiIjbKFhmBXc5Wv87rUfj+SZu181VDcXW5Dzrg2JksaZtySE+fT4Pqtxhyht70Qf8lg9uHVhHAClMeUPrB3t54fEYNzrwjekvUTCwEbbPhvTKHv5VfsfzK4CldmEaOO60SgYm9KmPRjugzmH4uMxQlhJO4s6Gx+VtPUkvvxa/YP/mdqhUk68Kgy6BvMVZTXCOo5jecSFSdByEmVFnpJSUClLS9oVybS9LJGhFOLHTFh35ECedRSzgX/sNkwKFV+2iiPVUEeY8/tnrYpot0o+kU8jqI0NZEEgFgYH6aIt6wus2ad/+teS6CbBON8/2ic7yTJkMyiOyY5omXHcSVCWZ714gEOQAvV0nCLtJuQeA7q67A724IhmLLklMLBEfKrs6MTMf7v2mVvLqq6nn2VryKCzSCHC4h098Vu5evl9J60x4yrjXJ3/Otdc7C05hT+wwFOyKXgVx9TXn0x5YOiX/TAKntw9GXgALSL4K3ErcaSFL9egAPuSb8VfZz16fU9gCuN2VSYVzh/K/uN6QnhgJMW+Eyv5fgSdLKSBUL5QM5/lUzvJpsfnXIS/azjF/eOqfhdsDvs9vBsVCZHyRxfv58O4vl2bc9PC+i+lni+Bg8Vs/PanNNq2vzOE4a4Iip54GjLTD3VlGsJnDK12TG2iW2ltDrYC43ddsQoFTuezTBK62pFieJtzMXYRVbqM9h+7N2GjJvi6RWul1B4W/eBHDf3yjPooxnvgEVDkXYx8+n7AVjWHgZV1wEd1JVJ5P4oJOvp3LmoyiygzG40DPkZQLUCqXgmXbY819m+OyUH8UuNfYgccW+3feCKev4sd3pYjEURKvyZ5JcEt0jXV2hpw6tyBQ2Q2axjUZrYa/iJE8tL77VHt3qw2LIeGGY+EsxmM8DCThk47xP8ENbUW139cplh74W0cdl/iatt/vGb62UgzDAbIHEtmCFuimzDmDEDGPT9pg4u9Zz+0igRj4xoHiNHXwsAm6L4UlqMGyKD2+GVABOenWospGKX5x5RxxVjoZl7TrRWC+l5kmF17qoElXFHIxBF/6QhKWWOFLFQcWg2piQYfju070JrP6YfzqGJs+7zkq+6He6yh0wHTRfWnucx50S2OrMyDDrFq/8fNGs98V5h2mu4Gf6s6feV0NLWV2LsPRk1k15S54FHHpEWSODBojJHuqoYg+hEYdI+/cbzGvO17MCtDJzyPMVq3663e45BbYYEtxVQ29m6zq1R6h4K+kBTJcW5SuBh8VFTQpMQwtLz5fqczUxkpjv4CB6/IPSdhbMzuRa+V9UglVw/j8iyH47XsbIdE2l5z4bws4d0VfrDAPo659onzOMw4ORDjwh/H1D+QO22momgrULyV83lVW2jvQwOH2gT1FCHh5BG3BUOCaYoF7BbQCUu66bv/J/6ih77H4MpkRZbacBrZ6+QVdcCkITIu6AKEN4dMmk1wsQBJYF9jYQ+kDY6AJ243loA5Z/1hlB2AJdlvy9BsaarnWe9n+nKjT8qAB8tzGpAzdJ7Xvj3Qgg0Sd/hv+k9Hy3dXveSbND7LNJVeI7lUgjWTNya4YASGKqMc2jWzkxA9S436Tn0+hsIrenCEQdjlqAb1sses+MPuLNjyAF4YXqa2qutO8s53eRZSr75h9z8tSf3Qup74EJYOczf0WAO0TOfKgqD4VG31R436rwgjQigPGqrZSehZGTYXCezGMx0yew51Bpq1rzJzvF6J8QlY5wYAMGt9y2m8T88L0rXvoM0uhyKLppbloAoL/UasRQCIae3XkzV1V7zNkWnv6qAJqrdU5u8Ma21HvhJdE7gB0fmXCVfRYPmsNCzeIDPIHTPH1rIXLaJD1RFqZn2hw4XGFztWyejEP15G0VP9J7fe6D5GgVTxuljR5IbICTgLC+OTdfTYQSgdYAqBdRMLvN0mTDLRNKQ3Z+Fq8zYTP36PQpv5rvg6RWOv/jblLGWwsrGIYP3PJ8ZoYPjKm6nyShDHweioMhYW/e3fPhpoJEpeOZl4RsUcW4ZoOJzBOkeu4kj4cUV9rNlUcSWQ3WuMHkWMnvawffeitu5Pu2RMEmF/tC57C4+8TWb+YEbr/BHTwYv19Rl7UMEs0iU4mib6ivdyvDUZvfDFX3Q38SEXDF3GTtCJ0f8d0mD6pSjVOEnALeCr5TpA+MPqjnPLi0KeIAANZBU23pQOmyBQIYbmfYnZ376h/dLo5GM8dw0Jnr339kfvchhnpTZbhp3BZ2F/ppmoTc2jCrBXExmTnG4SGbj13pWZs9WbFnML4pyBuZi00IXOzWmpR8dw0ihhU2ohlUGDp/x3tpEL/5t16Npz6+tuRaDFfUi2zjRp3NxSjz5k5dffSPrepU7VYU6hI/NzfDUzJfdeJXtOcUvFuJhdchhuP5NDwHa1aJ4e65y+XcdBAV01f7vQxcHZ0baZzmUZpLiKXt4HDPmlsaw2zVdLBNOEAEhA1496YSJ7wogBTFlhwVf3/lRrrIjL8DDrlOH+AfbrvQZOTd+BASjbePmEPdvWmUUqqTfbGohJLTz3+BRMzttKKr+n+DcD5Jk0igLMgw63SueW4DNzwlX5VVGn0feSRHmDMs/d8TBXjmsXWhVLdIQ/L8Ar0KC9fHR/pbVHLB9pYa9ilgBkl5dy8zVF6n7KXOskEXP7yJFn07ZbqeGgkPbRuSCfG4A1K0lBu0vRL8dGBzaGOi3g5NzxeaS2hRepKHHSFCK4WUA8u/DGFHw1smSyNzZzbGuNppNMPPVhJieYdr1ulbaunGWi/StIFgWyHWUQBSXg3J0BNoQ4FJJt8gGCHOJx2oytO2IjzQuxuiaXZD3QKQJEr+uJGX2gGWbcxBLxyCriTyRo/TwgIZS4/VG0zJgo2cjP2Zh5btK7ZTdF6hPL0yCZDQocRKd6ggENiBG29IqYBGmLGHCAmJjEtWvX2NqGBGWi4md1TiUk486Tj5kapkoFQ2jfS28Yqyd7GzI6PD0shLvJ7UmeCt8cvBVqnl7hVNoZeWcun4scYwKWeCvQvh2RUMmh+X5tWTPmumh63eb/J4pi+xvC2EH3ts4DNG+m45toqrZljsAjHm/xD8+hrnUYH1YHFQKjDO197JeJ9l5gSul6jReYyPAwRo2yLH1It2O8uE8UGzJYiR/rOEcF9nNf0RoKkE+e5Bl4qi2PSbbranyYVEyUUeYqSZqIzqQxhXf7e3elA2BnIAU+5JqIDVbXaiuxdtr3iT9BfzPnKjgDdWWf5/SpnH9Rz3SkdxwmFfeR4+eqXsdnqVibmIbygjdBxeD/iz+eOWGWSDYF4w7/i3rzBAtVhETOIw92CU7Zvb51/eMFH7WRarY6V0Z05Q7XamFzzI3NC7xp2q5N/Zws2Qg0t5Kce4EWjkckxxvP5gqU+8RKA2gYl4wiCj32PDIhetVTsc9lfHbWgLSZXmHiUA3IE4nU2UZPuYUEjCKAB/dNr+PZ4kII34w+d/bV7TJDFX7c8hgOT8E3RprGI86UJopdVEcmYa9e8ExjM+xcGARLhZ5PXWcfZxjIZjCt+8CQ7DbV374aDzaHjVoovqhRpxko6PY/aFULGbTXO4ydbrDZHHZeuO+m8MaulKE+nl47OmLqCiVtiU5dj7thu/06BRjM2wk2N8/lqOHJxuJMfDKLV6QDnZkXca+0iR56nyZKwlcmLvyli8mOI56EnDYjDVq+lDs1jJe0suSbgPGP0h8tSmFSJaJROn8K/WUGDKfwMyR8EAgLDtFkAotpcNFvQFYVygZ7Bg6dlbfHnHWG9t04QL6m94YFoV3M2rocrbyB6bjizNZuJe2OocEqA4XvWAs43UM6kQKgZ098JUfuhgx89qTlmvhekve44fySQabiRb40WUaEgsLpkFhXxtU53SDGiJQk5kVlqXp58bQzdSO6WaDnRtwdNUiyjaX6fe5/YO5iB1CRqobwozk1hM5VkhSDyES3K9XBbSl15w1i8zUuyl8plFsR2u9mkl0U8fKVKXDPmAeZyx374Jl39MEyUZ6R3qR+ABlX+WH8gFl0Z3STQDKNyi61bzmSu8t/QS4bKOKm4ds8CM4omOJp14mHfo+Z4pJz3UidqDUAtb+DWQ3tdCJ/hd/RbEJ8RYDBbatMJv6Hs2wjEFr7jY/mAVQ2c/VoTM3+cpXqD8RNl9OsRcfLYYtTWab6R7nOKlaj/FMd45F/x5roT6CxVb912ZBe5qt4aybTXv7vuu8TLloooHo/VHq0ohGVDtQRW9O72Z3BVtMW9/IikpXXKa7JyTsbwM+PPYBlqAE9nzaobGM+AMYYnJg6A9k/PQ7JfKh+d6nRSE9HwQmG79huOFPfHydz3pWJlC4iIL7ydSDMJzdD2SLZ4i6lu3pGcmMVgnY8J0mMBoBHBaOCIxMZmo7x7C80RMuSx0Tw3m0v5XyKI6JHZ0IrOciGtSIn4N3fnXKiDkE1x4l5FzwTeSeuN0em3YOdqsCxAhdYsHO4mn82AvgziHNw7IAoAjmmckINTX+4NxEoAXJj2l9O3nZrkzkck1rsfnVWfIvKosqvJDB5LQDxQLVkovf4+v3+hEy3r4haf7rCS9cCFuwpo850293Yt4Vog/W3EKuPAaLPidlkjmeuvwG/bTbo902gQlSYEATVEtxAGGobu2qXORnp/g2mwFrUlsT7/iOrgxYms8ZvPrQyeJv4wibGD6ARZpejlKZDIiHPnPjB8r8yQ3C9LvE+Bvq7Oj4vY7QVKI0UwRPrg+ZK6Fg8C45Kfui6fwOcGMQ35XUJAU2+m30tktK/ZS0UxfapMXQTE6Mw82VarxaIA5xrNfxidXUYj1+3+hA+QvA8qW0sCs4osaYakK1El99950UKDGFCPEmr54Ndag5nZyTXdxdoyje7AtsZE2z5J2bI5gRuKh4u4u/PQQu7o5WIRXimPDbOohzJu7qYDSCXW1r7zewEdziOrmjGxudO6BbF8XATY9mHyckMOlKdznj2+3VWJpVh7f6LTURYCmT2H2j/QgOvoYjMTcbVR7kl+Zai4KeZtaALpuidLUcj1ixBcJqsSRzQKsp1cGBbKLdf2pCLs53j/5n8YaMQlY0fTjPRNMwkEs8ZK/38wLHlrMvvfGQmZKjIQ5996I7e0eBjk8xtRVH5XE+H5kDM5Q7ZcR4Bs/rlKNYyLGZYtBj3Zh7XxFuI/OFV+p9Lpj86phna4svEmW0AEVTEXzzUS0TjXHdZbYGluvWMjhzeejr0vm11d2wceH19MnTwHgl1eiFh04UWzCuZG2+ESiI8JSSo+1fx5A3r/RBI0+jPna0CkN8sG3FzAQ0gTEbb09t/w5FuduT/kFI3Z1/rOR7zr1UmIUQNSjobI1GGEQeKfOirtp+edeU71F4h5WXn0pvD6ZwqHzYYnaQuOd2uBW/ipLtGaBPPq+XO2y3DpOdCQoPWHhYHrXX9f/xSfZdVazuj1knhi0cyE6QNzG2+ZfD8WlFZcN3qmgOy6y7/DfBt2XdyzfQB0WlMy+TOdiFbLBfyAH9D/kmwNnlriE8VjAIwISVGUfbrz9pfccx/3e2j+Wy4SGjlpEppqBDWZQV49PHECxY6rzZys86EVFMLg6qcuuoK+ZKef77g/83Fr0v8f5xJ1xnXMoYGIXwFPfE/wmr7LhoVtW/B3jx77CP7YtTtbhlvxVfoaQ4+kWBoQXH26RfguBAGn7B+meUVOwRZ109ifQBvxGRCxsJOkpnD7r5xdBaRPflYkA1fJy1mZCNFW8ubUDrZDTOChDDwnn/ppD7Glkx9o01roFm054YJAa/10p+dQ3P/Qy7hu+Gv/jtbWnJ2tHjQmB3q97CXNlrd71QW0guD56kKzrTTU1+DPsQkn0VpVLJAsZmzRPzndQDlef7jyL7D4w7E4Il1qpLmpkdQj+r04PX6he7FkB9JAARsbtQgr/9M+sORufyZ5Jh1bxl22n0JcuBb1tJwHY7GXF+Mvo8jKsKTQS9cCdVeiFOdUXJCl8m5A9w6hBeqvI+OYZMlGEC0gYeXqY4ZUzaU8KI0tPkOqOCtPQVlDb8NOyBQ3qkHFxEGUBprr4ZEVw/cA5cCqz8gps3NZoeJ5w7T1haJ13NTZS8DtudEahkfXef1aWpvpYd8xcIO347AcrIoI5XoXRdJ/8=")
	//key := []byte(checkFaceKey)
	//arr := tools.AESCBCEncrypt([]byte(str), key, key)
	//if arr == nil {
	//	b.logger.Error("checkFaceRecognition加密图片数据错误")
	//	return nil, errors.New("加密图片数据错误")
	//}

	req := map[string]interface{}{
		"frmsNo":    frmsNo,
		"userId":    b.IdType + b.IdNo,
		"faceImage": str,
		"userType":  "1",
		"bizType":   "2",
	}
	b.addBaseReq(&req)

	res := checkFaceRecognitionRes{}
	if _, err := b.postData(urlCheckFaceRecognition, &req, &res); err != nil {
		b.logger.Errorf("checkFaceRecognition请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) sendSMSCode(frmsNo string) (*sendSMSCodeRes, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
	}
	b.addBaseReq(&req)

	res := sendSMSCodeRes{}
	if _, err := b.postData(urlSendSMSCode, &req, &res); err != nil {
		b.logger.Errorf("sendSMSCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) reBuildNumber(frmsNo string) (*reBuildNumberRes, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
	}

	res := reBuildNumberRes{}
	if _, err := b.postData(urlReBuildNumber, &req, &res); err != nil {
		b.logger.Errorf("reBuildNumberRes请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) verifySMSCode(frmsNo, code string) (*verifySMSCodeRes, error) {
	req := map[string]interface{}{
		"frmsNo":  frmsNo,
		"smsCode": code,
	}
	b.addBaseReq(&req)

	res := verifySMSCodeRes{}
	if _, err := b.postData(urlVerifySMSCode, &req, &res); err != nil {
		b.logger.Errorf("verifySMSCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) verifyNumber(frmsNo, numbers string) (*verifyNumberRes, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
		"number": numbers,
	}
	// b.addBaseReq(&req)

	res := verifyNumberRes{}
	if _, err := b.postData(urlVerifyNumber, &req, &res); err != nil {
		b.logger.Errorf("urlVerifyNumber请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) verifyPwd(frmsNo string) (*verifyPwdRes, error) {
	ba := bytes.NewBuffer([]byte{})
	ba.Write([]byte(fmt.Sprintf("%.2d", len(b.PayPwd()))))
	ba.Write([]byte(b.PayPwd()))

	data := ba.Bytes()
	cnt := 0x40 - len(data)
	for i := 0; i < cnt; i++ {
		data = append(data, byte(tools.RandBetween(1, 255)))
	}

	pwd, err := encSM2(data, b.sm2KeyX, b.sm2KeyY)
	if err != nil {
		b.logger.Errorf("verifyPwd加密支付密码错误: %+v.", err)
		return nil, err
	}

	req := map[string]interface{}{
		"frmsNo": frmsNo,
		"pwd":    pwd,
	}
	b.addBaseReq(&req)

	res := verifyPwdRes{}
	if _, err := b.postData(urlVerifyPwd, &req, &res); err != nil {
		b.logger.Errorf("verifyPwd请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) doTransfer(frmsNo string) (*doTransferRes, string, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
		"refer":  "",
	}
	b.addBaseReq(&req)

	res := doTransferRes{}
	body, err := b.postData(urlDoTransfer, &req, &res)
	if err != nil {
		b.logger.Errorf("doTransfer请求错误: %+v.", err)
		return nil, "", err
	}

	return &res, body, nil
}

func (b *Bank) realtimeTransferResult(accountIndex int, frmsNo string) (*realtimeTransferResultRes, error) {
	req := map[string]interface{}{
		"accountIndex": accountIndex,
		"netTraceNo":   frmsNo,
	}
	//b.addBaseReq(&req)

	res := realtimeTransferResultRes{}
	if _, err := b.postData(urlRealtimeTransferResult, &req, &res); err != nil {
		b.logger.Errorf("realtimeTransferResult请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) getSoftTokenId(frmsNo string) (*getSoftTokenIdRes, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
	}
	b.addBaseReq(&req)

	res := getSoftTokenIdRes{}
	if _, err := b.postData(urlGetSoftTokenID, &req, &res); err != nil {
		b.logger.Errorf("getSoftTokenId请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (b *Bank) verifySoftToken(frmsNo, softTokenId, code string) (*verifySoftTokenRes, error) {
	req := map[string]interface{}{
		"frmsNo":      frmsNo,
		"softTokenId": softTokenId,
		"code":        code,
	}
	//b.addBaseReq(&req)

	res := verifySoftTokenRes{}
	if _, err := b.postData(urlVerifySoftToken, &req, &res); err != nil {
		b.logger.Errorf("verifySoftToken请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}
