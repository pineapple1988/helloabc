package cib

import (
	"crypto/rsa"
	"math/big"
)

const (
	urlGeneratePost           = "https://bd.cib.com.cn:10010/public/generate/post"
	urlDownloadFrms           = "https://bd.cib.com.cn:10010/public/downloads/frms-fingerprint.js?custID=123&serviceUrl=https://bd.cib.com.cn:10010/public/generate/jsonp&channel=IOS&loadSource=script"
	urlGenerateJsonp          = "https://bd.cib.com.cn:10010/public/generate/jsonp"
	urlKeyHandle              = "https://z.cib.com.cn/api/secure/security/key/handle"
	urlKeepAlive              = "https://z.cib.com.cn/api/common/security/index/keepAlive"
	urlQueryPrivacyProtocol   = "https://z.cib.com.cn/api/common/protocol/protocol/queryPrivacyProtocol"
	urlAgreePrivacyProtocol   = "https://z.cib.com.cn/api/common/protocol/protocol/agreePrivacyProtocol"
	urlDeviceInnerCode        = "https://z.cib.com.cn/api/common/device/device/innerCode"
	urlQueryUserByMisty       = "https://z.cib.com.cn/api/crm/login/login/queryUserByMisty"
	urlQueryUserByUniauthID   = "https://z.cib.com.cn/api/crm/login/login/queryUserByUniauthId"
	urlGetEncryptPK           = "https://z.cib.com.cn/api/common/encrypt/encrypt/getEncryptPK"
	urlComitLoginInfo         = "https://z.cib.com.cn/api/crm/login/login/comitLoginInfo"
	urlGetToken               = "https://z.cib.com.cn/api/common/token/token/token"
	urlMobiles                = "https://z.cib.com.cn/api/crm/login/login/mobiles"
	urlCustLogin              = "https://z.cib.com.cn/api/crm/login/login/custLogin"
	urlGetAccountsByURL       = "https://z.cib.com.cn/api/query/account/accountQuery/getAccountsByUrl"
	urlQueryBalance           = "https://z.cib.com.cn/api/query/account/accountQuery/queryBalance"
	urlQueryTransListByPage   = "https://z.cib.com.cn/api/query/account/accountAsset/queryTransListByPage"
	urlScanCodePay            = "https://z.cib.com.cn/api/crm/scanPay/scanPayVerify/scanCodePay"
	urlMobileAccess           = "https://scp.cib.com.cn/scancodepay/scp/mobileAccess.do"
	urlCardInfoVerify         = "https://scp.cib.com.cn/scancodepay/scp/bankCard!cardInfoVerify.do"
	urlGoSetAmount            = "https://scp.cib.com.cn/scancodepay/scp/amountConfirm!execute.do"
	urlEnsureAmount           = "https://scp.cib.com.cn/scancodepay/scp/amountConfirm!ensureAmount.do"
	urlGoBack                 = "https://scp.cib.com.cn/scancodepay/scp/home!goBack.do"
	urlQueryPayerResult       = "https://scp.cib.com.cn/scancodepay/scp/payee!queryPayerResult.do"
	urlCardVerify             = "https://scp.cib.com.cn/scancodepay/scp/tiedCardSecurity!cardVerify.do"
	urlToAgreement            = "https://scp.cib.com.cn/scancodepay/scp/bankCard!toAgreement.do"
	urlTiedCardCheck          = "https://scp.cib.com.cn/scancodepay/scp/tiedCardSecurity!tiedCardCheck.do"
	urlEncrypt                = "https://scp.cib.com.cn/scancodepay/scp/encrypt.do"
	urlCheckPassword          = "https://scp.cib.com.cn/scancodepay/scp/pwdValidate!checkPassword.do"
	urlSendValidateCode       = "https://scp.cib.com.cn/scancodepay/scp/send!sendValidateCode.do"
	urlGetFrmsNo              = "https://z.cib.com.cn/api/common/frms/frms/getFrmsNo"
	urlCardSelection          = "https://z.cib.com.cn/api/payment/common/query/cardSelection"
	urlGetBankByCardNo        = "https://z.cib.com.cn/api/payment/bank/transferBank/getBankByCardNo"
	urlCanSuperTransfer       = "https://z.cib.com.cn/api/payment/bank/transferBank/canSuperTransfer"
	urlCussentAccountQuery    = "https://z.cib.com.cn/api/payment/account/cussentAccount/query"
	urlTransferNextStep       = "https://z.cib.com.cn/api/payment/transfer/transfer/transferNextStep"
	urlQueryAcclmt            = "https://z.cib.com.cn/api/payment/common/query/acclmt"
	urlQueryRemarks           = "https://z.cib.com.cn/api/payment/common/query/remarks"
	urlTodayToTaCount         = "https://z.cib.com.cn/api/payment/common/query/todayToTaCount"
	urlBeforeTransfer         = "https://z.cib.com.cn/api/payment/transfer/transfer/beforeTransfer"
	urlQueryFrmsSign          = "https://z.cib.com.cn/api/common/frms/frms/queryFrmsSign"
	urlConfirmTransfer        = "https://z.cib.com.cn/api/payment/transfer/transfer/confirmTransfer"
	urlCheckFaceRecognition   = "https://z.cib.com.cn/api/common/frms/frms/checkFaceRecognition"
	urlSendSMSCode            = "https://z.cib.com.cn/api/common/frms/frms/sendSmsCode"
	urlReBuildNumber          = "https://z.cib.com.cn/api/common/frms/frms/reBuildNumber"
	urlVerifySMSCode          = "https://z.cib.com.cn/api/common/frms/frms/verifySmsCode"
	urlVerifyPwd              = "https://z.cib.com.cn/api/common/frms/frms/verifyPwd"
	urlVerifyNumber           = "https://z.cib.com.cn/api/common/frms/frms/verifyNumber"
	urlDoTransfer             = "https://z.cib.com.cn/api/payment/transfer/transfer/doTransfer"
	urlRealtimeTransferResult = "https://z.cib.com.cn/api/payment/common/query/realtimeTransferResult"
	urlGetSoftTokenID         = "https://z.cib.com.cn/api/common/frms/frms/getSoftTokenId"
	urlVerifySoftToken        = "https://z.cib.com.cn/api/common/frms/frms/verifySoftToken"
	urlSendOperSmsCode        = "https://z.cib.com.cn/api/common/frms/frms/sendOperSmsCode"
	urlVerifyOperSmsCode      = "https://z.cib.com.cn/api/common/frms/frms/verifyOperSmsCode"
)

const (
	cfBundleShortVersion = "5.0.35"
	appVerCode           = "103"
	sdkVersion           = "4.5.3"
	pkgName              = "com.cib.cibmb"
	checkFaceKey         = "E256744EFC699C84"
)

var rsaKey *rsa.PublicKey

func init() {
	rsaKey = &rsa.PublicKey{
		N: new(big.Int).SetBytes([]byte{
			0xB9, 0xF7, 0x97, 0xBD, 0xD6, 0xAF, 0x8D, 0x26, 0x51, 0x7C, 0x20, 0xD1, 0x0F, 0x0D, 0x1E, 0xFF,
			0xC7, 0x0D, 0xAC, 0xE8, 0x4D, 0x82, 0x53, 0x13, 0x4A, 0xF5, 0xAD, 0x3A, 0x8D, 0xCC, 0xAF, 0x37,
			0x32, 0x3B, 0x90, 0x91, 0x08, 0xC0, 0xBC, 0x26, 0xD9, 0xED, 0x08, 0xAC, 0x6E, 0x02, 0x7A, 0xDE,
			0x1E, 0xF9, 0xCA, 0x73, 0x12, 0x53, 0x24, 0xF8, 0x86, 0x0A, 0x34, 0xC2, 0xE0, 0x44, 0x8C, 0x9D,
			0x8B, 0x8C, 0xCD, 0xB8, 0x52, 0x24, 0x1C, 0x0C, 0xBF, 0x73, 0x68, 0x48, 0x1E, 0x12, 0x2E, 0xE4,
			0xB7, 0x0C, 0x38, 0x02, 0x9C, 0x42, 0x41, 0xBA, 0xE9, 0xBF, 0x5F, 0x78, 0x69, 0xBD, 0xC4, 0x9E,
			0x7B, 0xBF, 0xE7, 0x10, 0x30, 0xBF, 0x02, 0xA9, 0x0F, 0x9C, 0xB5, 0xE6, 0xE4, 0xB7, 0xE9, 0x04,
			0xDE, 0xE3, 0xA6, 0x88, 0xA5, 0x8A, 0x61, 0x93, 0x2A, 0x30, 0x47, 0xFC, 0xDC, 0x5C, 0x52, 0xF7,
		}),
		E: 65537,
	}
}
