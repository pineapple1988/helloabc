package cib

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm2"
	"bytes"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/binary"
	"fmt"
	"image"
	"image/jpeg"
	"math/big"
	"strings"
)

func (b *Bank) getHandleID() string {
	return b.HandleID + b.startTime
}

func getTokenData(softTokenID, activeCode string) string {
	// 拼接字符串 求sha1
	seed := sha1.Sum([]byte(activeCode[6:] + softTokenID + activeCode[:6]))
	//fmt.Println(hex.Dump(seed[:]))

	t := uint64(tools.Timestamp() / 30)
	tBuf := bytes.NewBuffer([]byte{})
	_ = binary.Write(tBuf, binary.BigEndian, t)
	//fmt.Println(hex.Dump(tBuf.Bytes()))

	hmacSha1 := hmac.New(sha1.New, seed[:])
	hmacSha1.Write(tBuf.Bytes())
	v13 := hmacSha1.Sum(nil)
	//fmt.Println(hex.Dump(v13))

	table := []uint32{
		0xA, 0x64, 0x3E8, 0x2710, 0x186A0, 0xF4240, 0x989680, 0x5F5E100, 0x3B9ACA00, 0x3B9ACA00,
	}
	v10 := table[5]
	index := v13[19] & 0xF

	v0 := uint32(v13[index]&0x7F) << 24 & 0x7f000000
	v1 := uint32(v13[index+1]) << 16
	v1 = v1 | v0
	v2 := uint32(v13[index+2]) << 8 & 0x0000ff00
	v2 = v2 | v1
	v3 := uint32(v13[index+3])
	v3 = v3 | v2

	return fmt.Sprintf("%06d", v3-v3/v10*v10)
}

func encAESKey(in []byte) string {
	// rsa no padding
	m := new(big.Int).SetBytes(in)
	c := new(big.Int)
	e := big.NewInt((int64)(rsaKey.E))

	c.Exp(m, e, rsaKey.N)

	return fmt.Sprintf("%x", c.Bytes())
}

func encSM2(data []byte, x, y string) (string, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	data, e := sm2.EncryptFixedK(pub, data, "4C62EEFD6ECFC2B95B92FD6C3D9575148AFA17425546D49018E5388D49DD7B4F")
	if e != nil {
		return "", e
	}

	return fmt.Sprintf("%X", data[1:]), nil
}

func stringMix(s, start, end string) string {
	i := strings.Index(s, start)
	ss := s[i+len(start):]
	//fmt.Println(ss)
	i = strings.Index(ss, end)
	return ss[:i]
}

func compressImageWithMaxLength(data []byte, maxLength int) []byte {
	if len(data) <= maxLength {
		return data
	}


	img, _, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		return data
	}

	imgLength := len(data)
	buf := bytes.Buffer{}
	for quality := 95; imgLength > maxLength; quality -= 5 {
		buf = bytes.Buffer{}
		err = jpeg.Encode(&buf, img, &jpeg.Options{Quality: quality})
		if err != nil {
			return data
		}
		imgLength = buf.Len()
	}

	return buf.Bytes()
}
