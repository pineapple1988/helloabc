package cib

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"bufio"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"os"
	"strconv"
	"strings"

	"github.com/go-http-utils/headers"

	"net/http"
	"net/http/cookiejar"
	"net/url"
	"time"
)

// Bank 兴业银行帐号
type Bank struct {
	Account              string       `json:"account"`
	EnLoginPwd           string       `json:"loginPwd"`
	EnPayPwd             string       `json:"payPwd"`
	SerialNO             string       `json:"serialNo"`
	IDFA                 string       `json:"idfa"`
	IDFV                 string       `json:"idfv"`
	UUID                 string       `json:"uuid"`
	UUID2                string       `json:"uuid2"`
	HandleID             string       `json:"handleId"`
	AppCache             int          `json:"appCache"` // app使用空间
	IdNo                 string       `json:"idNo"`
	IdType               string       `json:"idType"`
	DFP                  string       `json:"dfp"`
	DFPExpire            string       `json:"dfpExp"`
	UniauthID            string       `json:"uniAuthId"`
	ProtocolVersion      string       `json:"protocolVersion"`
	UpdateDate           uint32       `json:"UpdateDate"`
	SystemStartTime      string       `json:"systemStartTime"` // 系统启动时间
	AlgID                string       `json:"algId"`
	HardwareInfo         HardwareInfo `json:"hardwareInfo"`
	client               *http.Client
	jar                  *cookiejar.Jar
	aesKey               string
	salt                 string
	rsaPublicKey         string
	sm2KeyX              string
	sm2KeyY              string
	token                string
	startTime            string
	loginStatus          int32
	loginPadding         int32
	lastPing             int64
	loginFailCount       int
	payPasswordFailCount int
	IsLogin              bool
	BindCardNO           string
	logger               *log2.MyLog
	toNativeBankNo       string
	toNativeBankName     string
	toCityCode           string
	isSmallBank          bool
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // iPhone 7
	OwnerName            string `json:"ownerName"`            // jj 的iPhone
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace int    `json:"availableSystemSpace"` // 可用空间
	Battery              string `json:"battery"`              // 电池
	Brightness           string `json:"brightness"`           // 屏幕亮度
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
	WebkitVersion        string `json:"webkitVersion"`        // webkit版本
	Mobile               string `json:"mobile"`               // 手机识别
	StartupTime          string `json:"startupTime"`          // 开机时间
}

// New 兴业银行创建一个新的账号
func New(account, loginPwd, payPwd, serialNO string) *Bank {
	b := &Bank{
		Account:      account,
		EnLoginPwd:   loginPwd, // 如果要加密需要更改
		EnPayPwd:     payPwd,   // 如果要加密需要更改
		SerialNO:     serialNO, // 兴业特有数字串
		HardwareInfo: HardwareInfo{},
	}
	b.IDFA = tools.NewUUIDUpper()
	b.UUID = tools.NewUUIDUpper()
	b.UUID2 = tools.NewUUIDUpper()
	b.HandleID = tools.NewUUIDUpper()
	b.AppCache = 12169848 + tools.RandIntn(50*1024*1024)
	b.SystemStartTime = fmt.Sprintf("%d", tools.Timestamp()-uint32(tools.RandIntn(864000)))
	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()
	b.HardwareInfo.ScreenSize = tools.ScreenPt(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.CellularIP = tools.NewIPV4()
	b.HardwareInfo.AvailableSystemSpace = 21249343488 + tools.RandBetween(1000000, 9999999)
	b.HardwareInfo.Battery = fmt.Sprintf("[unplugged-%0.2f0000]", 0.5+tools.RandFloat(0.5))
	b.HardwareInfo.Brightness = fmt.Sprintf("%f", 0.3+tools.RandFloat(0.7))
	b.HardwareInfo.TotalMemory = strconv.FormatInt(tools.PhysicalMemory(b.HardwareInfo.Model)-int64(tools.RandBetween(20*1024*1024, 100*1024*1024)), 10)
	b.HardwareInfo.TotalSystemSpace = strconv.FormatInt(tools.NewDiskSpace(b.HardwareInfo.Model)-int64(tools.RandBetween(2*1024*1024*1024, 5*1024*1024*1024)), 10)
	b.HardwareInfo.WebkitVersion = tools.WebKitVersion(b.HardwareInfo.SystemVersion)
	b.HardwareInfo.Mobile = tools.Mobile(b.HardwareInfo.SystemVersion)
	b.Save()
	return b
}

// Save 需要服务端来实现，用来存储账号信息
func (b *Bank) Save() {
	path := "./cib/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (b *Bank) NewHTTPClient() (*http.Client, *cookiejar.Jar) {
	jarN, _ := cookiejar.New(nil)

	u, _ := url.Parse("http://127.0.0.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
		},
		Timeout: time.Second * 10,
		Jar:     jarN,
	}, jarN
}

// LoginPwd 需要服务端来实现，对密码进行解密操作
func (b *Bank) LoginPwd() string {
	return b.EnLoginPwd
}

// PayPwd 需要服务端来实现，对密码进行解密操作
func (b *Bank) PayPwd() string {
	return b.EnPayPwd
}

// Login 登录操作
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.client, b.jar = b.NewHTTPClient()
	// 日志
	b.logger = &log2.MyLog{Prefix: fmt.Sprintf("[CIB][%s]", b.Account)}
	// 设置App启动时间
	b.startTime = tools.TimeFmtEx0()

	if tools.Timestamp()-b.UpdateDate > 86400 {
		r := tools.RandIntn(5 * 1024 * 1024)
		if tools.RandInt()%2 == 0 {
			if b.AppCache < r {
				b.AppCache += r
			} else {
				b.AppCache -= r
			}
		} else {
			b.AppCache += r
		}

		r = tools.RandIntn(500 * 1024 * 1024)
		if tools.RandInt()%2 == 0 {
			if b.HardwareInfo.AvailableSystemSpace < r {
				b.HardwareInfo.AvailableSystemSpace += r
			} else {
				b.HardwareInfo.AvailableSystemSpace -= r
			}
		} else {
			b.HardwareInfo.AvailableSystemSpace += r
		}

		b.HardwareInfo.Battery = fmt.Sprintf("[unplugged-%0.2f0000]", 0.5+tools.RandFloat(0.5))
		b.HardwareInfo.Brightness = fmt.Sprintf("%f", 0.3+tools.RandFloat(0.7))

		if tools.RandInt()%20 == 0 {
			// 更新系统启动时间
			b.SystemStartTime = fmt.Sprintf("%d", tools.Timestamp())
		}

		b.UpdateDate = tools.Timestamp()
	}

	expTime, _ := strconv.ParseInt(b.DFPExpire, 10, 64)
	curTime := tools.TimestampEx()
	b.AlgID = "TEemNRYfiD"
	if expTime <= 0 || expTime <= curTime {
		//jsTxt := b.downloadFrms()
		//ss := strings.Split(jsTxt, "?algID\\x3d")
		//if len(ss) >= 2 {
		//	ss = strings.Split(ss[1], "\"")
		//	if len(ss) >= 2 {
		//		b.AlgID = ss[0]
		//		b.logger.Infof("获取到algID=%s", b.AlgID)
		//	}
		//}
		//
		//if b.AlgID == "" {
		//	b.logger.Error("未获取到algID")
		//	return base.LoginResultFail
		//}
		res := b.generateJsonp(b.AlgID)
		if res.IDFV != "" {
			b.IDFV = res.IDFV
		}
		if res.Dfp != "" {
			b.DFP = res.Dfp
			b.DFPExpire = res.Exp
		}
	}
	b.Save()
	u, _ := url.Parse("https://z.cib.com.cn")
	b.jar.SetCookies(u, []*http.Cookie{
		{
			Name:  "BSFIT_DEVICEID",
			Value: b.DFP,
		},
	})
	b.logger.Info("获取设备指纹信息成功.")
	// 返回的加密key和传上去的一样
	key, err := b.keyHandle()
	if err != nil {
		b.logger.Errorf("交换加密密钥错误: %+v.", err)
		return base.LoginResultFail
	}

	if key.Status != 200 {
		msg := fmt.Sprintf("交换加密密钥失败, %+v", key.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.LoginResultFail
	}

	b.logger.Info("交换加密密钥成功.")

	// 隐私协议相关
	privacy, err := b.queryPrivacyProtocol()
	if err != nil {
		b.logger.Errorf("获取隐私协议错误: %+v.", err)
		return base.LoginResultFail
	}

	if privacy.Status != 200 {
		msg := fmt.Sprintf("获取隐私协议失败, %+v", privacy.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.LoginResultFail
	}

	if privacy.Data.IsShow {
		// 获取device InnerCode
		innerCode, err := b.deviceInnerCode()
		if err != nil {
			b.logger.Errorf("获取设备innerCode错误: %+v.", err)
			return base.LoginResultFail
		}

		if innerCode.Status != 200 {
			msg := fmt.Sprintf("获取设备innerCode失败, %+v", innerCode.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}

		// 同意
		agree, err := b.agreePrivacyProtocol(privacy.Data.ProtocolVersion, innerCode.Data.InnerCode)
		if err != nil {
			b.logger.Errorf("同意隐私协议失败: %+v.", err)
			return base.LoginResultFail
		}

		if agree.Status != 200 {
			msg := fmt.Sprintf("同意隐私协议失败, %+v", agree.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}

		b.ProtocolVersion = privacy.Data.ProtocolVersion
		b.Save()
	}

	// 现在的登陆流程都改为了通过手机获取到证件号，然后在同意登陆的，这里不用改
	if b.UniauthID == "" {
		res, err := b.queryUserByMisty()
		if err != nil {
			b.logger.Errorf("获取用户UniauthId错误: %+v.", err)
			return base.LoginResultFail
		}

		if res.Status != 200 {
			msg := fmt.Sprintf("获取用户UniauthId失败, %+v", res.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}

		b.UniauthID = res.Data.CustList[0].UniauthID
		b.Save()

		b.logger.Infof("获取用户UniauthId成功, UniauthId: %+v.", b.UniauthID)
	} else {
		res, err := b.queryUserByUniauthID()
		if err != nil {
			b.logger.Errorf("查询用户UniauthId错误: %+v.", err)
			return base.LoginResultFail
		}

		if res.Status != 200 {
			msg := fmt.Sprintf("查询用户UniauthId失败, %+v", res.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
	}

	pk, err := b.getEncryptPK()
	if err != nil {
		b.logger.Errorf("获取加密公钥错误: %+v.", err)
		return base.LoginResultFail
	}

	if pk.Status != 200 {
		msg := fmt.Sprintf("获取加密公钥失败, %+v", pk.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.LoginResultFail
	}

	b.rsaPublicKey = pk.Data.RSAPublicKey
	b.sm2KeyX = pk.Data.SM2PublicKeyX
	b.sm2KeyY = pk.Data.SM2PublicKeyY

	b.logger.Info("获取加密公钥成功.")

	comitLogin, err := b.comitLoginInfo()
	if err != nil {
		b.logger.Errorf("提交登录信息错误: %+v.", err)
		return base.LoginResultFail
	}

	if comitLogin.Status != 200 {
		msg := fmt.Sprintf("提交登录信息失败, %+v", comitLogin.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.LoginResultFail
	}

	// 需要绑定设备
	if comitLogin.Data.FrmsCompages != 0 {
		token, err := b.getToken()
		if err != nil {
			b.logger.Errorf("获取token错误: %+v.", err)
			return base.LoginResultFail
		}

		if token.Status != 200 {
			msg := fmt.Sprintf("获取token失败, %+v", token.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
		b.token = token.Data.Token

		// 查询一下这个账号有多少个手机号
		mobile, err := b.mobiles()
		if err != nil {
			b.logger.Errorf("获取手机号错误: %+v.", err)
			return base.LoginResultFail
		}

		if mobile.Status != 200 {
			msg := fmt.Sprintf("获取手机号失败, %+v", token.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
		// 找出手机号index
		index := -1
		for i := range mobile.Data.Mobiles {
			if strings.HasPrefix(mobile.Data.Mobiles[i], b.Account[:3]) &&
				strings.HasSuffix(mobile.Data.Mobiles[i], b.Account[len(b.Account)-4:]) {
				index = i
				break
			}
		}

		b.logger.Infof("手机号index = %d", index)

		sendOperSms, err := b.sendOperSmsCode(index)
		if err != nil {
			b.logger.Errorf("发送绑定码错误: %+v.", err)
			return base.LoginResultFail
		}
		if sendOperSms.Status != 200 {
			msg := fmt.Sprintf("发送绑定码失败, %+v", sendOperSms.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
		if sendOperSms.Data.Result != 1 {
			msg := fmt.Sprintf("发送绑定码失败, 信息: %+v", sendOperSms.Data.ResultDesc)
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}

		b.logger.Info("需要输入绑定码:")
		// 获取短信验证码
		br := bufio.NewReader(os.Stdin)
		smsCode, _, _ := br.ReadLine()
		b.logger.Infof("获取到短信=%s", string(smsCode))
		verifyOperSms, err := b.verifyOperSmsCode(string(smsCode))
		if err != nil {
			b.logger.Errorf("验证绑定码错误: %+v.", err)
			return base.LoginResultFail
		}

		if verifyOperSms.Status != 200 {
			msg := fmt.Sprintf("验证绑定码失败, %+v", verifyOperSms.getErrMsg())
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
		if verifyOperSms.Data.Result != 1 {
			msg := fmt.Sprintf("验证绑定码失败, 信息: %+v", verifyOperSms.Data.ResultDesc)
			b.logger.Errorf("%+v.", msg)
			return base.LoginResultFail
		}
	}

	token, err := b.getToken()
	if err != nil {
		b.logger.Errorf("获取token错误: %+v.", err)
		return base.LoginResultFail
	}

	if token.Status != 200 {
		msg := fmt.Sprintf("获取token失败, %+v", token.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.LoginResultFail
	}

	b.token = token.Data.Token

	custLogin, err := b.custLogin(comitLogin.Data.FrmsCompages != 0)
	if err != nil {
		b.logger.Errorf("用户登录错误: %+v.", err)
		return base.LoginResultFail
	}

	if custLogin.Status != 200 {
		b.logger.Errorf("登录失败, %s.", custLogin.Error.Msg)
		return base.LoginResultFail
	}

	if custLogin.Data.IDNo != "" {
		b.IdNo = custLogin.Data.IDNo
	}
	if custLogin.Data.IDType != "" {
		b.IdType = custLogin.Data.IDType
	}

	if b.IdNo == "" {
		b.logger.Error("登陆完成,为获取到idNo,无法继续")
		return base.LoginResultFail
	}
	b.Save()
	b.logger.Info("登录成功.")
	return base.LoginResultSuccess
}

// CardList 获取银行卡列表
func (b *Bank) CardList() (*getAccountsByURLRes, error) {
	return b.getAccountsByURL()
}

// Balance 查余额，需要指定银行卡index，这个从CardList中返回
func (b *Bank) Balance(index int) (*queryBalanceRes, error) {
	return b.queryBalance(index)
}

// BillList 查帐单
// startDate=20191212 endDate=20191218 page=1 (重1开始)
func (b *Bank) BillList(accountIndex int, startDate, endDate string, page int) *queryTransListByPageRes {
	billList, err := b.queryTransListByPage(accountIndex, startDate, endDate, page)
	if err != nil {
		b.logger.Errorf("查询帐单错误: %+v.", err)
		return nil
	}

	if billList.Status != 200 {
		msg := fmt.Sprintf("查询帐单失败, %+v", billList.getErrMsg())
		b.logger.Errorf("%+v.", msg)

		return nil
	}

	return billList
}

// Transfer 转帐
func (b *Bank) Transfer(cardIndex int, destCardNO, destName, amount, remark string, toNativeBankNo, toNativeBankName, toCityCode string) base.TransferResultCode {
	b.toNativeBankNo = toNativeBankNo
	b.toNativeBankName = toNativeBankName
	b.toCityCode = toCityCode
	b.isSmallBank = false
	if b.toNativeBankNo != "" {
		b.isSmallBank = true
	}

	token, err := b.getToken()
	if err != nil {
		b.logger.Errorf("获取转帐token错误: %+v.", err)
		return base.TransferResultFail
	}

	if token.Status != 200 {
		msg := fmt.Sprintf("获取转帐token失败, %+v", token.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	b.token = token.Data.Token

	frmsNo, err := b.getFrmsNo()
	if err != nil {
		b.logger.Errorf("生成转帐订单号错误: %+v.", err)
		return base.TransferResultFail
	}

	if frmsNo.Status != 200 {
		msg := fmt.Sprintf("生成转帐订单号失败, %+v", frmsNo.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}
	tradeNo := frmsNo.Data.FrmsNo

	selectCard, err := b.cardSelection(cardIndex, tradeNo)
	if err != nil {
		b.logger.Errorf("选择支付卡号错误: %+v.", err)
		return base.TransferResultFail
	}

	if selectCard.Status != 200 {
		msg := fmt.Sprintf("选择支付卡号失败, %+v", selectCard.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	amountNum, _ := strconv.ParseFloat(amount, 64)
	if selectCard.Data.CurAmount < amountNum {
		b.logger.Errorf("转账失败，可用余额不足 balance=%f transferAmount=%f", amountNum, selectCard.Data.CurAmount)
		return base.TransferResultFail
	}

	bankInfo, err := b.getBankByCardNo(destCardNO)
	if err != nil {
		b.logger.Error("查询目标银行信息错误: %+v.")
		return base.TransferResultFail
	}

	if bankInfo.Status != 200 {
		msg := fmt.Sprintf("查询目标银行信息失败, %+v", bankInfo.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	bankCode := bankInfo.Data.BankCode
	bankNo := bankInfo.Data.ToRtBankNo
	bankName := bankInfo.Data.BankName

	if bankCode != "309" && !b.isSmallBank {
		if bankCode == "" || bankNo == "" || bankName == "" {
			b.logger.Errorf("查询到暂不支持的银行, 卡号: %+v, 银行名字: %+v, BankCode: %+v, BankNo: %+v.",
				destCardNO, bankName, bankCode, bankNo)
			return base.TransferResultFail
		}
	}

	superTransfer, err := b.canSuperTransfer(bankCode)
	if err != nil {
		b.logger.Errorf("查询是否支持快速转帐错误: %+v.", err)
		return base.TransferResultFail
	}

	if superTransfer.Status != 200 {
		msg := fmt.Sprintf("查询是否支持快速转帐失败, %+v", superTransfer.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	nextStep, err := b.transferNextStep(
		tradeNo,
		destCardNO,
		destName,
		bankCode,
		bankNo,
		bankName)
	if err != nil {
		b.logger.Errorf("转帐下一步操作错误: %+v.", err)
		return base.TransferResultFail
	}

	if nextStep.Status != 200 {
		msg := fmt.Sprintf("转帐下一步操作失败, %+v", nextStep.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	if nextStep.Data.Result != 1 {
		msg := fmt.Sprintf("转帐一下操作返回异常, 信息: %+v", nextStep.Data.ResultDesc)
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	accLimit, err := b.queryAcclmt(cardIndex)
	if err != nil {
		b.logger.Errorf("查询用户限额信息错误: %+v.", err)
		return base.TransferResultFail
	}

	if accLimit.Status != 200 {
		msg := fmt.Sprintf("查询用户限额信息失败, %+v", accLimit.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	today, err := b.todayToTaCount(cardIndex, destCardNO)
	if err != nil {
		b.logger.Errorf("查询当天转帐信息错误: %+v.", err)
		return base.TransferResultFail
	}

	if today.Status != 200 {
		msg := fmt.Sprintf("查询当天转帐信息失败, %+v", today.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	before, err := b.beforeTransfer(tradeNo, amount, bankNo, bankName, remark)
	if err != nil {
		b.logger.Errorf("提交转帐信息错误: %+v.", err)
		return base.TransferResultFail
	}

	if before.Status != 200 {
		msg := fmt.Sprintf("提交转帐信息失败, %+v", before.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	frmsSign, err := b.queryFrmsSign(cardIndex)
	if err != nil {
		b.logger.Errorf("查询订单签名错误: %+v.", err)
		return base.TransferResultFail
	}

	if frmsSign.Status != 200 {
		msg := fmt.Sprintf("查询订单签名失败， %+v", frmsSign.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	confirm, err := b.confirmTransfer(tradeNo)
	if err != nil {
		b.logger.Errorf("确认转帐信息错误: %+v.", err)
		return base.TransferResultFail
	}

	if confirm.Status != 200 {
		msg := fmt.Sprintf("确认转帐信息失败, %+v", confirm.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	compages := confirm.Data.FrmsCompages

	b.logger.Infof("转账验证组合为: %+v.", compages)

	for i := 0; i < len(compages); i++ {
		switch compages[i] {
		case '1':
			b.logger.Info("动态令牌验证")
			return base.TransferResultFail
		case '2':
			b.logger.Infof("普通短信验证模式.")
			code, err := b.sendSMSCode(tradeNo)
			if err != nil {
				b.logger.Errorf("发送支付验证码错误: %+v.", err)
				return base.TransferResultFail
			}

			if code.Status != 200 {
				msg := fmt.Sprintf("发送支付验证码失败, %+v", code.getErrMsg())
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}

			if code.Data.Result != 1 {
				msg := fmt.Sprintf("发送支付验证码失败, 信息: %+v", code.Data.ResultDesc)
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}
			// 获取短信验证码
			br := bufio.NewReader(os.Stdin)
			smsCode, _, _ := br.ReadLine()
			b.logger.Infof("获取到短信=%s", string(smsCode))

			smsResult, err := b.verifySMSCode(tradeNo, string(smsCode))
			if err != nil {
				b.logger.Errorf("验证支付验证码错误: %+v.", err)
				return base.TransferResultFail
			}

			if smsResult.Status != 200 {
				msg := fmt.Sprintf("验证支付验证码失败, %+v", smsResult.getErrMsg())
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}

			if smsResult.Data.Result != 1 {
				msg := fmt.Sprintf("验证支付验证码失败, 信息: %+v", smsResult.Data.ResultDesc)
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}
		case '5':
			b.logger.Info("软令牌认证")
			getTokenIdRes, err := b.getSoftTokenId(tradeNo)
			if err != nil {
				b.logger.Errorf("软令牌认证getSoftTokenId出错, 错误: %+v.", err)
				return base.TransferResultFail
			}
			if getTokenIdRes.Data.SoftTokenId == "" || getTokenIdRes.Data.ActiveCode == "" {
				b.logger.Errorf("软令牌认证getSoftTokenId出错, 错误: %+v.", getTokenIdRes.getErrMsg())
				return base.TransferResultFail
			}

			b.logger.Infof("获取SoftTokenId=%s, ActiveCode=%s", getTokenIdRes.Data.SoftTokenId, getTokenIdRes.Data.ActiveCode)
			code := getTokenData(getTokenIdRes.Data.SoftTokenId, getTokenIdRes.Data.ActiveCode)
			b.logger.Infof("生成软令牌认证code = %s", code)

			verifyTokenRes, err := b.verifySoftToken(tradeNo, getTokenIdRes.Data.SoftTokenId, code)
			if err != nil {
				b.logger.Errorf("软令牌认证verifySoftToken出错, 错误: %+v.", err)
				return base.TransferResultFail
			}
			if verifyTokenRes.Data.Result != 1 {
				b.logger.Errorf("软令牌认证verifySoftToken出错, 错误: result=%d, resultDesc=%s", verifyTokenRes.Data.Result, verifyTokenRes.Data.ResultDesc)
				return base.TransferResultFail
			}
			b.logger.Info("软令牌认证成功")
		case '6':
			if confirm.Data.NumStart == -1 {
				b.logger.Info("脸部识别")

				faceData, _ := ioutil.ReadFile(fmt.Sprintf("./cib/bin/%s.jpg", b.Account))
				checkFace, cibError := b.checkFaceRecognition(tradeNo, faceData)
				if cibError != nil {
					b.logger.Errorf("刷脸操作错误, 错误: %+v.",
						cibError)
					return base.TransferResultFail
				}

				if checkFace.Status != 200 {
					b.logger.Errorf("刷脸操作返回失败, 代码: %+v.", checkFace.Status)
					return base.TransferResultFail
				}

				if checkFace.Data.Result == 0 {
					b.logger.Errorf("刷脸图片检测失败, 相似度: %+v.", checkFace.Data.Similarity)
					return base.TransferResultFail
				} else if checkFace.Data.Result == 1 {
					b.logger.Infof("刷脸图片检测成功, 相似度: %+v.", checkFace.Data.Similarity)
				} else {
					b.logger.Errorf("刷脸图片检测未知状态, 状态: %+v, 描述: %+v.", checkFace.Data.Result, checkFace.Data.ResultDesc)
					return base.TransferResultFail
				}
			} else {
				// 先发送rebuildNumber
				reNum, err := b.reBuildNumber(tradeNo)
				if err != nil {
					b.logger.Errorf("reBuildNumber操作错误: %+v.", err)
					return base.TransferResultFail
				}

				if reNum.Status != 200 {
					msg := fmt.Sprintf("reBuildNumber失败, %+v", reNum.getErrMsg())
					b.logger.Errorf("%+v.", msg)
					return base.TransferResultFail
				}

				start := reNum.Data.NumStart
				num := b.SerialNO[start : start+4]
				b.logger.Infof("验证数字串 从%d开始，字符串为%s", start, num)
				serial, err := b.verifyNumber(tradeNo, num)
				if err != nil {
					b.logger.Errorf("验证数字串操作错误: %+v.", err)
					return base.TransferResultFail
				}

				if serial.Status != 200 {
					msg := fmt.Sprintf("验证数字串操作失败, %+v", serial.getErrMsg())
					b.logger.Errorf("%+v.", msg)
					return base.TransferResultFail
				}
				if serial.Data.Result != 1 {
					msg := fmt.Sprintf("验证数字串操作失败, 信息:%+v", serial.Data.ResultDesc)
					b.logger.Errorf("%+v.", msg)
					return base.TransferResultFail
				}
			}
		case '9':
			b.logger.Info("取款密码")
			pwd, err := b.verifyPwd(tradeNo)
			if err != nil {
				b.logger.Errorf("验证支付密码操作错误: %+v.", err)
				return base.TransferResultFail
			}

			if pwd.Status != 200 {
				msg := fmt.Sprintf("验证支付密码失败, %+v", pwd.getErrMsg())
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}

			if pwd.Data.Result != 1 {
				msg := fmt.Sprintf("验证支付密码失败, 信息: %+v", pwd.Data.ResultDesc)
				b.logger.Errorf("%+v.", msg)
				return base.TransferResultFail
			}
		default:
			b.logger.Errorf("出现未知的安全工具验证方式: %+v.", compages)
			return base.TransferResultFail
		}
	}

	newToken, err := b.getToken()
	if err != nil {
		b.logger.Errorf("获取转帐确认token错误: %+v.", err)
		return base.TransferResultFail
	}

	if newToken.Status != 200 {
		msg := fmt.Sprintf("获取转帐确认token失败, %+v", newToken.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	b.token = newToken.Data.Token

	transfer, _, err := b.doTransfer(tradeNo)
	if err != nil {
		b.logger.Errorf("转帐确认错误: %+v.", err)
		return base.TransferResultFail
	}

	if transfer.Status != 200 {
		msg := fmt.Sprintf("转帐确认失败, %+v", transfer.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return base.TransferResultFail
	}

	transferNo := transfer.Data.TransferNo

	if transfer.Data.ToBankName == "兴业银行" {
		b.logger.Infof("查询转帐状态成功, 流水号: %+v.", transferNo)
		return base.TransferResultSuccess
	} else if b.isSmallBank {
		// 小银行转账完成了，后续由于没有状态跟踪，所以无法确定对方已收到钱
		b.logger.Infof("小银行转帐完成, 流水号: %+v.", transferNo)
		return base.TransferResultSuccess
	} else {
		for i := 0; i < 5; i++ {
			time.Sleep(time.Second * 2)
			result, err := b.realtimeTransferResult(cardIndex, transferNo)
			if err != nil {
				continue
			}

			if result.Status != 200 {
				b.logger.Errorf("查询转帐状态失败, 流水号: %+v, %+v.", transferNo, result.getErrMsg())
				continue
			}

			// 未确定的
			if result.Data.DealStatus == "1" {
				b.logger.Infof("查询转帐状态尚未确定, 流水号: %+v.", transferNo)
				continue
			}

			// 确定成功
			if result.Data.DealStatus == "Y" {
				b.logger.Infof("查询转帐状态成功, 流水号: %+v.", transferNo)
				return base.TransferResultSuccess
			}

			// 确定失败
			if result.Data.DealStatus == "F" {
				b.logger.Infof("查询转帐状态失败, 流水号: %+v, 信息: %+v.", transferNo, result.Data.RejectInfo)
				return base.TransferResultFail
			}

			// 未知状态
			b.logger.Infof("未知的转帐状态, 流水号: %+v, 状态: %+v.", transferNo, result.Data.DealStatus)
		}
	}

	return base.TransferResultUnknown
}

// CreateQrCode 生成二维码,返回的直接是一个网页上的图片base64编码 'data:image/png;base64,..."
// 不需要设置金额 amount设置为""
func (b *Bank) CreateQrCode(amount, remark string) string {
	scanPayRes, err := b.scanCodePay()
	if err != nil {
		b.logger.Errorf("生成二维码第一步出现错误: %+v.", err)
		return ""
	}
	if scanPayRes.Status != 200 || scanPayRes.Data.CertNo == "" {
		msg := fmt.Sprintf("生成二维码第一步出现错误, %+v", scanPayRes.getErrMsg())
		b.logger.Errorf("%+v.", msg)
		return ""
	}

	qrcodeHmtl, err := b.mobileAccess(scanPayRes.Data.CardNo, scanPayRes.Data.CertNo)
	if err != nil {
		b.logger.Errorf("生成二维码出现错误: %+v.", err)
		return ""
	}

	if strings.Contains(qrcodeHmtl, "开通扫码付") {
		b.logger.Error("生成二维码出现错误: 未开通扫码付")
		return ""
	}

	// 银行卡同人检验
	verify, err := b.cardInfoVerify()
	if err != nil {
		b.logger.Errorf("生成二维码银行卡同人检验出现错误: %+v.", err)
		return ""
	}
	if verify.Error {
		b.logger.Errorf("生成二维码银行卡同人检验出现错误: code=%+s msg=%s", verify.ErrCode, verify.Msg)
		return ""
	}

	// 生成成功了
	if amount != "" {
		// 点击设置金额
		qrcodeHmtl, err = b.setAmount(amount, remark)
		if err != nil {
			b.logger.Errorf("生成二维码设置金额出错: %+v.", err)
			return ""
		}
	}
	// 检查生成无金额二维码是否成功，测试可以直接把qrcodeHmtl保存起来，网页打开就明白怎么回事了
	qrNoReslutStr := stringMix(qrcodeHmtl, "name=\"qrNoReslut\" value=\"", "\"")

	b.logger.Info("qrNoReslut " + qrNoReslutStr)

	qrNoReslut, _ := strconv.ParseBool(qrNoReslutStr)
	if !qrNoReslut {
		b.logger.Errorf("返回网页中没有找到二维码图片")
		return ""
	}
	qrcode := stringMix(qrcodeHmtl, "data:image/png;base64,", ">")
	return qrcode[:len(qrcode)-1]
}

// QueryPayerResult 查询扫码结果
func (b *Bank) QueryPayerResult() string {
	// post 设置金额
	r, err := http.NewRequest("POST", urlQueryPayerResult, nil)
	if err != nil {
		b.logger.Errorf("QueryPayerResult 创建http请求错误: %+v.", err)
		return ""
	}
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	// header
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	r.Header.Add(headers.UserAgent, fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/%s (KHTML, like Gecko) Mobile/%s cib-ebank/newland/%s/%d/t-d",
		sysVer, b.HardwareInfo.WebkitVersion, b.HardwareInfo.Mobile, cfBundleShortVersion, apptag))
	r.Header.Add(headers.Accept, "application/json")
	r.Header.Add(headers.XRequestedWith, "XMLHttpRequest")
	r.Header.Add(headers.AcceptLanguage, "zh-cn")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")

	body, err := tools.DoHTTPReq(b.client, r)
	if err != nil {
		b.logger.Errorf("QueryPayerResult http操作错误: %+v.", err)
		return ""
	}
	b.logger.Infof("QueryPayerResult, url: %s, res body: %s.", urlEnsureAmount, body)
	return body
}
