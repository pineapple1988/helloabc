package icbc

import "encoding/xml"

type getSwitchFlagRes struct {
	Opdata struct {
		FirstLoginFlag        string `json:"firstLoginFlag"`
		ResetPWDFlag          string `json:"resetPWD_flag"`
		TranErrorCode         string `json:"TranErrorCode"`
		TranErrorDisplayMsg   string `json:"TranErrorDisplayMsg"`
		WX                    string `json:"WX"`
		OAUTH                 string `json:"OAUTH"`
		ZW                    string `json:"ZW"`
		SS                    string `json:"SS"`
		WM                    string `json:"WM"`
		ZC                    string `json:"ZC"`
		DX                    string `json:"DX"`
		ZSYM                  string `json:"ZSYM"`
		OauthGate             string `json:"OauthGate"`
		HDNS                  string `json:"HDNS"`
		FaceWM                string `json:"FaceWM"`
		WXF                   string `json:"WXF"`
		HD                    string `json:"HD"`
		WXL                   string `json:"WXL"`
		ZX                    string `json:"ZX"`
		ZXIN                  string `json:"ZXIN"`
		ZFB                   string `json:"ZFB"`
		OKHTTP                string `json:"OKHTTP"`
		WKWeb                 string `json:"WKWeb"`
		AppleID               string `json:"AppleID"`
		NEWBIND               string `json:"NEWBIND"`
		ZFBN                  string `json:"ZFBN"`
		NOPERCEPTION          string `json:"NOPERCEPTION"`
		APPLEN                string `json:"APPLEN"`
		SW                    string `json:"SW"`
		FOVALG                string `json:"FOVALG"`
		WXN                   string `json:"WXN"`
		NEWUI                 string `json:"NEWUI"`
		AgreementNAME         string `json:"AgreementNAME"`
		FaceRate              string `json:"FaceRate"`
		DeviceProtectOpenFlag string `json:"DeviceProtectOpenFlag"`
		PassUnionWapFlag      string `json:"PassUnionWapFlag"`
		IsEncrypt             string `json:"isEncrypt"`
		AddLoginContextFlag   string `json:"AddLoginContextFlag"`
		NewRandomFlag         string `json:"NewRandomFlag"`
		HSNewFlag             string `json:"HSNewFlag"`
		QuickLoginFlag        string `json:"QuickLoginFlag"`
		OutCountList          string `json:"OutCountList"`
		WKMAreaName           string `json:"WKM_AreaName"`
		NEWBINDFLAG           string `json:"NEWBINDFLAG"`
		MENUID                string `json:"MENUID"`
		SupportVersion        string `json:"supportVersion"`
		NewFaceFlag           string `json:"NewFaceFlag"`
		JGAreaName            string `json:"JG_AreaName"`
		ResetCardPSWTime      string `json:"ResetCardPSWTime"`
		HappyEyeballsFlag     string `json:"HappyEyeballsFlag"`
		BttParamFlag          string `json:"BttParamFlag"`
		DelayTime             string `json:"delayTime"`
	} `json:"opdata"`
}

type sendSmsCodeRes struct {
	SendMessageNo                string `json:"SendMessageNo"`
	PhotoTimeStamp               string `json:"PhotoTimeStamp"`
	DEVICEPWDFLAG                string `json:"DEVICEPWDFLAG"`
	MobileRegisted               string `json:"mobileRegisted"`
	Mobile                       string `json:"mobile"`
	FirstLoginEncryptedDataToApp string `json:"firstLoginEncryptedDataToApp"`
	MobileNumWhiteFlag           string `json:"MobileNumWhiteFlag"`
	TranErrorDisplayMsg          string `json:"TranErrorDisplayMsg"`
	FirstLoginsignDataToApp      string `json:"firstLoginsignDataToApp"`
	RegisterTime                 string `json:"register_time"`
	TranErrorDisplayMsgEN        string `json:"TranErrorDisplayMsgEN"`
	InterposeFlagC               string `json:"interposeFlagC"`
	PhotoPath                    string `json:"PhotoPath"`
	TranErrorCode                string `json:"TranErrorCode"`
	DeviceInWhiteList            string `json:"deviceInWhiteList"`
	ChannelIdentifier            string `json:"channelIdentifier"`
	AgreementName                string `json:"agreementName"`
	ChannelName                  string `json:"channelName"`
	ISREALNAME                   string `json:"ISREALNAME"`
}

type randomNumRes struct {
	TranErrorCode         string `json:"TranErrorCode"`
	TranErrorDisplayMsg   string `json:"TranErrorDisplayMsg"`
	Randomnum1            string `json:"randomnum1"`
	TranErrorDisplayMsgEN string `json:"TranErrorDisplayMsgEN"`
	Randomnum             string `json:"randomnum"`
}

type loginRes struct {
	IsEpassOpen           string `json:"isEpassOpen"`
	LoginRiskControlType  string `json:"loginRiskControlType"`
	PhotoTimeStamp        string `json:"PhotoTimeStamp"`
	ICBCEmpFlag           string `json:"ICBCEmpFlag"`
	SignDataToApp         string `json:"signDataToApp"`
	TranErrorDisplayMsg   string `json:"TranErrorDisplayMsg"`
	IsEpassRelatedWeChat  string `json:"isEpassRelatedWeChat"`
	CustName              string `json:"custName"`
	DLCode                string `json:"DLCode"`
	TranErrorDisplayMsgEN string `json:"TranErrorDisplayMsgEN"`
	FaceRecognitionFlag   string `json:"FaceRecognitionFlag"`
	ProtectZoneFlag4C     string `json:"ProtectZoneFlag4C"`
	IsEpassRelatedAlipay  string `json:"isEpassRelatedAlipay"`
	IsEpassRelatedAppleID string `json:"isEpassRelatedAppleId"`
	RandomID              string `json:"randomId"`
	PhotoPath             string `json:"PhotoPath"`
	TranErrorCode         string `json:"TranErrorCode"`
	LoginPermission       string `json:"loginPermission"`
	UserID                string `json:"UserId"`
	DLMSG                 string `json:"DLMSG"`
	IsBand                string `json:"IsBand"`
	EncryptedDataToApp    string `json:"encryptedDataToApp"`
	WapMobileNo           string `json:"wapMobileNo"`
}

type sendSmsRes struct {
	ModifyPasswordBindFlag string `json:"modifyPasswordBindFlag"`
	SendMsgErr             string `json:"SendMsgErr"`
	RetFlagCS              string `json:"retFlagCS"`
	FailCheckLimit         string `json:"failCheckLimit"`
	SignDataToApp          string `json:"signDataToApp"`
	TranErrorDisplayMsg    string `json:"TranErrorDisplayMsg"`
	SendMsgTraceNum        string `json:"SendMsgTraceNum"`
	SerialNoCheckResult    string `json:"SerialNoCheckResult"`
	TranErrorDisplayMsgEN  string `json:"TranErrorDisplayMsgEN"`
	TranErrorCode          string `json:"TranErrorCode"`
	SimplePasswordFlag     string `json:"simplePasswordFlag"`
	SessionID              string `json:"SessionId"`
	EncryptedDataToApp     string `json:"encryptedDataToApp"`
}

type bandRes struct {
	ModifyPasswordBindFlag string `json:"modifyPasswordBindFlag"`
	DEVICEPWDFLAG          string `json:"DEVICEPWDFLAG"`
	AlertFlag              string `json:"alertFlag"`
	DEVICEPWDSTAT          string `json:"DEVICEPWDSTAT"`
	TranErrorDisplayMsg    string `json:"TranErrorDisplayMsg"`
	TipMsg                 string `json:"tipMsg"`
	SendMsgTraceNum        string `json:"SendMsgTraceNum"`
	TranErrorDisplayMsgEN  string `json:"TranErrorDisplayMsgEN"`
	WarnFlag               string `json:"warnFlag"`
	FaceVerifyFlag         string `json:"FaceVerifyFlag"`
	TranErrorCode          string `json:"TranErrorCode"`
	DEVICEPWDSUCC          string `json:"DEVICEPWDSUCC"`
	DEVICEPROTECTSTAT      string `json:"DEVICEPROTECTSTAT"`
	VerifyCardNoIndex      string `json:"verify_card_no_index"`
	DEVICEPROSUCC          string `json:"DEVICEPROSUCC"`
}

type checkFaceInfoNewRes struct {
	TranErrorCode         string `json:"TranErrorCode"`
	RetFlagCS             string `json:"retFlagCS"`
	TranErrorDisplayMsg   string `json:"TranErrorDisplayMsg"`
	TranErrorDisplayMsgEN string `json:"TranErrorDisplayMsgEN"`
}

type signoffRes struct {
	TranErrorDisplayMsg   string `json:"TranErrorDisplayMsg"`
	TranErrorDisplayMsgEN string `json:"TranErrorDisplayMsgEN"`
	TranErrorCode         string `json:"TranErrorCode"`
}

type XMLBODY struct {
	XMLName xml.Name `xml:"XMLBODY"`
	Text    string   `xml:",chardata"`
	Map     []struct {
		Text  string `xml:",chardata"`
		ID    string `xml:"id,attr"`
		Field []struct {
			Text string `xml:",chardata"`
			ID   string `xml:"id,attr"`
		} `xml:"Field"`
		List []struct {
			Text string `xml:",chardata"`
			ID   string `xml:"id,attr"`
		} `xml:"List"`
	} `xml:"Map"`
}

type cardListRes struct {
	NavigationBar struct {
		RightBtn struct {
			BtnAction struct {
				TargetMenuID   string `json:"targetMenuID"`
				ForceLoginFlag string `json:"forceLoginFlag"`
			} `json:"btnAction"`
			BtnActionType string `json:"btnActionType"`
			BtnID         string `json:"btnId"`
			BtnImg        string `json:"btnImg"`
			BtnName       string `json:"btnName"`
		} `json:"rightBtn"`
		Title string `json:"title"`
	} `json:"navigationBar"`
	Table struct {
		IsTokenLogin      string `json:"isTokenLogin"`
		OtherBankCustFlag string `json:"otherBankCustFlag"`
		SwitchToBPageBtn  struct {
			BtnAction struct {
				TargetMenuID string `json:"targetMenuID"`
			} `json:"btnAction"`
			BtnActionType string `json:"btnActionType"`
			BtnName       string `json:"btnName"`
		} `json:"switchToBPageBtn"`
		Section []struct {
			CellType     string `json:"cellType"`
			CellLeftImg  string `json:"cellLeftImg"`
			CellRightImg string `json:"cellRightImg"`
			SectionTitle string `json:"sectionTitle"`
			SectionType  string `json:"sectionType"`
			CardList     []struct {
				MyAccountOrderCardListQueryFlag string `json:"MyAccountOrderCardListQueryFlag"`
				CardNum                         string `json:"cardNum"`
				CardType                        string `json:"cardType"`
				Classification                  string `json:"classification"`
				ActionTypeClick                 string `json:"actionType_click"`
				ActionFunClick                  string `json:"actionFun_click"`
				DefaultCardImg                  string `json:"defaultCardImg"`
				NonDefaultCardImg               string `json:"nonDefaultCardImg"`
				CloseItemImg                    string `json:"closeItemImg"`
				SetDefaultCardRequest           string `json:"setDefaultCard_request"`
				BasicCardInfo                   struct {
					HiddenCard           string `json:"hiddenCard"`
					SplitCard            string `json:"splitCard"`
					AreaName             string `json:"areaName"`
					CardTypeDesc         string `json:"cardTypeDesc"`
					BalanceTitle         string `json:"balanceTitle"`
					Alias                string `json:"alias"`
					RegType              string `json:"regType"`
					NotAllowSetDefault   string `json:"notAllowSetDefault"`
					BankIoc              string `json:"bankIoc"`
					BankBgIoc            string `json:"bankBgIoc"`
					ShowCardNumText      string `json:"showCardNumText"`
					ShowCardNumTextColor string `json:"showCardNumTextColor"`
					HideCardNumText      string `json:"hideCardNumText"`
					ShowCardNumBgImg     string `json:"showCardNumBgImg"`
					StarImg              string `json:"starImg"`
					StarBgImg            string `json:"starBgImg"`
					DefaultCardText      string `json:"defaultCardText"`
					DefaultCardTextColor string `json:"defaultCardTextColor"`
					ArrowImg             string `json:"arrowImg"`
					CardStateImg         string `json:"cardStateImg"`
					CardStateFlag        string `json:"cardStateFlag"`
					IsDefault            string `json:"isDefault"`
					IImgBtn              struct {
						BtnAction struct {
							PageType    string `json:"pageType"`
							PageNo      string `json:"PageNo"`
							TriggerDate string `json:"TriggerDate"`
						} `json:"btnAction"`
						BtnActionType string `json:"btnActionType"`
						BtnID         string `json:"btnId"`
						BtnImg        string `json:"btnImg"`
					} `json:"iImgBtn,omitempty"`
				} `json:"basicCardInfo"`
				CardAccountInfo struct {
					MoneyBalance string `json:"moneyBalance"`
					BalanceTitle string `json:"balanceTitle"`
				} `json:"cardAccountInfo"`
			} `json:"cardList"`
		} `json:"section"`
	} `json:"table"`
}

type billListRes struct {
	NavigationBar struct {
		RightBtn struct {
			BtnAction struct {
				TargetMenuID   string `json:"targetMenuID"`
				ForceLoginFlag string `json:"forceLoginFlag"`
				TargetParams   string `json:"targetParams"`
			} `json:"btnAction"`
			BtnActionType string `json:"btnActionType"`
			BtnID         string `json:"btnId"`
			BtnImg        string `json:"btnImg"`
			BtnName       string `json:"btnName"`
		} `json:"rightBtn"`
		Title string `json:"title"`
	} `json:"navigationBar"`
	Table struct {
		HasMore string `json:"hasMore"`
		Header  struct {
			ImgPath      string `json:"imgPath"`
			RightImgPath string `json:"rightImgPath"`
			Income       string `json:"income"`
			Outcome      string `json:"outcome"`
			Subtitle     string `json:"subtitle"`
			Title        string `json:"title"`
			TotalTitle   string `json:"totalTitle"`
			CardType     string `json:"cardType"`
			Balance      string `json:"balance"`
			AvailBalance string `json:"availBalance"`
		} `json:"header"`
		Message        string `json:"message"`
		RefreshMoreURL string `json:"refreshMoreUrl"`
		Section        []struct {
			CellType     string `json:"cellType"`
			SectionTitle string `json:"sectionTitle"`
			SectionType  string `json:"sectionType"`
			CellList     []struct {
				DetailTime string `json:"detailTime"`
				DetailWeek string `json:"detailWeek"`
				DetailList []struct {
					ActionFunClick  string `json:"actionFun_click"`
					ActionTypeClick string `json:"actionType_click"`
					DetailInfoList  []struct {
						TitleLabel string `json:"titleLabel"`
						TitleValue string `json:"titleValue"`
					} `json:"detailInfoList"`
					SubtitleLabel      string `json:"subtitleLabel"`
					SubtitleLabelColor string `json:"subtitleLabelColor"`
					TitleLabel         string `json:"titleLabel"`
					TitleLabelColor    string `json:"titleLabelColor"`
					TitleLabel2        string `json:"titleLabel2"`
					TitleLabel2Color   string `json:"titleLabel2Color"`
					TitleValue         string `json:"titleValue"`
					TitleValueColor    string `json:"titleValueColor"`
					SubtitleValue      string `json:"subtitleValue"`
					SubtitleValueColor string `json:"subtitleValueColor"`
					Balance            string `json:"balance"`
					BalanceColor       string `json:"balanceColor"`
				} `json:"detailList"`
			} `json:"cellList"`
		} `json:"section"`
	} `json:"table"`
}

type balanceRes struct {
	Parameter struct {
		DseApplicationID string `json:"dse_applicationId"`
		DseSessionID     string `json:"dse_sessionId"`
		BalancingParam   string `json:"balancingParam"`
		DsePageID        string `json:"dse_pageId"`
		WapVersion       string `json:"wapVersion"`
	} `json:"parameter"`
	Opdata struct {
		BalanceDisplay string `json:"balanceDisplay"`
		Balance        string `json:"balance"`
	} `json:"opdata"`
}

type searchBankRes struct {
	Parameter struct {
		DseApplicationID string `json:"dse_applicationId"`
		DseSessionID     string `json:"dse_sessionId"`
		BalancingParam   string `json:"balancingParam"`
		DsePageID        string `json:"dse_pageId"`
		WapVersion       string `json:"wapVersion"`
	} `json:"parameter"`
	Opdata struct {
		TranErrCodeForJSON    string `json:"tranErrCodeForJson"`
		TranErrDispMsgForJSON string `json:"tranErrDispMsgForJson"`
		StockAccountFlag      string `json:"stockAccountFlag"`
		PayeeBranchName       string `json:"payeeBranchName"`
		RecTypeBranchNo       string `json:"Rec_Type_branchNo"`
		Blvcode               string `json:"blvcode"`
		IcbcCardType          string `json:"icbcCardType"`
		CardListJSONDataQ     string `json:"cardListJsonDataQ"`
		PayCardNumtmp         string `json:"payCardNumtmp"`
		Sign                  string `json:"sign"`
		BankType              string `json:"bankType"`
		BlvNameTmp            string `json:"blvNameTmp"`
		RecCardSecondBindFlag string `json:"RecCardSecondBindFlag"`
		SecondCardDayQuota    string `json:"secondCardDayQuota"`
		SecondCardYearQuota   string `json:"secondCardYearQuota"`
		SecondCardDayLimit    string `json:"secondCardDayLimit"`
		BindProtocolType      string `json:"bind_protocol_type"`
		QryPbankFlag          string `json:"qry_pbank_flag"`
		EventSerialNo4Bind    string `json:"eventSerialNo4bind"`
		BindFlag              string `json:"bindFlag"`
		RegCardFlag           string `json:"regCardFlag"`
		InAcctType4Hide       string `json:"inAcctType4hide"`
		OutAcctType4Hide      string `json:"outAcctType4hide"`
		OutIsRemitNotice      string `json:"out_isRemitNotice"`
		BindMediumID          string `json:"bind_medium_id"`
		OutFTType             string `json:"outFTType"`
		InFTType              string `json:"inFTType"`
	} `json:"opdata"`
}

type remitRes struct {
	Parameter struct {
		DseApplicationID string `json:"dse_applicationId"`
		DseSessionID     string `json:"dse_sessionId"`
		BalancingParam   string `json:"balancingParam"`
		DsePageID        string `json:"dse_pageId"`
		WapVersion       string `json:"wapVersion"`
	} `json:"parameter"`
	Opdata struct {
		TranErrCodeForJSON         string `json:"tranErrCodeForJson"`
		TranErrDispMsgForJSON      string `json:"tranErrDispMsgForJson"`
		MediumTypeEventObjList     string `json:"mediumTypeEventObjList"`
		PayCardNum                 string `json:"payCardNum"`
		EpayAgreementTitle         string `json:"epayAgreementTitle"`
		EpayContractData           string `json:"epayContractData"`
		CheckFacePictureResultFlag string `json:"checkFacePictureResultFlag"`
		EPaySingleQuotaLarge       string `json:"ePaySingleQuota_large"`
		EPayDayQuotaLarge          string `json:"ePayDayQuota_large"`
		BAmountDaySumLimitSys      string `json:"bAmountDaySumLimit_sys"`
		BtDaySumLimitFlag          string `json:"btDaySumLimitFlag"`
		NewTranAuthenFlag          string `json:"newTranAuthenFlag"`
		MediumTypeList             string `json:"mediumTypeList"`
		DefaultAuthenTypeNAD       string `json:"defaultAuthenTypeNAD"`
		MinorAgeFaceFlag           string `json:"minorAgeFaceFlag"`
		MinorAgeAdultList          string `json:"minorAgeAdultList"`
		MinorAgeRelName            string `json:"minorAgeRelName"`
		RegType                    string `json:"regType"`
		OutRegMode                 string `json:"outRegMode"`
		AlternateAuthenTypeNAD     string `json:"alternateAuthenTypeNAD"`
		RemitTypeFlag              string `json:"remitTypeFlag"`
		FaceServiceOpenFlag        string `json:"faceServiceOpenFlag"`
		TranData                   string `json:"tranData"`
		URL                        string `json:"url"`
		TipsArrayHtm               string `json:"tipsArrayHtm"`
		TranAuthenInfoData         struct {
			ChooseUshield              string `json:"chooseUshield"`
			XFaceFlag                  string `json:"xFaceFlag"`
			Adduviflag                 string `json:"adduviflag"`
			OpenComplexCallBack        string `json:"openComplexCallBack"`
			IsGuideOpenComplex         string `json:"isGuideOpenComplex"`
			MultiWebView               string `json:"multiWebView"`
			SupportMediumFlagNAD       string `json:"supportMediumFlagNAD"`
			LanguageTag                string `json:"languageTag"`
			FingerErrorNAD             string `json:"fingerErrorNAD"`
			TipMsg                     string `json:"tipMsg"`
			ChooseEpay                 string `json:"chooseEpay"`
			WapbLoginFlag              string `json:"wapbLoginFlag"`
			ComplexAuthenNAD           string `json:"complexAuthenNAD"`
			DisplayDyna                string `json:"displayDyna"`
			NewAuthenTemplateOpenFlag  string `json:"newAuthenTemplateOpenFlag"`
			DisplayUshield             string `json:"displayUshield"`
			DefaultAuthenType          string `json:"defaultAuthenType"`
			ChooseInnerUkey            string `json:"chooseInnerUkey"`
			Additionuvi                string `json:"additionuvi"`
			BdFlag                     string `json:"bdFlag"`
			ChooseMediumCallBack       string `json:"chooseMediumCallBack"`
			ModalTitle                 string `json:"modalTitle"`
			RightUpLink                string `json:"rightUpLink"`
			FormName                   string `json:"formName"`
			EPayHTTPURL                string `json:"ePayHttpUrl"`
			CISNum                     string `json:"CISNum"`
			FormNameStep1              string `json:"formNameStep1"`
			Displaytoken               string `json:"displaytoken"`
			Curpageno                  string `json:"curpageno"`
			NoConfirmButton            string `json:"noConfirmButton"`
			DisplayInnerUkey           string `json:"displayInnerUkey"`
			ChooseDyna                 string `json:"chooseDyna"`
			AuthenFlag                 string `json:"authenFlag"`
			ChooseFinger               string `json:"chooseFinger"`
			ShowDialogFlagFinger       string `json:"showDialogFlagFinger"`
			EPayMobile                 string `json:"ePayMobile"`
			SpecialMediumCallBack      string `json:"specialMediumCallBack"`
			Choosetoken                string `json:"choosetoken"`
			ComplexAuthenStep1CallBack string `json:"complexAuthenStep1CallBack"`
			ChooseEpayReg              string `json:"chooseEpayReg"`
			ChooseUms                  string `json:"chooseUms"`
			CPLC                       string `json:"CPLC"`
			IsGuideOpenEpay            string `json:"isGuideOpenEpay"`
			ChooseOne                  string `json:"chooseOne"`
			CustAuthenType             string `json:"custAuthenType"`
			DigitalCertData            struct {
				DcVerifyFlag string `json:"dcVerifyFlag"`
			} `json:"digitalCertData"`
			Tslt struct {
				Next              string `json:"next"`
				ChooseCardPass    string `json:"choose_card_pass"`
				LanguageTag       string `json:"languageTag"`
				PayOrFaceAuth     string `json:"pay_or_face_auth"`
				SignfreeAuth      string `json:"signfree_auth"`
				ChooseSms         string `json:"choose_sms"`
				UkeyAudioAuth     string `json:"ukey_audio_auth"`
				ChooseAuth        string `json:"choose_auth"`
				SmsAuth           string `json:"sms_auth"`
				ChooseToken       string `json:"choose_token"`
				ChooseInnerukey   string `json:"choose_innerukey"`
				TokenAuth         string `json:"token_auth"`
				Confirmation      string `json:"confirmation"`
				CardAuth          string `json:"card_auth"`
				ChooseFaceFinger  string `json:"choose_face_finger"`
				InputSmsCode      string `json:"input_sms_code"`
				PayPassAuth       string `json:"pay_pass_auth"`
				Confirm           string `json:"confirm"`
				ClickToOpen       string `json:"click_to_open"`
				UkeyBluetoothAuth string `json:"ukey_bluetooth_auth"`
				ChooseDyna        string `json:"choose_dyna"`
				Resend            string `json:"resend"`
				FaceFingerAuth    string `json:"face_finger_auth"`
				DynaAuth          string `json:"dyna_auth"`
				ChooseEpayPass    string `json:"choose_epay_pass"`
				ChooseUkey        string `json:"choose_ukey"`
			} `json:"tslt"`
			MediumTypeJSONData struct {
			} `json:"mediumTypeJsonData"`
		} `json:"tranAuthenInfoData"`
	} `json:"opdata"`
}

type verifyEpayPasswordRes struct {
	Opdata struct {
		TranErrCodeForJSON    string `json:"tranErrCodeForJson"`
		TranErrDispMsgForJSON string `json:"tranErrDispMsgForJson"`
		CleanEpayBindInfoFlag string `json:"cleanEpayBindInfoFlag"`
		MainCIS               string `json:"mainCIS"`
		EpayMobile            string `json:"epayMobile"`
	} `json:"opdata"`
}
