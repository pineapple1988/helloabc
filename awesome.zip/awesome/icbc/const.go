package icbc

const (
	urlGetSwitchFlag                   = "https://epass.icbc.com.cn/epasslogin/main/client_getSwitchFlag.jsp"
	urlEpassloginAsynGetDataServlet    = "https://epass.icbc.com.cn/servlet/epasslogin/AsynGetDataServlet"
	urlAsynGetDataServlet              = "https://epass.icbc.com.cn/servlet/AsynGetDataServlet"
	urlICBCINBSEstablishSessionServlet = "https://epass.icbc.com.cn/servlet/ICBCINBSEstablishSessionServlet"
	urlICBCINBSReqServlet              = "https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"
	urlWAPEstablishSessionServlet      = "https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPEstablishSessionServlet"
	urlWAPReqServlet                   = "https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"
	urlEBDPWAPReqServlet               = "https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/EBDPWAPReqServlet?"
	urlWAPGetServerParamServlet        = "https://mywap2.icbc.com.cn/ICBCWAPBank/WAPGetServerParamServlet"
)

const (
	cfBundleVersion = "1.6.33"
	authenVersion   = "21.06"
	wapVersion      = "3.0.1.3"
	newVersion      = "6.1.0.6.1"
	inUDID          = "4A3934D5CD7F5"
	wap3desKey      = "e*ui(3pr:di~u&3.4@Vf-Ue#"
	aesKey          = "6a8w0c91kc7"                      // 6a8w0c91kc7
	clientSecret    = "dGpDMys3cEd4QkQ0c1d5L0c3eGVnOGJq" // appInfo1.ini
)
