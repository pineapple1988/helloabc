package icbc

import (
	"awesome/tools"
	"crypto/rsa"
	"fmt"
	"math/big"
	"strconv"
)

type rule struct {
	iPos      int
	iRuleCode int
	iParam    int
}

type safeInput struct {
	m_oaSource      []string
	m_oaKey         []string
	m_sModuls       []byte
	m_sm2PublicKeyX string
	m_sm2PublicKeyY string
	m_oaSaveRules   []rule
	m_sRule         string
	m_sChangeRule   string
}

type randomValue struct {
	m_osValues []int
}

func initValues(values []int) *randomValue {
	return &randomValue{
		m_osValues: values,
	}
}

func (r *randomValue) getRandomValue() int {
	if len(r.m_osValues) > 0 {
		index := tools.RandIntn(len(r.m_osValues))
		value := r.m_osValues[index]
		r.m_osValues = append(r.m_osValues[:index], r.m_osValues[index+1:]...)
		return value
	}

	return 0
}

func newSafeInput() *safeInput {
	s := &safeInput{}
	// initSource
	s.m_oaSource = []string{
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
		"n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
		"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "~", "`", "!", "@", "#", "$",
		"%", "^", "&", "*", "(", ")", "-", "_", "=", "+", "[", "{", "]", "}", "\\", "|", ";", ":", "'", "\"", ",", "<",
		".", ">", "/", "?", "€", "£", "¥",
	}

	// data1.ini
	// loadInit
	s.m_oaKey = []string{
		"hi/", "o[m", "1lp", "n8,", "Q5R", "{*L", ">IW", "OQ\\", "iLV", "/<u", "~)e", "6Ak", "QLc", "yrN", "uDC", "Cxq",
		"TY5", "Z$`", "hju", "Y9o", "Nsr", "z7~", "O9+", "s~Y", "Wun", "/tA", "aCe", "Nv]", "s7p", "qHB", "@WN", "sGE",
		"x~B", "?5_", "-,T", "!?J", "(;>", "|8]", "=;F", "sSu", "C}3", "tG*", "fP4", "Xg8", "RLj", "Xzh", "NwJ", "Dm`",
		"'yh", "P8&", "6m0", "arZ", "Ogo", "r#N", "+j~", "+ri", "<w_", "-+c", "Pex", "kHA", "jZH", "Vmz", "-Dt", "TIi",
		"KS@", "*?z", "8:>", "Qt)", "IOu", "9P!", "X]&", "S.\\", "&,6", "4b-", "^yX", "'?v", "lbs", "WiE", "@^C", "R4*",
		"A-p", "=}<", "%S.", ">B9", "ELi", "T~R", "+o%", "P\\~", "X&w", "]#2", "W#a", "cd4", "L]V", "eoT", "J=O", "g2V",
		"(>=", "k*X",
	}
	s.m_sModuls = []byte{
		0xE6, 0x7B, 0x03, 0x35, 0xA2, 0x93, 0xC0, 0x6B, 0x59, 0xE2, 0x2F, 0x51, 0x11, 0xB4, 0x57, 0x21,
		0x76, 0x2F, 0x86, 0x89, 0x33, 0x5C, 0x9E, 0x36, 0xC8, 0x40, 0x5A, 0xDB, 0xAE, 0x88, 0xAE, 0x6D,
		0x73, 0x72, 0x3B, 0xA5, 0xC8, 0x51, 0x50, 0x81, 0xA5, 0xD6, 0xC8, 0xB3, 0x21, 0xBB, 0x01, 0x19,
		0xB1, 0xC9, 0xB1, 0x45, 0xA8, 0xA3, 0x46, 0xE7, 0x92, 0x75, 0x0C, 0x08, 0x31, 0xFF, 0x97, 0xBC,
		0x9D, 0xA9, 0xEB, 0xC5, 0x0F, 0xEB, 0x25, 0x1F, 0xC2, 0xAD, 0x86, 0x52, 0x4F, 0x3D, 0x5B, 0x07,
		0xE1, 0x1A, 0x45, 0x1D, 0x21, 0x33, 0x69, 0x79, 0xF9, 0x93, 0xCB, 0x7A, 0x77, 0x5B, 0xF8, 0x6E,
		0xA3, 0x9B, 0x94, 0xCD, 0x13, 0x82, 0x8A, 0x20, 0xF4, 0xD6, 0x63, 0x71, 0xDC, 0xDA, 0x04, 0x79,
		0x4A, 0x17, 0x41, 0x1A, 0x74, 0xE2, 0x37, 0x25, 0x81, 0x4E, 0x55, 0x28, 0xC3, 0xB0, 0xBE, 0x7D,
	}
	// loadInitXY
	s.m_sm2PublicKeyX = "BEF9D48E4C351FAD3276FB6169885BB47742D6F1D8CDB9FD967B4CBAD16E5247"
	s.m_sm2PublicKeyY = "B3A09DD43A1DF376E3A2BBF85F5A576CD4B761F24CD2F64DC1E05F23DF0139DD"
	return s
}

func (s *safeInput) getARule() (iRuleCode, iParam int) {
	iRuleCode = tools.RandIntn(5) + 1
	switch iRuleCode {
	case 1:
		iParam = 0
	case 2, 3:
		for {
			iParam = tools.RandIntn(99) + 1
			if iParam%len(s.m_oaKey) != 0 {
				break
			}
		}
	case 4, 5:
		for {
			iParam = tools.RandIntn(99) + 1
			if iParam%len(s.m_oaKey[0]) != 0 {
				break
			}
		}
	}

	return iRuleCode, iParam
}

func (s *safeInput) parseRules(sRule string) {
	s.m_sRule = sRule
	s.m_oaSaveRules = []rule{}
	for len(sRule) > 0 {
		posLen, _ := strconv.ParseInt(sRule[:1], 10, 32)
		sRule = sRule[1:]
		iPos, _ := strconv.ParseInt(sRule[:posLen], 10, 32)
		sRule = sRule[posLen:]
		iRuleCode, _ := strconv.ParseInt(sRule[:1], 10, 32)
		sRule = sRule[1:]
		iParam := int64(0)
		if iRuleCode != 1 {
			paramLen, _ := strconv.ParseInt(sRule[:1], 10, 32)
			sRule = sRule[1:]
			iParam, _ = strconv.ParseInt(sRule[:paramLen], 10, 32)
			sRule = sRule[paramLen:]
		}
		s.m_oaSaveRules = append(s.m_oaSaveRules, rule{
			iPos:      int(iPos),
			iRuleCode: int(iRuleCode),
			iParam:    int(iParam),
		})
	}
}

func (s *safeInput) initRules() string {
	s.m_sRule = ""
	s.m_oaSaveRules = []rule{}

	random := initValues([]int{
		7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
		26, 27, 28, 29, 30,
	})

	count := tools.RandIntn(6) + 10
	pos := []int{1, 2, 3, 4, 5, 6}
	for i := 6; i < count; i++ {
		pos = append(pos, random.getRandomValue())
	}

	for i := 0; i < count; i++ {
		iRuleCode, iParam := s.getARule()
		s.m_oaSaveRules = append(s.m_oaSaveRules, rule{
			iPos:      pos[i],
			iRuleCode: iRuleCode,
			iParam:    iParam,
		})

		posLen := 0
		if pos[i] < 10 {
			posLen = 1
		} else {
			posLen = 2
		}
		s.m_sRule = s.m_sRule + fmt.Sprintf("%d%d%d", posLen, pos[i], iRuleCode)

		if iParam != 0 {
			iParamLen := 0
			if iParam < 10 {
				iParamLen = 1
			} else {
				iParamLen = 2
			}
			s.m_sRule = s.m_sRule + fmt.Sprintf("%d%d", iParamLen, iParam)
		}
	}

	return s.m_sRule
}

func (s *safeInput) parseChangeRules(changeRule string) {
	s.m_sChangeRule = changeRule
	changeWho, _ := strconv.ParseInt(changeRule[:1], 10, 32)
	changeIndexLen, _ := strconv.ParseInt(changeRule[1:2], 10, 32)
	changeIndex, _ := strconv.ParseInt(changeRule[2:2+changeIndexLen], 10, 32)

	// 开始变换m_oaSource 或者 m_oaKey
	if changeWho == 1 {
		change := len(s.m_oaSource) - int(changeIndex)%len(s.m_oaSource)
		s.m_oaSource = append(s.m_oaSource[change:], s.m_oaSource[:change]...)
	} else {
		change := len(s.m_oaKey) - int(changeIndex)%len(s.m_oaKey)
		s.m_oaKey = append(s.m_oaKey[change:], s.m_oaKey[:change]...)
	}
}

func (s *safeInput) initChangeRules() string {
	if len(s.m_oaSource) == 0 || len(s.m_oaKey) == 0 || len(s.m_oaSource) != len(s.m_oaKey) {
		return ""
	}

	s.m_sChangeRule = ""

	changeWho := tools.RandIntn(1) + 1
	changeIndex := tools.RandIntn(100)
	changeIndexLen := 0
	if changeIndex < 10 {
		changeIndexLen = 1
	} else {
		changeIndexLen = 2
	}
	s.m_sChangeRule = fmt.Sprintf("%d%d%d", changeWho, changeIndexLen, changeIndex)

	// 开始变换m_oaSource 或者 m_oaKey
	if changeWho == 1 {
		change := len(s.m_oaSource) - changeIndex%len(s.m_oaSource)
		s.m_oaSource = append(s.m_oaSource[change:], s.m_oaSource[:change]...)
	} else {
		change := len(s.m_oaKey) - changeIndex%len(s.m_oaKey)
		s.m_oaKey = append(s.m_oaKey[change:], s.m_oaKey[:change]...)
	}

	return s.m_sChangeRule
}

func (s *safeInput) getRuleByPos(pos int) (int, int) {
	for i := 0; i < len(s.m_oaSaveRules); i++ {
		if s.m_oaSaveRules[i].iPos == pos {
			return s.m_oaSaveRules[i].iRuleCode, s.m_oaSaveRules[i].iParam
		}
	}

	return 0, 0
}

func (s *safeInput) mappingCode(pwd string) string {
	mappings := ""
	pos := 0
	code := ""
	key := ""
	sourceIndex := 0
	for i := 0; i < len(pwd); i++ {
		pos = i + 1
		code = pwd[i : i+1]
		key = ""

		// 找出code对应在m_oaSource中的index
		sourceIndex = 0
		for ; sourceIndex < len(s.m_oaSource); sourceIndex++ {
			if s.m_oaSource[sourceIndex] == code {
				break
			}
		}

		// 根据输入顺序找出变换规则
		iRuleCode, iParam := s.getRuleByPos(pos)

		// 根据RuleCode进行不同的处理
		switch iRuleCode {
		case 0: // 保留原数据
			key = code
		case 1: // 根据sourceIndex获取到oaKey中对应数据
			key = s.m_oaKey[sourceIndex]
		case 2: // 改变sourceIndex
			key = s.m_oaKey[sourceIndex-iParam+len(s.m_oaKey)&((sourceIndex-iParam)>>31)]
		case 3: // 改变sourceIndex
			key = s.m_oaKey[(sourceIndex+iParam)%len(s.m_oaKey)]
		case 4: // 改变key
			key = s.m_oaKey[sourceIndex]
			singleKeys := make([]string, len(key))
			for j := 0; j < len(key); j++ {
				singleKeys[j] = key[j : j+1]
			}
			iParam = iParam % len(key)
			tmpSingleKeys := make([]string, len(key))
			for j := 0; j < len(key); j++ {
				tmpSingleKeys[(j+iParam)%len(key)] = singleKeys[j]
			}

			key = ""
			for j := 0; j < len(tmpSingleKeys); j++ {
				key = key + tmpSingleKeys[j]
			}
		case 5: // 改变key
			key = s.m_oaKey[sourceIndex]
			singleKeys := make([]string, len(key))
			for j := 0; j < len(key); j++ {
				singleKeys[j] = key[j : j+1]
			}
			iParam = iParam % len(key)
			tmpSingleKeys := make([]string, len(key))
			for j := 0; j < len(key); j++ {
				tmpSingleKeys[j-iParam+len(key)&((j-iParam)>>31)] = singleKeys[j]
			}

			key = ""
			for j := 0; j < len(tmpSingleKeys); j++ {
				key = key + tmpSingleKeys[j]
			}
		default:
			key = code
		}
		mappings = mappings + key
	}

	return mappings
}

func (s *safeInput) getRsaCode(plain string) string {
	// rsa加密
	rsaPubKey := &rsa.PublicKey{
		N: new(big.Int).SetBytes(s.m_sModuls),
		E: 65537,
	}
	enRsaData, _ := tools.RSAEncrypt([]byte(plain), rsaPubKey)

	// sm2加密
	enSm2Data, _ := encSM2([]byte(plain), s.m_sm2PublicKeyX, s.m_sm2PublicKeyY)

	return fmt.Sprintf("%X||%s", enRsaData, enSm2Data)
}
