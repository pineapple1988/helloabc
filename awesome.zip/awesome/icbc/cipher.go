package icbc

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm2"
	"crypto/md5"
	"fmt"
	"math/big"
	"net/url"
	"strings"
)

func (b *Bank) userAgent(path string) string {
	ua := fmt.Sprintf("ICBCiPhoneCSNew F-ePass %s ICBCiPhone epassComponentVersion:%s %s %s %s wifi ",
		authenVersion, authenVersion, b.Model, b.SystemVersion, b.IMEI)

	u, _ := url.Parse(path)
	cookies := b.c.Jar.Cookies(u)

	cookieUA := ""
	for _, c := range cookies {
		if strings.HasPrefix(c.Name, "epass") {
			if cookieUA != "" {
				cookieUA += ";"
			}
			paths := strings.Split(c.Value, "|")
			if len(paths) >= 1 {
				cookieUA = c.Name + "=" + paths[0]
			}
		}
	}

	return ua + cookieUA + " (null)"
}

func (b *Bank) userAgentIOS(path string) string {
	ua := fmt.Sprintf("ICBCiPhoneCSNew F-ePass %s ICBCiPhone epassComponentVersion:%s %s %s %s wifi BSComponentVersion:%s ",
		authenVersion, authenVersion, b.Model, b.SystemVersion, b.IMEI, authenVersion)

	u, _ := url.Parse(path)
	cookies := b.c.Jar.Cookies(u)

	cookieUA := ""
	for _, c := range cookies {
		if strings.HasPrefix(c.Name, "epass") {
			if cookieUA != "" {
				cookieUA += ";"
			}
			paths := strings.Split(c.Value, "|")
			if len(paths) >= 1 {
				cookieUA = c.Name + "=" + paths[0]
			}
		}
	}
	// Mozilla/5.0 (iPhone; CPU iPhone OS 13_1_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148
	iosUA := fmt.Sprintf(" Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
		strings.ReplaceAll(b.SystemVersion, ".", "_"))

	return ua + cookieUA + iosUA + " (null)"
}

func (b *Bank) userAgentBSIOS(path string) string {
	ua := fmt.Sprintf("ICBCiPhoneBSNew F-ePass %s ICBCiPhone epassComponentVersion:%s %s %s %s wifi BSComponentVersion:%s ",
		authenVersion, authenVersion, b.Model, b.SystemVersion, b.IMEI, authenVersion)

	u, _ := url.Parse(path)
	cookies := b.c.Jar.Cookies(u)

	cookieUA := ""
	for _, c := range cookies {
		if strings.HasPrefix(c.Name, "epass") {
			if cookieUA != "" {
				cookieUA += ";"
			}
			paths := strings.Split(c.Value, "|")
			if len(paths) >= 1 {
				cookieUA = c.Name + "=" + paths[0]
			}
		}
	}
	// Mozilla/5.0 (iPhone; CPU iPhone OS 13_1_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148
	iosUA := fmt.Sprintf(" Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
		strings.ReplaceAll(b.SystemVersion, ".", "_"))

	return ua + cookieUA + iosUA + " (null)"
}

func (b *Bank) userAgentBSIOSAndWebview(path string) string {
	ua := fmt.Sprintf("ICBCiPhoneBSNew F-ePass %s ICBCiPhone epassComponentVersion:%s %s %s %s wifi BSComponentVersion:%s ",
		authenVersion, authenVersion, b.Model, b.SystemVersion, b.IMEI, authenVersion)

	u, _ := url.Parse(path)
	cookies := b.c.Jar.Cookies(u)

	cookieUA := ""
	for _, c := range cookies {
		if strings.HasPrefix(c.Name, "epass") {
			if cookieUA != "" {
				cookieUA += ";"
			}
			paths := strings.Split(c.Value, "|")
			if len(paths) >= 1 {
				cookieUA = c.Name + "=" + paths[0]
			}
		}
	}
	// Mozilla/5.0 (iPhone; CPU iPhone OS 13_1_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148
	iosUA := fmt.Sprintf(" Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
		strings.ReplaceAll(b.SystemVersion, ".", "_"))

	return ua + cookieUA + iosUA
}

func (b *Bank) userAgentWap() string {
	return fmt.Sprintf("ICBCiPhoneCSNew F-WAPB %s fullversion:%s newversion:%s %s %s %s wifi",
		wapVersion, wapVersion, newVersion, b.Model, b.SystemVersion, b.IMEI)
}

func (b *Bank) userAgentWapIOS() string {
	ua := fmt.Sprintf("ICBCiPhoneBSNew F-WAPB %s fullversion:%s newversion:%s %s %s %s wifi",
		wapVersion, wapVersion, newVersion, b.Model, b.SystemVersion, b.IMEI)
	iosUA := fmt.Sprintf(" Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 BSComponentVersion:%s",
		strings.ReplaceAll(b.SystemVersion, ".", "_"), "6.1")
	return ua + iosUA
}

func encryptMaps(body map[string]string, key string) *url.Values {
	ret := &url.Values{}
	for k, v := range body {
		enV, _ := tools.TripleDESECBEncrypt([]byte(v), []byte(key))
		ret.Set(k, fmt.Sprintf("%X", enV))
	}
	return ret
}

func encSM2(data []byte, x, y string) (string, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	out, err := sm2.EncryptFixedK(pub, data, "4C62EEFD6ECFC2B95B92FD6C3D9575148AFA17425546D49018E5388D49DD7B4F")
	if err != nil {
		return "", err
	}

	// 这里的输出顺序需要改变一下
	c1 := out[:0x41]
	c3 := out[0x41:0x61]
	c2 := out[0x61:]
	// 这里一定要用copy 不能使用append
	realOut := make([]byte, len(out))
	copy(realOut, c1)
	copy(realOut[len(c1):], c2)
	copy(realOut[len(c1)+len(c2):], c3)

	return fmt.Sprintf("%X", realOut[1:]), nil
}

func build3DESKeyWithS1(imeiString string) (string, string) {
	s1 := fmt.Sprintf("%d", tools.RandIntn(10000)+1)
	salt1 := []byte{
		0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
		0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
		0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
		0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36, 0x36,
	}
	salt2 := []byte{
		0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C,
		0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C,
		0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C,
		0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C, 0x5C,
	}

	for i := 0; i < len(s1); i++ {
		salt1[i] = salt1[i] ^ s1[i]
		salt2[i] = salt2[i] ^ s1[i]
	}

	hash := md5.New()
	hash.Write(salt1)
	hash.Write([]byte(imeiString))
	md := hash.Sum(nil)

	hash = md5.New()
	hash.Write(salt2)
	hash.Write(md[:])
	md = hash.Sum(nil)

	key := fmt.Sprintf("%xf*^*^)9nznv#39Nidu3e)*!#", md)

	return key[:0x18], s1
}
