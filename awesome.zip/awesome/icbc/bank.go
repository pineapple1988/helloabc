package icbc

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"bufio"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

// Bank 工商银行
type Bank struct {
	Account        string `json:"account"`  // 账号，手机号
	LoginPwd       string `json:"loginPwd"` // 登陆密码
	PayPwd         string `json:"payPwd"`   // 支付密码
	CardNo         string `json:"cardNo"`   // 卡号
	IMEI           string `json:"imei"`
	Model          string `json:"model"`
	SystemVersion  string `json:"systemVersion"`
	ClientIP       string `json:"clientIp"`
	PhysicalMemory string `json:"physicalMemory"` // 内存大小
	OwnerName      string `json:"ownerName"`
	CISNo          string `json:"cisNo"`
	UserId         string `json:"userId"`
	EbdpUUID       string `json:"ebdpUUID"`
	//AamNum         string `json:"aamNum"`
	//TokenID        string `json:"tokenId"`
	dseSessionId  string
	dseSessionId2 string
	dsePageId     string
	c             *http.Client
	logger        *log2.MyLog
}

// New 创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:  account,
		LoginPwd: loginPwd,
		PayPwd:   payPwd,
	}

	b.IMEI = tools.NewUUIDUpper()
	b.EbdpUUID = tools.NewUUIDUpper()
	b.Model = tools.NewModel()
	b.SystemVersion = tools.NewSysVersion()
	b.ClientIP = tools.NewIPV4()
	b.PhysicalMemory = fmt.Sprintf("%d", (tools.PhysicalMemory(b.Model)-int64(tools.RandBetween(1024*1024*50, 1024*1024*200)))/1000)
	b.OwnerName = tools.NewOwnerName()

	b.Save()
	return b
}

// Save 保存账号信息
func (b *Bank) Save() {
	path := "./icbc/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 创建新的client
func (b *Bank) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	u, _ := url.Parse("http://127.0.0.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// Login 登陆
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.c = b.NewHTTPClient()
	// log
	b.logger = &log2.MyLog{Prefix: fmt.Sprintf("[ICBC][%s]", b.Account)}

	b.getSwitchFlag()
	sendCode := &sendSmsCodeRes{}
	if b.CISNo == "" {
		sendCode = b.requestMsgVerifyCode()
		if sendCode.TranErrorCode != "0" {
			b.logger.Errorf("首次登陆发送验证码出现错误 msg=%s, code=%s", sendCode.TranErrorDisplayMsg, sendCode.TranErrorCode)
			return base.LoginResultFail
		}
		if sendCode.MobileRegisted != "1" {
			b.logger.Error("当前账号未注册，请注册后再登陆")
			return base.LoginResultFail
		}

		b.logger.Info("首次登陆需要短信，请输入验证码：")
		br := bufio.NewReader(os.Stdin)
		code, _, _ := br.ReadLine()
		b.logger.Infof("收到短信验证码：%s", string(code))
		sendCode = b.submitMsgVerifyCode(sendCode.SendMessageNo, string(code))
		if sendCode.TranErrorCode != "0" {
			b.logger.Errorf("首次登陆提交验证码出现错误 msg=%s, code=%s", sendCode.TranErrorDisplayMsg, sendCode.TranErrorCode)
			return base.LoginResultFail
		}
	}

	randomRes := b.getRandomNum()
	if randomRes.TranErrorCode != "0" {
		b.logger.Errorf("获取键盘随机数出现错误 msg=%s, code=%s", randomRes.TranErrorDisplayMsg, randomRes.TranErrorCode)
		return base.LoginResultFail
	}

	res := b.login(randomRes, sendCode)
	if res.TranErrorCode != "0" {
		b.logger.Errorf("登陆提交数据出现错误 msg=%s, code=%s", res.TranErrorDisplayMsg, res.TranErrorCode)
		return base.LoginResultFail
	}
	encryptedData := res.EncryptedDataToApp
	signData := res.SignDataToApp
	if res.IsBand == "3" {
		// 还没绑定卡
		b.logger.Error("当前账号未绑定银行卡，请绑定后在登陆")
		return base.LoginResultFail
	}
	// 需要绑定设备
	if res.IsBand == "0" {
		html := b.gotoDeviceBand(res)
		b.dsePageId = getHtmlText(html, `name="dse_pageId"value="`)
		// 如果不是第一次登陆就需要获取验证码，第一次的话 前面已经验证过验证码了
		if b.CISNo != "" {
			sessionId := getHtmlText(html, `sendParam["SessionId"]="`)
			dseSessionId := getHtmlText(html, `sendParam["dse_sessionId"]="`)
			if sessionId == "" || dseSessionId == "" {
				b.logger.Errorf("登陆绑定设备获取参数不完整sessionId=%s, dseSessionId=%s", sessionId, dseSessionId)
				return base.LoginResultFail
			}

			sendRes := b.sendSMS(sessionId, dseSessionId)
			if sendRes.TranErrorCode != "0" || sendRes.SendMsgErr != "" {
				b.logger.Errorf("发送短信验证码出现错误 msg=%s, code=%s, sendMsgErr=%s", sendRes.TranErrorDisplayMsg,
					sendRes.TranErrorCode, sendRes.SendMsgErr)
				return base.LoginResultFail
			}

			// 获取验证码
			b.logger.Info("请输入验证码:")
			br := bufio.NewReader(os.Stdin)
			smsCode, _, _ := br.ReadLine()
			b.logger.Infof("收到验证码[%s]", string(smsCode))

			// 提交验证码
			html = b.link(string(smsCode), dseSessionId)
			// 信息代码：96110139  提示信息：您的手机号或短信验证码输入错误或已超时，请认真核对后重新输入
			if strings.Contains(html, "您的手机号或短信验证码输入错误或已超时") {
				b.logger.Error("验证码错误或已超时")
				return base.LoginResultFail
			}
		}
		b.dsePageId = getHtmlText(html, `name="dse_pageId"value="`)
		encryptedData = getHtmlText(html, `name="encryptedData"value="`)
		signData = getHtmlText(html, `name="signData"value="`)
		dseSessionId := getHtmlText(html, `name="dse_sessionId"value="`)
		sessionId := dseSessionId
		if encryptedData == "" || signData == "" {
			b.logger.Errorf("绑定设备进入下一个页面 获取参数不完整encryptedData=%s, signData=%s", encryptedData, signData)
			return base.LoginResultFail
		}

		// 获取到选择卡输入支付密码界面
		selectCardHtml := b.interveneForm(encryptedData, signData, dseSessionId)

		if strings.Contains(selectCardHtml, "个人客户人脸识别服务授权书") {
			b.logger.Error("需要手动去开通人脸识别服务")
			return base.LoginResultFail
		}

		if strings.Contains(selectCardHtml, "为了保证信息安全，即将进行人脸验证") {
			if tools.FileExist("./icbc/bin/" + b.Account + ".jpg") {
				b.logger.Info("绑定设备需要进行刷脸，走刷脸流程")

				b.dsePageId = getHtmlText(selectCardHtml, `name="dse_pageId"value="`)
				tranFlagFirst := getHtmlText(selectCardHtml, `name="tranFlagFirst"value="`)
				tranFlagNewFace := getHtmlText(selectCardHtml, `name="tranFlagNewFace"value="`)
				selectCardHtml = b.faceRecognitionTranLink1(tranFlagFirst, tranFlagNewFace, dseSessionId)

				b.dsePageId = getHtmlText(selectCardHtml, `name="dse_pageId"value="`)
				tranFlagFirst = getHtmlText(selectCardHtml, `name="tranFlagFirst"value="`)
				tranFlagNewFace = getHtmlText(selectCardHtml, `name="tranFlagNewFace"value="`)
				// 获取重要的参数
				encryptedDataToApp := getHtmlText(selectCardHtml, `encryptedDataToApp="`)
				signDataToApp := getHtmlText(selectCardHtml, `signDataToApp="`)
				imgData, _ := ioutil.ReadFile("./icbc/bin/" + b.Account + ".jpg")
				if encryptedDataToApp == "" || signDataToApp == "" || len(imgData) <= 0 {
					b.logger.Errorf("绑定设备准备提交刷脸图片参数不全 encryptedDataToApp=%s, signDataToApp=%s， imgDataLen=%d",
						encryptedDataToApp, signDataToApp, len(imgData))
					return base.LoginResultFail
				}
				faceRes := b.checkFaceInfoNew(encryptedDataToApp, signDataToApp, sessionId, imgData)
				if faceRes.TranErrorCode != "0" && faceRes.TranErrorCode != "" {
					b.logger.Errorf("绑定设备提交刷脸图片返回错误 msg=%s, code=%s", faceRes.TranErrorDisplayMsg, faceRes.TranErrorCode)
					// 这里就不返回失败了，直接跳过刷脸，后面转账会刷脸
					//return base.LoginResultFail
				} else {
					selectCardHtml = b.faceRecognitionTranLink(tranFlagFirst, tranFlagNewFace, dseSessionId)
				}
			} else {
				b.logger.Info("绑定设备需要进行刷脸，没有刷脸图片")
			}
		}

		b.dsePageId = getHtmlText(selectCardHtml, `name="dse_pageId"value="`)
		// 获取到randomId
		randomId := getHtmlText(selectCardHtml, `name="randomId"value="`)
		// 获取到对应卡号的index和cardNo
		selectCardHtml = strings.ReplaceAll(selectCardHtml, " ", "")

		allCardStr := strings.Split(selectCardHtml, "onclick=zerotj(\"")
		cardCount := len(allCardStr) - 1

		verifyCardIndex := ""
		verifyCardNo := ""
		cardMap := map[string]string{}

		if b.CardNo == "" {
			b.logger.Error("此账号未指定卡,请检查")
			return base.LoginResultFail
		}

		// 多张卡
		if cardCount >= 1 {
			for i := 0; i < cardCount; i++ {
				singerStr := allCardStr[i+1]
				cardIndexAndNo := strings.Split(singerStr, "\",\"")
				index := cardIndexAndNo[0]
				cardIndexAndNo = strings.Split(cardIndexAndNo[1], "\"")
				cardNo := cardIndexAndNo[0]
				cardMap[index] = cardNo
			}
		}

		// 只有一张
		if len(cardMap) <= 0 {
			cardNo := getHtmlText(selectCardHtml, `zerotj("0","`)
			if cardNo != "" {
				cardMap["0"] = cardNo
			}
		}

		if len(cardMap) <= 0 {
			// 如果需要刷脸没走刷脸流程，需要生成
			cardMap["0"] = fmt.Sprintf("%s&nbsp;****&nbsp;%s", b.CardNo[:4], b.CardNo[len(b.CardNo)-4:])
		}
		if randomId == "" {
			// 如果需要刷脸没走刷脸流程，需要生成，没生成也没关系
			randomId = fmt.Sprintf("%d", time.Now().UnixNano())
		}

		for k := range cardMap {
			if strings.Contains(cardMap[k], b.CardNo[len(b.CardNo)-4:]) {
				verifyCardIndex = k
				verifyCardNo = cardMap[k]
			}
		}

		//verifyCardIndex := "0"
		//verifyCardNo := "6222&nbsp;****&nbsp;1810"
		// 这里不判断randomId
		if verifyCardIndex == "" || verifyCardNo == "" {
			b.logger.Errorf("设备绑定提交卡密码参数不全, verifyCardIndex=%s, verifyCardNo=%s",
				verifyCardIndex, verifyCardNo)
			return base.LoginResultFail
		}

		submitCardPwdRes := b.submitPayPwd(verifyCardIndex, verifyCardNo, randomId, sessionId, dseSessionId)
		if submitCardPwdRes.TranErrorCode != "0" {
			b.logger.Errorf("提交卡密码出现错误 msg=%s, code=%s", submitCardPwdRes.TranErrorDisplayMsg,
				submitCardPwdRes.TranErrorCode)
			return base.LoginResultFail
		}

		html = b.successForm(dseSessionId, randomId)
		b.dsePageId = getHtmlText(html, `name="dse_pageId"value="`)

		html = b.bd002succ(dseSessionId)
		b.dsePageId = getHtmlText(html, `name="dse_pageId"value="`)

		// 不判断错误了，只要EncryptedDataToApp和SignDataToApp有就行
		sendRes := b.submitBind_M(sessionId, dseSessionId)
		//if sendRes.TranErrorCode != "0" || sendRes.SendMsgErr != "" {
		//	b.logger.Errorf("submitBind_M出现错误 msg=%s, code=%s, sendMsgErr=%s", sendRes.TranErrorDisplayMsg,
		//		sendRes.TranErrorCode, sendRes.SendMsgErr)
		//	return base.LoginResultFail
		//}

		b.submitAuto(dseSessionId)

		encryptedData = sendRes.EncryptedDataToApp
		signData = sendRes.SignDataToApp
		b.signoff(sessionId, dseSessionId)
	}

	if encryptedData == "" || signData == "" {
		b.logger.Errorf("获取参数不完整encryptedData=%s, signData=%s", encryptedData, signData)
		return base.LoginResultFail
	}

	twiceLoginRes := b.handleLoginResponseData(encryptedData, signData)
	sessionId := ""
	userId := ""
	mainCIS := ""
	//aamNum := ""
	for _, m := range twiceLoginRes.Map {
		if m.ID == "parameter" {
			for _, f := range m.Field {
				if f.ID == "dse_sessionId" {
					b.dseSessionId2 = f.Text
				}
				if f.ID == "balancingParam" {
					// name="dse_sessionId" value="6997C865842A9F43155960988F355D8D8B98934762347C5300CD9EA3C7094A472FB3806486C1F1239020656789E3E5E4"
					if strings.HasPrefix(f.Text, `name="dse_sessionId"`) {
						ss := strings.Split(f.Text, `value="`)
						if len(ss) >= 2 {
							text := ss[1]
							text = text[:len(text)-1]
							b.dseSessionId = text
							b.logger.Infof("获取到dseSessionId=%s", b.dseSessionId)
							break
						}
					}
				}
			}
		}
		if m.ID == "opdata" {
			for _, f := range m.Field {
				if f.ID == "sessionid" {
					sessionId = f.Text
				}
				if f.ID == "mainCIS" {
					mainCIS = f.Text
				}
				if f.ID == "userId" {
					userId = f.Text
				}
				//if f.ID == "aamNum" {
				//	aamNum = f.Text
				//}
			}
		}
	}

	if sessionId == "" || userId == "" || mainCIS == "" {
		b.logger.Errorf("登陆完未获取到完整数据 sessionId=%s, userId=%s, mainCIS=%s", sessionId, userId, mainCIS)
		return base.LoginResultFail
	}

	// 完成对数据的解密
	aes128key := aesKey + sessionId[:5]
	bytesUserId, _ := base64.StdEncoding.DecodeString(userId)
	bytesMainCIS, _ := base64.StdEncoding.DecodeString(mainCIS)
	//bytesAamNum, _ := base64.StdEncoding.DecodeString(aamNum)

	deUserId := tools.AESCBCDecrypt(bytesUserId, []byte(aes128key), []byte(aes128key))
	deMainCIS := tools.AESCBCDecrypt(bytesMainCIS, []byte(aes128key), []byte(aes128key))
	//deAamNum := tools.AESCBCDecrypt(bytesAamNum, []byte(aes128key), []byte(aes128key))

	if string(deUserId) != "" {
		b.UserId = string(deUserId)
	}
	if string(deMainCIS) != "" {
		b.CISNo = string(deMainCIS)
	}
	b.Save()
	//b.AamNum = string(deAamNum)
	//b.UserId = "1001282346746"
	if b.dseSessionId == "" {
		b.logger.Error("登陆完成未获取到dseSessionId")
		return base.LoginResultFail
	}

	b.loginTokenManager()
	return base.LoginResultSuccess
}

// CardList 查询卡列表
func (b *Bank) CardList() {
	list := b.cardList()
	tranErrCode := ""
	tranErrDispMsg := ""
	res := &cardListRes{}
	for _, m := range list.Map {
		if m.ID == "opdata" {
			for _, f := range m.Field {
				if f.ID == "tranErrCode" {
					tranErrCode = f.Text
				}
				if f.ID == "tranErrDispMsg" {
					tranErrDispMsg = f.Text
				}
				if f.ID == "page" {
					err := json.Unmarshal([]byte(f.Text), res)
					if err != nil {
						b.logger.Errorf("CardList json.Unmarshal err=%+v", err)
					}
				}
			}
		}
	}

	if tranErrCode != "0" && tranErrCode != "" {
		b.logger.Errorf("查询卡列表出错  msg=%s, code=%s", tranErrDispMsg, tranErrCode)
		return
	}

	//fmt.Println(res)
}

// BillList 查询账单列表
func (b *Bank) BillList() {
	// 必须先使用billListRecent 不然会返回错误 code="96300119" msg="请您核对查询交易明细的输入信息是否有误，谢谢！"
	// billListRecent是最近一个月的账单 已经够用了

	// areaCode 为卡号的 6-10位
	// areaName "盐城" 在卡列表中有返回
	// careType "011" 在卡列表中有返回
	// careTypeDesc "借记卡(Ⅰ类)" 在卡列表中有返回
	cardNo := "6212264301023201856"
	cardType := "011"
	cardTypeDesc := "借记卡(Ⅰ类)"
	areaName := "南京"
	list, pageId := b.billListRecent(cardNo, cardType, cardTypeDesc, cardNo[6:10], areaName, 0, "")
	tranErrCode := ""
	tranErrDispMsg := ""
	res := &billListRes{}
	for _, m := range list.Map {
		if m.ID == "opdata" {
			for _, f := range m.Field {
				if f.ID == "tranErrCode" {
					tranErrCode = f.Text
				}
				if f.ID == "tranErrDispMsg" {
					tranErrDispMsg = f.Text
				}
				if f.ID == "page" {
					err := json.Unmarshal([]byte(f.Text), res)
					if err != nil {
						b.logger.Errorf("BillList json.Unmarshal err=%+v", err)
					}
				}
			}
		}
	}
	if tranErrCode != "0" && tranErrCode != "" {
		b.logger.Errorf("查询账单出错 msg=%s, code=%s", tranErrDispMsg, tranErrCode)
		return
	}

	if res.Table.HasMore == "1" {
		// 下一页
		list, pageId = b.billListRecent(cardNo, cardType, cardTypeDesc, cardNo[6:10], areaName, pageId, res.Table.RefreshMoreURL)
	}

	pageId++
	startTime := "20201217"
	endTime := "20210317"
	list, pageId = b.billList(cardNo, cardType, cardTypeDesc, startTime, endTime, pageId, "")
	tranErrCode = ""
	tranErrDispMsg = ""
	res = &billListRes{}
	for _, m := range list.Map {
		if m.ID == "opdata" {
			for _, f := range m.Field {
				if f.ID == "tranErrCode" {
					tranErrCode = f.Text
				}
				if f.ID == "tranErrDispMsg" {
					tranErrDispMsg = f.Text
				}
				if f.ID == "page" {
					err := json.Unmarshal([]byte(f.Text), res)
					if err != nil {
						b.logger.Errorf("BillList json.Unmarshal err=%+v", err)
					}
				}
			}
		}
	}
	if tranErrCode != "0" && tranErrCode != "" {
		b.logger.Errorf("查询账单出错 msg=%s, code=%s", tranErrDispMsg, tranErrCode)
		return
	}
	if res.Table.HasMore == "1" {
		// 下一页
		list, pageId = b.billList(cardNo, cardType, cardTypeDesc, startTime, endTime, pageId, res.Table.RefreshMoreURL)
	}
}

// Transfer 转账
func (b *Bank) Transfer(destCardNo, destName, amount, remark string) base.TransferResultCode {
	srcCardNo := "6212264301023201856"
	srcCardType := "011"

	//sessionIDRes := b.getTransferSessionID()
	//transferDseSessionId := ""
	//tranErrCode := ""
	//tranErrDispMsg := ""
	//for _, m := range sessionIDRes.Map {
	//	if m.ID == "parameter" {
	//		for _, f := range m.Field {
	//			if f.ID == "dse_sessionId" {
	//				transferDseSessionId = f.Text
	//			}
	//		}
	//	}
	//	if m.ID == "opdata" {
	//		for _, f := range m.Field {
	//			if f.ID == "tranErrCode" {
	//				tranErrCode = f.Text
	//			}
	//			if f.ID == "tranErrDispMsg" {
	//				tranErrDispMsg = f.Text
	//			}
	//		}
	//	}
	//}
	//if tranErrCode != "0" && tranErrCode != "" {
	//	b.logger.Errorf("获取转账dse_sessionid出错 msg=%s, code=%s", tranErrDispMsg, tranErrCode)
	//	return base.TransferResultFail
	//}

	transferDseSessionId := b.dseSessionId2
	b.gotoTransferHistory(transferDseSessionId)

	transferHtml := b.gotoTransfer(transferDseSessionId)
	tranTime := getHtmlText(transferHtml, `name="tranTimetemp"value="`)
	b.dsePageId = getHtmlText(transferHtml, `name="dse_pageId"value="`)
	if b.dsePageId == "" {
		b.dsePageId = "7"
	}

	// 检查余额
	balance := b.balance(srcCardNo, srcCardType, transferDseSessionId)
	if balance.Opdata.Balance != "" {
		fBalance, _ := strconv.ParseFloat(balance.Opdata.Balance, 64)
		fAmount, _ := strconv.ParseFloat(amount, 64)
		fAmount = fAmount * 100
		if fBalance < fAmount {
			b.logger.Errorf("转出账户余额不足 balance=%.2f amount=%s", fBalance/100, amount)
			return base.TransferResultFail
		}
	}
	searchRes := b.searchBank(destCardNo, destName, transferDseSessionId)
	bankName := searchRes.Opdata.PayeeBranchName // &#x4e2d;&#x56fd;&#x519c;&#x4e1a;&#x94f6;&#x884c;&#x80a1;&#x4efd;&#x6709;&#x9650;&#x516c;&#x53f8;
	bankName = strings.ReplaceAll(bankName, "&#x", "")
	bankNameWords := strings.Split(bankName, ";")
	bankName = unicode2Chinese(bankNameWords)

	bankFullCode := searchRes.Opdata.Blvcode
	bankCode := searchRes.Opdata.RecTypeBranchNo

	isSamebank := false
	randomId := ""
	verifyCode := "1111"
	if bankCode == "102" {
		// 同行
		isSamebank = true
		randomId = getHtmlText(transferHtml, `name="randomId"value="`)
		verifyCode = getHtmlText(transferHtml, `name="verifyCode"value="`)
	}

	confirmRes := b.remit(isSamebank, srcCardNo, srcCardType, destCardNo, destName, bankName, bankFullCode, bankCode, amount, remark, transferDseSessionId)
	// 96303002  对不起，你尚未开通对外转账功能，请到柜面开通
	if confirmRes.Opdata.TranErrCodeForJSON != "" {
		b.logger.Errorf("第一次提交转账出现错误，msg=%s, code=%s", confirmRes.Opdata.TranErrDispMsgForJSON, confirmRes.Opdata.TranErrCodeForJSON)
		return base.TransferResultFail
	}
	if confirmRes.Opdata.BtDaySumLimitFlag == "1" {
		// 超过日累确认标志 0:否 ，1：是
		b.logger.Error("超过日累计限额")
		return base.TransferResultFail
	}
	if strings.Contains(confirmRes.Opdata.MediumTypeList, "997") && confirmRes.Opdata.DefaultAuthenTypeNAD == "991" {
		b.logger.Error("交易金额已超过您的最高限额,请登陆手机App调高限额再转账")
		return base.TransferResultFail
	}

	defaultAuthenType := confirmRes.Opdata.TranAuthenInfoData.DefaultAuthenType
	if defaultAuthenType == "4" {
		b.logger.Error("第一次验证需要密码器验证，请手动修改e支付验证方式")
		return base.TransferResultFail
	}

	if defaultAuthenType != "991" && defaultAuthenType != "99" {
		b.logger.Errorf("第一次验证出现其他的验证方式，需要完善 defaultAuthenType=%s", defaultAuthenType)
		return base.TransferResultFail
	}

	if (strings.Contains(confirmRes.Opdata.MediumTypeList, "997") && defaultAuthenType == "991") ||
		(strings.Contains(confirmRes.Opdata.MediumTypeList, "101") && defaultAuthenType == "992") {
		if confirmRes.Opdata.CheckFacePictureResultFlag == "2" {
			b.logger.Error("本次转账金额超过您的支付密码认证的最高限额，通过人脸验证后可上调至最高单笔" + confirmRes.Opdata.EPaySingleQuotaLarge + "元、日累计" +
				confirmRes.Opdata.EPayDayQuotaLarge + "元。您当前不在人民银行联网核查系统工作时间内(9:00-17:00)或超过人脸识别最大错误次数。")
		} else {
			b.logger.Error("交易金额已超过您的最高限额，请手动陌生人转账提高转账额度")
		}
		return base.TransferResultFail
	}

	html := ""
	code := base.TransferResultFail
	// 支付密码校验
	if defaultAuthenType == "991" {
		verifyRes := b.verifyEpayPassword(transferDseSessionId)
		if verifyRes.Opdata.TranErrCodeForJSON != "0" {
			b.logger.Errorf("verifyEpayPassword出错 msg=%s, code=%s", verifyRes.Opdata.TranErrDispMsgForJSON, verifyRes.Opdata.TranErrCodeForJSON)
			return base.TransferResultFail
		}
	}

	// 短信校验
	if defaultAuthenType == "99" {
		// 这种情况一般是没开通ePay支付密码校验
		html, code = b.transferVerifySms(isSamebank, tranTime, randomId, verifyCode, transferDseSessionId)
		if code != base.TransferResultSuccess {
			return code
		}
	}

	if confirmRes.Opdata.TranAuthenInfoData.ComplexAuthenNAD == "1" {
		// 验证还没完成
		confirmRes = b.remit2(isSamebank, tranTime, transferDseSessionId)
		// 93000000 人脸识别对比失败，请重试。
		// 96300119 请您核对查询交易明细的输入信息是否有误，谢谢！ -> 这里不是报错
		if confirmRes.Opdata.TranErrCodeForJSON != "" {
			b.logger.Errorf("第二次提交转账出现错误， msg=%s, code=%s", confirmRes.Opdata.TranErrDispMsgForJSON, confirmRes.Opdata.TranErrCodeForJSON)
			return base.TransferResultFail
		}
		defaultAuthenType = confirmRes.Opdata.TranAuthenInfoData.DefaultAuthenType
		if defaultAuthenType == "4" {
			b.logger.Error("第二次验证需要密码器验证，请手动修改e支付验证方式")
			return base.TransferResultFail
		}
		if defaultAuthenType != "99" {
			b.logger.Errorf("第二次验证出现其他的验证方式，需要完善 defaultAuthenType=%s", defaultAuthenType)
			return base.TransferResultFail
		}

		html, code = b.transferVerifySms(isSamebank, tranTime, randomId, verifyCode, transferDseSessionId)
		if code != base.TransferResultSuccess {
			return code
		}
	} else {
		html = b.query01(isSamebank, tranTime, randomId, verifyCode, transferDseSessionId)
	}

	if strings.Contains(html, "rma上行短信结果页") && strings.Contains(html, "请您按短信提示操作完成转账") {
		// 需要转发工行短信到工行才能完成转账
		return base.TransferResultUnknown
	}

	if strings.Contains(html, "rma核实确认页") && strings.Contains(html, "为了您的交易安全，请输入以下信息进行验证:") {
		// 找出要核实的项目
		b.logger.Error("rma需要核实确认 转账失败")
		return base.TransferResultFail
	}

	for i := 0; i < 3; i++ {
		b.dsePageId = getHtmlText(html, `name="dse_pageId"value="`)
		if b.dsePageId == "" {
			b.dsePageId = "8"
		}
		if strings.Contains(html, "交易正在处理") {
			// 轮循
			time.Sleep(2 * time.Second)
			html = b.query02(isSamebank, i+1, transferDseSessionId)
		} else if strings.Contains(html, "交易成功") || strings.Contains(html, "已实时到账") {
			// 同行 "已实时到账"
			// 跨行 "交易成功"
			b.logger.Info("转账成功")
			return base.TransferResultSuccess
		} else if strings.Contains(html, "交易失败") {
			subHtml := strings.ReplaceAll(html, " ", "")
			ss := strings.Split(subHtml, "失败原因：")
			if len(ss) >= 2 {
				ss = strings.Split(ss[1], "</")
				if len(ss) >= 2 {
					ss[0] = strings.TrimSpace(ss[0])
					ss[0] = strings.ReplaceAll(ss[0], "&#x", "")
					sss := strings.Split(ss[0], ";")
					b.logger.Errorf("转账失败，原因：%s", unicode2Chinese(sss))
				}
			}
			return base.TransferResultFail
		} else if strings.Contains(html, "您本次登录使用当前交易笔数超过我行交易次数限制，建议重新登录后再使用我行手机银行功能") {
			// 96300262 您本次登录使用当前交易笔数超过我行交易次数限制，建议重新登录后再使用我行手机银行功能
			b.logger.Error("交易结果未知")
			return base.TransferResultUnknown
		} else if strings.Contains(html, "e支付反欺诈") {
			riskControlType := getHtmlText2(html, `RiskControlType='`)
			formName := getHtmlText(html, `RiskControlVerify("`)
			b.logger.Infof("转账需要进行e支付反欺诈核实 RiskControlType=%s, formName=%s", riskControlType, formName)
			switch riskControlType {
			case "0002": // 验证卡密
				b.logger.Error("反欺诈验证卡密")
			case "0003": // 验证证件
				b.logger.Error("反欺诈验证证件")
			case "0004": // 验证介质序列号
				b.logger.Error("反欺诈验证介质序列号")
			case "0005": // 验证预留问题
				b.logger.Error("反欺诈验证预留问题")
			case "0013": // 验证短信
				b.logger.Error("反欺诈验证短信")
			case "0016": // 验证人脸
				b.logger.Error("反欺诈验证人脸")
			case "0017": // 验证电信诈骗问题
				b.logger.Error("反欺诈验证电信诈骗问题")
			case "9997", "0022", "0008": // 直接提交的form
				b.logger.Errorf("反欺诈验证formName=%s", formName)
			default:
				b.logger.Errorf("未知的反欺诈验证类型 riskControlType=%s", riskControlType)
			}

			return base.TransferResultFail
		}
	}
	// 信息代码:96310703 提示信息:交易失败

	return base.TransferResultFail
}

func (b *Bank) transferVerifySms(isSameBank bool, tranTime, randomID, verifyCode, desSessionId string) (string, base.TransferResultCode) {
	b.logger.Info("转账需要短信，请输入验证码：")
	br := bufio.NewReader(os.Stdin)
	code, _, _ := br.ReadLine()
	b.logger.Infof("收到短信验证码：%s", string(code))
	html := b.verifyEpayPassInput(isSameBank, string(code), tranTime, randomID, verifyCode, desSessionId)
	// 信息代码：96300233 提示信息：您输入的信息有误，请重新输入。   ->  这个是短信的位数输入不够，提交信息会返回这个
	// 信息代码：96309169 提示信息：手机短信验证码错误
	if html == "" {
		return "", base.TransferResultFailWrongSms
	}
	if strings.Contains(html, "手机短信验证码错误") {
		b.logger.Error("手机短信验证码错误")
		return "", base.TransferResultFailWrongSms
	} else if strings.Contains(html, "&#x624b;&#x673a;&#x77ed;&#x4fe1;&#x9a8c;&#x8bc1;&#x7801;&#x9519;&#x8bef;&#x3002;") {
		b.logger.Error("手机短信验证码错误")
		return "", base.TransferResultFailWrongSms
	}

	return html, base.TransferResultSuccess
}

func getHtmlText(html, prefix string) string {
	html = strings.ReplaceAll(html, " ", "")
	ss := strings.Split(html, prefix)
	if len(ss) >= 2 {
		ss = strings.Split(ss[1], "\"")
		if len(ss) >= 2 {
			return ss[0]
		}
	}

	return ""
}

func getHtmlText2(html, prefix string) string {
	html = strings.ReplaceAll(html, " ", "")
	ss := strings.Split(html, prefix)
	if len(ss) >= 2 {
		ss = strings.Split(ss[1], "'")
		if len(ss) >= 2 {
			return ss[0]
		}
	}

	return ""
}

func unicode2Chinese(chars []string) string {
	var context string
	for _, v := range chars {
		if len(v) < 1 {
			continue
		}
		temp, err := strconv.ParseInt(v, 16, 32)
		if err != nil {
			continue
		}
		context += fmt.Sprintf("%c", temp)
	}

	return context
}
