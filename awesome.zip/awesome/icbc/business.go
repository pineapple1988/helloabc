package icbc

import (
	"awesome/tools"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"github.com/go-http-utils/headers"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

func (b *Bank) getSwitchFlag() *getSwitchFlagRes {
	respObj := &getSwitchFlagRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)

	enData, _ := tools.TripleDESECBEncrypt([]byte(b.CISNo), []byte(key))

	query := &url.Values{
		"IMEI":                []string{b.IMEI},
		"channelCode":         []string{"303"},
		"cisCode":             []string{fmt.Sprintf("%X", enData)},
		"forDistributionFlag": []string{"1"},
		"login_id":            []string{fmt.Sprintf("%X", enData)},
		"passAppType":         []string{"303"},
		"s1":                  []string{s1},
		"versionNum":          []string{authenVersion},
	}

	header := &http.Header{
		headers.Cookie:         []string{"grayFlag=0"},
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{b.userAgent(urlGetSwitchFlag)},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPGet(b.c, urlGetSwitchFlag, query, header)
	b.logger.Infof("getSwitchFlag req:%s \r\n resp:%s", query.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("getSwitchFlag DoHTTPGet err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("getSwitchFlag json.Unmarshal resp err=%+v", err)
	}
	return respObj
}

// 第一次登陆发送短信验证码
func (b *Bank) requestMsgVerifyCode() *sendSmsCodeRes {
	respObj := &sendSmsCodeRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)
	enData, _ := tools.TripleDESECBEncrypt([]byte(b.Account), []byte(key))
	ua := b.userAgent(urlEpassloginAsynGetDataServlet)

	body := &url.Values{
		"channelCode":           []string{"303"},
		"ClientUA":              []string{ua},
		"DeviceID":              []string{b.IMEI},
		"IMEI":                  []string{b.IMEI},
		"Language":              []string{"zh_CN"},
		"PhoneNum":              []string{fmt.Sprintf("%X", enData)},
		"TranFlag":              []string{"0"},
		"ZoneNo":                []string{"+86"},
		"clientName":            []string{"1"},
		"clientSystem":          []string{"iOS" + b.SystemVersion},
		"firstLoginFlag_Client": []string{"1"},
		"passAppType":           []string{"303"},
		"s1":                    []string{s1},
		"tranCode":              []string{"A00007"},
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlEpassloginAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("requestMsgVerifyCode req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("requestMsgVerifyCode DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("requestMsgVerifyCode json.Unmarshal resp err=%+v", err)
	}
	return respObj
}

// 第一次登陆验证短信
func (b *Bank) submitMsgVerifyCode(sendMessageNo, code string) *sendSmsCodeRes {
	respObj := &sendSmsCodeRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)
	enData, _ := tools.TripleDESECBEncrypt([]byte(b.Account), []byte(key))
	enSendMessageNo, _ := tools.TripleDESECBEncrypt([]byte(sendMessageNo), []byte(key))
	enCode, _ := tools.TripleDESECBEncrypt([]byte(code), []byte(key))
	ua := b.userAgent(urlEpassloginAsynGetDataServlet)

	body := &url.Values{
		"channelCode":           []string{"303"},
		"ClientUA":              []string{ua},
		"DeviceID":              []string{b.IMEI},
		"IMEI":                  []string{b.IMEI},
		"Language":              []string{"zh_CN"},
		"PhoneNum":              []string{fmt.Sprintf("%X", enData)},
		"SendMessageNo":         []string{fmt.Sprintf("%X", enSendMessageNo)},
		"SignVerifyCode_input":  []string{fmt.Sprintf("%X", enCode)},
		"TranFlag":              []string{"2"},
		"ZoneNo":                []string{"+86"},
		"clientName":            []string{"1"},
		"clientSystem":          []string{"iOS" + b.SystemVersion},
		"firstLoginFlag_Client": []string{"1"},
		"passAppType":           []string{"303"},
		"s1":                    []string{s1},
		"tranCode":              []string{"A00007"},
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlEpassloginAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("submitMsgVerifyCode req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("submitMsgVerifyCode DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("submitMsgVerifyCode json.Unmarshal resp err=%+v", err)
	}
	return respObj
}

// 获取键盘随机数
func (b *Bank) getRandomNum() *randomNumRes {
	respObj := &randomNumRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)
	enData, _ := tools.TripleDESECBEncrypt([]byte(b.Account), []byte(key))
	ua := b.userAgent(urlEpassloginAsynGetDataServlet)
	enUA, _ := tools.TripleDESECBEncrypt([]byte(ua), []byte(key))

	body := &url.Values{
		"ClientUA":  []string{fmt.Sprintf("%X", enUA)},
		"IMEI":      []string{b.IMEI},
		"Language":  []string{"zh_CN"},
		"logonName": []string{fmt.Sprintf("%X", enData)},
		"repFlag":   []string{"2"},
		"s1":        []string{s1},
		"tranCode":  []string{"A00041"},
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlEpassloginAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("getRandomNum req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("getRandomNum DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("getRandomNum json.Unmarshal resp err=%+v", err)
	}
	return respObj
}

// 登陆提交
func (b *Bank) login(randomNum *randomNumRes, sendCode *sendSmsCodeRes) *loginRes {
	respObj := &loginRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)
	enAppVersion, _ := tools.TripleDESECBEncrypt([]byte(cfBundleVersion), []byte(key))
	enBackupLogin, _ := tools.TripleDESECBEncrypt([]byte("0"), []byte(key))
	ua := b.userAgent(urlEpassloginAsynGetDataServlet)
	enUA, _ := tools.TripleDESECBEncrypt([]byte(ua), []byte(key))
	enOSFlag, _ := tools.TripleDESECBEncrypt([]byte("1"), []byte(key))
	enAppType, _ := tools.TripleDESECBEncrypt([]byte("1"), []byte(key))
	encryptedDataFromApp, _ := tools.TripleDESECBEncrypt([]byte(fmt.Sprintf(
		"<?xml version='1.0' encoding='GBK' standalone='YES'?>"+
			"<encryptedData><channelCode>303</channelCode><customerGroup>0111</customerGroup>"+
			"<timeStamp></timeStamp><isExtraRegist>1</isExtraRegist><forwardUrl></forwardUrl>"+
			"<userName>hehe1</userName><customArea></customArea><customMac>%s</customMac><customIP>%s</customIP>"+
			"<passAppType>303</passAppType></encryptedData>", b.IMEI, b.ClientIP)), []byte(key))
	enFirstLoginFlag, _ := tools.TripleDESECBEncrypt([]byte{}, []byte(key))
	enIsRoot, _ := tools.TripleDESECBEncrypt([]byte("false"), []byte(key))
	enLogonName, _ := tools.TripleDESECBEncrypt([]byte(b.Account), []byte(key))
	enVerifyFlag, _ := tools.TripleDESECBEncrypt([]byte("0"), []byte(key))
	// 密码加密
	safe1 := newSafeInput()
	passwdRule := safe1.initRules()
	passwdChangeRule := safe1.initChangeRules() + "#0"
	pwdMapCode := safe1.mappingCode(b.LoginPwd)
	plain := fmt.Sprintf("ICBCRandomID%sICBCRandomID%s", randomNum.Randomnum, pwdMapCode)
	passwd := safe1.getRsaCode(plain)
	enPasswd, _ := tools.TripleDESECBEncrypt([]byte(passwd), []byte(key))
	// 对key进行加密
	safe2 := newSafeInput()
	passwdRule2 := safe2.initRules()
	passwdChangeRule2 := safe2.initChangeRules() + "#0"
	keyMapCode := safe2.mappingCode(key)
	plain = fmt.Sprintf("ICBCRandomID%sICBCRandomID%s", randomNum.Randomnum1, keyMapCode)
	s2 := safe2.getRsaCode(plain)

	body := &url.Values{
		"APPVERSION":           []string{fmt.Sprintf("%X", enAppVersion)},
		"AlipayNonReal":        []string{"1"},
		"BackupLogin":          []string{fmt.Sprintf("%X", enBackupLogin)},
		"CLIENTIP":             []string{b.ClientIP},
		"CLIENTMEMORY":         []string{b.PhysicalMemory},
		"CPUNO":                []string{""},
		"ClientUA":             []string{fmt.Sprintf("%X", enUA)},
		"DEVICENAME":           []string{b.OwnerName},
		"FACTORYINFO":          []string{tools.PhoneName(b.Model)},
		"IMEI":                 []string{b.IMEI},
		"OSFLAG":               []string{fmt.Sprintf("%X", enOSFlag)},
		"OSVERSION":            []string{fmt.Sprintf("iOS%s", b.SystemVersion)},
		"SCRESOLUTION":         []string{tools.ScreenPt(b.Model)}, // 375*667
		"User_os":              []string{"iOS"},
		"appType":              []string{fmt.Sprintf("%X", enAppType)},
		"currentcity":          []string{""},
		"encryptedDataFromApp": []string{fmt.Sprintf("%X", encryptedDataFromApp)},
		"firstLoginFlag":       []string{fmt.Sprintf("%X", enFirstLoginFlag)},
		"in_isRoot":            []string{fmt.Sprintf("%X", enIsRoot)},
		"logonName":            []string{fmt.Sprintf("%X", enLogonName)},
		"randomId":             []string{""},
		"logonPass":            []string{fmt.Sprintf("%X", enPasswd)},
		"passwdRule":           []string{passwdRule},
		"passwdChangeRule":     []string{passwdChangeRule},
		"passwdRule2":          []string{passwdRule2},
		"passwdChangeRule2":    []string{passwdChangeRule2},
		"s1":                   []string{s1},
		"s2":                   []string{s2},
		"tranCode":             []string{"A00001"},
		"verifyCode":           []string{""},
		"verifyFlag":           []string{fmt.Sprintf("%X", enVerifyFlag)},
	}

	if sendCode.FirstLoginEncryptedDataToApp != "" && sendCode.FirstLoginsignDataToApp != "" {
		// 第一次登陆
		body.Set("firstLoginEncryptedDataToApp", sendCode.FirstLoginEncryptedDataToApp)
		body.Set("firstLoginsignDataToApp", sendCode.FirstLoginsignDataToApp)
		body.Set("firstLoginFlag", fmt.Sprintf("%X", enAppType)) // "1"
		body.Set("fisrtLoginBind", "1")
		body.Set("fisrtDeviceName", url.QueryEscape(b.OwnerName))
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlEpassloginAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("login req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("login DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("login json.Unmarshal resp err=%+v", err)
	}

	// 解密
	if respObj.IsBand != "" && respObj.IsBand != "0" && respObj.IsBand != "1" {
		isBand, _ := hex.DecodeString(respObj.IsBand)
		deIsBand, _ := tools.TripleDESECBDecrypt(isBand, []byte(key))
		respObj.IsBand = string(deIsBand)
	}

	return respObj
}

// 去绑定设备,返回的是一个网页 需要去获取到SessionId和dse_sessionId
func (b *Bank) gotoDeviceBand(res *loginRes) string {

	ua := b.userAgentBSIOS(urlICBCINBSEstablishSessionServlet)

	body := url.Values{
		"ClientUA":           {ua},
		"ComputID":           {"10"},
		"FastLoginShowFlag":  {"010"},
		"Language":           {"zh_CN"},
		"PlatFlag":           {"0"},
		"encryptedDataToApp": {res.EncryptedDataToApp},
		"netType":            {"6"},
		"signDataToApp":      {res.SignDataToApp},
		"tranFlag":           {"0"},
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSEstablishSessionServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("gotoDeviceBand req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("gotoDeviceBand DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 发送短信验证码
func (b *Bank) sendSMS(sessionId, dseSessionId string) *sendSmsRes {
	respObj := &sendSmsRes{}

	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlAsynGetDataServlet) + " wkwebview:true"

	body := url.Values{
		"SessionId":     {sessionId},
		"dse_sessionId": {dseSessionId},
		"tranCode":      {"A00011"},
		"tranFlag":      {"13"},
	}

	header := &http.Header{
		headers.Accept:         {"application/json, text/javascript, */*; q=0.01"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("sendSMS req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("sendSMS DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("sendSMS json.Unmarshal resp err=%+v", err)
	}

	return respObj
}

// 提交验证码
func (b *Bank) link(smsCode, dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_RemitMenuBindOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlag":          {"2"},
		"smsSmsVerifyNoTmp": {smsCode},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("link req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("link DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 点击下一步
func (b *Bank) interveneForm(encryptedData, signData, dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_InterveneOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlag":          {""},
		"encryptedData":     {encryptedData},
		"signData":          {signData},
		"tranFlagFirst":     {"0"},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("interveneForm req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("interveneForm DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

func (b *Bank) faceRecognitionTranLink1(tranFlagFirst, tranFlagNewFace, dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_InterveneOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlagFirst":     {tranFlagFirst},
		"tranFlagNewFace":   {tranFlagNewFace},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("faceRecognitionTranLink1 req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("faceRecognitionTranLink1 DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 提交刷脸图片
// 图片大小 480*640 jpg格式 正面照
func (b *Bank) checkFaceInfoNew(encryptedData, signData, sessionId string, imgData []byte) *checkFaceInfoNewRes {
	respObj := &checkFaceInfoNewRes{}

	key, s1 := build3DESKeyWithS1(b.IMEI)
	imgb64 := base64.StdEncoding.EncodeToString(imgData)
	enData, _ := tools.TripleDESECBEncrypt([]byte(imgb64), []byte(key))
	ua := b.userAgent(urlAsynGetDataServlet)
	enUA, _ := tools.TripleDESECBEncrypt([]byte(ua), []byte(key))

	body := &url.Values{
		"ClientUA":      []string{fmt.Sprintf("%X", enUA)},
		"IMEI":          []string{b.IMEI},
		"SessionId":     []string{sessionId},
		"channelCode":   []string{"303"},
		"clientIp":      []string{b.ClientIP},
		"encryptedData": []string{encryptedData},
		"s1":            []string{s1},
		"signData":      []string{signData},
		"tranCode":      []string{"A00044"},
		"userPhoto":     []string{fmt.Sprintf("%X", enData)},
	}

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("checkFaceInfoNew req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("checkFaceInfoNew DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("checkFaceInfoNew json.Unmarshal resp err=%+v", err)
	}
	return respObj
}

// 写刷脸日志的
func (b *Bank) writeLog(faceRes *checkFaceInfoNewRes, encryptedData, signData, sessionId string) string {

	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlAsynGetDataServlet) + " wkwebview:true"

	faceResBytes, _ := json.Marshal(faceRes)

	body := url.Values{
		"SessionId":           {sessionId},
		"result":              {string(faceResBytes)},
		"tranFlag":            {"3"},
		"TranErrorCode":       {faceRes.TranErrorCode},
		"TranErrorDisplayMsg": {faceRes.TranErrorDisplayMsg},
		"ua":                  {b.userAgent(urlAsynGetDataServlet)},
		"encryptedData":       {encryptedData},
		"signData":            {signData},
		"logType":             {"1"},
		"tranCode":            {"A00040"},
	}

	header := &http.Header{
		headers.Accept:         {"application/json, text/javascript, */*; q=0.01"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("writeLog req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("writeLog DoHTTPPostForm err=%+v", err)
	}

	return string(resp)
}

func (b *Bank) faceRecognitionTranLink(tranFlagFirst, tranFlagNewFace, dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_InterveneOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlagFirst":     {tranFlagFirst},
		"tranFlagNewFace":   {tranFlagNewFace},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("faceRecognitionTranLink1 req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("faceRecognitionTranLink1 DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 提交支付密码
func (b *Bank) submitPayPwd(accountIndex, account, randomId, sessionId, dseSessionId string) *bandRes {
	respObj := &bandRes{}

	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlAsynGetDataServlet) + " wkwebview:true"

	s := newSafeInput()
	pwdRule := s.initRules()
	pwdChangeRule := s.initChangeRules() + "#0"
	mapCode := s.mappingCode(b.PayPwd)
	enPwd := s.getRsaCode(mapCode)
	body := url.Values{
		"dse_sessionId":        {dseSessionId},
		"SessionId":            {sessionId},
		"dse_applicationId":    {"-1"},
		"dse_operationName":    {"epass_InterveneOp"},
		"dse_pageId":           {b.dsePageId},
		"tranFlagCard":         {"1"},
		"tranFlagFirst":        {"1"},
		"tranCode":             {"A00035"},
		"randomId":             {randomId},
		"AccountCovered":       {account},
		"regCardNoTmpzero":     {accountIndex},
		"regCardPwdTmp":        {"......"},
		"regCardPwdChangeRule": {pwdChangeRule},
		"regCardPwdRule":       {pwdRule},
		"regCardPwd":           {enPwd},
	}

	header := &http.Header{
		headers.Accept:         {"application/json, text/javascript, */*; q=0.01"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("submitPayPwd req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("submitPayPwd DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("submitPayPwd json.Unmarshal err=%+v", err)
	}

	return respObj
}

// 网页也要提交一下
func (b *Bank) successForm(dseSessionId, randomId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_InterveneOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlagCard":      {"2"},
		"tranFlagFirst":     {"1"},
		"tranCode":          {"A00035"},
		"randomId":          {randomId},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("successForm req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("successForm DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 网页又要确认绑定
func (b *Bank) bd002succ(dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_RemitMenuBindOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlag":          {"19"},
		"Language":          {"zh_CN"},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("bd002succ req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("bd002succ DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

func (b *Bank) submitBind_M(sessionId, dseSessionId string) *sendSmsRes {
	respObj := &sendSmsRes{}

	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlAsynGetDataServlet) + " wkwebview:true"

	body := url.Values{
		"SessionId":     {sessionId},
		"dse_sessionId": {dseSessionId},
		"tranFlag":      {"3"},
		"tranCode":      {"A00011"},
		"recodeOper":    {"1"},
		"deviceName_in": {b.OwnerName},
	}

	header := &http.Header{
		headers.Accept:         {"application/json, text/javascript, */*; q=0.01"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("submitBind_M req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("submitBind_M DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("submitBind_M json.Unmarshal resp err=%+v", err)
	}

	return respObj
}

func (b *Bank) submitAuto(dseSessionId string) string {
	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"dse_sessionId":     {dseSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"epass_RemitMenuBindOp"},
		"dse_pageId":        {b.dsePageId},
		"tranFlag":          {"6"},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	header := &http.Header{
		headers.Accept:         {"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlICBCINBSReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("bd002succ req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("bd002succ DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 页面签退
func (b *Bank) signoff(sessionId, dseSessionId string) *signoffRes {
	respObj := &signoffRes{}

	ua := "ICBCiPhone " + b.userAgentBSIOSAndWebview(urlICBCINBSReqServlet) + " wkwebview:true"

	body := url.Values{
		"SessionId":     {sessionId},
		"dse_sessionId": {dseSessionId},
		"tranCode":      {"A00006"},
	}

	header := &http.Header{
		headers.Accept:         {"application/json, text/javascript, */*; q=0.01"},
		headers.UserAgent:      {ua},
		headers.AcceptLanguage: {"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: {"gzip, deflate, br"},
		headers.XRequestedWith: {"XMLHttpRequest"},
		headers.Origin:         {"https://epass.icbc.com.cn"},
		headers.Referer:        {"https://epass.icbc.com.cn/servlet/ICBCINBSReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlAsynGetDataServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("signoff req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("signoff DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("signoff json.Unmarshal resp err=%+v", err)
	}

	return respObj
}

// 将登陆的返回的数据再次提交上去,获取到dse_sessionId
func (b *Bank) handleLoginResponseData(encryptedData, signData string) *XMLBODY {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"IMEI":                b.IMEI,
		"deviceName":          b.OwnerName,
		"encryptedDataToApp":  url.QueryEscape(encryptedData),
		"epassFlag":           "2",
		"fullversion":         newVersion,
		"iPhoneClientVersion": wapVersion,
		"inUdid":              inUDID,
		"in_appVersion":       cfBundleVersion,
		"in_clientMemory":     b.PhysicalMemory,
		"in_deviceId":         b.IMEI,
		"in_deviceNum":        b.IMEI,
		"in_factoryInfo":      tools.PhoneName(b.Model),
		"in_isRoot":           "false",
		"in_osLanguage":       "zh-Hans-CN",
		"in_osVersion":        "iOS" + b.SystemVersion,
		"in_paramDev":         "001099599909995", // 越狱 流量方式 代理 反调试检测
		"in_scResolution":     url.QueryEscape(tools.ScreenPt(b.Model)),
		"in_wifiSSID":         "",
		"lifeAreaCode":        "0",
		"loginId":             b.Account,
		"netType":             "33",
		"newversion":          newVersion,
		"shareLastUUID":       "",
		"signDataToApp":       url.QueryEscape(signData),
		"token":               "iPhone",
		"wapbtestFLag":        "0",
	}, wap3desKey)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPEstablishSessionServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("handleLoginResponseData req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("handleLoginResponseData DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("handleLoginResponseData xml.Unmarshal resp err=%+v", err)
	}
	return respObj
}

func (b *Bank) loginTokenManager() *XMLBODY {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"description":       url.QueryEscape("获取免登录token的请求"),
		"dse_applicationId": "-1",
		"dse_deviceId":      b.IMEI,
		"dse_operationName": "clientNew_LoginTokenManagerOp",
		"dse_pageId":        "1",
		"opName":            "clientNew_LoginTokenManagerOp",
		"origTokenID":       "",
		"tranFlag":          "0",
		"wapVersion":        "3",
	}, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("loginTokenManager req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("loginTokenManager DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("loginTokenManager xml.Unmarshal resp err=%+v", err)
	}

	return respObj
}

func (b *Bank) cardList() *XMLBODY {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"dse_applicationId": "-1",
		"dse_operationName": "clientNew_AccountQueryCheckBalanceOp",
		"dse_pageId":        "5",
		"myAcctCTypeFlag":   "1",
		"pageFlag":          "0",
		"wapVersion":        "3",
	}, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("cardList req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("cardList DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("cardList xml.Unmarshal resp err=%+v", err)
	}

	return respObj
}

// 最近一个月
func (b *Bank) billListRecent(cardNo, cardType, cardTypeDesc, areaCode, areaName string, pageId int, refreshMoreUrl string) (*XMLBODY, int) {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	if pageId == 0 {
		pageId = 7
	} else {
		pageId++
	}

	body1 := map[string]string{
		"acctCodeTmp":       "0",
		"areaCode":          areaCode, // "1109"
		"beFlag":            "0",
		"cardAlias":         "",
		"cardNumTmp":        cardNo,
		"cardTypeShow":      url.QueryEscape(fmt.Sprintf("%s %s", areaName, cardTypeDesc)), // 借记卡(Ⅰ类)
		"cardTypeTmp":       cardType,                                                      // 011
		"controller":        "2",
		"currTypeTmp":       "001", // 人民币
		"dse_applicationId": "-1",
		"dse_operationName": "clientNew_AccountQueryHisDetailForClientOp",
		"dse_pageId":        fmt.Sprintf("%d", pageId),
		"flashCardFlag":     "0",
		"isFromBalance":     "0",
		"myAcctInjectFlag":  "1",
		"wapVersion":        "3",
	}

	if refreshMoreUrl != "" {
		values, _ := url.ParseQuery(refreshMoreUrl)
		for k := range values {
			body1[k] = values.Get(k)
		}
	}

	body := encryptMaps(body1, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("billListRecent req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("billListRecent DoHTTPPostForm err=%+v", err)
		return respObj, pageId
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("cardList xml.Unmarshal resp err=%+v", err)
	}

	return respObj, pageId
}

// 必须先掉用最近一个月账单
func (b *Bank) billList(cardNo, cardType, cardTypeDesc, startTime, endTime string, pageId int, refreshMoreUrl string) (*XMLBODY, int) {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	if pageId == 0 {
		pageId = tools.RandBetween(15, 25)
	} else {
		pageId++
	}

	body1 := map[string]string{
		"acctAlias":         "null",
		"acctTypeTmp":       "",
		"areaCode":          "0",
		"beFlag":            "0",
		"cardAlias":         "",
		"cardNum":           cardNo,
		"cardNumTmp":        cardNo,
		"cardTypeShow":      url.QueryEscape(cardTypeDesc), // 借记卡(Ⅰ类)
		"cardTypeTmp":       cardType,                      // 011
		"controller":        "10",
		"dateEndTmp":        endTime,   // 20201109
		"dateStartTmp":      startTime, // 20210309
		"dse_applicationId": "-1",
		"dse_operationName": "clientNew_AccountQueryHisDetailForClientOp",
		"dse_pageId":        fmt.Sprintf("%d", pageId),
		"firstFlag":         "1",
		"flashCardFlag":     "0",
		"isAcct":            "0",
		"isFromMore":        "1",
		"isNewCheck":        "1",
		"moreSearchFlag":    "1",
		"myAcctInjectFlag":  "1",
		"returnFlag":        "0",
		"selectTypeTmp":     "0",
		"wapVersion":        "3",
		"acctCodeTmp":       "0",
		"acctTypeName":      url.QueryEscape("工银借记卡"),
	}

	if refreshMoreUrl != "" {
		values, _ := url.ParseQuery(refreshMoreUrl)
		for k := range values {
			body1[k] = values.Get(k)
		}
	}

	body := encryptMaps(body1, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("billList req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("billList DoHTTPPostForm err=%+v", err)
		return respObj, pageId
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("cardList xml.Unmarshal resp err=%+v", err)
	}

	return respObj, pageId
}

// 获取转账开始的 dse_sessionId
func (b *Bank) getTransferSessionID() *XMLBODY {
	respObj := &XMLBODY{}

	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"dse_applicationId": "-1",
		"dse_operationName": "clientNew_logonProcessNoSessionOp",
		"dse_pageId":        "-1",
		"mimsCISNo":         b.CISNo,
		"mimsMsgSwitch":     "1",
		"mimsUserId":        b.UserId,
		"wapVersion":        "3",
	}, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("getTransferSessionID req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("getTransferSessionID DoHTTPPostForm err=%+v", err)
		return respObj
	}

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("getTransferSessionID xml.Unmarshal resp err=%+v", err)
	}

	return respObj
}

func (b *Bank) getServerParam() string {
	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"dse_applicationId": "-1",
		"dse_pageId":        "1",
		"paramSeq":          tools.TimeFmt(),
		"paramType":         "1",
		"wapVersion":        "3",
	}, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPGetServerParamServlet, nil, header, []byte(body.Encode()))
	//b.logger.Infof("gotoTransferHistory req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("getServerParam DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

func (b *Bank) handleUserInfo(areaCode string) string {
	ua := b.userAgentWap()

	body := encryptMaps(map[string]string{
		"dse_applicationId":        "-1",
		"dse_operationName":        "client_HandleUserInfoOp",
		"dse_pageId":               "2",
		"hasBrokenRedEnvelopCount": "0",
		"in_ADV_AREACODE":          areaCode,
		"token":                    "updateadv",
		"tranFlag":                 "13",
		"wapVersion":               "3",
	}, b.dseSessionId[:0x18])
	body.Set("dse_sessionId", b.dseSessionId)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	//b.logger.Infof("gotoTransferHistory req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("getServerParam DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 点击转账，进入最近转账选择的html页面
func (b *Bank) gotoTransferHistory(desSessionId string) string {
	ua := b.userAgentWapIOS()

	body := url.Values{
		"dse_operationName": {"clientNew_RemitAllOp"},
		"dse_applicationId": {"-1"},
		"pageMark":          {"100"},
		"dse_sessionId":     {desSessionId},
		"dse_pageId":        {"4"},
		"wapVersion":        {"3"},
		"isEasyRemitFlag":   {"1"},
		"NativeFlag":        {"1"},
	}

	header := &http.Header{
		headers.Accept:         []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		headers.Origin:         []string{"null"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	//b.logger.Infof("gotoTransferHistory req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("gotoTransferHistory DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 点击境内转账
func (b *Bank) gotoTransfer(desSessionId string) string {
	ua := b.userAgentWapIOS()

	body := url.Values{
		"NativeFlag":        {"1"},
		"needBackFlag":      {"1"},
		"wapVersion":        {"3"},
		"dse_sessionId":     {desSessionId},
		"bindVerifyFlag":    {"1"},
		"isFromMenu":        {"1"},
		"dse_pageId":        {"4"},
		"dse_operationName": {"clientNew_RemitAllOp"},
		"dse_applicationId": {"-1"},
		"unbindVerifyFlag":  {"1"},
	}

	header := &http.Header{
		headers.Accept:         []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	//b.logger.Infof("gotoTransferHistory req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("gotoTransferHistory DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

// 查询卡余额
func (b *Bank) balance(srcCardNo, cardType, desSessionId string) *balanceRes {
	respObj := &balanceRes{}

	ua := b.userAgentWapIOS()

	random := fmt.Sprintf("%d", tools.RandBetween(10000, 100000))
	key := aesKey + random

	payCardNumtmp := base64.StdEncoding.EncodeToString(tools.AESCBCEncrypt([]byte(srcCardNo), []byte(key), []byte(key)))

	body := url.Values{
		"dse_sessionId":          {desSessionId},
		"dse_applicationId":      {"-1"},
		"dse_operationName":      {"clientNew_RemitAllOp"},
		"dse_pageId":             {b.dsePageId},
		"wapVersion":             {"3"},
		"wapAppServerid":         {"wapapp_153"},
		"pageMark":               {"3"},
		"payCardNumtmp":          {payCardNumtmp},
		"acctCodeTmp":            {""},
		"currTypeTmp":            {"001"},
		"cashSignTmp":            {"0"},
		"outAcctTypeTmp":         {cardType}, // 011
		"outAcctNumTmp":          {""},
		"_encrypt_payCardNumtmp": {""},
		"_encrypt_params":        {fmt.Sprintf("%s|payCardNumtmp", random)},
	}

	header := &http.Header{
		headers.Accept:          []string{"*/*"},
		headers.UserAgent:       []string{ua},
		headers.AcceptLanguage:  []string{"zh-cn"},
		headers.AcceptEncoding:  []string{"gzip, deflate, br"},
		headers.CacheControl:    {"no-cache"},
		headers.XRequestedWith:  {"XMLHttpRequest"},
		"X-ICBC-Channel-Client": {"AsyncRequest"},
		headers.Origin:          {"https://mywap2.icbc.com.cn"},
		headers.Referer:         {"https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("balance req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("balance DoHTTPPostForm err=%+v", err)
		return respObj
	}

	respStr := string(resp)
	respStr = strings.ReplaceAll(respStr, "\"", "\\\"")
	respStr = strings.ReplaceAll(respStr, "'", "\"")
	err = json.Unmarshal([]byte(respStr), respObj)
	if err != nil {
		b.logger.Errorf("searchBank json.Unmarshal err=%+v", err)
	}

	return respObj
}

// 查询银行
func (b *Bank) searchBank(destCardNo, destName, desSessionId string) *searchBankRes {
	respObj := &searchBankRes{}

	ua := b.userAgentWapIOS()

	body := url.Values{
		"dse_sessionId":     {desSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"clientNew_RemitAllOp"},
		"dse_pageId":        {b.dsePageId},
		"wapVersion":        {"3"},
		"wapAppServerid":    {"wapapp_153"},
		"pageMark":          {"2"},
		"recAccttmp":        {destCardNo},
		"recNametmp":        {destName},
		"appointBankCode":   {""},
		"appointNetCode":    {""},
	}

	header := &http.Header{
		headers.Accept:          []string{"*/*"},
		headers.UserAgent:       []string{ua},
		headers.AcceptLanguage:  []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding:  []string{"gzip, deflate, br"},
		headers.CacheControl:    {"no-cache"},
		headers.XRequestedWith:  {"XMLHttpRequest"},
		"X-ICBC-Channel-Client": {"AsyncRequest"},
		headers.Origin:          {"https://mywap2.icbc.com.cn"},
		headers.Referer:         {"https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("searchBank req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("searchBank DoHTTPPostForm err=%+v", err)
		return respObj
	}

	respStr := string(resp)
	respStr = strings.ReplaceAll(respStr, "\"", "\\\"")
	respStr = strings.ReplaceAll(respStr, "'", "\"")
	err = json.Unmarshal([]byte(respStr), respObj)
	if err != nil {
		b.logger.Errorf("searchBank json.Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) remit(isSameBank bool, srcCardNo, srcCardType, destCardNo, destName, bankName, bankFullCode, bankCode, amount, remark, desSessionId string) *remitRes {
	respObj := &remitRes{}

	ua := b.userAgentWapIOS()

	random := fmt.Sprintf("%d", tools.RandBetween(10000, 100000))
	key := aesKey + random

	destCardtmp := base64.StdEncoding.EncodeToString(tools.AESCBCEncrypt([]byte(destCardNo), []byte(key), []byte(key)))
	destCardNoDis := ""
	for i := 0; i < len(destCardNo); i += 4 {
		next := i + 4
		if next >= len(destCardNo) {
			destCardNoDis = destCardNoDis + " " + destCardNo[i:]
		} else {
			destCardNoDis = destCardNoDis + " " + destCardNo[i:next]
		}
	}
	destCardNoDis = destCardNoDis[1:]

	amountNum, _ := strconv.ParseFloat(amount, 32)

	injectPageInfo := map[string]interface{}{
		"payeeInfo": map[string]interface{}{
			"payeeBankInfo": map[string]string{
				"payeeBankCode":     bankCode,
				"payeeBankName":     bankName,
				"payeeBankNameShow": "",
				"payeeNetCode":      bankFullCode,
				"payeeNetName":      "",
			},
			"aliasBindFlag": "",
			"payeeName":     destName,
			"payeeAcct":     destCardNo,
			"aliasBindAcct": "",
		},
		"remitInfo": map[string]interface{}{
			"isSendSMS":     "0",
			"remitAmt":      int(amountNum * 100),
			"reMark":        remark,
			"remitTimeType": "0",
			"MoreInfoFlag":  "1",
			"recSMSMobile":  "",
		},
		"payInfo": map[string]string{
			"payCardNum": srcCardNo,
		},
		"injectInfo": map[string]string{},
		"appointmentInfo": map[string]string{
			"appointmentDate":        "",
			"appointmentExpireDate":  "",
			"appoinmentFrequence":    "",
			"appoinmentType":         "",
			"normalOrBooking":        "0",
			"remitAppointmentModify": "",
			"appointmentDIYTypeName": "",
		},
	}

	injectPageInfoJsonData, _ := json.Marshal(injectPageInfo)

	body := url.Values{
		"dse_sessionId":                  {desSessionId},
		"dse_applicationId":              {"-1"},
		"dse_pageId":                     {b.dsePageId},
		"wapVersion":                     {"3"},
		"wapAppServerid":                 {"wapapp_153"},
		"sixRemitType":                   {"2"},
		"inPrice":                        {amount}, // 0.30
		"clientBindJsonValuetmp":         {""},
		"oldDeviceIdTmp":                 {""},
		"newDeviceIdTmp":                 {b.IMEI},
		"clientCisNumTmp":                {""},
		"deviceNameTmp":                  {b.OwnerName},
		"remitRectimeType":               {"0"},
		"fingerPrintFlagFromDev":         {"1"},
		"fingerStateFromDev":             {"0"},
		"lng":                            {""},
		"lat":                            {""},
		"RMA_province":                   {""},
		"RMA_city":                       {""},
		"isFromMenu":                     {"1"},
		"injectPageInfoJsonData":         {url.QueryEscape(string(injectPageInfoJsonData))},
		"remitAppointmentDateTmp":        {""},
		"remitAppointmentExpireTmp":      {""},
		"remitAppointmentFrequencyTmp":   {""},
		"remitAppointmentTypeTmp":        {""},
		"normalOrBookingTmp":             {"0"},
		"remitAppointmentModifyTmp":      {""},
		"remitAppointmentDIYTypeNameTmp": {""},
		"remitallAppointmentFlagTmp":     {"1"},
		"currTypeTmp":                    {"001"},
		"cashSignTmp":                    {"0"},
		"remarkTmp":                      {remark},
	}

	if !isSameBank {
		body.Set("dse_operationName", "clientNew_RemitQuickEtransOp")
		body.Set("pageMark", "4")
		body.Set("pageFlag", "1")
		body.Set("addFlag", "0")
		body.Set("recNametmp1", "0")
		body.Set("recAccttmp1", "0")
		body.Set("electAcctFlagtmp", "0")
		body.Set("fromRemitAllFlagtmp", "1")
		body.Set("appFlag", "1")
		body.Set("labelFlagTmp", "1")
		body.Set("txtusage", "2")
		body.Set("PayeeaddrNumtmp", bankFullCode) // 103100000026
		body.Set("Payeeaddrtmp", "")
		body.Set("payeeBranchNametmp", bankName) // 中国农业银行股份有限公司
		body.Set("payeeBranchTypetmp", bankCode) // 103
		body.Set("recMobile", "")
		body.Set("isSendSMSTmp", "0")
		body.Set("acctType1", srcCardType)                                // 011
		body.Set("bankInfos", fmt.Sprintf("%s|%s|1", bankName, bankCode)) // 中国农业银行股份有限公司|103|1
		body.Set("devicehardidtmp", b.IMEI)
		body.Set("bankInfos2", fmt.Sprintf("%s|%s|1", bankName, bankCode)) // 中国农业银行股份有限公司|103|1
		body.Set("branchInfos", "|")
		body.Set("fromAlertFlag", "1")
		body.Set("Payee_Num", bankFullCode)
		body.Set("Rec_Type_branchNo", bankCode)
		body.Set("Rcevpoint", bankFullCode)
		body.Set("singleSignOn", "1")
		body.Set("wapEPayFlagTmp", "")
		body.Set("RenBankCardFlag", "0")
		body.Set("recAccttmp", destCardtmp)
		body.Set("mobileAliasFlag4UP", "")
		body.Set("mobileAlias4UP", "")
		body.Set("recNametmp", destName)
		body.Set("recAccttmpDis", destCardNoDis)
		body.Set("receiveBank", "")
		body.Set("inPriceTmp", amount)
		body.Set("payCardNumtmp", srcCardNo)
		body.Set("recMobileTmp", "")
		body.Set("_encrypt_recAccttmp", "")
		body.Set("_encrypt_params", fmt.Sprintf("%s|recAccttmp", random))
	} else {
		body.Set("dse_operationName", "clientNew_RemitEtransOp")
		body.Set("nextMedium", "-1")
		body.Set("checkOneClickFlag", "1")
		body.Set("pageMark", "1")
		body.Set("notice", "")
		body.Set("noticeflag", "")
		body.Set("isSendSMSForBack", "0")
		body.Set("outRegModeTmp", "0")
		body.Set("outEPayFlagTmp", "0")
		body.Set("selectedAuthenTypeTmp", "")
		body.Set("recAcctNumPrefix", destCardNo)
		body.Set("recAcctNumForValidate", destCardNo)
		body.Set("prefixFTFlag", "")
		body.Set("usageTmp", "")
		body.Set("deviceIdInput", b.IMEI)
		body.Set("recAcctName", destName)
		body.Set("recAcctNum", destCardNo)
		body.Set("usageSelectTmp", "")
		body.Set("usageInput", "")
		body.Set("useOfFundsTmp", "")
		body.Set("payCardNum", srcCardNo)
		body.Set("recMobileForBack", "undefined")
		body.Set("remitAllFlag", "1")
	}

	header := &http.Header{
		headers.Accept:          []string{"*/*"},
		headers.UserAgent:       []string{ua},
		headers.AcceptLanguage:  []string{"zh-cn"},
		headers.AcceptEncoding:  []string{"gzip, deflate, br"},
		headers.CacheControl:    {"no-cache"},
		headers.XRequestedWith:  {"XMLHttpRequest"},
		"X-ICBC-Channel-Client": {"AsyncRequest"},
		headers.Origin:          {"https://mywap2.icbc.com.cn"},
		headers.Referer:         {"https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("remit req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("remit DoHTTPPostForm err=%+v", err)
		return respObj
	}

	respStr := string(resp)
	index1 := strings.Index(respStr, `name="dse_sessionId"`)
	index2 := strings.Index(respStr, `"',`)
	if index1 != -1 && index2 != -1 {
		respStr = respStr[:index1] + respStr[index2+1:]
	}
	index3 := strings.Index(respStr, `'<div`)
	index4 := strings.Index(respStr, `/div>'`)
	if index3 != -1 && index4 != -1 {
		respStr = respStr[:index3+1] + respStr[index4+5:]
	}
	index5 := strings.Index(respStr, `='sendNo'`)
	if index5 != -1 {
		respStr = respStr[:index5] + respStr[index5+9:]
	}
	respStr = strings.ReplaceAll(respStr, "'", "\"")
	err = json.Unmarshal([]byte(respStr), respObj)
	if err != nil {
		b.logger.Errorf("remit json.Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) verifyEpayPassword(desSessionId string) *verifyEpayPasswordRes {
	respObj := &verifyEpayPasswordRes{}

	ua := fmt.Sprintf("ICBCiPhoneBSNew F-ePass %s ICBCiPhone BSComponentVersion:%s %s %s %s wifi %s",
		"6.1", "6.1", b.Model, b.SystemVersion, b.IMEI, b.userAgentWapIOS())

	// 交易密码加密
	s := newSafeInput()
	pwdRule := s.initRules()
	pwdChangeRule := s.initChangeRules() + "#0"
	mapCode := s.mappingCode(b.PayPwd)
	enPwd := s.getRsaCode(mapCode)

	s1 := tools.RandBetween(100000000, 10000000000)
	tmp := md5.Sum([]byte(fmt.Sprintf("%d%s%s", s1, b.EbdpUUID, clientSecret)))
	key1 := append(tmp[:], tmp[:0x8]...)
	tmp = md5.Sum([]byte(fmt.Sprintf("1918156293%s", clientSecret)))
	key2 := append(tmp[:], tmp[:0x8]...)

	data := url.Values{
		"dse_sessionId":        {desSessionId},
		"dse_applicationId":    {"-1"},
		"dse_operationName":    {"clientNew_EPayQuickPayOperatorOp"},
		"dse_pageId":           {b.dsePageId},
		"wapVersion":           {"3"},
		"retDataType":          {"1"},
		"wapAppServerid":       {"wapapp_153"},
		"pageMark":             {"0"},
		"ebdp_encryptResponse": {"1"},
		"deviceHardId":         {b.IMEI},
		"cisNum":               {b.CISNo},
		"adduviflag":           {""},
		"additionuvi":          {""},
		"epayMobile":           {b.Account},
		"deviceName":           {b.OwnerName},
		"crule":                {pwdChangeRule},
		"rule":                 {pwdRule},
		"epayStaticPwd":        {enPwd},
	}

	encryptData, _ := tools.TripleDESECBEncrypt([]byte(data.Encode()), key1)
	b64encryptData := base64.StdEncoding.EncodeToString(encryptData)
	encryptS1, _ := tools.TripleDESECBEncrypt([]byte(fmt.Sprintf("%d", s1)), key2)
	b64encryptS1 := base64.StdEncoding.EncodeToString(encryptS1)
	encryptDid, _ := tools.TripleDESECBEncrypt([]byte(b.EbdpUUID), key2)
	b64encryptDid := base64.StdEncoding.EncodeToString(encryptDid)
	b64appId := base64.StdEncoding.EncodeToString([]byte("F-WAPB161536"))

	body := encryptMaps(map[string]string{
		"ebdp_nst":           "1",
		"ebdp_encryptS1":     url.QueryEscape(b64encryptS1),
		"ebdp_encryptDid":    url.QueryEscape(b64encryptDid),
		"ebdp_appIdEnc":      url.QueryEscape(b64appId),
		"ebdp_K1encryptData": url.QueryEscape(b64encryptData),
	}, wap3desKey)

	header := &http.Header{
		headers.Accept:         []string{"*/*"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		"X-ICBC-Locale":        []string{"zh_CN"},
		"X-ICBC-Language":      []string{"zh-Hans-CN"},
		"X-ICBC-Channel":       []string{"iPhone"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlEBDPWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("verifyEpayPassword req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("verifyEpayPassword DoHTTPPostForm err=%+v", err)
		return respObj
	}

	respStr := string(resp)
	respStr = strings.TrimSpace(respStr)
	if strings.Contains(respStr, "ebdp_encrypted") {
		respStr = strings.ReplaceAll(respStr, "ebdp_encrypted", "")
		resp, _ = base64.StdEncoding.DecodeString(respStr)
		// 解密
		resp, _ = tools.TripleDESECBDecrypt(resp, key1)

		err = json.Unmarshal(resp, respObj)
		if err != nil {
			b.logger.Errorf("verifyEpayPassword json.Unmarshal err=%+v", err)
		}
	}
	return respObj
}

// 再一次提交 返回下一步验证的信息
func (b *Bank) remit2(isSameBank bool, tranTime, desSessionId string) *remitRes {
	respObj := &remitRes{}

	ua := b.userAgentWapIOS()

	body := url.Values{
		"dse_sessionId":            {desSessionId},
		"dse_applicationId":        {"-1"},
		"dse_pageId":               {"7"},
		"wapVersion":               {"3"},
		"wapAppServerid":           {"wapapp_153"},
		"faceCheckTranDataForSign": {""},
	}

	if !isSameBank {
		body.Set("dse_operationName", "clientNew_RemitQuickEtransOp")
		body.Set("pageMark", "16")
		body.Set("tranTimetemp", tranTime)
		body.Set("labelFlag", "")
		body.Set("commission", "")
		body.Set("mqflagD", "")
		body.Set("oneclickType4LogTemp", "")
	} else {
		body.Set("dse_operationName", "clientNew_RemitEtransOp")
		body.Set("pageMark", "98")
	}

	header := &http.Header{
		headers.Accept:          []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:       []string{ua},
		headers.AcceptLanguage:  []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding:  []string{"gzip, deflate, br"},
		headers.CacheControl:    {"no-cache"},
		headers.XRequestedWith:  {"XMLHttpRequest"},
		"X-ICBC-Channel-Client": {"AsyncRequest"},
		headers.Origin:          {"https://mywap2.icbc.com.cn"},
		headers.Referer:         {"https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("remit2 req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("remit2 DoHTTPPostForm err=%+v", err)
		return respObj
	}

	respStr := string(resp)
	index1 := strings.Index(respStr, `name="dse_sessionId"`)
	index2 := strings.Index(respStr, `"',`)
	if index1 != -1 && index2 != -1 {
		respStr = respStr[:index1] + respStr[index2+1:]
	}
	index3 := strings.Index(respStr, `'<div`)
	index4 := strings.Index(respStr, `/div>'`)
	if index3 != -1 && index4 != -1 {
		respStr = respStr[:index3+1] + respStr[index4+5:]
	}
	index5 := strings.Index(respStr, `='epayNo'`)
	if index5 != -1 {
		respStr = respStr[:index5] + respStr[index5+9:]
	}
	respStr = strings.ReplaceAll(respStr, "'", "\"")
	err = json.Unmarshal([]byte(respStr), respObj)
	if err != nil {
		b.logger.Errorf("remit2 json.Unmarshal err=%+v", err)
	}

	return respObj
}

// 验证验证码
func (b *Bank) verifyEpayPassInput(isSameBank bool, smsCode, tranTime, randomID, verifyCode, desSessionId string) string {
	if len(smsCode) != 6 {
		b.logger.Errorf("短信位数不正确, smsCode=%s", smsCode)
		return ""
	}
	ua := b.userAgentWapIOS()

	random := fmt.Sprintf("%d", tools.RandBetween(10000, 100000))
	key := aesKey + random

	ePayPassInput := base64.StdEncoding.EncodeToString(tools.AESCBCEncrypt([]byte(smsCode), []byte(key), []byte(key)))

	body := url.Values{
		"dse_sessionId":             {desSessionId},
		"dse_applicationId":         {"-1"},
		"dse_pageId":                {b.dsePageId},
		"wapVersion":                {"3"},
		"wapAppServerid":            {"wapapp_153"},
		"faceCheckTranDataForSign":  {""},
		"ePayPassInputNAD":          {ePayPassInput},
		"undefined":                 {"undefined"},
		"_encrypt_payCardNumtmp":    {""},
		"NativeFlag":                {"0"},
		"_encrypt_ePayPassInputNAD": {""},
		"_encrypt_params":           {fmt.Sprintf("%s|ePayPassInputNAD", random)},
		"multiWebView":              {"1"},
		"_PVprodcode":               {""},
		"_PVdataSource":             {""},
		"_PVactivityNO":             {""},
		"searchWordPV":              {""},
		"searchChannelPV":           {""},
		"filterWordPV":              {""},
	}
	if !isSameBank {
		body.Set("dse_operationName", "clientNew_RemitQuickEtransOp")
		body.Set("pageMark", "6")
		body.Set("tranTimetemp", tranTime)
		body.Set("labelFlag", "")
		body.Set("commission", "")
		body.Set("mqflagD", "")
	} else {
		body.Set("dse_operationName", "clientNew_RemitEtransOp")
		body.Set("randomId", randomID)
		body.Set("verifyCode", verifyCode)
		body.Set("pageMark", "7")
		body.Set("savepayeeSign", "1")
		body.Set("Time", tranTime)
		body.Set("recAcctNum", "")
		body.Set("inPrice", "")
		body.Set("oneclickType4LogTemp", "")
	}

	header := &http.Header{
		headers.Accept:         []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		headers.Origin:         {"null"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("verifyEpayPassInput req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("verifyEpayPassInput DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

func (b *Bank) query01(isSameBank bool, tranTime, randomID, verifyCode, desSessionId string) string {

	ua := b.userAgentWapIOS()

	body := url.Values{
		"dse_sessionId":            {desSessionId},
		"dse_applicationId":        {"-1"},
		"dse_pageId":               {b.dsePageId},
		"wapVersion":               {"3"},
		"wapAppServerid":           {"wapapp_153"},
		"faceCheckTranDataForSign": {""},
		"NativeFlag":               {"0"},
		"multiWebView":             {"1"},
		"_PVprodcode":              {""},
		"_PVprodname":              {""},
		"_PVdataSource":            {""},
		"_PVactivityNO":            {""},
		"searchWordPV":             {""},
		"searchChannelPV":          {""},
		"filterWordPV":             {""},
	}
	if !isSameBank {
		body.Set("dse_operationName", "clientNew_RemitQuickEtransOp")
		body.Set("pageMark", "6")
		body.Set("tranTimetemp", tranTime)
		body.Set("labelFlag", "")
		body.Set("commission", "")
		body.Set("mqflagD", "")
	} else {
		body.Set("dse_operationName", "clientNew_RemitEtransOp")
		body.Set("randomId", randomID)
		body.Set("verifyCode", verifyCode)
		body.Set("pageMark", "7")
		body.Set("savepayeeSign", "1")
		body.Set("Time", tranTime)
		body.Set("recAcctNum", "")
		body.Set("inPrice", "")
		body.Set("oneclickType4LogTemp", "")
	}

	header := &http.Header{
		headers.Accept:         []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		headers.Origin:         {"null"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("query01 req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("query01 DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}

func (b *Bank) query02(isSameBank bool, count int, desSessionId string) string {

	ua := b.userAgentWapIOS()

	body := url.Values{
		"dse_sessionId":     {desSessionId},
		"dse_applicationId": {"-1"},
		"dse_operationName": {"clientNew_RemitQuickEtransOp"},
		"dse_pageId":        {b.dsePageId},
		"wapVersion":        {"3"},
		"wapAppServerid":    {"wapapp_153"},
		"pageMark":          {"13"},
		"count":             {fmt.Sprintf("%d", count)},
		"submit":            {"ICBCSubmit"},
		"NativeFlag":        {"0"},
	}

	if isSameBank {
		body.Set("dse_operationName", "clientNew_RemitEtransOp")
	}

	header := &http.Header{
		headers.Accept:         []string{"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
		headers.UserAgent:      []string{ua},
		headers.AcceptLanguage: []string{"zh-Hans-CN;q=1"},
		headers.AcceptEncoding: []string{"gzip, deflate, br"},
		headers.Origin:         {"https://mywap2.icbc.com.cn"},
		headers.Referer:        {"https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/WAPReqServlet"},
	}

	resp, err := tools.DoHTTPPostForm(b.c, urlWAPReqServlet, nil, header, []byte(body.Encode()))
	b.logger.Infof("query02 req:%s \r\n resp:%s", body.Encode(), string(resp))
	if err != nil {
		b.logger.Errorf("query02 DoHTTPPostForm err=%+v", err)
		return ""
	}

	return string(resp)
}
