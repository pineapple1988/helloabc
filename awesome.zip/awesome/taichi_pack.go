package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"time"
)

// IsDir 判断所给路径是否为文件夹
func IsDir(path string) bool {
	s, err := os.Stat(path)
	if err != nil {
		return false
	}
	return s.IsDir()
}

// Exists 判断所给路径文件/文件夹是否存在
func Exists(path string) bool {
	_, err := os.Stat(path)
	if err != nil {
		if os.IsExist(err) {
			return true
		}
		return false
	}
	return true
}

func execCommand(commandName string, params []string) bool {
	cmd := exec.Command(commandName, params...)
	fmt.Println(cmd.Args)

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		fmt.Println(err)
		return false
	}

	cmd.Start()
	in := bufio.NewScanner(stdout)
	for in.Scan() {
		fmt.Println(in.Text())
	}

	cmd.Wait()
	cmd.Wait()
	return true
}

func execCommandWithInput(commandName string, input string, params []string) bool {
	cmd := exec.Command(commandName, params...)
	fmt.Println(cmd.Args)

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		fmt.Println(err)
		return false
	}
	stdin, err := cmd.StdinPipe()
	if err != nil {
		fmt.Println(err)
		return false
	}

	cmd.Start()
	io.WriteString(stdin, input+"\n")
	in := bufio.NewScanner(stdout)
	for in.Scan() {
		fmt.Println(in.Text())
	}

	cmd.Wait()
	cmd.Wait()
	return true
}

var pluginPath string
var taichiPath string
var rename string

const apktoolPath = "../apktool.sh"

func init() {
	flag.StringVar(&pluginPath, "p", "", "plugin apk file path")
	flag.StringVar(&taichiPath, "t", "", "taichi decode dir name")
	flag.StringVar(&rename, "r", "", "rename apk")
}

func main() {
	flag.Parse()

	if pluginPath == "" {
		fmt.Println("请指定plugin path")
		return
	}

	if taichiPath == "" {
		fmt.Println("请指定taichi path")
		return
	}

	if IsDir(pluginPath) {
		fmt.Println("plugin path必须指定一个文件名")
		return
	}

	if !IsDir(taichiPath) {
		fmt.Println("taichi path必须指定一个文件夹名")
		return
	}

	if !Exists(apktoolPath) {
		fmt.Println("请将apktool.sh放入taichi_pack的上级目录")
		return
	}

	if Exists(taichiPath + "/smali_classes2") {
		execCommand("rm", []string{"-rf", taichiPath + "/smali_classes2"})
	}

	if !execCommand(apktoolPath, []string{"d", "-r", "-f", "-o", "out", pluginPath}) {
		return
	}

	if !execCommand("mv", []string{"out/smali", taichiPath + "/smali_classes2"}) {
		return
	}

	// 开始打包
	if !execCommand(apktoolPath, []string{"b", taichiPath}) {
		return
	}
	// zipaligin
	if !execCommand("zipalign", []string{"-f", "-v", "4", taichiPath + "/dist/" + taichiPath + ".apk", taichiPath + "/dist/" + taichiPath + "_aligin.apk"}) {
		return
	}
	// 签名
	if !execCommandWithInput("apksigner", "123456", []string{"sign", "--ks", "/Users/jjyy/Documents/android_key/helper.jks", "--v3-signing-enabled", "false", taichiPath + "/dist/" + taichiPath + "_aligin.apk"}) {
		return
	}
	// 安装
	execCommand("adb", []string{"install", "-r", taichiPath + "/dist/" + taichiPath + "_aligin.apk"})

	time.Sleep(1 * time.Second)

	if rename != "" {
		execCommand("mv", []string{taichiPath + "/dist/" + taichiPath + "_aligin.apk", rename})
	}
}
