package ghbank

const (
	urlMgw = "https://mgs.ghbank.com.cn:8001/mgw.htm"
)

const (
	appID           = "161BC41101438" // meta.config
	billAppID       = "00000001"
	nbVersion       = "1.0.0.10"
	workspaceID     = "product"
	cfBundleVersion = "1.3.0"
	productVersion  = "1.2.1.0"
	menuListVersion = "3.2.36"
	utdidHmacKey    = "d6fc3a4a06adbde89223bvefedc24fecde188aaa9161"
	signSalt        = "c0b074cacb68fd79f4b70faaf2e680f3"
	defaultX        = "29.586084"  // 固定的值
	defaultY        = "103.760721" // 固定的值
	pemRPCSM2Pub    = `-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAE1EBLFFSnek8XYw1mHq7owsBrcDIo
n5x1e+cgkAt+4Qhok94tZg0npCp92MhGEK5THbo/5cDTsS0ubp7LiP3BLQ==
-----END PUBLIC KEY-----`
	pwdSm2PubX = "E8014A13D2E0387ED8BA1DA365810C49AC8AF53C2A6F361C94D58486E9239076"
	pwdSm2PubY = "83F4B3B5518DE21B3D9899B49E8287A3A8B38E789FFFAB5EBD549F9E930C842F"
)

var defaultIV []byte

func init() {
	defaultIV = []byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	}
}
