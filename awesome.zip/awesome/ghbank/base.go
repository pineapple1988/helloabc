package ghbank

import (
	"awesome/tools"
	"bytes"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"net/url"
	"strings"
)

func (b *Bank) userAgent() string {
	return fmt.Sprintf("%s/4 CFNetwork/1120 Darwin/%s", url.PathEscape("乐山商业银行"), tools.KernelVersion(b.SysVer))
}

func newUTDID() string {
	ts := tools.Timestamp()
	r := tools.RandBetween(0x10000000, 0xFFFFFFFF)
	uuid := tools.NewUUIDUpper()
	hc := hashCode(uuid)

	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, ts)
	_ = binary.Write(buffer, binary.BigEndian, uint32(r))
	_ = binary.Write(buffer, binary.BigEndian, uint8(3))
	_ = binary.Write(buffer, binary.BigEndian, uint8(0))
	_ = binary.Write(buffer, binary.BigEndian, hc)

	hb := hmacBase64Value(buffer.Bytes(), utdidHmacKey)
	_ = binary.Write(buffer, binary.BigEndian, hashCode(hb))

	return base64.StdEncoding.EncodeToString(buffer.Bytes())
}

// HashCode 计算字符串的hashcode
func hashCode(str string) uint32 {
	if str == "" {
		return 0
	}

	b := []byte(str)
	var r uint32
	for i := 0; i < len(b); i++ {
		r = uint32(b[i]) + 31*r
	}

	return r
}

// HMACBase64Value 计算hmac值
func hmacBase64Value(in []byte, key string) string {
	h := hmac.New(sha1.New, []byte(key))
	h.Write(in)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

func digits10toMy64(x int64) string {
	table := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")

	index := 11
	arr := make([]byte, index)

	for x > 0 {
		index--
		arr[index] = table[x&0x3F]
		x >>= 6
	}

	return string(arr[index:])
}

func my64toDigits10(x string) int64 {
	table := "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/"

	v := int64(0)
	for _, i := range x {
		v <<= 6
		index := strings.IndexRune(table, i)
		v += int64(index)
	}

	return v
}

func sign(op string, body []byte, ts string) string {
	reqData := base64.StdEncoding.EncodeToString(body)
	param := fmt.Sprintf("%+v&Operation-Type=%+v&Request-Data=%+v&Ts=%+v",
		signSalt, op, reqData, ts)
	return fmt.Sprintf("%x", md5.Sum([]byte(param)))
}

// 生成随机字符串
func generateRandom(count int) string {
	rndBytes := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")
	rndBytesLen := len(rndBytes)
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytes[tools.RandIntn(rndBytesLen)])
	}

	return string(buffer)
}

func intToBytes(x int) []byte {
	var buf = make([]byte, 4)

	binary.BigEndian.PutUint32(buf, uint32(x))
	return buf
}

func pwdEncrypt(pwd string) string {
	pwd = fmt.Sprintf("%02d%s", len(pwd), pwd)
	pwdBuffer := make([]byte, 0x20)
	copy(pwdBuffer, pwd)

	// 进行sm2加密
	enBuffer, _ := tools.SM2Encrypt(pwdBuffer, pwdSm2PubX, pwdSm2PubY)

	return fmt.Sprintf("%X", enBuffer[1:])
}
