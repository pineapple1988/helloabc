package ghbank

type sysDateResp struct {
	Body struct {
		CURDATE   string `json:"CUR_DATE"`
		CURTIME   string `json:"CUR_TIME"`
		TIMESTAMP string `json:"TIMESTAMP"`
	} `json:"body"`
	Head struct {
		HMSG    string `json:"H_MSG"`
		HSTATUS string `json:"H_STATUS"`
	} `json:"head"`
}

type respHead struct {
	BUSITRACENO string `json:"BUSI_TRACE_NO"`
	CLIENTCRACK string `json:"CLIENT_CRACK"`
	CLIENTID    string `json:"CLIENT_ID"`
	CLIENTINFO  string `json:"CLIENT_INFO"`
	CLIENTIP    string `json:"CLIENT_IP"`
	CLIENTOS    string `json:"CLIENT_OS"`
	CLIENTTYPE  string `json:"CLIENT_TYPE"`
	CLIENTVERNO string `json:"CLIENT_VER_NO"`
	HCHNLID     string `json:"H_CHNL_ID"`
	HMSG        string `json:"H_MSG"`
	HNONCE      string `json:"H_NONCE"`
	HRSPSEQ     string `json:"H_RSP_SEQ"`
	HRSPTIME    string `json:"H_RSP_TIME"`
	HSTATUS     string `json:"H_STATUS"`
	HTIME       string `json:"H_TIME"`
	HTIMEOFFSET string `json:"H_TIME_OFFSET"`
	INCORPNO    string `json:"INCORP_NO"`
	SESSION     string `json:"SESSION"`
	TRANSNAME   string `json:"TRANS_NAME"`
	XLINE       string `json:"X_LINE"`
	YLINE       string `json:"Y_LINE"`
}

type loginByPWDResp struct {
	Body struct {
		CID                    string `json:"CID"`
		CUSTCAPLVL             string `json:"CUST_CAP_LVL"`
		CUSTHEADURL            string `json:"CUST_HEAD_URL"`
		CUSTISIDTFYVERIFY      string `json:"CUST_IS_IDTFY_VERIFY"`
		CUSTMOBILE             string `json:"CUST_MOBILE"`
		CUSTMOBILES            string `json:"CUST_MOBILES"`
		CUSTMOBILESKEY         string `json:"CUST_MOBILES_KEY"`
		CUSTNAME               string `json:"CUST_NAME"`
		CUSTSEX                string `json:"CUST_SEX"`
		FIRSTLGNFLAG           string `json:"FIRST_LGN_FLAG"`
		IDTEXPIREREMIND        string `json:"IDT_EXPIRE_REMIND"`
		IDTEXPIREREMINDCONTENT string `json:"IDT_EXPIRE_REMIND_CONTENT"`
		IMGCODE                string `json:"IMG_CODE"`
		ISBINDDEVICE           string `json:"IS_BIND_DEVICE"`
		ISUPDPWD               string `json:"IS_UPD_PWD"`
		LASTLGNCHNL            string `json:"LAST_LGN_CHNL"`
		LASTLGNCITY            string `json:"LAST_LGN_CITY"`
		LASTLGNDATE            string `json:"LAST_LGN_DATE"`
		LASTLGNIP              string `json:"LAST_LGN_IP"`
		LASTLGNMAC             string `json:"LAST_LGN_MAC"`
		LASTLGNSTATUS          string `json:"LAST_LGN_STATUS"`
		LASTLGNTIME            string `json:"LAST_LGN_TIME"`
		LASTLGTTYPE            string `json:"LAST_LGT_TYPE"`
		MENUID                 string `json:"MENU_ID"`
		MSG                    string `json:"MSG"`
		RESINFO                string `json:"RES_INFO"`
		STATUS                 string `json:"STATUS"`
		TRANSN                 string `json:"TRAN_SN"`
	} `json:"body"`
	Head respHead `json:"head"`
}

type acctListResp struct {
	Body struct {
		LIST []struct {
			ACCT        string `json:"ACCT"`
			ACCTADDCHNL string `json:"ACCT_ADD_CHNL"`
			ACCTADDDATE string `json:"ACCT_ADD_DATE"`
			ACCTADDTIME string `json:"ACCT_ADD_TIME"`
			ACCTALIAS   string `json:"ACCT_ALIAS"`
			ACCTLVL     string `json:"ACCT_LVL"`
			ACCTOPENORG string `json:"ACCT_OPEN_ORG"`
			ACCTOPENWAY string `json:"ACCT_OPEN_WAY"`
			ACCTSORT    string `json:"ACCT_SORT"`
			ACCTTYPE    string `json:"ACCT_TYPE"`
			ISDEFTACCT  string `json:"IS_DEFT_ACCT"`
			SUBACCT     string `json:"SUB_ACCT"`
		} `json:"LIST"`
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}

type smsSendResp struct {
	Body struct {
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}

type deviceBindResp struct {
	Body struct {
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}

type systemDateResp struct {
	Body struct {
		DAY    string `json:"DAY"`
		MONTH  string `json:"MONTH"`
		YEAR   string `json:"YEAR"`
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}

type transListResp struct {
	Body struct {
		LIST []struct {
			Account string `json:"account"`
		} `json:"LIST"`
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}

// todo 由于没有交易数据，所以需要有交易数据的账号进行测试
type transQryResp struct {
	Body struct {
		ALLGET string `json:"ALL_GET"`
		ALLPAY string `json:"ALL_PAY"`
		MSG    string `json:"MSG"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
	Head respHead `json:"head"`
}
