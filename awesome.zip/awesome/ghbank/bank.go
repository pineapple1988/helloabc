package ghbank

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"crypto/tls"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"strconv"
	"strings"
	"time"
)

// Bank 广东华兴银行
type Bank struct {
	c          *http.Client
	logger     *log2.MyLog
	Account    string `json:"account"`
	LoginPwd   string `json:"loginPwd"`
	PayPwd     string `json:"payPwd"`
	CardNO     string `json:"cardNo"`
	DeviceName string `json:"deviceName"`
	Model      string `json:"model"`
	SysVer     string `json:"sysVer"`
	UTDID      string `json:"utdid"`
	IDFV       string `json:"idfv"`
	En0Ipv4    string `json:"en0Ipv4"` // wifi本地地址
	serverTime int64
}

// New 创建一个全新的账号，生成随机的设备信息
func New(phoneNumber, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:  phoneNumber,
		LoginPwd: loginPwd, // 如果要加密需要更改
		PayPwd:   payPwd,   // 如果要加密需要更改
	}

	b.Model = tools.NewModel()
	b.DeviceName = tools.PhoneName(b.Model)
	b.SysVer = tools.NewSysVersion()
	b.UTDID = newUTDID()
	b.IDFV = strings.ReplaceAll(tools.NewUUIDUpper(), "-", "")
	b.En0Ipv4 = tools.NewIPV4()

	b.Save()
	return b
}

// Save 保存信息到文件
func (b *Bank) Save() {
	path := "./ghbank/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (b *Bank) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	// u, _ := url.Parse("http://192.168.137.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			// Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// LoginPwd 对密码进行解密操作
func (b *Bank) loginPWD() string {
	return b.LoginPwd
}

// PayPwd 对密码进行解密操作
func (b *Bank) payPWD() string {
	return b.PayPwd
}

// Login 登录操作
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.c = b.NewHTTPClient()
	// 日志
	b.logger = &log2.MyLog{Prefix: fmt.Sprintf("[GHBANK][%s]", b.Account)}

	sys := b.sysDate()
	if sys.Body.TIMESTAMP == "" {
		b.logger.Errorf("密码登陆|获取服务器时间出错了 msg=%s", sys.Head.HMSG)
		return base.LoginResultFail
	}
	b.serverTime, _ = strconv.ParseInt(sys.Body.TIMESTAMP, 10, 64)

	b.updateVersion()

	b.noticePageQry("0") //有返回cookie
	//b.resetCookies()

	b.cacheVerListQry() //有返回cookie
	//cacheCookies := b.cookies()
	//b.resetCookies()

	b.chnlControl() //有返回cookie
	//b.resetCookies()

	b.noticePageQry("6") //有返回cookie
	//b.resetCookies()

	b.activityListQuery() //有返回cookie
	//b.resetCookies()

	b.recommenQry() //有返回cookie
	//recommenCookie := b.cookies()
	//b.resetCookies()

	b.noticeNotReadQry() //有返回cookie
	//noticeCookie := b.cookies()
	//b.resetCookies()

	//b.setCookies(cacheCookies)
	b.menuListQry() // 带上了cookies

	//b.setCookies(recommenCookie)
	b.adverListQry()
	//b.resetCookies()

	time.Sleep(time.Duration(rand.Int31n(3000)+3000) * time.Millisecond)
	//b.setCookies(noticeCookie)
	b.removeImageCode()
	pwdLogin := b.loginByPwd()
	if pwdLogin.Head.HSTATUS == "login.Pwd..error" {
		b.logger.Errorf("密码登陆|密码错误 msg=%s", pwdLogin.Head.HMSG)
		return base.LoginResultFailWrongPwd
	}

	if pwdLogin.Head.HSTATUS != "1" {
		b.logger.Errorf("密码登陆|出现未知错误 msg=%s", pwdLogin.Head.HMSG)
		return base.LoginResultFailWrongPwd
	}

	//uu, _ := url.Parse(urlMgw)
	//b.j.SetCookies(uu, []*http.Cookie{
	//	{
	//		Name:  "SESSION",
	//		Value: pwdLogin.Head.SESSION,
	//	},
	//})

	if pwdLogin.Body.ISBINDDEVICE == "Y" {
		b.logger.Info("密码登陆|需要绑定设备")
		// 需要绑定设备
		// b.bind()
		accts := b.acctList()
		if accts.Head.HSTATUS != "1" {
			b.logger.Errorf("密码登陆|绑定设备|获取账号出现错误 msg=%s", accts.Head.HMSG)
			return base.LoginResultFail
		}

		// 获取到默认账号
		for _, acct := range accts.Body.LIST {
			if acct.ISDEFTACCT == "Y" {
				b.CardNO = acct.ACCT
				break
			}
		}
		if b.CardNO == "" {
			b.logger.Errorf("密码登陆|绑定设备|没有获取到默认账号")
			return base.LoginResultFail
		}
		b.logger.Infof("密码登陆|绑定设备|获取到默认账号=%s", b.CardNO)

		b.queryActiDrawnList()
		b.integralAdd(pwdLogin.Body.TRANSN)
		b.loginByMarketing()

		time.Sleep(time.Duration(rand.Int31n(3000)+3000) * time.Millisecond)
		smsSend := b.smsSend("100002")
		if smsSend.Head.HSTATUS != "1" {
			b.logger.Errorf("密码登陆|绑定设备|发送验证码出现错误 msg=%s", smsSend.Head.HMSG)
			return base.LoginResultFail
		}

		return base.LoginResultFailNeedSms
	}

	return base.LoginResultSuccess
}

// LoginVerifySMS 登陆验证短信
func (b *Bank) LoginVerifySMS(code string) base.LoginResultCode {
	b.logger.Info("获取到短信 -> " + code)

	bind := b.deviceBind(code)
	if bind.Head.HSTATUS == "sms.check.error" {
		b.logger.Errorf("密码登陆|绑定设备|验证码校验失败 msg=%s", bind.Head.HMSG)
		return base.LoginResultFailWrongSms
	}

	if bind.Head.HSTATUS != "1" {
		b.logger.Errorf("密码登陆|绑定设备|验证码校验出现未知错误 msg=%s", bind.Head.HMSG)
		return base.LoginResultFail
	}

	return base.LoginResultSuccess
}

// BillList 查询账单
// pageTs
//     打开账单页面的时间戳，第一次不用写，翻页需要使用返回的
// cardNO
//     需要查询账单的卡号
// date
// 	  TODAY       当天
//	  ONE_WEEK    最近一周
//	  ONE_MONTH   最近一个月
//	  THREE_MONTH 最近三周
// pageNumber
//    1 默认是1开始
func (b *Bank) BillList(pageTs, cardNO, date, pageNumber string) (*transQryResp, string, string) {
	if pageNumber == "1" {
		_, pageTs = b.systemDate()
		// 获取账号列表
		account := b.transList(pageTs)
		// 默认使用第一个账号
		cardNO = account.Body.LIST[0].Account
	}
	b.logger.Infof("开始查询账号[%s]的账单", cardNO)

	return b.transQry(pageTs, cardNO, date, pageNumber), cardNO, pageTs
}
