package main

// func main() {
//	manager.Start()
// 	acc := &alipay.Account{}
// 	if tools.FileExist("./alipay/bin/????") {
// 		tools.LoadJSONFromFile("./alipay/bin/????", acc)
// 	} else {
// 		acc = alipay.NewAccount("????", "???", "???")
// 	}
// 	aliConn := alipay.New(acc)
// 	aliConn.Connect()

// 	select {}
// }
