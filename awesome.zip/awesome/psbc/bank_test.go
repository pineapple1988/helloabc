package psbc

import (
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"
	"testing"
)

func TestUnicode(t *testing.T) {
	fmt.Println(strings.ReplaceAll(strconv.QuoteToASCII("大人"), "\"", ""))
	fmt.Println("\\u5927\\u4eba")
	fmt.Println(hex.Dump([]byte("\\u5927\\u4eba")))
	s := "大人"
	ss := []rune(s)
	fmt.Println(string(ss[:2]))
}
