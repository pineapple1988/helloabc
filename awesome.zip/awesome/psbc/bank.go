package psbc

import (
	"awesome/tools"
	"awesome/tools/base"
	"awesome/tools/log2"
	"bufio"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/http/cookiejar"
	"os"
	"time"
)

// Account 邮政银行
type Account struct {
	Account         string       `json:"account"`
	Password        string       `json:"password"`
	PayPassword     string       `json:"payPassword"`
	CardNo          string       `json:"cardNo"`
	MobileOperators string       `json:"mobileOperators"`
	ClientID        string       `json:"clientID"`
	TokenID         string       `json:"tokenID"`
	UserID          int          `json:"UserID"`
	HardwareInfo    HardwareInfo `json:"hardwareInfo"`
	http            *http.Client
	jar             *cookiejar.Jar
	AesKey          []byte
	ConversationID  string
	Rs              string
	RandKey         []byte
	PassSM4Key      []byte
	PassSM4IV       []byte
	DeviceSM4Key    []byte
	DeviceSM4IV     []byte

	loginStatus      int32
	loginPadding     int32
	transferPadding  int32
	loginFailCount   int
	smscodeFailCount int
	AcctNo           string
	CardBookFlag     string
	AcctType         string
	acctCodeNew      string
	custName         string
	idtNo            string

	transferOrderNo       string
	transferTargetAccount string
	transferTargetName    string
	transferAmount        string
	transferComment       string
	transferBankCode      string
	transferBankName      string
	transferPayeeType     string
	transferBusiType      string
	transferAcctType      string
	transferCardBookFlag  string
	transferAuthType      string
	transferUseableAmt    string
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	Model         string `json:"model"`         // 设备类型
	CellularIP    string `json:"cellularIP"`    // ip地址
}

var logger = log2.MyLog{
}

// New 兴业银行创建一个新的账号
func New(account, loginPwd, payPwd string) *Account {
	b := &Account{
		Account:      account,
		Password:     loginPwd, // 如果要加密需要更改
		PayPassword:  payPwd,   // 如果要加密需要更改
		HardwareInfo: HardwareInfo{},
	}
	b.ClientID = tools.NewUUIDUpper()
	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.CellularIP = tools.NewIPV4()

	b.Save()
	return b
}

// Save 需要服务端来实现，用来存储账号信息
func (acc *Account) Save() {
	path := "./psbc/bin/" + acc.Account + ".json"
	tools.SaveJSON2File(path, acc)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (acc *Account) NewHTTPClient() (*http.Client, *cookiejar.Jar) {
	jarN, _ := cookiejar.New(nil)

	// u, _ := url.Parse("http://192.168.0.110:8888")
	return &http.Client{
		Transport: &http.Transport{
			// Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
		},
		Timeout: time.Second * 10,
		Jar:     jarN,
	}, jarN
}

// Login 登录操作
func (acc *Account) Login(timeout int) base.LoginResultCode {
	// 创建一个新的
	acc.http, acc.jar = acc.NewHTTPClient()
	// 日志
	logger.Prefix = fmt.Sprintf("[PSBC][%s]", acc.Account)

	// 开始登陆
	login, err := acc.executeLogin()
	if err != nil {
		logger.Errorf("登录错误: %+v.", err)
		return base.LoginResultFail
	}

	if login.Success == false {
		logger.Errorf("登录失败, 信息: %+v.", login.Message)
		return base.LoginResultFail
	}

	if err = acc.selectCard(login); err != nil {
		logger.Errorf("选择银行卡错误: %+v.", err)
		return base.LoginResultFail
	}

	//帐号需要绑定
	if login.Result.BindStatus == 0 {
		logger.Info("需要进行设备ID绑定.")
		acc.custName = login.Result.CustName
		acc.idtNo = login.Result.IdtNO

		// 准备刷脸数据
		faceParam, err := acc.getFaceParam()
		if err != nil {
			logger.Errorf("请求刷脸参数错误: %+v.", err)
			return base.LoginResultFail
		}

		if !faceParam.Success {
			logger.Errorf("请求刷脸参数失败, 信息: %+v.", faceParam.Message)
			return base.LoginResultFail
		}

		// 读取刷脸数据
		faceBytes, _ := ioutil.ReadFile(fmt.Sprintf("./psbc/bin/%s.jpg", acc.Account))
		faceData := base64.StdEncoding.EncodeToString(faceBytes)
		face, err := acc.personFace(faceData)
		if err != nil {
			logger.Errorf("刷脸操作错误: %+v.", err)
			return base.LoginResultFail
		}

		// 操作不成功
		if !face.Success {
			logger.Errorf("刷脸操作失败: %+v.", face.Message)
			return base.LoginResultFail
		}

		// 刷脸失败
		if face.Result.Result != "1" {
			logger.Errorf("刷脸检测失败, 相似度过低: %+v.", face.Result.Score)
			return base.LoginResultFail
		}

		newSmsCode, err := acc.getNewSmsCode()
		if err != nil {
			logger.Errorf("发送登录验证码错误.")
			return base.LoginResultFail
		}

		if newSmsCode.Success == false {
			logger.Errorf("发送登录验证码失败, 信息: %+v.", newSmsCode.Message)
			return base.LoginResultFail
		}

		// 输入验证码
		logger.Info("请输入验证码:")
		br := bufio.NewReader(os.Stdin)
		smsCode, _, _ := br.ReadLine()
		logger.Infof("获取到短信[%s]", string(smsCode))
		executeDeviceBind, err := acc.executeDeviceBindNew(string(smsCode))
		if err != nil {
			logger.Errorf("校验验证码操作错误: %+v.", err)
			return base.LoginResultFail
		}

		if !executeDeviceBind.Success {
			logger.Errorf("校验登录验证码失败, 信息: %+v.", executeDeviceBind.Message)
			return base.LoginResultFail
		}

		//查询设备是否第一次登录
		firstLoginFlag, err := acc.queryFirstLoginFlag()
		if err != nil {
			logger.Errorf("查询设备是否第一次登录错误: %+v.", err)
			return base.LoginResultFail
		}

		if firstLoginFlag.Success == false {
			logger.Errorf("查询设备是否第一次登录失败, 代码: %+v.", firstLoginFlag.Message)
			return base.LoginResultFail
		}

	}

	time.Sleep(time.Millisecond * 5000)
	accountQueryShowBal, err := acc.getAccountQueryShowBal()
	if err != nil {
		logger.Errorf("查询余额错误: %+v", err)
		return base.LoginResultFail
	}
	if accountQueryShowBal.Success == false {
		logger.Errorf("查询余额失败, 信息: %+v.", accountQueryShowBal.Message)
		return base.LoginResultFail
	}
	if accountQueryShowBal.Result.AcctCodeNew != "" {
		acc.acctCodeNew = accountQueryShowBal.Result.AcctCodeNew
	}

	return base.LoginResultSuccess
}

func (acc *Account) selectCard(balance *resExecuteLogin) error {
	if balance == nil || len(balance.Result.List) <= 0 {
		return errors.New("这个账号居然没有卡，完蛋")
	}

	if acc.CardNo == "" {

		acc.AcctNo = balance.Result.AcctNO
		acc.CardBookFlag = balance.Result.List[0].CardBookFlag
		acc.AcctType = balance.Result.List[0].AccType

		logger.Infof("未指定银行卡号, 默认选择第一张, 标识: %+v.", acc.AcctNo)
		return nil
	}

	for _, v := range balance.Result.List {
		no := v.AcctNO
		if acc.CardNo == no {
			acc.AcctNo = v.AcctNO
			acc.CardBookFlag = v.CardBookFlag
			acc.AcctType = v.AccType
			logger.Infof("选定指定银行卡号, 卡号: %+v, 标识: %+v.", acc.CardNo, acc.AcctNo)
			return nil
		}
	}

	logger.Errorf("没有找到指定的银行卡号: %s.", acc.AcctNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.AcctNo)
}

func (acc *Account) Transfer(orderNo, targetAccount, targetName, amount, comment string) base.TransferResultCode {
	acc.transferOrderNo = orderNo
	acc.transferTargetAccount = targetAccount
	acc.transferTargetName = targetName
	acc.transferAmount = amount
	acc.transferComment = comment

	cardBinInfo, err := acc.getCardBinInfo(targetAccount)
	if err != nil {
		logger.Errorf("查询目标银行信息错误: %+v.", err)
		return base.TransferResultFail
	}

	if cardBinInfo.Success == false {
		logger.Errorf("查询目标银行信息失败, 信息: %+v.", cardBinInfo.Message)
		return base.TransferResultFail

	}

	acc.transferBankCode = cardBinInfo.Result.BankCode
	acc.transferBankName = cardBinInfo.Result.BankName

	if acc.transferBankCode == "" || acc.transferBankName == "" {
		logger.Errorf("查询到斩不支持的银行, 卡号: %+v, BankCode: %+v, BankName: %+v.",
			acc.transferTargetAccount, acc.transferBankCode, acc.transferBankName)
		return base.TransferResultFail
	}

	//判断是否是同行转账
	if acc.transferBankCode == "403100000004" {
		acc.transferPayeeType = "0" //同行
		acc.transferBusiType = "1"

		//===同行需要用到
		accountType, err := acc.getAccountType()
		if err != nil {
			logger.Errorf("查询银行类型错误: %+v.", err)
			return base.TransferResultFail
		}

		if accountType.Success == false {
			logger.Errorf("查询银行类型失败, 代码: %+v, 信息: %+v.", accountType.Error, accountType.Message)
			return base.TransferResultFail
		}

		acc.transferAcctType = accountType.Result.AcctType
		acc.transferCardBookFlag = accountType.Result.CardBookFlag
		//===同行需要用到

	} else {
		acc.transferPayeeType = "2" //跨行
		acc.transferBusiType = "3"
	}

	// 拉下帐户列表
	//acc.queryAccountLists()

	// 查询余额
	if err := acc.getAccountBalance(); err != nil {
		logger.Errorf("查询余额错误: %+v.", err)
		return base.TransferResultFail
	}

	// 转帐阈值
	if err := acc.getSysDict(); err != nil {
		logger.Errorf("查询转帐阈值错误: %+v.", err)
		return base.TransferResultFail
	}

	// 查询收款人
	name := []rune(acc.transferTargetName)
	for i := 0; i < len(name); i++ {
		time.Sleep(time.Duration(tools.RandIntn(1500)+500) * time.Millisecond)
		if err = acc.queryDimPayee(string(name[:i+1])); err != nil {
			logger.Errorf("查询收款人信息错误: %+v.", err)
			return base.TransferResultFail
		}
	}

	// 新加数据包
	if _, err := acc.executeValidateLimit(); err != nil {
		logger.Errorf("验证用户限额错误: %+v.", err)
		return base.TransferResultFail
	}

	// 获取余额
	balance, err := acc.getAccountQueryShowBal()
	if err != nil {
		logger.Errorf("获取用户余额错误: %+v.", err)
		return base.TransferResultFail
	}

	acc.transferUseableAmt = balance.Result.UseableAmt
	if acc.transferUseableAmt == "" {
		logger.Infof("获取用户可用余额失败: %+v.", acc.transferUseableAmt)
		return base.TransferResultFail
	}

	checkAuthenticationWay, err := acc.executeCheckAuthenticationWay()
	if err != nil {
		logger.Errorf("获取交易认证方式错误: %+v.", err)
		return base.TransferResultFail
	}

	if checkAuthenticationWay.Success == false {
		logger.Errorf("获取交易认证方式失败: %+v.", checkAuthenticationWay.Success)
		return base.TransferResultFail
	}

	// 	if (params.type == "SMS") { //短信+密码
	//		App.sendParams.sms_serv_code = indicate == "88" ? "126" : indicate == "89" ? "127" : indicate;
	//		App.sendParams.SMS_CODE_FLAG = "1"; //短信验证标志 0不验证 1验证
	//		App.sendParams.YLPMMBZ = "0"; //验令牌密码标志 0不验证 1验证
	//		App.sendParams.SMS_CODE = params.code;
	//		App.sendParams.RZLX = "01";
	//		App.sendParams.targetCode = "ZZ00000009"; //目标功能点代码
	//		App.sendParams.YMMBZ = "1";
	//	} else if (params.type == "TOKEN") { //令牌
	//		App.sendParams.SMS_CODE_FLAG = "0";
	//		App.sendParams.YLPMMBZ = "1";
	//		App.sendParams.DZLPMM = params.dztrading; //电子令牌密码
	//		App.sendParams.RZLX = "02";
	//	} else if (params.type == "T$S") { //令牌+短信
	//		App.sendParams.SMS_CODE_FLAG = "1";
	//		App.sendParams.YLPMMBZ = "1";
	//		App.sendParams.DZLPMM = params.dztrading;
	//		App.sendParams.SMS_CODE = params.code;
	//		App.sendParams.sms_serv_code = indicate == "88" ? "126" : indicate == "89" ? "127" : indicate;
	//		App.sendParams.RZLX = "02";
	//		App.sendParams.targetCode = "ZZ00000009";
	//	} else if (params.type == "STICKCARDPINTWO") { // 贴膜卡认证
	//		App.sendParams.sms_serv_code = indicate == "88" ? "126" : indicate == "89" ? "127" : indicate;
	//		App.sendParams.SMS_CODE_FLAG = "1";
	//		App.sendParams.SMS_CODE = params.code;
	//		App.sendParams.YLPMMBZ = "0";
	//		App.sendParams.tmktrading = params.tmktrading;
	//		App.sendParams.RZLX = "01";
	//		App.sendParams.YDBZ = "1";
	//		App.sendParams.targetCode = "ZZ00000009";
	//	} else if (params.type == "SIM_CARD") { // TODO SIM卡盾认证
	//		App.sendParams.sms_serv_code = indicate == "88" ? "126" : indicate == "89" ? "127" : indicate;
	//		App.sendParams.SMS_CODE_FLAG = "1";
	//		App.sendParams.SMS_CODE = params.code;
	//		App.sendParams.YLPMMBZ = "0";
	//		App.sendParams.RZLX = "01";
	//		App.sendParams.YDBZ = "1";
	//		App.sendParams.targetCode = "ZZ00000009";
	//	} else if (params.type == "CODE") { //只验短信验证码
	//		App.sendParams.sms_serv_code = indicate == "88" ? "126" : indicate == "89" ? "127" : indicate;
	//		App.sendParams.SMS_CODE_FLAG = "1";
	//		App.sendParams.SMS_CODE = params.code;
	//		App.sendParams.SMS_CODE_TYPE = "1";
	//		App.sendParams.YLPMMBZ = "0";
	//		App.sendParams.RZLX = "01";
	//		App.sendParams.YDBZ = "0";
	//		App.sendParams.targetCode = "ZZ00000009";
	//	} else {
	//		App.sendParams.SMS_CODE_FLAG = "0";
	//		App.sendParams.YLPMMBZ = "0";
	//		App.sendParams.RZLX = "01";
	//		App.sendParams.YMMBZ = "1";
	//	}
	acc.transferAuthType = checkAuthenticationWay.Result.AuthList[0]
	smsCode := ""
	switch acc.transferAuthType {
	case "SMS", "CODE": // 都需要验证短信
		transferSmsCode, err := acc.getTransferSmsCode()
		if err != nil {
			logger.Errorf("发送短信验证码错误: %+v.", err)
			return base.TransferResultFail
		}

		if transferSmsCode.Success == false {
			logger.Errorf("发送短信验证码失败, 信息: %+v.", transferSmsCode.Message)
			return base.TransferResultFail
		}

		// 输入验证码
		logger.Info("请输入验证码:")
		br := bufio.NewReader(os.Stdin)
		sms, _, _ := br.ReadLine()
		smsCode = string(sms)
		logger.Infof("获取到短信[%s]", smsCode)
	case "TOKEN"://令牌
		logger.Error("未处理的验证方式: 令牌")
		return base.TransferResultFail
	case "T$S"://令牌+短信
		logger.Error("未处理的验证方式:令牌+短信")
		return base.TransferResultFail
	case "STICKCARDPINTWO":// 贴膜卡认证
		logger.Error("未处理的验证方式: 贴膜卡认证")
		return base.TransferResultFail
	case "SIM_CARD": //SIM卡盾认证
		logger.Error("未处理的验证方式: SIM卡盾认证")
		return base.TransferResultFail
	default:
		logger.Infof("只验证交易密码的情况: %+v.", acc.transferAuthType)
	}

	eTransfer, _, err := acc.executeTransfer(smsCode)
	if err != nil {
		logger.Errorf("转账操作错误: %+v.", err)
		return base.TransferResultFail
	}

	if eTransfer.Success == false {
		logger.Errorf("转账操作失败, 代码: %+v 信息: %+v.", eTransfer.Error, eTransfer.Message)
		return base.TransferResultFail
	}

	if acc.transferPayeeType == "2" {
		for i := 0; i < 5; i++ {
			time.Sleep(time.Second * 2)
			result, err := acc.getSuperNetInterStatus(eTransfer.Result.OpenAcctNo, eTransfer.Result.ClearDate, eTransfer.Result.SendBusinessNo)
			if err != nil {
				continue
			}

			if !result.Success {
				logger.Errorf("查询转帐状态失败, 流水号: %+v, 信息: %+v.", eTransfer.Result.SendBusinessNo, result.Message)
				continue
			}

			if result.Result.Status == "01" {
				logger.Infof("查询转帐状态成功, 流水号: %+v.", eTransfer.Result.SendBusinessNo)
				break
			}

			if result.Result.Status == "02" {
				logger.Infof("查询转帐状态失败, 流水号: %+v.", eTransfer.Result.SendBusinessNo)
				return base.TransferResultFail
			}

			logger.Infof("查询转帐状态未确认, 流水号: %+v, 状态: %+v.", eTransfer.Result.SendBusinessNo, result.Result.Status)
		}
	}

	logger.Info("转账成功.")
	return base.TransferResultSuccess
}
