package psbc

import (
	"awesome/tools"
	"bytes"
	"compress/gzip"
	"encoding/json"
	"errors"
	"fmt"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
	"io/ioutil"
	"net/http"
	"strings"

	jsoniter "github.com/json-iterator/go"
)

func (acc *Account) fillHeader(req *http.Request) {
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Content-Type", "text/xml;charset=UTF-8")
	req.Header.Set("User-Agent", "iphone")
	req.Header.Set("Accept-Language", "zh-cn")
	req.Header.Set("Accept-Encoding", "br, gzip, deflate")
}

// GBK2UTF8 将gbk编码转成utf-8编码
func GBK2UTF8(s []byte) ([]byte, error) {
	t := transform.NewReader(bytes.NewReader(s), simplifiedchinese.GBK.NewDecoder())
	d, err := ioutil.ReadAll(t)
	if err != nil {
		return nil, err
	}

	return d, nil
}

// HTTPGetBody 取http响应数据
func HTTPGetBody(resp *http.Response) (string, error) {
	// http状态码
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("提交数据响应错误, 状态码: %d", resp.StatusCode)
	}

	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		var err error
		if body, err = gzip.NewReader(body); err != nil {
			return "", err
		}
	}

	data, err := ioutil.ReadAll(body)
	if err != nil {
		return "", err
	}

	// 如果有gbk编码转成utf8
	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "GBK") || strings.Contains(ct, "gbk") {
		var err error
		if data, err = GBK2UTF8(data); err != nil {
			return "", err
		}
	}

	return string(data), nil
}

// DoHTTP 进行http操作
func DoHTTP(c *http.Client, req *http.Request) (string, error) {
	if c == nil {
		return "", errors.New("http客户端为空")
	}

	if req == nil {
		return "", errors.New("http请求为空")
	}

	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()

	return HTTPGetBody(resp)
}

func (acc *Account) postHTTPData(url string, req interface{}, res interface{}, needEncrypt bool) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("postHTTPData序列化错误: %+v.", err)
		return "", err
	}

	// fmt.Println(string(arr))
	reqJSON := string(arr)

	sm4randKey := tools.RandString(16)
	if needEncrypt {
		arr = reqPkgEnc(arr, sm4randKey)
	}

	// fmt.Println(string(arr))

	r, err := http.NewRequest("POST", url, bytes.NewReader(arr))
	// r, err := http.NewRequest("POST", urlChannel, strings.NewReader(sendstr))
	if err != nil {
		logger.Errorf("postHTTPData创建http请求错误: %+v.", err)
		return "", err
	}

	acc.fillHeader(r)

	body, err := DoHTTP(acc.http, r)
	if err != nil {
		fmt.Printf("%+v.", err)
		logger.Errorf("postHTTPData http操作错误: %+v.", err)
		return "", err
	}

	if needEncrypt {
		body = string(respPkgDec(body, sm4randKey))
	}

	// fmt.Println(body)
	if url != urlDataTrans {
		logger.Infof("http请求成功, data: %s, body: %s.", reqJSON, body)
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), res); err != nil {
			logger.Errorf("postHTTPData反序列化响应数据错误: %+v.", err)
			return "", err
		}
	}

	return body, nil
}

func (acc *Account) executeLogin() (*resExecuteLogin, error) {
	pass := encryptPWD(acc.Account, acc.Password)

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "loginService/executeLogin",
			"_t":      fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"CAPTCHA":              "",
			"APP_TYPE":             "001",
			"LOGIN_TYPE":           "1",
			"APP_VERSION":          appVersion,
			"X_LINE":               "0.000000",
			"CLIENT_OS":            "I",
			"MOBILE":               acc.Account,
			"MOBILE_PHONE_VERSION": fmt.Sprintf("iOS %s", acc.HardwareInfo.SystemVersion),
			"IS_REMMBER_NO":        "1",
			"PWD":                  pass,
			"IS_ACTIVATE":          "0",
			"CLIENT_NO":            acc.ClientID,
			// "CLIENT_NO": "FF662CD6-474B-4682-93F7-40FC5A2BF3B1",
			"CLIENT_INFO":        "iPhone",
			"CLIENT_TYPE":        "IP",
			"CLIENT_VER":         "4",
			"CLIENT_WIFI_FLAG":   "WIFI",
			"CLIENT_ROOT_FLAG":   "0",
			"FINGER_CHANGE_FLAG": "0",
			"CLIENT_IP":          "",
			"Y_LINE":             "0.000000",
			"PRIVACY_VERS":       "1.0.2",
			"DEVICE_PRINT_SIGN":  "",
			"OPER_MAC":           "",
			"OPER_IMEI":          "",
			"OPER_IP":            acc.HardwareInfo.CellularIP,
		},
	}

	res := resExecuteLogin{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("executeLogin请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getFaceParam() (*getFaceParamRes, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "execute",
			"options":    nil,
			"service":    "personFaceService/getParam",
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"wsType": "2",
		},
	}

	res := getFaceParamRes{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("getFaceParam请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) personFace(imgData string) (*personFaceRes, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"option":     "",
			"service":    "personFaceService/getESB_O_faceRecognImageCompareWithoutIDcard",
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"busiCode":      "6",
			"chalType":      "15",
			"cryptType":     "0",
			"ctmLevel":      "0",
			"custName0":     acc.custName,
			"idCard":        acc.idtNo,
			"idImgBase":     "111",
			"imgBase":       imgData,
			"inspectNum":    "1",
			"isActived":     "0",
			"isLoginFlag":   "0",
			"isSave":        "1",
			"orgCode":       "11005293",
			"papeNum0":      acc.idtNo,
			"tellerId":      "001",
			"tradeSysCode":  "99100061500",
			"tradeTypeCode": "100001",
			"transChannel":  "003",
			"transDepno":    "000",
			"transScene":    "00001",
			"wsType":        "2",
		},
	}

	res := personFaceRes{}
	if _, err := acc.postHTTPData(urlDataTrans, &data, &res, false); err != nil {
		logger.Errorf("personFace请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getNewSmsCode() (*resGetNewSmsCode, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "get",
			"options":    nil,
			"service":    "smsCodeService/getNewSmsCode",
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"INDICATE":      "10",
			"smsIndex":      tools.RandBetween(1000, 9999),
			"sms_serv_code": "2020043001",
			"targetCode":    "GRSZ000014",
		},
	}

	res := resGetNewSmsCode{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("getNewSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getNewCheckSmsCode(code string) (*resGetNewCheckSmsCode, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "smsCodeService/getNewCheckSmsCode",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "get",
			"options":    nil,
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"INDICATE":      "0",
			"SMS_CODE":      code,
			"SMS_CODE_FLAG": "1",
			"sms_serv_code": "0",
			"targetCode":    "SBYZ100001",
		},
	}

	res := resGetNewCheckSmsCode{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("getNewCheckSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) executeDeviceBindNew(smsCode string) (*executeDeviceBindNewRes, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "execute",
			"options":    nil,
			"service":    "deviceBindService/executeDeviceBind_new",
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"BIND_CODE":     "",
			"INDICATE":      "10",
			"SMS_CODE":      smsCode,
			"checkType":     "5",
			"phoneTypeFlag": 3,
			"sms_serv_code": "10",
		},
	}

	res := executeDeviceBindNewRes{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("executeDeviceBindNew请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryFirstLoginFlag() (*resqueryFirstLoginFlag, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "deviceBindService/queryFirstLoginFlag",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "query",
			"options":    nil,
			"staticData": false,
		},
		"payload": map[string]interface{}{},
	}

	res := resqueryFirstLoginFlag{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("queryFirstLoginFlag请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryAccountLists() (*resqueryAccountLists, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "acctManageService/queryAccountLists",
			"_t":      fmt.Sprintf("%d", tools.TimestampEx()),
			"method":  "query",
			"options": map[string]interface{}{
				"allowCount": true,
				"limit":      0,
				"start":      0,
			},
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"log": true,
		},
	}

	res := resqueryAccountLists{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("queryAccountLists请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//获取账户信息和余额
func (acc *Account) getAccountQueryShowBal() (*resgetAccountQueryShowBal, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctManageService/getAccountQueryShowBal",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "get",
			"options":    nil,
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"ACCT_NO":        acc.AcctNo,
			"CHECK_MARK":     "0",
			"PASS_WORD":      "0",
			"CARD_BOOK_FLAG": acc.CardBookFlag,
			"ACCT_CODE":      "",
			"INDEX":          0,
			"ACCT_TYPE":      acc.AcctType,
			"KHJG_FLAG":      "1",
		},
	}

	res := resgetAccountQueryShowBal{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("getAccountQueryShowBal请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryInterTransferDetail(startDate, endDate string, page int) (*resqueryInterTransferDetail, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "acctManageService/queryInterTransferDetail",
			"_t":      fmt.Sprintf("%d", tools.TimestampEx()),
			"method":  "query",
			"options": map[string]interface{}{
				"allowCount": true,
				"start":      page,
				"limit":      10,
			},
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"payAcctNo":   acc.AcctNo,
			"startDate":   startDate,
			"endDate":     endDate,
			"payAcctFlag": "2",
			"NEW_BK_NO":   acc.acctCodeNew,
			"accessFlag":  "0",
			"transType":   "1",
			"MAXROW":      1,
			// "allowCount":  true,
			// "start":       0,
			// "limit":       5,
		},
	}

	res := resqueryInterTransferDetail{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("queryInterTransferDetail请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//获取对方账户银行卡信息
func (acc *Account) getCardBinInfo(targetAccount string) (*resgetCardBinInfo, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctInfoService",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "getCardBinInfo",
			"options":    nil,
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"CARD_BIN": targetAccount,
		},
	}

	res := resgetCardBinInfo{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("getCardBinInfo请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getAccountBalance() error {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctManageService",
			"method":     "getAccountBalance",
			"staticData": false,
			"options":    []string{},
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"ACCT_NO":        acc.AcctNo,
			"CHECK_MARK":     "0",
			"PASS_WORD":      "0",
			"CARD_BOOK_FLAG": "2",
			"ACCT_CODE":      "",
		},
	}

	if _, err := acc.postHTTPData(urlChannel, &data, nil, true); err != nil {
		return err
	}

	return nil
}

func (acc *Account) queryDimPayee(name string) error {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "payeeDimService",
			"method":     "queryDimPayee",
			"staticData": false,
			"options": map[string]interface{}{
				"allowCount": true,
				"start":      0,
				"limit":      10,
			},
			"_t": fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"PAYEE_NAME": tools.ToUnicodeString(name), // unicode
			"BIG_TYP":    "N",
		},
	}

	if _, err := acc.postHTTPData(urlChannel, &data, nil, true); err != nil {
		return err
	}

	return nil
}

func (acc *Account) getSysDict() error {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "systemService",
			"method":     "getSysDict",
			"staticData": false,
			"options":    []string{},
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"TYPE": "TRANS_LIMIT",
		},
	}

	if _, err := acc.postHTTPData(urlChannel, &data, nil, true); err != nil {
		return err
	}

	return nil
}

func (acc *Account) executeValidateLimit() (*resExecuteValidateLimit, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "transferService/executeValidateLimit",
			"method":     "execute",
			"staticData": false,
			"options":    []string{},
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"payeeType":         "2",
			"tradeType":         "1B",// A-个人对个人行内转账 1B-转账业务（记261）1B-转账业务（记261）
			"accountNum":        acc.AcctNo,
			"overlimitSign":     "0",
			"cardFlag":          acc.CardBookFlag,
			"transAmt":          acc.transferAmount,
			"poundageType":      "2", // 业务手续费扣收方式
			"rollInAccount":     acc.transferTargetAccount,
			"rollInCusname":     tools.ToUnicodeString(acc.transferTargetName), // unicode
			"rollInAccountBank": tools.ToUnicodeString(acc.transferBankName),   // unicode
			"transType":         "4", // 转账类型 1行内借记卡 2 行内信用卡 3 对公 4跨行
			"khjCode":           acc.acctCodeNew, // 开户机构代码
			"chlCheckType":      "0", // 渠道凭证类型
			"limitFlag":         "1", // 限额提示框标志
			"checkPaperFlag":    "0", // 验证件类型
		},
	}

	res := resExecuteValidateLimit{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("executeValidateLimit请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//转账第1步: 获取交易认证方式
func (acc *Account) executeCheckAuthenticationWay() (*resExecuteCheckAuthenticationWay, error) {

	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]

	busiType := "1000"
	if acc.transferPayeeType == "0" {
		busiType = "1000"
	} else {
		busiType = "1002"
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"_t":      fmt.Sprintf("%d", tools.TimestampEx()),
			"service": "authService",
			"method":  "executeCheckAuthenticationWay",
			"options": []string{
				"31",
			},
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"ACCT_NO":             acc.AcctNo, //付款账号
			"BUSI_TYPE":           busiType,   //根据 PAYEE_TYPE赋值 if PAYEE_TYPE == "0" {BUSI_TYPE == 1000} 2=1002
			"PAYEE_ACCT_NO":       acc.transferTargetAccount,
			"AUTH_LEVEL":          "RISK",
			"JYLX":                "1",
			"PAYEE_TYPE":          acc.transferPayeeType, // 0行内转账  2跨行转账
			"INDICATE":            "31", // 这个应该是短信模版
			"AMT":                 acc.transferAmount,
			"userName":            tools.ToUnicodeString(acc.transferTargetName), //"张强" //收款人名字 // unicode
			"cardNo":              cardNo,                                        //"4317"//取收款卡最后4位
			"last4MobileNo":       "",
			"sms_serv_code":       "31", // sms_serv_code == INDICATE
			"orderNo":             "",
			"safeFlag":            "",
			"chlCheckType":        "0",          // 渠道凭证类型 0普通5电子令牌
			"isCheckPasteCardDia": "true",       // 若是使用贴膜卡做交易，增加此字段。不用不能加。目前只有转账和汇款用到。
			"isSIMCardDia":        "true",       // 若是使用SIM卡盾做交易，增加此字段。不用不能加。目前只有转账和汇款用到
			"targetCode":          "ZZ00000009", // 目标功能代码
			"tradeType":           "01",         //1-转账,2-支付,3-缴费,4-外汇
			"FINGER_FLAG":         "0",
			"useableAmt":          acc.transferUseableAmt, //2021.1.29 新加字段
			"transInfo":           acc.transferAmount,     //2021.1.29 新加字段
		},
	}

	res := resExecuteCheckAuthenticationWay{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("executeCheckAuthenticationWay请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//转账第2步 提交转账订单获取转账交易短信验证码
func (acc *Account) getTransferSmsCode() (*resTransferSmsCode, error) {

	smsIndex := tools.RandBetween(1000, 9999)
	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]

	busiType := "1000"
	if acc.transferPayeeType == "0" {
		busiType = "1000"
	} else {
		busiType = "1002"
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "smsCodeService/getNewSmsCode",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "get",
			"options":    []interface{}{},
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"ACCT_NO":             acc.AcctNo, //付款账号
			"BUSI_TYPE":           busiType,   //根据 PAYEE_TYPE赋值 if PAYEE_TYPE == "0" {BUSI_TYPE == 1000}
			"PAYEE_ACCT_NO":       acc.transferTargetAccount,
			"AUTH_LEVEL":          "RISK",
			"JYLX":                "1",
			"PAYEE_TYPE":          acc.transferPayeeType, //0行内转账  2跨行转账
			"INDICATE":            "31",
			"AMT":                 acc.transferAmount,
			"userName":            tools.ToUnicodeString(acc.transferTargetName), //"张强" //收款人名字 // unicode
			"cardNo":              cardNo,                                        //"4317"//取收款卡最后4位
			"last4MobileNo":       "",
			"sms_serv_code":       "31", //sms_serv_code == INDICATE
			"orderNo":             "",
			"safeFlag":            "",
			"chlCheckType":        "0",          //渠道凭证类型
			"isCheckPasteCardDia": "true",       // 若是使用贴膜卡做交易，增加此字段。不用不能加。目前只有转账和汇款用到。
			"isSIMCardDia":        "true",       // 若是使用SIM卡盾做交易，增加此字段。不用不能加。目前只有转账和汇款用到
			"targetCode":          "ZZ00000009", // 目标功能代码
			"tradeType":           "01",         // 1-转账,2-支付,3-缴费,4-外汇
			"FINGER_FLAG":         "0",
			"smsIndex":            smsIndex,
			"useableAmt":          acc.transferUseableAmt, //2021.1.29 新加字段
			"transInfo":           acc.transferAmount,     //2021.1.29 新加字段
		},
	}

	res := resTransferSmsCode{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("getTransferSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//如果是同行转账需要发这个包
func (acc *Account) getAccountType() (*resgetAccountType, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctManageService/getAccountType",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "get",
			"options":    []interface{}{},
			"staticData": false,
		},
		"payload": map[string]interface{}{
			"ACCT_NO": acc.AcctNo, //付款账号
		},
	}

	res := resgetAccountType{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("getAccountType请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//转账第3步 确认转账
func (acc *Account) executeTransfer(code string) (*resExecuteTransfer, string, error) {

	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]
	smsCodeFlag := "1"
	if len(code) == 0 {
		smsCodeFlag = "0"
	}
	payload := map[string]interface{}{
		"PAYEE_TYPE":       acc.transferPayeeType, // 0行内转账  2跨行转账
		"ACCT_NO":          acc.AcctNo,            // 付款账号
		"CARD_BOOK_FLAG":   acc.CardBookFlag,
		"TRANS_AMT":        acc.transferAmount,
		"PAYEE_ACCT_NO":    acc.transferTargetAccount,
		"PAYEE_NAME":       tools.ToUnicodeString(acc.transferTargetName), // unicode
		"ACTUAL_FEE":       "0.0",
		"POUNDAGERATIO":    "",
		"PAYEE_BANK_CODE":  acc.transferBankCode,
		"PAYEE_BANK_NAME":  tools.ToUnicodeString(acc.transferBankName), // unicode
		"ZZFS":             "0",
		"COMPANYOPENORGAN": "",
		"BUSITYPE":         acc.transferBusiType,
		"REMARK":           acc.transferComment,
		"OVERLIMITFLAG":    "0",
		"ACCT_CODE":        acc.acctCodeNew,
		"SMS_CODE_FLAG":    smsCodeFlag,
		"SMS_CODE":         code,
		"targetCode":       "ZZ00000009",
		"sms_serv_code":    "31",
		"YLPMMBZ":          "0",
		"IS_SAVE_PAYEE":    "1",
		"AMT":              acc.transferAmount,
		"userName":         tools.ToUnicodeString(acc.transferTargetName), // unicode
		"cardNo":           cardNo,
	}

	if acc.transferPayeeType == "0" {
		payload["PAYEE_ACCT_TYPE"] = acc.transferAcctType
		payload["PAYEE_ACCT_CARDFLAG"] = acc.transferCardBookFlag
	}

	// 如果是CODE不需要密码验证,还有只验证密码的情况
	if acc.transferAuthType == "SMS" || len(code) == 0 {
		paypass := encryptPWD(acc.Account, acc.PayPassword)
		payload["YMMBZ"] = "1"
		payload["JYMM"] = paypass
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "transferService/executeTransfer",
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
			"method":     "execute",
			"options":    []string{},
			"staticData": false,
		},
		"payload": payload,
	}

	res := resExecuteTransfer{}

	body, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("executeTransfer请求错误: %+v.", err)
		return nil, "", err
	}

	return &res, body, nil
}

//如果是同行转账需要发这个包
func (acc *Account) executeLogout() (*resexecuteLogout, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "loginService/executeLogout",
			"_t":      fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"X_LINE": acc.AcctNo, //付款账号
		},
	}

	res := resexecuteLogout{}

	_, err := acc.postHTTPData(urlChannel, &data, &res, true)
	if err != nil {
		logger.Errorf("executeLogout请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getSuperNetInterStatus(openAcctNo, tranDate, tranSeqNo string) (*resGetSuperNetInterStatus, error) {
	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "transferService/getSuperNetInterStatus",
			"method":     "get",
			"staticData": false,
			"options":    []interface{}{},
			"_t":         fmt.Sprintf("%d", tools.TimestampEx()),
		},
		"payload": map[string]interface{}{
			"acctNo":        acc.AcctNo,
			"openAcctNo":    openAcctNo,
			"accountFlag":   "10",
			"oprCode":       "00000000000",
			"oldTranDate":   tranDate,
			"oldTransSeqNo": tranSeqNo,
		},
	}

	res := resGetSuperNetInterStatus{}
	if _, err := acc.postHTTPData(urlChannel, &data, &res, true); err != nil {
		logger.Errorf("getSuperNetInterStatus请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}
