package lsccb

const (
	urlMgw = "https://mb.lsccb.com:8443/mgw.htm"
)

const (
	appID           = "5A5F8C2261109" // meta.config
	billAppID       = "00000001"
	nbVersion       = "1.0.0.10"
	workspaceID     = "product"
	cfBundleVersion = "1.3.0"
	productVersion  = "1.2.1.0"
	menuListVersion = "3.2.36"
	utdidHmacKey    = "d6fc3a4a06adbde89223bvefedc24fecde188aaa9161"
	signSalt        = "c0b074cacb68fd79f4b70faaf2e680f3"
	defaultX        = "29.586084"  // 固定的值
	defaultY        = "103.760721" // 固定的值
	pemRsaPub       = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA65fvomleurpxbQ4aPga8
qAZF+4TUs9mJdGSZSNsgN9RqB/yz4tyYMlMO+BmR52QxwFyCXliMwQeMXr+oWHa0
DMsAcC2vPy2fp9JFn2dR7cpOgziji5D5/8BJ2ju+e47Vsrfjg6Ch5uM9wg8/lx3h
PNLYnw+7ykT9M+rMbV3R3u2YFRVzEoFfTNry6IYc+MUcxv4chn/MHq0neW6CbBkV
VwZ4RGJdXi94Kc/VObiBqj4GtMm2hbAjWKVwlXHIfj7t9430EMm3vEgSW/fWfHPD
El5igvHNtp8hXrOVwT07rPXrxv/ZRLuJYx4uKVl2t7+25VGG8stKkfu79uZX1/SH
qwIDAQAB
-----END PUBLIC KEY-----`
	pwdSm2PubX = "E8014A13D2E0387ED8BA1DA365810C49AC8AF53C2A6F361C94D58486E9239076"
	pwdSm2PubY = "83F4B3B5518DE21B3D9899B49E8287A3A8B38E789FFFAB5EBD549F9E930C842F"
)

var defaultIV []byte

func init() {
	defaultIV = []byte{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	}
}
