package lsccb

import (
	"awesome/tools"
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/go-http-utils/headers"
	"github.com/golang/protobuf/proto"
)

func (b *Bank) post(header *http.Header, body []byte) ([]byte, error) {
	// gzip 压缩
	bodyZ, err := tools.GZipCompress(body)
	if err != nil {
		return nil, err
	}

	// 生成key
	aesKey := generateRandom(16)

	// 对key进行rsa加密
	rsaPub := tools.DecodePublicKeyPEMData(pemRsaPub)
	aeskeyE, err := tools.RSAEncrypt([]byte(aesKey), rsaPub)
	if err != nil {
		return nil, err
	}

	// 对数据进行aes加密
	bodyE := tools.AESCBCEncrypt(bodyZ, []byte(aesKey), defaultIV)

	// 组包
	buffer := bytes.NewBuffer([]byte{})
	// key加密类型
	buffer.Write([]byte{0x01})
	// key加密后长度
	buffer.Write(intToBytes(len(aeskeyE))[1:])
	// 加密后key
	buffer.Write(aeskeyE)
	// 数据加密类型
	buffer.Write([]byte{0x0B})
	// 数据加密后长度
	buffer.Write(intToBytes(len(bodyE))[1:])
	// 加密后数据
	buffer.Write(bodyE)

	// 发送
	resp, err := tools.DoHTTPPost(b.c, urlMgw, nil, header, buffer.Bytes())
	if err != nil {
		return nil, err
	}

	// 对返回数据进行解密操作
	respD := tools.AESCBCDecrypt(resp, []byte(aesKey), defaultIV)

	// 解压缩
	respZ, err := tools.GZipUncompress(respD)
	if err != nil {
		return nil, err
	}

	return respZ, nil
}

func (b *Bank) addBaseHeader(op string, body []byte) *http.Header {
	ts := digits10toMy64(tools.TimestampEx())
	s := sign(op, body, ts)
	return &http.Header{
		"x-mgs-encryption": {"1"},
		"AppId":            {appID},
		"WorkspaceId":      {workspaceID},
		"Accept":           {"*/*"},
		"Accept-Language":  {"zh-cn"},
		"Accept-Encoding":  {"gzip, deflate, br"},
		"Operation-Type":   {op},
		"Platform":         {"IOS"},
		"UniformGateway":   {urlMgw},
		"Did":              {b.UTDID},
		"User-Agent":       {b.userAgent()},
		"Ts":               {ts},
		"Sign":             {s},
	}
}

func (b *Bank) addBaseInnerHeader() map[string]string {
	ts := tools.TimestampEx()
	offset := ts - b.serverTime
	return map[string]string{
		"CLIENT_CRACK":  "N",
		"CLIENT_ID":     b.IDFV,
		"CLIENT_INFO":   fmt.Sprintf("%s|iOS|%s", b.IDFV, b.SysVer),
		"CLIENT_IP":     b.En0Ipv4,
		"CLIENT_OS":     "I",
		"CLIENT_TYPE":   "I",
		"CLIENT_VER_NO": cfBundleVersion,
		"H_CHNL_ID":     "1001",
		"H_NONCE":       fmt.Sprintf("%s%d", tools.NewUUIDUpper(), tools.TimestampEx()), // 随机uuid+时间戳
		"H_TIME":        fmt.Sprintf("%d", ts),
		"H_TIME_OFFSET": fmt.Sprintf("%d", offset),
		"INCORP_NO":     "000090",
		"X_LINE":        defaultX,
		"Y_LINE":        defaultY,
	}
}

func (b *Bank) sysDate() *sysDateResp {
	respObj := &sysDateResp{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("sysDate", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("sysDate post err=%+v", err)
		return respObj
	}

	b.logger.Infof("sysDate >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("sysDate json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj
}

func (b *Bank) getUnionResource(params []*UnionResourceParam) *UnionResourceResult {
	body, _ := proto.Marshal(&UnionResourceRequest{
		Platform:           UnionPlatformType_ios.Enum(),
		ProductId:          proto.String(fmt.Sprintf("%s_IOS-%s", appID, workspaceID)),
		ProductVersion:     proto.String(productVersion),
		ReleaseVersion:     proto.String(productVersion),
		Utdid:              proto.String(b.UTDID),
		ClientId:           proto.String(b.UTDID),
		PhoneBrand:         proto.String("apple"),
		PhoneModel:         proto.String(b.DeviceName),
		OsVersion:          proto.String(b.SysVer),
		NetType:            proto.String("WIFI"),
		ResourceParam:      params,
		Uid:                proto.String(""),
		CpuInstructionList: []string{"arm64"},
	})

	header := b.addBaseHeader("alipay.client.getUnionResource", body)
	header.Set(headers.ContentType, "application/protobuf")
	header.Set("Version", "2")
	// pb反序列化
	result := &UnionResourceResult{}

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("getUnionResource post err=%+v", err)
		return result
	}

	err = proto.Unmarshal(resp, result)
	if err != nil {
		b.logger.Errorf("getUnionResource proto.Unmarshal err=%+v", err)
	}

	b.logger.Infof("getUnionResource >>>> %s", proto.MarshalTextString(result))

	return result
}

func (b *Bank) updateVersion() {
	body, _ := json.Marshal(&map[string]interface{}{
		"clientId": b.UTDID,
		"did":      b.UTDID,
		"extInfos": map[string]string{
			"prisonBreakFlag": "-1",
		},
		"mobileBrand":    "Apple",
		"mobileModel":    b.DeviceName,
		"netType":        "WIFI",
		"osType":         "IOS",
		"osVersion":      b.SysVer,
		"prisonBreak":    0,
		"productVersion": productVersion,
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("alipay.client.updateVersion", body)
	header.Set(headers.ContentType, "application/json")
	header.Set("Version", "2")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("updateVersion post err=%+v", err)
		return
	}

	b.logger.Infof("updateVersion >>>> %s", string(resp))
}

func (b *Bank) noticePageQry(noticeType string) {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"CHNL_TYPE":   "MB",
				"INCORP_NO":   "000090",
				"NEXT_KEY":    "1",
				"NOTICE_TYPE": noticeType,
				"PAGE_SIZE":   "100",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("noticePageQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("noticePageQry post err=%+v", err)
		return
	}

	b.logger.Infof("noticePageQry >>>> %s", string(resp))
}

func (b *Bank) cacheVerListQry() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"CHNL_TYPE": "MB",
				"INCORP_NO": "000090",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("cacheVerListQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("cacheVerListQry post err=%+v", err)
		return
	}

	b.logger.Infof("cacheVerListQry >>>> %s", string(resp))
}

func (b *Bank) chnlControl() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"CHNL_TYPE": "MB",
				"INCORP_NO": "000090",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("chnlControl", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("chnlControl post err=%+v", err)
		return
	}

	b.logger.Infof("chnlControl >>>> %s", string(resp))
}

func (b *Bank) noticeNotReadQry() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"NOTICE_MOBILE": b.Account,
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("noticeNotReadQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("noticeNotReadQry post err=%+v", err)
		return
	}

	b.logger.Infof("noticeNotReadQry >>>> %s", string(resp))
}

func (b *Bank) activityListQuery() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("activityListQuery", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("activityListQuery post err=%+v", err)
		return
	}

	b.logger.Infof("activityListQuery >>>> %s", string(resp))
}

func (b *Bank) recommenQry() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("recommenQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("recommenQry post err=%+v", err)
		return
	}

	b.logger.Infof("recommenQry >>>> %s", string(resp))
}

func (b *Bank) menuListQry() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"CHNL_TYPE":  "MB",
				"CLIENT_OS":  "I",
				"CLIENT_VER": menuListVersion,
				"INCORP_NO":  "000090",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("menuListQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("menuListQry post err=%+v", err)
		return
	}

	b.logger.Infof("menuListQry >>>> %s", string(resp))
}

func (b *Bank) adverListQry() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"ADAP_FBL":  "1",
				"CHNL_TYPE": "MB",
				"INCORP_NO": "000090",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("adverListQry", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("adverListQry post err=%+v", err)
		return
	}

	b.logger.Infof("menuListQry >>>> %s", string(resp))
}

func (b *Bank) removeImageCode() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("removeImageCode", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("removeImageCode post err=%+v", err)
		return
	}

	b.logger.Infof("removeImageCode >>>> %s", string(resp))
}

func (b *Bank) loginByPwd() *loginByPWDResp {
	respObj := &loginByPWDResp{}

	pwd := pwdEncrypt(b.loginPWD())
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"CHNL_TYPE":       "MB",
				"CUST_LGN_NAME":   b.Account,
				"CUST_LGN_WAY":    "PW",
				"IMG_CODE":        "",
				"LGN_CITY":        "",
				"LGN_CLIENT_ID":   b.IDFV,
				"LGN_CLIENT_TYPE": "I",
				"LGN_CLIENT_VER":  b.SysVer,
				"LGN_CRACK":       "N",
				"LGN_MAC":         b.IDFV,
				"LGN_OS":          "ios",
				"LGN_PWD":         pwd,
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("loginByPwd", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("loginByPwd post err=%+v", err)
		return respObj
	}

	b.logger.Infof("loginByPwd >>>> %s", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("loginByPwd json.Unmarshal err=%+v, respData=%s", err, hex.Dump(resp))
		return respObj
	}

	return respObj
}

func (b *Bank) bind() {
	body, _ := proto.Marshal(&YunpushcoreBindInfoReq{
		AppId:         proto.String(appID),
		WorkspaceId:   proto.String(workspaceID),
		UserId:        proto.String(b.Account),
		DeliveryToken: proto.String(""),
		OsType:        proto.Int32(2),
	})

	header := b.addBaseHeader("alipay.client.yunpushcore.bind", body)
	header.Set(headers.ContentType, "application/protobuf")
	header.Set("Version", "2")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("bind post err=%+v", err)
		return
	}

	// pb反序列化
	result := &YunpushcoreResult{}
	err = proto.Unmarshal(resp, result)
	if err != nil {
		b.logger.Errorf("bind proto.Unmarshal err=%+v", err)
		return
	}

	b.logger.Infof("bind >>>> %s", proto.MarshalTextString(result))
}

func (b *Bank) acctList() *acctListResp {
	respObj := &acctListResp{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("acctList", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("acctList post err=%+v", err)
		return respObj
	}

	b.logger.Infof("acctList >>>> %s", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.logger.Errorf("acctList json.Unmarshal err=%+v, respData=%s", err, hex.Dump(resp))
		return respObj
	}

	return respObj
}

func (b *Bank) queryActiDrawnList() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"THIRD_PRE": "ERCHUANG",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("queryActiDrawnList", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("queryActiDrawnList post err=%+v", err)
		return
	}

	b.logger.Infof("queryActiDrawnList >>>> %s", string(resp))
}

func (b *Bank) integralAdd(tranSN string) {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"OLD_TRAN_SN": tranSN,
				"SCENE_ID":    "002",
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("integralAdd", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("integralAdd post err=%+v", err)
		return
	}

	b.logger.Infof("integralAdd >>>> %s", string(resp))
}

func (b *Bank) loginByMarketing() {
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("loginByMarketing", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("loginByMarketing post err=%+v", err)
		return
	}

	b.logger.Infof("loginByMarketing >>>> %s", string(resp))
}

func (b *Bank) smsSend(tmplID string) *smsSendResp {
	respObj := &smsSendResp{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"PHONE_NO":    b.Account[len(b.Account)-4:],
				"SMS_TMPL_ID": tmplID,
			},
			"head": b.addBaseInnerHeader(),
		},
	})

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("smsSend", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("smsSend post err=%+v", err)
		return respObj
	}

	b.logger.Infof("smsSend >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("smsSend json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj
}

func (b *Bank) deviceBind(smsCode string) *deviceBindResp {
	respObj := &deviceBindResp{}

	payPwd := pwdEncrypt(b.payPWD())
	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"ACCT_ID":        b.CardNO,
				"ACCT_PWD":       payPwd,
				"CHNL_TYPE_MB":   "MB",
				"CLIENT_OS":      "I",
				"DEVICE_APP_VER": cfBundleVersion,
				"DEVICE_ID":      b.IDFV,
				"SMS_CODE":       smsCode,
			},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("deviceBind", body)
	header.Set(headers.ContentType, "application/json")

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("deviceBind post err=%+v", err)
		return respObj
	}

	b.logger.Infof("deviceBind >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("deviceBind json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////账单列表/////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
func (b *Bank) systemDate() (*systemDateResp, string) {
	respObj := &systemDateResp{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("systemDate", body)
	header.Set(headers.ContentType, "application/json")
	pageTs := fmt.Sprintf("-__%s_", digits10toMy64(tools.TimestampEx()))
	(*header)["pagets"] = []string{pageTs}
	(*header)["srcSpm"] = []string{"-"}
	(*header)["lastClickSpm"] = []string{""}
	(*header)["nbappid"] = []string{billAppID}
	(*header)["x-nb-appid"] = []string{fmt.Sprintf("AP_%s_ios", billAppID)}

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("systemDate post err=%+v", err)
		return respObj, pageTs
	}

	b.logger.Infof("systemDate >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("systemDate json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj, pageTs
}

func (b *Bank) transList(pageTs string) *transListResp {
	respObj := &transListResp{}

	body, _ := json.Marshal(&map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{},
			"head": b.addBaseInnerHeader(),
		},
	})
	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("transList", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["pagets"] = []string{pageTs}
	(*header)["srcSpm"] = []string{"-"}
	(*header)["lastClickSpm"] = []string{""}
	(*header)["nbappid"] = []string{billAppID}
	(*header)["x-nb-appid"] = []string{fmt.Sprintf("AP_%s_ios", billAppID)}

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("transList post err=%+v", err)
		return respObj
	}

	b.logger.Infof("transList >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("transList json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj
}

func (b *Bank) transQry(pageTs, cardNO, date, pageNumber string) *transQryResp {
	respObj := &transQryResp{}

	reqObj := &map[string]interface{}{
		"_requestBody": map[string]interface{}{
			"body": map[string]string{
				"GU_DATE":    date, // TODAY ONE_WEEK ONE_MONTH THREE_MONTH
				"TRANS_TYPE": "ALL",
				"chxunbis":   "10",
				"kehuzhao":   cardNO,
				"pagenumber": pageNumber,
			},
			"head": b.addBaseInnerHeader(),
		},
	}
	if pageNumber == "1" {
		(*reqObj)["_requestBody"].(map[string]interface{})["body"].(map[string]string)["FIRST_SELECT"] = "1"
	}

	body, _ := json.Marshal(reqObj)

	// 添加 []
	body = append([]byte{0x5B}, body...)
	body = append(body, 0x5D)

	header := b.addBaseHeader("transQry", body)
	header.Set(headers.ContentType, "application/json")
	(*header)["pagets"] = []string{pageTs}
	(*header)["srcSpm"] = []string{"-"}
	(*header)["lastClickSpm"] = []string{""}
	(*header)["nbappid"] = []string{billAppID}
	(*header)["x-nb-appid"] = []string{fmt.Sprintf("AP_%s_ios", billAppID)}

	resp, err := b.post(header, body)
	if err != nil {
		b.logger.Errorf("transQry post err=%+v", err)
		return respObj
	}

	b.logger.Infof("transQry >>>> %s", string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		b.logger.Errorf("transQry json.Unmarshal err=%+v respData=%s", err, hex.Dump(resp))
	}
	return respObj
}
