package jegotrip

import (
	"bytes"
	"crypto/md5"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"awesome/tools"
	"awesome/tools/log2"
	"math/big"
	"math/rand"
	"net"
	"time"
)

type Jegotrip struct {
	myConn
	Account      string `json:"account"`
	SipPwd       string `json:"sipPwd"`
	DeviceId     string `json:"deviceId"`
	BootTime     int64  `json:"bootTime"`
	IP           string `json:"ip"`
	Port         string `json:"port"`
	magic        []byte
	magicIndex   uint32
	pkgIndex     uint32
	localSeqNo1  uint16
	localSeqNo2  uint16
	serverSeqNo1 uint16
	serverSeqNo2 uint16
	localTicks   uint16
	serverTicks  uint16
	localKey     uint32
	serverKey    uint32
	enKey1       uint32
	enKey2       uint32
	enKeyBuf     [0x10]byte
	enLen        int
	deKey1       uint32
	deKey2       uint32
	deKeyBuf     [0x10]byte
	deLen        int
}

// New
func New(account, sipPwd string) *Jegotrip {
	j := &Jegotrip{
		Account: account,
		SipPwd:  sipPwd,
	}
	j.DeviceId = tools.NewUUIDUpper()
	j.IP = "18.163.39.57"
	j.Port = "10800"
	// 开机时间纳秒
	j.BootTime = time.Now().UnixNano() - 1000000000*60*60*24*(rand.Int63()%31)
	j.Save()
	return j
}

func (j *Jegotrip) Save() {
	path := "./jegotrip/bin/" + j.Account + ".json"
	tools.SaveJSON2File(path, j)
}

func (j *Jegotrip) getClientId() string {
	return fmt.Sprintf("%s%s", pkgName, j.DeviceId)
}

func (j *Jegotrip) getDeviceInfoCC() string {
	return "3031.553721781#113.130.126.124"
}

func (j *Jegotrip) getCurTicks() int64 {
	im := big.NewInt(time.Now().UnixNano() - j.BootTime)
	in := big.NewInt(0x431BDE82D7B634DB)
	im.Mul(im, in)
	im.Rsh(im, 64)
	im.Rsh(im, 18)
	return im.Int64()
}

func (j *Jegotrip) getLocalTicks() int64 {
	im := big.NewInt(time.Now().UnixNano() - j.BootTime)
	in := big.NewInt(0x431BDE82D7B634DB)
	im.Mul(im, in).Lsh(im, 64).Lsh(im, 18)
	return im.Int64()
}

func (j *Jegotrip) getMagic() []byte {
	if len(j.magic) <= 0 {
		md := md5.Sum([]byte(fmt.Sprintf("username:+86%s/<UnifiedSession>%08X%08X", j.Account, getRand(), getRand())))
		j.magicIndex = getRand()
		j.magic = md[:0xc]
	}

	buf := bytes.NewBuffer(j.magic)
	j.magicIndex += 1
	_ = binary.Write(buf, binary.BigEndian, j.magicIndex)
	return buf.Bytes()
}

func (j *Jegotrip) getPkgIndex() uint32 {
	if j.pkgIndex <= 0 {
		j.pkgIndex = getRand()
	}

	j.pkgIndex += 1

	return j.pkgIndex
}

func (j *Jegotrip) getSeqNo1() uint16 {
	if j.localSeqNo1 <= 0 {
		j.localSeqNo1 = uint16(getRand())
	}

	j.localSeqNo1 += 1

	return j.localSeqNo1
}

func (j *Jegotrip) getSeqNo2() uint16 {
	if j.localSeqNo2 <= 0 {
		j.localSeqNo2 = uint16(getRand())
	}

	j.localSeqNo2 += 1

	return j.localSeqNo2
}

///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////基本函数//////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
func getRand() uint32 {
	rand.Seed(time.Now().UnixNano())
	return rand.Uint32()
}

func writeKVS(buffer *bytes.Buffer, k string, v string) {
	writeString(buffer, k)
	writeString(buffer, v)
}

func writeKVB(buffer *bytes.Buffer, k string, v []byte) {
	writeString(buffer, k)
	writeBytes(buffer, v)
}

func writeString(buffer *bytes.Buffer, v string) {
	_ = binary.Write(buffer, binary.BigEndian, int32(len(v)))
	buffer.Write([]byte(v))
}

func writeBytes(buffer *bytes.Buffer, v []byte) {
	_ = binary.Write(buffer, binary.BigEndian, int32(len(v)))
	buffer.Write(v)
}

func writeObj(buffer *bytes.Buffer, data *bytes.Buffer) {
	_ = binary.Write(buffer, binary.BigEndian, int32(len(data.Bytes()))+0x5)
	buffer.Write([]byte{0x00, 0x00, 0x01, 0x00, 0x00})
	buffer.Write(data.Bytes())
}

func crypt(inData []byte, keyBuf [0x10]byte, key1 uint32, key2 uint32, encryptedLen int) ([]byte, [0x10]byte, uint32, uint32, int) {
	blockSize := 0
	inLen := len(inData)
	outData := inData
	for {
		if encryptedLen&0xf == 0 {
			key1 = key1 + 0x3249A234
			binary.BigEndian.PutUint32(keyBuf[:], key1)
			key1 = key1 * key2
			binary.BigEndian.PutUint32(keyBuf[4:], key1)
			key1 = key1 ^ (key1 << 16)
			binary.BigEndian.PutUint32(keyBuf[8:], key1)
			key2 = key2 + 0x10923487
			key1 = (key2 + uint32(encryptedLen)>>4) ^ key1
			binary.BigEndian.PutUint32(keyBuf[0xc:], key1)
		}

		blockSize = 16 - encryptedLen&0xf
		if blockSize > inLen {
			blockSize = inLen
		}
		encryptedLen += blockSize
		inLen -= blockSize
		for i := 0; i < blockSize; i++ {
			outData[i] ^= keyBuf[i]
		}

		outData = outData[blockSize:]
		if inLen < 1 {
			break
		}
	}

	var keyFinal [0x10]byte
	for i := 0; i < 16-blockSize; i++ {
		keyFinal[i] = keyBuf[blockSize+i]
	}

	return inData, keyFinal, key1, key2, encryptedLen
}

///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////网络链接//////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
// 开始连接
func (j *Jegotrip) Connect() {
	j.myConn = *NewMyConn(j)
	addr := net.JoinHostPort(j.IP, j.Port)
	go j.handleConn(addr, false)
}

// 停止连接
func (j *Jegotrip) DisConnect() {
	j.stopChan <- true
}

// OnConnected 连接成功或失败
func (j *Jegotrip) OnConnected(err error) {
	if err == nil {
		//j.timeExchange1()
		//j.accountEntry()
		//j.keyExchange()
		j.registerAlive()
		//j.sendTcp([]byte{0xff, 0xff, 0x02})
	} else {
		log2.Errorf("[WorkGroup|OnConnected] err=%+v", err)
	}
}

// OnClose 关闭连接
func (j *Jegotrip) OnClose() {
	log2.Info("[WorkGroup|OnClose]")
}

// OnReceived 接收到网络数据 8008
func (j *Jegotrip) OnReceived(data []byte) {
	log2.Info("recv >>>> \r\n")
	log2.Info( "\r\n" + hex.Dump(data))
	for ; len(data) > 4; {
		// 读取长度
		dataLen := binary.BigEndian.Uint32(data[:4])
		if int(4 + dataLen) > len(data) {
			return
		}
		pkg := data[4 : 4+dataLen]
		var outData []byte
		switch pkg[2] {
		case 0:
			// 解密一下
			outData, j.deKeyBuf, j.deKey1, j.deKey2, j.deLen = crypt(pkg[3:], j.deKeyBuf, j.deKey1, j.deKey2, j.deLen)
			log2.Info("\r\n" + hex.Dump(outData))
			// 发送一个确认包
			buf := bytes.NewBuffer([]byte{})
			buf.Write(outData[:5])
			buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00})
			outData, j.enKeyBuf, j.enKey1, j.enKey2, j.enLen = crypt(buf.Bytes(), j.enKeyBuf, j.enKey1, j.enKey2, j.enLen)
			j.sendTcp(append([]byte{0xFF, 0xFF, 0x01}, outData...))
		case 1:
			// 这是交换密钥后的第一个包,这里有可能是带密钥或者不带密钥的
			if j.deKey1 == 0 {
				j.deKey1 = binary.BigEndian.Uint32(pkg[3:7])
				j.deKey2 = j.deKey1
				log2.Infof("获取到解密key -> %08x %08x \r\n", j.deKey1, j.deKey2)
				pkg = pkg[4:] // 去掉四个字节
			}
			outData, j.deKeyBuf, j.deKey1, j.deKey2, j.deLen = crypt(pkg[3:], j.deKeyBuf, j.deKey1, j.deKey2, j.deLen)
			log2.Info("\r\n" + hex.Dump(outData))
		case 2:
			if dataLen == 3 {
				j.sendTcp([]byte{0xff, 0xff, 0x0e})
			}
			if dataLen > 3 {
				j.deKey1 = binary.BigEndian.Uint32(pkg[3:7])
				j.deKey2 = j.deKey1
				log2.Infof("获取到解密key -> %08x %08x \r\n", j.deKey1, j.deKey2)
			}
		case 4:
			j.sendTcp([]byte{0xff, 0xff, 0x04})
		case 0xe:
			if dataLen == 3 {
				j.sendTcp([]byte{0xff, 0xff, 0x02})
			}
			if dataLen > 3 {
				j.deKey1 = binary.BigEndian.Uint32(pkg[3:7])
				j.deKey2 = j.deKey1
				log2.Infof("获取到解密key -> %08x %08x \r\n", j.deKey1, j.deKey2)
			}
		}
		data = data[4+dataLen:]
	}
}

// OnReceived 接收到网络数据 10800
//func (j *Jegotrip) OnReceived(data []byte) {
//	fmt.Println("recv >>>> ")
//	fmt.Println(hex.Dump(data))
//	for ; len(data) > 4; {
//		// 读取长度
//		dataLen := binary.BigEndian.Uint32(data[:4])
//		// 长度不够
//		if int(4+dataLen) > len(data) {
//			return
//		}
//		pkg := data[4 : 4+dataLen]
//		if j.serverTicks == 0 {
//			j.serverTicks = binary.BigEndian.Uint16(pkg[4:6])
//			j.localTicks = uint16(j.getCurTicks())
//			fmt.Printf("serverTicks=0x%x localTicks=0x%x \r\n", j.serverTicks, j.localTicks)
//		}
//
//		if dataLen == 8 {
//			if pkg[7] == 0x13 {
//				// 回一个0x13
//				j.heartbeat()
//			}
//		}
//
//		if len(pkg) < 23 {
//			return
//		}
//		if pkg[22] == 2 {
//			// 获取到交换的密钥
//			j.serverKey = binary.BigEndian.Uint32(pkg[23:27])
//			fmt.Printf("获取到解密key -> 0x%08x \r\n", j.serverKey)
//			j.keyExchangeDone()
//		}
//		data = data[4+dataLen:]
//	}
//}

// OnError 出现错误
func (j *Jegotrip) OnError(err error) {
	log2.Errorf("[WorkGroup|OnError]:%+v.", err)
}

func (j *Jegotrip) sendTcp(data []byte) {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, int32(len(data)))
	buf.Write(data)
	j.Send(buf.Bytes())

	fmt.Println("send >>>>> ")
	fmt.Println(hex.Dump(buf.Bytes()))
}

///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////业务逻辑//////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
func (j *Jegotrip) Login() {
	j.accountEntry()
}
