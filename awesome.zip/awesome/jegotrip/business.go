package jegotrip

import (
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"awesome/tools"
)

func (j *Jegotrip) timeExchange1() {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(buf, binary.BigEndian, ticks)
	_ = binary.Write(buf, binary.BigEndian, j.serverTicks)
	buf.Write([]byte{0x00, 0x10})
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	buf.Write([]byte{0xFF, 0xFF})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo2())
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	j.Send(buf.Bytes())
	fmt.Println(hex.Dump(buf.Bytes()))
}

func (j *Jegotrip) timeExchange2() {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(buf, binary.BigEndian, ticks)
	_ = binary.Write(buf, binary.BigEndian, j.serverTicks+ticks-j.localTicks)
	buf.Write([]byte{0x00, 0x11})
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	buf.Write([]byte{0xFF, 0xFF})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo2())
	buf.Write([]byte{0x00, 0x00})
	_ = binary.Write(buf, binary.BigEndian, j.serverSeqNo1)
	_ = binary.Write(buf, binary.BigEndian, j.serverSeqNo2)
	j.Send(buf.Bytes())
	fmt.Println(hex.Dump(buf.Bytes()))
}

func (j *Jegotrip) keyExchange() {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(buf, binary.BigEndian, ticks)
	if j.serverTicks != 0 {
		_ = binary.Write(buf, binary.BigEndian, j.serverTicks+ticks-j.localTicks)
	} else {
		_ = binary.Write(buf, binary.BigEndian, uint16(0))
	}
	buf.Write([]byte{0x00, 0x10})
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	buf.Write([]byte{0xFF, 0xFF, 02})

	j.sendTcp(buf.Bytes())
}

func (j *Jegotrip) keyExchangeDone() {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(buf, binary.BigEndian, ticks)
	if j.serverTicks != 0 {
		_ = binary.Write(buf, binary.BigEndian, j.serverTicks+ticks-j.localTicks)
	} else {
		_ = binary.Write(buf, binary.BigEndian, uint16(0))
	}
	buf.Write([]byte{0x00, 0x10})
	buf.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	buf.Write([]byte{0xFF, 0xFF, 0x0E})

	j.sendTcp(buf.Bytes())
}

func (j *Jegotrip) heartbeat() {
	buf := bytes.NewBuffer([]byte{})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(buf, binary.BigEndian, ticks)
	if j.serverTicks != 0 {
		_ = binary.Write(buf, binary.BigEndian, j.serverTicks+ticks-j.localTicks)
	} else {
		_ = binary.Write(buf, binary.BigEndian, uint16(0))
	}
	buf.Write([]byte{0x00, 0x13})
	j.sendTcp(buf.Bytes())
}


// loginSession.AccountEntry.Account
func (j *Jegotrip) accountEntry() {
	obj := bytes.NewBuffer([]byte{})
	writeString(obj, fmt.Sprintf("[username:+86%s@%s]", j.Account, justalk))
	writeString(obj, "<UnifiedSession>")
	obj.Write([]byte{0x00, 0x00, 0x00, 0x06})
	writeKVS(obj, "__app", "2")
	writeKVS(obj, "ClientId", j.getClientId())
	writeKVS(obj, "DeviceId", j.DeviceId)
	writeKVS(obj, "__domain", domain)
	writeKVS(obj, "ForceFlag", "1")
	writeKVS(obj, "DeviceInfo.CC", j.getDeviceInfoCC())

	buf := bytes.NewBuffer([]byte{})
	buf.Write([]byte{0x00})
	_ = binary.Write(buf, binary.BigEndian, j.getPkgIndex())
	buf.Write([]byte{0x00, 0x00, 0x00, 0x05})
	writeKVS(buf, "domain", domain)
	writeKVS(buf, "id", "AccountEntry")
	writeKVS(buf, "pwd", j.SipPwd)
	writeKVB(buf, "__magic", j.getMagic())
	writeKVS(buf, "__locate", "direct")
	// cmd
	writeString(buf, "loginSession.AccountEntry.Account")
	// obj
	writeObj(buf, obj)

	key := getRand()
	outData, _, _, _, _ := crypt(buf.Bytes(), [0x10]byte{}, key, key, 0)

	bufHead := bytes.NewBuffer([]byte{})
	_ = binary.Write(bufHead, binary.BigEndian, j.getSeqNo1())
	ticks := uint16(j.getCurTicks())
	_ = binary.Write(bufHead, binary.BigEndian, ticks)
	_ = binary.Write(bufHead, binary.BigEndian, j.serverTicks)
	bufHead.Write([]byte{0x00, 0x10})
	bufHead.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
	bufHead.Write([]byte{0xFF, 0xFF})
	_ = binary.Write(buf, binary.BigEndian, j.getSeqNo2())
	bufHead.Write([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00})

	bufHead.Write([]byte{0xff, 0x00})
	_ = binary.Write(bufHead, binary.BigEndian, key)
	bufHead.Write(outData)

	j.sendTcp(bufHead.Bytes())
}

func (j *Jegotrip) registerAlive() {
	obj := bytes.NewBuffer([]byte{})
	writeString(obj, "102286_157468") // 102286_157468 102286_365154 102286_360768
	writeString(obj, "<UnifiedSession>")
	_ = binary.Write(obj, binary.BigEndian, tools.TimestampEx())
	_ = binary.Write(obj, binary.BigEndian, int32(0xb4))

	buf := bytes.NewBuffer([]byte{})
	buf.Write([]byte{0x00})
	_ = binary.Write(buf, binary.BigEndian, j.getPkgIndex())
	buf.Write([]byte{0x00, 0x00, 0x00, 0x06})
	writeKVS(buf, "domain", domain)
	writeKVS(buf, "id", "AccountAlive")
	writeKVS(buf, "token", "M505ce37e7893c96bb637dbcfb27394f3T1589034793DHKBHK30319147E5D701")
							//   M579b59f307998179fd8731c4f3dc0fcfT1589025634DHKBHK3030C4BE74F920
							//   Md2ac289f2322a04c5981a7d50de31b5cT1589026800DHKBHK303011D5F602B9
							//   M505ce37e7893c96bb637dbcfb27394f3T1589034793DHKBHK30319147E5D701
	writeKVB(buf, "__magic", j.getMagic())
	writeKVS(buf, "__locate", "direct")
	writeKVS(buf, "accountEntry", "AccountEntry:sarc -h 3031 -p 98;sarc -h 3030 -p 98;sarc -h 3200 -p 98;sarc -h 3201 -p 98;")
	                        // cmd
	writeString(buf, "registerAlive.AccountAlive.Account")
	// data
	writeObj(buf, obj)

	var key uint32
	if j.enKey1 == 0 || j.enKey2 == 0 {
		j.enKey1 = getRand()
		j.enKey2 = j.enKey1
		key = j.enKey1
	}

	var outData []byte
	outData, j.enKeyBuf, j.enKey1, j.enKey2, j.enLen = crypt(buf.Bytes(), j.enKeyBuf, j.enKey1, j.enKey2, j.enLen)
	finallyData := bytes.NewBuffer([]byte{})
	finallyData.Write([]byte{0xff, 0xff, 0x00})
	if key != 0 {
		_ = binary.Write(finallyData, binary.BigEndian, key)
	}
	finallyData.Write(outData)

	j.sendTcp(finallyData.Bytes())
}
