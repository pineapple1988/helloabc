package jegotrip

const (
	pkgName = "com.cmi.jegotrip"
	domain  = "102286"
	justalk = "102286.cloud.justalk.com"
)
