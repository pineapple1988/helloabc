package CZB

import (
	"awesome/utils"
	"net/http"
	"net/http/cookiejar"
	"time"
)

type Account struct {
	PhoneNumber      string `json:"phoneNumber"`
	CardNo           string `json:"cardNo"`
	LoginPwd         string `json:"loginPwd"`
	PayPwd           string `json:"payPwd"`
	Tls              TLS    `json:"tls"`
}

func NewAccount(phoneNumber, loginPwd, payPwd string) *Account {
	a := &Account{
		PhoneNumber: phoneNumber,
		LoginPwd:    loginPwd,
		PayPwd:      payPwd,
		Tls:         TLS{},
	}

	return a
}

func (a *Account) Save() {
	path := "./bin/" + a.PhoneNumber + ".json"
	utils.SaveJson2File(path, a)
}

type WorkGroup struct {
	http.Client
	Acc *Account
	randomKey         string
	newMobileFlag     string
	faceAuthLoginFlag string
	redisId           string
	postURLFull       []string
	PostURL           []string
	ServerIp          []string
}

func New(acc *Account) *WorkGroup {
	w := &WorkGroup{
		Acc: acc,
	}
	jar, _ := cookiejar.New(nil)
	//u, _ := url.Parse("http://127.0.0.1:8888")
	w.Client = http.Client{
		Transport: &http.Transport{
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			//DisableKeepAlives:   true,
		},
		Timeout: time.Second * 10,
		Jar:     jar,
	}
	return w
}