package CZB

import (
	"awesome/utils"
	"awesome/utils/log2"
	"compress/gzip"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"github.com/go-http-utils/headers"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

func (w *WorkGroup) post(u string, query *map[string]string, header *map[string]string, body interface{}, needEncrypt bool) []byte {
	myUrl, err := url.Parse(u)
	if err != nil {
		log2.Errorf("post url.Parse url=%s error=%+v", u, err)
		return nil
	}
	myQuery := myUrl.Query()
	// 添加公共query
	myQuery.Set("app", "ebank")
	myQuery.Set("o", "i")
	// 添加自定义query
	for key, value := range *query {
		myQuery.Set(key, value)
	}
	myUrl.RawQuery = myQuery.Encode()

	var postBody []byte
	switch body.(type) {
	case []byte:
		postBody = body.([]byte)
	case string:
		postBody = []byte(strings.ReplaceAll(body.(string), "+", "%20"))
		//fmt.Println(string(postBody))
	}

	if needEncrypt {
		// 进行aes加密
		postBody = utils.AesCBCEncryptWithPkcs7Padding(postBody, w.Acc.Tls.clientKey, w.Acc.Tls.clientIv)
	}

	postStr := base64.StdEncoding.EncodeToString(postBody)

	sign := ""
	if needEncrypt {
		hmacSha1 := hmac.New(sha1.New, w.Acc.Tls.clientHmacKey)
		hmacSha1.Write([]byte(postStr))
		sign = base64.StdEncoding.EncodeToString(hmacSha1.Sum(nil))
	}

	w.postURLFull = append(w.postURLFull, myUrl.String())
	w.PostURL = append(w.PostURL, myUrl.Scheme + "://" + myUrl.Host + myUrl.Path)

	addrs, err := net.LookupHost(myUrl.String())
	if err != nil {
		log2.Errorf("post net.LookupHost url=%s, error=%+v", myUrl.String(), err)
	} else {
		w.ServerIp = append(w.ServerIp, addrs[0])
	}

	req, err := http.NewRequest("POST", myUrl.String(), strings.NewReader(postStr))
	if err != nil {
		log2.Errorf("post http.NewRequest url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	// 添加公共header
	req.Header.Set(headers.UserAgent, w.getUserAgent())
	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.AcceptEncoding, "gzip")
	// 添加自定义header
	for key, value := range *header {
		req.Header.Set(key, value)
	}
	// 添加header
	if w.Acc.Tls.sessionId != "" {
		req.Header.Set(headerXEmpCookie, w.getXEmpCookie())
	}
	if w.redisId != "" {
		req.Header.Set(headerXEmpRedis, w.redisId)
	}
	if sign != "" {
		req.Header.Set(headerXEMPSignature, sign)
	}

	resp, err := w.Do(req)
	if err != nil {
		log2.Errorf("post w.Do url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	// 获取新的redisId
	if redisId := resp.Header.Get(headerSetEmpRedis); redisId != "" {
		w.redisId = redisId
	}

	// 如果是gzip需要解压
	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			log2.Errorf("post gzip.NewReader url=%s, error=%+v", myUrl.String(), err)
			return nil
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		log2.Errorf("post ioutil.ReadAll url=%s, error=%+v", myUrl.String(), err)
		return nil
	}

	_ = resp.Body.Close()

	encrypted, _ := strconv.ParseBool(resp.Header.Get(headerXEmpEncrypted))
	if encrypted {
		respBody, err = base64.StdEncoding.DecodeString(string(respBody))
		if err != nil {
			log2.Errorf("post base64 Decode respBody url=%s, error=%+v", myUrl.String(), err)
			return nil
		}
		// 解密操作
		respBody = utils.AesCBCDecryptWithPkcs7Unpadding(respBody, w.Acc.Tls.serverKey, w.Acc.Tls.serverIv)

	}

	return respBody
}

// 握手
func (w *WorkGroup) HandShake() bool {
	w.Acc.Tls.clientHelloBody = nil
	w.Acc.Tls.serverHelloBody = nil
	w.Acc.Tls.clientKeyExBody = nil
	w.Acc.Tls.serverKeyExBody = nil

	ret := false
	if len(w.Acc.Tls.ServerRSAPubKey) > 0 {
		ret = w.Acc.Tls.clientHelloAndKeyExchange(w)
	} else {
		if w.Acc.Tls.clientHelloRequest(w) {
			ret = w.Acc.Tls.sendClientKeyExchange(w)
		}
	}
	w.Acc.Save()

	return ret
}

