package utils

import (
	"crypto/md5"
	"fmt"
)

func MD5(b []byte) string {
	ctx := md5.New()
	_, err := ctx.Write(b)
	if err != nil {
		return ""
	}

	return fmt.Sprintf("%x", ctx.Sum(nil))
}