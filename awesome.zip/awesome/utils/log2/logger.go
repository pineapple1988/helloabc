package log2

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os"
)

const (
	infoPrefix  = "[INFO ] - "
	errorPrefix = "[ERROR] - "
)

var (
	logInfo  = log.New(os.Stdout, infoPrefix, log.LstdFlags|log.Lmicroseconds)
	logError = log.New(os.Stdout, errorPrefix, log.LstdFlags|log.Lmicroseconds|log.Llongfile)
)

// Info 普通日志
func Info(log string) {
	_ = logInfo.Output(2, log)
}

// Infof 普通日志
func Infof(logFmt string, logs ...interface{}) {
	_ = logInfo.Output(2, fmt.Sprintf(logFmt, logs...))
}

// Error 错误日志
func Error(log string) {
	_ = logError.Output(2, log)
}

// Errorf 错误日志
func Errorf(logFmt string, logs ...interface{}) {
	_ = logError.Output(2, fmt.Sprintf(logFmt, logs...))
}


func InfoJson(log string) {
	var dst bytes.Buffer
	if err := json.Indent(&dst, []byte(log), "", "\t"); err != nil {
		Errorf("json.Indent err = %+v", err)
	}
	_ = logInfo.Output(2, dst.String())
}