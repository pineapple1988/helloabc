package utils

import (
	"crypto/aes"
	"crypto/cipher"
)

// AES CBC加密, 使用PKCS7填充
func AesCBCEncryptWithPkcs7Padding(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)

	in = pkcs7Pad(in, c.BlockSize())
	out := make([]byte, len(in))

	e := cipher.NewCBCEncrypter(c, iv)
	e.CryptBlocks(out, in)

	return out
}

// AES CBC解密, 并去除PKCS7填充
func AesCBCDecryptWithPkcs7Unpadding(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)
	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}
