package utils

import (
	"fmt"
	"testing"
)

func TestMD5(t *testing.T) {
	fmt.Println( MD5([]byte(`["AlipayWallet"]`)))
}
