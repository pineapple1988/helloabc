package utils

import (
	"awesome/utils/log2"
	"strconv"
	"strings"
)

// 型号					屏幕尺寸	分辨率（pt）	Reader	分辨率（px）	 渲染后（px）  PPI
// iPhone 5/5S/5C/SE	4.0寸	320 x 568	@2x	    640 x 1136	 空	         326
// iPhone 6/6S/7/8		4.7寸	375 x 667	@2x	    750 x 1334	 空	         326
// iPhone 6/6S/7/8 Plus	5.5寸	414 x 736	@3x	    1242 x 2208	 1080 x 1920 401
// iPhone X/XS			5.8寸	375 x 812	@3x	    1125 x 2436	 空	         458
// iPhone XR			6.1寸	414 x 896	@2x	    828 x 1792	 空	         326
// iPhone XS Max		6.5寸	414 x 896	@3x	    1242 x 2688	 空	         458

// iPhone6s以下不能升级iOS13
// https://www.theiphonewiki.com/wiki/Kernel
// https://www.theiphonewiki.com/wiki/Models
type CPU struct {
	Name string `json:"name"`
	Core int32  `json:"core"`
}

type iPhone struct {
	Name           string  `json:"name"`
	InternalName   string  `json:"internalName"`
	SizePt         string  `json:"sizePt"`
	SizePx         string  `json:"sizePx"`
	PhysicalMemory int64   `json:"physicalMemory"`
	DiskSpace      []int64 `json:"diskSpace"`
	Cpu            CPU     `json:"CPU"`
}

type iOS struct {
	KernelVersion string `json:"kernelVersion"`
	Uname         string `json:"uname"`
	Timestamp     int64  `json:"timestamp"`
}

var iPhoneMap map[string]iPhone
var model []string
var iOSMap map[string]iOS

func init() {
	// 系统版本直接使用最新的
	iOSMap = map[string]iOS{
		"11.3": {
			KernelVersion: "17.5.0",
			Uname:         "Darwin Kernel Version 17.5.0: Tue Mar 13 21:32:11 PDT 2018; root:xnu-4570.52.2~8/RELEASE_ARM64_",
			Timestamp:     1836122112,
		},
		"12.0": {
			KernelVersion: "18.0.0",
			Uname:         "Darwin Kernel Version 18.0.0: Fri Aug 10 20:58:13 PDT 2018; root:xnu-4903.203.1~1/RELEASE_ARM64_",
		},
		"12.1": {
			KernelVersion: "18.2.0",
			Uname:         "Darwin Kernel Version 18.2.0: Mon Oct 8 08:27:41 PDT 2018; root:xnu-4903.223.3~2/RELEASE_ARM64_",
		},
		"12.2": {
			KernelVersion: "18.5.0",
			Uname:         "Darwin Kernel Version 18.5.0: Wed Mar 13 15:19:12 PDT 2019; root:xnu-4903.253.2~6/RELEASE_ARM64_",
		},
		"12.3": {
			KernelVersion: "18.6.0",
			Uname:         "Darwin Kernel Version 18.6.0: Thu Apr 25 21:37:28 PDT 2019; root:xnu-4903.263.2~1/RELEASE_ARM64_",
		},
		"12.4.2": {
			KernelVersion: "18.7.0",
			Uname:         "Darwin Kernel Version 18.7.0: Mon Aug 19 22:24:08 PDT 2019; root:xnu-4903.272.1~1/RELEASE_ARM64_",
			Timestamp:     1871347712,
		},
	}

	// A9  S8000 (Manufactured by Samsung Electronics)
	//	   S8003 (Manufactured by TSMC)
	// A10 T8010
	// A11 T8015
	// A12 T8020
	// A13 T8030
	iPhone6s := iPhone{
		Name:           "iPhone 6s",
		InternalName:   "N71mAP",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128,
		},
		Cpu: CPU{
			Name: "S8003",
			Core: 2,
		},
	}
	iPhone6sPlus := iPhone{
		Name:           "iPhone 6s Plus",
		InternalName:   "N66mAP",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128,
		},
		Cpu: CPU{
			Name: "S8003",
			Core: 2,
		},
	}
	iPhoneSE := iPhone{
		Name:           "iPhone SE",
		InternalName:   "N69AP",
		SizePt:         "320*568",
		SizePx:         "640*1136",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64,
		},
		Cpu: CPU{
			Name: "S8003",
			Core: 2,
		},
	}

	iPhone7 := iPhone{
		Name:           "iPhone 7",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 32, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8010",
			Core: 2,
		},
	}
	iPhone7Plus := iPhone{
		Name:           "iPhone 7 Plus",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 32, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8010",
			Core: 2,
		},
	}
	// todo 测试所有iphone机型中的核心数
	// iPhone8以后的手机没有进行测试 2+4 4个能效核心
	iPhone8 := iPhone{
		Name:           "iPhone 8",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 11024 * 024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8015",
			Core: 2,
		},
	}
	iPhone8Plus := iPhone{
		Name:           "iPhone 8 Plus",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8015",
			Core: 2,
		},
	}
	iPhoneX := iPhone{
		Name:           "iPhone X",
		SizePt:         "375*812",
		SizePx:         "1125*2436",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8015",
			Core: 2,
		},
	}

	iPhoneXS := iPhone{
		Name:           "iPhone XS",
		SizePt:         "375*812",
		SizePx:         "1125*2436",
		PhysicalMemory: 1024 * 1024 * 1024 * 4,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneXR := iPhone{
		Name:           "iPhone XR",
		SizePt:         "414*896",
		SizePx:         "828*1792",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneXSMAX := iPhone{
		Name:           "iPhone XS MAX",
		SizePt:         "414*896",
		SizePx:         "1242*2688",
		PhysicalMemory: 1024 * 1024 * 1024 * 4,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		Cpu: CPU{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneMap = make(map[string]iPhone, 0x10)
	iPhoneMap["iPhone8,1"] = iPhone6s

	iPhoneMap["iPhone8,2"] = iPhone6sPlus

	iPhoneMap["iPhone8,4"] = iPhoneSE

	iPhone7.InternalName = "D10AP"
	iPhoneMap["iPhone9,1"] = iPhone7

	iPhone7.InternalName = "D101AP"
	iPhoneMap["iPhone9,3"] = iPhone7

	iPhone7Plus.InternalName = "D11AP"
	iPhoneMap["iPhone9,2"] = iPhone7Plus

	iPhone7Plus.InternalName = "D111AP"
	iPhoneMap["iPhone9,4"] = iPhone7Plus

	iPhone8.InternalName = "D20AP"
	iPhoneMap["iPhone10,1"] = iPhone8

	iPhone8.InternalName = "D201AP"
	iPhoneMap["iPhone10,4"] = iPhone8

	iPhone8Plus.InternalName = "D21AP"
	iPhoneMap["iPhone10,2"] = iPhone8Plus

	iPhone8Plus.InternalName = "D211AP"
	iPhoneMap["iPhone10,5"] = iPhone8Plus

	iPhoneX.InternalName = "D22AP"
	iPhoneMap["iPhone10,3"] = iPhoneX

	iPhoneX.InternalName = "D221AP"
	iPhoneMap["iPhone10,6"] = iPhoneX

	iPhoneXR.InternalName = "N841AP"
	iPhoneMap["iPhone11,8"] = iPhoneXR

	iPhoneXS.InternalName = "D321AP"
	iPhoneMap["iPhone11,2"] = iPhoneXS

	iPhoneXSMAX.InternalName = "D331pAP"
	iPhoneMap["iPhone11,6"] = iPhoneXSMAX

	// 暂时只加入这些，不使用带faceId的iphone
	model = []string{
		"iPhone8,1",
		"iPhone8,2",
		"iPhone8,4",
		"iPhone9,1",
		"iPhone9,3",
		"iPhone9,2",
		"iPhone9,4",
		"iPhone10,1",
		"iPhone10,4",
		"iPhone10,2",
		"iPhone10,5",
	}
}

// 只存储跟硬件相关的讯息，软件生成的不放入这个里面
type IosDevice struct {
	IMEI               string `json:"imei"`
	IMSI               string `json:"imsi"`
	IDFA               string `json:"idfa"`
	IDFV               string `json:"idfv"`
	SysVer             string `json:"sysVer"`
	Model              string `json:"model"` // iPhone9,3
	Name               string `json:"name"`  // jj的 iPhone
	BluetoothMac       string `json:"bluetoothMac"`
	WifiMac            string `json:"wifiMac"`
	WifiName           string `json:"wifiName"`
	OtherMac           string `json:"otherMac"`
	RealPhysicalMemory int64  `json:"realPhysicalMemory"` // 实际内存大小
	PhysicalMemory     int64  `json:"physicalMemory"`     // 规格内存大小
	RealDiskSpace      int64  `json:"realDiskSpace"`      // 实际存储大小
	DiskSpace          int64  `json:"diskSpace"`          // 规格存储大小
	DocNode            int32  `json:"docNode"`            // 文件inode /var/mobile/Containers/Data/Application/26B7CB66-933D-4E8A-A432-49B82C115F56/Documents
	PreNode            int32  `json:"preNode"`            // 文件inode /var/mobile/Containers/Data/Application/26B7CB66-933D-4E8A-A432-49B82C115F56/Documents/Preferences
	En0Ipv6            string `json:"en0Ipv6"`
	En0Ipv4            string `json:"en0Ipv4"`
	En2Ipv6            string `json:"en2Ipv6"`
	En2Ipv4            string `json:"en2Ipv4"`
	Awdl0Ipv6          string `json:"awdl0Ipv6"`
	Utun0Ipv6          string `json:"utun0Ipv6"`
}

// 使用了ios12最新的版本
func NewSysVersion() string {
	return "12.4.2"
}

func NewModel() string {
	return model[RandIntn(len(model))]
}
func NewName() string {
	return RandStringNoNum(RandBetween(2, 6)) + "的 iPhone"
}

func width(size string) int {
	i, err := strconv.Atoi(strings.Split(size, "*")[0])
	if err != nil {
		return 0
	}
	return i
}
func height(size string) int {
	i, err := strconv.Atoi(strings.Split(size, "*")[1])
	if err != nil {
		return 0
	}
	return i
}

func (i *IosDevice) NewWifiName() string {
	brand := []string{
		"TP-Link",
		"Tenda",
		"MERCURY",
	}
	// wifimac后6位
	s := strings.ReplaceAll(i.WifiMac, ":", "")
	s = s[len(s)-6:]
	s = strings.ToUpper(s)

	return brand[RandIntn(len(brand))] + "_" + s
}
func (i *IosDevice) NewPhysicalMemory() int64 {
	return iPhoneMap[i.Model].PhysicalMemory
}

func (i *IosDevice) NewDiskSpace() int64 {
	return iPhoneMap[i.Model].DiskSpace[RandIntn(len(iPhoneMap[i.Model].DiskSpace))]
}

func (i *IosDevice) PhoneModel() string {
	return iPhoneMap[i.Model].Name
}

func (i *IosDevice) ScreenPt() string {
	return iPhoneMap[i.Model].SizePt
}

func (i *IosDevice) ScreenPx() string {
	return iPhoneMap[i.Model].SizePx
}

func (i *IosDevice) ScreenWidthPt() int {
	phone := iPhoneMap[i.Model]
	return width(phone.SizePt)
}
func (i *IosDevice) ScreenHeightPt() int {
	phone := iPhoneMap[i.Model]
	return height(phone.SizePt)
}

func (i *IosDevice) ScreenWidthPx() int {
	phone := iPhoneMap[i.Model]
	return width(phone.SizePx)
}
func (i *IosDevice) ScreenHeightPx() int {
	phone := iPhoneMap[i.Model]
	return height(phone.SizePx)
}

func (i *IosDevice) Mcc() string {
	return i.IMSI[:3]
}

func (i *IosDevice) Mnc() string {
	return i.IMSI[3:5]
}

func (i *IosDevice) Carrier() string {
	if len(i.IMSI) > 0 {
		mcc := i.IMSI[:3]
		mnc := i.IMSI[3:5]
		if mcc != "460" {
			log2.Errorf("mcc != 460开始不是中国的电话卡, %+v", mcc)
			return ""
		}

		// 中国移动系统使用00、02、04、07
		// 中国联通GSM系统使用01、06、09
		// 中国电信CDMA系统使用03、05、电信4G使用11
		// 中国铁通系统使用20
		switch mnc {
		case "00", "02", "04", "07":
			return "中国移动"
		case "01", "06", "09":
			return "中国联通"
		case "03", "05", "11":
			return "中国电信"
		default:
			log2.Errorf("未知mnc，%+v", mnc)
			return ""
		}
	} else {
		log2.Error("imsi == nil")
		return ""
	}
}

func (i *IosDevice) Uname() string {
	return iOSMap[i.SysVer].Uname + iPhoneMap[i.Model].Cpu.Name
}

func (i *IosDevice) CpuCore() int32 {
	return iPhoneMap[i.Model].Cpu.Core
}

func (i *IosDevice) CpuFreq() int32 {
	return 0
}

func (i *IosDevice) InternalName() string {
	return iPhoneMap[i.Model].InternalName
}

func (i *IosDevice) KernelVersion() string {
	return iOSMap[i.SysVer].KernelVersion
}

func (i *IosDevice) KernelTimestamp() int64 {
	return iOSMap[i.SysVer].Timestamp
}
