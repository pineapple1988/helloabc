package utils

import (
	"fmt"
	"testing"
)

func TestTimefmt(t *testing.T) {
	fmt.Println(TimeFmt())
	fmt.Println(TimeFmtEx0())
	fmt.Println(TimeFmtEx1())
	fmt.Println(TimeFmtEx2())
}
