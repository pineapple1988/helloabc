package utils

import (
	"bytes"
	"github.com/satori/go.uuid"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
	"io/ioutil"
	"reflect"
)

// 反转切片
func ReverseSlice(s interface{}) {
	size := reflect.ValueOf(s).Len()
	if size <= 0 {
		return
	}

	swap := reflect.Swapper(s)
	for i, j := 0, size-1; i < j; i, j = i+1, j-1 {
		swap(i, j)
	}
}

// NewUUID 生成一个新的UUID
func NewUUID() string {
	u := uuid.NewV4()
	return u.String()
}

func GBK2UTF8(s []byte) ([]byte, error) {
	t := transform.NewReader(bytes.NewReader(s), simplifiedchinese.GBK.NewDecoder())
	d, err := ioutil.ReadAll(t)
	if err != nil {
		return nil, err
	}

	return d, nil
}