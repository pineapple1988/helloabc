package utils

import "crypto/des"

// TripleDESECBEncrypt 3DESECB加密, 使用PKCS7填充
func TripleDESECBEncrypt(in, key []byte) []byte {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil
	}

	in = pkcs7Pad(in, c.BlockSize())
	var out []byte
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out
}

func TripleDESECBDecrypt(in, key []byte) []byte {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil
	}

	if len(in) % c.BlockSize() != 0 {
		return nil
	}

	var out []byte
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return pkcs7Unpad(out)
}
