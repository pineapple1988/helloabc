package utils

import (
	"awesome/github.com/tjfoc/gmsm/sm2"
	"awesome/github.com/tjfoc/gmsm/sm4"
	"awesome/utils/cipher2"
	"math/big"
)

func SM2Encrypt(in []byte, x, y string) []byte {
	pub := sm2.PublicKey{
		Curve: sm2.P256Sm2(),
	}
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	out, err := pub.Encrypt(in)
	if err != nil {
		return nil
	}

	return out
}

// pkcs1v5填充
func SM4ECBEncrypt(in, key[]byte) []byte {
	s4, err := sm4.NewCipher(key)
	if err != nil {
		return nil
	}

	in = pkcs7Pad(in, s4.BlockSize())
	out := make([]byte, len(in))

	c := cipher2.NewECBEncrypter(s4)
	c.CryptBlocks(out, in)

	return out
}

func SM4ECBDecrypt(in, key[]byte) []byte {
	s4, err := sm4.NewCipher(key)
	if err != nil {
		return nil
	}

	out := make([]byte, len(in))

	c := cipher2.NewECBDecrypter(s4)
	c.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}
