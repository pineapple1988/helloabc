package utils


/*
#include <stdint.h>

#define HashEverythingLimit 96

#define HashNextFourUniChars(accessStart, accessEnd, pointer) \
    {result = result * 67503105 + (accessStart 0 accessEnd) * 16974593  + (accessStart 1 accessEnd) * 66049  + (accessStart 2 accessEnd) * 257 + (accessStart 3 accessEnd); pointer += 4;}

#define HashNextUniChar(accessStart, accessEnd, pointer) \
    {result = result * 257 + (accessStart 0 accessEnd); pointer++;}

typedef unsigned long long CFHashCode;

uint16_t __CFCharToUniCharTable[256] = {
    0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
    16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31,
    32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,
    48,  49,  50,  51,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,  62,  63,
    64,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
    80,  81,  82,  83,  84,  85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,
    96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
    112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127,
    128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
    144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
    176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
    192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
    208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,
    224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
    240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255
};

CFHashCode __CFStrHashEightBit(const uint8_t *cContents, int len)
{
    CFHashCode result = len;
    if (len <= HashEverythingLimit)
    {
        const uint8_t *end4 = cContents + (len & ~3);
        const uint8_t *end = cContents + len;
        while (cContents < end4)
            HashNextFourUniChars(__CFCharToUniCharTable[cContents[, ]], cContents);
        while (cContents < end)
            HashNextUniChar(__CFCharToUniCharTable[cContents[, ]], cContents);
    }
    else
    {
        const uint8_t *contents, *end;
        contents = cContents;
        end = contents + 32;
        while (contents < end)
            HashNextFourUniChars(__CFCharToUniCharTable[contents[, ]], contents);
        contents = cContents + (len >> 1) - 16;
        end = contents + 32;
        while (contents < end)
            HashNextFourUniChars(__CFCharToUniCharTable[contents[, ]], contents);
        end = cContents + len;
        contents = end - 32;
        while (contents < end)
            HashNextFourUniChars(__CFCharToUniCharTable[contents[, ]], contents);
    }
    return result + (result << (len & 31));
}

CFHashCode __CFStringHash(uint8_t *contents, int len)
{
    return __CFStrHashEightBit(contents, len);
}
 */
import "C"

func CFStringHash(str string) uint64 {
	buf := []byte(str)
	result := C.__CFStringHash((*C.uint8_t)(&buf[0]), C.int(len(buf)))
	return uint64(result)
}