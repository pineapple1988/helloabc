package utils

import (
	"awesome/utils/log2"
	"encoding/json"
	"io/ioutil"
	"os"
)

func Exist(path string) bool {
	_, err := os.Stat(path)
	if err != nil && os.IsNotExist(err) {
		return false
	}
	return true
}

func LoadJsonFromFile(path string, v interface{}) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		log2.Errorf("LoadJsonFromFile ioutil.ReadFile err %+v.", err)
	}

	if err = json.Unmarshal(data, v); err != nil {
		log2.Errorf("LoadJsonFromFile json.Unmarshal err %+v.", err)
	}
}

func SaveJson2File(path string, v interface{}) {
	infoBytes, err := json.MarshalIndent(v, "", "\t")
	if err != nil {
		log2.Errorf("SaveJson2File json.MarshalIndent err %+v.", err)
	}

	err = ioutil.WriteFile(path, infoBytes, 0644)
	if err != nil {
		log2.Errorf("SaveJson2File ioutil.WriteFile err %+v.", err)
	}
}
