package utils

import (
	"encoding/hex"
	"fmt"
	"testing"
)


func TestRotateLeft(t *testing.T) {
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 1))
	fmt.Println(hex.Dump(RotateLeft([]byte{0x6c, 0x24, 0x3b, 0x2c}, 2)))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 5))
}

func TestRotateRight(t *testing.T) {
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 1))
	fmt.Println(hex.Dump(RotateRight([]byte{0x6c, 0x24, 0x3b, 0x2c}, 2)))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 5))
}