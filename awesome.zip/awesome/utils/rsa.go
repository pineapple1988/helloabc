package utils

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"log"
)
import "crypto/rand"

// RSAEncryptWithPKCS1v15Padding RSA加密, 并用PKCS1, V1.5填充
func RSAEncryptWithPKCS1v15Padding(plain []byte, key *rsa.PublicKey) []byte {
	MaxBlockSize := key.Size() - 11

	var buf, toEncrypt, encrypted []byte
	var err error

	toEncrypt = plain
	for {
		if len(plain) == 0 {
			break
		} else if len(plain) <= MaxBlockSize {
			toEncrypt = plain
			plain = []byte{}
		} else {
			toEncrypt = plain[:MaxBlockSize]
			plain = plain[MaxBlockSize:]
		}

		encrypted, err = rsa.EncryptPKCS1v15(rand.Reader, key, toEncrypt)
		if err != nil {
			return nil
		}

		buf = append(buf, encrypted...)
	}

	return buf
}


func DecodePublicKeyPEMData(pemData []byte) *rsa.PublicKey {
	block, _ := pem.Decode(pemData)
	if block == nil || block.Type != "PUBLIC KEY" {
		log.Fatal("failed to decode PEM block containing public key")
	}
	if key, err := x509.ParsePKIXPublicKey(block.Bytes); err == nil{
		return key.(*rsa.PublicKey)
	}

	return nil
}

func X509RsaEncrypt(plain []byte, key []byte) []byte {
	cert, err := x509.ParseCertificate(key)
	if err != nil {
		return nil
	}
	pub := cert.PublicKey.(*rsa.PublicKey)

	return RSAEncryptWithPKCS1v15Padding(plain, pub)
}