package utils

func RotateLeft(buf []byte, count int) []byte {
	count = count % len(buf)

	tmpAll := make([]byte, len(buf))
	copy(tmpAll, buf)

	tmp := make([]byte, count)
	copy(tmp, tmpAll[:count])

	tmpAll = append(tmpAll[count:], tmp...)
	copy(buf, tmpAll)
	return buf
}

func RotateRight(buf []byte, count int) []byte {
	bufLen := len(buf)
	count = count % bufLen

	tmpAll := make([]byte, len(buf))
	copy(tmpAll, buf)

	tmp := make([]byte, count)
	copy(tmp, tmpAll[bufLen-count:])

	tmpAll = append(tmp, tmpAll[:bufLen-count]...)
	copy(buf, tmpAll)
	return buf
}