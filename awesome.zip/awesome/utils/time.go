package utils

import (
	"strings"
	"time"
)

// 时间格式化，秒级
// 20190930222716
func TimeFmt() string {
	return time.Now().Format("20060102150405")
}

// 时间格式化，毫秒级
// 20190930222716382
func TimeFmtEx0() string {
	return strings.ReplaceAll(time.Now().Format("20060102150405.000"), ".", "")
}

// 时间格式化
// 2019-09-30 22:27:16:382
func TimeFmtEx1() string {
	return strings.ReplaceAll(time.Now().Format("2006-01-02 15:04:05.000"), ".", ":")
}

// 时间格式化
// 2019.10.18.16:34:37.200
func TimeFmtEx2() string {
	return time.Now().Format("2006.01.02.15:04:05.000")
}

// 时间戳, 秒级
func Timestamp() uint32 {
	return uint32(time.Now().Unix())
}

// 时间戳, 毫秒级 13位
func TimestampEx() int64 {
	return time.Now().UnixNano() / 1000000
}

// 时间戳, 毫秒级 16位
func TimestampEx2() int64 {
	return time.Now().UnixNano() / 1000
}