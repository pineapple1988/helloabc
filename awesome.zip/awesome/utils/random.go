package utils

import (
	"fmt"
	"math/rand"
	"strings"
	"time"
)

func RandBytes(n int) []byte {
	r := make([]byte, n)
	for i := 0; i < n; i++ {
		r[i] = byte(RandInt31())
	}
	return r
}

func RandBetween(min, max int) int {
	if min > max || min == 0 || max == 0 {
		return 0
	}

	return RandIntn(max-min) + min
}

func RandIntn(n int) int {
	rand.Seed(time.Now().UnixNano())
	return rand.Intn(n)
}

func RandInt31() int32 {
	rand.Seed(time.Now().UnixNano())
	return rand.Int31()
}

func RandFloat(max float32) float32 {
	r := rand.Float32()
	for {
		if r > max {
			r -= max
		} else {
			return r
		}
	}

}

var rndBytesNoNum = []byte("abcdefghijklmnopqrstuvwsyzABCDEFGHIGKLMNOPQRSTUVWSYZ")
var rndBytesNoNumLen = len(rndBytesNoNum)
func RandStringNoNum(count int) string {
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytesNoNum[RandIntn(rndBytesNoNumLen)])
	}

	return string(buffer)
}


var rndBytes = []byte("0123456789abcdefghijklmnopqrstuvwsyz")
var rndBytesLen = len(rndBytes)

func RandString(count int) string {
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytes[RandIntn(rndBytesLen)])
	}

	return string(buffer)
}

var rndHexBytes = []byte("0123456789abcdef")
var rndHexBytesLen = len(rndHexBytes)
func RandHex(count int) string {
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndHexBytes[RandIntn(rndHexBytesLen)])
	}

	return string(buffer)
}

func RandHexNoZero(count int) string {
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndHexBytes[RandIntn(rndHexBytesLen-1)+1])
	}

	return string(buffer)
}

func NewMacAddress() string {
	var arr []string
	for i := 0; i < 6; i++ {
		n := RandIntn(255)
		if i == 0 && n%2 != 0 {
			n++
		}

		arr = append(arr, fmt.Sprintf("%.2x", n))
	}

	return strings.Join(arr, ":")
}

// 最高位不让为0
func NewHexNumber(count int) string {
	return RandHexNoZero(1) + RandHex(count-1)
}

