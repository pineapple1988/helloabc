package czb

import (
	"awesome/tools/log2"
)

const (
	urlDomain              = "http://nm.czbank.com:80"
	urlUpdateAdvertisement = "http://nm.czbank.com:80/ebank_s/doUpdateAdvertisement"
	urlGetPage             = "http://nm.czbank.com:80/test_s/get_page"
	urlRun                 = "http://nm.czbank.com:80/channel_s/run"
	bundleShortVersion     = "4.0.9"
	headerXEmpCookie       = "X-Emp-Cookie"
	headerXEMPSignature    = "X-EMP-Signature"
	headerXEmpEncrypted    = "X-Emp-Encrypted"
	pwdRsaPub              = "MIICnDCCAkagAwIBAgIJAK0CrBu+95jPMA0GCSqGSIb3DQEBBQUAMGoxCzAJBgNVBAYTAkNOMREwDwYDVQQIEwhaaGVKaWFuZzERMA8GA1UEBxMISGFuZ1pob3UxDzANBgNVBAoTBkNaQkFOSzENMAsGA1UECxMEVGVjaDEVMBMGA1UEAxMMQ1pCQU5LIEVCQU5LMB4XDTExMTEwOTAzMzcyMloXDTQxMTEwMTAzMzcyMlowajELMAkGA1UEBhMCQ04xETAPBgNVBAgTCFpoZUppYW5nMREwDwYDVQQHEwhIYW5nWmhvdTEPMA0GA1UEChMGQ1pCQU5LMQ0wCwYDVQQLEwRUZWNoMRUwEwYDVQQDEwxDWkJBTksgRUJBTkswWzANBgkqhkiG9w0BAQEFAANKADBHAkB5nRr6dKUY0mUmt+PS9X9v7PgQvB0/Wlhq0CuUlCcM+dK36EHmZKmpv01FRZL/nN5NSzBwevj4w62fQr7tJb8ZAgMBAAGjgc8wgcwwHQYDVR0OBBYEFN+JLAWV/1WBMb/rq5gcVRqH8tBWMIGcBgNVHSMEgZQwgZGAFN+JLAWV/1WBMb/rq5gcVRqH8tBWoW6kbDBqMQswCQYDVQQGEwJDTjERMA8GA1UECBMIWmhlSmlhbmcxETAPBgNVBAcTCEhhbmdaaG91MQ8wDQYDVQQKEwZDWkJBTksxDTALBgNVBAsTBFRlY2gxFTATBgNVBAMTDENaQkFOSyBFQkFOS4IJAK0CrBu+95jPMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADQQBq0lmrcVjATH5T15NbRDzwPeNfVRYJ5WZUFzG+nYlEYCsEPV4lTCdHe3dhLDvUgv8sKpXostvIdSfyJXfrBIYf"
)

var logger *log2.MyLog

func init() {
	logger = &log2.MyLog{Prefix: ""}
}
