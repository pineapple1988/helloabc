package czb

type login2Resp struct {
	ErrorStatus        string `json:"errorStatus"`
	ErrorNO            string `json:"errorNO"`
	ErrorMsg           string `json:"errorMsg"`
	Age                string `json:"age"`
	AntiMoney          string `json:"antiMoney"`
	AntiMoneyOutDate   string `json:"antiMoneyOutDate"`
	AntiTipFlag        string `json:"antiTipFlag"`
	AntiTipNum         string `json:"antiTipNum"`
	AntiexpirationDate string `json:"antiexpirationDate"`
	AntiissuedDate     string `json:"antiissuedDate"`
	Antioccupation     string `json:"antioccupation"`
	AntipostalAddress  string `json:"antipostalAddress"`
	Carfklimit         string `json:"carfklimit"`
	ChangeFlag         string `json:"changeFlag"`
	Cstno              string `json:"cstno"`
	CtfNo              string `json:"ctfNo"`
	CtfType            string `json:"ctfType"`
	CustomerAlias      string `json:"customerAlias"`
	CustomerID         string `json:"customerId"`
	CustomerName       string `json:"customerName"`
	EbankCsp           string `json:"ebankCsp"`
	FirstLogon         string `json:"firstLogon"`
	FirstLogonStatus   string `json:"firstLogonStatus"`
	Flag1              string `json:"flag1"`
	Flag2              string `json:"flag2"`
	Flag3              string `json:"flag3"`
	FlagRelated        string `json:"flag_related"`
	GiftTimes          string `json:"giftTimes"`
	Hceflag            string `json:"hceflag"`
	IfHasKey           string `json:"ifHasKey"`
	KeyAlg             string `json:"keyAlg"`
	KeyCn              string `json:"keyCn"`
	KeyEndDate         string `json:"keyEndDate"`
	KeyNo              string `json:"keyNo"`
	Keymode            string `json:"keymode"`
	LastDeviceName     string `json:"lastDeviceName"`
	LastlogTime        string `json:"lastlogTime"`
	LoginSessionID     string `json:"loginSessionId"`
	LoginStatus        string `json:"loginStatus"`
	LogonChange        string `json:"logon_change"`
	LogonMode          string `json:"logon_mode"`
	MainAcc            string `json:"mainAcc"`
	Mobile             string `json:"mobile"`
	NearExpireFlag     string `json:"nearExpireFlag"`
	NewBuluFlag        string `json:"newBuluFlag"`
	OpenFlag           string `json:"openFlag"`
	PifuFlag           string `json:"pifuFlag"`
	SetPuLongin        string `json:"setPuLongin"`
	ShPopFlag          string `json:"shPopFlag"`
	Tflag              string `json:"tflag"`
	Type               string `json:"type"`
	UnCertiAntiCtx     string `json:"unCertiAntiCtx"`
	UnCertiAntiFlag    string `json:"unCertiAntiFlag"`
	Usercode           string `json:"usercode"`
	UUIDNo             string `json:"uuidNo"`
	ValidateMsg        string `json:"validateMsg"`
	Zflag              string `json:"zflag"`
}

type transListResp struct {
	AccAlias   string `json:"AccAlias"`
	ErrorNo    string `json:"ErrorNo"`
	AcctNo     string `json:"acctNo"`
	CurrCode   string `json:"currCode"`
	EndDate    string `json:"endDate"`
	Func       string `json:"func"`
	IsClean    string `json:"isClean"`
	IsLastPage string `json:"isLastPage"`
	Items      []struct {
		ID             string `json:"id"`
		Money          string `json:"money"`
		Name           string `json:"name"`
		PurchaseAmount string `json:"purchaseAmount"`
		TitleName      string `json:"titleName"`
	} `json:"items"`
	MinAmt      string `json:"minAmt"`
	Msg         string `json:"msg"`
	OnClick     string `json:"onClick"`
	Page        string `json:"page"`
	StartDate   string `json:"startDate"`
	TotalIncome string `json:"totalIncome"`
	TotalPay    string `json:"totalPay"`
}

type cardListResp struct {
	AccState     string `json:"accState"`
	BranchName   string `json:"branchName"`
	CheckState   string `json:"checkState"`
	CtfNo        string `json:"ctfNo"`
	CustomerName string `json:"customerName"`
	Customerflag string `json:"customerflag"`
	EbankCsp     string `json:"ebankCsp"`
	EntranceFlag string `json:"entranceFlag"`
	Items        []struct {
		AccAlias    string `json:"accAlias"`
		AccName     string `json:"accName"`
		AccountNo   string `json:"accountNo"`
		AccountType string `json:"accountType"`
		Balanceable string `json:"balanceable"`
		CardType    string `json:"cardType"`
		CurrCode    string `json:"currCode"`
		ID          string `json:"id"`
		IsCheck     string `json:"isCheck"`
		SubAccType  string `json:"subAccType"`
	} `json:"items"`
	KeyAlg         string `json:"keyAlg"`
	KeyCn          string `json:"keyCn"`
	MainAcc        string `json:"mainAcc"`
	MobRegNode     string `json:"mobRegNode"`
	Mobile         string `json:"mobile"`
	Open23CardFlag string `json:"open23CardFlag"`
	Pageurl        string `json:"pageurl"`
}
