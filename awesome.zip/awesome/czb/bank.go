package czb

import (
	"awesome/tools"
	"awesome/tools/base"
	"encoding/base64"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"time"
)

// Bank 浙商银行
type Bank struct {
	Account  string         `json:"account"`
	LoginPwd string         `json:"loginPwd"`
	PayPwd   string         `json:"payPwd"`
	TLS      rytTLS         `json:"tls"`
	Client   *http.Client   `json:"-"`
	Jar      *cookiejar.Jar `json:"-"`
	Model    string         `json:"model"`
	SysVer   string         `json:"sysVer"`
	DeviceID string         `json:"deviceId"`
	ClientIP string         `json:"clientIp"`
	UUID     string         `json:"uuid"`
}

// New 创建一个全新的账号，生成随机的设备信息
func New(phoneNumber, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:  phoneNumber,
		LoginPwd: loginPwd,
		PayPwd:   payPwd,
		TLS:      rytTLS{},
		Model:    tools.NewModel(),
		SysVer:   tools.NewSysVersion(),
		DeviceID: tools.NewUUIDUpper(),
		ClientIP: tools.NewIPV4(),
	}

	return b
}

// Save 保存信息到文件
func (b *Bank) Save() {
	path := "./czb/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

func (b *Bank) userAgent() string {
	return fmt.Sprintf("%s %s (iPhone; iOS %s; zh_CN)", tools.UTF82ISO88591("浙商银行"), bundleShortVersion, b.SysVer)
}
func (b *Bank) getXEmpCookie() string {
	return fmt.Sprintf("_session_id=%s", b.TLS.sessionId)
}

func (b *Bank) pwdEncrypt(pwd string) string {
	pub, _ := base64.StdEncoding.DecodeString(pwdRsaPub)
	enPwd, err := tools.X509RsaEncrypt([]byte(pwd), pub)
	if err != nil {
		logger.Errorf("加密密码%s出现错误 err=%+v", pwd, err)
		return ""
	}

	return base64.StdEncoding.EncodeToString(enPwd)
}

// Login 登陆
func (b *Bank) Login() base.LoginResultCode {

	logger.Prefix = fmt.Sprintf("[CZB][%s]", b.Account)

	b.Jar, _ = cookiejar.New(nil)

	//u, _ := url.Parse("http://127.0.0.1:8888")
	b.Client = &http.Client{
		Transport: &http.Transport{
			//Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			//DisableKeepAlives:   true,
		},
		Timeout: time.Second * 20,
		Jar:     b.Jar,
	}
	if !b.handShake() {
		logger.Error("握手失败了！！！")
		return base.LoginResultFail
	}

	b.doUpdateAdvertisement()
	b.indexNew()
	b.getFirstPage()

	time.Sleep(time.Duration(rand.Int31n(3000)+2000) * time.Millisecond)
	b.newFirstRegisterPage()
	if b.UUID == "" {
		// 第一次登陆，先输入手机号
		time.Sleep(time.Duration(rand.Int31n(3000)+2000) * time.Millisecond)
		b.newRegisterUserInfo()
		b.newFirstMobileLogin() // 跳转到密码登陆界面
	}
	// 输入密码, 这里不会去做设备认证，设备认证方式有 支付密码+刷脸，U盾
	time.Sleep(time.Duration(rand.Int31n(3000)+2000) * time.Millisecond)
	login := b.login2()
	if login.ErrorNO == "000000" {
		logger.Info("登陆成功")
		// 保存数据
		b.UUID = login.UUIDNo
		return base.LoginResultSuccess
	}

	// 登陆密码错误
	if login.ErrorNO == "88003" {
		logger.Infof("登陆返回密码错误了 ErrorMsg=%s", login.ErrorMsg)
		return base.LoginResultFailWrongPwd
	}
	// 登陆出现未知错误
	logger.Errorf("登陆出现了错误 ErrorMsg=%s, ErrorNO=%s", login.ErrorMsg, login.ErrorNO)
	return base.LoginResultFail
}

// BillList 给定月份返回当前月份以及之前月份的账单
// startDate 开始时间 eg 20191012
// endDate   结束时间 eg 20200114
// page      当前页数 从1开始
// 时间范围不能超过100天
func (b *Bank) BillList(cardNO, startDate, endDate, page string) *transListResp {
	return b.getTransListByDate(cardNO, startDate, endDate, page)
}

// CardList 查询卡列表，获取到卡的UID
func (b *Bank) CardList() *cardListResp {
	return b.qryBankAccountSrvOp()
}
