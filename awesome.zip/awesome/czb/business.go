package czb

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm3"
	"bytes"
	"compress/gzip"
	"crypto/hmac"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/go-http-utils/headers"
	"io/ioutil"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

func (b *Bank) post(u string, query *url.Values, header *http.Header, body interface{}, needEncrypt bool) ([]byte, error) {
	url0, err := url.Parse(u)
	if err != nil {
		return nil, err
	}
	query0 := url0.Query()
	// 添加query
	if query != nil {
		for key, value := range *query {
			query0[key] = value
		}
	}
	url0.RawQuery = query0.Encode()

	var postBody []byte
	switch body.(type) {
	case []byte:
		postBody = body.([]byte)
	case string:
		postBody = []byte(strings.ReplaceAll(body.(string), "+", "%20"))
		//fmt.Println(string(postBody))
	}

	var sign string
	if needEncrypt {
		// 前面20个直接是0
		zero := []byte{
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		}
		postBody = append(zero, postBody...)
		// 进行sm4加密
		postBody, _ = tools.SM4CBCEncrypt(postBody, b.TLS.clientKey[:0x10], b.TLS.clientIv)
		// 增加序号
		b.TLS.serialN++
		buffer := bytes.NewBuffer([]byte{0x00})
		_ = binary.Write(buffer, binary.BigEndian, b.TLS.serialN)
		buffer.Write(postBody)
		postBody = buffer.Bytes()

		// 算sign
		hmacSm3 := hmac.New(sm3.New, b.TLS.clientHmacKey)
		hmacSm3.Write(postBody)
		hmacData := hmacSm3.Sum(nil)
		sign = base64.StdEncoding.EncodeToString(hmacData)

		// 拼接
		buffer = bytes.NewBuffer([]byte{})
		buffer.Write(hmacData)
		buffer.Write(postBody)
		postBody = buffer.Bytes()
	}

	postStr := base64.StdEncoding.EncodeToString(postBody)

	req, err := http.NewRequest("POST", url0.String(), strings.NewReader(postStr))
	if err != nil {
		return nil, err
	}
	if header != nil {
		req.Header = *header
	}

	req.Header.Set(headers.UserAgent, b.userAgent())
	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.AcceptEncoding, "gzip")
	if b.TLS.sessionId != "" {
		req.Header.Set(headerXEmpCookie, b.getXEmpCookie())
	}
	if sign != "" {
		req.Header.Set(headerXEMPSignature, sign)
	}

	resp, err := b.Client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	reader := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			return nil, err
		}
	}

	// 全部读出来
	respData, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}

	encrypted, _ := strconv.ParseBool(resp.Header.Get(headerXEmpEncrypted))
	if encrypted {
		respData, err = base64.StdEncoding.DecodeString(string(respData))
		if err != nil {
			return nil, err
		}
		// 前面0x20是验证签名，这里直接跳过了
		if len(respData) > 0x20 {
			respData = respData[0x20:]
		}
		// 解密操作
		respData, _ = tools.SM4CBCDecrypt(respData, b.TLS.serverKey[:0x10], b.TLS.serverIv)
	}

	return respData, nil
}

// 握手
func (b *Bank) handShake() bool {
	b.TLS.clientHelloBody = nil
	b.TLS.serverHelloBody = nil
	b.TLS.clientKeyExBody = nil
	b.TLS.serverKeyExBody = nil

	ret := false
	if len(b.TLS.ServerSM2PubKey) > 0 {
		ret = b.TLS.clientHelloAndKeyExchange(b)
	} else {
		if b.TLS.clientHelloRequest(b) {
			ret = b.TLS.sendClientKeyExchange(b)
		}
	}

	if ret {
		b.Save()
	}

	return ret
}

func (b *Bank) addBaseQuery() *url.Values {
	return &url.Values{
		"app":        {"ebank"},
		"o":          {"i"},
		"islogin":    {"0"},
		"ios7":       {"1"},
		"creditcard": {"false"},
	}
}

func (b *Bank) doUpdateAdvertisement() {
	query := b.addBaseQuery()
	query.Set("imageSizeinfo", "1")

	resp, err := b.post(urlUpdateAdvertisement, query, nil, "1=1", true)
	if err != nil {
		logger.Errorf("doUpdateAdvertisement post err=%+v", err)
		return
	}

	logger.Info("doUpdateAdvertisement >>>>>> " + string(resp))
}

func (b *Bank) indexNew() {
	query := b.addBaseQuery()

	values := &url.Values{}
	values.Set("name", "channels/index/xhtml/indexNew.xhtml")

	resp, err := b.post(urlGetPage, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("indexNew post err=%+v", err)
		return
	}

	logger.Info("indexNew >>>>>> " + string(resp))
}

func (b *Bank) getFirstPage() {
	query := b.addBaseQuery()

	values := &url.Values{}
	values.Set("id", "investment")
	values.Set("loginStatus", "0")
	values.Set("tranCode", "getFirstPage_wh")
	values.Set("isexit_wkhq", "0")

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("getFirstPage post err=%+v", err)
		return
	}

	logger.Info("getFirstPage >>>>>> " + string(resp))
}

func (b *Bank) newFirstRegisterPage() {
	query := b.addBaseQuery()

	values := &url.Values{}
	values.Set("name", "channels/register/xhtml/newfirstRegisterPage.xhtml")

	resp, err := b.post(urlGetPage, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("newFirstRegisterPage post err=%+v", err)
		return
	}

	logger.Info("newFirstRegisterPage >>>>>> " + string(resp))
}

func (b *Bank) newRegisterUserInfo() {
	query := b.addBaseQuery()

	// tranCode=newRegisterUserInfo&id=register&inMobile=19141941510&loginStatus=0&dideviceid=56F64FB1-C34A-4E7E-AE34-400A0277F4FA
	values := &url.Values{}
	values.Set("tranCode", "newRegisterUserInfo")
	values.Set("id", "register")
	values.Set("inMobile", b.Account)
	values.Set("loginStatus", "0")
	values.Set("dideviceid", b.DeviceID)

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("newRegisterUserInfo post err=%+v", err)
		return
	}
	// {"errorNO":"MB9990","errorMsg":"您已注册开通手机银行，请前往登录。"}
	logger.Info("newRegisterUserInfo >>>>>> " + string(resp))
}

func (b *Bank) newFirstMobileLogin() {
	query := b.addBaseQuery()

	values := &url.Values{}
	values.Set("name", "channels/register/xhtml/newfirstMobileLogin.xhtml")

	resp, err := b.post(urlGetPage, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("newFirstMobileLogin post err=%+v", err)
		return
	}

	logger.Info("newFirstMobileLogin >>>>>> " + string(resp))
}

func (b *Bank) login2() *login2Resp {
	respObj := &login2Resp{}

	query := b.addBaseQuery()

	// netType=0&platform=iPhone%20OS&deviceName=iPhone%207&logon_token=19141941510&tranCode=login_2&id=login&logon_pwd=
	// K%2B9hShbMlVckDelaqj5%2BP%2F7QV2Ra6SntH51er8tIKkqEmyfQRvV86yhqg3d8%2BB7a10rbbw%2B5QwUKNg7lsggJ%2Fg%3D%3D&deviceID
	// =56F64FB1-C34A-4E7E-AE34-400A0277F4FA&appFlag=0&version=13.2.3&model=iPhone&loginStatus=0&setPuLongin=1&logon_mode
	// =A&clientIp=111.230.198.209
	values := &url.Values{}
	values.Set("netType", "0")
	values.Set("platform", "iPhone OS")
	values.Set("deviceName", tools.PhoneName(b.Model))
	values.Set("logon_token", b.Account)
	values.Set("tranCode", "login_2")
	values.Set("id", "login")
	values.Set("logon_pwd", b.pwdEncrypt(b.LoginPwd))
	values.Set("deviceID", b.DeviceID)
	values.Set("appFlag", "0")
	values.Set("version", b.SysVer)
	values.Set("model", "iPhone")
	values.Set("loginStatus", "0")
	values.Set("setPuLongin", "1")
	values.Set("logon_mode", "A")
	values.Set("clientIp", b.ClientIP)

	fmt.Println(values.Encode())

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("login2 post err=%+v", err)
		return respObj
	}
	// 密码错误
	// {"errorStatus":"0","errorNO":"88003","errorMsg":"登录密码输入错误"}
	// 首次登陆返回数据
	// {
	//	"age": "",
	//	"antiMoney": "0",
	//	"antiMoneyOutDate": "0",
	//	"antiTipFlag": "0",
	//	"antiTipNum": "0",
	//	"antiexpirationDate": "2027-05-02",
	//	"antiissuedDate": "2007-05-02",
	//	"antioccupation": "1201",
	//	"antipostalAddress": "武青东一路42号",
	//	"carfklimit": "",
	//	"changeFlag": "0",
	//	"cstno": "100004402988",
	//	"ctfNo": "511124197510154616",
	//	"ctfType": "1",
	//	"customerAlias": "",
	//	"customerId": "511124197510154616",
	//	"customerName": "曾华",
	//	"ebankCsp": "EnterSafe InterPass3000 CSP v1.0 FOR CZBANK",
	//	"errorNO": "000000",
	//	"firstLogon": "0",
	//	"firstLogonStatus": "0",
	//	"flag1": "1",
	//	"flag2": "0",
	//	"flag3": "0",
	//	"flag_related": "2",
	//	"giftTimes": "F",
	//	"hceflag": "",
	//	"ifHasKey": "1",
	//	"keyAlg": "RSA",
	//	"keyCn": "cn=041@ZY0000177204@6510000710346520191008@00000001,ou=Customers,ou=CZB,o=CFCA Operation CA2,c=cn",
	//	"keyEndDate": "2023-10-08-13.37.25.000000",
	//	"keyNo": "1016331960",
	//	"keymode": "0",
	//	"lastDeviceName": "iPhone 7",
	//	"lastlogTime": "2020-01-14 21:12",
	//	"loginSessionId": "AQGWIBIVERJIBTBXDKEGGRGPBABRCQDUDQCRGZJB",
	//	"loginStatus": "1",
	//	"logon_change": "191****1510",
	//	"logon_mode": "0",
	//	"mainAcc": "6223096510810129846",
	//	"mobile": "19141941510",
	//	"nearExpireFlag": "0",
	//	"newBuluFlag": "1",
	//	"openFlag": "",
	//	"pifuFlag": "2",
	//	"setPuLongin": "1",
	//	"shPopFlag": "0",
	//	"tflag": "0",
	//	"type": "2",
	//	"unCertiAntiCtx": "",
	//	"unCertiAntiFlag": "1",
	//	"usercode": "511124197510154616",
	//	"uuidNo": "ef87e1e9-c424-4fd4-8391-3151f110bda5",
	//	"validateMsg": "q8uabs1m",
	//	"zflag": "1"
	//}
	// 第二次登陆返回数据
	logger.Info("login2 >>>>>> " + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("login2 json.Unmarshal err=%+v, resp=%s", err, hex.Dump(resp))
	}

	return respObj
}

func (b *Bank) bindDeviceSrvOp() {
	query := b.addBaseQuery()

	// id=bindDeviceSrvOp&loginStatus=1&tranCode=ifALert&clBindFlag=0
	values := &url.Values{}
	values.Set("id", "bindDeviceSrvOp")
	values.Set("loginStatus", "1")
	values.Set("tranCode", "ifALert")
	values.Set("clBindFlag", "0")

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("bindDeviceSrvOp post err=%+v", err)
		return
	}
	// {"authFlag":"1","secProtect":"0","errorNo":"000000"}
	logger.Info("bindDeviceSrvOp >>>>>> " + string(resp))
}

func (b *Bank) toBindPage() {
	query := b.addBaseQuery()

	// tranCode=toBindPage&loginStatus=1&id=bindDeviceSrvOp
	values := &url.Values{}
	values.Set("tranCode", "toBindPage")
	values.Set("loginStatus", "1")
	values.Set("id", "bindDeviceSrvOp")

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("toBindPage post err=%+v", err)
		return
	}
	// {
	//	"accList": [
	//		{
	//			"accName": "曾华",
	//			"acountNo": "6223096510810129846",
	//			"acountType": "901",
	//			"currCode": "01",
	//			"seqNo": "1",
	//			"subacctype": ""
	//		}
	//	],
	//	"bindLmt": "3",
	//	"creditList": [],
	//	"ctfNo": "511124197510154616",
	//	"customerId": "511124197510154616",
	//	"customerName": "曾华",
	//	"deviceIdFs": "56F64FB1-C34A-4E7E-AE34-400A0277F4FA",
	//	"deviceNameFs": "iPhone 7",
	//	"ebankCsp": "EnterSafe InterPass3000 CSP v1.0 FOR CZBANK",
	//	"errorMsg": "",
	//	"errorNo": "000000",
	//	"items": [],
	//	"keyAlg": "RSA",
	//	"keyCn": "cn=041@ZY0000177204@6510000710346520191008@00000001,ou=Customers,ou=CZB,o=CFCA Operation CA2,c=cn",
	//	"pageurl": "bindDeviceSrvOp/xhtml/device_bind.xhtml"
	//}
	logger.Info("toBindPage >>>>>> " + string(resp))
}

func (b *Bank) deviceBind(name string) {
	query := b.addBaseQuery()

	values := &url.Values{}
	values.Set("name", name) // toBindPage 返回的 "channels/bindDeviceSrvOp/xhtml/device_bind.xhtml"

	resp, err := b.post(urlGetPage, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("deviceBind post err=%+v", err)
		return
	}

	logger.Info("deviceBind >>>>>> " + string(resp))
}

func (b *Bank) getTransListByDate(cardNO, startDate, endDate, page string) *transListResp {
	respObj := &transListResp{}

	query := b.addBaseQuery()

	// timeflag=4&toAccName=&loginStatus=1&id=transInquiry&tranCode=getTransListByDate_new&page=1&endDate=20200114&
	// jiedaiFlag=0&currCode=01&toAccNo=&startDate=20191012&ksFlag=0&cashRemit=01&accountNo=6223096510810129846
	values := &url.Values{}
	values.Set("timeflag", "4")
	values.Set("toAccName", "")
	values.Set("loginStatus", "1")
	values.Set("id", "transInquiry")
	values.Set("tranCode", "getTransListByDate_new")
	values.Set("page", page)
	values.Set("endDate", endDate)
	values.Set("jiedaiFlag", "0")
	values.Set("currCode", "01")
	values.Set("toAccNo", "")
	values.Set("startDate", startDate)
	values.Set("ksFlag", "0")
	values.Set("cashRemit", "01")
	values.Set("accountNo", cardNO)

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("getTransListByDate post err=%+v", err)
		return respObj
	}
	// {
	//	"AccAlias": "",
	//	"ErrorNo": "000000",
	//	"acctNo": "6223096510810129846",
	//	"currCode": "01",
	//	"endDate": "20200114",
	//	"func": "getMore",
	//	"isClean": "true",
	//	"isLastPage": "true", // 判断是否可以翻页
	//	"items": [
	//		{
	//			"id": "/1/-10.00/0.00/e转出/2019-10-17 11:14/27611110/1/622908433091131018/谢利宗/兴业银行总行//",
	//			"money": "0.00",
	//			"name": "2019-10-17 11:14",
	//			"purchaseAmount": "-10.00",
	//			"titleName": "e转出"
	//		},
	//		{
	//			"id": "/2/+10.00/10.00/e转入/2019-10-17 11:11/27594847/1/622908433091131018/谢利宗/兴业银行总行//",
	//			"money": "10.00",
	//			"name": "2019-10-17 11:11",
	//			"purchaseAmount": "+10.00",
	//			"titleName": "e转入"
	//		}
	//	],
	//	"minAmt": "0.00",
	//	"msg": "RecordMsg",
	//	"onClick": "toTransDetail",
	//	"page": "1",
	//	"startDate": "20191012",
	//	"totalIncome": "10.00",
	//	"totalPay": "10.00"
	//}
	logger.Info("getTransListByDate >>>>>> " + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("getTransListByDate json.Unmarshal err=%+v, resp=%s", err, hex.Dump(resp))
	}

	return respObj
}

func (b *Bank) qryBankAccountSrvOp() *cardListResp {
	respObj := &cardListResp{}

	query := b.addBaseQuery()

	// tranCode=qryBankAccountSrvOp&loginStatus=1&id=accountAdministration
	values := &url.Values{}
	values.Set("tranCode", "qryBankAccountSrvOp")
	values.Set("loginStatus", "1")
	values.Set("id", "accountAdministration")

	resp, err := b.post(urlRun, query, nil, values.Encode(), true)
	if err != nil {
		logger.Errorf("qryBankAccountSrvOp post err=%+v", err)
		return respObj
	}

	logger.Info("qryBankAccountSrvOp >>>>>> " + string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("qryBankAccountSrvOp json.Unmarshal err=%+v, resp=%s", err, hex.Dump(resp))
	}
	// {
	//	"accState": "1",
	//	"branchName": "浙商银行成都青羊支行",
	//	"checkState": "",
	//	"ctfNo": "511124197510154616",
	//	"customerName": "曾华",
	//	"customerflag": "0",
	//	"ebankCsp": "EnterSafe InterPass3000 CSP v1.0 FOR CZBANK",
	//	"entranceFlag": "ebank",
	//	"items": [
	//		{
	//			"accAlias": "",
	//			"accName": "曾华",
	//			"accountNo": "6223096510810129846",
	//			"accountType": "901",
	//			"balanceable": "0.00",
	//			"cardType": "1",
	//			"currCode": "01",
	//			"id": "6223096510810129846|901|01|曾华||1|1|0.00|0|20191014|0.00|   |浙商银行成都青羊支行|651000071|",
	//			"isCheck": "1",
	//			"subAccType": "   "
	//		}
	//	],
	//	"keyAlg": "RSA",
	//	"keyCn": "cn=041@ZY0000177204@6510000710346520191008@00000001,ou=Customers,ou=CZB,o=CFCA Operation CA2,c=cn",
	//	"mainAcc": "6223096510810129846",
	//	"mobRegNode": "651000071",
	//	"mobile": "19141941510",
	//	"open23CardFlag": "0",
	//	"pageurl": "accountAdministration/xhtml/firstPage.xhtml"
	//}
	return respObj
}
