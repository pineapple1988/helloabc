package czb

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm2"
	"awesome/tools/gmsm/sm3"
	"bytes"
	"crypto/ecdsa"
	"crypto/hmac"
	"encoding/binary"
	"fmt"
	"io"
	"net/url"
)

type rytTLS struct {
	rnc             []byte
	rns             []byte
	Rns2            []byte `json:"rns2"`
	pms             []byte
	pms2            []byte
	ms              []byte
	ms2             []byte
	serialN         int64
	clientKey       []byte
	clientIv        []byte
	serverKey       []byte
	serverIv        []byte
	clientHmacKey   []byte
	serverHmacKey   []byte
	sessionId       string
	ServerSM2PubKey []byte `json:"serverSM2PubKey"`
	clientHelloBody []byte
	serverHelloBody []byte
	clientKeyExBody []byte
	serverKeyExBody []byte
}

const (
	TLS_MD_PREMASTER_SECRET_CONST       = "premaster secret"
	TLS_MD_MASTER_SECRET_CONST          = "master secret"
	TLS_MD_CLIENT_FINISH_CONST          = "client finished"
	TLS_MD_MASTER_SECRET2_CONST         = "master secret2"
	TLS_MD_CLIENT_SERVER_KEYIVMAC_CONST = "key expansion"
	TLS_MD_SERVER_FINISH_CONST          = "server finished"
	TLS_ONCE_SECRET_CONST               = "once secret"
)

func (t *rytTLS) getClientRandom(count int) []byte {
	b := make([]byte, count)
	for i := 0; i < count; i++ {
		b[i] = byte(tools.RandIntn(0x100))
	}
	return b
}

func (t *rytTLS) hmacSm3AndXOR(prf, label, seed []byte, length int) []byte {
	halfLen := (len(prf) & 1) + (len(prf) >> 1)
	sm3SourceAry1 := prf[:halfLen]
	sm3SourceAry2 := prf[halfLen:]
	param2BA := &bytes.Buffer{}
	param2BA.Write(label)
	param2BA.Write(seed)
	sm3Ary1 := t.hmacSm3(sm3SourceAry1, param2BA.Bytes(), length)
	sm3Ary2 := t.hmacSm3(sm3SourceAry2, param2BA.Bytes(), length)
	return t.hmacXOR(sm3Ary1, sm3Ary2)
}

func (t *rytTLS) hmacSm3(key, data []byte, size int) []byte {
	rltBA := &bytes.Buffer{}
	lastData := data
	for len(rltBA.Bytes()) <= size {
		hsm3 := hmac.New(sm3.New, key)
		hsm3.Write(lastData)
		lastData = hsm3.Sum(nil)
		t := &bytes.Buffer{}
		t.Write(lastData)
		t.Write(data)
		hsm3.Reset()
		hsm3.Write(t.Bytes())
		rltBA.Write(hsm3.Sum(nil))
	}
	return rltBA.Bytes()[:size]
}

func (t *rytTLS) hmacXOR(p1, p2 []byte) []byte {
	buf := &bytes.Buffer{}
	for i := 0; i < len(p1); i++ {
		buf.WriteByte(p1[i] ^ p2[i])
	}
	return buf.Bytes()
}

func (t *rytTLS) getClientProtocolVersion() []byte {
	return []byte{0x01, 0x04}
}

func (t *rytTLS) getSessionID() []byte {
	return []byte{0x00}
}

func (t *rytTLS) getRecordGroup() []byte {
	return []byte{0x0A}
}

func (t *rytTLS) getCipherSuite() []byte {
	return []byte{0x00, 0x06, 0x00, 0x07, 0x00, 0x06, 0x00, 0x0c}
}

func (t *rytTLS) getCertSerialNumber() []byte {
	if len(t.ServerSM2PubKey) == 0 {
		return []byte{0x00}
	}

	cert, err := sm2.ParseCertificateEx(t.ServerSM2PubKey)
	if err != nil {
		logger.Error("getCertSerialNumber 获取SM2 序列号错误")
		return []byte{0x00}
	}

	b := &bytes.Buffer{}
	b.WriteByte(byte(len(cert.SerialNumber.Bytes())))
	b.Write(cert.SerialNumber.Bytes())

	return b.Bytes()
}

func (t *rytTLS) createOnceRNC() []byte {
	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.LittleEndian, tools.Timestamp())
	buffer.Write(t.getClientRandom(28))
	return buffer.Bytes()
}

func (t *rytTLS) createFullClientHelloBody() []byte {
	t.rnc = t.createOnceRNC()
	buffer1 := bytes.NewBuffer([]byte{})
	buffer1.Write(t.getClientProtocolVersion())
	buffer1.Write(t.rnc)
	buffer1.Write(t.getRecordGroup())
	buffer1.Write(t.getCipherSuite())
	buffer1.Write(t.getCertSerialNumber())

	buffer2 := bytes.NewBuffer([]byte{})
	buffer2.WriteByte(1)
	_ = binary.Write(buffer2, binary.BigEndian, uint32(len(buffer1.Bytes())))
	buffer2.Write(buffer1.Bytes())

	t.clientHelloBody = make([]byte, buffer2.Len())
	copy(t.clientHelloBody, buffer2.Bytes())

	return buffer2.Bytes()
}
func (t *rytTLS) getPreMasterSecret() []byte {
	prf := t.getClientRandom(46)

	//prf = []byte{
	//	0xDA, 0xFE, 0x81, 0xD5, 0xA0, 0x24, 0x46, 0x8F, 0x35, 0x98, 0xCC, 0xAD, 0xD3, 0x78, 0xAC, 0x23,
	//	0xD0, 0xCE, 0x7F, 0xAE, 0xA7, 0x1D, 0x01, 0xAF, 0xE5, 0xB1, 0x01, 0x5A, 0x49, 0x07, 0xA6, 0xE8,
	//	0xF8, 0xAE, 0xB3, 0xB8, 0x7D, 0xBF, 0x4A, 0x3A, 0x17, 0x25, 0xFD, 0x5E, 0x41, 0x3D,
	//}

	lable := []byte(TLS_MD_PREMASTER_SECRET_CONST)
	seed := bytes.NewBuffer([]byte{})
	seed.Write(t.rnc)
	seed.Write(t.rns)
	hmacData := t.hmacSm3AndXOR(prf, lable, seed.Bytes(), 46)

	buffer := bytes.NewBuffer([]byte{})
	buffer.Write(t.getClientProtocolVersion())
	buffer.Write(hmacData)

	return buffer.Bytes()
}
func (t *rytTLS) getClientKeyExchangeBody() []byte {
	t.pms = t.getPreMasterSecret()
	buffer := bytes.NewBuffer([]byte{})
	buffer.Write(t.pms)
	buffer.Write(t.rns)
	buffer.WriteByte(0)
	//fmt.Println(hex.Dump(buffer.Bytes()))
	// 进行加密了
	enBuffer := t.sm2EncryptToAsn1(buffer.Bytes(), t.ServerSM2PubKey)
	//fmt.Println(hex.Dump(enBuffer))
	buffer.Reset()
	buffer.WriteByte(9)
	_ = binary.Write(buffer, binary.BigEndian, int32(len(enBuffer)))
	buffer.Write(enBuffer)

	return buffer.Bytes()
}

func (t *rytTLS) getChangeCipherSpecBody() []byte {
	return []byte{0x07, 0x00, 0x00, 0x00, 0x01, 0x00}
}

func (t *rytTLS) getVerifyData(body []byte) []byte {
	seed := &bytes.Buffer{}
	seed.Write(t.rnc)
	seed.Write(t.rns)
	label := []byte(TLS_MD_MASTER_SECRET_CONST)
	t.ms = t.hmacSm3AndXOR(t.pms, label, seed.Bytes(), 68)

	seed.Reset()
	md5DigestData := sm3.Sm3Sum(body)
	sha1DigestData := sm3.Sm3Sum(body)
	seed.Write(md5DigestData[:])
	seed.Write(sha1DigestData[:])
	label = []byte(TLS_MD_CLIENT_FINISH_CONST)
	return t.hmacSm3AndXOR(t.ms, label, seed.Bytes(), 12)
}

func (t *rytTLS) getFinishedBody(body []byte) []byte {
	verify := t.getVerifyData(body)

	buffer := &bytes.Buffer{}
	buffer.WriteByte(0xA)
	_ = binary.Write(buffer, binary.BigEndian, int32(len(verify)))
	buffer.Write(verify)

	return buffer.Bytes()
}
func (t *rytTLS) clientHelloRequest(b *Bank) bool {
	clientHelloBody := t.createFullClientHelloBody()

	//fmt.Println("clientHelloRequest req \n" + hex.Dump(clientHelloBody))

	deviceUUID := "(null)"
	if b.UUID != "" {
		deviceUUID = b.UUID
	}

	resp, err := b.post(urlDomain+"/user/hello", &url.Values{
		"clientinfo":       {fmt.Sprintf("ios-iPhone-%s-1234-UA_ios%s", bundleShortVersion, b.SysVer)},
		"is_first":         {"0"},
		"app":              {"ebank"},
		"o":                {"i"},
		"islogin":          {"0"},
		"ios7":             {"1"},
		"creditcard":       {"false"},
		"x-wl-device-uuid": {deviceUUID},
	}, nil, clientHelloBody, false)

	//fmt.Println("clientHelloRequest resp \n" + hex.Dump(resp))

	if err != nil {
		logger.Error("clientHelloRequest post err")
		return false
	} else {
		return t.handleFullServerHelloResponse(resp)
	}
}

func (t *rytTLS) writeHashBody(buffer *bytes.Buffer) {
	// -[RYTTLS getResourceHashBody]
	buffer.Write([]byte{
		0x0C, 0x00, 0x00, 0x00, 0x40, 0x34, 0x62, 0x31, 0x38, 0x39, 0x30, 0x65, 0x64, 0x62, 0x64, 0x39,
		0x38, 0x66, 0x30, 0x30, 0x36, 0x33, 0x66, 0x39, 0x30, 0x32, 0x32, 0x63, 0x33, 0x34, 0x34, 0x33,
		0x35, 0x65, 0x61, 0x61, 0x38, 0x35, 0x38, 0x62, 0x35, 0x61, 0x64, 0x65, 0x61, 0x35, 0x63, 0x39,
		0x39, 0x31, 0x37, 0x33, 0x39, 0x39, 0x31, 0x35, 0x37, 0x33, 0x35, 0x31, 0x63, 0x30, 0x39, 0x34,
		0x35, 0x32, 0x32, 0x33, 0x30,
	})

	// -[RYTTLS getResourceHashOptBody]
	buffer.Write([]byte{
		0x0D, 0x00, 0x00, 0x00, 0x00,
	})
}

func (t *rytTLS) sendClientKeyExchange(b *Bank) bool {
	buffer := &bytes.Buffer{}

	clientKeyExchangeBody := t.getClientKeyExchangeBody()
	changeCipherSpecBody := t.getChangeCipherSpecBody()

	buffer.Write(t.clientHelloBody)
	buffer.Write(t.serverHelloBody)
	buffer.Write(clientKeyExchangeBody)
	buffer.Write(changeCipherSpecBody)

	finishBody := t.getFinishedBody(buffer.Bytes())

	buffer.Reset()
	buffer.Write(clientKeyExchangeBody)
	buffer.Write(changeCipherSpecBody)
	buffer.Write(finishBody)

	t.clientKeyExBody = buffer.Bytes()
	t.writeHashBody(buffer)

	//fmt.Println("sendClientKeyExchange req \n" + hex.Dump(buffer.Bytes()))
	deviceUUID := "(null)"
	if b.UUID != "" {
		deviceUUID = b.UUID
	}
	resp, err := b.post(urlDomain+"/user/exchange", &url.Values{
		"ota_version":      {fmt.Sprintf("IP-UMP-%s-000000", bundleShortVersion)},
		"sign":             {"(null)"},
		"platform":         {"iphone"},
		"app":              {"ebank"},
		"o":                {"i"},
		"resolution":       {tools.ScreenPx(b.Model)},
		"islogin":          {"0"},
		"ios7":             {"1"},
		"creditcard":       {"false"},
		"x-wl-device-uuid": {deviceUUID},
	}, nil, buffer.Bytes(), false)

	//fmt.Println("sendClientKeyExchange resp \n" + hex.Dump(resp))

	if err != nil {
		logger.Errorf("sendClientKeyExchange post err=%+v", err)
		return false
	}
	return t.handleFullServerKeyExchangeResponse(resp)
}

func (t *rytTLS) clientHelloAndKeyExchange(b *Bank) bool {
	// 拷贝rns2 -> rns
	t.rns = make([]byte, len(t.Rns2))
	copy(t.rns, t.Rns2)

	buffer := &bytes.Buffer{}
	buffer.Write(t.createFullClientHelloBody())
	buffer.Write(t.getClientKeyExchangeBody())
	buffer.Write(t.getChangeCipherSpecBody())
	buffer.Write(t.getFinishedBody(buffer.Bytes()))
	t.clientHelloBody = buffer.Bytes()
	t.writeHashBody(buffer)
	//fmt.Println("clientHelloAndKeyExchange req \n" + hex.Dump(t.clientHelloBody))

	deviceUUID := "(null)"
	if b.UUID != "" {
		deviceUUID = b.UUID
	}

	resp, err := b.post(urlDomain+"/user/handshake", &url.Values{
		"ota_version":      {fmt.Sprintf("IP-UMP-%s-000000", bundleShortVersion)},
		"tmsUserCode":      {"(null)"},
		"bankUserCode":     {"(null)"},
		"clientinfo":       {fmt.Sprintf("ios-iPhone-%s-1234-UA_ios%s", bundleShortVersion, b.SysVer)},
		"is_first":         {"0"},
		"sign":             {"(null)"},
		"platform":         {"iphone"},
		"app":              {"ebank"},
		"o":                {"i"},
		"resolution":       {tools.ScreenPx(b.Model)},
		"islogin":          {"0"},
		"ios7":             {"1"},
		"creditcard":       {"false"},
		"x-wl-device-uuid": {deviceUUID},
	}, nil, t.clientHelloBody, false)

	//fmt.Println("clientHelloAndKeyExchange resp \n" + hex.Dump(resp))

	if err != nil {
		logger.Errorf("clientHelloAndKeyExchange post err=%+v", err)
		return false
	} else {
		return t.handleSimpleClientHelloAndKeyExchangeResponse(resp)
	}
}

func (t *rytTLS) handleSimpleClientHelloAndKeyExchangeResponse(resp []byte) bool {
	reader := bytes.NewReader(resp)
	t.handleServerHello(reader)
	if t.handleServerCertificate(reader) {
		if t.parseServerKeyExchange(reader) {
			t.handleChangeCipher(reader)
			if t.handleFinish(reader) {
				t.handleInitContent(reader)
				return true
			}
		}
	}
	return false
}

func (t *rytTLS) handleFullServerHelloResponse(resp []byte) bool {
	t.serverHelloBody = resp
	reader := bytes.NewReader(resp)
	t.handleServerHello(reader)
	return t.handleServerCertificate(reader)
}

func (t *rytTLS) handleFullServerKeyExchangeResponse(resp []byte) bool {
	reader := bytes.NewReader(resp)
	if t.parseServerKeyExchange(reader) {
		t.handleChangeCipher(reader)
		if t.handleFinish(reader) {
			t.handleInitContent(reader)
			return true
		}
	}

	return false
}

func (t *rytTLS) handleServerHello(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	if f != 2 {
		_, _ = reader.Seek(4, io.SeekCurrent)
	}
	// 在读取6个字节
	_, _ = reader.Seek(6, io.SeekCurrent)
	// 读取rns
	t.rns = make([]byte, 0x20)
	_, _ = reader.Read(t.rns)
	// 读取sessionId
	sessionIdLen, _ := reader.ReadByte()
	sessionId := make([]byte, sessionIdLen)
	_, _ = reader.Read(sessionId)
	t.sessionId = string(sessionId)
	_, _ = reader.Seek(2, io.SeekCurrent)
}

func (t *rytTLS) handleServerCertificate(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	if f == 4 {
		var keyLen uint32
		_ = binary.Read(reader, binary.BigEndian, &keyLen)
		t.ServerSM2PubKey = make([]byte, keyLen)
		_, _ = reader.Read(t.ServerSM2PubKey)
		return true
	}
	logger.Error("handleServerCertificate error f != 4")
	return false
}
func (t *rytTLS) parseServerKeyExchange(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	if f == 5 {
		key := t.getAesKey(t.ms)
		iv := t.getAesIv(t.ms)

		// 读出需要解密的内容
		var enDataLen uint32
		_ = binary.Read(reader, binary.BigEndian, &enDataLen)
		enData := make([]byte, enDataLen)
		_, _ = reader.Read(enData)

		// 解密
		plainData, _ := tools.SM4CBCDecrypt(enData, key[:0x10], iv)
		plainReader := bytes.NewReader(plainData)
		t.Rns2 = make([]byte, 32)
		_, _ = plainReader.Read(t.Rns2)

		// 准备开始校验了
		v27 := make([]byte, 2)
		v16 := make([]byte, 46)
		hmacData := make([]byte, 0x20)
		_, _ = plainReader.Read(v27)
		_, _ = plainReader.Read(v16)
		_, _ = plainReader.Read(hmacData)

		if t.verifyHmac(t.ms, append(append(t.Rns2, v27...), v16...), hmacData) {
			t.pms2 = append(v27, v16...)
			label := []byte(TLS_MD_MASTER_SECRET2_CONST)
			seed := append(t.rnc, t.rns...)
			t.ms2 = t.hmacSm3AndXOR(t.pms2, label, seed, 48)
			t.createAesKey(t.ms2, seed)
			return true
		}

		logger.Error("handleServerCertificate 建立安全通道失败，原因为hmac较验失败。")
		return false
	}

	logger.Error("handleServerCertificate error f != 5")
	return false
}

func (t *rytTLS) handleChangeCipher(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f != 7 {
		dataLen = 0
	}
	dataLen += uint32(reader.Size()) - uint32(reader.Len())
	_, _ = reader.Seek(0, io.SeekStart)
	t.serverKeyExBody = make([]byte, dataLen)
	_, _ = reader.Read(t.serverKeyExBody)
}

func (t *rytTLS) handleFinish(reader *bytes.Reader) bool {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f == 10 {
		finishData := make([]byte, dataLen)
		_, _ = reader.Read(finishData)
		if t.verifyFinishData(finishData) {
			return true
		}
		logger.Error("handleFinish verifyFinishData 建立安全通道失败，原因为finish较验失败")
		return false
	}
	logger.Error("handleFinish error f != 10")
	return false
}

func (t *rytTLS) handleInitContent(reader *bytes.Reader) {
	f, _ := reader.ReadByte()
	var dataLen uint32
	_ = binary.Read(reader, binary.BigEndian, &dataLen)
	if f == 11 {
		initContent := make([]byte, dataLen)
		_, _ = reader.Read(initContent)
		content, _ := tools.SM4CBCDecrypt(initContent, t.serverKey[:0x10], t.serverIv)
		logger.Info(" handleInitContent >>>>>>>> " + string(content))
		return
	}
	logger.Error("handleInitContent error f != 11")
}

func (t *rytTLS) verifyFinishData(data []byte) bool {
	var allData []byte
	if len(t.clientHelloBody) > 0 {
		allData = append(allData, t.clientHelloBody...)
	}
	if len(t.serverHelloBody) > 0 {
		allData = append(allData, t.serverHelloBody...)
	}
	if len(t.clientKeyExBody) > 0 {
		allData = append(allData, t.clientKeyExBody...)
	}
	if len(t.serverKeyExBody) > 0 {
		allData = append(allData, t.serverKeyExBody...)
	}

	label := []byte(TLS_MD_SERVER_FINISH_CONST)
	md5Ary := sm3.Sm3Sum(allData)
	sha1Ary := sm3.Sm3Sum(allData)

	retAry := t.hmacSm3AndXOR(t.ms2, label, append(md5Ary[:], sha1Ary[:]...), 12)

	if len(retAry) <= 0 || len(data) <= 0 {
		return false
	}

	if len(retAry) != len(data) {
		return false
	}

	for i, v := range retAry {
		if v != data[i] {
			return false
		}
	}

	return true
}

func (t *rytTLS) verifyHmac(ms, orgData, hmacData []byte) bool {
	key := t.getHmacKey(ms)
	hmacSm3 := hmac.New(sm3.New, key)
	hmacSm3.Write(orgData)
	digest := hmacSm3.Sum(nil)

	if len(digest) <= 0 || len(hmacData) <= 0 {
		return false
	}

	if len(digest) != len(hmacData) {
		return false
	}

	for i, v := range digest {
		if v != hmacData[i] {
			return false
		}
	}

	return true
}

func (t *rytTLS) createAesKey(key, seed []byte) {
	label := []byte(TLS_MD_CLIENT_SERVER_KEYIVMAC_CONST)
	allKeyIv := t.hmacSm3AndXOR(key, label, seed, 136)
	//fmt.Println(hex.Dump(allKeyIv))
	t.clientKey = t.getAesKey(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientKey))
	t.clientIv = t.getAesIv(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientIv))
	t.clientHmacKey = t.getHmacKey(allKeyIv[:68])
	//fmt.Println(hex.Dump(t.clientHmacKey))

	t.serverKey = t.getAesKey(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverKey))
	t.serverIv = t.getAesIv(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverIv))
	t.serverHmacKey = t.getHmacKey(allKeyIv[68:])
	//fmt.Println(hex.Dump(t.serverHmacKey))
}

func (t *rytTLS) getAesKey(data []byte) []byte {
	return data[:32]
}

func (t *rytTLS) getAesIv(data []byte) []byte {
	return data[32:48]
}

func (t *rytTLS) getHmacKey(data []byte) []byte {
	return data[48:68]
}

func (t *rytTLS) sm2EncryptToAsn1(in, key []byte) []byte {
	cert, _ := sm2.ParseCertificateEx(key)
	pub := cert.PublicKey.(*ecdsa.PublicKey)

	sm2Pub := &sm2.PublicKey{
		Curve: sm2.P256Sm2(),
		X:     pub.X,
		Y:     pub.Y,
	}

	out, err := sm2.Encrypt(sm2Pub, in)
	if err != nil {
		return nil
	}
	//fmt.Println(hex.Dump(out))

	// 进行asn1编码
	// 开始进行ans1 编码
	ans1C := bytes.NewBuffer([]byte{})
	out = out[1:]
	x1Buf := out[:0x20]
	y1Buf := out[0x20:0x40]
	h := out[0x40:0x60]

	// TagInteger         = 2
	if x1Buf[0] > 0x7F {
		x1Buf = append([]byte{0x00}, x1Buf...)
	}
	ans1C.Write([]byte{0x02, byte(len(x1Buf))})
	ans1C.Write(x1Buf)

	// TagInteger         = 2
	if y1Buf[0] > 0x7F {
		y1Buf = append([]byte{0x00}, y1Buf...)
	}
	ans1C.Write([]byte{0x02, byte(len(y1Buf))})
	ans1C.Write(y1Buf)

	// TagOctetString     = 4
	ans1C.Write([]byte{0x04, 0x20})
	ans1C.Write(h)

	// TagOctetString     = 4
	ans1C.Write([]byte{0x04, byte(len(in))})
	ans1C.Write(out[96:])

	return append([]byte{0x30, 0x81, byte(ans1C.Len())}, ans1C.Bytes()...)
}
