package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"strconv"
)

type env struct {
	DeviceModel  string `json:"deviceModel"`
	AppVersion   string `json:"appVersion"`
	Manufacturer string `json:"manufacturer"`
	AppName      string `json:"appName"`
	OsVersion    string `json:"osVersion"`
	ViSdkVersion string `json:"viSdkVersion"`
	DeviceType   string `json:"deviceType"`
	Apdid        string `json:"apdid"`
	ApdidToken   string `json:"apdidToken"`
	Tid          string `json:"tid"`
	Bp           string `json:"bp"`
}

type tipView struct {
	ReturnCode      int    `json:"returnCode"`
	LeftButtonText  string `json:"leftButtonText"`
	RightButtonText string `json:"rightButtonText"`
	Title           string `json:"title"`
	Message         string `json:"message"`
}

type contentConfig struct {
	Coll struct {
		Authorization    bool     `json:"authorization"`
		Beauty           bool     `json:"beauty"`
		UploadMonitorPic int      `json:"uploadMonitorPic"`
		ActionMode       []string `json:"actionMode"`
	} `json:"coll"`
	Upload struct {
		Collection []string `json:"collection"`
	} `json:"upload"`
	NoCamPermissionWords string `json:"noCamPermissionWords"`
	SceneEnv             struct {
		SceneCode string `json:"sceneCode"`
		SceneType string `json:"sceneType"`
	} `json:"sceneEnv"`
	SampleMode int    `json:"sampleMode"`
	Env        int    `json:"env"`
	Type       int    `json:"type"`
	RunEnv     string `json:"runEnv"`
	FaceTips   struct {
		AuthorizationAlert      tipView `json:"authorizationAlert"`
		SystemErrorAlert        tipView `json:"systemErrorAlert"`
		SystemVersionErrorAlert tipView `json:"systemVersionErrorAlert"`
		LimitAlert              tipView `json:"limitAlert"`
		FailAlert               tipView `json:"failAlert"`
		UnsurpportAlert         tipView `json:"unsurpportAlert"`
		CameraNoPermissionAlert tipView `json:"cameraNoPermissionAlert"`
		NetworkErrorAlert       tipView `json:"networkErrorAlert"`
		InterruptAlert          tipView `json:"interruptAlert"`
	} `json:"faceTips"`
	Token string `json:"token"`
	Ui    string `json:"ui"`
	Navi  struct {
		Enable  bool   `json:"enable"`
		Version string `json:"version"`
		Url     string `json:"url"`
	} `json:"navi"`
	VerifyMode string `json:"verifyMode"`
	Algorithm  struct {
		LivenessCombination []string `json:"liveness_combination"`
		SecurityLevel       string   `json:"securityLevel"`
		UseGrayModel        bool     `json:"useGrayModel"`
		SecProtocol         string   `json:"secProtocol"`
		AlgoUpdate          bool     `json:"algoUpdate"`
		Threshold           struct {
			ZfaceBlinkLiveness []float32 `json:"zfaceBlinkLiveness"`
		} `json:"threshold"`
		EyeOpenness float32 `json:"eye_openness"`
		MinIod      float32 `json:"min_iod"`
	} `json:"algorithm"`
}

type initFaceVerifyResData struct {
	AbTest              string `json:"abTest"`
	IsWelcomePageHidden string `json:"isWelcomePageHidden"`
	RankScore           string `json:"rankScore"`
	UserID              string `json:"USER_ID"`
	SourceLevel         string `json:"sourceLevel"`
	UsableDegradeMode   string `json:"usableDegradeMode"`
	ProdUnitId          string `json:"prodUnitId"`
	SdkCode             string `json:"sdkCode"`
	IgnoreRefUsable     string `json:"ignoreRefUsable"`
	IgnoreAppversion    string `json:"ignoreAppversion"`
	FaceStyle           string `json:"faceStyle"`
	SceneId             string `json:"sceneId"`
	DesensName          string `json:"desensName"`
	PopupErrMsg         string `json:"popupErrMsg"`
	ProductBizCode      string `json:"productBizCode"`
	AuthTag             string `json:"authTag"`
	NaviWords           string `json:"naviWords"`
	ZimInitResp         string `json:"zimInitResp"`
	SampleMode          string `json:"sampleMode"`
	PreCheckPass        string `json:"pre_check_pass"`
	ServiceLevel        string `json:"serviceLevel"`
	FarOut              string `json:"farOut"`
	ProdCode            string `json:"prodCode"`
	ZimId               string `json:"zimId"`
	AppID               string `json:"appID"`
	UiType              string `json:"uiType"`
	ProdGroupId         string `json:"prodGroupId"`
	NaviEnabled         string `json:"naviEnabled"`
	UseZim              string `json:"useZim"`
	UserNameHidden      string `json:"userNameHidden"`
}

func (w *WorkGroup) parseZimInitResponse(data []byte, verifyId, token string, scene VerifyScene) {
	respData := &initFaceVerifyResData{}
	_ = json.Unmarshal(data, respData)
	if respData.UseZim == "Y" {
		zimInitResp := &pb.ZimInitResponse{}
		// 这里不是标准的base64
		zimInitRespData, _ := base64.RawURLEncoding.DecodeString(respData.ZimInitResp)
		_ = proto.Unmarshal(zimInitRespData, zimInitResp)
		if zimInitResp.GetRetCode() == 100 {
			config := &pb.APBThinClientConfig{}
			_ = proto.Unmarshal(zimInitResp.GetProtocolBytes(), config)
			ctCfg := &contentConfig{}
			_ = json.Unmarshal([]byte(config.GetContent()), ctCfg)

			log2.Infof("initFaceVerifyResData, zimId=%s, bisToken=%s, verifyId=%s, token=%s",
				zimInitResp.GetZimId(), ctCfg.Token, verifyId, token)

			w.sendZimValidateRequest(zimInitResp.GetZimId(), ctCfg.Token, token, token, scene)
		}
	}
}

func (w *WorkGroup) sendInitFaceLoginReqPbPB(image *imageInfo) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.InitFaceLoginResPbPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("InitFaceLoginResPbPB, proto.Unmarshal err: %+v", err)
		} else {
			//log2.Infof("InitFaceLoginResPbPB, resp: \r\n%+v", hex.Dump(resp))
			if respObj.GetResultStatus() == "1000" {
				w.parseZimInitResponse([]byte(respObj.GetData()), respObj.GetVerifyId(), respObj.GetToken(), VerifyScene_Login)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcInitFaceLoginV2,
		"retryable2":     "0",
	}

	devKeySet := fmt.Sprintf("{\"apdidToken\":\"%s\"}", w.acc.APDIDToken)
	ldf := w.getLocalDevicesFeature()

	postionData, _ := json.Marshal(&map[string]interface{}{
		"speed":                 0,
		"wifiConn":              "true",
		"extraInfos":            map[string]string{},
		"longitude":             0,
		"lbsOpen":               "false",
		"latitude":              0,
		"voiceOver":             "false",
		"source":                AppKey,
		"os":                    "iOS",
		"currentMobileOperator": tools.CarrierByIMSI(w.acc.Device.IMSI),
		"accuracy":              0,
		"altitude":              0,
		"direction":             0,
		"accessWirelessNetType": "Wifi",
	})
	bizRequestData, _ := json.Marshal(&map[string]interface{}{
		"loginId":  w.acc.AccName,
		"signData": nil,
		"externParams": map[string]string{
			"faceVerifyType": "verifyId",
			"idfa":           w.acc.Device.IDFA,
			"edgeData":       "",
			"devKeySet":      devKeySet,
			"recommendScene": "newInstall",
		},
		"checkCode":      nil,
		"clientType":     nil,
		"mobileModel":    w.acc.Device.Model,
		"ssoToken":       nil,
		"alipayEnvJson":  nil,
		"wifiMac":        w.acc.Device.WifiMac,
		"IMEI":           w.acc.Device.IMEI,
		"loginPwd":       nil,
		"productVersion": ProductVersion,
		"scene":          nil,
		"loginType":      "alipay",
		"userAgent":      nil,
		"appKey":         AppKey,
		"appId":          "ALIPAY",
		"isPrisonBreak":  "0",
		"umidToken":      w.acc.UMIDToken,
		"clientPostion":  string(postionData),
		"screenWidth":    strconv.Itoa(tools.ScreenWidthPx(w.acc.Device.Model)),
		"appData": map[string]interface{}{
			"productId":       ProductId,
			"mspTid":          w.acc.TID,
			"userAgent":       w.acc.Device.Model,
			"walletClientKey": w.acc.ClientKey,
			"mspImei":         w.acc.Device.IMEI,
			"mac":             w.acc.Device.BluetoothMac,
			"walletTid":       w.acc.TID,
			"mspImsi":         w.acc.Device.IMSI,
			"mspClientKey":    w.acc.ClientKey,
			"vimsi":           w.acc.VIMSI,
			"externParams": map[string]interface{}{
				"apdid":        w.acc.APDID,
				"netType":      "WIFI",
				"terminalName": w.acc.Device.Name,
				"ldf":          ldf,
				"devKeySet": map[string]string{
					"apdidToken": w.acc.APDIDToken,
				},
			},
			"channels":       "apple-iphone",
			"clientId":       fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI),
			"osVersion":      w.acc.Device.SysVer,
			"terminalName":   w.acc.Device.Name,
			"productVersion": ProductVersion,
			"vimei":          w.acc.VIMEI,
		},
		"channel":       nil,
		"deviceId":      fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI), //"unknown",
		"mobileBrand":   "Apple",
		"ttid":          nil,
		"tid":           w.acc.TID,
		"validateTpye":  "withface",
		"systemVersion": w.acc.Device.SysVer,
		"IMSI":          w.acc.Device.IMSI,
		"checkCodeId":   nil,
		"lacId":         nil,
		"apdid":         w.acc.APDID,
		"cellId":        nil,
		"utdid":         w.acc.UTDID,
		"sdkVersion":    SdkVersion,
		"accessPoint":   nil,
		"systemType":    "IOS",
		"token":         nil,
		"taobaoEnvJson": nil,
		"screenHigh":    strconv.Itoa(tools.ScreenHeightPx(w.acc.Device.Model)),
		"wifiNodeName":  w.acc.Device.WifiName,
		"productId":     ProductId,
	})

	envData, _ := json.Marshal(&env{
		DeviceModel:  w.acc.Device.Model,
		AppVersion:   AppVersion,
		Manufacturer: "Apple",
		AppName:      BundleId,
		OsVersion:    fmt.Sprintf("iOS%s", w.acc.Device.SysVer),
		ViSdkVersion: VIDataVersion,
		DeviceType:   "ios",
		Apdid:        w.acc.APDID,
		ApdidToken:   w.acc.APDIDToken,
		Tid:          w.acc.TID,
		Bp:           getBP(),
	})
	w.SendHttpMessage(onResp, headers, &pb.InitFaceLoginReqPbPB{
		LoginId:         proto.String(w.acc.AccName),
		UserId:          proto.String(w.acc.UserId),
		UmidToken:       proto.String(w.acc.UMIDToken),
		Apdid:           proto.String(w.acc.APDID),
		Tid:             proto.String(w.acc.TID),
		ProductId:       proto.String(ProductId),
		ProductVersion:  proto.String(ProductVersion),
		SystemName:      proto.String("ios"),
		Count:           proto.Int32(0), // 重试这里会不一样
		Utdid:           proto.String(w.acc.UTDID),
		EnvJson:         proto.String(w.getRdsMessage(w.getUAFaceLogin())),
		FaceLoginSource: proto.String("BIS_RECOMMEND_PAGE_FACELOGIN"),
		SecurityId:      proto.String(""),
		ExternParams: []*pb.AuthLoginTokenExternParamsPB{
			{
				Key:   proto.String("bizRequestData"),
				Value: proto.String(string(bizRequestData)),
			}, {
				Key:   proto.String("envData"),
				Value: proto.String(string(envData)),
			}, {
				Key:   proto.String("bioMetaInfo"),
				Value: proto.String(w.getBioMetaInfo()),
			}, {
				Key:   proto.String("bp"),
				Value: proto.String(getBP()),
			}, {
				Key:   proto.String("appName"),
				Value: proto.String("AlipayWallet"),
			}, {
				Key:   proto.String("recommendScene"),
				Value: proto.String("coldLaunch"),
			}, {
				Key:   proto.String("ldf"),
				Value: proto.String(ldf),
			}, {
				Key:   proto.String("devKeySet"),
				Value: proto.String(devKeySet),
			},
		},
	})
}
