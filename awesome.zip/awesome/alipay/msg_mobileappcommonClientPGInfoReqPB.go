package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"fmt"
	"github.com/golang/protobuf/proto"
	"strconv"
)

// 上报客户端获取到的权限
func (w *WorkGroup) sendMobileappcommonClientPGInfoReqPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MobileappcommonClientPGInfoRespPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("MobileappcommonClientPGInfoRespPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("MobileappcommonClientPGInfoRespPB, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				w.acc.LastPGInfoTime, _ = strconv.ParseInt(respObj.GetLastTime(), 10, 64)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcPGInfo,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.MobileappcommonClientPGInfoReqPB{
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		ClientId:       proto.String(fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI)),
		MobileModel:    proto.String(tools.PhoneName(w.acc.Device.Model)),
		Manufacturer:   proto.String("apple"),
		MobileBrand:    proto.String("apple"),
		NetType:        proto.String("WIFI"),
		Utdid:          proto.String(w.acc.UTDID),
		LastTime:       proto.String(strconv.FormatInt(w.acc.LastPGInfoTime, 10)),
		Platform:       proto.String("ios"),
		OsVersion:      proto.String(w.acc.Device.SysVer),
		ExtraData: []*pb.MobileappcommonPgDataPB{
			{
				Key:   proto.String("NOTIFICATION"),
				Value: proto.String("0"),
			}, {
				Key:   proto.String("LBS"),
				Value: proto.String("0"),
			}, {
				Key:   proto.String("LBSSERVICE"),
				Value: proto.String("0"),
			}, {
				Key:   proto.String("CAMERA"),
				Value: proto.String("1"),
			}, {
				Key:   proto.String("PHOTO"),
				Value: proto.String("1"),
			}, {
				Key:   proto.String("ADDRESSBOOK"),
				Value: proto.String("0"),
			}, {
				Key:   proto.String("MICROPHONE"),
				Value: proto.String("1"),
			},
		},
	})
}
