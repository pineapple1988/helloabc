package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendMOBILEAPPABTestConfigRequestPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MOBILEAPPABTestConfigResponsePB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("MOBILEAPPABTestConfigResponsePB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("MOBILEAPPABTestConfigResponsePB, resp: \r\n%+v", proto.MarshalTextString(respObj))

		}
	}
	headers := map[string]string{
		"Operation-Type": RpcABTestConfig,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.MOBILEAPPABTestConfigRequestPB{
		Params: []*pb.MOBILEAPPClientParamPB{
			{
				Key:   proto.String("productVersion"),
				Value: proto.String(ProductVersion),
			}, {
				Key:   proto.String("os"),
				Value: proto.String("iphone"),
			}, {
				Key:   proto.String("phoneBrand"),
				Value: proto.String("apple"),
			}, {
				Key:   proto.String("phoneModel"),
				Value: proto.String("iPhone"),
			}, {
				Key:   proto.String("osVersion"),
				Value: proto.String(w.acc.Device.SysVer),
			}, {
				Key:   proto.String("clientAutoLoginStatus"),
				Value: proto.String("false"),
			},
		},
		ProductName:        proto.String("alipay"),
		IdentificationCode: proto.String(""),
	})
}
