package alipay

import (
	"awesome/tools"
	"bytes"
	"compress/gzip"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"github.com/go-http-utils/headers"
	"io/ioutil"
	"math/rand"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// DeserializeLen 反序列化长度
func deserializeLen(buf []byte, pos int) (x int32, n int) {
	for shift := 0; shift < 4; shift++ {
		if (n + pos) >= len(buf) {
			return 0, 0
		}
		b := int32(buf[n+pos])
		n++
		x = (x << 7) | (b & 0x7F)
		if (b & 0x80) == 0 {
			return x, n
		}
	}

	return 0, 0
}

// SerializeLen 序列化长度
func serializeLen(x int32) []byte {
	var buf []byte
	if x > 127 {
		b := false
		for n := uint32(21); n > 0; n -= 7 {
			k := (x >> n) & 0x7F
			if k != 0 || b {
				buf = append(buf, uint8(k|0x80))
				b = true
			}
		}
	}

	buf = append(buf, byte(x&0x7f))

	return buf
}

func digits10toMy64(x int64) string {
	table := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")

	index := 11
	arr := make([]byte, index)

	for x > 0 {
		index--
		arr[index] = table[x&0x3F]
		x >>= 6
	}

	return string(arr[index:])
}

func my64toDigits10(x string) int64 {
	table := "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/"

	v := int64(0)
	for _, i := range x {
		v <<= 6
		index := strings.IndexRune(table, i)
		v += int64(index)
	}

	return v
}

func tfToken() string {
	rand.Seed(time.Now().UnixNano())
	r := int64(rand.Uint32())
	r1 := r * 0x51eb851f
	r2 := int32(r1>>63) + int32(r1>>37)
	r3 := int32(r) - r2*0x64

	return fmt.Sprintf("%d%d", tools.Timestamp(), r3)
}

func newUTDID() string {
	ts := tools.Timestamp()
	r := tools.RandBetween(0x10000000, 0xFFFFFFFF)
	uuid := strings.ToUpper(tools.NewUUID())
	hc := hashCode(uuid)

	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, ts)
	_ = binary.Write(buffer, binary.BigEndian, uint32(r))
	_ = binary.Write(buffer, binary.BigEndian, uint8(3))
	_ = binary.Write(buffer, binary.BigEndian, uint8(0))
	_ = binary.Write(buffer, binary.BigEndian, hc)

	hb := hmacBase64Value(buffer.Bytes(), UTDIDHmacKey)
	_ = binary.Write(buffer, binary.BigEndian, hashCode(hb))

	return base64.StdEncoding.EncodeToString(buffer.Bytes())
}

// HashCode 计算字符串的hashcode
func hashCode(str string) uint32 {
	if str == "" {
		return 0
	}

	b := []byte(str)
	var r uint32
	for i := 0; i < len(b); i++ {
		r = uint32(b[i]) + 31*r
	}

	return r
}

// HMACBase64Value 计算hmac值
func hmacBase64Value(in []byte, key string) string {
	h := hmac.New(sha1.New, []byte(key))
	h.Write(in)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

func miniwuaEncrypt(str string, key, iv []byte) string {
	arr, _ := base64.StdEncoding.DecodeString(str)

	buf := []byte{0x13, 0x7F, 0x40, 0x24, 0x00}
	buf[0] = byte(tools.RandBetween(0x10, 0xFF))
	buf[1] = byte(tools.RandBetween(0x10, 0xFF))

	buf = append(buf, arr...)
	arr = []byte{0x8A, 0x16, 0x00, 0x44, 0x22, 0x80}
	buf = append(buf, arr...)

	idx := 0
	for i := 5; i < len(buf); i++ {
		buf[i] ^= buf[idx]
		idx ^= 1
	}

	b := []byte{0, 0, 0, 1}
	b = append(b, buf...)

	d := tools.AESCBCEncrypt(b, key, iv)

	return "HHnB_" + base64.StdEncoding.EncodeToString(d)
}

func (w *WorkGroup) httpUserAgent() string {
	return fmt.Sprintf("%s/%s CFNetwork/897.15 Darwin/%s",
		url.QueryEscape("支付宝"), ProductVersion, tools.KernelVersion(w.acc.Device.SysVer))
}

func (w *WorkGroup) httpUserAgent1() string {
	return fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E216 NebulaSDK/1.8.100112 Nebula WK PSDType(1) AlipayDefined(nt:WIFI,ws:375|603|2.0) AliApp(AP/%s) AlipayClient/%s Language/zh-Hans Region/CN",
		strings.ReplaceAll(w.acc.Device.SysVer, ".", "_"), ProductVersion, ProductVersion)
}

func httpGetBody(resp *http.Response) (string, error) {
	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		var err error
		if body, err = gzip.NewReader(body); err != nil {
			return "", err
		}
	}

	data, err := ioutil.ReadAll(body)
	if err != nil {
		return "", err
	}

	// 如果有gbk编码转成utf8
	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "GBK") || strings.Contains(ct, "gbk") {
		var err error
		if data, err = tools.GBK2UTF8(data); err != nil {
			return "", err
		}
	}

	return string(data), nil
}

func (w *WorkGroup) httpGet(url, referer string) string {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return ""
	}

	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("ts", strconv.FormatInt(tools.TimestampEx(), 10))
	req.Header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	req.Header.Set(headers.UserAgent, w.httpUserAgent1())
	req.Header.Set(headers.AcceptLanguage, "zh-CN,en-US;q=0.8")
	req.Header.Set("X-Alipay-Client-Session", "check")
	// 缺少一个sign字段，后续补充
	//req.Header.Set("sign", "c4647d4176b56a228c4150573f6cf337")
	if referer != "" {
		req.Header.Set(headers.Referer, referer)
	}

	resp, err := w.Do(req)
	if err != nil {
		return ""
	}

	defer resp.Body.Close()

	r, _ := httpGetBody(resp)

	return r
}

func (w *WorkGroup) httpPost(url, body string, postForm bool, referer string) string {
	req, err := http.NewRequest("POST", url, strings.NewReader(body))
	if err != nil {
		return ""
	}

	req.Header.Set(headers.Accept, "application/json, text/javascript")
	req.Header.Set("X-Requested-With", "XMLHttpRequest")
	req.Header.Set(headers.AcceptLanguage, "zh-CN,en-US;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("ts", strconv.FormatInt(tools.TimestampEx(), 10))
	req.Header.Set(headers.UserAgent, w.httpUserAgent1())

	if postForm {
		req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	}

	if referer != "" {
		req.Header.Set(headers.Referer, referer)
	}

	req.Header.Set("X-Alipay-Client-Session", "check")

	resp, err := w.Do(req)
	if err != nil {
		return ""
	}

	defer resp.Body.Close()

	r, _ := httpGetBody(resp)

	return r
}
