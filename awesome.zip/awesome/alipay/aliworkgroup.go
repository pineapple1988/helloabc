package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/manager"
	"awesome/alipay/model/pb"
	"awesome/alipay/mynet"
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"encoding/hex"
	"math/rand"
	"net"
	"sync"
	"time"

	"github.com/golang/protobuf/proto"
)

// WorkGroupHandler workgroup事件处理
type WorkGroupHandler interface {
	OnEvent(event, code int, msg string, data interface{})
}

// PacketData 封包数据
type PacketData struct {
	Head []byte
	Body []byte
}

type WorkGroup struct {
	mynet.MyConn
	mynet.MyHttpClient
	acc          *Account
	lastRspTime  int64 // 最后响应时间
	Heart        *AliHeart
	hpackEncoder *hpack.Encoder
	hpackDecoder *hpack.Decoder
	hpackLock    sync.Mutex
	encodeBuffer *bytes.Buffer
	recvBuffer   []byte // 接收缓冲区
	packetChan   chan *PacketData
	rpcId        uint64
	cbInfo       map[string]HttpCallback
	handler      WorkGroupHandler
	initChan     chan bool
}

func New(acc *Account) *WorkGroup {
	w := &WorkGroup{
		acc:      acc,
		handler:  nil,
		initChan: make(chan bool),
	}
	w.MyConn = *mynet.NewMyConn(w)
	w.MyHttpClient = *mynet.NewMyHttpClient(&acc.Cookies)
	return w
}

// GetAcc 取帐号
func (w *WorkGroup) GetAcc() *Account {
	return w.acc
}

// SetHandler 设置事件处理接口
func (w *WorkGroup) SetHandler(handler WorkGroupHandler) {
	w.handler = handler
}

func (w *WorkGroup) Connect() {
	addr := net.JoinHostPort(w.acc.IP, w.acc.Port)
	w.Start(addr, true)
}

func (w *WorkGroup) DisConnect() {
	//manager.SaveSyncInfo(w.acc.AccName)
	w.Stop()
}

// OnConnected 连接成功或失败
func (w *WorkGroup) OnConnected(err error) {
	if err == nil {
		log2.Info("[WorkGroup]连接服务器成功.")
		// 连接成功，初始化数据
		w.recvBuffer = []byte{}
		w.cbInfo = make(map[string]HttpCallback, 8)
		w.packetChan = make(chan *PacketData, 0x8)
		w.rpcId = 999 // 重1000开始
		w.encodeBuffer = bytes.NewBuffer(make([]byte, 2048))
		w.hpackEncoder = hpack.NewEncoder(w.encodeBuffer)
		w.hpackDecoder = hpack.NewDecoder(2048, nil)
		// 加载syncInfo
		manager.LoadSyncInfo(w.acc.AccName)
		// 启动计时器，开启心跳
		w.Heart = &AliHeart{}
		w.Heart.StartHeart(w)
		go w.packetRoutine()
		go w.initRoutine()
		//if config.IsRunAsSvc() {
		//	go w.workRoutine()
		//} else {
		// 测试用，正式需要去掉
		go w.testRoutine()
		//}

	} else {
		log2.Errorf("[WorkGroup]连接服务器失败, 错误: %+v", err)
		w.notifyEvent(EventTypeLogin, LoginCodeNetError, "连接服务器失败", nil)
	}
}

func (w *WorkGroup) Run() {
	w.Heart.SendHeart(w)
}

// OnClose 关闭连接
func (w *WorkGroup) OnClose() {
	log2.Info("[WorkGroup|OnClose]")
	w.Heart.StopHeart()
	close(w.packetChan)
}

// OnReceived 接收到网络数据
func (w *WorkGroup) OnReceived(data []byte) {
	if len(data) <= 0 {
		return
	}

	if len(w.recvBuffer) > 0 && w.recvBuffer[0] != 0x90 {
		// 缓冲区还有数据时第一个字节必须是0x90, 否则丢弃
		log2.Errorf("[WorkGroup]缓冲区数据第一位不是0x90, 丢弃缓冲区数据: \r\n%+v.", hex.Dump(w.recvBuffer))
		w.recvBuffer = []byte{}
	}

	// 添加到缓冲区
	w.recvBuffer = append(w.recvBuffer, data...)

	// 开始拆包
	for {
		if len(w.recvBuffer) > 0 && w.recvBuffer[0] != 0x90 {
			log2.Errorf("[WorkGroup]接收数据第一位不是0x90, 丢弃数据: \r\n%+v.", hex.Dump(w.recvBuffer))
			w.recvBuffer = []byte{}
			break
		}
		pos := 1
		// 头部长度
		headerLen, n := deserializeLen(w.recvBuffer, pos)
		if n == 0 {
			break
		}
		pos += n

		// 消息体长度
		bodyLen, n := deserializeLen(w.recvBuffer, pos)
		if n == 0 {
			break
		}
		pos += n

		packetLen := pos + int(headerLen+bodyLen)
		// 不够一个包长度
		if len(w.recvBuffer) < packetLen {
			log2.Info("[WorkGroup]接收到数据长度不足一个包")
			break
		}

		bodyPos := pos + int(headerLen)
		bodyEnd := pos + int(headerLen+bodyLen)
		// 处理整个包
		packet := &PacketData{
			Head: w.recvBuffer[pos:bodyPos],
			Body: w.recvBuffer[bodyPos:bodyEnd],
		}
		w.packetChan <- packet
		// 清理处理的
		w.recvBuffer = w.recvBuffer[bodyEnd:]
	}
}

// OnError 连接出现错误
func (w *WorkGroup) OnError(err error) {
	log2.Errorf("[WorkGroup|OnError]:%+v.", err)
}

// 处理每一个包
func (w *WorkGroup) packetRoutine() {
	defer log2.Info("[WorkGroup|packetRoutine]结束处理数据协程.")
	for data := range w.packetChan {
		if data == nil {
			break
		}
		// 头
		mmtpHead := &pb.MmtpHead{}
		if len(data.Head) > 0 {
			if err := proto.Unmarshal(data.Head, mmtpHead); err != nil {
				log2.Errorf("[WorkGroup]数据头反序列化失败, 错误: %+v, 数据: %+v.", err, data.Head)
				continue
			}
		}
		// 解压
		if mmtpHead.GetZipType() == 1 {
			body, err := tools.GZipUncompress(data.Body)
			if err != nil {
				log2.Errorf("[WorkGroup]数据GZip解压失败, 错误: %+v, 数据: %+v.", err, data.Body)
				continue
			}

			data.Body = body
		}
		headLen := mmtpHead.GetDataFrameHeadLength()
		var htt2Head []hpack.HeaderField
		if headLen > 0 {
			var err error
			htt2Head, err = w.hpackDecoder.DecodeFull(data.Body[:headLen])
			if err != nil {
				log2.Errorf("[WorkGroup]HPACK解码失败, 错误: %+v, 数据: %+v.", err, data.Body[:headLen])
				continue
			}
		}
		w.processPacket(mmtpHead, htt2Head, data.Body[headLen:])
		w.lastRspTime = tools.TimestampEx()
	}
}

func (w *WorkGroup) workRoutine() {
	<-w.initChan
	//logger.Debug("[WorkGroup]workRoutine =====>>> 1111")
	time.Sleep(time.Second * time.Duration(3+rand.Intn(5)))
	//logger.Debug("[WorkGroup]workRoutine =====>>> 2222")
	w.loginRoutine()
}

func (w *WorkGroup) testRoutine() {
	first := true
	for {
		time.Sleep(time.Second * 30)

		// 存储一下数据
		w.acc.Save()

		if !w.acc.IsLogin && first {
			go w.loginRoutine()
			first = false
		} else {
			w.sendV99()
			//w.sendQuery(nil, "订单编号")
			//w.sendQrCode("10.00", "hdjsdhks")
			//w.sendQuery(nil, "订单编号", 0, 0)
			//w.sendQuerySingleBillDetailForH5("D_TRANSFER", "20190914200040011100750046848118")
			//w.sendQuery(nil, "", 0, 0)
			//w.sendTransListReq(1)
			//w.TransferToCard(&TransferReq{
			//	TransferCardNo:   "622908393182295611",
			//	Amount:           "0.01",
			//	Remark:           "789456",
			//	RealName:         "王文美",
			//	OnTransferResult: func(result *TransferRes) {
			//		log2.Infof("TransferRes %+v", result)
			//	},
			//})
			//w.acc.PayPwd = "181814"
			//w.TransferTo(&TransferReq{
			//	TransferAcc:      "13915054625",
			//	Amount:           "0.01",
			//	Remark:           "hello",
			//	RealName:         "朱超",
			//	OnTransferResult: func(result *TransferRes) {
			//		log2.Infof("TransferRes %+v", result)
			//	},
			//})
			//time.Sleep(time.Second * 50)
			//
			//w.acc.PayPwd = "181818"
			//w.TransferTo(&TransferReq{
			//	TransferAcc:      "13915054625",
			//	Amount:           "0.01",
			//	Remark:           "hello",
			//	RealName:         "朱超",
			//	OnTransferResult: func(result *TransferRes) {
			//		log2.Infof("TransferRes %+v", result)
			//	},
			//})
		}
	}
}

func (w *WorkGroup) notifyEvent(event, code int, msg string, data interface{}) {
	//if config.IsRunAsSvc() && w.handler != nil {
	//	w.handler.OnEvent(event, code, msg, data)
	//	return
	//}
}
