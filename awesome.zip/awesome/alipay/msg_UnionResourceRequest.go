package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"fmt"
	"github.com/golang/protobuf/proto"
	"strconv"
)

func (w *WorkGroup) sendUnionResourceRequest() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.UnionResourceResult{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("UnionResourceResult, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("UnionResourceResult, resp: \r\n%+v", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				for _, info := range respObj.GetInfo() {
					if info.GetSuccess() {
						for _, item := range info.GetItem() {
							resId, _ := strconv.Atoi(item.GetResId())
							hpid, _ := strconv.Atoi(w.acc.Hpid)
							if resId > hpid {
								w.acc.Hpid = item.GetResId()
							}
						}
					}
				}
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcUnionResource,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.UnionResourceRequest{
		Platform:       pb.UnionPlatformType_ios.Enum(),
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		ReleaseVersion: proto.String(ProductVersion),
		Utdid:          proto.String(w.acc.UTDID),
		ClientId:       proto.String(fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI)),
		PhoneBrand:     proto.String("apple"),
		PhoneModel:     proto.String(tools.PhoneName(w.acc.Device.Model)),
		OsVersion:      proto.String(w.acc.Device.SysVer),
		NetType:        proto.String("WIFI"),
		ResourceParam: []*pb.UnionResourceParam{
			{
				BizType: pb.UnionResourceBizType_IOSFRAMEWORK.Enum(),
			}, {
				BizType: pb.UnionResourceBizType_BUNDLE.Enum(),
			}, {
				BizType: pb.UnionResourceBizType_HOTPATCH.Enum(),
			}, {
				BizType: pb.UnionResourceBizType_CMD.Enum(),
			},
		},
		Uid: proto.String(w.acc.UserId),
		CpuInstructionList: []string{
			"arm64",
		},
	})
}
