package alipay

import (
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendSTMessage(action pb.Actions) {
	req := &pb.STMessage{
		Action: action.Enum(),
	}

	pd, err := proto.Marshal(req)
	if err != nil {
		log2.Errorf("[WorkGroup]STMessage序列化错误: %+v.", err)
	} else {
		mmtp := &pb.MmtpHead{
			Type:             proto.Uint32(4),
			DataFrameChannel: proto.Uint32(0),
		}
		w.SendMessage(mmtp, nil, pd)
	}
}

func (w *WorkGroup) sendSTMessageUserLogin() {
	req := &pb.STMessage{
		Action: pb.Actions_USERLOGIN.Enum(),
		UserId: proto.String(w.acc.UserId),
		ChannelExtBytes: []*pb.ChannelExtBytes{
			{
				ChannelId: proto.Int32(2),
				ExtParams: append([]byte{0x06, 0x0B, 0xB9}, w.getProtoSyncOpCode3001()...)},
		},
	}
	pd, err := proto.Marshal(req)
	if err != nil {
		log2.Errorf("[WorkGroup]STMessage序列化错误: %+v.", err)
	} else {
		mmtp := &pb.MmtpHead{
			Type:             proto.Uint32(4),
			DataFrameChannel: proto.Uint32(0),
		}
		w.SendMessage(mmtp, nil, pd)
	}
}

func (w *WorkGroup) onSTMessage(resp []byte) {
	respObj := &pb.STMessage{}
	if err := proto.Unmarshal(resp, respObj); err != nil {
		log2.Infof("onSTMessage, proto.Unmarshal err: %+v", err)
	} else {
		log2.Infof("onSTMessage, resp:\r\n%+v", proto.MarshalTextString(respObj))
		switch respObj.GetAction() {
		case pb.Actions_SESSION_NEED_REACTIVE:
			// 来了这个才需要再次登陆，否者直接发包就好了
			if w.acc.IsLogin {
				w.sendUserLogin()
			} else {
				w.sendSTMessage(pb.Actions_USERLOGOUT)
			}
		}
	}
}
