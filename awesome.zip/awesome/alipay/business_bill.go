package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"math/rand"
	"time"

	"github.com/golang/protobuf/proto"
)

// BillInfo 帐单信息
type BillInfo struct {
	TradeNo       string
	ConsumeTitle  string
	ConsumeFee    string
	ConsumeStatus string
	TradeTime     int64
	CreateDesc    string
	Inout         string
}

type queryTransListReq struct {
	NextPage       int32  `json:"nextPage"`  // nextPage重1开始
	PageCount      int32  `json:"pageCount"` // 每一页的数据条数
	TimeRange      string `json:"timeRange"` // 1 month
	QueryTransPage string `json:"queryTransPage"`
}

type bizResult struct {
	AppName      string `json:"appName"`
	FollowAction string `json:"followAction"`
	Message      string `json:"message"`
	ResultCode   int32  `json:"resultCode"`
	Success      bool   `json:"success"`
}
type transListVO struct {
	Balance          string `json:"balance"`          // 余额
	Date             string `json:"date"`             // 时间
	Money            string `json:"money"`            // 收入/支出
	SimpleDate       string `json:"simpleDate"`       // 简单时间
	TransInstitution string `json:"transInstitution"` // 支付方式
	TransLogId       string `json:"transLogId"`       // 流水号
	TransMemo        string `json:"transMemo"`        // 备注
	TransType        string `json:"transType"`        // 类型
}
type queryTransListRes struct {
	BizResult  bizResult     `json:"bizResult"`
	Page       int32         `json:"page"`
	PageCount  int32         `json:"pageCount"`
	TimeRange  string        `json:"timeRange"`
	TotalCount int64         `json:"totalCount"`
	TranList   []transListVO `json:"tranList"`
}

// 查询余额明细列表 不可删除或隐藏 只能查询一个月的账单 从1开始
func (w *WorkGroup) sendTransListReq(nextPage int32) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &queryTransListRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendTransList, json.Unmarshal err: %+v", err)
		} else {
			log2.Infof("sendTransList, resp: \r\n%+v.", string(resp))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcGetTranList,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &queryTransListReq{
		NextPage:       nextPage,
		PageCount:      20,
		QueryTransPage: "1m",
	})
}

// 查询账单列表 可以删除
// paging 获取最新的传nil,翻页就是使用上次一拉单返回的paging
// keyword 为搜索关键字查询订单
// startTime, endTime 13位时间戳 一天是相差86399000 不使用时间就写0
func (w *WorkGroup) sendQuery(paging *pb.PagingCondition, keyword string, startTime, endTime int64) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.QueryListRes{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendQuery, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("sendQuery, resp: \r\n%+v.", proto.MarshalTextString(respObj))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcQueryBillListPB,
		"retryable2":     "1",
	}
	scene := "BILL_LIST"
	if len(keyword) > 0 {
		scene = "KEY_SEARCH"
	}
	dateType := ""
	needMonthSeparator := true
	if startTime != 0 && endTime != 0 {
		dateType = "day"
		needMonthSeparator = false
	}

	w.SendHttpMessage(onResp, headers, &pb.QueryListReq{
		Category:               proto.String("ALL"),
		PageType:               proto.String(""),
		Paging:                 paging,
		SearchKeywords:         proto.String(keyword),
		NeedMonthSeparator:     proto.Bool(needMonthSeparator),
		Month:                  proto.String(""),
		BizType:                proto.String(""),
		BizSubType:             proto.String(""),
		Scene:                  proto.String(scene),
		Date:                   proto.String(""),
		Inout:                  proto.String(""),
		Product:                proto.String(""),
		OppositeCardNo:         proto.String(""),
		BizState:               proto.String(""),
		ConsumeStatus:          proto.String(""),
		ExtReq:                 proto.String(""),
		StartTime:              proto.Int64(startTime),
		EndTime:                proto.Int64(endTime),
		CategoryId:             proto.String(""),
		SubCategoryId:          proto.String(""),
		FloorAmount:            proto.String(""),
		CeilAmount:             proto.String(""),
		BillMonthCategoryId:    proto.String(""),
		BillMonthSubCategoryId: proto.String(""),
		ExtraFilter:            proto.String(""),
		BatchTagId:             proto.String(""),
		AsyncQueryTaskId:       proto.Int64(0),
		DateType:               proto.String(dateType),
		OldCategoryName:        proto.String(""),
		OrderType:              proto.String(""),
		FundState:              proto.String(""),
		BizExtraNo:             proto.String(""),
		BizOutNo:               proto.String(""),
	})
}

// 查询账单列表 可以删除
// paging 获取最新的传nil,翻页就是使用上次一拉单返回的paging
// keyword 为搜索关键字查询订单
// startTime, endTime 13位时间戳 一天是相差86399000
func (w *WorkGroup) sendQueryEx(list []*BillInfo, paging *pb.PagingCondition, keyword string, startTime, endTime int64) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.QueryListRes{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendQuery, proto.Unmarshal err: %+v", err)
			if len(list) > 0 {
				w.notifyEvent(EventTypeBill, BillCodeSuccess, "", list)
			} else {
				w.notifyEvent(EventTypeBill, BillCodeError, "解释帐单数据错误", nil)
			}
		} else {
			log2.Infof("sendQuery, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			for _, v := range respObj.GetBillListItems() {
				if v.GetRecordType() == pb.RecordType_MONTH {
					continue
				}

				info := &BillInfo{
					TradeNo:       v.GetBizInNo(),
					ConsumeTitle:  v.GetConsumeTitle(),
					ConsumeFee:    v.GetConsumeFee(),
					ConsumeStatus: v.GetConsumeStatus(),
					TradeTime:     v.GetGmtCreate(),
					CreateDesc:    v.GetCreateDesc(),
					Inout:         v.GetInout(),
				}

				list = append(list, info)
			}

			// 可以翻页, 进行翻页操作
			if respObj.GetHasMore() && respObj.GetPaging() != nil {
				time.Sleep(time.Second * time.Duration(1+rand.Intn(3)))
				go w.sendQueryEx(list, respObj.GetPaging(), keyword, startTime, endTime)
				return
			}

			w.notifyEvent(EventTypeBill, BillCodeSuccess, "", list)
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcQueryBillListPB,
		"retryable2":     "1",
	}
	scene := "BILL_LIST"
	if len(keyword) > 0 {
		scene = "KEY_SEARCH"
	}
	dateType := ""
	needMonthSeparator := true
	if startTime != 0 && endTime != 0 {
		dateType = "day"
		needMonthSeparator = false
	}

	w.SendHttpMessage(onResp, headers, &pb.QueryListReq{
		Category:               proto.String("ALL"),
		PageType:               proto.String(""),
		Paging:                 paging,
		SearchKeywords:         proto.String(keyword),
		NeedMonthSeparator:     proto.Bool(needMonthSeparator),
		Month:                  proto.String(""),
		BizType:                proto.String(""),
		BizSubType:             proto.String(""),
		Scene:                  proto.String(scene),
		Date:                   proto.String(""),
		Inout:                  proto.String(""),
		Product:                proto.String(""),
		OppositeCardNo:         proto.String(""),
		BizState:               proto.String(""),
		ConsumeStatus:          proto.String(""),
		ExtReq:                 proto.String(""),
		StartTime:              proto.Int64(startTime),
		EndTime:                proto.Int64(endTime),
		CategoryId:             proto.String(""),
		SubCategoryId:          proto.String(""),
		FloorAmount:            proto.String(""),
		CeilAmount:             proto.String(""),
		BillMonthCategoryId:    proto.String(""),
		BillMonthSubCategoryId: proto.String(""),
		ExtraFilter:            proto.String(""),
		BatchTagId:             proto.String(""),
		AsyncQueryTaskId:       proto.Int64(0),
		DateType:               proto.String(dateType),
		OldCategoryName:        proto.String(""),
		OrderType:              proto.String(""),
		FundState:              proto.String(""),
		BizExtraNo:             proto.String(""),
		BizOutNo:               proto.String(""),
	})
}

// SendQueryEx 查询帐单
func (w *WorkGroup) SendQueryEx(startTime, endTime int64) {
	list := []*BillInfo{}
	w.sendQueryEx(list, nil, "", startTime, endTime)
}

type singleBillDetailForH5Req struct {
	BizType string `json:"bizType"`
	TradeNo string `json:"tradeNo"`
}

// 查询订单详情
// bizType "TRADE"/"D_TRANSFER" 不知道就填""
// tradeNo 支付宝订单号
func (w *WorkGroup) sendQuerySingleBillDetailForH5(bizType, tradeNo string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		// {
		//    "buttons": [
		//
		//    ],
		//    "code": 0,
		//    "extension": {
		//        "bizInNo": "20190914200040011100750046848118",
		//        "bizType": "D_TRANSFER",
		//        "gmtBizCreateTime": "1568475287000",
		//        "mdata": "{\"conbiz_biztype\":\"D_TRANSFER\",\"conbiz_bizinno\":\"20190914200040011100750046848118\",\"conbiz_bizsubtype\":\"1106\",\"conbiz_opp_uid\":\"2088922027799889\"}" -> conbiz_opp_uid为付款方userId
		//    },
		//    "fields": [
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailTitle",
		//            "type": "birdNest",
		//            "value": "{\"goto\":\"alipays://platformapi/startapp?appId=09999988&actionType=toAccount&userId=2088922027799889&sourceId=bill\",\"icon\":\"https://t.alipayobjects.com/images/partner/TB1VbBPaaFzDuNkUuyQXXbFwXXa_[pixelWidth]x.png\",\"content\":\"巴萨斯诺曼(*超)\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailPrice",
		//            "type": "birdNest",
		//            "value": "{\"Amount\":\"-0.01\",\"statusColor\":\"#A5A5A5\",\"status\":\"交易成功\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailCommon",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"余额\",\"goto\":\"alipays://platformapi/startapp?appId=20000019&path=detaillist\",\"needVerify\":false,\"seed\":\"billPayToolInfo\"}],\"title\":\"付款方式\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailCommon",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"转账\",\"needVerify\":false}],\"title\":\"转账备注\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailCommon",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"巴萨斯诺曼(*超) 139******25\",\"needVerify\":false}],\"title\":\"对方账户\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailSplitLine",
		//            "type": "birdNest"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailCommon",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"2019-09-14 23:34\",\"needVerify\":false}],\"title\":\"创建时间\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailCommon",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"20190914200040011100750046848118\",\"needVerify\":false}],\"title\":\"订单号\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailBlankArea",
		//            "type": "birdNest",
		//            "value": ""
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLNewCategory",
		//            "type": "birdNest",
		//            "value": "{\"content\":\"转账充值\",\"needVerify\":false,\"seed\":\"billLifeCategory\",\"title\":\"账单分类\"}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailLink",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"content\":\"\",\"goto\":\"alipays://platformapi/startapp?appId=66666698&url=%2Fwww%2Findex.html%3FgmtBizCreate%3D1568475287000%26bizInNo%3D20190914200040011100750046848118%26bizType%3DD_TRANSFER%26tagTitle%3D%E6%A0%87%E7%AD%BE%26essayTitle%3D%E5%A4%87%E6%B3%A8\",\"needVerify\":false,\"seed\":\"billTagAndEssay\",\"title\":\"标签和备注\"}]}"
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailBlankArea",
		//            "type": "birdNest",
		//            "value": ""
		//        },
		//        {
		//            "locationPage": "main",
		//            "templateId": "BLDetailLink",
		//            "type": "birdNest",
		//            "value": "{\"data\":[{\"goto\":\"alipays://platformapi/startApp?appId=20000076&actionType=toBillList&scene=CONTACT_BILL_DETAIL&oppositeCardNo=2088922027799889&title=巴萨斯诺曼(*超)\",\"infoLevel\":\"10\",\"needVerify\":false,\"seed\":\"contactQuery\",\"title\":\"查看往来记录\"},{\"goto\":\"alipays://platformapi/startapp?appId=20000067&url=https%3A%2F%2Fcsmobile.alipay.com%2Fhall%2Ftips.htm%3Fscene%3Dmbill_tips%26errorCode%3DMBILL_TIPS%26bizNo%3D20190914200040011100750046848118\",\"infoLevel\":\"3\",\"needVerify\":false,\"seed\":\"selfHelp\",\"title\":\"对此订单有疑问\"},{\"goto\":\"alipays://platformapi/startapp?appId=20000067&url=https%3A%2F%2Fsecurityassistant.alipay.com%2Fflow%2FsmartReport.htm%3FbizInNo%3D20190914200040011100750046848118%26groupBizInNo%3D20190914200040011100750046848118%26reportSource%3D01\",\"infoLevel\":\"2\",\"needVerify\":false,\"seed\":\"complaint\",\"title\":\"投诉\"}]}"
		//        }
		//    ],
		//    "logisticsModel": {
		//        "nodes": [
		//
		//        ]
		//    },
		//    "refundModel": {
		//        "fundBatch": [
		//
		//        ]
		//    },
		//    "succ": true
		//}
		log2.Infof("sendQuerySingleBillDetailForH5, resp: \r\n%+v.", string(resp))
	}
	headers := map[string]string{
		"Operation-Type": RpcQuerySingleBillDetailForH5,
		"retryable2":     "1",
		"lastClickSpm":   "",
		"nbappid":        "66666676",
		"nbversion":      NBVersion,
		"package_nick":   "6.3.38",
		"pagets":         fmt.Sprintf("a113.b2456__%s_", digits10toMy64(tools.TimestampEx())),
		"srcSpm":         "a113.b7166",
		"x-nb-appid":     "AP_66666676_ios",
	}
	w.SendHttpMessage(onResp, headers, &singleBillDetailForH5Req{
		BizType: bizType,
		TradeNo: tradeNo,
	})
}
