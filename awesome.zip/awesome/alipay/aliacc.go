package alipay

import (
	"awesome/tools"
	"errors"
	"fmt"
	"strconv"
	"strings"

	uuid "github.com/satori/go.uuid"
)

const (
	alipayAccountKey = "AlipayAccount"
)

// Account 支付宝登录帐号结构体
type Account struct {
	Device         tools.IosDevice   `json:"device"`
	AccName        string            `json:"zfbAccName"`
	UserId         string            `json:"userId"`
	LoginPwd       string            `json:"loginPwd"`
	PayPwd         string            `json:"payPwd"`
	Balance        string            `json:"balance"`
	IsLogin        bool              `json:"isLogin"`
	UTDID          string            `json:"utdid"`
	ClientKey      string            `json:"clientKey"`
	TID            string            `json:"tid"`
	RandomAPDID    string            `json:"randomApdid"`
	APDID          string            `json:"apdid"`
	APDIDToken     string            `json:"apdidToken"`
	VIMEI          string            `json:"vimei"`
	VIMSI          string            `json:"vimsi"`
	AWID           string            `json:"awid"`     // 随机生成的
	DeviceID       string            `json:"deviceId"` // 转账有用到
	Miniwua        string            `json:"miniwua"`
	UMIDToken      string            `json:"umidToken"`
	MmtpDid        string            `json:"mmtpDid"`
	SessionID      string            `json:"sessionId"`
	DynamicKey     string            `json:"dynamicKey"`
	UUID1          string            `json:"uuid1"` // /var/mobile/Containers/Data/Application/FEA27996-6BD6-4E06-AE02-3C39D4567AA5
	UUID2          string            `json:"uuid2"` // /var/containers/Bundle/Application/C6FF64D0-ACE9-4C71-8D47-851A00517424/AlipayWallet.app/Info.plist
	UUID3          string            `json:"uuid3"`
	UUID4          string            `json:"uuid4"`
	Hpid           string            `json:"hpid"`           // 资源文件的id
	Cookies        map[string]string `json:"cookies"`        // cookie 存储
	LastReportTime int64             `json:"lastReportTime"` // ReportRequestPB 使用
	ReportInterval int64             `json:"reportInterval"` // ReportRequestPB发送时间间隔
	LastQueryTime  int64             `json:"lastQueryTime"`  // FetchLatestReq 使用
	LastSwitchTime int64             `json:"lastSwitchTime"` // SwitchInfoRespPb 使用
	LastPGInfoTime int64             `json:"lastPGInfoTime"` // MobileappcommonClientPGInfoReqPB 使用
	MspSwitchVer   string            `json:"mspSwitchVer"`
	IP             string            `json:"ip"`
	Port           string            `json:"port"`
	QrCodeReq      *createSessionReq `json:"qrCode"` // 二维码
	loginRsaPubKey string            // 登陆密码加密用
	verify         *VerifyInfo       // 登陆验证
	transferReq    *TransferReq      // 转账请求
}

func NewAccount(zfbAcc, loginPwd, payPwd string) *Account {
	a := &Account{
		AccName:        zfbAcc,
		UserId:         "",
		LoginPwd:       loginPwd,
		PayPwd:         payPwd,
		Balance:        "",
		IsLogin:        false,
		LastReportTime: 86400000,
		Device:         tools.IosDevice{},
	}
	a.IP = AlipayHost
	a.Port = AlipayPort
	VUDID := tools.RandString(30)
	a.Hpid = "0"
	a.VIMEI = VUDID[:15]
	a.VIMSI = VUDID[15:]
	a.ClientKey = tools.RandString(10)
	a.RandomAPDID = strings.ToUpper(uuid.NewV4().String())
	a.AWID = strings.ToUpper(uuid.NewV4().String())
	a.UUID1 = strings.ToUpper(uuid.NewV4().String())
	a.UUID2 = strings.ToUpper(uuid.NewV4().String())
	a.UUID3 = strings.ToUpper(uuid.NewV4().String())
	a.UUID4 = strings.ToUpper(uuid.NewV4().String())
	a.DeviceID = "FFFFFFFF" + strings.ToUpper(strings.ReplaceAll(uuid.NewV4().String(), "-", ""))
	a.Cookies = make(map[string]string, 3)
	a.MspSwitchVer = "1937163293"

	UDID := tools.RandString(30)
	a.Device.IMEI = UDID[:15]
	// 直接全是中国移动
	a.Device.IMSI = "46000" + UDID[20:]
	a.Device.IDFA = strings.ToUpper(uuid.NewV4().String())
	a.Device.IDFV = strings.ToUpper(uuid.NewV4().String())
	a.Device.SysVer = tools.NewSysVersion()
	a.Device.Model = tools.NewModel()
	a.Device.Name = tools.NewOwnerName()
	a.Device.BluetoothMac = "02:00:00:00:00:00"
	a.Device.WifiMac = tools.NewMacAddress()
	a.Device.OtherMac = tools.NewMacAddress()
	a.Device.WifiName = tools.NewWifiName(a.Device.WifiMac)
	a.Device.PhysicalMemory = tools.NewPhysicalMemory(a.Device.Model)
	a.Device.DiskSpace = tools.NewDiskSpace(a.Device.Model)
	a.Device.RealPhysicalMemory = a.Device.PhysicalMemory - int64(tools.RandBetween(1024*1024*200, 1024*1024*500))
	a.Device.RealDiskSpace = a.Device.DiskSpace - int64(tools.RandBetween(1024*1024*500, 1024*1024*1800))
	a.Device.DocNode = int32(tools.RandBetween(50000, 1000000))
	a.Device.PreNode = a.Device.DocNode + int32(tools.RandBetween(1000, 10000))
	a.Device.En0Ipv6 = "fe80::1" + newHexNumber(3) + ":" + newHexNumber(4) + ":" + newHexNumber(4) + ":" + newHexNumber(4)
	r := tools.RandIntn(27)
	s := ""
	if r < 10 {
		s = "0" + strconv.Itoa(r)
	}
	a.Device.En0Ipv4 = "192.168.0.1" + s
	a.Device.En2Ipv6 = "fe80::8" + newHexNumber(2) + ":" + newHexNumber(4) + ":" + newHexNumber(4) + ":" + newHexNumber(4)
	a.Device.En2Ipv4 = "169.254.3." + strconv.Itoa(tools.RandIntn(255))
	a.Device.Awdl0Ipv6 = "fe80::5" + newHexNumber(3) + ":" + newHexNumber(4) + ":" + newHexNumber(4) + ":" + newHexNumber(4)
	a.Device.Utun0Ipv6 = "fe80::4" + newHexNumber(3) + ":" + newHexNumber(4) + ":" + newHexNumber(4) + ":" + newHexNumber(4)
	return a
}

func newHexNumber(count int) string {
	return strconv.FormatInt(int64(tools.RandBetween(1, 0x10)), 16) + tools.RandHexString(count-1)
}

func (a *Account) Save() {
	path := "./alipay/bin/" + a.AccName + ".json"
	tools.SaveJSON2File(path, a)
}

// Load 加载帐号信息
func (a *Account) Load(account string) error {
	path := fmt.Sprintf("./bin/%s.json", account)
	if tools.FileExist(path) {
		tools.LoadJSONFromFile(path, a)
		return nil
	}

	return errors.New("无法加载帐号")
}

// ResetPassword 重置密码
func (a *Account) ResetPassword(password, payPassword string) {
	a.LoginPwd = password
	a.PayPwd = payPassword
	a.Save()
}
