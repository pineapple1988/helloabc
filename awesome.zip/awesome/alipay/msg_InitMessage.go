package alipay

import (
	"awesome/alipay/manager"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func buildInitKV(acc string) []*pb.KeyValuePairs {
	info := manager.GetSyncInfo(acc)
	if info != nil {
		buildV := func(v int64) string {
			if v <= 1 {
				return "0"
			}
			return digits10toMy64(v)
		}
		var list []*pb.KeyValuePairs
		for _, v := range info.APSyncConfigs {
			if v.UpsKey == "1" && v.Cmd == "1" {
				list = append(list, &pb.KeyValuePairs{
					Key:   proto.String("1_" + v.Enum),
					Value: proto.String(buildV(v.SyncKey)),
				})
			}
		}
		for _, v := range info.APBucketConfigs {
			if v.UpsKey == "1" && v.Cmd == "1" {
				list = append(list, &pb.KeyValuePairs{
					Key:   proto.String("2_" + v.Enum),
					Value: proto.String(buildV(v.SyncKey)),
				})
			}
		}
		list = append(list, &pb.KeyValuePairs{
			Key:   proto.String("AppName"),
			Value: proto.String(AppName),
		})
		list = append(list, &pb.KeyValuePairs{
			Key:   proto.String("syncIsNew"),
			Value: proto.String("0"),
		})
		list = append(list, &pb.KeyValuePairs{
			Key:   proto.String("syncVer"),
			Value: proto.String("6"),
		})
		//list = append(list, &pb.KeyValuePairs{
		//	Key:proto.String("dv"),
		//	Value:proto.String("10.1.70.6001"),
		//})
		//list = append(list, &pb.KeyValuePairs{
		//	Key:proto.String("uv"),
		//	Value:proto.String("10.1.70.6001"),
		//})

		return list
	} else {
		log2.Error("syncInfo buildInitKV info not found")
		return nil
	}
}
func (w *WorkGroup) buildInitMessage() *pb.InitMessage {
	return &pb.InitMessage{
		Apdid:          proto.String(w.acc.APDID),
		CacheSessionId: proto.String(w.acc.SessionID),
		Utdid:          proto.String(w.acc.UTDID),
		ExtParas: []*pb.ChannelExtParam{
			{
				ChannelId: proto.Int32(2),
				ExtParams: buildInitKV(w.acc.AccName),
			}},
		SystemVersion:    proto.String(w.acc.Device.SysVer),
		PublishChannel:   proto.String("apple-iphone"),
		ProductId:        proto.String(ProductId),
		ProductVersion:   proto.String(ProductVersion),
		Brand:            proto.String("apple"),
		Model:            proto.String(w.acc.Device.Model),
		ClientType:       proto.String("phone"),
		AppType:          proto.String("client"),
		Imei:             proto.String(w.acc.Device.IMEI),
		Imsi:             proto.String(w.acc.Device.IMSI),
		SettingVersion:   proto.Int64(SettingVersion),
		UserId:           proto.String(w.acc.UserId),
		AppStatus:        proto.Int32(1),
		LinkAction:       proto.Int32(1),
		Language:         proto.String("zh-Hans"),
		NetworkEnum:      pb.MobileNetworkEnum_WIFI.Enum(),
		MobileSystemEnum: pb.MobileSystemEnum_IOS.Enum(),
		ClientSeq:        proto.Int64(tools.TimestampEx()),
		ConnectId:        proto.Int64(0),
		MmtpDid:          proto.String(w.acc.MmtpDid),
		AppName:          proto.String(AppName),
		NetLibVersion:    proto.Int32(2),
		OnlyToLink:       proto.Bool(true),
	}
}

func (w *WorkGroup) sendInitMessage() {
	initMessage := w.buildInitMessage()
	data, err := proto.Marshal(initMessage)
	if err != nil {
		log2.Errorf("[WorkGroup]InitMessage序列化错误: %+v.", err)
	}

	header := &pb.MmtpHead{
		Type:             proto.Uint32(3),
		DataFrameChannel: proto.Uint32(0),
	}

	w.SendMessage(header, nil, data)
}

func (w *WorkGroup) onInitReturnMessage(data []byte) {
	res := &pb.InitReturnMessage{}
	if err := proto.Unmarshal(data, res); err != nil {
		log2.Errorf("[WorkGroup]InitReturnMessage反序列化错误: %+v, 数据: %+v", err, data)
	} else {
		// result_code 字符串对应 pb.Actions 的枚举值
		log2.Infof("[WorkGroup]onInitReturnMessage resp:\r\n%+v", proto.MarshalTextString(res))
		if len(res.GetMmtpDid()) > 0 {
			log2.Info("[WorkGroup]onInitReturnMessage, 已更新mmtpdid")
			w.acc.MmtpDid = res.GetMmtpDid()
		} else {
			log2.Info("[WorkGroup]onInitReturnMessage, 未更新mmtpdid")
		}
	}

}
