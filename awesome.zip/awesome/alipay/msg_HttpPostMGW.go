package alipay

import (
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"github.com/go-http-utils/headers"
)

func protoDictData() []byte {
	data, _ := json.Marshal(&map[string]interface{}{
		"data": map[string]string{
			"namespace":   "com.alipay.mobilecashier",
			"api_name":    "com.alipay.quickpay",
			"api_version": MqpAPIVersion,
		},
	})

	lenS := fmt.Sprintf("%05d", len(data))

	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, []byte(lenS))
	_ = binary.Write(buffer, binary.BigEndian, data)

	return buffer.Bytes()
}

var tripleDesKey string

func tripeDesKeyData() []byte {
	tripleDesKey = tools.RandString(24)
	e, _ := tools.RSAEncrypt([]byte(tripleDesKey), TripeDesRsaPubKey)
	lenS := fmt.Sprintf("%05d", len(e))

	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, []byte(lenS))
	_ = binary.Write(buffer, binary.BigEndian, e)
	return buffer.Bytes()

}

func (w *WorkGroup) ctxData() []byte {
	ua := fmt.Sprintf("%s(i %s;1;%s;;;%s;%s;wifi;%s;1;;%s)(1)(%s)",
		MqpSdkVersion, w.acc.Device.SysVer, w.acc.ClientKey, w.acc.VIMEI, w.acc.VIMSI,
		w.acc.Device.BluetoothMac, w.acc.Device.Name, w.acc.APDIDToken)

	ctx, _ := json.Marshal(&map[string]interface{}{
		"action": map[string]string{
			"type":   "cashier",
			"method": "updateTidInfo",
		},
		"pa":             fmt.Sprintf("%s;%s", BundleId, ProductVersion),
		"external_info":  `bizcontext={"requestScene":"INIT"}`,
		"ua":             ua,
		"bp":             getBP(),
		"tid":            w.acc.TID,
		"lang":           "zh-Hans",
		"new_client_key": tools.RandString(10),
		"trdfrom":        "1",
		"has_alipay":     true,
		"utdid":          w.acc.APDID,
	})

	// 先压缩
	ctxZ, _ := tools.GZipCompress(ctx)
	// 再加密
	ctxE, _ := tools.TripleDESECBEncrypt(ctxZ, []byte(tripleDesKey))

	lenS := fmt.Sprintf("%05d", len(ctxE))
	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, []byte(lenS))
	_ = binary.Write(buffer, binary.BigEndian, ctxE)

	return buffer.Bytes()
}

func (w *WorkGroup) body() []byte {
	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, protoDictData())
	_ = binary.Write(buffer, binary.BigEndian, tripeDesKeyData())
	_ = binary.Write(buffer, binary.BigEndian, w.ctxData())

	return buffer.Bytes()
}
func (w *WorkGroup) postMGW() {
	body := w.body()
	//fmt.Println(hex.Dump(body))
	if body == nil {
		return
	}

	req, err := http.NewRequest("POST", UrlMGW, bytes.NewReader(body))
	if err != nil {
		log2.Errorf("[AliPay]postMGW 生成http请求对象失败, 帐号: %+v, 错误: %+v.", w.acc.AccName, err)
		return
	}

	req.Header.Set(headers.ContentType, "application/octet-stream")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set("Msp-Gzip", "true")
	//req.Header.Set("Keep-Alive", "timeout=180, max=100")
	req.Header.Set("Operation-Type", "alipay.msp.cashier.dispatch.bytes")
	req.Header.Set(headers.UserAgent, w.httpUserAgent())

	resp, err := w.Do(req)
	if err != nil {
		log2.Errorf("[AliPay]postMGW http 请求失败, 帐号: %+v, 错误: %+v.", w.acc.AccName, err)
		return
	}
	defer resp.Body.Close()

	for _, v := range resp.Cookies() {
		w.acc.Cookies[v.Name] = v.Value
	}

	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log2.Errorf("[AliPay]postMGW resp 读取失败, 帐号: %+v, 错误: %+v.", w.acc.AccName, err)
		return
	}
	// 解密数据
	//fmt.Println(hex.Dump(data))

	plainLen, _ := strconv.ParseInt(string(data[:5]), 10, 32)
	data = data[5:]
	fmt.Println("明文数据:\r\n " + string(data[:plainLen]))
	data = data[plainLen:]
	encryptLen, _ := strconv.ParseInt(string(data[:5]), 10, 32)
	if encryptLen != 0 {
		data = data[5:]
		//fmt.Println(hex.Dump(data))
		ctx, _ := tools.TripleDESECBDecrypt(data[:encryptLen], []byte(tripleDesKey))
		// 解压缩
		uncompress, _ := tools.GZipUncompress(ctx)
		fmt.Println("密文数据:\r\n " + string(uncompress))
	}
}
