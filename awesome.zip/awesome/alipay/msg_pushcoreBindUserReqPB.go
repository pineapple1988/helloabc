package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendPushcoreBindUserReqPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.PushcorePushRpcRespPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("PushcorePushRpcRespPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("PushcorePushRpcRespPB, resp: \r\n%+v.", proto.MarshalTextString(respObj))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcIosBind,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.PushcoreBindUserReqPB{
		MspTid:         proto.String(w.acc.TID),
		UserId:         proto.String(w.acc.UserId),
		PublishVersion: proto.String("1.1.0"),
		AppId:          proto.String("alipayclient"),
		OsType:         proto.String("IOS"),
		ClientId:       proto.String(w.acc.UTDID),
		AppName:        proto.String(BundleId),
		DeviceId:       proto.String(""),
		AppVersion:     proto.String(ProductVersion),
		IsPush:         proto.String("0"),
	})
}
