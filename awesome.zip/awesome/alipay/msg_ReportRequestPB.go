package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"strconv"
	"strings"
)

func (w *WorkGroup) sendReportRequestPB(maidian int32) {
	if tools.TimestampEx()-w.acc.LastReportTime < w.acc.ReportInterval {
		return
	}
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.ReportResultPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("ReportResultPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("ReportResultPB, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				if w.acc.ReportInterval, err = strconv.ParseInt(respObj.GetResultData().GetTimeInterval(), 10, 64); err != nil {
					w.acc.ReportInterval = 86400000
				}
				w.acc.APDID = respObj.GetResultData().GetApdid()
				w.acc.APDIDToken = respObj.GetResultData().GetApdidToken()
				w.acc.DynamicKey = respObj.GetResultData().GetDynamicKey()
				w.acc.Cookies["devKeySet"] = fmt.Sprintf("{\"apdidToken\":\"%s\"}", w.acc.APDIDToken)
			}
		}
	}

	// 安装时间
	var appInstallTime string
	if maidian == 1 {
		rndTime := float32(tools.Timestamp()) - float32(tools.RandBetween(60*60*24*5, 60*60*24*15)) + tools.RandFloat(0.8)
		appInstallTime = fmt.Sprintf("{\"%s_%s\":\"%f\"}", BundleId, ProductVersion, rndTime)
	} else {
		appInstallTime = "s"
	}

	currentTime := float64(float32(tools.Timestamp()) + tools.RandFloat(0.99))
	openTime := float64(float32(tools.RandBetween(10000, 86400*30)) + tools.RandFloat(0.99))
	bootTime := currentTime - openTime + float64(tools.RandBetween(0, 20))
	extDeviceData, _ := json.Marshal(&map[string]string{
		"ID34": tools.Uname(w.acc.Device.SysVer, w.acc.Device.Model),
		"ID30": "",
		// todo EdgeRiskResult
		"IE17": "",
		"ID37": "",
		"ID33": "",
		"ID23": "0",
		"IE16": "ios",
		"ID36": w.getID36(),
		"ID32": w.acc.Device.BluetoothMac,
		"IE19": BundleId,
		"IE15": w.acc.Device.Name,
		// -[ASSStaticInfoCollector getPasscodeStatus] 锁屏密码
		"ID35": "1",
		"ID31": fmt.Sprintf("{\"wua\":\"%s\",\"version\":\"3.0\"}", w.acc.Miniwua),
		"IE18": "",
		// 签名信息中的数据
		"IE20": "BPM6A296T5",
	})

	headers := map[string]string{
		"Operation-Type": RpcDeviceReport,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.ReportRequestPB{
		BizData: &pb.BizData{
			Apdid:      proto.String(w.acc.APDID),
			ApdidToken: proto.String(w.acc.APDIDToken),
			LastTime:   proto.String(strconv.FormatInt(w.acc.LastReportTime, 10)),
			DynamicKey: proto.String(w.acc.DynamicKey),
			UmidToken:  proto.String(w.acc.UMIDToken),
		},
		DeviceData: &pb.DeviceData{
			// -[ASSStaticInfoCollector checkJB]
			IE2: proto.Int32(0),
			// 模拟器检测
			IE3: proto.Bool(false),
			IE4: proto.String(w.acc.Device.Model),
			IE5: proto.String(w.acc.Device.SysVer),
			IE6: proto.String(strings.ReplaceAll(w.acc.Device.Name, "的 ", "de-")),
			IE7: proto.String(w.acc.Device.Model),
			IE8: proto.String(tools.CarrierByIMSI(w.acc.Device.IMSI)),
			// getPublicIPInfo
			IE9: proto.String(""),
			// 开机时间
			IE11: proto.Float64(bootTime),
			IE12: proto.Float64(openTime),
			IE13: proto.Float64(currentTime),
			// -[ASSStaticInfoCollector updateMaiDianInfo:]
			IE14: proto.Int32(maidian),
			IL3:  proto.String(w.acc.Device.WifiMac),
			ID1:  proto.String(w.acc.VIMEI),
			ID2:  proto.String(w.acc.VIMSI),
			ID3:  proto.String(w.acc.Device.IDFA),
			ID5:  proto.String(""),
			ID8:  proto.Int32(int32(tools.ScreenWidthPt(w.acc.Device.Model))),
			ID9:  proto.Int32(int32(tools.ScreenHeightPt(w.acc.Device.Model))),
			ID10: proto.Int32(tools.CPUCore(w.acc.Device.Model)),
			ID11: proto.Int32(tools.CPUFreq()),
			ID12: proto.Int64(w.acc.Device.RealPhysicalMemory),
			ID13: proto.Int64(w.acc.Device.RealDiskSpace),
			ID15: proto.String(""),
			ID16: proto.String(""),
			ID17: proto.String(w.acc.Device.IDFV),
			ID18: proto.String("Asia/Shanghai (GMT+8) offset 28800"),
			ID19: proto.String("zh-Hans-CN"),
			// evaluatedPolicyDomainState 每个手机都应该不一样 返回的指纹数据加base64
			// 这个地方暂时不用
			ID22: proto.String(""),
			ID23: proto.String("0"),
			// DiskFreeSpace
			ID24: proto.Int64(w.acc.Device.DiskSpace - int64(tools.RandBetween(8*1024*1024*1024, 12*1024*1024*1024))),
			// BatteryLevel
			ID25: proto.Float32(float32(tools.RandBetween(25, 99)) / 100),
			// BatteryStatus
			// typedef NS_ENUM(NSInteger, UIDeviceBatteryState) {
			//    UIDeviceBatteryStateUnknown,
			//    UIDeviceBatteryStateUnplugged,   // on battery, discharging
			//    UIDeviceBatteryStateCharging,    // plugged in, less than 100%
			//    UIDeviceBatteryStateFull,        // plugged in, at 100%
			//} API_UNAVAILABLE(tvos);              // available in iPhone 3.0
			ID26: proto.Int32(1),
			IA1:  proto.String(BundleId),
			IA2:  proto.String(ProductVersion),
			IA4:  proto.String("P1.3.8.20190809"),
			IA5:  proto.String(appInstallTime),
			IA6:  proto.String(""),
			IC1:  proto.String(w.acc.TID),
			IC4:  proto.String(w.acc.RandomAPDID),
			IC5:  proto.String(w.acc.UserId),
			// appName
			IC9: proto.String(""),
			// appKeyClient
			IC10: proto.String(""),
		},
		ExtDeviceData: proto.String(string(extDeviceData)),
	})
	w.acc.LastReportTime = tools.TimestampEx()
}
