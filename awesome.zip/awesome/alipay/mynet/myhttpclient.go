package mynet

import (
	"crypto/tls"
	"github.com/go-http-utils/headers"
	"net/http"
	"time"
)

type MyHttpClient struct {
	http.Client
	cookies *map[string]string
}

func NewMyHttpClient(jar *map[string]string) *MyHttpClient {
	c := &MyHttpClient{
		cookies: jar,
	}
	c.Client = http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
	}
	return c
}

func (c *MyHttpClient) Do(req *http.Request) (*http.Response, error) {
	// 先添加cookies
	req.Header.Add(headers.Cookie, RawCookies(*c.cookies))

	resp, err := c.Client.Do(req)

	// 保存cookie
	if err == nil {
		for _, cookie := range resp.Cookies() {
			(*c.cookies)[cookie.Name] = cookie.Value
		}
	}

	return resp, err
}
