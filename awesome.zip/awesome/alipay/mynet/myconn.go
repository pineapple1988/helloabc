package mynet

import (
	"awesome/tools/log2"
	"crypto/tls"
	"errors"
	"io"
	"net"
	"sync/atomic"
)

// NetHandler 网络事件接口
type NetHandler interface {
	// OnConnected 连接成功或失败
	OnConnected(err error)

	// OnClose 关闭连接
	OnClose()

	// OnReceived 接收到网络数据
	OnReceived(data []byte)

	// OnError 连接出现错误
	OnError(err error)
}

// 链接状态
const (
	stateNone       = 0
	stateConnecting = 1
	stateConnected  = 2
)

type MyConn struct {
	net.Conn
	handler  NetHandler  // 处理接收数据
	sendChan chan []byte // 处理发送数据
	stopChan chan bool   // 处理关闭
	state    int32       // 连接状态
}

func NewMyConn(handler NetHandler) *MyConn {
	return &MyConn{
		handler: handler,
		state:   stateNone,
	}
}

func (mc *MyConn) setConnectState(state int) {
	atomic.StoreInt32(&mc.state, int32(state))
}

func (mc *MyConn) getConnectState() int {
	return int(mc.state)
}

// IsConnected 返回是否已经成功连接服务器
func (mc *MyConn) IsConnected() bool {
	return mc.getConnectState() == stateConnected
}

// Send 发送数据
func (mc *MyConn) Send(data []byte) {
	if !mc.IsConnected() {
		log2.Info("onSend but IsConnected = false")
		return
	}

	if data != nil && len(data) > 0 {
		//log2.Infof("onSend >>>>>>>> \r\n%s", hex.Dump(data))
		mc.sendChan <- data
	}
}

// 发送协程
func (mc *MyConn) sendConn(sendChan <-chan []byte, stopChan chan<- bool) {
	defer log2.Info("[myConn|sendConn]结束数据发送协程.")
	for {
		data := <-sendChan
		for len(data) > 0 {
			n, err := mc.Write(data)
			if err != nil {
				log2.Errorf("[myConn|sendConn]写入数据错误: %+v.", err)
				mc.handler.OnError(err)
				// 写入出错关闭连接
				stopChan <- true
				return
			}
			data = data[n:]
		}
		// 收到空数据,判断是否是退出
		if mc.IsConnected() {
			continue
		} else {
			return
		}
	}
}

// 接收协程
func (mc *MyConn) recvConn(recvChan chan<- []byte, stopChan chan<- bool) {
	buffer := make([]byte, 4096)
	for {
		n, err := mc.Read(buffer)
		if err != nil {
			if err == io.EOF {
				log2.Infof("[myConn|recvConn]网络连接已关闭.")
			} else if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
				log2.Infof("[myConn|recvConn]读取数据超时.")
				if mc.IsConnected() {
					continue
				}
			} else {
				log2.Errorf("[myConn|recvConn]读取数据错误: %+v.", err)
			}

			if mc.IsConnected() {
				mc.handler.OnError(err)
			}

			break
		}
		// 拷贝数据发送出去,不拷贝发现使用chan发送的数据是同一个地址
		recvB := make([]byte, n)
		copy(recvB, buffer[:n])
		recvChan <- recvB
	}
	log2.Info("[myConn|recvConn]结束数据接收协程.")
	close(recvChan)
	stopChan <- true
}

// 处理协程
func (mc *MyConn) handleConn(addr string, useTls bool) {
	if mc.getConnectState() != stateNone {
		mc.handler.OnError(errors.New("connect state != stateNone"))
	}

	mc.setConnectState(stateConnecting)

	var err error
	mc.Conn, err = net.Dial("tcp", addr)
	if err != nil {
		mc.handler.OnConnected(err)
		mc.setConnectState(stateNone)
		return
	}
	if useTls {
		mc.Conn = tls.Client(mc.Conn, &tls.Config{
			MinVersion:         tls.VersionTLS12,
			InsecureSkipVerify: true,
		})
	}

	recvChan := make(chan []byte)
	mc.sendChan = make(chan []byte)
	mc.stopChan = make(chan bool)

	go mc.recvConn(recvChan, mc.stopChan)
	go mc.sendConn(mc.sendChan, mc.stopChan)

	mc.setConnectState(stateConnected)
	mc.handler.OnConnected(nil)
	defer mc.Close()

	for {
		select {
		case recvData := <-recvChan:
			mc.handler.OnReceived(recvData)
		case stop := <-mc.stopChan:
			if stop {
				mc.setConnectState(stateNone)
				mc.handler.OnClose()
				// 发送空数据，让发送协程退出
				mc.sendChan <- []byte{}
				close(mc.sendChan)
				// 连接关闭时，读取协程会报错，自动退出
				return
			}
		}
	}
}

// Start 开始连接
func (mc *MyConn) Start(addr string, useTls bool) {
	go mc.handleConn(addr, useTls)
}

// Stop 停止连接
func (mc *MyConn) Stop() {
	mc.stopChan <- true
}
