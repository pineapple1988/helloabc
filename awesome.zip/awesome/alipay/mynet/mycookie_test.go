package mynet

import (
	"fmt"
	"net/http/cookiejar"
	"net/url"
	"testing"
)

func TestReadRawCookies(t *testing.T) {
	cookies1 := ReadRawCookies(`zone=RZ11A; Path=/; Domain=.alipay.com; Version=1`)
	cookies2 := ReadRawCookies(`zone=RZ11B; Path=/; Domain=.alipay.com; Version=1`)
	fmt.Printf("%+v\r\n", cookies1[0].String())
	jar, _ := cookiejar.New(nil)
	u, _ := url.Parse("https://mygw.alipay.com")
	jar.SetCookies(u, cookies1)
	jar.SetCookies(u, cookies2)
	u, _ = url.Parse("https://alipay.com")
	cookies2 = jar.Cookies(u)
	cookies := make(map[string]string, 2)
	cookies["hello"] = "world"
	cookies["12345"] = "7890"

	fmt.Printf("%+v\r\n", cookies2)
	fmt.Println(RawCookies(cookies))
}
