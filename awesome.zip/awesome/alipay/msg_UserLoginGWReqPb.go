package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) getLocalDevicesFeature() string {
	infos, _ := json.Marshal(&map[string]string{
		"n2": strconv.Itoa(int(w.acc.Device.PreNode)),
		"i2": w.acc.Device.IDFV,
		"n1": strconv.Itoa(int(w.acc.Device.DocNode)),
		"i1": w.acc.Device.Model,
		"v":  "1",
	})
	enc := WbEncrypt(infos)
	enc = append([]byte("1"), enc...)
	// base64
	return base64.StdEncoding.EncodeToString(enc)
}

func (w *WorkGroup) sendUserLogin() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.UserLoginGWResultPb{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("UserLoginGWResultPb, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("UserLoginGWResultPb, resp: \r\n%+v", proto.MarshalTextString(respObj))
			switch respObj.GetResultStatus() {
			case 1000: // 登录成功
				w.acc.IsLogin = true
				// 存储一下数据
				w.acc.UserId = respObj.GetUserId()
				w.acc.SessionID = respObj.GetSessionId()
				w.sendFetchLatestReq()

				w.afterLogin()

			case 1014: // 请输入账号密码重新登录
				// 账号是未登陆状态，需要重新登陆
				w.acc.IsLogin = false
			default:
				w.acc.IsLogin = false
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcUserLogin,
		"retryable2":     "1",
		"uid":            w.acc.UserId[len(w.acc.UserId)-3 : len(w.acc.UserId)-1],
	}
	w.SendHttpMessage(onResp, headers, &pb.UserLoginGWReqPb{
		LoginId:         proto.String(w.acc.AccName),
		LoginType:       pb.LoginTypeWithout_alipay_.Enum(),
		LoginWthPwd:     pb.LoginWithout_without_.Enum(),
		LoginPassword:   proto.String(""),
		LoginCheckCode:  proto.String(""),
		TbCheckCodeId:   proto.String(""),
		TbCheckCode:     proto.String(""),
		ProductId:       proto.String(ProductId),
		ProductVersion:  proto.String(ProductVersion),
		OsVersion:       proto.String(w.acc.Device.SysVer),
		UserAgent:       proto.String(w.acc.Device.Model),
		Channels:        proto.String("apple-iphone"),
		ClientDigest:    proto.String(""),
		DeviceToken:     proto.String(""),
		ScreenWidth:     proto.Int32(int32(tools.ScreenWidthPx(w.acc.Device.Model))),
		ScreenHigh:      proto.Int32(int32(tools.ScreenHeightPx(w.acc.Device.Model))),
		ClientId:        proto.String(fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI)),
		WalletTid:       proto.String(w.acc.TID),
		WalletClientKey: proto.String(w.acc.ClientKey),
		MspTid:          proto.String(w.acc.TID),
		MspImsi:         proto.String(w.acc.Device.IMSI),
		MspImei:         proto.String(w.acc.Device.IMEI),
		MspClientKey:    proto.String(w.acc.ClientKey),
		SourceId:        proto.String(""),
		Mac:             proto.String(w.acc.Device.BluetoothMac),
		CellId:          proto.String(""),
		Location:        proto.String(""),
		Vimsi:           proto.String(w.acc.VIMSI),
		Vimei:           proto.String(w.acc.VIMEI),
		ExternParams: []*pb.AuthLoginTokenExternParamsPB{
			{
				Key:   proto.String("umidToken"),
				Value: proto.String(w.acc.UMIDToken),
			}, {
				Key:   proto.String("netType"),
				Value: proto.String("WIFI"),
			}, {
				Key:   proto.String("loginSource"),
				Value: proto.String("appLaunch"),
			}, {
				Key:   proto.String("appState"),
				Value: proto.String("foreground"),
			}, {
				Key:   proto.String("gestureType"),
				Value: proto.String("0"),
			}, {
				Key:   proto.String("devKeySet"),
				Value: proto.String(fmt.Sprintf(`{"apdidToken":"%s"}`, w.acc.APDIDToken)),
			}, {
				Key:   proto.String("apdid"),
				Value: proto.String(w.acc.APDID),
			}, {
				Key:   proto.String("idfa"),
				Value: proto.String(w.acc.Device.IDFA),
			}, {
				Key:   proto.String("terminalName"),
				Value: proto.String(w.acc.Device.Name),
			}, {
				Key:   proto.String("ldf"),
				Value: proto.String(w.getLocalDevicesFeature()),
			},
		},
	})
}
