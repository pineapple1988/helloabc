package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"encoding/json"
	"github.com/golang/protobuf/proto"
)

type rsaKeyRes struct {
	PubKey string `json:"pubKey"`
}

func (w *WorkGroup) sendAUSRsaKeyReqPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj1 := &rsaKeyRes{}
		respObj2 := &pb.AUSRsaKeyResPB{}
		// 这个是用来加密登陆密码的key
		if err := json.Unmarshal(resp, respObj1); err == nil {
			w.acc.loginRsaPubKey = respObj1.PubKey
		} else {
			if err := proto.Unmarshal(resp, respObj2); err == nil {
				w.acc.loginRsaPubKey = respObj2.GetPubKey()
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcGetRsaKey2,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.AUSRsaKeyReqPB{
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		SdkVersion:     proto.String(SdkVersion),
	})
}
