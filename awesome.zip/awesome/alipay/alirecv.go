package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/alipay/mynet"
	"awesome/tools/log2"
	"encoding/hex"
	"github.com/golang/protobuf/proto"
	"strconv"
)

func (w *WorkGroup) processPacket(mmtpHead *pb.MmtpHead, http2Head []hpack.HeaderField, data []byte) {
	// 更新cookies
	for _, f := range http2Head {
		if f.Name == "Set-Cookie" && len(f.Value) > 0 {
			cookies := mynet.ReadRawCookies(f.Value)
			for _, cookie := range cookies {
				w.acc.Cookies[cookie.Name] = cookie.Value
			}
		}
	}

	switch mmtpHead.GetType() {
	case 1:
		log2.Info("[WorkGroup]A data-frame is received")
		w.onDataFrameChannel(mmtpHead, http2Head, data)
	case 2:
		log2.Info("[WorkGroup]A heartbeat-frame is received")
		w.Heart.OnHeart(data)
	case 3:
		log2.Info("[WorkGroup]An init-frame is received")
		w.onInitReturnMessage(data)
	case 4:
		log2.Info("[WorkGroup]A status-frame is received")
		w.onSTMessage(data)
	case 5:
		log2.Info("[WorkGroup]A setting-frame is received")
		w.onSettingMessage(data)
	case 6:
		log2.Info("[WorkGroup]A reconnect-frame is received")
	case 7:
		log2.Info("[WorkGroup]An ack-frame is received")
	case 8:
		log2.Info("[WorkGroup]A secret-frame is received")
	case 9:
		log2.Info("[WorkGroup]A command-frame is received")
		w.onCmdListMessage(data)
	case 10:
		log2.Info("[WorkGroup]A sleep-frame is received")
	case 11:
		log2.Info("[WorkGroup]A missile-frame is received")
	case 12:
		log2.Info("[WorkGroup]A compensate-frame is received")
	case 13:
		err := &pb.MmtpAlert{}
		_ = proto.Unmarshal(data, err)
		log2.Infof("[WorkGroup]An alert-frame is received \r\n%+v", proto.MarshalTextString(err))
	case 14:
		log2.Info("[WorkGroup]A dict-frame is received")
	case 15:
		log2.Info("[WorkGroup]A report-frame is received")
	case 100:
		log2.Info("[WorkGroup]A huawei-frame is received")
	default:
		log2.Errorf("[WorkGroup]An unknown-frame is received: %+v", mmtpHead.GetType())
	}
}
func (w *WorkGroup) onDataFrameChannel(mmtpHead *pb.MmtpHead, http2Heads []hpack.HeaderField, data []byte) {
	switch mmtpHead.GetDataFrameChannel() {
	case 1:
		if mmtpHead.GetDirect() == 1 {
			rpcId := func() string {
				for _, head := range http2Heads {
					if head.Name == "RpcId" {
						return head.Value
					}
				}
				return ""
			}()

			if rpcId == "" {
				log2.Error("[WorkGroup]onDataFrameChannel无法从找到rpcId.")
				return
			}

			callback, ok := w.cbInfo[rpcId]
			if !ok {
				log2.Errorf("[WorkGroup]onDataFrameChannel无法找到rpcId对应的回调信息, rpcId: %+v.", rpcId)
				return
			}
			callback(data, http2Heads)
			delete(w.cbInfo, rpcId)
		}
	case 2:
		log2.Info("[WorkGroup]onDataFrameChannel syncOpCode is coming")
		w.onSyncOpCode(http2Heads, data)
	default:
		log2.Infof("[WorkGroup]onDataFrameChannel unknown channel %d", mmtpHead.GetDataFrameChannel())
	}
}

func (w *WorkGroup) onSettingMessage(data []byte) {
	res := &pb.SettingMessage{}
	if err := proto.Unmarshal(data, res); err != nil {
		log2.Errorf("[WorkGroup]onSettingMessage反序列化错误: %+v, 数据: \r\n%+v", err, hex.Dump(data))
	} else {
		log2.Infof("onSettingMessage \r\n %+v", proto.MarshalTextString(res))
	}
}

func (w *WorkGroup) onCmdListMessage(data []byte) {
	res := &pb.CmdListMessage{}
	if err := proto.Unmarshal(data, res); err != nil {
		log2.Errorf("[WorkGroup]CmdListMessage反序列化错误: %+v, 数据: \r\n%+v", err, hex.Dump(data))
	} else {
		for _, cmd := range res.GetCmdList() {
			switch cmd.GetCmdType() {
			case pb.CmdType_IpListUpdate:
				ipList := &pb.IpListCmdData{}
				if err := proto.Unmarshal(cmd.GetCmdData(), ipList); err != nil {
					log2.Errorf("[WorkGroup]IpListCmdData反序列化错误: %+v, 数据: \r\n%+v", err, hex.Dump(cmd.GetCmdData()))
				} else {
					log2.Infof("CmdType_IpListUpdate \r\n %+v", proto.MarshalTextString(ipList))
					dns := ipList.GetDns()
					if dns != nil {
						for _, d := range dns {
							if d.GetDomain() == AlipayHost {
								if len(d.Ips) > 0 {
									w.acc.IP = d.Ips[0].GetIp()
									w.acc.Port = strconv.Itoa(int(d.Ips[0].GetPort()))
									break
								}
							}
						}
					}
				}
			case pb.CmdType_ReConnect:
				log2.Infof("CmdType_ReConnect \r\n %+v", hex.Dump(cmd.GetCmdData()))
			case pb.CmdType_ConnectionDowngrade:
				cmdMap := &pb.CmdMap{}
				if err := proto.Unmarshal(data, cmdMap); err != nil {
					log2.Errorf("[WorkGroup]CmdMap反序列化错误: %+v, 数据: \r\n%+v", err, hex.Dump(cmd.GetCmdData()))
				} else {
					log2.Infof("CmdType_ConnectionDowngrade \r\n %+v", proto.MarshalTextString(cmdMap))
				}
			case pb.CmdType_Crash:
				log2.Infof("CmdType_Crash \r\n %+v ", hex.Dump(cmd.GetCmdData()))
			default:
				log2.Infof("Unknown CmdType")
			}
		}
	}
}
