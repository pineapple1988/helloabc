package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"encoding/json"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) SendMessage(mmtpHead *pb.MmtpHead, headers []byte, msg []byte) {
	tmp := bytes.NewBuffer([]byte{})
	if headers != nil && len(headers) > 0 {
		tmp.Write(headers)
		mmtpHead.DataFrameHeadLength = proto.Uint32(uint32(tmp.Len()))
	}
	tmp.Write(msg)

	var err error
	var headersB []byte
	msg = tmp.Bytes()

	// 如果长度大于0x200就压缩并设置头部
	if len(msg) > 0x200 {
		msg, err = tools.GZipCompress(msg)
		if err != nil {
			log2.Errorf("[WorkGroup]压缩包体数据错误: %+v.", err)
			return
		}
		mmtpHead.ZipType = proto.Uint32(1)
	}

	headersB, err = proto.Marshal(mmtpHead)
	if err != nil {
		log2.Errorf("[WorkGroup]MmtpHead序列化错误: %+v, 数据: %+v.", err, mmtpHead)
		return
	}
	headLen := int32(len(headersB))
	bodyLen := int32(len(msg))

	tmp = bytes.NewBuffer([]byte{})
	tmp.WriteByte(0x90)
	tmp.Write(serializeLen(headLen))
	tmp.Write(serializeLen(bodyLen))
	tmp.Write(headersB)
	tmp.Write(msg)

	w.Send(tmp.Bytes())
}

// MsgCallback 消息回调函数
type HttpCallback func(resp []byte, headers []hpack.HeaderField)

func (w *WorkGroup) SendHttpMessage(onResp HttpCallback, headers map[string]string, body interface{}) {
	// 根据类型来进行序列化
	var msg []byte
	var err error
	switch body.(type) {
	case proto.Message:
		// pb类型
		msg, err = proto.Marshal(body.(proto.Message))
		if err != nil {
			log2.Errorf("[WorkGroup] pb 序列化错误: %+v, %+v", msg, err)
			return
		}
		headers["Content-Type"] = "application/protobuf"
	case string:
		msg = []byte(body.(string))
		headers["Content-Type"] = "application/json"
	default:
		// 默认使用json
		msg, err = json.Marshal(body)
		if err != nil {
			log2.Errorf("[WorkGroup] json 序列化错误: %+v, %+v", msg, err)
			return
		}
		// 添加[]
		msg = append([]byte{0x5B}, msg...)
		msg = append(msg, 0x5D)

		headers["Content-Type"] = "application/json"
	}

	headers["Ts"] = digits10toMy64(tools.TimestampEx())
	headers["Sign"] = w.Sign(headers["Operation-Type"], msg, headers["Ts"])
	headers["RpcId"] = w.RpcId()
	headers2 := w.Http2Headers(headers)

	w.cbInfo[headers["RpcId"]] = onResp
	w.SendMessage(&pb.MmtpHead{
		DataFrameChannel: proto.Uint32(1),
		MmtpUpSequence:   proto.Uint64(uint64(tools.TimestampEx())),
	}, headers2, msg)
}
