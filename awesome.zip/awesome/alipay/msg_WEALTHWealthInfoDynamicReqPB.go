package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"

	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendV99() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.WEALTHWealthHomeDynamicV99ResultPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendV99, proto.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeBalance, BalanceCodeError, "解释返回数据错误", nil)
		} else {
			//log2.Infof("sendV99, resp: \r\n%+v", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				for _, module := range respObj.GetModuleInfos() {
					if module.GetWidgetId() == "WEALTH_HOME_ACC_BALANCE" {
						// 更新余额 <1.88 元>
						w.acc.Balance = module.GetMainInfo()
						log2.Infof("sendV99, 获取到余额: %+v", module.GetMainInfo())
						w.notifyEvent(EventTypeBalance, BalanceCodeSuccess, module.GetMainInfo(), nil)
					}
				}
			} else {
				w.notifyEvent(EventTypeBalance, BalanceCodeError, "查询余额失败", nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcQueryWealthHomeInfoV996,
		"retryable2":     "1",
	}
	w.SendHttpMessage(onResp, headers, &pb.WEALTHWealthInfoDynamicReqPB{
		LastMd5: proto.String(""),
	})
}

// QueryBalance 查询余额
func (w *WorkGroup) QueryBalance() {
	w.sendV99()
}
