package alipay

// 事件
const (
	EventTypeLogin    = iota // 登录事件
	EventTypeSMS             // sms事件
	EventTypeBalance         // 余额事件
	EventTypeBill            // 帐单事件
	EventTypeQRCode          // 生成二维码事件
	EventTypeQRScan          // 扫描二维码事件
	EventTypeTransfer        // 转帐事件
	EventTypeNotify          // 通知事件
)

// 登录处理代码
const (
	LoginCodeSuccess      = iota // 登录成功
	LoginCodeNetError            // 网络错误
	LoginCodeNeedCode            // 需要验证码
	LoginCodeNeedFaceScan        // 需要刷脸
	LoginCodeOtherError          // 其它登录错误
)

// 短信处理代码
const (
	SMSCodeSuccess = iota // 短信验证成功
	SMSCodeError          // 短信验证码错误
)

// 查询余额处理代码
const (
	BalanceCodeSuccess = iota // 查询余额成功
	BalanceCodeError          // 查询余额错误
)

// 查询帐单处理代码
const (
	BillCodeSuccess = iota // 查询帐单成功
	BillCodeError          // 查询帐单错误
)

// 转帐处理代码
const (
	TransferCodeSuccess = iota // 转帐成功
	TransferCodeError          // 转帐错误
)

// 生成二维码处理代码
const (
	GetQRCodeSuccess = iota // 生成二维码成功
	GetQRCodeError          // 生成二维码错误
)

// 通知事件代码
const (
	NotifyLoginOtherDevice = iota // 其它设备登录
	NotifyMsgBill                 // 到帐
)
