package alipay

import (
	"awesome/alipay/manager"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"github.com/golang/protobuf/proto"
	"github.com/robfig/cron/v3"
)

type AliHeart struct {
	lastHeartbeatTime int64
	heartValue        int16
	id                cron.EntryID
}

func (ah *AliHeart) OnHeart(data []byte) {
	log2.Infof("[WorkGroup] OnHeart \r\n%+v", hex.Dump(data))
}

func (ah *AliHeart) StartHeart(ac *WorkGroup) {
	var err error

	ah.heartValue = 1
	// 20 秒一次心跳
	ac.Heart.id, err = manager.AddJob("*/20 * * * * ?", ac)
	if err != nil {
		log2.Errorf("[startHeart] AddJob err = %+v.", err)
	}
}

func (ah *AliHeart) StopHeart() {
	manager.Remove(ah.id)
	ah.id = 0
}

func (ah *AliHeart) SendHeart(ac *WorkGroup) {
	buffer := bytes.NewBuffer([]byte{})
	_ = binary.Write(buffer, binary.BigEndian, ah.heartValue)

	mmtpHead := pb.MmtpHead{
		Type:             proto.Uint32(2),
		DataFrameChannel: proto.Uint32(0),
	}

	ac.SendMessage(&mmtpHead, nil, buffer.Bytes())
	ah.heartValue += 2
	ah.lastHeartbeatTime = tools.TimestampEx()
}
