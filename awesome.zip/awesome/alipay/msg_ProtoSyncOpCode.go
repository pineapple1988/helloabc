package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/manager"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"bytes"
	"encoding/binary"
	"strconv"
	"strings"

	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendProtoSyncOpCode2002(http2Heads []hpack.HeaderField, code2001 *pb.ProtoSyncOpCode2001) {
	var bizSyncInfoList []*pb.ProtoBizSyncInfo
	for _, item := range code2001.GetBizSyncData() {
		bizSyncInfoList = append(bizSyncInfoList, &pb.ProtoBizSyncInfo{
			BizType:        proto.Int32(item.GetBizType()),
			SyncKey:        proto.Int64(item.GetSyncKey()),
			Pf:             proto.Int32(item.GetPf()),
			DispatchStatus: proto.Int32(1001),
		})
	}
	var bucketSyncInfo *pb.ProtoBucketSyncInfo
	if code2001.GetBucketSyncInfo() != nil {
		bucketSyncInfo = &pb.ProtoBucketSyncInfo{
			BucketType: proto.Int32(code2001.GetBucketSyncInfo().GetBucketType()),
			SyncKey:    proto.Int64(code2001.GetBucketSyncInfo().GetSyncKey()),
		}
	}
	code2002 := &pb.ProtoSyncOpCode2002{
		BizSyncInfo:     bizSyncInfoList,
		BucketSyncInfo:  bucketSyncInfo,
		HasMoreData:     proto.Bool(code2001.GetHasMoreData()),
		PrincipalIdType: proto.Int32(code2001.GetPrincipalIdType()),
		PrincipalId:     proto.String(code2001.GetPrincipalId()),
		AppName:         proto.String(AppName),
	}
	pd, err := proto.Marshal(code2002)
	if err != nil {
		log2.Errorf("[[WorkGroup|sendProtoSyncOpCode2002]序列化错误: %+v, 数据: %+v.", err, proto.MarshalTextString(code2002))
		return
	}

	mmtp := &pb.MmtpHead{
		DataFrameChannel: proto.Uint32(2),
	}
	var hpData []byte
	if http2Heads != nil {
		w.hpackLock.Lock()
		defer w.hpackLock.Unlock()
		w.encodeBuffer.Reset()
		for _, k := range http2Heads {
			_ = w.hpackEncoder.WriteField(k)
		}

		hpData = w.encodeBuffer.Bytes()
	}
	// -[APSyncPBFactory build2002DataWithBucketSyncInfo:bizSyncInfo:message2001:]
	// 06 2002
	data := []byte{0x06, 0x07, 0xD2}
	data = append(data, pd...)
	w.SendMessage(mmtp, hpData, data)
}

func (w *WorkGroup) getProtoSyncOpCode3001() []byte {
	info := manager.GetSyncInfo(w.acc.AccName)
	var bizSyncInfo []*pb.ProtoBizSyncInfo
	for _, node := range info.APSyncConfigs {
		if node.Type == "user" && node.UpsKey == "1" {
			enum, _ := strconv.Atoi(node.Enum)
			bizSyncInfo = append(bizSyncInfo, &pb.ProtoBizSyncInfo{
				BizType: proto.Int32(int32(enum)),
				SyncKey: proto.Int64(node.SyncKey),
			})
		}
	}

	var bucketSyncInfo []*pb.ProtoBucketSyncInfo
	for _, node := range info.APBucketConfigs {
		if node.Type == "user" && node.UpsKey == "1" {
			enum, _ := strconv.Atoi(node.Enum)
			bucketSyncInfo = append(bucketSyncInfo, &pb.ProtoBucketSyncInfo{
				BucketType: proto.Int32(int32(enum)),
				SyncKey:    proto.Int64(node.SyncKey),
			})
		}
	}

	op3001 := &pb.ProtoSyncOpCode3001{
		UserId:         proto.String(w.acc.UserId),
		BizSyncInfo:    bizSyncInfo,
		BucketSyncInfo: bucketSyncInfo,
		AppName:        proto.String(AppName),
	}

	op3001B, _ := proto.Marshal(op3001)
	return op3001B
}

func (w *WorkGroup) sendProtoSyncOpCode4011(value string) {
	req := &pb.ProtoSyncOpCode4011{
		BizType:         proto.String("CONFIGSDK-NOTIFY"),
		Key:             proto.String("ConfigArrivalCount" + value),
		Version:         proto.String(""),
		ClientLocalTime: proto.Int64(tools.TimestampEx() / 1000 * 1000),
		AppName:         proto.String(""),
	}

	pd, err := proto.Marshal(req)
	if err != nil {
		log2.Errorf("[WorkGroup]ProtoSyncOpCode4011序列化错误: %+v.", err)
	} else {
		mmtp := &pb.MmtpHead{
			DataFrameChannel: proto.Uint32(2),
		}
		// +[APSyncPBFactory build4011WithBiz:key:version:timestamp:appName:]
		// 06 4011
		data := []byte{0x06, 0x0F, 0xAB}
		data = append(data, pd...)
		w.SendMessage(mmtp, nil, data)
	}
}

func (w *WorkGroup) onSyncOpCode(http2Heads []hpack.HeaderField, data []byte) {
	// 去掉一字节
	r := bytes.NewReader(data[1:])
	var opCode int16
	if err := binary.Read(r, binary.BigEndian, &opCode); err != nil {
		log2.Errorf("[WorkGroup|onSyncOpCode]read op code err: %+v", err)
		return
	}

	switch opCode {
	case 2001:
		w.onSyncOpCode2001(http2Heads, data[3:])
	default:
		log2.Errorf("[WorkGroup|onSyncOpCode]未处理的opCode: %+v", opCode)
	}
}

func (w *WorkGroup) onSyncOpCode2001(http2Heads []hpack.HeaderField, data []byte) {
	res := &pb.ProtoSyncOpCode2001{}
	if err := proto.Unmarshal(data, res); err != nil {
		log2.Errorf("[WorkGroup|onSyncOpCode2001] proto.Unmarshal err: %+v", err)
		return
	}

	// 开始更新sync信息
	infos := manager.GetSyncInfo(w.acc.AccName)
	if infos == nil {
		log2.Error("[WorkGroup|onSyncOpCode2001] syncinfo == nil")
		return
	}
	changed := false
	for _, item := range res.GetBizSyncData() {
		info := infos.FindSyncKeyInfoWithName(item.GetBizName())
		if info == nil {
			log2.Errorf("[WorkGroup|onSyncOpCode2001] FindSyncKeyInfoWithName == nil, item = %+v", proto.MarshalTextString(item))
			continue
		}
		info.SyncKey = item.GetSyncKey()
		if item.GetMultiDevice() {
			info.UpsKey = "1"
		} else {
			info.UpsKey = "0"
		}
		if item.GetPersistentBiz() {
			info.Cmd = "1"
		} else {
			info.Cmd = "0"
		}
		changed = true
	}

	if res.GetBucketSyncInfo() != nil && res.GetBucketSyncInfo().GetSyncKey() != 0 {
		info := infos.FindSyncKeyInfoWithName(res.GetBucketSyncInfo().GetBucketName())
		if info == nil {
			log2.Errorf("[WorkGroup|onSyncOpCode2001] FindSyncKeyInfoWithName == nil, item = %+v", proto.MarshalTextString(res.GetBucketSyncInfo()))
		} else {
			info.SyncKey = res.GetBucketSyncInfo().GetSyncKey()
			if res.GetBucketSyncInfo().GetMultiDevice() {
				info.UpsKey = "1"
			} else {
				info.UpsKey = "0"
			}
			changed = true
		}
	}
	if changed {
		log2.Infof("[WorkGroup|onSyncOpCode2001] 保存同步数据")
		manager.SaveSyncInfo(w.acc.AccName)
	}

	//log2.Infof("[WorkGroup|onSyncOpCode2001] resp:\r\n%+v", proto.MarshalTextString(res))
	if len(res.GetBizSyncData()) > 0 {
		// 同步数据
		w.sendProtoSyncOpCode2002(http2Heads, res)
		// 处理同步消息
		for _, item := range res.GetBizSyncData() {
			switch item.GetBizType() {
			case 4: // devicelock
				for _, log := range item.GetOplog() {
					payload := log.GetPayload()
					if len(payload) <= 0 {
						continue
					}
					log2.Infof("[WorkGroup|onSyncOpCode2001] \r\nbizType=4 payload=%+v", payload)
					// 被挤下线
					if strings.Contains(payload, "账号在其他设备登陆") {
						log2.Infof("[WorkGroup|onSyncOpCode2001] %+v", payload)
						w.sendSTMessage(pb.Actions_USERLOGOUT)
						w.notifyEvent(EventTypeNotify, NotifyLoginOtherDevice, "", nil)
					}
				}
			case 17: // UCHAT
				for _, log := range item.GetOplog() {
					binaryPayload := log.GetBinaryPayload()
					if len(binaryPayload) <= 0 {
						continue
					}
					log2.Infof("[WorkGroup|onSyncOpCode2001] \r\nbizType=17 binaryPayload=%+v", string(binaryPayload))
				}
			case 91: // CASHIER-USER
				for _, log := range item.GetOplog() {
					payload := log.GetPayload()
					if len(payload) <= 0 {
						continue
					}
					log2.Infof("[WorkGroup|onSyncOpCode2001] \r\nbizType=91 payload=%+v", payload)
				}
			case 106: // MSG-BILL
				for _, log := range item.GetOplog() {
					payload := log.GetPayload()
					if len(payload) <= 0 {
						continue
					}
					log2.Infof("[WorkGroup|onSyncOpCode2001] \r\nbizType=106 payload=%+v", payload)
					w.notifyEvent(EventTypeNotify, NotifyMsgBill, payload, nil)
				}
			case 117: // MS-DUPGRADE 升级通知
				for _, log := range item.GetOplog() {
					payload := log.GetPayload()
					if len(payload) <= 0 {
						continue
					}
					log2.Infof("[WorkGroup|onSyncOpCode2001] \r\nbizType=117 payload=%+v", payload)
				}
			}
		}
	}
}
