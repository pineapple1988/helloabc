package alipay

import (
	"encoding/json"
	"fmt"
	"testing"
)

func TestHello(t *testing.T) {
	sessionReq := &createSessionReq{
		PrintQrCodeUrl: "https://qr.alipay.com/fkx08092fbxzlzjbzegdzb5",
		QrCodeUrl:      "https://qr.alipay.com/fkx08765sytlondojrifkbc?t=1569568396080",
	}
	sessionReqB, _ := json.Marshal(sessionReq)
	sessionReqB = append([]byte{0x5b}, sessionReqB...)
	sessionReqB = append(sessionReqB, 0x5d)
	fmt.Println(string(sessionReqB))
}
