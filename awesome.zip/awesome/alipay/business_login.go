package alipay

import (
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"math/rand"
	"net/url"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"
	"golang.org/x/net/html"
)

func (w *WorkGroup) loginRoutine() {
	w.sendAUSRsaKeyReqPB()
	// todo 增加EdgeRequestPB

	time.Sleep(time.Second * time.Duration(3+rand.Intn(5)))
	w.sendAUSUnifyLoginRecommendReqHpbPB()
}

func extractToken(s string) string {
	prefix := "TokenID:'"
	start := strings.Index(s, prefix)
	if start == -1 {
		prefix = "TokenID: '"
		start = strings.Index(s, prefix)
	}

	if start != -1 {
		s = s[start+len(prefix):]
		end := strings.Index(s, "'")
		if end != -1 {
			return s[:end]
		}
	}

	return ""
}

func extractVerifyID(s string) string {
	prefix := "VID:'"
	start := strings.Index(s, prefix)
	if start == -1 {
		prefix = "VID: '"
		start = strings.Index(s, prefix)
	}

	if start != -1 {
		s = s[start+len(prefix):]
		end := strings.Index(s, "'")
		if end != -1 {
			return s[:end]
		}
	}

	return ""
}

func extractFormToken(s string) string {
	prefix := `name="_form_token" value="`
	start := strings.Index(s, prefix)
	if start != -1 {
		end := strings.Index(s[start:], `"/>`)
		if end != -1 {
			return s[start+len(prefix) : start+end]
		}
	}

	return ""
}

func extractSmsToken(s string) string {
	prefix := "短信验证码&quot;,&quot;token&quot;:&quot;"
	start := strings.Index(s, prefix)
	if start == -1 {
		return ""
	} else {
		s = s[start+len(prefix):]
		end := strings.Index(s, "&quot")
		if end == -1 {
			return ""
		} else {
			return s[:end]
		}
	}
}

func extractAnswerToken(s string) string {
	prefix := "与您有关的问题&quot;,&quot;token&quot;:&quot;"
	start := strings.Index(s, prefix)
	if start == -1 {
		return ""
	} else {
		s = s[start+len(prefix):]
		end := strings.Index(s, "&quot")
		if end == -1 {
			return ""
		} else {
			return s[:end]
		}
	}
}

func extractFaceToken(s string) string {
	prefix := "刷脸&quot;,&quot;token&quot;:&quot;"
	start := strings.Index(s, prefix)
	if start == -1 {
		return ""
	} else {
		s = s[start+len(prefix):]
		end := strings.Index(s, "&quot")
		if end == -1 {
			return ""
		} else {
			return s[:end]
		}
	}
}

type questionData struct {
	TotalNum                 int                 `json:"totalNum"`
	PrivacyQuestionQueryView []questionQueryView `json:"privacyQuestionQueryView"`
	StrategyId               string              `json:"strategyId"`
	Token                    string              `json:"token"`
}
type questionQueryView struct {
	DisplayType  string   `json:"displayType"`
	QuestionId   string   `json:"questionId"`
	Options      []option `json:"options"`
	Text         string   `json:"text"`
	CorrectNum   int      `json:"correctNum"`
	PropName     string   `json:"propName"`
	QuestionType string   `json:"questionType"`
}
type option struct {
	DisplayUrl  string `json:"displayUrl"`
	DisplayText string `json:"displayText"`
	Value       string `json:"value"`
}

type validateInfo struct {
	Validateinfo questionAnswerViews `json:"validateinfo"`
}
type questionAnswerViews struct {
	PrivacyQuestionAnswerViews []answer `json:"privacyQuestionAnswerViews"`
	StrategyId                 string   `json:"strategyId"`
	Token                      string   `json:"token"`
}

type answer struct {
	QuestionId     string   `json:"questionId"`
	MultipleAnswer []string `json:"multipleAnswer"`
}

type questionVerifyRes struct {
	HasOtherFlows bool `json:"hasOtherFlows"`
	PrivacyShield struct {
		Msg            string `json:"msg"`
		Code           string `json:"code"`
		IsClosed       bool   `json:"isClosed"`
		ErrorTimesLeft int    `json:"errorTimesLeft"`
		ErrorCode      string `json:"errorCode"`
		ProdSuccess    bool   `json:"prodSuccess"`
		//validateResult
	} `json:"PRIVACY_SHIELD"`
	Success bool `json:"success"`
	Finish  bool `json:"finish"`
}

func (w *WorkGroup) parseQuestion(resp string) string {
	doc, _ := goquery.NewDocumentFromReader(strings.NewReader(resp))
	s := doc.Find("script").Nodes
	var n *html.Node
	for _, node := range s {
		if node.FirstChild != nil && strings.Contains(node.FirstChild.Data, "window.initData.questionData") {
			n = node.FirstChild
			break
		}
	}
	if n != nil {
		end := strings.Index(n.Data, ";")
		question := strings.ReplaceAll(n.Data[:end], "window.initData.questionData", "")
		question = strings.Replace(question, "=", "", 1)
		q := &questionData{}
		_ = json.Unmarshal([]byte(question), q)
		// 随机生成一个结果
		answerViews := make([]answer, q.TotalNum)
		for i := 0; i < q.TotalNum; i++ {
			r := tools.RandIntn(len(q.PrivacyQuestionQueryView[i].Options))
			answerViews[i] = answer{
				QuestionId:     q.PrivacyQuestionQueryView[i].QuestionId,
				MultipleAnswer: []string{q.PrivacyQuestionQueryView[i].Options[r].Value},
			}
		}

		validate, _ := json.Marshal(&validateInfo{
			Validateinfo: questionAnswerViews{
				StrategyId:                 q.StrategyId,
				Token:                      q.Token,
				PrivacyQuestionAnswerViews: answerViews,
			},
		})
		return string(validate)
	} else {
		return ""
	}
}

type accountBindingSMS struct {
	Msg            string `json:"msg"`
	Code           string `json:"code"`
	IsClosed       bool   `json:"isClosed"`
	ErrorTimesLeft int    `json:"errorTimesLeft"`
	ErrorCode      string `json:"errorCode"`
	ProdSuccess    bool   `json:"prodSuccess"`
}

type smsVerifyResult struct {
	HasOtherFlows           bool              `json:"hasOtherFlows"`
	Service                 bool              `json:"service"`
	CallbackType            string            `json:"call_back_type"`
	CallbackURL             string            `json:"call_back_url"`
	CallbackScript          bool              `json:"call_back_script"`
	Success                 bool              `json:"success"`
	Finish                  bool              `json:"finish"`
	AccountBindingSMS       accountBindingSMS `json:"ACCOUNT_BINDING_SMS"`
	AccountBindingSMSSimple accountBindingSMS `json:"ACCOUNT_BINDING_SMS_SIMPLE"`
}

type VerifyInfo struct {
	token       string
	verifyId    string
	verifyToken string
	securityId  string
	refererUrl  string
}

func (w *WorkGroup) toSecurityCore(h5Url, verifyToken, securityId string) {
	// mobileBasicValidate.htm
	// 重定向到/mic/enterMobileVerify.htm
	securityUrl, _ := url.Parse(h5Url)
	query := securityUrl.Query()
	query.Set("callbackUrl", UrlSMSH5Callback)
	securityUrl.RawQuery = query.Encode()
	resp1 := w.httpGet(securityUrl.String(), "")
	log2.Info("resp1 >>>>> " + resp1)

	token := extractToken(resp1)
	verifyId := extractVerifyID(resp1)
	if token == "" || verifyId == "" {
		log2.Error("第一次进入验证界面没有找到token和verifyId")
		return
	}

	gotoUrl, _ := url.Parse(UrlFinishVerify)
	gotoUrl.RawQuery = query.Encode()
	enterUrl, _ := url.Parse(UrlEnterVerify)
	query = enterUrl.Query()
	query.Set("verifyId", verifyId)
	query.Set("vsSecurityId", securityId)
	query.Set("goto", gotoUrl.String())
	enterUrl.RawQuery = query.Encode()

	// 第一次如果不是短信验证就去选择验证方式
	if strings.Contains(resp1, "ACCOUNT_BINDING_SMS") {
		// 验证码登陆
		log2.Info("验证码验证")
		w.acc.verify = &VerifyInfo{
			token:       token,
			verifyId:    verifyId,
			verifyToken: verifyToken,
			securityId:  securityId,
			refererUrl:  enterUrl.String(),
		}
		w.notifyEvent(EventTypeLogin, LoginCodeNeedCode, "", nil)
		return
	}

	// 直接进入选择界面
	checkUrl, _ := url.Parse(UrlCheckVerify)
	query = checkUrl.Query()
	query.Set("token", token)
	query.Set("verifyId", verifyId)
	query.Set("code", "1003") // 1002表示点击的是选择其他验证方式进入,1003表示后退到进入到选择验证方式界面
	checkUrl.RawQuery = query.Encode()
	resp2 := w.httpGet(checkUrl.String(), enterUrl.String())
	log2.Info("resp2 >>>>> " + resp2)

	log2.Infof("回答问题=%+v, 短信验证=%+v, 刷脸=%+v",
		strings.Contains(resp2, "与您有关的问题"),
		strings.Contains(resp2, "短信验证码"),
		strings.Contains(resp2, "刷脸"))

	verifyId = extractVerifyID(resp2)
	// 优先短信，其次回答问题，再次刷脸
	token = ""
	if strings.Contains(resp2, "短信验证码") {
		// 切换到短信验证
		token = extractSmsToken(resp2)
	}
	if token == "" && strings.Contains(resp2, "与您有关的问题") {
		token = extractAnswerToken(resp2)
	}
	if token == "" && strings.Contains(resp2, "刷脸") {
		token = extractFaceToken(resp2)
	}

	var viewUrl *url.URL
	if token != "" && verifyId != "" {
		// 如果有token就进入验证界面
		viewUrl, _ = url.Parse(urlView)
		query = viewUrl.Query()
		query.Set("token", token)
		query.Set("verifyId", verifyId)
		viewUrl.RawQuery = query.Encode()
		resp2 = w.httpGet(viewUrl.String(), checkUrl.String())
		log2.Info(resp2)
	}
	// 无论如何，再次获取验证相关的token和verifyId
	token = extractToken(resp2)
	verifyId = extractVerifyID(resp2)
	if token == "" || verifyId == "" {
		log2.Info("第二次进入验证界面没有找到token和verifyId，只能使用第一次的验证")
		resp2 = resp1
		token = extractToken(resp2)
		verifyId = extractVerifyID(resp2)
	}
	// 第二次判断是何种验证方式
	if strings.Contains(resp2, "ACCOUNT_BINDING_SMS") {
		// 验证码登陆
		log2.Info("验证码验证")
		w.acc.verify = &VerifyInfo{
			token:       token,
			verifyId:    verifyId,
			verifyToken: verifyToken,
			securityId:  securityId,
			refererUrl:  checkUrl.String(),
		}
		w.notifyEvent(EventTypeLogin, LoginCodeNeedCode, "", nil)
	} else if strings.Contains(resp2, "PRIVACY_SHIELD") {
		if viewUrl == nil {
			viewUrl = checkUrl
		}

		// 需要回答问题来验证，这里直接乱选，在达到一定次数后，会失败，下次在登陆就会出现短信验证码
		log2.Info("回答问题验证")
		// 拿出问题
		validateInfo := w.parseQuestion(resp2)
		formToken := extractFormToken(resp2)
		if validateInfo == "" || formToken == "" {
			log2.Error("回答问题失败")
			return
		}
		body := fmt.Sprintf("verifyId=%s&group=h5&token=%s&product=PRIVACY_SHIELD&PRIVACY_SHIELD=%s",
			verifyId, token, url.QueryEscape(validateInfo))

		// 发送结果上去
		resp2 = w.httpPost(urlVerify, body, true, viewUrl.String())
		verifyRes := &questionVerifyRes{}
		_ = json.Unmarshal([]byte(resp2), verifyRes)
		// 乱选的不可能会成功
		if !verifyRes.Finish {
			// 如果没有完成就再次获取题目
			securityUrl, _ = url.Parse(urlVerify)
			query = securityUrl.Query()
			query.Set("_form_token", formToken)
			query.Set("token", token)
			query.Set("verifyId", verifyId)
			query.Set("group", "h5")
			securityUrl.RawQuery = query.Encode()
			resp2 = w.httpGet(securityUrl.String(), viewUrl.String())
		} else {
			// 认证失败完成,在次登陆
			time.Sleep(3 * time.Second)
			w.sendUnifyLoginReqPbPB("", "")
			return
		}
	} else {
		log2.Info("刷脸验证")
		w.acc.verify = &VerifyInfo{
			verifyId:    verifyId,
			token:       token,
			verifyToken: verifyToken,
			securityId:  securityId,
		}

		data, _ := json.Marshal(&map[string]interface{}{
			"externParams": map[string]interface{}{
				"bioMetaInfo": w.getBioMetaInfo(),
				"secData":     w.getSecData(),
				"isNeedFP":    "true",
				"isSupportFP": "true",
				"bp":          getBP(),
			},
		})

		// 开始请求人脸验证
		w.sendMIMICRpcRequestV2PB("INIT", "",
			string(data), w.acc.verify.verifyId, w.acc.verify.token, VerifyScene_LoginCheck)
	}
}

func (w *WorkGroup) verifySmsCode(code string) {
	if len(code) == 0 || len(w.acc.verify.verifyToken) == 0 || len(w.acc.verify.verifyId) == 0 {
		log2.Errorf("verifySmsCode 出现错误，参数 code:%s verifyToken:%s verifyId:%s", code, w.acc.verify.verifyToken, w.acc.verify.verifyId)
		w.notifyEvent(EventTypeSMS, SMSCodeError, "参数错误", nil)
		return
	}

	isSimple := true
	if len(code) > 4 {
		isSimple = false
	}

	code = fmt.Sprintf(`{"ackCode":"%s"}`, code)
	var body string
	if isSimple {
		body = fmt.Sprintf("verifyId=%s&group=h5&token=%s&product=ACCOUNT_BINDING_SMS_SIMPLE&ACCOUNT_BINDING_SMS_SIMPLE=%s",
			w.acc.verify.verifyId, w.acc.verify.token, url.QueryEscape(code))
	} else {
		body = fmt.Sprintf("verifyId=%s&group=h5&token=%s&product=ACCOUNT_BINDING_SMS&ACCOUNT_BINDING_SMS=%s",
			w.acc.verify.verifyId, w.acc.verify.token, url.QueryEscape(code))
	}

	resp := w.httpPost(urlVerify, body, true, w.acc.verify.refererUrl)
	//logger.Debugf("[WorkGroup][%s]校验验证码[%s], 请求: %s, 返回: %+v.", w.acc.AccName, code, body, resp)
	verifyRes := &smsVerifyResult{}
	_ = json.Unmarshal([]byte(resp), verifyRes)

	if verifyRes.Success {
		// 验证成功
		w.sendUnifyLoginReqPbPB(w.acc.verify.verifyToken, w.acc.verify.securityId)
		w.notifyEvent(EventTypeSMS, SMSCodeSuccess, "", nil)
	} else {
		// 验证失败
		log2.Errorf("verify failed!!! verifyRes %+v", verifyRes)
		w.notifyEvent(EventTypeSMS, SMSCodeError, "短信验证码校验失败", verifyRes)
	}

	// w.acc.verify = nil
}

// VerifyCode 校验验证码, 外部调用使用
func (w *WorkGroup) VerifyCode(code string) {
	w.verifySmsCode(code)
}
