package alipay

import (
	"awesome/alipay/model/pb"
	"time"
)

func (w *WorkGroup) initRoutine() {
	//logger.Debug("[WorkGroup]initRoutine =====>>> start")
	if len(w.acc.UTDID) <= 0 {
		w.acc.UTDID = newUTDID()
	}
	//logger.Debug("[WorkGroup]initRoutine =====>>> postSaveWb")
	if len(w.acc.Miniwua) <= 0 {
		w.postSaveWb()
	}
	//logger.Debug("[WorkGroup]initRoutine =====>>> sendMspReqV3PBGenTid")
	if len(w.acc.TID) <= 0 {
		w.sendMspReqV3PBGenTid()
		time.Sleep(3 * time.Second)
	}
	if len(w.acc.APDID) <= 0 {
		w.acc.APDID = w.acc.RandomAPDID
	}
	//logger.Debug("[WorkGroup]initRoutine =====>>> sendReportRequestPB")
	if len(w.acc.APDIDToken) <= 0 {
		w.sendReportRequestPB(1)
		time.Sleep(3 * time.Second)
	}

	w.sendReportRequestPB(3)
	w.sendInitMessage()
	w.sendSTMessage(pb.Actions_FOREGROUND)
	w.sendSwitchInfo()
	w.sendProtoSyncOpCode4011("1")
	w.sendUnionResourceRequest()
	w.sendMOBILEAPPABTestConfigRequestPB()
	w.sendALPReportActiveReq()
	w.sendDeviceLocation(nil)
	//logger.Debug("[WorkGroup]initRoutine =====>>> postMGW")
	w.postMGW()

	//logger.Debug("[WorkGroup]initRoutine =====>>> end")
	select {
	case w.initChan <- true:
	case <-time.After(time.Second * 1):
	}
}
