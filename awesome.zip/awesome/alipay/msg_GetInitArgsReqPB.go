package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendGetInitArgsReqPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.GetInitArgsResPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("GetInitArgsResPB, json.Unmarshal err: %+v", err)
		} else {
			log2.Infof("GetInitArgsResPB, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			//这里是返回付款码相关文字
			//"{
			//    \"changeChannelButton\": \"更换\",
			//    \"channelPageTitle\": \"选择优先付款方式\",
			//    \"choosePageTips\": \"优先使用所选付款方式，如付款失败将尝试使用其他方式完成付款\",
			//    \"displayChannelTips\": \"优先使用此付款方式\",
			//    \"facePaySecureTips\": \"仅限当面向商家付款使用，勿泄露给他人\",
			//    \"facepayCodeTip\": \"付款码及数字每分钟更新，请当面使用勿泄露\"
			//}"
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcGetInitArgs,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.GetInitArgsReqPB{
		IsQueryFacePaySwitch: proto.Bool(true),
		Tid:                  proto.String(w.acc.TID),
	})
}
