package alipay

/*
#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshift-count-overflow"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbitwise-op-parentheses"
#endif

#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>

#ifndef HEXRAYS_DEFS_H
#define HEXRAYS_DEFS_H

#if defined(__GNUC__)
  typedef          long long ll;
  typedef unsigned long long ull;
  #define __int64 long long
  #define __int32 int
  #define __int16 short
  #define __int8  char
  #define MAKELL(num) num ## LL
  #define FMT_64 "ll"
#elif defined(_MSC_VER)
  typedef          __int64 ll;
  typedef unsigned __int64 ull;
  #define MAKELL(num) num ## i64
  #define FMT_64 "I64"
#elif defined (__BORLANDC__)
  typedef          __int64 ll;
  typedef unsigned __int64 ull;
  #define MAKELL(num) num ## i64
  #define FMT_64 "L"
#else
  #error "unknown compiler"
#endif
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;

typedef          char   int8;
typedef   signed char   sint8;
typedef unsigned char   uint8;
typedef          short  int16;
typedef   signed short  sint16;
typedef unsigned short  uint16;
typedef          int    int32;
typedef   signed int    sint32;
typedef unsigned int    uint32;
typedef ll              int64;
typedef ll              sint64;
typedef ull             uint64;

// Partially defined types. They are used when the decompiler does not know
// anything about the type except its size.
#define _BYTE  uint8
#define _WORD  uint16
#define _DWORD uint32
#define _QWORD uint64
#if !defined(_MSC_VER)
#define _LONGLONG __int128
#endif

// Non-standard boolean types. They are used when the decompiler can not use
// the standard "bool" type because of the size mistmatch but the possible
// values are only 0 and 1. See also 'BOOL' type below.
typedef int8 _BOOL1;
typedef int16 _BOOL2;
typedef int32 _BOOL4;

#ifndef _WINDOWS_
typedef int8 BYTE;
typedef int16 WORD;
typedef int32 DWORD;
typedef int32 LONG;
typedef int BOOL;       // uppercase BOOL is usually 4 bytes
#endif
typedef int64 QWORD;
#ifndef __cplusplus
typedef int bool;       // we want to use bool in our C programs
#endif

#define __pure          // pure function: always returns the same value, has no
                        // side effects

// Non-returning function
#if defined(__GNUC__)
#define __noreturn  __attribute__((noreturn))
#else
#define __noreturn  __declspec(noreturn)
#endif


#ifndef NULL
#define NULL 0
#endif

// Some convenience macros to make partial accesses nicer
#define LAST_IND(x,part_type)    (sizeof(x)/sizeof(part_type) - 1)
#if defined(__BYTE_ORDER) && __BYTE_ORDER == __BIG_ENDIAN
#  define LOW_IND(x,part_type)   LAST_IND(x,part_type)
#  define HIGH_IND(x,part_type)  0
#else
#  define HIGH_IND(x,part_type)  LAST_IND(x,part_type)
#  define LOW_IND(x,part_type)   0
#endif
// first unsigned macros:
#define BYTEn(x, n)   (*((_BYTE*)&(x)+n))
#define WORDn(x, n)   (*((_WORD*)&(x)+n))
#define DWORDn(x, n)  (*((_DWORD*)&(x)+n))

#define LOBYTE(x)  BYTEn(x,LOW_IND(x,_BYTE))
#define LOWORD(x)  WORDn(x,LOW_IND(x,_WORD))
#define LODWORD(x) DWORDn(x,LOW_IND(x,_DWORD))
#define HIBYTE(x)  BYTEn(x,HIGH_IND(x,_BYTE))
#define HIWORD(x)  WORDn(x,HIGH_IND(x,_WORD))
#define HIDWORD(x) DWORDn(x,HIGH_IND(x,_DWORD))
#define BYTE1(x)   BYTEn(x,  1)         // byte 1 (counting from 0)
#define BYTE2(x)   BYTEn(x,  2)
#define BYTE3(x)   BYTEn(x,  3)
#define BYTE4(x)   BYTEn(x,  4)
#define BYTE5(x)   BYTEn(x,  5)
#define BYTE6(x)   BYTEn(x,  6)
#define BYTE7(x)   BYTEn(x,  7)
#define BYTE8(x)   BYTEn(x,  8)
#define BYTE9(x)   BYTEn(x,  9)
#define BYTE10(x)  BYTEn(x, 10)
#define BYTE11(x)  BYTEn(x, 11)
#define BYTE12(x)  BYTEn(x, 12)
#define BYTE13(x)  BYTEn(x, 13)
#define BYTE14(x)  BYTEn(x, 14)
#define BYTE15(x)  BYTEn(x, 15)
#define WORD1(x)   WORDn(x,  1)
#define WORD2(x)   WORDn(x,  2)         // third word of the object, unsigned
#define WORD3(x)   WORDn(x,  3)
#define WORD4(x)   WORDn(x,  4)
#define WORD5(x)   WORDn(x,  5)
#define WORD6(x)   WORDn(x,  6)
#define WORD7(x)   WORDn(x,  7)

// now signed macros (the same but with sign extension)
#define SBYTEn(x, n)   (*((int8*)&(x)+n))
#define SWORDn(x, n)   (*((int16*)&(x)+n))
#define SDWORDn(x, n)  (*((int32*)&(x)+n))

#define SLOBYTE(x)  SBYTEn(x,LOW_IND(x,int8))
#define SLOWORD(x)  SWORDn(x,LOW_IND(x,int16))
#define SLODWORD(x) SDWORDn(x,LOW_IND(x,int32))
#define SHIBYTE(x)  SBYTEn(x,HIGH_IND(x,int8))
#define SHIWORD(x)  SWORDn(x,HIGH_IND(x,int16))
#define SHIDWORD(x) SDWORDn(x,HIGH_IND(x,int32))
#define SBYTE1(x)   SBYTEn(x,  1)
#define SBYTE2(x)   SBYTEn(x,  2)
#define SBYTE3(x)   SBYTEn(x,  3)
#define SBYTE4(x)   SBYTEn(x,  4)
#define SBYTE5(x)   SBYTEn(x,  5)
#define SBYTE6(x)   SBYTEn(x,  6)
#define SBYTE7(x)   SBYTEn(x,  7)
#define SBYTE8(x)   SBYTEn(x,  8)
#define SBYTE9(x)   SBYTEn(x,  9)
#define SBYTE10(x)  SBYTEn(x, 10)
#define SBYTE11(x)  SBYTEn(x, 11)
#define SBYTE12(x)  SBYTEn(x, 12)
#define SBYTE13(x)  SBYTEn(x, 13)
#define SBYTE14(x)  SBYTEn(x, 14)
#define SBYTE15(x)  SBYTEn(x, 15)
#define SWORD1(x)   SWORDn(x,  1)
#define SWORD2(x)   SWORDn(x,  2)
#define SWORD3(x)   SWORDn(x,  3)
#define SWORD4(x)   SWORDn(x,  4)
#define SWORD5(x)   SWORDn(x,  5)
#define SWORD6(x)   SWORDn(x,  6)
#define SWORD7(x)   SWORDn(x,  7)


// Helper functions to represent some assembly instructions.

#ifdef __cplusplus

// compile time assertion
#define __CASSERT_N0__(l) COMPILE_TIME_ASSERT_ ## l
#define __CASSERT_N1__(l) __CASSERT_N0__(l)
#define CASSERT(cnd) typedef char __CASSERT_N1__(__LINE__) [(cnd) ? 1 : -1]

// check that unsigned multiplication does not overflow
template<class T> bool is_mul_ok(T count, T elsize)
{
  CASSERT((T)(-1) > 0); // make sure T is unsigned
  if ( elsize  == 0 || count == 0 )
    return true;
  return count <= ((T)(-1)) / elsize;
}

// multiplication that saturates (yields the biggest value) instead of overflowing
// such a construct is useful in "operator new[]"
template<class T> bool saturated_mul(T count, T elsize)
{
  return is_mul_ok(count, elsize) ? count * elsize : T(-1);
}

#include <stddef.h> // for size_t

// memcpy() with determined behavoir: it always copies
// from the start to the end of the buffer
// note: it copies byte by byte, so it is not equivalent to, for example, rep movsd
inline void *qmemcpy(void *dst, const void *src, size_t cnt)
{
  char *out = (char *)dst;
  const char *in = (const char *)src;
  while ( cnt > 0 )
  {
    *out++ = *in++;
    --cnt;
  }
  return dst;
}

// Generate a reference to pair of operands
template<class T>  int16 __PAIR__( int8  high, T low) { return ((( int16)high) << sizeof(high)*8) | uint8(low); }
template<class T>  int32 __PAIR__( int16 high, T low) { return ((( int32)high) << sizeof(high)*8) | uint16(low); }
template<class T>  int64 __PAIR__( int32 high, T low) { return ((( int64)high) << sizeof(high)*8) | uint32(low); }
template<class T> uint16 __PAIR__(uint8  high, T low) { return (((uint16)high) << sizeof(high)*8) | uint8(low); }
template<class T> uint32 __PAIR__(uint16 high, T low) { return (((uint32)high) << sizeof(high)*8) | uint16(low); }
template<class T> uint64 __PAIR__(uint32 high, T low) { return (((uint64)high) << sizeof(high)*8) | uint32(low); }

// rotate left
template<class T> T __ROL__(T value, int count)
{
  const uint nbits = sizeof(T) * 8;

  if ( count > 0 )
  {
    count %= nbits;
    T high = value >> (nbits - count);
    if ( T(-1) < 0 ) // signed value
      high &= ~((T(-1) << count));
    value <<= count;
    value |= high;
  }
  else
  {
    count = -count % nbits;
    T low = value << (nbits - count);
    value >>= count;
    value |= low;
  }
  return value;
}

inline uint8  __ROL1__(uint8  value, int count) { return __ROL__((uint8)value, count); }
inline uint16 __ROL2__(uint16 value, int count) { return __ROL__((uint16)value, count); }
inline uint32 __ROL4__(uint32 value, int count) { return __ROL__((uint32)value, count); }
inline uint64 __ROL8__(uint64 value, int count) { return __ROL__((uint64)value, count); }
inline uint8  __ROR1__(uint8  value, int count) { return __ROL__((uint8)value, -count); }
inline uint16 __ROR2__(uint16 value, int count) { return __ROL__((uint16)value, -count); }
inline uint32 __ROR4__(uint32 value, int count) { return __ROL__((uint32)value, -count); }
inline uint64 __ROR8__(uint64 value, int count) { return __ROL__((uint64)value, -count); }

// carry flag of left shift
template<class T> int8 __MKCSHL__(T value, uint count)
{
  const uint nbits = sizeof(T) * 8;
  count %= nbits;

  return (value >> (nbits-count)) & 1;
}

// carry flag of right shift
template<class T> int8 __MKCSHR__(T value, uint count)
{
  return (value >> (count-1)) & 1;
}

// sign flag
template<class T> int8 __SETS__(T x)
{
  if ( sizeof(T) == 1 )
    return int8(x) < 0;
  if ( sizeof(T) == 2 )
    return int16(x) < 0;
  if ( sizeof(T) == 4 )
    return int32(x) < 0;
  return int64(x) < 0;
}

// overflow flag of subtraction (x-y)
template<class T, class U> int8 __OFSUB__(T x, U y)
{
  if ( sizeof(T) < sizeof(U) )
  {
    U x2 = x;
    int8 sx = __SETS__(x2);
    return (sx ^ __SETS__(y)) & (sx ^ __SETS__(x2-y));
  }
  else
  {
    T y2 = y;
    int8 sx = __SETS__(x);
    return (sx ^ __SETS__(y2)) & (sx ^ __SETS__(x-y2));
  }
}

// overflow flag of addition (x+y)
template<class T, class U> int8 __OFADD__(T x, U y)
{
  if ( sizeof(T) < sizeof(U) )
  {
    U x2 = x;
    int8 sx = __SETS__(x2);
    return ((1 ^ sx) ^ __SETS__(y)) & (sx ^ __SETS__(x2+y));
  }
  else
  {
    T y2 = y;
    int8 sx = __SETS__(x);
    return ((1 ^ sx) ^ __SETS__(y2)) & (sx ^ __SETS__(x+y2));
  }
}

// carry flag of subtraction (x-y)
template<class T, class U> int8 __CFSUB__(T x, U y)
{
  int size = sizeof(T) > sizeof(U) ? sizeof(T) : sizeof(U);
  if ( size == 1 )
    return uint8(x) < uint8(y);
  if ( size == 2 )
    return uint16(x) < uint16(y);
  if ( size == 4 )
    return uint32(x) < uint32(y);
  return uint64(x) < uint64(y);
}

// carry flag of addition (x+y)
template<class T, class U> int8 __CFADD__(T x, U y)
{
  int size = sizeof(T) > sizeof(U) ? sizeof(T) : sizeof(U);
  if ( size == 1 )
    return uint8(x) > uint8(x+y);
  if ( size == 2 )
    return uint16(x) > uint16(x+y);
  if ( size == 4 )
    return uint32(x) > uint32(x+y);
  return uint64(x) > uint64(x+y);
}

#else
// The following definition is not quite correct because it always returns
// uint64. The above C++ functions are good, though.
#define __PAIR__(high, low) (((uint64)(high)<<sizeof(high)*8) | low)
// For C, we just provide macros, they are not quite correct.
#define __ROL__(x, y) __rotl__(x, y)      // Rotate left
#define __ROR__(x, y) __rotr__(x, y)      // Rotate right
#define __CFSHL__(x, y) invalid_operation // Generate carry flag for (x<<y)
#define __CFSHR__(x, y) invalid_operation // Generate carry flag for (x>>y)
#define __CFADD__(x, y) invalid_operation // Generate carry flag for (x+y)
#define __CFSUB__(x, y) invalid_operation // Generate carry flag for (x-y)
#define __OFADD__(x, y) invalid_operation // Generate overflow flag for (x+y)
#define __OFSUB__(x, y) invalid_operation // Generate overflow flag for (x-y)
#endif

// No definition for rcl/rcr because the carry flag is unknown
#define __RCL__(x, y)    invalid_operation // Rotate left thru carry
#define __RCR__(x, y)    invalid_operation // Rotate right thru carry
#define __MKCRCL__(x, y) invalid_operation // Generate carry flag for a RCL
#define __MKCRCR__(x, y) invalid_operation // Generate carry flag for a RCR
#define __SETP__(x, y)   invalid_operation // Generate parity flag for (x-y)

// In the decompilation listing there are some objects declarared as _UNKNOWN
// because we could not determine their types. Since the C compiler does not
// accept void item declarations, we replace them by anything of our choice,
// for example a char:

#define _UNKNOWN char

#ifdef _MSC_VER
#define snprintf _snprintf
#define vsnprintf _vsnprintf
#endif

#endif // HEXRAYS_DEFS_H


typedef uint8*(*fnPtrFun)(uint8 *, int);
uint8 uint8_104760678[] = {
    0, 1, 3, 7, 0xF, 0x1F, 0x3F, 0x7F, 0xFF, 0, 0, 0, 0,
    0, 0, 0
};

const char *aLtScriptGt = "&lt,script&gt";

const char *a1tScriptGt = "&1t,script&gt";

const char *aItScriptGt = "&it,script&gt";

const char *a1tScriptGt_0 = "&1t;script&gt";

// 0
uint8* sub_100ABEB30(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (*v2 >> 4) & 0xF | 16 * *v2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 1
uint8* sub_100ABEB54(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (*v2 >> 4) & 0xF | 16 * *v2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 2
uint8* sub_100ABEB78(uint8 *result, int a2)
{
  	if ( a2 )
  	{
    	for (int i = 0; i != a2; ++i )
		{
      		*(result + i) ^= aLtScriptGt[i - 13 * (i / 0x400001A0)];
		}
  	}
  	return result;
}

// 3
uint8* sub_100ABEBCC(uint8 *result, int a2)
{
    if ( a2 )
  	{
    	for (int i = 0; i != a2; ++i )
		{
      		*(result + i) ^= aLtScriptGt[i - 13 * (i / 0x400001A0)];
		}
  	}
  	return result;
}

// 4
uint8* sub_100ABEC20(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 68;
            --a2;
        } while (a2);
    }
    return result;
}

// 5
uint8* sub_100ABEC40(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 68;
            --a2;
        } while (a2);
    }
    return result;
}

// 6
uint8* sub_100ABEC60(uint8 *result, int a2)
{
  	uint8 v3; // w11
  	uint8 v4; // w12

  	if ( a2 )
  	{
    	for (int i = 0; i < a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		v4 = *(result + i) - 1;
      		*(result + i) = v4;
      		*(result + i) = (v4 >> (i - (v3 & 0xF8))) & uint8_104760678[8 - ((i - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (i - (v3 & 0xF8))));
		}
	}

  	return result;
}

// 7
uint8* sub_100ABECCC(uint8 *result, int a2)
{
  	uint8 v3; // w11

  	if ( a2 )
  	{
		for (int i = 0; i != a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		*(result + i) = ((*(result + i) >> (8 - (i - (v3 & 0xF8)))) & uint8_104760678[(i - (v3 & 0xF8))] | (*(result + i) << (i - (v3 & 0xF8)))) + 1;
    	}
  	}

  	return result;
}

// 8
uint8* sub_100ABED30(uint8 *result, int a2)
{
  int v2; // x8
  uint8 v3; // w9

  if ( a2 )
  {
    v2 = 0;
    v3 = 54;
    do
    {
      *(result + v2) ^= v3;
      v3 *= v2++;
    }
    while ( a2 != v2 );
  }
  return result;
}

// 9
uint8* sub_100ABED74(uint8 *result, int a2)
{
  int v2; // x8
  uint8 v3; // w9

  if ( a2 )
  {
    v2 = 0;
    v3 = 54;
    do
    {
      *(result + v2) ^= v3;
      v3 *= v2++;
    }
    while ( a2 != v2 );
  }
  return result;
}

// 10
uint8* sub_100ABEDB8(uint8 *result, int a2)
{
    uint8 v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 11
uint8* sub_100ABEDE0(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 12
uint8* sub_100ABEE08(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            *v3++ ^= (v2 ^ 16 * v2) & 0xF0 | (v2 >> 4);
            --a2;
            v2 = (v2 ^ 16 * v2) & 0xF0 | (v2 >> 4);
        } while (a2);
    }
    return result;
}

// 13
uint8* sub_100ABEE3C(uint8 *result, int a2)
{
    return sub_100ABEE08(result, a2);
}

// 14
uint8* sub_100ABEE40(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 15
uint8* sub_100ABEE64(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 16
uint8* sub_100ABEE88(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xCA;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 17
uint8* sub_100ABEEB0(uint8 *result, int a2)
{
	int v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 202;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 18
uint8* sub_100ABEED4(uint8 *result, int a2)
{
	int v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 19
uint8* sub_100ABEEF8(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xCB;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 20
uint8* sub_100ABEF20(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w10
    uint8 v4; // w12
    uint8 v5; // w11

    if (a2)
    {
        v2 = 0;
        v3 = 0xD4;
        do
        {
            v4 = 0;
            v5 = 0;
            do
            {
                v5 = (1 << v4) & v3 | v5;
                v3 = ((4 * v3) ^ (32 * v3)) & 0x80 | (v3 >> 1);
                ++v4;
            } while (v4 != 8);
            *(result + v2++) ^= v5;
        } while (v2 != a2);
    }
    return result;
}

// 21
uint8* sub_100ABEF84(uint8 *result, int a2)
{
    return sub_100ABEF20(result, a2);
}

// 22
uint8* sub_100ABEF88(uint8 *result, int a2)
{
    uint8 *v2; // x10
    uint8 v3; // w11

    if (a2)
    {
        v2 = result;
        do
        {
            v3 = *v2 & 0xF ^ (*v2 >> 4) | *v2 & 0xF0;
            *v2++ = (v3 >> 1) & 0x55 | (2 * v3) & 0xAA;
            --a2;
        } while (a2);
    }
    return result;
}

// 23
uint8* sub_100ABEFC8(uint8 *result, int a2)
{
    return sub_100ABEF88(result, a2);
}

// 24
uint8* sub_100ABEFCC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 25
uint8* sub_100ABEFF4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = 16 * (*v2 - 2) & 0xF0 | ((*v2 - 2) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 26
uint8* sub_100ABF01C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 3;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 27
uint8* sub_100ABF044(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (16 * (*v2 - 3)) | ((*v2 - 3) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 28
uint8* sub_100ABF06C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | (16 * *v2)) + 4;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 29
uint8* sub_100ABF094(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (16 * (*v2 - 4)) | ((*v2 - 4) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 30
uint8* sub_100ABF0BC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | (16 * *v2)) + 5;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 31
uint8* sub_100ABF0E4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (16 * (*v2 - 5)) | ((*v2 - 5) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 32
uint8* sub_100ABF10C(uint8 *result, int a2)
{
    int v2; // x8

    if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= aLtScriptGt[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 33
uint8* sub_100ABF160(uint8 *result, int a2)
{
    int v2; // x8

    if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= aLtScriptGt[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 34
uint8* sub_100ABF1B4(uint8 *result, int a2)
{
    if (a2)
    {
        for (int i = 0; i < a2; ++i)
		{
			*(result + i) ^= a1tScriptGt[(i + 2) % 0xD];
		}
    }
    return result;
}

// 35
uint8* sub_100ABF208(uint8 *result, int a2)
{
    if (a2)
    {
        for (int i = 0; i < a2; ++i)
		{
			*(result + i) ^= a1tScriptGt[(i + 2) % 0xD];
		}
    }
    return result;
}

// 36
uint8* sub_100ABF25C(uint8 *result, int a2)
{
    int v2; // x8

    if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= aItScriptGt[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 37
uint8* sub_100ABF2B0(uint8 *result, int a2)
{
    int v2; // x8

    if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= aItScriptGt[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 38
uint8* sub_100ABF304(uint8 *result, int a2)
{
    int v2; // x8

	if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= a1tScriptGt_0[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 39
uint8*  sub_100ABF358(uint8 *result, int a2)
{
    int v2; // x8
	if (a2)
    {
        v2 = 0;
        do
        {
            *(result + v2) ^= a1tScriptGt_0[(v2 + 1) % 0xD];
        }
        while (a2 != ++v2);
    }
    return result;
}

// 40
uint8* sub_100ABF3AC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 67;
            --a2;
        } while (a2);
    }
    return result;
}

// 41
uint8* sub_100ABF3CC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 67;
            --a2;
        } while (a2);
    }
    return result;
}

// 42
uint8* sub_100ABF3EC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 68;
            --a2;
        } while (a2);
    }
    return result;
}

// 43
uint8* sub_100ABF40C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 68;
            --a2;
        } while (a2);
    }
    return result;
}

// 44
uint8* sub_100ABF42C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 69;
            --a2;
        } while (a2);
    }
    return result;
}

// 45
uint8* sub_100ABF44C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 69;
            --a2;
        } while (a2);
    }
    return result;
}

// 46
uint8* sub_100ABF46C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 70;
            --a2;
        } while (a2);
    }
    return result;
}

// 47
uint8* sub_100ABF48C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 70;
            --a2;
        } while (a2);
    }
    return result;
}

// 48
uint8* sub_100ABF4AC(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
       	for (int i = 0; i != a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		v4 = *(result + i) - 2;
      		*(result + i) = v4;
      		*(result + i) = (v4 >> (i - (v3 & 0xF8))) & uint8_104760678[8 - ((i - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (i - (v3 & 0xF8))));
    	}
    }
    return result;
}

// 49
uint8* sub_100ABF518(uint8 *result, int a2)
{
    int v3; // w11

    if (a2)
    {
        for (int i = 0; i < a2; ++i )
		{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		*(result + i) = ((*(result + i) >> (8 - (i - (v3 & 0xF8)))) & uint8_104760678[i - (v3 & 0xF8)] | (*(result + i) << (i - (v3 & 0xF8)))) + 2;
    	}
    }
    return result;
}

// 50
uint8* sub_100ABF57C(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        for (int i = 0; i < a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		v4 = *(result + i) - 1;
      		*(result + i) = v4;
      		*(result + i) = (v4 >> (i - (v3 & 0xF8) + 1)) & uint8_104760678[8 - ((i - (v3 & 0xF8) + 1) & 0xFF)] | (v4 << (7 - (i - (v3 & 0xF8))));
    	}
    }
    return result;
}

// 51
uint8* sub_100ABF5EC(uint8 *result, int a2)
{
    uint8 v3; // w11

    if (a2)
    {
        for (int i = 0; i < a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		*(result + i) = ((*(result + i) >> (7 - (i - (v3 & 0xF8)))) & uint8_104760678[i - (v3 & 0xF8) + 1] | (*(result + i) << (i - (v3 & 0xF8) + 1))) + 1;
    	}
    }
    return result;
}

// 52
uint8* sub_100ABF654(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        for (int i = 0; i != a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		v4 = *(result + i) - 1;
      		*(result + i) = v4;
      		*(result + i) = ((v4 >> (i - (v3 & 0xF8))) & uint8_104760678[8 - ((i - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (i - (v3 & 0xF8))))) + 1;
    	}
    }
    return result;
}

// 53
uint8* sub_100ABF6C4(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        for (int i = 0; i != a2; ++i )
    	{
      		v3 = *(result + i) - 1;
      		*(result + i) = v3;
      		v4 = i + 7;
      		if ( i >= 0 )
        		v4 = i;
      		*(result + i) = ((v3 >> (8 - (i - (v4 & 0xF8)))) & uint8_104760678[i - (v4 & 0xF8)] | (v3 << (i - (v4 & 0xF8)))) + 1;
    	}
    }
    return result;
}

// 54
uint8* sub_100ABF734(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        for (int i = 0; i != a2; ++i )
    	{
      		v3 = i + 7;
      		if ( i >= 0 )
        		v3 = i;
      		v4 = *(result + i) - 1;
      		*(result + i) = v4;
      		*(result + i) = ((v4 >> (i - (v3 & 0xF8))) & uint8_104760678[8 - ((i - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (i - (v3 & 0xF8))))) + 2;
    	}
    }
    return result;
}

// 55
uint8* sub_100ABF7A4(uint8 *result, int a2)
{
    uint8 v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        for (int i = 0LL; i != a2; ++i )
    	{
      		v3 = *(result + i) - 2;
      		*(result + i) = v3;
      		v4 = i + 7;
      		if ( i >= 0 )
        		v4 = i;
			*(result + i) = ((v3 >> (8 - (i - (v4 & 0xF8)))) & uint8_104760678[i - (v4 & 0xF8)] | (v3 << (i - (v4 & 0xF8)))) + 1;
    	}
    }
    return result;
}

// 56
uint8* sub_100ABF814(uint8* result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 53;
        do
        {
            *(result + v2) ^= v3;
			v3 = v3 * v2++ + 1;
        } while (a2 != v2);
    }
    return result;
}

// 57
uint8* sub_100ABF85C(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 53;
        do
        {
            *(result + v2) ^= v3;
			v3 = v3 * v2++ + 1;
        } while (a2 != v2);
    }
    return result;
}

// 58
uint8* sub_100ABF8A4(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3;
			v3 = v3 * v2++ + 1;
        } while (a2 != v2);
    }
    return result;
}

// 59
uint8* sub_100ABF8EC(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3;
			v3 = v3 * v2++ + 1;
        } while (a2 != v2);
    }
    return result;
}

// 60
uint8* sub_100ABF934(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3 + 1;
			v3 *= v2++;
        } while (a2 != v2);
    }
    return result;
}

// 61
uint8* sub_100ABF97C(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3 + 1;
			v3 *= v2++;
        } while (a2 != v2);
    }
    return result;
}

// 62
uint8* sub_100ABF9C4(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3 + 2;
			v3 *= v2++;
        } while (a2 != v2);
    }
    return result;
}

// 63
uint8* sub_100ABFA0C(uint8 *result, int a2)
{
    int v2; // x8
    uint8 v3; // w9

    if (a2)
    {
        v2 = 0;
        v3 = 54;
        do
        {
            *(result + v2) ^= v3 + 2;
			v3 *= v2++;
        } while (a2 != v2);
    }
    return result;
}

// 64
uint8* sub_100ABFA54(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x10
    uint8 v4; // w9

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

// 65
uint8* sub_100ABFA80(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x10
    uint8 v4; // w9

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 1;
			++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 66
uint8* sub_100ABFAAC(uint8 *result, int a2)
{
    uint8 v2; // w8
    uint8 *v3; // x9
    uint8 v4; // w10

    if (a2)
    {
        v2 = 104;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 1;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

// 67
uint8* sub_100ABFAD8(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 1;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 68
uint8* sub_100ABFB04(uint8 *result, int a2)
{
    uint8 v2; // w8
    uint8 *v3; // x9
    uint8 v4; // w10

    if (a2)
    {
        v2 = 104;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 2;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

// 69
uint8* sub_100ABFB30(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 70
uint8* sub_100ABFB5C(uint8 *result, int a2)
{
    uint8 v2; // w8
    uint8 *v3; // x9
    uint8 v4; // w10

    if (a2)
    {
        v2 = 105;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 2;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

// 71
uint8* sub_100ABFB88(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

// 72
uint8* sub_100ABFBB4(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            *v3++ ^= ((v2 + 1) ^ 16 * v2) & 0xF0 | (v2 >> 4);
            --a2;
            v2 = ((v2 + 1) ^ 16 * v2) & 0xF0 | (v2 >> 4);
        } while (a2);
    }
    return result;
}

// 73
uint8* sub_100ABFBEC(uint8 *result, int a2)
{
    return sub_100ABFBB4(result, a2);
}

// 74
uint8* sub_100ABFBF0(uint8 *result, int a2)
{
    uint8 v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            v2 = (v2 ^ (16 * v2)) & 0xF0 | (v2 >> 4);
            *v3++ ^= v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 75
uint8* sub_100ABFC24(uint8 *result, int a2)
{
    return sub_100ABFBF0(result, a2);
}

// 76
uint8* sub_100ABFC28(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            *v3++ ^= ((v2 + 1) ^ (16 * v2)) & 0xF0 | (v2 >> 4);
            --a2;
            v2 = ((v2 + 1) ^ (16 * v2)) & 0xF0 | (v2 >> 4);
        } while (a2);
    }
    return result;
}

// 77
uint8* sub_100ABFC60(uint8 *result, int a2)
{
    return sub_100ABFC28(result, a2);
}

// 78
uint8* sub_100ABFC64(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            *v3++ ^= (v2 ^ (16 * v2)) & 0xF0 | ((v2 + 1) >> 4);
            --a2;
            v2 = (v2 ^ (16 * v2)) & 0xF0 | ((v2 + 1) >> 4);
        } while (a2);
    }
    return result;
}

// 79
uint8* sub_100ABFC9C(uint8 *result, int a2)
{
    return sub_100ABFC64(result, a2);
}

// 80
uint8* sub_100ABFCA0(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 81
uint8* sub_100ABFCC4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 82
uint8* sub_100ABFCE8(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xC;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 83
uint8* sub_100ABFD0C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (*v2 >> 4) ^ 0xC;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

// 84
uint8* sub_100ABFD30(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w9

    if (a2)
    {
        v2 = 0xC6;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 5;
            --a2;
        } while (a2);
    }
    return result;
}

// 85
uint8* sub_100ABFD5C(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xC6;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 5;
            --a2;
        } while (a2);
    }
    return result;
}

// 86
uint8* sub_100ABFD84(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w9

    if (a2)
    {
        v2 = 0xCD;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 1;
            --a2;
        } while (a2);
    }
    return result;
}

// 87
uint8* sub_100ABFDB0(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xCD;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 1;
            --a2;
        } while (a2);
    }
    return result;
}

// 88
uint8* sub_100ABFDD8(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x10
    uint8 v4; // w9

    if (a2)
    {
        v2 = 0xCD;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

// 89
uint8* sub_100ABFE04(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xCD;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

// 90
uint8* sub_100ABFE2C(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w9

    if (a2)
    {
        v2 = 0xCB;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 3;
            --a2;
        } while (a2);
    }
    return result;
}

// 91
uint8* sub_100ABFE58(uint8 *result, int a2)
{
    uint8 v2; // w9
    uint8 *v3; // x8
    uint8 v4; // w10

    if (a2)
    {
        v2 = 0xCB;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 3;
            --a2;
        } while (a2);
    }
    return result;
}

void sub_100ABDD44(fnPtrFun *result)
{
    result[0] = sub_100ABEB30;
    result[1] = sub_100ABEB54;
    result[2] = sub_100ABEB78;
    result[3] = sub_100ABEBCC;
    result[4] = sub_100ABEC20;
    result[5] = sub_100ABEC40;
    result[6] = sub_100ABEC60;
    result[7] = sub_100ABECCC;
    result[8] = sub_100ABED30;
    result[9] = sub_100ABED74;
    result[10] = sub_100ABEDB8;
    result[11] = sub_100ABEDE0;
    result[12] = sub_100ABEE08;
    result[13] = sub_100ABEE3C;
    result[14] = sub_100ABEE40;
    result[15] = sub_100ABEE64;
    result[16] = sub_100ABEE88;
    result[17] = sub_100ABEEB0;
    result[18] = sub_100ABEED4;
    result[19] = sub_100ABEEF8;
    result[20] = sub_100ABEF20;
    result[21] = sub_100ABEF84;
    result[22] = sub_100ABEF88;
    result[23] = sub_100ABEFC8;
    result[24] = sub_100ABEFCC;
    result[25] = sub_100ABEFF4;
    result[26] = sub_100ABF01C;
    result[27] = sub_100ABF044;
    result[28] = sub_100ABF06C;
    result[29] = sub_100ABF094;
    result[30] = sub_100ABF0BC;
    result[31] = sub_100ABF0E4;
    result[32] = sub_100ABF10C;
    result[33] = sub_100ABF160;
    result[34] = sub_100ABF1B4;
    result[35] = sub_100ABF208;
    result[36] = sub_100ABF25C;
    result[37] = sub_100ABF2B0;
    result[38] = sub_100ABF304;
    result[39] = sub_100ABF358;
    result[40] = sub_100ABF3AC;
    result[41] = sub_100ABF3CC;
    result[42] = sub_100ABF3EC;
    result[43] = sub_100ABF40C;
    result[44] = sub_100ABF42C;
    result[45] = sub_100ABF44C;
    result[46] = sub_100ABF46C;
    result[47] = sub_100ABF48C;
    result[48] = sub_100ABF4AC;
    result[49] = sub_100ABF518;
    result[50] = sub_100ABF57C;
    result[51] = sub_100ABF5EC;
    result[52] = sub_100ABF654;
    result[53] = sub_100ABF6C4;
    result[54] = sub_100ABF734;
    result[55] = sub_100ABF7A4;
    result[56] = sub_100ABF814;
    result[57] = sub_100ABF85C;
    result[58] = sub_100ABF8A4;
    result[59] = sub_100ABF8EC;
    result[60] = sub_100ABF934;
    result[61] = sub_100ABF97C;
    result[62] = sub_100ABF9C4;
    result[63] = sub_100ABFA0C;
    result[64] = sub_100ABFA54;
    result[65] = sub_100ABFA80;
    result[66] = sub_100ABFAAC;
    result[67] = sub_100ABFAD8;
    result[68] = sub_100ABFB04;
    result[69] = sub_100ABFB30;
    result[70] = sub_100ABFB5C;
    result[71] = sub_100ABFB88;
    result[72] = sub_100ABFBB4;
    result[73] = sub_100ABFBEC;
    result[74] = sub_100ABFBF0;
    result[75] = sub_100ABFC24;
    result[76] = sub_100ABFC28;
    result[77] = sub_100ABFC60;
    result[78] = sub_100ABFC64;
    result[79] = sub_100ABFC9C;
    result[80] = sub_100ABFCA0;
    result[81] = sub_100ABFCC4;
    result[82] = sub_100ABFCE8;
    result[83] = sub_100ABFD0C;
    result[84] = sub_100ABFD30;
    result[85] = sub_100ABFD5C;
    result[86] = sub_100ABFD84;
    result[87] = sub_100ABFDB0;
    result[88] = sub_100ABFDD8;
    result[89] = sub_100ABFE04;
    result[90] = sub_100ABFE2C;
    result[91] = sub_100ABFE58;
    result[92] = NULL;
    result[93] = NULL;
}

// 字节数组 2 字符数组 长度翻倍
int sub_100ABCB38(uint8 *a1, int a2, uint8 *a3, int *a4)
{
    int result; // x0
    signed __int64 v5; // x8
    unsigned int v6; // w9
    char v7; // w9
    unsigned int v8; // w9
    unsigned int v9; // w8
    char v10; // w8

    if (2 * a2 > *a4)
        return -1;

    *a4 = 0;
    if (a1 && a2)
    {
        v5 = 0LL;
        do
        {
            v6 = *a1 & 0xF;
            if (v6 > 9)
                v7 = v6 + 87;
            else
                v7 = v6 | 0x30;
            a3[v5 + 1] = v7;
            v8 = *a1;
            v9 = v8 >> 4;
            if (v8 > 0x9F)
                v10 = v9 + 87;
            else
                v10 = v9 | 0x30;
            a3[*a4] = v10;
            v5 = *a4 + 2;
            *a4 = v5;
            ++a1;
            --a2;
        } while (a2);
        result = 0;
    }
    else
    {
        result = 0;
        *a3 = 0;
    }
    return result;
}

int EncryptAndSign(uint8_t *in, int len, uint8_t *out)
{
    fnPtrFun fnFunAry[94];
    sub_100ABDD44(fnFunAry);

    srand((unsigned)time(NULL));
    uint8 randA = (uint8)rand();
    uint8 randB = (uint8)rand();
    uint8 randC = (uint8)rand();

    //uint8 randA = 0x60;
    //uint8 randB = 0x13;
    //uint8 randC = 0xAD;

	//uint8 randFunA = 46 - randA % 46;
    //uint8 randFunB = 46 - randB % 46;
    //uint8 randFunC = 46 - randB % 46;
	uint64 s = 0xB21642C9;
	uint8 randFunA = randA - 46 * ((s*randA) >> 37);
    uint8 randFunB = randB - 46 * ((s*randB) >> 37);
    uint8 randFunC = randC - 46 * ((s*randC) >> 37);

    fnPtrFun fnFunA = fnFunAry[randFunA * 2];
    fnPtrFun fnFunB = fnFunAry[randFunB * 2];
    fnPtrFun fnFunC = fnFunAry[randFunC * 2];

    fnFunA(in, len);
    fnFunB(in, len);
    fnFunC(in, len);

    uint8 randAry[] = { randA, randB, randC };
    int randOL = 2 * 3 | 1;
    uint8 randOutAry[0x10] = { 0 };
    sub_100ABCB38(randAry, sizeof(randAry), randOutAry, &randOL);

    int ol = 2 * len | 1;
    uint8* contentOutAry = (uint8*)malloc(ol);
	if (contentOutAry != NULL) {
    	sub_100ABCB38(in, len, contentOutAry, &ol);

    	memcpy(out, randOutAry, randOL);
    	memcpy(out + randOL, contentOutAry, ol);

		free(contentOutAry);
		return randOL + ol;
	}
    return 0;
}
*/
import "C"
import (
	"crypto/sha1"
	"fmt"
)

// EncryptAndSign 自定义算法
func EncryptAndSign(in []byte) string {
	buf := make([]byte, 0x2000)
	length := C.EncryptAndSign((*C.uint8_t)(&in[0]), C.int(len(in)), (*C.uint8_t)(&buf[0]))
	arr := buf[:int(length)]

	salt1 := make([]byte, 64)
	salt2 := make([]byte, 64)
	outData := make([]byte, 20)
	copy(salt1, RdsSalt)
	copy(salt2, RdsSalt)

	for i := 0; i < 64; i++ {
		salt1[i] ^= 0x36
		salt2[i] ^= 0x5c
	}

	s1 := sha1.New()
	s1.Write(salt1)
	s1.Write(arr)
	outData = s1.Sum(nil)

	s2 := sha1.New()
	s2.Write(salt2)
	s2.Write(outData)
	outData = s2.Sum(nil)

	return string(arr) + fmt.Sprintf("%x", outData)
}
