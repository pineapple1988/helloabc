package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"

	"github.com/golang/protobuf/proto"
)

type VerifyScene int

const (
	VerifyScene_Login      = 1
	VerifyScene_LoginCheck = 2
	VerifyScene_Transfer   = 3
)

func (w *WorkGroup) sendMIMICRpcRequestV2PB(module, action, data, verifyId, token string, scene VerifyScene) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MICMICRpcResponseV2PB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("MICMICRpcResponseV2PB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("MICMICRpcResponseV2PB, resp: \r\n%+v", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				switch scene {
				case VerifyScene_Login:
					if respObj.GetVerifySuccess() {
						loginRes := &unifyLoginRes{}
						_ = json.Unmarshal([]byte(respObj.GetBizResponseData()), loginRes)
						w.parseLoginRes(loginRes.Code, loginRes.Msg, loginRes.UserId, loginRes.SessionId, loginRes.Data)
					}
				case VerifyScene_LoginCheck:
					if respObj.GetNextStep() == "FACEVERIFY" {
						w.parseZimInitResponse([]byte(respObj.GetPbData()), respObj.GetVerifyId(), respObj.GetToken(), scene)
					} else {
						if respObj.GetVerifySuccess() {
							w.sendUnifyLoginReqPbPB(w.acc.verify.verifyToken, w.acc.verify.securityId)
							w.acc.verify = nil
						}
					}
				}
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcDispatchV2,
		"retryable2":     "0",
	}

	envData, _ := json.Marshal(&map[string]string{
		"bp":           getBP(),
		"appVersion":   AppVersion,
		"manufacturer": "Apple",
		"appName":      BundleId,
		"osVersion":    fmt.Sprintf("iOS%s", w.acc.Device.SysVer),
		"viSdkVersion": VIDataVersion,
		"deviceType":   "ios",
		"apdid":        w.acc.APDID,
		"apdidToken":   w.acc.APDIDToken,
		"tid":          w.acc.TID,
		"deviceModel":  w.acc.Device.Model,
	})

	w.SendHttpMessage(onResp, headers, &pb.MICMICRpcRequestV2PB{
		Module:     proto.String(module),
		Action:     proto.String(action),
		PbData:     proto.String(data),
		Token:      proto.String(token),
		VerifyId:   proto.String(verifyId),
		Version:    proto.String(VIDataVersion),
		EnvData:    proto.String(string(envData)),
		BizRequest: proto.String(""),
	})
}
