package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"fmt"
	"github.com/golang/protobuf/proto"
)

// 	sub_10078F5B0 构造数据
// 	-[WPCarryInfo isJailbroken]_0 判断是否越狱
// 	   	sub_100F98BD8 具体的检测地方

func buildExtInfos(acc *Account) []*pb.PBEntryStringString {
	return []*pb.PBEntryStringString{
		{
			Key:   proto.String("cellId"),
			Value: proto.String(""),
		}, {
			Key:   proto.String("idfa"),
			Value: proto.String(acc.Device.IDFA),
		}, {
			Key:   proto.String("isPrisonBreak"), // 越狱检测
			Value: proto.String("T"),
		}, {
			Key:   proto.String("longitude"),
			Value: proto.String(""),
		}, {
			Key:   proto.String("latitude"),
			Value: proto.String(""),
		}, {
			Key:   proto.String("devKeySet"),
			Value: proto.String(fmt.Sprintf(`{"apdidToken":"%s"}`, acc.APDIDToken)),
		}, {
			Key:   proto.String("apdid"),
			Value: proto.String(acc.APDID),
		}, {
			Key:   proto.String("umidToken"),
			Value: proto.String(acc.UMIDToken),
		}, {
			Key:   proto.String("wifiMac"),
			Value: proto.String(acc.Device.WifiMac),
		}, {
			Key:   proto.String("wifiNodeName"),
			Value: proto.String(acc.Device.WifiName),
		}, {
			Key:   proto.String("lacId"),
			Value: proto.String(""),
		}, {
			Key:   proto.String("hpid"),
			Value: proto.String(acc.Hpid),
		},
	}
}

func (w *WorkGroup) sendALPReportActiveReq() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.ALPReportActiveRespPBPB{}
		err := proto.Unmarshal(resp, respObj)
		if err != nil {
			log2.Errorf("ALPReportActiveRespPBPB proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("ALPReportActiveRespPBPB \r\n%+v", proto.MarshalTextString(respObj))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcReportActive,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.ALPReportActiveReqPBPB{
		Channels:       proto.String("apple-iphone"),
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		UserAgent:      proto.String("ALIPAY_FOR_IOS"),
		MobileBrand:    proto.String("apple"),
		MobileModel:    proto.String("iPhone"),
		AccessPoint:    proto.String("wifi"),
		ClientPostion:  proto.String(""),
		SystemVersion:  proto.String(w.acc.Device.SysVer),
		Awid:           proto.String(w.acc.AWID),
		DeviceToken:    proto.String(""),
		SourceId:       proto.String(""),
		Imei:           proto.String(w.acc.Device.IMEI),
		Imsi:           proto.String(w.acc.Device.IMSI),
		ScreenSize:     proto.String(""),
		Carrier:        proto.String(tools.CarrierByIMSI(w.acc.Device.IMSI)),
		ExtInfos: &pb.PBMapStringString{
			Entries: buildExtInfos(w.acc),
		},
		ScreenWidth:  proto.Int64(int64(tools.ScreenWidthPt(w.acc.Device.Model))),
		ScreenHeight: proto.Int64(int64(tools.ScreenHeightPt(w.acc.Device.Model))),
		SystemType:   pb.SystemType_IPHONE.Enum(),
		MobileModel2: proto.String(w.acc.Device.Model),
	})
}
