package alipay

import (
	"awesome/alipay/model/pb"
	"awesome/tools"
	"crypto/md5"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"math/rand"
	"strconv"
	"strings"
	"time"
)

func RandSensor(base [2][3]float32) []string {
	var r [3][4]float32
	for i := 0; i < 3; i++ {
		for j := 0; j < 4; j++ {
			if rand.Uint32()%2 == 0 {
				r[i][j] = base[0][i] + tools.RandFloat(base[1][i])
			} else {
				r[i][j] = base[0][i] - tools.RandFloat(base[1][i])
			}
		}
	}
	return []string{
		fmt.Sprintf("%f,%f,%f", r[0][0], r[1][0], r[2][0]),
		fmt.Sprintf("%f,%f,%f", r[0][1], r[1][1], r[2][1]),
		fmt.Sprintf("%f,%f,%f", r[0][2], r[1][2], r[2][2]),
		fmt.Sprintf("%f,%f,%f", r[0][3], r[1][3], r[2][3]),
	}
}
func (w *WorkGroup) getUAFaceLogin() *pb.RdsRequestMessageSdkUsrUa {
	actionTime := tools.TimestampEx()
	action1 := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				Pr: proto.String("-"),
				T:  proto.String(strconv.FormatInt(actionTime, 10)),
			},
		},
		Cn:   proto.String("-"),
		Et:   proto.String("pe"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("0"),
		Type: proto.String("1"),
		T:    proto.String(strconv.FormatInt(actionTime, 10)),
	}
	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(1500, 2500)))
	loginBtnTime := tools.TimestampEx()
	action2 := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				T: proto.String(strconv.FormatInt(loginBtnTime, 10)),
			},
		},
		Cn:   proto.String("FaceLoginBtn"),
		Et:   proto.String("cc"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("1"),
		Type: proto.String("0"),
		T:    proto.String(strconv.FormatInt(loginBtnTime, 10)),
	}

	return &pb.RdsRequestMessageSdkUsrUa{
		Action: []*pb.RdsRequestMessageSdkUsrAction{
			action1, action2,
		},
		Num: proto.String("2"),
		T:   proto.String(strconv.FormatInt(actionTime, 10)),
	}
}
func (w *WorkGroup) getUAReLogin() *pb.RdsRequestMessageSdkUsrUa {
	actionTime := tools.TimestampEx()
	action := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				Pr: proto.String("-"),
				T:  proto.String(strconv.FormatInt(actionTime, 10)),
			},
		},
		Cn:   proto.String("-"),
		Et:   proto.String("pe"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("0"),
		Type: proto.String("1"),
		T:    proto.String(strconv.FormatInt(actionTime, 10)),
	}

	return &pb.RdsRequestMessageSdkUsrUa{
		Action: []*pb.RdsRequestMessageSdkUsrAction{
			action,
		},
		Num: proto.String("1"),
		T:   proto.String(strconv.FormatInt(actionTime, 10)),
	}
}
func (w *WorkGroup) getUAInputAccount() *pb.RdsRequestMessageSdkUsrUa {
	enter := tools.TimestampEx()
	// 进入账号页面
	actPageEnter := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				Pr: proto.String("-"),
				T:  proto.String(strconv.FormatInt(enter, 10)),
			},
		},
		Cn:   proto.String("-"),
		Et:   proto.String("pe"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("0"),
		Type: proto.String("1"),
		T:    proto.String(strconv.FormatInt(enter, 10)),
	}

	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(500, 1500)))
	startInput := tools.TimestampEx()
	// 账号框获取焦点
	actGetFocus := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				T: proto.String(strconv.FormatInt(startInput, 10)),
				F: proto.Bool(true),
			},
		},
		Cn:   proto.String("UsernameET"),
		Et:   proto.String("fc"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("1"),
		Type: proto.String("0"),
		T:    proto.String(strconv.FormatInt(startInput, 10)),
	}

	// 开始输入账号
	ads := make([]*pb.RdsRequestMessageSdkUsrAD, len(w.acc.AccName))
	for i := 0; i < len(w.acc.AccName); i++ {
		time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(300, 1200)))
		ads[i] = &pb.RdsRequestMessageSdkUsrAD{
			T:   proto.String(strconv.FormatInt(tools.TimestampEx(), 10)),
			Key: proto.String(w.acc.AccName[:i+1]),
		}
	}
	actInput := &pb.RdsRequestMessageSdkUsrAction{
		Ad:   ads,
		Cn:   proto.String("UsernameET"),
		Et:   proto.String("ei"),
		Num:  proto.String(strconv.Itoa(len(w.acc.AccName))),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("2"),
		Type: proto.String("0"),
		T:    proto.String(ads[0].GetT()),
	}

	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(1000, 2000)))
	endInput := tools.TimestampEx()
	// 账号框失去焦点
	actLostFocus := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				T: proto.String(strconv.FormatInt(endInput, 10)),
				F: proto.Bool(false),
			},
		},
		Cn:   proto.String("UsernameET"),
		Et:   proto.String("fc"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("3"),
		Type: proto.String("0"),
		T:    proto.String(strconv.FormatInt(endInput, 10)),
	}

	return &pb.RdsRequestMessageSdkUsrUa{
		Action: []*pb.RdsRequestMessageSdkUsrAction{
			actPageEnter, actGetFocus, actInput, actLostFocus,
		},
		Num: proto.String("4"),
		T:   proto.String(strconv.FormatInt(enter, 10)),
	}
}
func (w *WorkGroup) getUAInputLoginPwd() *pb.RdsRequestMessageSdkUsrUa {
	enter := tools.TimestampEx()
	// 进入输入密码界面
	actPageEnter := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				Pr: proto.String("-"),
				T:  proto.String(strconv.FormatInt(enter, 10)),
			},
		},
		Cn:   proto.String("-"),
		Et:   proto.String("pe"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("0"),
		Type: proto.String("1"),
		T:    proto.String(strconv.FormatInt(enter, 10)),
	}

	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(500, 1500)))
	startInput := tools.TimestampEx()
	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(4000, 8000)))
	endInput := tools.TimestampEx()
	// 密码框获取焦点
	actInput := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				T: proto.String(strconv.FormatInt(startInput, 10)),
				F: proto.Bool(true),
			}, {
				T: proto.String(strconv.FormatInt(endInput, 10)),
				F: proto.Bool(false),
			},
		},
		Cn:   proto.String("PwdET"),
		Et:   proto.String("fc"),
		Num:  proto.String("2"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("1"),
		Type: proto.String("0"),
		T:    proto.String(strconv.FormatInt(startInput, 10)),
	}

	time.Sleep(time.Millisecond * time.Duration(tools.RandBetween(1000, 2000)))
	click := tools.TimestampEx()
	// 点击登陆
	actClickLogin := &pb.RdsRequestMessageSdkUsrAction{
		Ad: []*pb.RdsRequestMessageSdkUsrAD{
			{
				T: proto.String(strconv.FormatInt(click, 10)),
			},
		},
		Cn:   proto.String("LoginBtn"),
		Et:   proto.String("cc"),
		Num:  proto.String("1"),
		Pn:   proto.String("LoginPage"),
		Seq:  proto.String("2"),
		Type: proto.String("0"),
		T:    proto.String(strconv.FormatInt(click, 10)),
	}
	// 输入密码的每个字符并没有进行记录
	return &pb.RdsRequestMessageSdkUsrUa{
		Action: []*pb.RdsRequestMessageSdkUsrAction{
			actPageEnter, actInput, actClickLogin,
		},
		Num: proto.String("3"),
		T:   proto.String(strconv.FormatInt(enter, 10)),
	}
}

func (w *WorkGroup) getID36() string {
	extra, _ := json.Marshal(&map[string]interface{}{
		"appInfo": map[string]interface{}{
			"resign":       0,
			"debug":        0,
			"appleEncrypt": true,
			"personSign":   false,
			"Injectplugs":  false,
			"hook":         0,
			"restict":      false,
			"pie":          true,
			"memoryplug":   "",
			"rebuild":      0,
		},
		"deviceInfo": map[string]interface{}{
			"jbport":      0,
			"Jalibreaktm": 0,
			"emulator":    false,
			"ifaname": []string{
				"awdl0",
				"en0",
				"en1",
				"en2",
				"lo0",
				"pdp_ip0",
				"pdp_ip1",
				"pdp_ip2",
				"pdp_ip3",
				"pdp_ip4",
				"utun0",
			},
			"vpn":   0,
			"uname": tools.Uname(w.acc.Device.SysVer, w.acc.Device.Model),
		},
		"scanInfo": []string{},
	})

	return string(extra)
}

func (w *WorkGroup) getRdsMessage(ua *pb.RdsRequestMessageSdkUsrUa) string {

	// -[APSecRDS getPortalDataPB]
	rds := &pb.RdsRequestMessage{
		Native: &pb.RdsRequestMessageNative{
			Env: &pb.RdsRequestMessageNativeEnv{
				// 模拟器检测
				Em: proto.Bool(false),
				// 注入检测
				Rep: proto.Bool(false),
				// 越狱检测
				Root: proto.Bool(false),
				// md5 -[RDSSecurityCheck getHeaderByte]
				Binaryhash: proto.String("ff50ad4ce1514a6e2323c9745b3a4f11"),
				// 注入的动态库和自身的名称hash
				Repiehash: proto.String(fmt.Sprintf("%x", md5.Sum([]byte(`["AlipayWallet"]`)))),
				// 30 -> 0001 1110
				//  2 -> 0000 0010  -[RDSSecurityCheck checkSecurityHeaderRestrictSection]
				//  4 -> 0000 0100  -[RDSSecurityCheck checkAntiDebugStauts]
				//  8 -> 0000 1000  -[RDSSecurityCheck checkEncryptionStatus]
				//0x10-> 0001 0000  -[RDSSecurityCheck checkPIEStatus]
				Safe: proto.String("30"),
				// 证书重签名的 签名名称
				Sign: proto.String(""),
				// 从文件中获取到签名数据的 md5
				Signhash: proto.String("bf829f22c3ea96446cee9310c2386465"),
				Repie: []string{
					"AlipayWallet",
				},
			},
		},
		Sdk: &pb.RdsRequestMessageSdk{
			Dev: &pb.RdsRequestMessageSdkDev{
				Apdid: proto.String(w.acc.APDID),
				Gss:   proto.String(""),
				Gss2:  proto.String(""),
				H:     proto.String(strconv.Itoa(tools.ScreenHeightPt(w.acc.Device.Model))),
				Idfa:  proto.String(w.acc.Device.IDFA),
				Imei:  proto.String(""),
				Imsi:  proto.String(""),
				Mac:   proto.String(""),
				Px:    proto.String(tools.ScreenPt(w.acc.Device.Model)),
				Sensor: &pb.RdsRequestMessageSdkDevSensor{
					// 输入支付宝账号这段时间的传感器数据变化
					SensorData: &pb.RdsRequestMessageSdkDevSensorSensorData{
						// 加速度计
						Accelerometer: RandSensor([2][3]float32{
							{-0.035, -0.075, -0.98},
							{0.01, 0.01, 0.1},
						}),
						//	[]string{
						//	"-0.035278,-0.078506,-0.983871",
						//	"-0.034683,-0.077072,-0.976654",
						//	"-0.035049,-0.078415,-0.978287",
						//	"-0.035233,-0.078415,-0.979614",
						//},
						// 重力
						Gravity: RandSensor([2][3]float32{
							{-0.04, -0.08, -0.996},
							{0.01, 0.01, 0.001},
						}),
						//	[]string{
						//	"-0.035892,-0.079151,-0.996216",
						//	"-0.035970,-0.079147,-0.996214",
						//	"-0.036194,-0.079726,-0.996160",
						//	"-0.036157,-0.079533,-0.996176",
						//},
						// 陀螺仪
						Gyroscope: RandSensor([2][3]float32{
							{0, 0, -0.01},
							{0.001, 0.002, 0.001},
						}),
						//	[]string{
						//	"0.001018,-0.000986,-0.010657",
						//	"-0.000050,-0.000985,-0.010652",
						//	"-0.000053,0.002226,-0.012768",
						//	"-0.000055,-0.000977,-0.011716",
						//},
						// 磁力计
						Magnetometer: RandSensor([2][3]float32{
							{28.8, 9, -512.5},
							{0.9, 0.9, 0.9},
						}),
						//	[]string{
						//	"28.875641,9.736298,-512.546204",
						//	"29.251541,9.736496,-511.948273",
						//	"29.781174,11.537155,-511.259949",
						//	"29.551727,11.167313,-513.737061",
						//},
					},
					// 进入需要上传rds数据页面的时间
					T: proto.Int64(tools.TimestampEx() + int64(tools.RandBetween(20, 100))),
				},
				Tid:   proto.String(w.acc.TID),
				Umid:  proto.String(w.acc.UMIDToken),
				Usb:   proto.String(""),
				Utdid: proto.String(w.acc.UTDID),
				W:     proto.String(strconv.Itoa(tools.ScreenWidthPt(w.acc.Device.Model))),
				Wi:    proto.String(""),
			},
			Env: &pb.RdsRequestMessageSdkEnv{
				Asdk:         proto.String(""),
				Board:        proto.String(""),
				Brand:        proto.String(""),
				Displayid:    proto.String(""),
				Em:           proto.Bool(false),
				Incremental:  proto.String(""),
				Kerver:       proto.String(""),
				Manufacturer: proto.String(""),
				Model:        proto.String(w.acc.Device.Model),
				Name:         proto.String(strings.ReplaceAll(w.acc.Device.Name, "的 ", "de-")),
				Os:           proto.String("iOS"),
				// CPU Frequency 这个是通过sysctl获取，但ios上这个方法获取不到
				Pf: proto.String(strconv.Itoa(int(tools.CPUFreq()))),
				Pm: proto.String(""),
				// number of cpus iphone7是2+2，但是调用Api只获取到2
				Pn:        proto.String(strconv.Itoa(int(tools.CPUCore(w.acc.Device.Model)))),
				Processor: proto.String(""),
				Qemu:      proto.String(""),
				OsRelease: proto.String(w.acc.Device.SysVer),
				Root:      proto.Bool(false),
				Tags:      proto.String(""),
				Device:    proto.String(""),
			},
			Loc: &pb.RdsRequestMessageSdkLoc{
				Acc:     proto.String(""),
				Active:  proto.Bool(true),
				Bssid:   proto.String(w.acc.Device.WifiMac),
				Carrier: proto.String(tools.CarrierByIMSI(w.acc.Device.IMSI)),
				Cid:     proto.String(""),
				La:      proto.String(""),
				Lac:     proto.String(""),
				Lo:      proto.String(""),
				Mcc:     proto.String(tools.Mcc(w.acc.Device.IMSI)),
				Mnc:     proto.String(tools.Mnc(w.acc.Device.IMSI)),
				Nettype: proto.String("WIFI"),
				Ssid:    proto.String(w.acc.Device.WifiName),
				// 如果能拿到位置信息这里就不是0了
				T: proto.Int64(0),
			},
			Usr: &pb.RdsRequestMessageSdkUsr{
				Appkey:  proto.String(AppKey),
				Appname: proto.String("AlipayWallet"),
				Appver:  proto.String(ProductVersion),
				Pubkey:  proto.String(""),
				Sdkname: proto.String(SdkName),
				Sdkver:  proto.String(SdkVersion),
				Ua:      ua,
				User:    proto.String(w.acc.AccName),
			},
		},
		Taobao: &pb.RdsRequestMessageTaobao{
			Version: proto.String("3.0"),
			Wua:     proto.String(w.acc.Miniwua),
		},
		// +[AntAppInfo securityAppInfo]
		Extra2: proto.String(w.getID36()),
	}

	rdsB, _ := proto.Marshal(rds)
	rdsZipB, _ := tools.GZipCompress(rdsB)

	env, _ := json.Marshal(&map[string]string{
		"version": "4",
		"data":    EncryptAndSign(rdsZipB),
	})

	return string(env)
}
