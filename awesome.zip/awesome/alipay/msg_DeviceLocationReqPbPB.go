package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendDeviceLocation(extInfo []*pb.DeviceLocationExtraInfoPbPB) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.DeviceLocationResPbPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("onDeviceLocationResPbPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("onDeviceLocationResPbPB, resp: \r\n%+v", proto.MarshalTextString(respObj))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcReportDeviceLocation,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.DeviceLocationReqPbPB{
		Apdid:                 proto.String(w.acc.APDID),
		Os:                    proto.String("iOS"),
		VoiceOver:             proto.String("false"),
		Altitude:              proto.Float64(0),
		Speed:                 proto.Float64(0),
		Direction:             proto.Float64(0),
		Longitude:             proto.Float64(0),
		Latitude:              proto.Float64(0),
		Accuracy:              proto.Float64(0),
		WifiConn:              proto.Bool(true),
		LbsOpen:               proto.Bool(false),
		CurrentMobileOperator: proto.String(tools.CarrierByIMSI(w.acc.Device.IMSI)),
		AccessWirelessNetType: proto.String("Wifi"),
		BlueToothOpen:         proto.Bool(false),
		Source:                proto.String(AppKey),
		QueryLbs:              proto.Bool(false),
		OsVersion:             proto.String(w.acc.Device.SysVer),
		ExtraInfos:            extInfo,
	})
}
