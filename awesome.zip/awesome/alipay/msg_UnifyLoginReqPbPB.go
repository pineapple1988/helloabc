package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"fmt"

	"github.com/golang/protobuf/proto"
)

type unifyLoginRes struct {
	AlipayLoginId string            `json:"alipayLoginId"`
	CheckCodeId   string            `json:"checkCodeId"`
	CheckCodeUrl  string            `json:"checkCodeUrl"`
	Code          string            `json:"code"`
	Data          string            `json:"data"`
	ExtMap        map[string]string `json:"extMap"`
	H5Url         string            `json:"h5Url"`
	HeadImg       string            `json:"headImg"`
	Hid           string            `json:"hid"`
	MobileNo      string            `json:"mobileNo"`
	Msg           string            `json:"msg"`
	Scene         string            `json:"scene"`
	SessionId     string            `json:"sessionId"`
	SignData      string            `json:"signData"`
	SsoToken      string            `json:"ssoToken"`
	Success       bool              `json:"success"`
	TaobaoNick    string            `json:"taobaoNick"`
	TaobaoUserId  int               `json:"taobaoUserId"`
	TbLoginId     string            `json:"tbLoginId"`
	Token         string            `json:"token"`
	UserId        string            `json:"userId"`
}

type unifyLoginResData struct {
	BindCard              bool   `json:"bindCard"`
	CurrentProductVersion string `json:"currentProductVersion"`
	CustomerType          string `json:"customerType"`
	ExistNewVersion       string `json:"existNewVersion"`
	ExtResAttrs           struct {
		H5Url                     string `json:"h5Url"`
		MemberGrade               string `json:"memberGrade"`
		ResultCode                string `json:"resultCode"`
		AlipayCnTrustLoginExtInfo string `json:"alipayCnTrustLoginExtInfo"`
		SecurityId                string `json:"securityId"`
		IsNewUser                 string `json:"isNewUser"`
		ShowRegion                string `json:"showRegion"`
		Token                     string `json:"token"`
	} `json:"extResAttrs"`
	ExternToken     string `json:"extern_token"`
	HeadImg         string `json:"headImg"`
	IsCertified     string `json:"isCertified"`
	LoginId         string `json:"loginId"`
	LoginServerTime string `json:"loginServerTime"`
	Memo            string `json:"memo"`
	MobileNo        string `json:"mobileNo"`
	ResultStatus    string `json:"resultStatus"`
	SessionId       string `json:"sessionId"`
	UserId          string `json:"userId"`
	UserName        string `json:"userName"`
	WirelessUser    bool   `json:"wirelessUser"`
}

func (w *WorkGroup) parseLoginRes(code, msg, userId, sessionId, result string) {
	switch code {
	case "1000": // 登录成功
		w.acc.IsLogin = true
		w.acc.UserId = userId
		w.acc.SessionID = sessionId
		// 其实在返回头中已经设置了
		w.acc.Cookies["ALIPAYJSESSIONID"] = sessionId
		w.afterLogin()
	//case 1014: // 请输入账号密码重新登录
	//	// 账号是未登陆状态，需要重新登陆
	//	w.acc.IsLogin = false
	case "6207": // 需要验证
		w.acc.IsLogin = false
		w.acc.UserId = userId
		w.acc.SessionID = sessionId
		resultData := &unifyLoginResData{}
		_ = json.Unmarshal([]byte(result), &resultData)
		go w.toSecurityCore(resultData.ExtResAttrs.H5Url, resultData.ExtResAttrs.Token, resultData.ExtResAttrs.SecurityId)
	default:
		w.acc.IsLogin = false
		log2.Errorf("登陆失败啦！！！==>> [%d:%s]", code, msg)
		w.notifyEvent(EventTypeLogin, LoginCodeOtherError, msg, nil)
	}
}

func (w *WorkGroup) afterLogin() {
	w.sendMobileappcommonClientPGInfoReqPB()
	w.sendSTMessageUserLogin()
	w.sendGetInitArgsReqPB()
	w.sendPushcoreBindUserReqPB()
	w.sendFetchLatestReq()
	w.sendV99()
	w.acc.Save()

	w.notifyEvent(EventTypeLogin, LoginCodeSuccess, "", nil)
}

func (w *WorkGroup) sendUnifyLoginReqPbPB(token, securityId string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.UnifyLoginResPbPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("UnifyLoginResPbPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("UnifyLoginResPbPB, resp: \r\n%+v", proto.MarshalTextString(respObj))
			w.parseLoginRes(respObj.GetCode(), respObj.GetMsg(), respObj.GetUserId(), respObj.GetSessionId(), respObj.GetResultData())
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcUnifyLogin,
		"retryable2":     "0",
		"loginid":        w.acc.AccName,
	}
	// 加密登陆密码
	der, _ := base64.StdEncoding.DecodeString(w.acc.loginRsaPubKey)
	pubKey, _ := x509.ParsePKCS1PublicKey(der)
	if pubKey == nil {
		pubKey = LoginPwdRsaPubKey
	}
	encryptPwd, _ := tools.RSAEncrypt([]byte(w.acc.LoginPwd), LoginPwdRsaPubKey)
	encryptPwdS := base64.StdEncoding.EncodeToString(encryptPwd)
	postion, _ := json.Marshal(&map[string]interface{}{
		"speed":                 0,
		"wifiConn":              "true",
		"extraInfos":            map[string]string{},
		"longitude":             0,
		"lbsOpen":               "false",
		"latitude":              0,
		"voiceOver":             "false",
		"source":                AppKey,
		"os":                    "iOS",
		"currentMobileOperator": tools.CarrierByIMSI(w.acc.Device.IMSI),
		"accuracy":              0,
		"altitude":              0,
		"direction":             0,
		"accessWirelessNetType": "Wifi",
	})

	//edge := []byte{0x3c, 0x00} // 这个表示登陆
	//edge := append(edge, )

	devKeySet := fmt.Sprintf("{\"apdidToken\":\"%s\"}", w.acc.APDIDToken)
	ldf := w.getLocalDevicesFeature()

	externParams, _ := json.Marshal(&map[string]interface{}{
		"apdid":        w.acc.APDID,
		"netType":      "WIFI",
		"terminalName": w.acc.Device.Name,
		"ldf":          ldf,
		"devKeySet": map[string]string{
			"apdidToken": w.acc.APDIDToken,
		},
	})
	protoExternParams := []*pb.AuthLoginTokenExternParamsPB{
		{
			Key:   proto.String("netType"),
			Value: proto.String("WIFI"),
		}, {
			Key:   proto.String("afterLoginSyncConfig"),
			Value: proto.String("{  \"faceStatus\" : \"N\"}"),
		}, {
			Key:   proto.String("ldf"),
			Value: proto.String(ldf),
		}, {
			Key:   proto.String("recommendScene"),
			Value: proto.String("coldLaunch"),
		}, {
			Key:   proto.String("apdidDowngrade"),
			Value: proto.String("N"),
		}, {
			Key:   proto.String("edgeData"),
			Value: proto.String(""),
		}, {
			Key:   proto.String("idfa"),
			Value: proto.String(w.acc.Device.IDFA),
		}, {
			Key:   proto.String("applicationId"),
			Value: proto.String(BundleId),
		}, {
			Key:   proto.String("devKeySet"),
			Value: proto.String(devKeySet),
		},
	}
	validateType := pb.LoginWthPwd_withsndpwd
	alipayEnvJson := ""
	if securityId == "" {
		validateType = pb.LoginWthPwd_withsndpwd
		alipayEnvJson = w.getRdsMessage(w.getUAInputLoginPwd())
	} else {
		validateType = pb.LoginWthPwd_withchecktoken
		protoExternParams = append(protoExternParams, &pb.AuthLoginTokenExternParamsPB{
			Key:   proto.String("securityId"),
			Value: proto.String(securityId),
		})
	}

	w.SendHttpMessage(onResp, headers, &pb.UnifyLoginReqPbPB{
		LoginId:        proto.String(w.acc.AccName),
		AppId:          proto.String("ALIPAY"),
		AppKey:         proto.String(AppKey),
		LoginType:      pb.LoginType_alipay.Enum(),
		ValidateType:   validateType.Enum(),
		Scene:          proto.String(""),
		LoginPwd:       proto.String(encryptPwdS),
		SsoToken:       proto.String(""),
		SignData:       proto.String(""),
		CheckCodeId:    proto.String(""),
		CheckCode:      proto.String(""),
		Apdid:          proto.String(w.acc.APDID),
		Utdid:          proto.String(w.acc.UTDID),
		Tid:            proto.String(w.acc.TID),
		Ttid:           proto.String(""),
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		UmidToken:      proto.String(w.acc.UMIDToken),
		Imsi:           proto.String(w.acc.Device.IMSI),
		Imei:           proto.String(w.acc.Device.IMEI),
		Channel:        proto.String(""),
		ClientType:     proto.String(""),
		UserAgent:      proto.String(""),
		ScreenWidth:    proto.Int32(int32(tools.ScreenWidthPx(w.acc.Device.Model))),
		ScreenHigh:     proto.Int32(int32(tools.ScreenHeightPx(w.acc.Device.Model))),
		MobileBrand:    proto.String("Apple"),
		MobileModel:    proto.String(w.acc.Device.Model),
		AccessPoint:    proto.String(""),
		ClientPostion:  proto.String(string(postion)),
		SystemType:     proto.String("IOS"),
		SystemVersion:  proto.String(w.acc.Device.SysVer),
		WifiMac:        proto.String(w.acc.Device.WifiMac),
		WifiNodeName:   proto.String(w.acc.Device.WifiName),
		LacId:          proto.String(""),
		CellId:         proto.String(""),
		IsPrisonBreak:  proto.String("0"),
		AlipayEnvJson:  proto.String(alipayEnvJson),
		TaobaoEnvJson:  proto.String(""),
		Token:          proto.String(token),
		DeviceId:       proto.String("unknown"),
		AppData: []*pb.AuthLoginTokenExternParamsPB{
			{
				Key:   proto.String("productId"),
				Value: proto.String(ProductId),
			}, {
				Key:   proto.String("mspTid"),
				Value: proto.String(w.acc.TID),
			}, {
				Key:   proto.String("userAgent"),
				Value: proto.String(w.acc.Device.Model),
			}, {
				Key:   proto.String("walletClientKey"),
				Value: proto.String(w.acc.ClientKey),
			}, {
				Key:   proto.String("mspImei"),
				Value: proto.String(w.acc.Device.IMEI),
			}, {
				Key:   proto.String("mac"),
				Value: proto.String(w.acc.Device.BluetoothMac),
			}, {
				Key:   proto.String("walletTid"),
				Value: proto.String(w.acc.TID),
			}, {
				Key:   proto.String("mspImsi"),
				Value: proto.String(w.acc.VIMSI),
			}, {
				Key:   proto.String("mspClientKey"),
				Value: proto.String(w.acc.ClientKey),
			}, {
				Key:   proto.String("vimsi"),
				Value: proto.String(w.acc.VIMSI),
			}, {
				Key:   proto.String("channels"),
				Value: proto.String("apple-iphone"),
			}, {
				Key:   proto.String("clientId"),
				Value: proto.String(fmt.Sprintf("%s|%s", w.acc.Device.IMSI, w.acc.Device.IMEI)),
			}, {
				Key:   proto.String("osVersion"),
				Value: proto.String(w.acc.Device.SysVer),
			}, {
				Key:   proto.String("terminalName"),
				Value: proto.String(w.acc.Device.Name),
			}, {
				Key:   proto.String("productVersion"),
				Value: proto.String(ProductVersion),
			}, {
				Key:   proto.String("vimei"),
				Value: proto.String(w.acc.VIMEI),
			}, {
				Key:   proto.String("externParams"),
				Value: proto.String(string(externParams)),
			},
		},
		ExternParams: protoExternParams,
		SdkVersion:   proto.String(SdkVersion),
	})
}
