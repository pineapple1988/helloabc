package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/base64"
	"fmt"
	"github.com/golang/protobuf/proto"
	"time"
)

type imageInfo struct {
	content string
	key     string
}

func (w *WorkGroup) sendZimValidateRequest(zimId, bisToken, verifyId, token string, scene VerifyScene) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.ZimValidateResponse{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("ZimValidateResponse, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("ZimValidateResponse, resp: \r\n%+v", proto.MarshalTextString(respObj))
			//index += 1
			//w.sendZimValidateRequest(zimId, bisToken, verifyId, token, index)
			if respObj.GetValidationRetCode() == 1000 {
				// 人脸图片验证成功
				w.sendMIMICRpcRequestV2PB("FACEVERIFY", "VERIFY_FACE",
					fmt.Sprintf("{\"zimId\":\"%s\",\"verifyId\":\"%s\",\"useZim\":\"Y\",\"token\":\"%s\"}", zimId, verifyId, token),
					verifyId, token, scene)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcZimVerify,
		"retryable2":     "1",
	}

	// todo 图片信息
	image := &imageInfo{}
	if image == nil {
		log2.Error("ZimValidateRequest 没有人脸数据")
		return
	}
	machineContentData, err := base64.StdEncoding.DecodeString(image.content)
	if err != nil {
		log2.Errorf("image.content base64 DecodeString err: %+v", err)
		return
	}
	machineAesKey, err := base64.StdEncoding.DecodeString(image.key)
	if err != nil {
		log2.Errorf("image.key base64 DecodeString err: %+v", err)
		return
	}
	machineContent := &pb.ToygerUploadContent{}
	_ = proto.Unmarshal(machineContentData, machineContent)

	var blob *pb.ToygerBlobElem
	for _, elem := range machineContent.GetBlob().GetBlobElem() {
		if elem.GetType() == "face" {
			blob = elem
			break
		}
	}
	if blob == nil {
		log2.Error("没找到脸部图片内容")
		return
	}

	imageAesKey := []byte(tools.RandString(16))
	behavAesKey := []byte(tools.RandString(16))

	imageData := tools.AESCBCEncrypt(blob.GetContent(), machineAesKey, FaceImageAesIv)
	contentData, _ := proto.Marshal(&pb.ToygerUploadContent{
		Meta: machineContent.GetMeta(),
		Blob: &pb.ToygerBlob{
			BlobVersion: machineContent.GetBlob().BlobVersion,
			BlobElem: []*pb.ToygerBlobElem{
				{
					Type:      blob.Type,
					SubType:   blob.SubType,
					Idx:       blob.Idx,
					Version:   blob.Version,
					Content:   tools.AESCBCEncrypt(imageData, imageAesKey, FaceImageAesIv),
					FaceInfos: blob.FaceInfos,
					DocInfo:   &pb.ToygerDocInfo{},
				},
			},
		},
	})
	dur := int32(tools.RandBetween(800, 2500))
	time.Sleep(time.Duration(dur) * time.Millisecond)
	behavLogData, _ := proto.Marshal(&pb.BisBehavLog{
		ClientInfo: &pb.BisClientInfo{
			Model:     proto.String(w.acc.Device.Model),
			Os:        proto.String("iOS"),
			OsVer:     proto.String(w.acc.Device.SysVer),
			ClientVer: proto.String("1.0"),
		},
		BehavToken: &pb.BisBehavToken{
			Token:      proto.String(bisToken),
			Type:       proto.Int32(100),
			SampleMode: proto.Int32(0),
			Uid:        proto.String(w.acc.UserId),
			Apdid:      proto.String(""),
			Appid:      proto.String("AP_APP_ALIPAY"),
			Behid:      proto.String(tools.RandString(32)),
			Bizid:      proto.String(""),
			Verifyid:   proto.String(""),
			Vtoken:     proto.String(""),
			ApdidTolen: proto.String(""),
		},
		BehavCommon: &pb.BisBehavCommon{
			Invtp: proto.String("normal"),
			Tm:    proto.String(tools.TimeFmt()),
			Retry: proto.String("0"),
		},
		BehavTask: []*pb.BisBehavTask{
			{
				Name:    proto.String("cherryDetectTask"),
				Idx:     proto.String("0"),
				Dur:     proto.Int32(dur),
				ExtInfo: proto.String(`{"vidcnt":0,"actcnt":0,"EyeLeftOcclussion":0,"sensor":"","EyeRightOcclussion":0}`),
			},
		},
	})
	ctSig, _ := tools.RSAEncrypt(imageAesKey, FaceImageRsaPubKey)
	bhSig, _ := tools.RSAEncrypt(behavAesKey, FaceImageRsaPubKey)
	zimData, _ := proto.Marshal(&pb.APBBisUploadGwRequest{
		BisToken:    proto.String(bisToken),
		Content:     contentData,
		ContentSig:  ctSig,
		BehavLog:    tools.AESCBCEncrypt(behavLogData, behavAesKey, FaceImageAesIv),
		BehavLogSig: bhSig,
	})
	w.SendHttpMessage(onResp, headers, &pb.ZimValidateRequest{
		ZimId:   proto.String(zimId),
		ZimData: zimData,
	})
}
