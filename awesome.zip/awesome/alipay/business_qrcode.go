package alipay

import (
	"awesome/alipay/hpack"
	"awesome/tools/log2"
	"encoding/json"
)

type createSessionReq struct {
	QrCodeUrl      string `json:"qrCodeUrl"`      // 在线使用的二维码，别人付款的时候会收到通知 'xxx 正在付款' 但是协议中生成二维码之后退出了session，所以不要使用这个去收款
	PrintQrCodeUrl string `json:"printQrCodeUrl"` // 离线使用的二维码，点击保存时候的二维码(打印的二维码)
}

type singleVo struct {
	ItemId string `json:"itemId"`
	Link   string `json:"link"`
	Title  string `json:"title"`
}

type listVo struct {
	Title string `json:"title"`
	Type  string `json:"type"`
	Url   string `json:"url"`
}

type imageExt struct {
	ImageTopTitle           string `json:"imageTopTitle"`
	ImageMiddleHiddenName   string `json:"imageMiddleHiddenName"`
	ImageDownDesc           string `json:"imageDownDesc"`
	ImageMiddleMerchantName string `json:"imageMiddleMerchantName"`
}
type createSessionRes struct {
	BusinessMoreVo    singleVo `json:"businessMoreVo"`
	CifTag            bool     `json:"cifTag"`
	CollectRecordPath string   `json:"collectRecordPath"`
	DownList          []listVo `json:"downList"`
	RightList         []listVo `json:"rightList"`
	ExtInfo           imageExt `json:"extInfo"`
	MerchantTag       bool     `json:"merchantTag"`
	Opened            bool     `json:"opened"`
	PushAudio         bool     `json:"pushAudio"`
	PushAudioEnabled  bool     `json:"pushAudioEnabled"`
	PrintQrCodeUrl    string   `json:"printQrCodeUrl"`
	QrCodeUrl         string   `json:"qrCodeUrl"`
	RecordSubTitle    string   `json:"recordSubTitle"`
	SessionId         string   `json:"sessionId"`
	ShowSignEntrance  string   `json:"showSignEntrance"`
	TipUrl            string   `json:"tipUrl"`
	UserTypeForVendor int32    `json:"userTypeForVendor"`
	Success           bool     `json:"success"`
	ResultStatus      int32    `json:"resultStatus"`
}

type quitSessionReq struct {
	SessionId string `json:"sessionId"`
}

type consultSetAmountReq struct {
	Amount    string `json:"Amount"`
	Desc      string `json:"desc"`
	SessionId string `json:"sessionId"`
}

type consultSetAmountRes struct {
	CodeId         string `json:"codeId"`
	PrintQrCodeUrl string `json:"printQrCodeUrl"`
	QrCodeUrl      string `json:"qrCodeUrl"`
	Success        bool   `json:"success"`
	ResultStatus   int32  `json:"resultStatus"`
}

func (w *WorkGroup) sendQrCode(amount, desc string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &createSessionRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendQrCode, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeQRCode, GetQRCodeError, "解释返回数据错误[1]", nil)
		} else {
			log2.Infof("sendQrCode, resp: \r\n%+v.", respObj)

			if w.acc.QrCodeReq == nil {
				w.acc.QrCodeReq = &createSessionReq{}
			}
			// 更新qrcode
			if len(respObj.QrCodeUrl) > 0 {
				w.acc.QrCodeReq.QrCodeUrl = respObj.QrCodeUrl
			}

			if len(respObj.PrintQrCodeUrl) > 0 {
				w.acc.QrCodeReq.PrintQrCodeUrl = respObj.PrintQrCodeUrl
			}

			if len(respObj.SessionId) > 0 {

				if len(amount) > 0 {
					// 需要生成带金额的二维码
					w.sendConsultSetAmount(respObj.SessionId, amount, desc)
				} else {
					// quitSession
					w.sendQuitSession(respObj.SessionId)
				}
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcCreateSession,
		"retryable2":     "0",
	}
	if w.acc.QrCodeReq == nil {
		w.acc.QrCodeReq = &createSessionReq{
			QrCodeUrl:      "",
			PrintQrCodeUrl: "",
		}
	}
	w.SendHttpMessage(onResp, headers, w.acc.QrCodeReq)
}

func (w *WorkGroup) sendQuitSession(sessionId string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &createSessionRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendQuitSession, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeQRCode, GetQRCodeError, "解释返回数据错误[2]", nil)
		} else {
			log2.Infof("sendQuitSession, resp: \r\n%+v.", respObj)
			if w.acc.QrCodeReq == nil {
				w.acc.QrCodeReq = &createSessionReq{}
			}
			// 更新qrcode
			if len(respObj.QrCodeUrl) > 0 {
				w.acc.QrCodeReq.QrCodeUrl = respObj.QrCodeUrl
			}

			if len(respObj.PrintQrCodeUrl) > 0 {
				w.acc.QrCodeReq.PrintQrCodeUrl = respObj.PrintQrCodeUrl
			}

			w.notifyEvent(EventTypeQRCode, GetQRCodeSuccess, "", nil)
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcQuitSession,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &quitSessionReq{
		SessionId: sessionId,
	})
}

func (w *WorkGroup) sendConsultSetAmount(sessionId, amount, desc string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &consultSetAmountRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("sendConsultSetAmount, json.Unmarshal err: %+v", err)
		} else {
			log2.Infof("sendConsultSetAmount, resp: \r\n%+v.", respObj)
		}

		w.sendQuitSession(sessionId)
	}
	headers := map[string]string{
		"Operation-Type": RpcConsultSetAmount,
		"pagets":         "PECollectSettingViewController",
		"retryable2":     "0",
		"lastClickSpm":   "",
		"srcSpm":         "",
	}
	w.SendHttpMessage(onResp, headers, &consultSetAmountReq{
		SessionId: sessionId,
		Amount:    amount,
		Desc:      desc,
	})
}

// GetQRCode 获取转帐二维码
func (w *WorkGroup) GetQRCode(amount, desc string) {
	w.sendQrCode(amount, desc)
}
