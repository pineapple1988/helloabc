package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"github.com/golang/protobuf/proto"
	"strconv"
)

//[APConfigCenter doFetchConfigPB:]
func (w *WorkGroup) sendSwitchInfo() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.SwitchInfoRespPb{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("onSwitchInfo, proto.Unmarshal err: %+v", err)
		} else {
			//log2.Infof("onSwitchInfo, resp: \r\n%+v", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				w.acc.LastSwitchTime, _ = strconv.ParseInt(respObj.GetResponseTime(), 10, 64)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcSwitchInfo,
		"retryable2":     "1",
	}
	w.SendHttpMessage(onResp, headers, &pb.SwitchInfoReqPb{
		ClientVersion:    proto.String(ProductVersion),
		Utdid:            proto.String(w.acc.UTDID),
		UserId:           proto.String(w.acc.UserId),
		Imei:             proto.String(w.acc.Device.IMEI),
		LastResponseTime: proto.String(strconv.FormatInt(w.acc.LastSwitchTime, 10)),
		SystemType:       proto.String("ios"),
		ProductId:        proto.String(ProductId),
		MobileBrand:      proto.String("apple"),
		MobileModel:      proto.String(w.acc.Device.Model),
		OsVersion:        proto.String(w.acc.Device.SysVer),
		Manufacturer:     proto.String("apple"),
	})
}
