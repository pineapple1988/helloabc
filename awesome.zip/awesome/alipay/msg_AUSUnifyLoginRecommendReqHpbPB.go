package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendAUSUnifyLoginRecommendReqHpbPB() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.AUSUnifyLoginRecommendResHpbPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("AUSUnifyLoginRecommendResHpbPB, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("AUSUnifyLoginRecommendResHpbPB, resp: \r\n%+v", proto.MarshalTextString(respObj))
			w.acc.UserId = respObj.GetUserId()

			for _, mode := range respObj.GetAvailableModes() {
				if mode == pb.LoginWthPwd_withsndpwd.String() {
					w.sendUnifyLoginReqPbPB("", "")
					return
				}
			}
			log2.Error("AUSUnifyLoginRecommendResHpbPB 没有密码登陆")

			//switch respObj.GetRecommendMode() {
			//case pb.LoginWthPwd_withsndpwd.String():
			//	w.sendUnifyLoginReqPbPB("", "")
			//case pb.LoginWthPwd_withface.String():
			//	if w.acc.FaceImageCount > 0 {
			//		w.sendInitFaceLoginReqPbPB()
			//	} else {
			//		w.sendUnifyLoginReqPbPB("", "")
			//	}
			//default:
			//	w.sendUnifyLoginReqPbPB("", "")
			//}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcUnifyLoginRecommend,
		"retryable2":     "0",
	}

	envData, _ := json.Marshal(&map[string]string{
		"deviceModel":  w.acc.Device.Model,
		"appVersion":   AppVersion,
		"manufacturer": "Apple",
		"appName":      BundleId,
		"osVersion":    fmt.Sprintf("iOS%s", w.acc.Device.SysVer),
		"viSdkVersion": VIDataVersion,
		"deviceType":   "ios",
		"apdid":        w.acc.APDID,
		"apdidToken":   w.acc.APDIDToken,
		"tid":          w.acc.TID,
		"bp":           getBP(),
	})

	w.SendHttpMessage(onResp, headers, &pb.AUSUnifyLoginRecommendReqHpbPB{
		LoginId:        proto.String(w.acc.AccName),
		EnvJson:        proto.String(w.getRdsMessage(w.getUAReLogin())),
		SecurityId:     proto.String(""),
		Apdid:          proto.String(w.acc.APDID),
		UmidToken:      proto.String(w.acc.UMIDToken),
		Utdid:          proto.String(w.acc.UTDID),
		Tid:            proto.String(w.acc.TID),
		ProductId:      proto.String(ProductId),
		ProductVersion: proto.String(ProductVersion),
		SdkVersion:     proto.String(SdkVersion),
		Channel:        proto.String(""),
		MobileBrand:    proto.String("Apple"),
		MobileModel:    proto.String(w.acc.Device.Model),
		AccessPoint:    proto.String(w.acc.Device.WifiName),
		SystemType:     proto.String("IOS"),
		SystemVersion:  proto.String(w.acc.Device.SysVer),
		WifiMac:        proto.String(w.acc.Device.WifiMac),
		LacId:          proto.String(""),
		CellId:         proto.String(""),
		IsPrisonBreak:  proto.String("0"),
		Imsi:           proto.String(w.acc.Device.IMSI),
		Imei:           proto.String(w.acc.Device.IMEI),
		WifiNodeName:   proto.String(w.acc.Device.WifiName),
		AppName:        proto.String("AlipayWallet"),
		ExtParams: &pb.PBMapStringString{
			Entries: []*pb.PBEntryStringString{
				{
					Key:   proto.String("bp"),
					Value: proto.String(getBP()),
				}, {
					Key:   proto.String("overSeaErrorCod"),
					Value: proto.String("accurate"),
				}, {
					Key:   proto.String("envData"),
					Value: proto.String(string(envData)),
				}, {
					Key:   proto.String("bioMetaInfo"),
					Value: proto.String(w.getBioMetaInfo()),
				}, {
					Key:   proto.String("faceloginAvailable"),
					Value: proto.String("false"),
				}, {
					Key:   proto.String("recommendScene"),
					Value: proto.String("coldLaunch"),
				},
			},
		},
	})
}
