package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools"
	"awesome/tools/log2"
	"crypto/md5"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/golang/protobuf/proto"
)

const (
	// 添加的转账错误
	TransferError_NoPeople           = -10000
	TransferError_NoPeople_Desc      = "没有此支付宝账号"
	TransferError_NotCertified       = -10001
	TransferError_NotCertified_Desc  = "对方账号未实名"
	TransferError_ParseVIData        = -10002
	TransferError_ParseVIData_Desc   = "解析VIData出错"
	TransferError_ParseWND           = -10003
	TransferError_ParseWND_Desc      = "解析WND出错"
	TransferError_PasswordError      = -10004
	TransferError_PasswordError_Desc = "支付密码不正确"
)

type TransferRes struct {
	success    bool
	resultCode int
	resultDesc string
	bizNo      string
}

type TransferReq struct {
	TransferAcc      string           // 对方支付宝账号
	TransferCardNo   string           // 转账卡号
	Amount           string           // 转账金额
	Remark           string           // 转账备注
	RealName         string           // 对方实名
	TransferSpeed    string           // 到账时间 2H/T1
	TradeNo          string           // 生成的转账订单
	OnTransferResult TransferCallback // 转账回掉
	searchResult     *pb.MobileRelationSearchResultVOPB
}

type TransferCallback func(result *TransferRes)

func (w *WorkGroup) TransferTo(req *TransferReq) {
	w.acc.transferReq = req
	w.queryContactInfo(w.acc.transferReq.TransferAcc)
}

func (w *WorkGroup) onTransferFailed(res *TransferRes) {
	// 删除没有成功的订单
	if len(w.acc.transferReq.TradeNo) > 0 {
		w.deleteTradeNo(w.acc.transferReq.TradeNo)
	}
	w.acc.transferReq.OnTransferResult(res)
}

func (w *WorkGroup) queryContactInfo(transferAcc string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MobileRelationSearchContactV2ResultPB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("queryContactInfo, proto.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "查询对方帐号错误", err)
		} else {
			log2.Infof("queryContactInfo, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetSuccess() {
				searchCount := len(respObj.GetSearchResultVOList())
				if searchCount <= 0 {
					w.acc.transferReq.OnTransferResult(&TransferRes{
						success:    false,
						resultCode: TransferError_NoPeople,
						resultDesc: TransferError_NoPeople_Desc,
					})
					w.notifyEvent(EventTypeTransfer, TransferCodeError, TransferError_NoPeople_Desc, nil)
				} else {
					searchResult := respObj.GetSearchResultVOList()[0]
					if searchCount > 1 {
						// 搜索到多个支付宝账号,只找相同的账号转账，这种情况只会出现在使用手机号搜索的情况
						for _, item := range respObj.GetSearchResultVOList() {
							if item.GetUserAccount() == transferAcc {
								searchResult = item
								break
							}
						}
					}
					// 判断是否实名
					if searchResult.GetRealNameStatus() == "Y" {
						w.acc.transferReq.searchResult = searchResult
						// 点击<点此验证>
						w.validateReceiveName1(w.acc.transferReq.searchResult.GetUserId())
					} else {
						w.acc.transferReq.OnTransferResult(&TransferRes{
							success:    false,
							resultCode: TransferError_NotCertified,
							resultDesc: TransferError_NotCertified_Desc,
						})
						w.notifyEvent(EventTypeTransfer, TransferCodeError, TransferError_NotCertified_Desc, nil)
					}
				}

			} else {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: int(respObj.GetResultCode()),
					resultDesc: respObj.GetResultDesc(),
				})

				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.GetResultDesc(), nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcRelationPBFindV2,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.MobileRelationSearchContactReqPB{
		SearchString: proto.String(transferAcc),
		Scheme:       proto.String(""),
	})
}

type validateReceiveNameReq struct {
	OptType      string `json:"optType"`
	ReceiverId   string `json:"receiverId"`
	ReceiverName string `json:"receiverName"`
	UserId       string `json:"userId"`
}

type validateReceiveNameRes struct {
	Success      bool   `json:"success"`
	CanCheckName bool   `json:"canCheckName"`
	Memo         string `json:"memo"`
	ResultStatus int    `json:"resultStatus"`
}

// 实名校验
func (w *WorkGroup) validateReceiveName1(userId string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &validateReceiveNameRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("validateReceiveName1, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "校验对方姓名错误[1]", nil)
		} else {
			log2.Infof("validateReceiveName1, resp %+v", string(resp))
			if respObj.Success && respObj.CanCheckName {
				// 补全对方姓名,点击 <确定>
				w.validateReceiveName2(userId, w.acc.transferReq.RealName)
			} else {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcValidateReceiveName,
		"lastClickSpm":   "",
		"pagets":         fmt.Sprintf("a110.b559__%s_", digits10toMy64(tools.TimestampEx())),
		"srcSpm":         "a110.b557",
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &validateReceiveNameReq{
		OptType:    "1",
		ReceiverId: userId,
	})
}

func (w *WorkGroup) validateReceiveName2(userId, realName string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &validateReceiveNameRes{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("validateReceiveName2, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "校验对方姓名错误[2]", nil)
		} else {
			log2.Infof("validateReceiveName2, resp %+v", string(resp))
			if respObj.Success && respObj.ResultStatus == 100 {
				// 实名认证成功，开始创建订单,点击<确认转账>
				w.createToAccount(
					w.acc.transferReq.TransferAcc,
					w.acc.transferReq.searchResult.GetUserId(),
					w.acc.transferReq.searchResult.GetUserAccount(),
					w.acc.transferReq.searchResult.GetShowName(),
					w.acc.transferReq.Amount,
					w.acc.transferReq.Remark,
					tfToken(),
					0)
			} else {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcValidateReceiveName,
		"lastClickSpm":   "",
		"pagets":         fmt.Sprintf("a110.b559__%s_", digits10toMy64(tools.TimestampEx())),
		"srcSpm":         "a110.b557",
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &validateReceiveNameReq{
		OptType:      "1",
		ReceiverId:   userId,
		ReceiverName: realName,
	})
}

type TFCreateToAccountReq struct {
	PayTool                  string            `json:"payTool"`
	From                     string            `json:"from"`
	HistoryIndex             string            `json:"historyIndex"`
	SecurityId               string            `json:"securityId"`
	Delay                    string            `json:"delay"`
	ConfirmCode              string            `json:"confirmCode"`
	Token                    string            `json:"token"`
	InputReceiverInfo        string            `json:"inputReceiverInfo"`
	VerifyId                 string            `json:"verifyId"`
	SourceId                 string            `json:"sourceId"`
	HasServiceFeeChecked     int32             `json:"hasServiceFeeChecked"`
	UseServiceFeeCheck       int32             `json:"useServiceFeeCheck"`
	ReceiverShowUserName     string            `json:"receiverShowUserName"`
	HasRealNameChecked       int32             `json:"hasRealNameChecked"`
	HasRiskChecked           int32             `json:"hasRiskChecked"`
	UseRiskCheck             int32             `json:"useRiskCheck"`
	MobileMatch              int32             `json:"mobileMatch"`
	ExtPropMap               map[string]string `json:"extPropMap"`
	AppId                    string            `json:"appId"`
	CallerSourceId           string            `json:"callerSourceId"`
	CallerAppId              string            `json:"callerAppId"`
	ForceCheck               int32             `json:"forceCheck"`
	InputRealName            string            `json:"inputRealName"`
	CertifyMobileNo          string            `json:"certifyMobileNo"`
	IngoreReceiveCertificate string            `json:"ingoreReceiveCertificate"`
	EmotionSource            string            `json:"emotionSource"`
	EmotionId                string            `json:"emotionId"`
	WithVoice                int32             `json:"withVoice"`
	Promotion                string            `json:"promotion"`
	TransferAmount           string            `json:"transferAmount"`
	Memo                     string            `json:"memo"`
	TransferMode             string            `json:"transferMode"`
	MobileBindingType        string            `json:"mobileBindingType"`
	Sign                     string            `json:"sign"`
	ReceiverUserId           string            `json:"receiverUserId"`
	ReceiverMobile           string            `json:"receiverMobile"`
	ReceiverAccount          string            `json:"receiverAccount"`
	UserId                   string            `json:"userId"`
}
type TRANSFERMessageCardInfo struct {
	ClientMsgId  string `json:"clientMsgId"`
	BizRemind    string `json:"bizRemind"`
	BizType      string `json:"bizType"`
	BizMemo      string `json:"bizMemo"`
	TemplateCode string `json:"templateCode"`
	TemplateData string `json:"templateData"`
	Link         string `json:"link"`
	Action       string `json:"action"`
}
type TFCreateToAccountResp struct {
	SecurityId        string                  `json:"securityId"`
	VerifyId          string                  `json:"verifyId"`
	ConfirmCode       string                  `json:"confirmCode"`
	ResultH5          string                  `json:"resultH5"`
	MessageCard       TRANSFERMessageCardInfo `json:"messageCard"`
	ToQuickPayCashier bool                    `json:"toQuickPayCashier"`
	RiskLevelMessage  string                  `json:"riskLevelMessage"`
	RiskUrl           string                  `json:"riskUrl"`
	RiskLevel         string                  `json:"riskLevel"`
	PayerGradeAFlag   string                  `json:"payerGradeAFlag"`
	ExtInfo           string                  `json:"extInfo"`
	ReceiverUserId    string                  `json:"receiverUserId"`
	BizSubType        string                  `json:"bizSubType"`
	BizType           string                  `json:"bizType"`
	TradeNo           string                  `json:"tradeNo"`
	Memo              string                  `json:"memo"`
	ResultStatus      int                     `json:"resultStatus"`
}

func (w *WorkGroup) createToAccount(inputReceiver, userId, userAccount, showName, amount, remark, token string, hasRiskChecked int32) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &TFCreateToAccountResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("createToAccount, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "生成转帐订单错误", nil)
		} else {
			log2.Info("createToAccount resp \r\n" + string(resp))
			if respObj.ResultStatus == 3500 && respObj.RiskLevel == "low" {
				// 出现低风险二次验证，直接再次确认
				w.createToAccount(inputReceiver, userId, userAccount, showName, amount, remark, token, 1)

				// 这里应该return掉吧???
				return
			}

			if len(respObj.TradeNo) <= 0 {
				// 创建订单失败，返回支付宝返回的原因
				// 706 -> 对方账户存在安全风险被限制收款
				// 707 -> 收款方当日收款额度已达上限，不能发起本次交易
				// 712 -> 你今天的转账笔数已达上限，请明天再付
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			} else {
				// 这是第二个包
				w.MspLoginCheckV3(respObj.TradeNo, "", "biz_account_transfer")
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcCreateToAccount,
		"lastClickSpm":   "",
		"pagets":         fmt.Sprintf("a110.b559__%s_", digits10toMy64(tools.TimestampEx())),
		"srcSpm":         "a110.b558",
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &TFCreateToAccountReq{
		InputReceiverInfo:    inputReceiver,
		ReceiverAccount:      userAccount,
		ReceiverUserId:       userId,
		TransferMode:         "DA",
		TransferAmount:       amount,
		Memo:                 remark,
		WithVoice:            0,
		ForceCheck:           1,
		MobileMatch:          0,
		UseRiskCheck:         1,
		HasRiskChecked:       hasRiskChecked,
		HasRealNameChecked:   1,
		UseServiceFeeCheck:   1,
		HasServiceFeeChecked: 0,
		SourceId:             "formtransfer",
		ConfirmCode:          "",
		SecurityId:           "",
		PayTool:              "",
		Token:                token,
		ExtPropMap: map[string]string{
			"linkSourceId":   "",
			"callerAppId":    "",
			"callerSourceId": "formtransfer",
		},
	})
}

type loginCheckRespData struct {
	CostTitle        string `json:"costTitle"`
	Product          string `json:"product"`
	Cost             string `json:"cost"`
	HelpQuery        string `json:"helpQuery"`
	HiddenLogonId    string `json:"hidden_logon_id"`
	PayTool          string `json:"payTool"`
	LogonId          string `json:"logon_id"`
	NewAccountSwitch bool   `json:"newAccountSwitch"`
	MicpwdPay        bool   `json:"micpwdPay"`
	Channels         bool   `json:"channels"`
	VIData           string `json:"VIData"`
	Detail           []struct {
		Price string `json:"price"`
		Info  string `json:"info"`
	} `json:"detail"`
	PayRetrieveOnce string `json:"payRetrieveOnce"`
	SpmObj          struct {
		InstId      string `json:"instId"`
		TradeNo     string `json:"tradeNo"`
		BizIdentity string `json:"bizIdentity"`
		ChannelType string `json:"channelType"`
		BizPdCode   string `json:"bizPdCode"`
	} `json:"spmObj"`
	VIPwdTpl string `json:"viPwdTpl"`
}

type viData struct {
	Vid  string `json:"vid"`
	Data string `json:"data"` // viDataData
}
type viDataData struct {
	Data          string `json:"data"` // viDataDataData
	Finish        bool   `json:"finish"`
	NextStep      string `json:"nextStep"`
	Success       bool   `json:"success"`
	Token         string `json:"token"`
	VerifyCode    string `json:"verifyCode"`
	VerifyId      string `json:"verifyId"`
	VerifyMessage string `json:"verifyMessage"`
	VerifySuccess bool   `json:"verifySuccess"`
}

type viDataDataData struct {
	IsFindPPW            bool   `json:"isFindPPW"`
	Forgot2VerifyText    string `json:"forgot2VerifyText"`
	IsSimplePPW          bool   `json:"isSimplePPW"`
	Forgot2Verify        string `json:"forgot2Verify"`
	IsExistPPW           bool   `json:"isExistPPW"`
	Timestamp            string `json:"timestamp"`
	OtherVerifyPaySwitch string `json:"otherVerifyPaySwitch"`
	OtherVerifyPayText   string `json:"otherVerifyPayText"`
}

type viPwdTpl struct {
	Format         string `json:"format"`
	Gray           bool   `json:"gray"`
	NeedRes        bool   `json:"needRes"`
	Platform       string `json:"platform"`
	PublishVersion string `json:"publishVersion"`
	ResInfo        struct {
		Hash string `json:"hash"`
		Url  string `json:"url"`
	} `json:"resInfo"`
	Tag        string `json:"tag"`
	Time       string `json:"time"`
	TplHash    string `json:"tplHash"`
	TplId      string `json:"tplId"`
	TplUrl     string `json:"tplUrl"`
	TplVersion string `json:"tplVersion"`
	UserId     string `json:"userId"`
}

func (w *WorkGroup) getSecData() map[string]string {
	return map[string]string{
		"rt": "0", // 是否越狱
		"ap": "",  // 固定
		"pn": BundleId,
		// bioType#1#2#wearableType#2#1#vendor#6#touchIDStatus!=0x6C#bioType!=4|touchIDStatus!=0x6B#0
		// 1      #1#2#0           #2#1#0     #6#0                  #1                             #0
		"bi": "1#1#2#0#2#1#0#6#0#1#0;",
		"dv": "17",             // 固定
		"ai": "2#2#0#2#1#0#6;", // 固定
		"pm": strings.ReplaceAll(w.acc.Device.Model, ",", "#"),
		// +[AlisecBioAuthenticator getDeviceID]
		"di": w.acc.DeviceID,
	}
}

func (w *WorkGroup) MspLoginCheckV3(tradeNo, fee, bizType string) {
	// 记录一下
	w.acc.transferReq.TradeNo = tradeNo

	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MspResV3PB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("MspLoginCheckV3, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "MspLoginCheckV3错误", nil)
		} else {
			log2.Infof("MspLoginCheckV3, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			// 解析返回参数
			if respObj.GetCode() != "0" {
				code, _ := strconv.Atoi(respObj.GetCode())
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: code,
					resultDesc: respObj.GetErrMsg(),
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.GetErrMsg(), nil)
			} else {
				extInfo := &extInfo{}
				if err := json.Unmarshal([]byte(respObj.GetExtinfo()), extInfo); err == nil {
					// 更新一下
					if len(extInfo.MspSwitch.Ver) > 0 {
						ver, _ := strconv.Atoi(extInfo.MspSwitch.Ver)
						if ver > 0 {
							w.acc.MspSwitchVer = extInfo.MspSwitch.Ver
						}
					}
				}

				w.sendDeviceLocation([]*pb.DeviceLocationExtraInfoPbPB{
					{
						Key:   proto.String("viewId"),
						Value: proto.String("MQPBNDocument"),
					},
				})
				// 点击 <立即付款> 输入密码
				mspParam := ""
				for _, header := range headers {
					if header.Name == "Msp-Param" {
						mspParam = header.Value
						break
					}
				}

				respData := &loginCheckRespData{}
				if err = json.Unmarshal([]byte(respObj.GetData()), respData); err == nil {
					if len(respData.VIData) > 0 {
						VIData := &viData{}
						if err = json.Unmarshal([]byte(respData.VIData), VIData); err == nil {
							verifyId := VIData.Vid
							if len(VIData.Data) > 0 && len(verifyId) > 0 {
								VIDataData := &viDataData{}
								viDataDataB, _ := base64.StdEncoding.DecodeString(VIData.Data)
								if err = json.Unmarshal(viDataDataB, VIDataData); err == nil {
									token := VIDataData.Token
									if VIDataData.Success && VIDataData.NextStep == "NATIVE_PAYMENT_PASSWORD" && len(token) > 0 {
										// 获取返回时间戳
										VIDataDataData := &viDataDataData{}
										if err = json.Unmarshal([]byte(VIDataData.Data), VIDataDataData); err == nil {
											if len(VIDataDataData.Timestamp) > 0 {
												w.Pay(mspParam, respObj.GetSession(), verifyId, token, VIDataDataData.Timestamp, VIDataDataData.IsSimplePPW)
												return
											}
										}
									}
								}
							}
						}
					}
				}
				w.onTransferFailed(&TransferRes{
					success:    false,
					resultCode: TransferError_ParseVIData,
					resultDesc: TransferError_ParseVIData_Desc,
				})

				w.notifyEvent(EventTypeTransfer, TransferCodeError, TransferError_ParseVIData_Desc, nil)
			}
		}
	}
	order := ""
	if bizType == "biz_account_transfer" {
		order = fmt.Sprintf(`trade_no="%s"&app_name="alipay"&biz_type="biz_account_transfer"&display_pay_result="false"&source_id="formtransfer"`, tradeNo)
	} else {
		order = fmt.Sprintf(`trade_no="%s"&app_name="alipay"&biz_type="biz_card_transfer"&display_pay_result="false"&service_fee="%s"`, tradeNo, fee)
	}

	// TODO 加入EdgeRiskData
	uv, _ := proto.Marshal(&pb.UploadedVariablesPB{
		Version:      proto.Int32(3),
		RtFund1D1Mth: proto.Int32(int32(tools.RandBetween(4, 15))),
		D1DCntHome:   proto.Int32(int32(tools.RandBetween(500, 1000))),
		RtTalk1D1Mth: proto.Int32(0),
		D1DCntFriend: proto.Int32(0),
	})
	traceId := fmt.Sprintf("A%x", md5.Sum([]byte(strconv.FormatInt(tools.TimestampEx(), 10))))

	viData, _ := json.Marshal(&map[string]interface{}{
		"dm":      w.acc.Device.Model,
		"secData": w.getSecData(),
		// 是否支持指纹支付
		"sfp": true,
		"tid": w.acc.TID,
		"viv": VIDataVersion,
		// 这个是和生物识别算法相关的一个东西
		"bmi": w.getBioMetaInfo(),
	})

	extInfo, _ := json.Marshal(&map[string]string{
		"lang":           "zh-Hans",
		"VIData":         string(viData),
		"msp_switch_ver": w.acc.MspSwitchVer,
	})

	// -[MQPRequestModel pbv3Header]
	headers := map[string]string{
		"Operation-Type": RpcMspLoginCheckV3,
		"retryable2":     "1",
		"Msp-Param":      fmt.Sprintf("trade_no=%s;biz_type=%s", tradeNo, bizType),
		"mqp-apiver":     MqpAPIVersion,
		// +[_MQPUtilInfo bnParams]
		"mqp-bp":  getBPEx(),
		"mqp-pa":  fmt.Sprintf("(%s;%s)", BundleId, ProductVersion),
		"mqp-tid": w.acc.TID,
		// -[MPDeviceInfo uaWithNetType:]
		"mqp-ua": fmt.Sprintf("%s(i %s;1;(a);;;(b);wifi;%s;0;;(c))(1)(%s)",
			MqpSdkVersion, w.acc.Device.SysVer, w.acc.Device.BluetoothMac, w.acc.APDIDToken),
		"utdid": w.acc.APDID,
	}
	w.SendHttpMessage(onResp, headers, &pb.MspReqV3PB{
		ApiNsp: proto.String("0"),
		ApiNm:  proto.String("0"),
		Action: proto.String("/cashier/main"),
		// [ImmersionPayService payWithAction:andOrder:]
		Synch: proto.String(strconv.FormatUint(tools.CFStringHash(fmt.Sprintf("%s%s", order, tools.TimeFmtEx1())), 10)),
		// [APKcartService extract]
		Decay:        proto.String(base64.StdEncoding.EncodeToString(uv)),
		ExternalInfo: proto.String(order),
		Trid:         proto.String(traceId),
		Trdfrom:      proto.Int32(1),
		PbHasAlipay:  proto.Int32(1),
		Subua1:       proto.String(w.acc.ClientKey),
		Subua2:       proto.String(fmt.Sprintf("%s;%s", w.acc.VIMEI, w.acc.VIMSI)),
		Subua3:       proto.String(w.acc.Device.Name),
		Extinfo:      proto.String(string(extInfo)),
	})
}

type wnd struct {
	Act struct {
		Neec   string `json:"neec"`
		Name   string `json:"name"`
		Params struct {
			ConfirmAct map[string]interface{} `json:"confirmAct"`
			VIData     string                 `json:"VIData"` //viDataData
		} `json:"params"`
		SyncMutex bool `json:"syncMutex"`
	} `json:"act"`
	Time int    `json:"time"`
	Type string `json:"type"`
}

func (w *WorkGroup) Pay(mspParam, session, verifyId, token, timestamp string, isSimplePPW bool) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MspResV3PB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("Pay, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "确认支付错误", nil)
		} else {
			log2.Infof("Pay, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetCode() != "0" {
				code, _ := strconv.Atoi(respObj.GetCode())
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: code,
					resultDesc: respObj.GetErrMsg(),
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.GetErrMsg(), nil)
			} else {
				mspParam := ""
				for _, header := range headers {
					if header.Name == "Msp-Param" {
						mspParam = header.Value
						break
					}
				}

				WND := &wnd{}
				if err = json.Unmarshal([]byte(respObj.GetWnd()), WND); err == nil {
					if WND.Act.Name == "/cashier/payResultQuery" {
						// 开始轮训,查询转账结果
						time.Sleep(time.Second * 1)
						w.PayResultQuery(mspParam, respObj.GetSession())
						return
					} else if len(WND.Act.Params.VIData) > 0 {
						// 开始判断是不是密码错误了
						VIDataData := &viDataData{}
						_ = json.Unmarshal([]byte(WND.Act.Params.VIData), VIDataData)
						if !VIDataData.VerifySuccess && strings.Contains(VIDataData.VerifyMessage, "支付密码不正确") {
							w.onTransferFailed(&TransferRes{
								success:    false,
								resultCode: TransferError_PasswordError,
								resultDesc: TransferError_PasswordError_Desc,
							})
							return
						}
					}
				}
				// 这个地方为什么不去删掉订单呢？害怕是解析错误，其实是成功的，删掉订单可能就没有
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: TransferError_ParseWND,
					resultDesc: TransferError_ParseWND_Desc,
				})

				w.notifyEvent(EventTypeTransfer, TransferCodeError, TransferError_ParseWND_Desc, nil)
			}
		}
	}
	// 密码加密
	encryptPwd, _ := tools.RSAEncrypt([]byte(w.acc.PayPwd+timestamp), PayPwdRsaPubKey)
	data, _ := json.Marshal(&map[string]string{
		"encryptPwd": base64.StdEncoding.EncodeToString(encryptPwd),
		// 个人账号这个地方是true，企业账号可能会有不同
		"isSimplePPW": strconv.FormatBool(isSimplePPW),
	})

	viData, _ := json.Marshal(&map[string]string{
		"version":  VIDataVersion,
		"data":     string(data),
		"verifyId": verifyId,
		"module":   "NATIVE_PAYMENT_PASSWORD",
		"token":    token,
		"action":   "VERIFY_PPW",
	})

	extInfo, _ := json.Marshal(&map[string]string{
		"VIData": string(viData),
	})

	headers := map[string]string{
		"Operation-Type": RpcDispatchV3,
		"retryable2":     "1",
		"Msp-Param":      mspParam,
		"mqp-apiver":     MqpAPIVersion,
		"mqp-bp":         getBPEx(),
		"mqp-tid":        w.acc.TID,
		"mqp-uac":        base64.StdEncoding.EncodeToString([]byte(fmt.Sprintf("zh_CN;;;;;%s;%s", w.acc.Device.WifiName, w.acc.Device.WifiMac))),
	}
	w.SendHttpMessage(onResp, headers, &pb.MspReqV3PB{
		ApiNsp:  proto.String("0"),
		ApiNm:   proto.String("0"),
		Action:  proto.String("/cashier/pay"),
		Session: proto.String(session),
		Extinfo: proto.String(string(extInfo)),
	})
}

func (w *WorkGroup) PayResultQuery(mspParam, session string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MspResV3PB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("PayResultQuery, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "查询支付结果错误", nil)
		} else {
			log2.Infof("PayResultQuery, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetCode() != "0" {
				code, _ := strconv.Atoi(respObj.GetCode())
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: code,
					resultDesc: respObj.GetErrMsg(),
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.GetErrMsg(), nil)
			} else if respObj.GetEndCode() == "9000" {
				// 转账成功
				result := respObj.GetResult()
				result, _ = url.QueryUnescape(result)
				values, _ := url.ParseQuery(result)
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    true,
					resultCode: 9000,
					resultDesc: "转账成功",
					bizNo:      strings.ReplaceAll(values["trade_no"][0], "\"", ""),
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeSuccess, strings.ReplaceAll(values["trade_no"][0], "\"", ""), proto.MarshalTextString(respObj))
			} else if len(respObj.GetEndCode()) <= 0 {
				// 没有endCode，说明没有结束，继续解析wnd，可能会出现问题
				mspParam := ""
				for _, header := range headers {
					if header.Name == "Msp-Param" {
						mspParam = header.Value
						break
					}
				}
				WND := &wnd{}
				if err = json.Unmarshal([]byte(respObj.GetWnd()), WND); err == nil {
					if WND.Act.Name == "/cashier/payResultQuery" {
						time.Sleep(time.Second * 1)
						w.PayResultQuery(mspParam, respObj.GetSession())
						return
					}
				}
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: TransferError_ParseWND,
					resultDesc: TransferError_ParseWND_Desc,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, TransferError_ParseWND_Desc, nil)
			} else {
				// 来到这里是说明有不同的endCode来了
				code, _ := strconv.Atoi(respObj.GetEndCode())
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: code,
					resultDesc: respObj.GetMemo(),
				})

				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.GetMemo(), nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcDispatchV3,
		"retryable2":     "1",
		"Msp-Param":      mspParam,
		"mqp-apiver":     MqpAPIVersion,
		"mqp-bp":         getBPEx(),
		"mqp-tid":        w.acc.TID,
	}
	w.SendHttpMessage(onResp, headers, &pb.MspReqV3PB{
		ApiNsp:  proto.String("0"),
		ApiNm:   proto.String("0"),
		Action:  proto.String("/cashier/payResultQuery"),
		Session: proto.String(session),
		Extinfo: proto.String("{}"),
	})
}

type DeleteToCardReq struct {
	Source     string `json:"source"`
	TransferNo string `json:"transferNo"`
	UserId     string `json:"userId"`
}

type DeleteToCardResp struct {
	Memo         string `json:"memo"`
	ResultStatus int    `json:"resultStatus"`
}

// 转账失败需要去删掉这个订单号
func (w *WorkGroup) deleteTradeNo(tradeNo string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &DeleteToCardResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("DeleteToCardResp, json.Unmarshal err: %+v", err)
		} else {
			log2.Infof("DeleteToCardResp, resp %+v", string(resp))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcDelete,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &DeleteToCardReq{
		TransferNo: tradeNo,
	})
}
