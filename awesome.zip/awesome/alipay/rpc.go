package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/mynet"
	"awesome/tools/log2"
	"crypto/md5"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strconv"
	"sync/atomic"
)

const (
	RpcGetRsaKey                  = "alipay.client.getRSAKey"
	RpcGetRsaKey2                 = "alipay.client.getRSAKey.v2"
	RpcReportActive               = "alipay.client.reportActive.pb"
	RpcSwitchInfo                 = "alipay.client.switches.all.get.afterloginPb"
	RpcReportDeviceLocation       = "alipay.alideviceinfo.reportDeviceLocation.pb"
	RpcUserLogin                  = "alipay.user.login.pb"
	RpcUnifyLoginRecommend        = "ali.user.gw.unifyLogin.recommend"
	RpcFetchLatest                = "alipay.contentfusion.zhome.pb.fetchIndexLatest"
	RpcCreateSession              = "alipay.transferprod.collect.singlemoney.createSession"
	RpcQuitSession                = "alipay.transferprod.collect.singlemoney.quitSession"
	RpcConsultSetAmount           = "alipay.transferprod.collect.singlemoney.consultSetAmount"
	RpcQueryWealthHomeInfoV996    = "alipay.wealth.home.queryWealthHomeInfoV996"
	RpcGetTranList                = "alipay.mobile.bill.getTransList"
	RpcQueryBillListPB            = "alipay.mobile.bill.queryBillListPB"
	RpcQuerySingleBillDetailForH5 = "alipay.mobile.bill.QuerySingleBillDetailForH5"
	RpcRelationPBFindV2           = "alipay.mobile.relation.pb.findV2"
	RpcValidateReceiveName        = "alipay.mobile.contact.validatereceivename"
	RpcCreateToAccount            = "alipay.mobile.transfer.createToAccount"
	RpcMspLoginCheckV3            = "alipay.msp.cashier.dispatch.logincheck.v3"
	RpcDispatchV3                 = "alipay.msp.cashier.dispatch.pb.v3"
	RpcUnifyLogin                 = "ali.user.gw.unifyLogin.hpb"
	RpcGetInitArgs                = "alipay.livetradeprod.soundWave.getInitArgs.pb"
	RpcPGInfo                     = "alipay.mobileappcommon.pg.pgPGInfo"
	RpcIosBind                    = "alipay.pushcore.device.iosbind"
	RpcUnionResource              = "alipay.client.getUnionResource"
	RpcABTestConfig               = "ant.abtest.configlite"
	RpcDeviceReport               = "alipay.security.device.data.report.pb.ios.v7"
	RpcCheckCardBin               = "alipay.mobile.transfer.checkCardBin"
	RpcQueryBankInfo              = "alipay.mobile.transfer.queryBankInfo"
	RpcValidateReceiveCard        = "alipay.mobile.transfer.validateReceiveCard"
	RpcCreateToCard               = "alipay.mobile.transfer.createToCard"
	RpcDelete                     = "alipay.mobile.transfer.deleteToCard"
	RpcInitFaceLoginV2            = "ali.user.gw.initFaceLoginV2.hpb"
	RpcZimVerify                  = "com.zoloz.zhub.zim.verify.pb"
	RpcDispatchV2                 = "alipay.mobile.ic.dispatch.pb.v2"
)

func (w *WorkGroup) writeField(name, value string) {
	field := hpack.HeaderField{
		Name:  name,
		Value: value,
	}
	if err := w.hpackEncoder.WriteField(field); err != nil {
		log2.Errorf("[WorkGroup]HPACK编码错误, 错误: %+v, key: %+v, value: %+v.", err, name, value)
	}
}

func (w *WorkGroup) Http2Headers(headers map[string]string) []byte {
	w.hpackLock.Lock()
	defer w.hpackLock.Unlock()

	w.encodeBuffer.Reset()
	for name, value := range headers {
		w.writeField(name, value)
	}

	// 写入一些公共头
	w.writeField("Accept-Language", "zh-Hans")
	w.writeField("AppId", ProductId)
	// cookie

	cookies := mynet.RawCookies(w.acc.Cookies)
	if len(cookies) >= 0 {
		w.writeField("Cookie", cookies)
	}
	w.writeField("Did", w.acc.UTDID)
	w.writeField("Version", "2")
	w.writeField("clientVersion", ProductVersion)

	miniWua := ""
	if w.acc.Miniwua != "" {
		miniWuaB, err := json.Marshal(&map[string]string{"w": w.acc.Miniwua})
		if err != nil {
			log2.Errorf("[WorkGroup]MiniWua序列化错误: %+v", err)
		} else {
			miniWua = string(miniWuaB)
		}
	}
	w.writeField("miniwua", miniWua)
	w.writeField("scene", "active")
	w.writeField("visibleflag", "1")
	return w.encodeBuffer.Bytes()
}

func (w *WorkGroup) RpcId() string {
	rpc := atomic.AddUint64(&w.rpcId, 1)
	return strconv.FormatUint(rpc, 10)
}

func (w *WorkGroup) Sign(op string, body []byte, ts string) string {
	reqData := ""
	if body != nil && len(body) > 0 {
		reqData = base64.StdEncoding.EncodeToString(body)
	}

	param := fmt.Sprintf("%+v&Operation-Type=%+v&Request-Data=%+v&Ts=%+v",
		SignSalt, op, reqData, ts)

	return fmt.Sprintf("%x", md5.Sum([]byte(param)))
}
