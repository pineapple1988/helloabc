package manager

import (
	"awesome/tools"
	"awesome/tools/log2"
	"encoding/json"
	"io/ioutil"
	"sync"
)

const (
	alipaySyncInfoKey = "AlipaySyncInfo"
)

type syncNode struct {
	Type    string `json:"type"`
	Biz     string `json:"biz"`
	Enum    string `json:"enum"`
	Cmd     string `json:"cmd"`
	UpsKey  string `json:"upskey"`
	SyncKey int64  `json:"synckey"`
}

type syncInfo struct {
	APUplinkConfigs []*syncNode `json:"APUplinkConfigs"`
	APSyncConfigs   []*syncNode `json:"APSyncConfigs"`
	APBucketConfigs []*syncNode `json:"APBucketConfigs"`
}

type syncInfos struct {
	list map[string]*syncInfo
	lock sync.RWMutex
}

var infos *syncInfos

func init() {
	infos = &syncInfos{
		list: make(map[string]*syncInfo, 0),
	}
}

func LoadSyncInfo(acc string) {
	var info syncInfo

	file := "./alipay/bin/SyncInfo_" + acc + ".json"
	if !tools.FileExist(file) {
		file = "./alipay/bin/syncInfo.json"
	}

	tools.LoadJSONFromFile(file, &info)

	// 处理cmd
	for i := range info.APUplinkConfigs {
		if len(info.APUplinkConfigs[i].Cmd) == 0 {
			info.APUplinkConfigs[i].Cmd = "1"
		}
	}
	for i := range info.APSyncConfigs {
		if len(info.APSyncConfigs[i].Cmd) == 0 {
			info.APSyncConfigs[i].Cmd = "1"
		}
	}
	for i := range info.APBucketConfigs {
		if len(info.APBucketConfigs[i].Cmd) == 0 {
			info.APBucketConfigs[i].Cmd = "1"
		}
	}

	infos.list[acc] = &info
}

func SaveSyncInfo(acc string) {
	info, exist := infos.list[acc]
	if exist {
		// 保存动作
		infoBytes, err := json.MarshalIndent(info, "", "\t")
		if err != nil {
			log2.Errorf("syncInfo SaveSyncInfo json.MarshalIndent err %+v.", err)
		}

		file := "./alipay/bin/SyncInfo_" + acc + ".json"
		err = ioutil.WriteFile(file, infoBytes, 0644)
		if err != nil {
			log2.Errorf("syncInfo SaveSyncInfo ioutil.WriteFile err %+v.", err)
		}
	} else {
		log2.Error("syncInfo SaveSyncInfo info not found")
	}
}

func GetSyncInfo(acc string) *syncInfo {
	info, exist := infos.list[acc]
	if exist {
		return info
	} else {
		return nil
	}
}

func (s *syncInfo) FindSyncKeyInfoWithName(name string) *syncNode {
	for _, item := range s.APSyncConfigs {
		if item.Biz == name {
			return item
		}
	}

	for _, item := range s.APBucketConfigs {
		if item.Biz == name {
			return item
		}
	}

	return nil
}
