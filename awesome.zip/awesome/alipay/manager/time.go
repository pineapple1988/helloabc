package manager

import (
	"github.com/robfig/cron/v3"
	"log"
	"os"
)

var (
	serviceCron *cron.Cron
)

func Start() {
	serviceCron = cron.New(
		cron.WithLogger(cron.VerbosePrintfLogger(log.New(os.Stdout, "[CRON ] - ", log.LstdFlags|log.Lmicroseconds))),
		cron.WithSeconds())

	serviceCron.Start()
}


func AddJob(spec string, cmd cron.Job)(cron.EntryID, error) {
	return serviceCron.AddJob(spec, cmd)
}

func Remove(id cron.EntryID) {
	 serviceCron.Remove(id)
}

func Stop() {
	serviceCron.Stop()
}