package alipay

import (
	"encoding/json"
	"fmt"
	"net/url"
	"strings"
	"testing"
)

func TestCreateToAccount(t *testing.T) {
	s := "{\"act\":{\"name\":\"loc:bncb\",\"params\":{\"confirmAct\":{},\"VIData\":\"{\\\"data\\\":\\\"{\\\\\\\"otherVerifyPaySwitch\\\\\\\":\\\\\\\"Y\\\\\\\",\\\\\\\"otherVerifyPayText\\\\\\\":\\\\\\\"\346\211\276\345\233\236\345\271\266\345\256\214\346\210\220\346\224\257\344\273\230\\\\\\\"}\\\",\\\"finish\\\":false,\\\"nextStep\\\":\\\"NATIVE_PAYMENT_PASSWORD\\\",\\\"success\\\":true,\\\"token\\\":\\\"8c7d839c53baaae207e5d73b069fd7b052RZ12B\\\",\\\"verifyCode\\\":\\\"RETRY\\\",\\\"verifyId\\\":\\\"componentVerify_5c5123567a037efc484568e7eb279c9d52RZ12B_mobile_cashier_payment_N_1\\\",\\\"verifyMessage\\\":\\\"\346\224\257\344\273\230\345\257\206\347\240\201\344\270\215\346\255\243\347\241\256\343\200\202\\\",\\\"verifySuccess\\\":false}\"}},\"time\":0,\"type\":\"tst\"}"
	WND := &wnd{}
	_ = json.Unmarshal([]byte(s), WND)
	VIDataData := &viDataData{}
	_ = json.Unmarshal([]byte(WND.Act.Params.VIData), VIDataData)
	//fmt.Println(WND)
	//fmt.Println(VIDataData)
	if !VIDataData.VerifySuccess && strings.Contains(VIDataData.VerifyMessage, "支付密码不正确") {
		fmt.Println(VIDataData.VerifyMessage)
	}
}

func TestParseResult(t *testing.T) {
	raw, _ := url.QueryUnescape("trade%5Fno%3D%2220191005200040011100750060481908%22%26app%5Fname%3D%22alipay%22%26biz%5Ftype%3D%22biz%5Faccount%5Ftransfer%22%26display%5Fpay%5Fresult%3D%22false%22%26source%5Fid%3D%22formtransfer%22%26success%3D%22true%22")
	values, _ := url.ParseQuery(raw)
	fmt.Println(strings.ReplaceAll(values["trade_no"][0], "\"", ""))
}