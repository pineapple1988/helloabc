package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"strconv"
)

type extInfo struct {
	MspSwitch struct {
		Ver     string `json:"ver"`
		Content struct {
			EnableMqpuserdefaultSourcenowrite string `json:"enable_mqpuserdefault_sourcenowrite"`
			CheckResultDataDegrade            string `json:"checkResultDataDegrade"`
			GrayLogMdapSpm                    string `json:"gray_log_mdap_spm"`
			GrayPrerenderResultpageWebview    string `json:"gray_prerender_resultpage_webview"`
			GrayAsyncLocationGet              string `json:"gray_async_location_get"`
			GrayFeedbackByGuess               struct {
				CashierChannelLogoFlex string `json:"cashier-channel-logo-flex"`
			} `json:"gray_feedback_by_guess"`
			GrayLogMdapMqp string `json:"gray_log_mdap_mqp"`
			PrerenderTpl   struct {
				CashierPayConfirmFlex       string `json:"cashier-pay-confirm-flex"`
				FrontpayChannelLogoFlexHtml string `json:"frontpay-channel-logo-flex.html"`
				FrontpayLimitQueryFlexHtml  string `json:"frontpay-limit-query-flex.html"`
				CashierResultFlex           string `json:"cashier-result-flex"`
			} `json:"prerenderTpl"`
			GrayNativeToDyapi string `json:"gray_native_to_dyapi"`
			GrayDynamicApi    struct {
				Openurl          string `json:"openurl"`
				Exit             string `json:"exit"`
				PostNotification string `json:"postNotification"`
			} `json:"gray_dynamic_api"`
		} `json:"content"`
	} `json:"msp_switch"`
}

func (w *WorkGroup) sendMspReqV3PBGenTid() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.MspResV3PB{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("MspReqV3PBGenTid, proto.Unmarshal err: %+v", err)
		} else {
			log2.Infof("MspReqV3PBGenTid, resp: \r\n%+v.", proto.MarshalTextString(respObj))
			if respObj.GetCode() != "0" {
				log2.Error("MspReqV3PBGenTid error!!")
			} else {
				w.acc.TID = respObj.GetTid()
				// 这个一般没看见会改变
				w.acc.ClientKey = respObj.GetClientKey()

				extInfo := &extInfo{}
				if err := json.Unmarshal([]byte(respObj.GetExtinfo()), extInfo); err == nil {
					// 更新一下
					if len(extInfo.MspSwitch.Ver) > 0 {
						ver, _ := strconv.Atoi(extInfo.MspSwitch.Ver)
						if ver > 0 {
							w.acc.MspSwitchVer = extInfo.MspSwitch.Ver
						}
					}
				}
			}
		}
	}
	var ua string
	if len(w.acc.APDIDToken) <= 0 {
		ua = fmt.Sprintf("%s(i %s;1;(a);;;(b);wifi;%s;0;;(c))",
			MqpSdkVersion, w.acc.Device.SysVer, w.acc.Device.BluetoothMac)
	} else {
		ua = fmt.Sprintf("%s(i %s;1;(a);;;(b);wifi;%s;0;;(c))(1)(%s)",
			MqpSdkVersion, w.acc.Device.SysVer, w.acc.Device.BluetoothMac, w.acc.APDIDToken)
	}
	headers := map[string]string{
		"Operation-Type": RpcDispatchV3,
		"retryable2":     "1",
		"mqp-apiver":     MqpAPIVersion,
		"mqp-pa":         fmt.Sprintf("(%s;%s)", BundleId, ProductVersion),
		"mqp-ua":         ua,
		"utdid":          w.acc.UTDID,
	}
	w.SendHttpMessage(onResp, headers, &pb.MspReqV3PB{
		ApiNsp:      proto.String("0"),
		ApiNm:       proto.String("0"),
		Action:      proto.String("/cashier/gentid"),
		PbHasAlipay: proto.Int32(1),
		Subua1:      proto.String(w.acc.ClientKey),
		Subua2:      proto.String(fmt.Sprintf("%s;%s", w.acc.VIMEI, w.acc.VIMSI)),
		Subua3:      proto.String(fmt.Sprintf("%s)(2)zh_CN;;;;;%s;%s", w.acc.Device.Name, w.acc.Device.WifiName, w.acc.Device.WifiMac)),
		Extinfo:     proto.String(fmt.Sprintf("{\"msp_switch_ver\":\"%s\"}", w.acc.MspSwitchVer)),
	})
}
