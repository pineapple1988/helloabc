package alipay

import (
	"awesome/alipay/hpack"
	"awesome/tools/log2"
	"encoding/json"
	"fmt"
	"math"
	"strconv"
)

type CheckCardBinReq struct {
	CardNo string `json:"cardNo"`
	UserId string `json:"userId"`
}
type CheckCardBinResp struct {
	BankName      string `json:"bankName"`
	BankShortName string `json:"bankShortName"`
	CardType      string `json:"cardType"`
	GuideFlag     bool   `json:"guideFlag"`
	ResultStatus  int    `json:"resultStatus"`
	Memo          string `json:"memo"`
}
type QueryBankInfoReq struct {
	ReceiverName       string `json:"receiverName"`
	CardNoHidden       int    `json:"cardNoHidden"`
	CardChannel        string `json:"cardChannel"`
	CardIndex          string `json:"cardIndex"`
	CardNo             string `json:"cardNo"`
	NeedReceiveTimeOpt string `json:"needReceiveTimeOpt"`
	BankShortName      string `json:"bankShortName"`
	UserId             string `json:"userId"`
}
type ReceiveTimeOpt struct {
	ConfirmPageMemo  string `json:"confirmPageMemo"`
	ActiveUrl        string `json:"activeUrl"`
	StatusCode       string `json:"statusCode"`
	MemberPoints     string `json:"memberPoints"`
	HighLightMemo    int    `json:"highLightMemo"`
	Memo             string `json:"memo"`
	TransferSpeedDes string `json:"transferSpeedDes"`
	TransferSpeed    string `json:"transferSpeed"`
	Enable           int    `json:"enable"`
}
type QueryBankInfoResp struct {
	RealTimeReceiveTimeOpt ReceiveTimeOpt   `json:"realTimeReceiveTimeOpt"`
	DefaultReceiveTimeOpt  ReceiveTimeOpt   `json:"defaultReceiveTimeOpt"`
	TransferSpeed          string           `json:"transferSpeed"`
	SpeedForceNotice       string           `json:"speedForceNotice"`
	ReceiveTimeOpts        []ReceiveTimeOpt `json:"receiveTimeOpts"`
	ReceiveTimeDes         string           `json:"receiveTimeDes"`
	SerivceFlag            string           `json:"serivceFlag"`
	Ad                     string           `json:"ad"`
	BankNotice             string           `json:"bankNotice"`
	BankName               string           `json:"bankName"`
	BankShortName          string           `json:"bankShortName"`
	ResultStatus           int              `json:"resultStatus"`
	Memo                   string           `json:"memo"`
}
type ErrorDialog struct {
	BtnRightAction string `json:"btnRightAction"`
	BtnLeftAction  string `json:"btnLeftAction"`
}
type SessionButtonVO struct {
	Url      string `json:"url"`
	SubTitle string `json:"subTitle"`
	Title    string `json:"title"`
	Type1    string `json:"type"`
}
type ValidateReceiveCardReq struct {
	CanContinue    int    `json:"canContinue"`
	ChargeFee      string `json:"chargeFee"`
	TransferAmount string `json:"transferAmount"`
	PayChannelType string `json:"payChannelType"`
	CardNoHidden   int    `json:"cardNoHidden"`
	ReceiverName   string `json:"receiverName"`
	CardChannel    string `json:"cardChannel"`
	BankShortName  string `json:"bankShortName"`
	CardIndex      string `json:"cardIndex"`
	CardNo         string `json:"cardNo"`
	UserId         string `json:"userId"`
}
type ValidateReceiveCardResp struct {
	Success      bool            `json:"success"`
	CanContinue  bool            `json:"canContinue"`
	ShowMessage  string          `json:"showMessage"`
	ErrorDialog  ErrorDialog     `json:"errorDialog"`
	LeadingInfo  SessionButtonVO `json:"leadingInfo"`
	ResultStatus int             `json:"resultStatus"`
	Memo         string          `json:"memo"`
}
type CreateToCardReq struct {
	From            string            `json:"from"`
	HistoryIndex    string            `json:"historyIndex"`
	AssignedChannel string            `json:"assignedChannel"`
	SecurityId      string            `json:"securityId"`
	ConfirmCode     string            `json:"confirmCode"`
	Token           string            `json:"token"`
	FeeRate         string            `json:"feeRate"`
	ExchangeAmount  string            `json:"exchangeAmount"`
	ExchangePoints  string            `json:"exchangePoints"`
	MemberPoints    string            `json:"memberPoints"`
	ExtPropMap      map[string]string `json:"extPropMap"`
	WithVoice       int               `json:"withVoice"`
	PayCardChannel  string            `json:"payCardChannel"`
	PayCardIndex    string            `json:"payCardIndex"`
	EmotionSource   string            `json:"emotionSource"`
	EmotionId       string            `json:"emotionId"`
	CardNoHidden    int               `json:"cardNoHidden"`
	OrderSource     string            `json:"orderSource"`
	Promotion       string            `json:"promotion"`
	MobileNo        string            `json:"mobileNo"`
	ChargeFee       string            `json:"chargeFee"`
	TransferSpeed   string            `json:"transferSpeed"`
	TransferAmount  string            `json:"transferAmount"`
	Memo            string            `json:"memo"`
	ReceiverName    string            `json:"receiverName"`
	CardChannel     string            `json:"cardChannel"`
	BankShortName   string            `json:"bankShortName"`
	CardIndex       string            `json:"cardIndex"`
	CardNo          string            `json:"cardNo"`
	UserId          string            `json:"userId"`
}
type DialogVO struct {
	BtnRightUrl  string `json:"btnRightUrl"`
	BtnRightText string `json:"btnRightText"`
	BtnLeftUrl   string `json:"btnLeftUrl"`
	BtnLeftText  string `json:"btnLeftText"`
	Content      string `json:"content"`
	Title        string `json:"title"`
}
type FeeVO struct {
	FirstEnterDialog DialogVO `json:"firstEnterDialog"`
	NoticeUrl        string   `json:"noticeUrl"`
	ChargeMemo       string   `json:"chargeMemo"`
	AvailableAmount  string   `json:"availableAmount"`
	FeeRate          string   `json:"feeRate"`
	ExchangeRule     string   `json:"exchangeRule"`
	ExchangeRate     string   `json:"exchangeRate"`
	RemainPoints     string   `json:"remainPoints"`
	MinChargeAmount  string   `json:"minChargeAmount"`
	SkipClient       bool     `json:"skipClient"`
}
type CreateToCardResp struct {
	SecurityId   string `json:"securityId"`
	VerifyId     string `json:"verifyId"`
	ConfirmCode  string `json:"confirmCode"`
	FeeVO        FeeVO  `json:"feeVo"`
	ChargeFee    string `json:"chargeFee"`
	BizSubType   string `json:"bizSubType"`
	BizType      string `json:"bizType"`
	TransferNo   string `json:"transferNo"`
	ResultStatus int    `json:"resultStatus"`
	Memo         string `json:"memo"`
}

//todo 获取当前转账免费额度，没有号没法测试

func (w *WorkGroup) TransferToCard(req *TransferReq) {
	w.acc.transferReq = req
	w.checkCardBin(w.acc.transferReq.TransferCardNo)
}

// 根据卡号查询需要的参数
func (w *WorkGroup) checkCardBin(cardNo string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &CheckCardBinResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("CheckCardBin, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "查询银行卡参数错误[1]", nil)
		} else {
			log2.Infof("CheckCardBin, resp %+v", string(resp))
			if respObj.ResultStatus == 100 {
				// 查询成功，继续获取转账所需时间是2H还是T1
				w.queryBankInfo(respObj.BankShortName, cardNo)
			} else {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcCheckCardBin,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &CheckCardBinReq{
		CardNo: cardNo,
	})
}

func (w *WorkGroup) queryBankInfo(bankShortName, cardNo string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &QueryBankInfoResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("queryBankInfo, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "查询银行卡参数错误[2]", nil)
		} else {
			log2.Infof("queryBankInfo, resp %+v", string(resp))
			if respObj.ResultStatus == 100 {
				w.acc.transferReq.TransferSpeed = respObj.TransferSpeed
				// 查询成功
				w.validateReceiveCard(cardNo, bankShortName, w.acc.transferReq.RealName, w.acc.transferReq.Amount)
			} else {
				// {"memo":"你输入的是信用卡卡号，如需要，请使用信用卡还款服务。","receiveTimeOpts":[],"resultStatus":376,"success":false}
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcQueryBankInfo,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &QueryBankInfoReq{
		BankShortName:      bankShortName,
		NeedReceiveTimeOpt: "Y",
		CardNo:             cardNo,
		CardNoHidden:       0,
	})
}

func (w *WorkGroup) validateReceiveCard(cardNo, bankShortName, receiverName, transferAmount string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &ValidateReceiveCardResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("validateReceiveCard, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "验证收款卡号错误", nil)
		} else {
			log2.Infof("validateReceiveCard, resp %+v", string(resp))
			if respObj.ResultStatus == 100 && respObj.CanContinue {
				// 卡号验证成功，创建订单
				w.createToCard(
					cardNo,
					bankShortName,
					receiverName,
					transferAmount,
					w.acc.transferReq.Remark,
					w.acc.transferReq.TransferSpeed)
			} else {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcValidateReceiveCard,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &ValidateReceiveCardReq{
		CardNo:         cardNo,
		BankShortName:  bankShortName,
		ReceiverName:   receiverName,
		CardNoHidden:   0,
		TransferAmount: transferAmount,
		CanContinue:    0,
	})
}

func fee(transferAmount string) string {
	f, _ := strconv.ParseFloat(transferAmount, 32)
	f = f * 100 * 0.001
	f = math.Round(f)
	if f < 10 {
		return "0.10"
	} else {
		return fmt.Sprintf("%.2f", f/100)
	}
}

func (w *WorkGroup) createToCard(cardNo, bankShortName, receiverName, transferAmount, remark, transferSpeed string) {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &CreateToCardResp{}
		if err := json.Unmarshal(resp, respObj); err != nil {
			log2.Infof("createToCard, json.Unmarshal err: %+v", err)
			w.notifyEvent(EventTypeTransfer, TransferCodeError, "生成转帐订单错误", nil)
		} else {
			log2.Infof("createToCard, resp %+v", string(resp))
			if len(respObj.TransferNo) <= 0 {
				w.acc.transferReq.OnTransferResult(&TransferRes{
					success:    false,
					resultCode: respObj.ResultStatus,
					resultDesc: respObj.Memo,
				})
				w.notifyEvent(EventTypeTransfer, TransferCodeError, respObj.Memo, nil)
			} else {
				w.MspLoginCheckV3(respObj.TransferNo, respObj.ChargeFee, "biz_card_transfer")
			}
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcCreateToCard,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &CreateToCardReq{
		CardNo:         cardNo,
		BankShortName:  bankShortName,
		ReceiverName:   receiverName,
		Memo:           remark,
		TransferAmount: transferAmount,
		TransferSpeed:  transferSpeed,
		ChargeFee:      fee(transferAmount),
		OrderSource:    "form",
		CardNoHidden:   0,
		EmotionSource:  "",
		WithVoice:      0,
		FeeRate:        "0.001",
		Token:          tfToken(),
		ConfirmCode:    "",
		SecurityId:     "",
	})
}
