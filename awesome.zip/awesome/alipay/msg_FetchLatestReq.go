package alipay

import (
	"awesome/alipay/hpack"
	"awesome/alipay/model/pb"
	"awesome/tools/log2"
	"encoding/hex"
	"github.com/golang/protobuf/proto"
)

func (w *WorkGroup) sendFetchLatestReq() {
	onResp := func(resp []byte, headers []hpack.HeaderField) {
		respObj := &pb.FetchIndexLatestResp{}
		if err := proto.Unmarshal(resp, respObj); err != nil {
			log2.Infof("FetchLatest, proto.Unmarshal err: %+v, resp: \r\n%+v", err, hex.Dump(resp))
		} else {
			w.acc.LastQueryTime = respObj.GetLastQueryTime()
			log2.Infof("FetchLatest, resp: \r\n%+v", proto.MarshalTextString(respObj))
		}
	}
	headers := map[string]string{
		"Operation-Type": RpcFetchLatest,
		"retryable2":     "0",
	}
	w.SendHttpMessage(onResp, headers, &pb.FetchLatestReq{
		LastQueryTime: proto.Int64(w.acc.LastQueryTime),
		LocationInfo: &pb.CFLocationInfo{
			Lat:         proto.Float64(0.000000),
			Lon:         proto.Float64(0.000000),
			AdCode:      proto.String(""),
			LocTime:     proto.String(""),
			Accuracy:    proto.String(""),
			CityAd_Code: proto.String(""),
		},
		RefreshMode: proto.String("init"),
		OsType:      proto.String("ios"),
	})
}
