package spdb

import (
	"awesome/tools"
	"awesome/tools/log2"
	"crypto/rsa"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	"testing"
)

func Test111(t *testing.T) {

	coreKeyModulus := "ABDC0622F6E096CDA1052DE3E6EBD479123187E3FC5580F98CB36BB5EB1890C3F56518E9ECBB682CF0560B8D868426BFD33190AED4C9EAC4997503052B107516DEAACE6BFBE860DBB75711560CC5794A847F931736534A7DAEBE74651B0F73645DB41165F01B5A8CABEF8A6A9EF2575C514F4B394D323E36D41EFDCF85CB4F6C120AD54DF3C05F3C0327BBC26426D0DCC095C24295B5F82C346F233A8A415AF82F8E97C634A1A72A13CA84A37C30B3EDBF3E3E46F696F7F6F25C968F4C0BB8CEA8F7C398877A32C6F853ABA88DC27DBB6877E74B0A160AABE946EFC99CA37D7AF3A05E88C470F956DF9C204CB763C218D8B96AE63B3F4943B842E5BAAB688697"
	pwd := "369369"

	pub := &rsa.PublicKey{}
	pub.N, _ = new(big.Int).SetString(coreKeyModulus, 16)
	pub.E = 65537
	pwd = fmt.Sprintf("%02d%s", len(pwd), pwd)
	pwds := make([]byte, 0x100)
	copy(pwds, pwd)
	fmt.Println(hex.Dump(pwds))

	m := new(big.Int).SetBytes(pwds)
	c := new(big.Int)
	e := big.NewInt(int64(pub.E))
	c.Exp(m, e, pub.N)

	fmt.Println(hex.Dump(c.Bytes()))
	pass := fmt.Sprintf("%X", c.Bytes())
	fmt.Println(len(pass))
}

func TestDeResp(t *testing.T) {
	data := "ffc8458758943ea1rJYubIVkaGbL27ZkFDzvQDz3Jt0vTycvZTwaXYi+Z/+TveZhhDAkc9BxLkMwD84qiBofxANQPUyO\nYKrE0ZJIYdDFOZhw5HQFDmprARURVWp0sp851F0z/azOT6YV6ym5G3WQY/8pJKnZ/UHjP5I7zP48\nU/3Lp7wR83K0jzyzDgLHqrtxRYi2TC/ijpayTs0KsIO1cKICTWdY47TJkraVVSd3NNrZg1OMzhEx\nybejf+s3wVJUzNI74ssOWI8pfinrI4WDif5tcUfRdRsM9Z12gSuk0VA8ukOqWa3giOH0YyCAQ0Uo\n8DKlUd95J4EpmsrfMdQUCnCL2ZaeWS0NUXl/WstGG2z0crpqfPZ+rZO9/msFDoCZGXjB6wpTlS8I\nJnSmou1/gc50SJh8Eh2cPC5u/xUx1fs4eZcZH1bUjxXKBSQHGKHRvG4K0LpZAID4oyfgVLxn6QmI\n3L8=\n"

	key := data[:8]
	iv := data[8:16]
	str := data[16:]

	arr, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		fmt.Println(err)
		return
	}

	arr, err = tools.DESCBCDecrypt(arr, []byte(key), []byte(iv))
	if err != nil {
		fmt.Println(err)
		return
	}
	log2.InfoJSON(string(arr))
}
