package spdb

import (
	"awesome/tools"
	"awesome/tools/base"
	"bufio"
	"bytes"
	"crypto/md5"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/go-http-utils/headers"
)

// Bank 浦发银行
type Bank struct {
	Account        string         `json:"account"`  // 账号，手机号
	LoginPwd       string         `json:"loginPwd"` // 登陆密码
	PayPwd         string         `json:"payPwd"`   // 支付密码
	HardwareInfo   HardwareInfo   `json:"hardwareInfo"`
	Client         *http.Client   `json:"-"`
	Jar            *cookiejar.Jar `json:"-"`
	AcctNO         string         `json:"acctNo"`
	AcctType       string         `json:"acctType"`
	AcctKind       string         `json:"acctKind"`
	AcctName       string         `json:"acctName"`
	UDID           string         `json:"UDID"`
	IDFV           string         `json:"IDFV"`
	IMEI           string         `json:"IMEI"`
	DeviceDigest   string         `json:"deviceDigest"`
	UserLevel      string         `json:"userLevel"`
	UserType       string         `json:"userType"`
	UpdateTime     string         `json:"updateTime"`
	StartTime      string         `json:"startTime"`
	StartTimeStamp int64          `json:"startTimeStamp"`
	IPAddr         string         `json:"ipAddr"`
	MasterID       string         `json:"masterId"`
	CustID         string         `json:"custId"`
	sessionID      string
	balance        string

	authMethodResult string
	destCardNo       string
	destName         string
	deptID           string
	deptName         string
	amount           string
	remark           string
	destBankNo       string
	destBankName     string
	remitType        string
	isSmallBank      bool
	isSameBank       bool
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	Model         string `json:"model"`         // 设备类型
	Carrier       string `json:"carrier"`       // 运营商
	DeviceName    string `json:"deviceName"`    // 设备名称  iPhone7
	OwnerName     string `json:"ownerName"`     // 设备用户名 jj的 iPhone
	WebkitVersion string `json:"webkitVersion"` // webkit版本
	IBootVersion  string `json:"iBootVersion"`  // iboot版本
	KernelVersion string `json:"kernelVersion"` // 内核版本
}

// New 创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:      account,
		LoginPwd:     loginPwd,
		PayPwd:       payPwd,
		HardwareInfo: HardwareInfo{},
	}
	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()
	b.HardwareInfo.IBootVersion = tools.Mobile(b.HardwareInfo.SystemVersion)
	b.HardwareInfo.WebkitVersion = tools.WebKitVersion(b.HardwareInfo.SystemVersion)
	b.HardwareInfo.KernelVersion = tools.KernelVersion(b.HardwareInfo.SystemVersion)

	b.CustID = "spdbank"
	b.UpdateTime = "20200103204238"
	b.IDFV = tools.NewUUIDUpper()
	b.IMEI = tools.NewUUIDUpper()
	b.UDID = fmt.Sprintf("%X", md5.Sum([]byte(b.IDFV)))
	b.DeviceDigest = fmt.Sprintf("%x", sha1.Sum([]byte("iOS"+b.HardwareInfo.SystemVersion+b.UDID)))
	b.IPAddr = "192.168.0." + strconv.Itoa(tools.RandIntn(25))

	b.Save()
	return b
}

// Save 存储账号信息
func (b *Bank) Save() {
	path := "./spdb/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////生成一些需要的东西////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

func (b *Bank) userAgent() string {
	return fmt.Sprintf("PNCBank/%s CFNetwork/1120 Darwin/%s", cfBundleVersion, b.HardwareInfo.KernelVersion)
}

func (b *Bank) deviceInfo() string {
	return fmt.Sprintf("%s|iPhone|iPhoneiOS%s", b.UDID, b.HardwareInfo.SystemVersion)
}

func (b *Bank) netWorkAndDeviceInfo() string {
	return fmt.Sprintf("'NetWorkType':'1','NetWorkName':'','DeviceInfo':'%s|iPhone|iPhoneiOS%s'",
		b.UDID, b.HardwareInfo.SystemVersion)
}

func (b *Bank) netWorkAndDeviceInfoAndDeviceDigest() string {
	return fmt.Sprintf("||'NetWorkType':'','NetWorkName':'4g','DeviceInfo':'%s|iPhone|iPhoneiOS%s','DeviceDigest':'%s'",
		b.UDID, b.HardwareInfo.SystemVersion, b.DeviceDigest)
}

func (b *Bank) baseHeader() *http.Header {
	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "gzip, deflate, br")
	return header
}

func (b *Bank) baseReqHeader() reqHeader {
	return reqHeader{
		NetWorkType:  "",
		NetWorkName:  "4g",
		DeviceInfo:   b.deviceInfo(),
		DeviceDigest: b.DeviceDigest,
		AppVersion:   appVersion,
	}
}

func (b *Bank) transBody(suffix1, suffix2 string, req interface{}) (string, error) {
	// json 序列化
	reqData, err := json.Marshal(req)
	if err != nil {
		return "", err
	}

	reqStr := string(reqData) + suffix1

	// rsa 加密
	enReqData, err := tools.RSAEncrypt([]byte(reqStr), rsaPubKey)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(enReqData) + suffix2, nil
}

func (b *Bank) enReq(req *baseReq) (string, error) {
	// json 序列化
	reqData, err := json.Marshal(req)
	if err != nil {
		return "", err
	}

	// rsa 加密
	enReqData, err := tools.RSAEncrypt(reqData, rsaPubKey)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(enReqData), nil
}

func (b *Bank) enPwd(pwd, coreKeyModulus, netBankKeyModulus, ts string) (string, error) {
	// rsa加密密码
	pub := &rsa.PublicKey{}
	pub.N, _ = new(big.Int).SetString(coreKeyModulus, 16)
	pub.E = 65537

	pwd = fmt.Sprintf("%02d%s", len(pwd), pwd)
	pwds := make([]byte, pub.Size())
	copy(pwds, pwd)
	//fmt.Println(hex.Dump(pwds))

	m := new(big.Int).SetBytes(pwds)
	c := new(big.Int)
	e := big.NewInt(int64(pub.E))
	c.Exp(m, e, pub.N)

	// 这里有可能会少一个字节，需要前面补0
	pass := fmt.Sprintf("%X", c.Bytes())
	if len(c.Bytes()) < pub.Size() {
		pass = "00" + pass
	}
	// rc4加密密码
	rc4Key := []byte(strings.ToLower(tools.RandString(16)))
	rc4Buf := []byte(fmt.Sprintf("%s:%s", ts, pass))
	if err := tools.RC4Encrypt(rc4Buf, rc4Key); err != nil {
		return "", err
	}

	// rsa加密rc4 key
	pub.N, _ = new(big.Int).SetString(netBankKeyModulus, 16)
	pub.E = 65537
	encRC4Key, err := tools.RSAEncrypt(rc4Key, pub)
	if err != nil {
		return "", err
	}
	// 反转
	tools.ReverseSlice(encRC4Key)

	ba := bytes.NewBuffer([]byte{})

	encRC4KeyLen := make([]byte, 0x14)
	copy(encRC4KeyLen, fmt.Sprintf("%08d", len(encRC4Key)+0xc))
	ba.Write(encRC4KeyLen)
	ba.Write(encRC4Key)

	// rc4数据长度
	ba.Write([]byte(fmt.Sprintf("%08d", len(rc4Buf))))
	ba.Write(rc4Buf)

	return base64.StdEncoding.EncodeToString(ba.Bytes()), nil
}

func (b *Bank) deResp(data []byte) ([]byte, error) {
	if len(data) < 16 {
		return nil, errors.New("错误的解密数据长度")
	}

	key := data[:8]
	iv := data[8:16]
	str := data[16:]

	arr, err := base64.StdEncoding.DecodeString(string(str))
	if err != nil {
		return nil, err
	}

	arr, err = tools.DESCBCDecrypt(arr, key, iv)
	if err != nil {
		return nil, err
	}

	return arr, nil
}

func getRandInt(cnt int) string {
	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	s := ""
	for i := 0; i < cnt; i++ {
		s += fmt.Sprintf("%d", rnd.Intn(10))
	}

	return s
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////逻辑业务////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Login 登陆操作
func (b *Bank) Login() base.LoginResultCode {
	b.Jar, _ = cookiejar.New(nil)

	u, _ := url.Parse("http://127.0.0.1:8888")
	b.Client = &http.Client{
		Transport: &http.Transport{
			Proxy: http.ProxyURL(u),
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     b.Jar,
	}

	b.StartTime = tools.TimeFmtEx3()
	b.StartTimeStamp = tools.TimestampEx()

	b.vesionRequest()
	b.initRequestPointRed()
	//b.adImage()
	//b.adViewRequest()
	//b.getImageAllDatas()
	//b.updateNewMenu()

	// b.appDelegate()
	// time.Sleep(time.Duration(rand.Int31n(2000)+1000) * time.Millisecond)
	// b.areaFullMenuList()
	// b.transServLet("HomeProductNotLoginQry")
	// b.transServLet("GeekRollList")
	// b.collectStart()
	// b.transServLet("ActivityAreaQryNew")
	// b.transServLet("HotGlodManage")
	// b.transServLet("WelfareSpeGenQry")
	// b.transServLet("AdGeneralPage")
	// b.appDelegate()

	// time.Sleep(time.Duration(rand.Int31n(3000)+2000) * time.Millisecond)
	// b.home()
	time.Sleep(time.Duration(rand.Int31n(2000)+1000) * time.Millisecond)
	if b.UserLevel == "" {
		// 输入手机号
		// time.Sleep(time.Duration(rand.Int31n(5000)+3000) * time.Millisecond)
		// b.preLogin()
		// b.preLogin()
		// b.alertAnswer()
		// b.binding()
		// 还未登陆过，需要输入手机号
		queryMobileOpen := b.clientQueryMobileOpen()
		// b.alertConfirm()

		// userType == 0 这个是需要先验证手机号，然后开始注册
		// userType == 1 登陆-查询密码登陆页-登陆按钮点击
		// userType == 2 注册设置查询密码的类型
		// userType == 3 登陆-查询密码及浦大喜奔登陆页-登陆按钮点击
		// userType == 4 注册设置查询密码及浦大喜奔密码的类型
		if queryMobileOpen.RspBody.UserType == "1" || queryMobileOpen.RspBody.UserType == "3" {
			b.UserType = queryMobileOpen.RspBody.UserType
		} else {
			b.Error("当前账户不存在")
			return base.LoginResultFailWrongAccount
		}
	}

	// 输入密码
	// time.Sleep(time.Duration(rand.Int31n(4000)+2000) * time.Millisecond)
	rsaInfo := b.queryRSAInfo()
	if rsaInfo.RspHeader.ResponseCode != successCode {
		b.Errorf("获取加密登陆密码的RSA密钥出错 code=%s, msg=%s", rsaInfo.RspHeader.ResponseCode, rsaInfo.RspHeader.ResponseMsg)
		return base.LoginResultFail
	}

	login, pwd := b.clientLogin(rsaInfo.RspBody.CoreKeyModulus, rsaInfo.RspBody.NetBankKeyModulus, rsaInfo.RspBody.TimeStamp)
	if login.RspHeader.ResponseCode != successCode {
		if login.RspHeader.ResponseCode == "EGG0042" {
			b.Errorf("登陆失败 登陆密码错误, msg=%s", login.RspHeader.ResponseMsg)
			return base.LoginResultFailWrongPwd
		}
		b.Errorf("登陆出错 code=%s, msg=%s", login.RspHeader.ResponseCode, login.RspHeader.ResponseMsg)
		return base.LoginResultFail
	}

	if login.RspBody.DeviceBindStatus == "1" {
		// 需要绑定设备
		if login.RspBody.IsSendPwdIn10Mins != "1" {
			authFlag := b.queryFastAuthOpenFlag()
			if authFlag.RspBody.IsOpen != "1" {
				b.Error("未开启快速绑定")
				return base.LoginResultFail
			}

			sendSms := b.sendSMSPwdMsg()
			if sendSms.RspBody.IsSendPwdIn10Mins != "1" {
				b.Error("发送短信验证码失败")
				return base.LoginResultFail
			}
		}

		b.Info("登陆需要绑定设备，短信验证码已发送")
		// 获取短信验证码
		br := bufio.NewReader(os.Stdin)
		smsCode, _, _ := br.ReadLine()
		b.Infof("获取到短信=%s", string(smsCode))

		login = b.checkMobilePwd(string(smsCode))
		if login.RspHeader.ResponseCode != successCode {
			if login.RspHeader.ResponseCode == "validation.mobilepwd.error" {
				b.Errorf("短信验证码登陆出错 验证码错误, msg=%s", login.RspHeader.ResponseMsg)
				return base.LoginResultFailWrongSms
			}
			b.Errorf("短信验证码登陆出错 code=%s, msg=%s", login.RspHeader.ResponseCode, login.RspHeader.ResponseMsg)
			return base.LoginResultFail
		}
		// 第一次登陆后clientInitUser 不传入 ""
		pwd = ""
	}

	initUser := b.clientInitUser(login.RspBody.TokenforClientlogin, pwd)
	if initUser.RspHeader.ResponseCode != successCode {
		b.Errorf("登陆获取用户信息失败 code=%s, msg=%s", initUser.RspHeader.ResponseCode, initUser.RspHeader.ResponseMsg)
		return base.LoginResultFail
	}

	b.MasterID = initUser.RspBody.MasterID
	// b.loginSuccess()
	b.UserLevel = initUser.RspBody.UserLevel
	// uUp4-D5gE8ZwFj-7shqBMdS-ZiBdD7VZALh8R7wp2SvsQdKEpwOc!459755528!1578282532448
	// 去掉最后一个时间戳
	// b.sessionID = login.JSESSIONID[:len(login.JSESSIONID)-14]
	b.AcctName = initUser.RspBody.PersonName
	// 选卡
	if len(initUser.RspBody.CommonCardList) > 0 {
		b.AcctNO = initUser.RspBody.CommonCardList[0].AcctNo
		b.AcctType = initUser.RspBody.CommonCardList[0].AcctType
		b.AcctKind = initUser.RspBody.CommonCardList[0].AcctKind
	}

	b.Save()
	return base.LoginResultSuccess
}

// QueryBalance 查询余额
func (b *Bank) QueryBalance() {
	// 点击首页
	// b.shouye()
	// time.Sleep(time.Duration(rand.Int31n(4000)+2000) * time.Millisecond)
	// 点击我的账户
	// b.appNew()
	// b.menu()
	// b.appNew()
	b.queryMyAccounts()
	// b.pageTime()
}

// BillList 账单列表
func (b *Bank) BillList(startDate, endDate string, index int) {
	// if page == "1" {
	// 	b.touch()
	// } else {
	// 	b.slide()
	// }
	b.keepSesAliveTrans()
	b.queryBillList(startDate, endDate, index)
	// b.queryBillDetail("99979497243020201014", "")
	// b.queryBillDetail("99979451152820201017", "")
}

// TransferQuerySmallBank 查询小银行编号
func (b *Bank) TransferQuerySmallBank(bankCode, cityID string) []SmallBankInfo {
	query := b.querySmallBank(bankCode, cityID)
	if query.RspHeader.ResponseCode != successCode {
		b.Errorf("查询小银行出错 code=%s, msg=%s", query.RspHeader.ResponseCode, query.RspHeader.ResponseMsg)
		return nil
	}

	return query.RspBody.List
}

// Transfer 转账
func (b *Bank) Transfer(destCardNo, destName, amount, remark string, deptID, deptName string) base.TransferResultCode {
	b.destCardNo = destCardNo
	b.destName = destName
	b.amount = amount
	b.remark = remark
	b.deptID = deptID
	b.deptName = deptName
	b.isSmallBank = false
	b.isSameBank = false
	b.remitType = "04"
	if b.deptID != "" {
		b.isSmallBank = true
		b.remitType = "02"
	}

	b.querySIMSignStatus() // SIM盾 状态

	status := b.checkPaymentCardStatus()
	if status.RspHeader.ResponseCode != successCode {
		b.Errorf("检查卡状态失败 code=%s, msg=%s", status.RspHeader.ResponseCode, status.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}
	if status.RspBody.SnglVchrUseSt != "0" {
		b.Error("付款卡状态不正常！")
		return base.TransferResultFail
	}
	b.balance = status.RspBody.AvlAmt
	fBalance, _ := strconv.ParseFloat(b.balance, 64)
	fAmount, _ := strconv.ParseFloat(b.amount, 64)
	if fBalance < fAmount {
		b.Error("余额不足")
		return base.TransferResultFail
	}

	bankResp := b.queryBankByAcctNo(b.destCardNo)
	if bankResp.RspBody.BankNo == "" && !b.isSmallBank {
		b.Errorf("查询银行出错 code=%s, msg=%s", bankResp.RspHeader.ResponseCode, bankResp.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}
	b.destBankNo = bankResp.RspBody.BankNo
	b.destBankName = strings.Trim(bankResp.RspBody.BankName, " ")
	if b.destBankNo == "310290000013" {
		b.isSameBank = true
	}

	check := b.checkBlackPayeeAcctNo(b.amount, b.destCardNo)
	if check.RspHeader.ResponseCode != successCode {
		b.Errorf("检查黑名单 检查出错 code=%s, msg=%s", check.RspHeader.ResponseCode, check.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}
	if check.RspBody.CheckResult == "1" {
		b.Error("您转入的银行账号为高风险账号，查实后进行转账。")
		return base.TransferResultFail
	}
	if check.RspBody.CheckResult == "2" {
		b.Error("您转入的银行账号异常，已对您的电子渠道交易进行锁定保护，请至我行柜面或通过手机银行核验身份后解锁。")
		return base.TransferResultFail
	}

	lmt := b.queryUserIsOverLmt(b.amount)
	if lmt.RspHeader.ResponseCode != successCode {
		b.Errorf("查询限额 检查出错 code=%s, msg=%s", lmt.RspHeader.ResponseCode, lmt.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}
	if lmt.RspBody.LDLmtFlag != "0" {
		b.Error("转账超过限额")
		return base.TransferResultFail
	}

	if b.isSmallBank {
		b.remitOutCharge(b.destCardNo, b.amount, b.remark, b.deptID, b.deptName)
	} else if b.isSameBank {
		b.remitType = "01"
		b.transferInBankConfirm(b.destCardNo, b.destName, b.amount, b.remark)
	} else {
		b.netQueryCharge(b.amount, "EG01")
	}

	//afds := b.AFDSMonInfoUdtRt(b.destBankNo, b.destCardNo, b.destName, amount)
	//if afds.RspHeader.ResponseCode != successCode {
	//    b.Errorf("AFDS 检查出错 code=%s, msg=%s", afds.RspHeader.ResponseCode, afds.RspHeader.ResponseMsg)
	//    return base.TransferResultFail
	//}

	// 查询验证方式
	authRes := b.queryAuthMethod(b.amount, b.destBankNo, b.destCardNo, b.destName)
	if authRes.RspHeader.ResponseCode != successCode {
		b.Errorf("查询认证方式失败 code=%s, msg=%s", authRes.RspHeader.ResponseCode, authRes.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}

	b.authMethodResult = authRes.RspBody.AuthMethodResult

	if authRes.RspBody.UkeyAuth == "1" {
		b.Error("转账需要UKEY验证")
		return base.TransferResultFail
	}
	if authRes.RspBody.FaceAuth == "1" {
		b.Error("转账需要刷脸验证")
		return base.TransferResultFail
	}

	sendResp := b.sendMobilePwdTransfer(b.destCardNo, b.destName, b.amount, b.remitType)
	if sendResp.RspHeader.ResponseCode != successCode {
		b.Errorf("发送短信失败 code=%s, msg=%s", sendResp.RspHeader.ResponseCode, sendResp.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}

	// 获取短信验证码
	b.Info("转账发送验证码成功:")
	br := bufio.NewReader(os.Stdin)
	smsCode, _, _ := br.ReadLine()
	b.Infof("获取到短信=%s", string(smsCode))
	return b.TransferVerifySms(string(smsCode))
}

// TransferVerifySms 转账验证提交
func (b *Bank) TransferVerifySms(smsCode string) base.TransferResultCode {
	b.Infof("收到短信 >>>> %s", smsCode)
	rsaInfo := b.queryRSAInfo()
	if rsaInfo.RspHeader.ResponseCode != successCode {
		b.Errorf("获取加密支付密码的RSA密钥出错 code=%s, msg=%s", rsaInfo.RspHeader.ResponseCode, rsaInfo.RspHeader.ResponseMsg)
		return base.TransferResultFail
	}

	if b.isSmallBank {
		transfer := b.remitOutRes(smsCode, rsaInfo.RspBody.CoreKeyModulus, rsaInfo.RspBody.NetBankKeyModulus, rsaInfo.RspBody.TimeStamp, b.destCardNo, b.destName, b.deptID, b.deptName, b.amount, b.remark)
		if transfer.RspHeader.ResponseCode == "validation.mobilepwd.error" {
			b.Errorf("转账小银行失败 验证码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}
		if transfer.RspHeader.ResponseCode == "EGG0391" {
			b.Errorf("转账小银行失败 交易密码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}

		if transfer.RspHeader.ResponseCode != successCode {
			b.Errorf("转账小银行失败 code=%s, msg=%s", transfer.RspHeader.ResponseCode, transfer.RspHeader.ResponseMsg)
			return base.TransferResultFail
		}

		// 到这就就转账完成了，但是交易状态需要等待比较长的时间才会变化
		b.Infof("小银行转账完成")
		b.queryBillDetail(transfer.RspBody.RemitNo, "")

	} else if b.isSameBank {
		transfer := b.transferInBank(smsCode, rsaInfo.RspBody.CoreKeyModulus, rsaInfo.RspBody.NetBankKeyModulus, rsaInfo.RspBody.TimeStamp, b.destCardNo, b.destName, b.amount, b.remark)
		if transfer.RspHeader.ResponseCode == "validation.mobilepwd.error" {
			b.Errorf("转账同行 验证码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}
		if transfer.RspHeader.ResponseCode == "EGG0391" {
			b.Errorf("转账小银行失败 交易密码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}

		if transfer.RspHeader.ResponseCode != successCode {
			b.Errorf("转账同行 code=%s, msg=%s", transfer.RspHeader.ResponseCode, transfer.RspHeader.ResponseMsg)
			return base.TransferResultFail
		}
		// 到这里直接就成功了
	} else {
		transfer := b.netTransferOutToBank(smsCode, rsaInfo.RspBody.CoreKeyModulus, rsaInfo.RspBody.NetBankKeyModulus, rsaInfo.RspBody.TimeStamp, b.destCardNo, b.destName, b.destBankNo, b.amount, b.remark)
		if transfer.RspHeader.ResponseCode == "validation.mobilepwd.error" {
			b.Errorf("转账失败 验证码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}
		if transfer.RspHeader.ResponseCode == "EGG0391" {
			b.Errorf("转账失败 交易密码错误 msg=%s", transfer.RspHeader.ResponseMsg)
			return base.TransferResultFailWrongSms
		}

		if transfer.RspHeader.ResponseCode != successCode {
			b.Errorf("转账失败 code=%s, msg=%s", transfer.RspHeader.ResponseCode, transfer.RspHeader.ResponseMsg)
			return base.TransferResultFail
		}

		// 需要查询状态
		query := b.queryNetTransferRes(transfer.RspBody.BusinessID)
		if query.RspBody.NetBusinessStatus == "1" {
			b.Info("转账成功")
		}
	}

	return base.TransferResultSuccess
}
