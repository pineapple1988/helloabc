package spdb

type areaFullMenuListReq struct {
	TransID    string `json:"TransId"`
	AppVersion string `json:"app_version"`
	UpdateTime string `json:"updateTime"`
	OsType     string `json:"OsType"`
}

type areaFullMenuListResp struct {
	JSESSIONID  string `json:"JSESSIONID"`
	UpdateTime  string `json:"updateTime"`
	ListenerURL []struct {
		ListenerTitle   string `json:"listener_title"`
		ListenerURL     string `json:"listener_url"`
		ListenerChannel string `json:"listener_channel"`
	} `json:"listenerUrl"`
	ResponseCode string        `json:"ResponseCode"`
	ForceUpdate  string        `json:"forceUpdate"`
	STATUS       string        `json:"STATUS"`
	List         []interface{} `json:"List"`
	TransSeqNo   string        `json:"TransSeqNo"`
	ResponseMsg  string        `json:"ResponseMsg"`
	PreImgURL    string        `json:"preImgUrl"`
	TransName    string        `json:"TransName"`
}

type reqHeader struct {
	NetWorkType  string `json:"NetWorkType"`
	NetWorkName  string `json:"NetWorkName"`
	DeviceInfo   string `json:"DeviceInfo"`
	DeviceDigest string `json:"DeviceDigest"`
	AppVersion   string `json:"AppVersion"`
}

type respHeader struct {
	ResponseMsg  string `json:"ResponseMsg"`
	AppVersion   string `json:"AppVersion"`
	ResponseCode string `json:"ResponseCode"`
}

type baseReq struct {
	ReqHeader reqHeader   `json:"ReqHeader"`
	ReqBody   interface{} `json:"ReqBody"`
}

type clientQueryMobileOpenResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		IsRegister string `json:"IsRegister"`
		MasterID   string `json:"MasterId"`
		UserType   string `json:"UserType"`
	} `json:"RspBody"`
}

type queryRsaInfoResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		NetBankKeyModulus string `json:"NetBankKeyModulus"`
		TimeStamp         string `json:"TimeStamp"`
		CoreKeyModulus    string `json:"CoreKeyModulus"`
		CreditKeyModulus  string `json:"CreditKeyModulus"`
	} `json:"RspBody"`
}

type cardInfo struct {
	AcctKind            string `josn:"AcctKind"`
	AcctName            string `json:"AcctName"`
	AcctNo              string `json:"AcctNo"`
	AcctType            string `josn:"AcctType"`
	Balance             string `json:"Balance"`
	BranchID            string `json:"BranchId"`
	CanUseBalance       string `json:"CanUseBalance"`
	CardClass           string `json:"CardClass"`
	CardType            string `json:"CardType"`
	CheckStatus         string `json:"CheckStatus"`
	Currency            string `josn:"Currency"`
	CurrencyType        string `josn:"CurrencyType"`
	DeptID              string `json:"DeptId"`
	NickName            string `json:"NickName"`
	OtherSysFlag        string `json:"OtherSysFlag"`
	OverdraftStatus     string `json:"OverdraftStatus"`
	SpecialModule       string `json:"SpecialModule"`
	SpecialModuleStatus string `josn:"SpecialModuleStatus"`
	WisdomCardStatus    string `json:"WisdomCardStatus"`
}

type clientLoginResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AcctList             []cardInfo `json:"AcctList"`
		Address              string     `json:"Address"`
		AuthenticateType     string     `json:"AuthenticateType"`
		Birthday             string     `json:"Birthday"`
		DefaultAcctName      string     `json:"DefaultAcctName"`
		DefaultAcctNo        string     `json:"DefaultAcctNo"`
		DeviceBindStatus     string     `json:"DeviceBindStatus"`
		Email                string     `json:"Email"`
		EngName              string     `json:"EngName"`
		FaceLoginOpenFlag    string     `json:"FaceLoginOpenFlag"`
		FaxNo                string     `json:"FaxNo"`
		FingerLoginOpenFlag  string     `json:"FingerLoginOpenFlag"`
		GestureFirstOpen     string     `json:"GestureFirstOpen"`
		GestureLoginOpenFlag string     `json:"GestureLoginOpenFlag"`
		IDDueDate            string     `json:"IdDueDate"`
		IDNo                 string     `json:"IdNo"`
		IDType               string     `json:"IdType"`
		IsEVoucherFlag       string     `json:"IsEVoucherFlag"`
		IsFQUser             string     `json:"IsFQUser"`
		IsResident           string     `json:"IsResident"`
		IsSendPwdIn10Mins    string     `json:"IsSendPwdIn10Mins"`
		IsVip                string     `json:"IsVip"`
		IsWxtFlag            string     `json:"IsWxtFlag"`
		LoginMobileNo        string     `json:"LoginMobileNo"`
		LoginWay             string     `json:"LoginWay"`
		LoginWelcome         string     `json:"LoginWelcome"`
		MasterID             string     `json:"MasterId"`
		ModifyFlag           string     `json:"ModifyFlag"`
		OpenXWFlag           string     `json:"OpenXWFlag"`
		PassPort             string     `json:"PassPort"`
		PersonName           string     `json:"PersonName"`
		PlatformFlag         string     `json:"PlatformFlag"`
		SDeptID              string     `json:"SDeptId"`
		Sex                  string     `json:"Sex"`
		TelephoneNo          string     `json:"TelephoneNo"`
		TokenforClientlogin  string     `json:"TokenforClientlogin"`
		UkeyFlag             string     `json:"UkeyFlag"`
		UkeyID               string     `json:"UkeyId"`
		UserLevel            string     `json:"UserLevel"`
		UserType             string     `json:"UserType"`
		VoiceLoginOpenFlag   string     `json:"VoiceLoginOpenFlag"`
		VoiceTextBtFlag      string     `json:"VoiceTextBtFlag"`
		WXTAcctBalance       string     `json:"WXTAcctBalance"`
		WXTAcctNo            string     `json:"WXTAcctNo"`
		WXTAcctStatus        string     `json:"WXTAcctStatus"`
		ZipCode              string     `json:"ZipCode"`
		ThreeLoginFlag       string     `json:"threeLoginFlag"`
	} `json:"RspBody"`
}

type queryFastAuthOpenFlagResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		IsOpen string `json:"isOpen"`
	} `json:"RspBody"`
}

type sendSMSPwdMsgResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		IsSendPwdIn10Mins string `json:"IsSendPwdIn10Mins"`
	} `json:"RspBody"`
}

type clientInitUserReq struct {
	APPVersion          string `json:"APP_Version"`
	DeviceDigest        string `json:"DeviceDigest"`
	DeviceInfo          string `json:"DeviceInfo"`
	DeviceType          string `json:"DeviceType"`
	DynamicCode         string `json:"DynamicCode"`
	IDNo                string `json:"IdNo"`
	IDType              string `json:"IdType"`
	ImageCoder          string `json:"ImageCoder"`
	IsRoot              string `json:"IsRoot"`
	IsSimulator         string `json:"IsSimulator"`
	Latitude            string `json:"Latitude"`
	LoginWay            string `json:"LoginWay"`
	Longtitude          string `json:"Longtitude"`
	MobileNo            string `json:"MobileNo"`
	MobilePhoneBrand    string `json:"MobilePhoneBrand"`
	MobilePhoneModel    string `json:"MobilePhoneModel"`
	NewActiveXFlag      string `json:"NewActiveXFlag"`
	NewVersionFlag      string `json:"NewVersionFlag"`
	OSVersion           string `json:"OS_Version"`
	PDXBPassword        string `json:"PDXBPassword"`
	Password            string `json:"Password"`
	Platform            string `json:"Platform"`
	SimplePwdFlag       string `json:"SimplePwdFlag"`
	TokenforClientlogin string `json:"TokenforClientlogin"`
	TransID             string `json:"TransId"`
	UserType            string `json:"UserType"`
	WapTelNo            string `json:"WapTelNo"`
}

type clientInitUserReq1 struct {
	DeviceType          string `json:"DeviceType"`
	MobileNo            string `json:"MobileNo"`
	Platform            string `json:"Platform"`
	TokenforClientlogin string `json:"TokenforClientlogin"`
	TransID             string `json:"TransId"`
}

type clientInitUserResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AcctList             []cardInfo    `json:"AcctList"`
		Address              string        `json:"Address"`
		AuthenticateType     string        `json:"AuthenticateType"`
		Birthday             string        `json:"Birthday"`
		CommonCardList       []cardInfo    `json:"COMMONCARDLIST"`
		CreditFlag           string        `json:"CreditFlag"`
		DefaultAcctName      string        `json:"DefaultAcctName"`
		DefaultAcctNo        string        `json:"DefaultAcctNo"`
		Email                string        `json:"Email"`
		EngName              string        `json:"EngName"`
		FaceLoginOpenFlag    string        `json:"FaceLoginOpenFlag"`
		FaxNo                string        `json:"FaxNo"`
		FingerLoginOpenFlag  string        `json:"FingerLoginOpenFlag"`
		GestureFirstOpen     string        `json:"GestureFirstOpen"`
		GestureLoginOpenFlag string        `json:"GestureLoginOpenFlag"`
		IDDueDate            string        `json:"IdDueDate"`
		IDNo                 string        `json:"IdNo"`
		IDType               string        `json:"IdType"`
		IsEVoucherFlag       string        `json:"IsEVoucherFlag"`
		IsFQUser             string        `json:"IsFQUser"`
		IsResident           string        `json:"IsResident"`
		IsVip                string        `json:"IsVip"`
		IsWxtFlag            string        `json:"IsWxtFlag"`
		LoginMobileNo        string        `json:"LoginMobileNo"`
		LoginWay             string        `json:"LoginWay"`
		LoginWelcome         string        `json:"LoginWelcome"`
		MasterID             string        `json:"MasterId"`
		OpenXWFlag           string        `json:"OpenXWFlag"`
		PersonName           string        `json:"PersonName"`
		PlatformFlag         string        `json:"PlatformFlag"`
		SDeptID              string        `json:"SDeptId"`
		Sex                  string        `json:"Sex"`
		TelephoneNo          string        `json:"TelephoneNo"`
		UkeyFlag             string        `json:"UkeyFlag"`
		UkeyID               string        `json:"UkeyId"`
		UserLevel            string        `json:"UserLevel"`
		UserType             string        `json:"UserType"`
		VoiceLoginOpenFlag   string        `json:"VoiceLoginOpenFlag"`
		VoiceTextBtFlag      string        `json:"VoiceTextBtFlag"`
		WXTAcctBalance       string        `json:"WXTAcctBalance"`
		WXTAcctNo            string        `json:"WXTAcctNo"`
		WXTAcctStatus        string        `json:"WXTAcctStatus"`
		WXTLIST              []interface{} `json:"WXTLIST"`
		ZipCode              string        `json:"ZipCode"`
		ThreeLoginFlag       string        `json:"threeLoginFlag"`
	} `json:"RspBody"`
}

type sendVoiceCodeReq struct {
	TransID       string `json:"TransId"`
	DynamicCodeNo string `json:"DynamicCodeNo"`
	ConveyTerm    string `json:"ConveyTerm"`
	MobileNo      string `json:"MobileNo"`
	Channel       string `json:"Channel"`
	Flag          string `json:"Flag"`
}

type sendVoiceCodeResp struct {
	JSESSIONID    string `json:"JSESSIONID"`
	MSG           string `json:"MSG"`
	ResponseCode  string `json:"ResponseCode"`
	ResponseMsg   string `json:"ResponseMsg"`
	Status        string `json:"STATUS"`
	TransName     string `json:"TransName"`
	TransSeqNo    string `json:"TransSeqNo"`
	IsSuccess     string `json:"IsSuccess"`
	DynamicCodeNo string `json:"DynamicCodeNo"`
}

type checkMobilePwdReq struct {
	AuthenticateType string `json:"AuthenticateType"`
	DeviceDigest     string `json:"DeviceDigest"`
	DeviceInfo       string `json:"DeviceInfo"`
	DeviceType       string `json:"DeviceType"`
	MobilePasswd     string `json:"MobilePasswd"`
	Platform         string `json:"Platform"`
	Scope            string `json:"Scope"`
	TransID          string `json:"TransId"`
}

type queryMyAccountsResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		List []struct {
			AcctNickName     string `json:"AcctNickName"`
			AcctNo           string `json:"AcctNo"`
			AcctType         string `json:"AcctType"`
			Balance          string `json:"Balance"`
			BalanceCNY       string `json:"BalanceCNY"`
			CanUseBalance    string `json:"CanUseBalance"`
			CanUseBalanceCNY string `json:"CanUseBalanceCNY"`
			CardStatus       string `json:"CardStatus"`
			CardType         string `json:"CardType"`
			HaveEntityCard   string `json:"HaveEntityCard"`
			IsDefaultAcctNo  string `json:"IsDefaultAcctNo"`
			IsFaceVerify     string `json:"IsFaceVerify"`
			IsMerchantAcct   string `json:"IsMerchantAcct"`
			MoneyType        string `json:"MoneyType"`
			OpenDeptNo       string `json:"OpenDeptNo"`
			QuickMenu        []struct {
				Link        string `json:"Link"`
				LinkChannel string `json:"LinkChannel"`
				MenuName    string `json:"MenuName"`
			} `json:"QuickMenu"`
			ThreeUpTwo string `json:"ThreeUpTwo"`
		} `json:"List"`
	} `json:"RspBody"`
}

type queryBillListResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		List []struct {
			AbstractCode    string `json:"AbstractCode"`
			AcctBal         string `json:"AcctBal"`
			AuthNo          string `json:"AuthNo"`
			BusinessID      string `json:"BusinessId"`
			CnterBankName   string `json:"CnterBankName"`
			DebitFlag       string `json:"DebitFlag"`
			HostSeqNo       string `json:"HostSeqNo"`
			Postscript      string `json:"Postscript"`
			RemitFlag       string `json:"RemitFlag"`
			RsrvIntFld1     string `json:"RsrvIntFld1"`
			Sign            string `json:"Sign"`
			TranAmt         string `json:"TranAmt"`
			TranCd          string `json:"TranCd"`
			TranCnterAcctNo string `json:"TranCnterAcctNo"`
			TranCnterNm     string `json:"TranCnterNm"`
			TranDate1       string `json:"TranDate1"`
			TranTime2       string `json:"TranTime2"`
		} `json:"List"`
	} `json:"RspBody"`
}
type queryBillDetailResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		TransDate         string `json:"TransDate"`
		PostScript        string `json:"PostScript"`
		PayerName         string `json:"PayerName"`
		PayerBankName     string `json:"PayerBankName"`
		PayeeName         string `json:"PayeeName"`
		PayeeBankName     string `json:"PayeeBankName"`
		PayeeAcct         string `json:"PayeeAcct"`
		NetBusinessStatus string `json:"NetBusinessStatus"`
		Charge            string `json:"Charge"`
		BusinessID        string `json:"BusinessId"`
		Amount            string `json:"Amount"`
		AcctNo            string `json:"AcctNo"`
	} `json:"RspBody"`
}

type queryBankByAcctNoReq struct {
	AcctNo string `json:"AcctNo"`
}
type queryBankByAcctNoResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AcctType         string `json:"AcctType"`
		BankName         string `json:"BankName"`
		BankNo           string `json:"BankNo"`
		BankPaymentLevel string `json:"BankPaymentLevel"`
		IsSuperPayeeBank string `json:"IsSuperPayeeBank"`
	} `json:"RspBody"`
}

// SmallBankInfo 小银行的信息
type SmallBankInfo struct {
	Address  string `json:"Address"`
	DeptName string `json:"DeptName"`
	DeptID   string `json:"DeptId"`
}

type querySmallBankResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		List []SmallBankInfo `json:"List"`
	} `json:"RspBody"`
}

type querySIMSignStatusReq struct {
	IsFromTrans string `json:"IsFromTrans"`
	QueryFlag   string `json:"QueryFlag"`
}

type querySIMSignStatusResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		SIMStatus string `json:"SIMStatus"`
	} `json:"RspBody"`
}

type checkPaymentCardStatusReq struct {
	AcctType     string `json:"AcctType"`
	ClientAcctNo string `json:"ClientAcctNo"`
	CurrencyNo   string `json:"CurrencyNo"`
	CurrencyType string `json:"CurrencyType"`
	TranAmt      string `json:"TranAmt"`
}
type checkPaymentCardStatusResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AvlAmt        string `json:"AvlAmt"`
		SnglVchrUseSt string `json:"SnglVchrUseSt"`
	} `json:"RspBody"`
}

type netQueryChargeReq struct {
	AcctNo    string `json:"AcctNo"`
	Amount    string `json:"Amount"`
	TransType string `json:"TransType"`
}
type netQueryChargeResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		Charge string `json:"Charge"`
	} `json:"RspBody"`
}

type remitOutChargeReq struct {
	AcctNo      string `json:"AcctNo"`
	Amount      string `json:"Amount"`
	Balance     string `json:"Balance"`
	DeptID      string `json:"DeptId"`
	DeptName    string `json:"DeptName"`
	PayeeAcctNo string `json:"PayeeAcctNo"`
	PostScript  string `json:"PostScript"`
}
type remitOutChargeResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		Charge   string `json:"Charge"`
		IsCharge string `json:"IsCharge"`
	} `json:"RspBody"`
}

type transferInBankConfirmReq struct {
	AcctNo        string `json:"AcctNo"`
	Amount        string `json:"Amount"`
	CanUseBalance string `json:"CanUseBalance"`
	PayeeAcctNo   string `json:"PayeeAcctNo"`
	PayeeAcctType string `json:"PayeeAcctType"`
	PayeeName     string `json:"PayeeName"`
	PostScript    string `json:"PostScript"`
	SubmitBtn2    string `json:"SubmitBtn2"`
}
type transferInBankConfirmResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		InnerCharge string `json:"InnerCharge"`
	} `json:"RspBody"`
}

type queryAuthMethodResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		SeqNo            string `json:"SeqNo"`
		FaceAuthScene    string `json:"FaceAuthScene"`
		FaceAuth         string `json:"FaceAuth"`
		AuthMethodResult string `json:"AuthMethodResult"`
		PassWdAuth       string `json:"PassWdAuth"`
		IsPayeeLD        string `json:"IsPayeeLD"`
		SimAuth          string `json:"SimAuth"`
		ConfidenceLevel  string `json:"ConfidenceLevel"`
		UkeyAuth         string `json:"UkeyAuth"`
		DigitalSignAuth  string `json:"DigitalSignAuth"`
		FingerPrintAuth  string `json:"FingerPrintAuth"`
		AntiFrautResult  string `json:"AntiFrautResult"`
		SMSAuth          string `json:"SMSAuth"`
		IsPayeeExist     string `json:"IsPayeeExist"`
	} `json:"RspBody"`
}

type checkBlackPayeeAcctNoReq struct {
	AcctNo      string `json:"AcctNo"`
	Amount      string `json:"Amount"`
	PayeeAcctNo string `json:"PayeeAcctNo"`
}
type checkBlackPayeeAcctNoResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		CheckResult string `json:"CheckResult"`
	} `json:"RspBody"`
}

type queryUserIsProtonReq struct {
	Amount           string `json:"Amount"`
	AuthenticateType string `json:"AuthenticateType"`
	UserID           string `json:"UserId"`
}
type queryUserIsOverLmtResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		LDLmtFlag     string `json:"LDLmtFlag"`
		LimtFlag      string `json:"LimtFlag"`
		LmtPerDay     string `json:"LmtPerDay"`
		UkeyLmtPerDay string `json:"UkeyLmtPerDay"`
	} `json:"RspBody"`
}

type sendMobilePwdTransferReq struct {
	PayeeAcctNo string `json:"PayeeAcctNo"`
	PayeeName   string `json:"PayeeName"`
	RemitAcctNo string `json:"RemitAcctNo"`
	RemitAmount string `json:"RemitAmount"`
	RemitType   string `json:"RemitType"`
	Remitter    string `json:"Remitter"`
}
type sendMobilePwdTransferResp struct {
	RspHeader respHeader        `json:"RspHeader"`
	RspBody   map[string]string `json:"RspBody"`
}

type netTransferOutToBankReq struct {
	AcctNo           string `json:"AcctNo"`
	AcctType         string `json:"AcctType"`
	Amount           string `json:"Amount"`
	AuthMethodResult string `json:"AuthMethodResult"`
	CheckSimFlag     string `json:"CheckSimFlag"`
	CmccSignFlag     string `json:"CmccSignFlag"`
	MobilePasswd     string `json:"MobilePasswd"`
	Password         string `json:"Password"`
	PayPurpose       string `json:"PayPurpose"`
	PayeeAcctNo      string `json:"PayeeAcctNo"`
	PayeeBankNo      string `json:"PayeeBankNo"`
	PayeeName        string `json:"PayeeName"`
	PostScript       string `json:"PostScript"`
	SimTransNo       string `json:"SimTransNo"`
	Signature        string `json:"signature"`
}
type netTransferOutToBankResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		SeqNo              string `json:"SeqNo"`
		BusinessID         string `json:"BusinessId"`
		NetAutoRequestFlag string `json:"NetAutoRequestFlag"`
	} `json:"RspBody"`
}

type transferInBankReq struct {
	AcctNo        string `json:"AcctNo"`
	Amount        string `json:"Amount"`
	CanUseBalance string `json:"CanUseBalance"`
	CheckSimFlag  string `json:"CheckSimFlag"`
	CmccSignFlag  string `json:"CmccSignFlag"`
	MobilePasswd  string `json:"MobilePasswd"`
	Password      string `json:"Password"`
	PayeeAcctNo   string `json:"PayeeAcctNo"`
	PayeeAcctType string `json:"PayeeAcctType"`
	PayeeName     string `json:"PayeeName"`
	PostScript    string `json:"PostScript"`
	SimTransNo    string `json:"SimTransNo"`
	TransID       string `json:"TransId"`
	Signature     string `json:"signature"`
}
type transferInBankResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AcctName      string `json:"AcctName"`
		AcctNo        string `json:"AcctNo"`
		AcctType      string `json:"AcctType"`
		Amount        string `json:"Amount"`
		Charge        string `json:"Charge"`
		PDTLSQ        string `json:"PDTLSQ"` // 这个就是BusinessId
		PayeeAcctNo   string `json:"PayeeAcctNo"`
		PayeeAcctType string `json:"PayeeAcctType"`
		PayeeName     string `json:"PayeeName"`
		IsExistEpayee string `json:"isExistEpayee"`
	} `json:"RspBody"`
}

type remitOutResReq struct {
	AcctNo       string `json:"AcctNo"`
	Amount       string `json:"Amount"`
	Balance      string `json:"Balance"`
	CheckSimFlag string `json:"CheckSimFlag"`
	CmccSignFlag string `json:"CmccSignFlag"`
	Count        string `json:"Count"`
	DeptID       string `json:"DeptId"`
	DeptName     string `json:"DeptName"`
	EVoucherStr  string `json:"EVoucherStr"`
	MobilePasswd string `json:"MobilePasswd"`
	Password     string `json:"Password"`
	PayeeAcctNo  string `json:"PayeeAcctNo"`
	PayeeName    string `json:"PayeeName"`
	PostScript   string `json:"PostScript"`
	Purpose      string `json:"Purpose"`
	RemitFee     string `json:"RemitFee"`
	SimTransNo   string `json:"SimTransNo"`
	TotalAmount  string `json:"TotalAmount"`
	Signature    string `json:"signature"`
}

type remitOutResResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		PostScriptFee string `json:"PostScriptFee"`
		RemitFee      string `json:"RemitFee"`
		RemitNo       string `json:"RemitNo"`
		SuccessFlag   string `json:"SuccessFlag"`
	} `json:"RspBody"`
}

type queryNetTransferResReq struct {
	BusinessID string `json:"BusinessId"`
}
type queryNetTransferResResp struct {
	RspHeader respHeader `json:"RspHeader"`
	RspBody   struct {
		AcctNo            string `json:"AcctNo"`
		AcctNoType        string `json:"AcctNoType"`
		Amount            string `json:"Amount"`
		BusinessID        string `json:"BusinessId"`
		BusinessKind      string `json:"BusinessKind"`
		BusinessType      string `json:"BusinessType"`
		Charge            string `json:"Charge"`
		Currency          string `json:"Currency"`
		NetBusinessStatus string `json:"NetBusinessStatus"`
		NetFeeAcct        string `json:"NetFeeAcct"`
		PayPurpose        string `json:"PayPurpose"`
		PayeeAcct         string `json:"PayeeAcct"`
		PayeeAcctType     string `json:"PayeeAcctType"`
		PayeeBankName     string `json:"PayeeBankName"`
		PayeeBankNo       string `json:"PayeeBankNo"`
		PayeeName         string `json:"PayeeName"`
		PayerAcctNoType   string `json:"PayerAcctNoType"`
		PayerBankName     string `json:"PayerBankName"`
		PayerBankNo       string `json:"PayerBankNo"`
		PayerName         string `json:"PayerName"`
		PostScript        string `json:"PostScript"`
		ResultMsg         string `json:"ResultMsg"`
		SignAgreeNo       string `json:"SignAgreeNo"`
		TransDate         string `json:"TransDate"`
		TransKind         string `json:"TransKind"`
	} `json:"RspBody"`
}

type AFDSMonInfoUdtRtResp struct {
	RspHeader struct {
		ResponseMsg  string `json:"ResponseMsg"`
		ResponseCode string `json:"ResponseCode"`
	} `json:"RspHeader"`
	RspBody struct {
		SeqNo      string `json:"SeqNo"`
		ReturnCode string `json:"ReturnCode"`
	} `json:"RspBody"`
}

type keepSesAliveTransResp struct {
	ResponseCode string `json:"ResponseCode"`
	STATUS       string `json:"STATUS"`
	TransName    string `json:"TransName"`
	ResponseMsg  string `json:"ResponseMsg"`
	TransSeqNo   string `json:"TransSeqNo"`
	JSESSIONID   string `json:"JSESSIONID"`
}
