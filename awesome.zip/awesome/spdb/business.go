package spdb

import (
	"awesome/tools"
	"encoding/json"
	"net/url"
	"strings"

	"github.com/go-http-utils/headers"
)

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////初始化///////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
func (b *Bank) vesionRequest() {
	query := &url.Values{
		"action":       {"act083"},
		"mobileMac":    {b.UDID},
		"mobileType":   {"iPhone"},
		"version":      {appVersion},
		"appId":        {"1"},
		"devicedigest": {b.DeviceDigest},
		"os":           {"ios" + b.HardwareInfo.SystemVersion},
		"appversion":   {appVersion},
		"mode_name":    {strings.ReplaceAll(b.HardwareInfo.Model, " ", "_")},
		"isNew":        {"1"},
		"custId":       {b.CustID},
		"deviceInfo":   {b.deviceInfo()},
	}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")

	resp, err := tools.DoHTTPGet(b.Client, urlMobile, query, header)
	if err != nil {
		b.Errorf("vesionRequest err=%+v", err)
		return
	}

	b.Info("vesionRequest >>>>>>> " + string(resp))
}

func (b *Bank) initRequestPointRed() {
	query := &url.Values{
		"action": {"act079"},
	}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	resp, err := tools.DoHTTPGet(b.Client, urlMobile, query, header)
	if err != nil {
		b.Errorf("initRequestPointRed err=%+v", err)
		return
	}

	b.InfoJSON("initRequestPointRed >>>>>>> ", string(resp))
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////登陆////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

func (b *Bank) clientQueryMobileOpen() *clientQueryMobileOpenResp {
	respObj := &clientQueryMobileOpenResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "text/xml;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"TransId":    "ClientQueryMobileOpen",
			"MobileNo":   b.Account,
			"DeviceName": b.HardwareInfo.OwnerName,
		},
	}

	b.InfoReq("clientQueryMobileOpen req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("clientQueryMobileOpen enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlClientQueryMobileOpen, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("clientQueryMobileOpen DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("clientQueryMobileOpen deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("clientQueryMobileOpen >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("clientQueryMobileOpen Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) queryRSAInfo() *queryRsaInfoResp {
	respObj := &queryRsaInfoResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "text/xml;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"TransId":      "QueryRSAInfo",
			"QueryRSAName": "",
			"DeviceName":   b.HardwareInfo.OwnerName,
		},
	}

	b.InfoReq("queryRSAInfo req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryRSAInfo enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryRSAInfo, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryRSAInfo DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryRSAInfo deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryRSAInfo >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryRSAInfo Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) clientLogin(coreKeyModulus, netBankKeyModulus, ts string) (*clientLoginResp, string) {
	respObj := &clientLoginResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	// 密码加密
	// PassGuardTextField getValue
	pwd, err := b.enPwd(b.LoginPwd, coreKeyModulus, netBankKeyModulus, ts)
	if err != nil {
		b.Errorf("clientLogin enPwd err=%+v", err)
		return respObj, ""
	}
	// PassGuardTextField getOutputEbank4 这个是和普通密码加密不一样的 出问题了在解决
	//pdxbPwd, err := b.enPwd(b.LoginPwd, creditKeyModulus, netBankKeyModulus, ts)

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Platform":         "iPhone",
			"MobileNo":         b.Account,
			"DeviceType":       "0",
			"DeviceDigest":     b.DeviceDigest,
			"IdType":           "",
			"NewActiveXFlag":   "2",
			"WapTelNo":         "",
			"PDXBPassword":     "",
			"MobilePhoneModel": strings.ReplaceAll(b.HardwareInfo.Model, " ", "_"),
			"IdNo":             "",
			"SimplePwdFlag":    "0",
			"NewVersionFlag":   "0",
			"Password":         pwd,
			"DeviceName":       b.HardwareInfo.OwnerName,
			"IsRoot":           "0",
			"DynamicCode":      "",
			"TransId":          "ClientLogin",
			"OS_Version":       b.HardwareInfo.SystemVersion,
			"LoginWay":         "1",
			"Longtitude":       "0.000000",
			"Latitude":         "0.000000",
			"MobilePhoneBrand": "iPhone",
			"UserType":         b.UserType,
			"APP_Version":      cfBundleVersion,
			"IsSimulator":      "0",
			"ImageCoder":       "",
			"DeviceInfo":       b.deviceInfo(),
		},
	}

	b.InfoReq("clientLogin req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("clientLogin enReq err=%+v", err)
		return respObj, ""
	}

	resp, err := tools.DoHTTPPost(b.Client, urlClientLogin, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("clientLogin DoHTTPPost err=%+v", err)
		return respObj, ""
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("clientLogin deResp err=%+v", err)
		return respObj, ""
	}

	b.InfoJSON("clientLogin >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("clientLogin Unmarshal err=%+v", err)
	}
	return respObj, pwd
}

func (b *Bank) queryFastAuthOpenFlag() *queryFastAuthOpenFlagResp {
	respObj := &queryFastAuthOpenFlagResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody:   map[string]string{},
	}

	b.InfoReq("queryFastAuthOpenFlag req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryFastAuthOpenFlag enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryFastAuthOpenFlag, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryFastAuthOpenFlag DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryFastAuthOpenFlag deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryFastAuthOpenFlag >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryFastAuthOpenFlag Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) sendSMSPwdMsg() *sendSMSPwdMsgResp {
	respObj := &sendSMSPwdMsgResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody:   map[string]string{},
	}

	b.InfoReq("sendSMSPwdMsg req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("sendSMSPwdMsg enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlSendSMSPwdMsg, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("sendSMSPwdMsg DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("sendSMSPwdMsg deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("sendSMSPwdMsg >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("sendSMSPwdMsg Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) clientInitUser(tokenforClientlogin, pwd string) *clientInitUserResp {
	respObj := &clientInitUserResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "text/xml;charset=UTF-8")
	var req111 interface{}
	if pwd == "" {
		req111 = map[string]string{
			"TransId":             "ClientInitUser",
			"Platform":            "iPhone",
			"DeviceType":          "0",
			"MobileNo":            b.Account,
			"TokenforClientlogin": tokenforClientlogin,
		}
	} else {
		req111 = clientInitUserReq{
			APPVersion:          appVersion,
			DeviceDigest:        b.DeviceDigest,
			DeviceInfo:          b.deviceInfo(),
			DeviceType:          "0",
			DynamicCode:         "",
			IDNo:                "",
			IDType:              "",
			ImageCoder:          "",
			IsRoot:              "0",
			IsSimulator:         "0",
			Latitude:            "0.000000",
			LoginWay:            "1",
			Longtitude:          "0.000000",
			MobileNo:            b.Account,
			MobilePhoneBrand:    "iPhone",
			MobilePhoneModel:    strings.ReplaceAll(b.HardwareInfo.Model, " ", "_"),
			NewActiveXFlag:      "2",
			NewVersionFlag:      "0",
			OSVersion:           b.HardwareInfo.SystemVersion,
			PDXBPassword:        "",
			Password:            pwd,
			Platform:            "iPhone",
			SimplePwdFlag:       "0",
			TokenforClientlogin: tokenforClientlogin,
			TransID:             "ClientInitUser",
			UserType:            b.UserType,
			WapTelNo:            "",
		}
	}

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody:   req111,
	}

	b.InfoReq("clientInitUser req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("clientInitUser enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlClientInitUser, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("clientInitUser DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("clientInitUser deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("clientInitUser >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("clientInitUser Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) checkMobilePwd(code string) *clientLoginResp {
	respObj := &clientLoginResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "text/xml;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"DeviceInfo":       b.deviceInfo(),
			"DeviceDigest":     b.DeviceDigest,
			"AuthenticateType": "0",
			"DeviceType":       "0",
			"Scope":            "",
			"MobilePasswd":     code,
			"Platform":         "iPhone",
			"TransId":          "CheckMobilePwd",
		},
	}

	b.InfoReq("checkMobilePwd req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("checkMobilePwd enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlCheckMobilePwd, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("checkMobilePwd DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("checkMobilePwd deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("checkMobilePwd >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("checkMobilePwd Unmarshal err=%+v", err)
	}
	return respObj
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////余额////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
func (b *Bank) queryMyAccounts() *queryMyAccountsResp {
	respObj := &queryMyAccountsResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody:   map[string]string{},
	}

	b.InfoReq("queryMyAccounts req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryMyAccounts enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryMyAccounts, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryMyAccounts DoHTTPPost err=%+v", err)
		return respObj
	}

	// 需要解密
	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryMyAccounts deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryMyAccounts >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryMyAccounts Unmarshal err=%+v", err)
	}
	return respObj
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////账单////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
// 保持连接
func (b *Bank) keepSesAliveTrans() *keepSesAliveTransResp {
	respObj := &keepSesAliveTransResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	reqBody, err := b.transBody("", b.netWorkAndDeviceInfoAndDeviceDigest(),
		&map[string]string{
			"TransId": "KeepSesAliveTrans",
		})
	if err != nil {
		b.Errorf("keepSesAliveTrans transBody err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlTrans, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("keepSesAliveTrans DoHTTPPost err=%+v", err)
		return respObj
	}

	b.InfoJSON("keepSesAliveTrans >>>>>>> ", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		b.Errorf("keepSesAliveTrans Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) queryBillList(startDate, endDate string, index int) *queryBillListResp {
	respObj := &queryBillListResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: &map[string]interface{}{
			"AcctKind":      b.AcctKind,
			"AcctNo":        b.AcctNO,
			"Acctype":       b.AcctType,
			"BeginDate":     startDate,
			"BeginNumber":   "",
			"CrDtIndicator": "",
			"CurrencyNo":    "01",
			"CurrencyType":  "0",
			"EndDate":       endDate,
			"FundSortOrder": "1",
			"QueryNumber":   "10",
			"SpecialType":   "0",
			"currentIndex":  index,
		},
	}

	b.InfoReq("queryBillList req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryBillList enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryFiveDetails, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryBillList DoHTTPPost err=%+v", err)
		return respObj
	}

	// 需要解密
	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryBillList deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryBillList >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryBillList Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询账单详情 authNo或者BusinessId任意给一个就行
func (b *Bank) queryBillDetail(authNo, businessID string) *queryBillDetailResp {
	respObj := &queryBillDetailResp{}

	if authNo == "" && businessID == "" {
		return respObj
	}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req111 := &map[string]string{}
	u := ""
	if authNo != "" {
		(*req111)["AuthNo"] = authNo
		u = urlQueryRemitOutBankDetail
	} else {
		(*req111)["BusinessId"] = businessID
		u = urlQueryPaymentHistoryDetail
	}

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody:   req111,
	}

	b.InfoReq("queryBillDetail req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryBillDetail enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, u, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryBillDetail DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryMyAccounts deResp err=%+v", err)
		return respObj
	}
	b.InfoJSON("queryBillDetail >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryBillDetail Unmarshal err=%+v", err)
	}
	return respObj
}

////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////转账////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

func (b *Bank) querySIMSignStatus() *querySIMSignStatusResp {
	respObj := &querySIMSignStatusResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"IsFromTrans": "1",
			"QueryFlag":   "1",
		},
	}

	b.InfoReq("querySIMSignStatus req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("querySIMSignStatus enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQuerySIMSignStatus, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("querySIMSignStatus DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("querySIMSignStatus deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("querySIMSignStatus >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("querySIMSignStatus Unmarshal err=%+v", err)
	}
	return respObj
}

// 检测当前卡状态，里面有余额
func (b *Bank) checkPaymentCardStatus() *checkPaymentCardStatusResp {
	respObj := &checkPaymentCardStatusResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"CurrencyType": "0",
			"TranAmt":      "0.01", // 代码中这里居然是写死的
			"CurrencyNo":   "01",
			"ClientAcctNo": b.AcctNO,
			"AcctType":     b.AcctType,
		},
	}

	b.InfoReq("checkPaymentCardStatus req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("checkPaymentCardStatus enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlCheckPaymentCardStatus, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("checkPaymentCardStatus DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("checkPaymentCardStatus deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("checkPaymentCardStatus >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("checkPaymentCardStatus Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询银行
func (b *Bank) queryBankByAcctNo(destCardNo string) *queryBankByAcctNoResp {
	respObj := &queryBankByAcctNoResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"AcctNo": destCardNo,
		},
	}

	b.InfoReq("queryBankByAcctNo req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryBankByAcctNo enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryBankByAcctNo, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryBankByAcctNo DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryBankByAcctNo deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryBankByAcctNo >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryBankByAcctNo Unmarshal err=%+v", err)
	}
	return respObj
}

// 小银行查询银行
func (b *Bank) querySmallBank(bankPaymentLevel, cityID string) *querySmallBankResp {
	respObj := &querySmallBankResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"DeptName":         "",
			"BankPaymentLevel": bankPaymentLevel,
			"CityId":           cityID,
		},
	}
	b.InfoReq("querySmallBank req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("querySmallBank enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryDeptList, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("querySmallBank DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("querySmallBank deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("querySmallBank >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("querySmallBank Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询手续费
func (b *Bank) netQueryCharge(amount, transType string) *netQueryChargeResp {
	respObj := &netQueryChargeResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"AcctNo":    b.AcctNO,
			"Amount":    amount,
			"TransType": transType,
		},
	}

	b.InfoReq("netQueryCharge req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("netQueryCharge enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlNetQueryCharge, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("netQueryCharge DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("netQueryCharge deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("netQueryCharge >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("netQueryCharge Unmarshal err=%+v", err)
	}
	return respObj
}

// 小银行转账查询手续费
func (b *Bank) remitOutCharge(destCardNo, amount, remark, deptID, deptName string) *remitOutChargeResp {
	respObj := &remitOutChargeResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: remitOutChargeReq{
			AcctNo:      b.AcctNO,
			Amount:      amount,
			Balance:     b.balance,
			DeptID:      deptID,
			DeptName:    deptName,
			PayeeAcctNo: destCardNo,
			PostScript:  remark,
		},
	}

	b.InfoReq("remitOutCharge req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("remitOutCharge enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlRemitOutCharge, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("remitOutCharge DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("remitOutCharge deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("remitOutCharge >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("remitOutCharge Unmarshal err=%+v", err)
	}
	return respObj
}

// 同行转账查询手续费
func (b *Bank) transferInBankConfirm(destCardNo, destName, amount, remark string) *transferInBankConfirmResp {
	respObj := &transferInBankConfirmResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Amount":        amount,
			"AcctNo":        b.AcctNO,
			"PostScript":    remark,
			"CanUseBalance": b.balance,
			"SubmitBtn2":    "123",
			"PayeeName":     destName,
			"PayeeAcctType": "1",
			"PayeeAcctNo":   destCardNo,
		},
	}

	b.InfoReq("transferInBankConfirm req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("transferInBankConfirm enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlTransferInBankConfirm, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("transferInBankConfirm DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("transferInBankConfirm deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("transferInBankConfirm >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("transferInBankConfirm Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) queryAuthMethod(amount, destBankNo, destCardNo, destName string) *queryAuthMethodResp {
	respObj := &queryAuthMethodResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Amount":          amount,
			"AcctNo":          b.AcctNO,
			"PayeeBankNo":     destBankNo,
			"SendFlag":        "2",
			"Currency":        "01",
			"NetTransferFlag": "1",
			"AcctType":        b.AcctType,
			"currCerStatus":   "1",
			"PayeeAcct":       destCardNo,
			"PayeeName":       destName,
		},
	}

	b.InfoReq("queryAuthMethod req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryAuthMethod enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlAuthMethodQry, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryAuthMethod DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryAuthMethod deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryAuthMethod >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryAuthMethod Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询对方是不是黑名单
func (b *Bank) checkBlackPayeeAcctNo(amount, destCardNo string) *checkBlackPayeeAcctNoResp {
	respObj := &checkBlackPayeeAcctNoResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"AcctNo":      b.AcctNO,
			"Amount":      amount,
			"PayeeAcctNo": destCardNo,
		},
	}

	b.InfoReq("checkBlackPayeeAcctNo req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("checkBlackPayeeAcctNo enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlCheckBlackPayeeAcctNo, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("checkBlackPayeeAcctNo DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("checkBlackPayeeAcctNo deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("checkBlackPayeeAcctNo >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("checkBlackPayeeAcctNo Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询限额
func (b *Bank) queryUserIsOverLmt(amount string) *queryUserIsOverLmtResp {
	respObj := &queryUserIsOverLmtResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Amount": amount,
			"UserId": b.MasterID,
		},
	}

	b.InfoReq("queryUserIsOverLmt req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryUserIsOverLmt enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryUserIsOverLmt, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryUserIsOverLmt DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryUserIsOverLmt deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryUserIsOverLmt >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryUserIsOverLmt Unmarshal err=%+v", err)
	}
	return respObj
}

// validation.afds.error
func (b *Bank) AFDSMonInfoUdtRt(destBankNO, destCardNO, destName, amount string) *AFDSMonInfoUdtRtResp {
	respObj := &AFDSMonInfoUdtRtResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"AcctNo":       b.AcctNO,
			"AcctType":     b.AcctType,
			"Amount":       amount,
			"CheckSimFlag": "",
			"Currency":     "01",
			"PayeeAcct":    destCardNO,
			"PayeeBankNo":  destBankNO,
			"PayeeName":    destName,
			"SendFlag":     "2",
		},
	}

	b.InfoReq("AFDSMonInfoUdtRt req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("AFDSMonInfoUdtRt enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlAFDSMonInfoUdtRt, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("AFDSMonInfoUdtRt DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("AFDSMonInfoUdtRt deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("AFDSMonInfoUdtRt >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryUserIsProton Unmarshal err=%+v", err)
	}
	return respObj
}

// 发送短信验证码
func (b *Bank) sendMobilePwdTransfer(destCardNo, destName, amount, remitType string) *sendMobilePwdTransferResp {
	respObj := &sendMobilePwdTransferResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"RemitAcctNo": b.AcctNO,
			"PayeeAcctNo": destCardNo,
			"RemitType":   remitType,
			"RemitAmount": amount,
			"Remitter":    b.AcctName,
			"PayeeName":   destName,
		},
	}

	b.InfoReq("sendMobilePwdTransfer req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("sendMobilePwdTransfer enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlSendMobilePwdTransfer, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("sendMobilePwdTransfer DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("sendMobilePwdTransfer deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("sendMobilePwdTransfer >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("sendMobilePwdTransfer Unmarshal err=%+v", err)
	}
	return respObj
}

// 提交短信和交易密码
func (b *Bank) netTransferOutToBank(smsCode, coreKeyModulus, netBankKeyModulus, ts, destCardNo, destName, destBankNo, amount, remark string) *netTransferOutToBankResp {
	respObj := &netTransferOutToBankResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	pwd, err := b.enPwd(b.PayPwd, coreKeyModulus, netBankKeyModulus, ts)
	if err != nil {
		b.Errorf("netTransferOutToBank enPwd err=%+v", err)
		return respObj
	}

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Amount":           amount,
			"SimTransNo":       "",
			"PostScript":       remark,
			"CmccSignFlag":     "N",
			"PayeeName":        destName,
			"Password":         pwd,
			"CheckSimFlag":     "",
			"PayeeAcctNo":      destCardNo,
			"MobilePasswd":     smsCode,
			"AcctType":         b.AcctType,
			"PayPurpose":       "0",
			"Signature":        "",
			"AcctNo":           b.AcctNO,
			"PayeeBankNo":      destBankNo,
			"AuthMethodResult": b.authMethodResult,
		},
	}

	b.InfoReq("netTransferOutToBank req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("netTransferOutToBank enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlNetTransferOutToBank, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("netTransferOutToBank DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("netTransferOutToBank deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("netTransferOutToBank >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("netTransferOutToBank Unmarshal err=%+v", err)
	}
	return respObj
}

// 查询转账状态
func (b *Bank) queryNetTransferRes(businessID string) *queryNetTransferResResp {
	respObj := &queryNetTransferResResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"BusinessId": businessID + "type=sshk",
		},
	}

	b.InfoReq("queryNetTransferRes req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("queryNetTransferRes enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlQueryNetTransferRes, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("queryNetTransferRes DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("queryNetTransferRes deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("queryNetTransferRes >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("queryNetTransferRes Unmarshal err=%+v", err)
	}
	return respObj
}

// 小银行提交短信和交易密码
func (b *Bank) remitOutRes(smsCode, coreKeyModulus, netBankKeyModulus, ts, destCardNo, destName, deptID, deptName, amount, remark string) *remitOutResResp {
	respObj := &remitOutResResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	pwd, err := b.enPwd(b.PayPwd, coreKeyModulus, netBankKeyModulus, ts)
	if err != nil {
		b.Errorf("remitOutRes enPwd err=%+v", err)
		return respObj
	}

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: remitOutResReq{
			AcctNo:       b.AcctNO,
			Amount:       b.amount,
			Balance:      b.balance,
			CheckSimFlag: "",
			CmccSignFlag: "N",
			Count:        "0",
			DeptID:       deptID,
			DeptName:     deptName,
			EVoucherStr:  "",
			MobilePasswd: smsCode,
			Password:     pwd,
			PayeeAcctNo:  destCardNo,
			PayeeName:    destName,
			PostScript:   remark,
			Purpose:      "划款",
			RemitFee:     "0.00",
			SimTransNo:   "",
			TotalAmount:  "",
			Signature:    "",
		},
	}

	b.InfoReq("remitOutRes req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("remitOutRes enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlRemitOutRes, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("remitOutRes DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("remitOutRes deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("remitOutRes >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("remitOutRes Unmarshal err=%+v", err)
	}
	return respObj
}

// 同行提交短信和交易密码
func (b *Bank) transferInBank(smsCode, coreKeyModulus, netBankKeyModulus, ts, destCardNo, destName, amount, remark string) *transferInBankResp {
	respObj := &transferInBankResp{}

	header := b.baseHeader()
	header.Set(headers.ContentType, "application/json;charset=UTF-8")

	pwd, err := b.enPwd(b.PayPwd, coreKeyModulus, netBankKeyModulus, ts)
	if err != nil {
		b.Errorf("transferInBank enPwd err=%+v", err)
		return respObj
	}

	req := &baseReq{
		ReqHeader: b.baseReqHeader(),
		ReqBody: map[string]string{
			"Amount":           amount,
			"SimTransNo":       "",
			"PostScript":       remark,
			"CmccSignFlag":     "N",
			"PayeeName":        destName,
			"PayeeAcctType":    "1",
			"Password":         pwd,
			"CheckSimFlag":     "",
			"PayeeAcctNo":      destCardNo,
			"MobilePasswd":     smsCode,
			"Signature":        "",
			"TransID":          "TransferInBank",
			"AcctNo":           b.AcctNO,
			"CanUseBalance":    b.balance,
			"AuthMethodResult": b.authMethodResult,
		},
	}

	b.InfoReq("transferInBank req=", req)

	reqBody, err := b.enReq(req)
	if err != nil {
		b.Errorf("transferInBank enReq err=%+v", err)
		return respObj
	}

	resp, err := tools.DoHTTPPost(b.Client, urlTransferInBank, nil, header, []byte(reqBody))
	if err != nil {
		b.Errorf("transferInBank DoHTTPPost err=%+v", err)
		return respObj
	}

	respData, err := b.deResp(resp)
	if err != nil {
		b.Errorf("transferInBank deResp err=%+v", err)
		return respObj
	}

	b.InfoJSON("transferInBank >>>>>>> ", string(respData))

	err = json.Unmarshal(respData, respObj)
	if err != nil {
		b.Errorf("transferInBank Unmarshal err=%+v", err)
	}
	return respObj
}
