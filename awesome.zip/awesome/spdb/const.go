package spdb

import (
	"crypto/rsa"
	"math/big"
)

const (
	appVersion      = "10.84"
	cfBundleVersion = "20210601203038"

	urlMobile = "https://wap.spdb.com.cn/cmnet/mobile.shtml"
	urlTrans  = "https://wap.spdb.com.cn/pmclient/svt/transservlet.shtml"
	urlETrksw = "https://databank.spdb.com.cn/etrksw/"
	urlETrack = "https://databank.spdb.com.cn/etrack/"

	urlClientQueryMobileOpen     = "https://wap.spdb.com.cn/mspmk-web-login/ClientQueryMobileOpen.ah"
	urlQueryRSAInfo              = "https://wap.spdb.com.cn/mspmk-web-basics/QueryRSAInfo.ah"
	urlClientLogin               = "https://wap.spdb.com.cn/mspmk-web-login/ClientLogin.ah"
	urlQueryFastAuthOpenFlag     = "https://wap.spdb.com.cn/mspmk-web-management/QueryFastAuthOpenFlag.ah"
	urlSendSMSPwdMsg             = "https://wap.spdb.com.cn/mspmk-web-login/SendSMSPwdMsg.ah"
	urlCheckMobilePwd            = "https://wap.spdb.com.cn/mspmk-web-login/CheckMobilePwd.ah"
	urlClientInitUser            = "https://wap.spdb.com.cn/mspmk-web-login/ClientInitUser.ah"
	urlQueryMyAccounts           = "https://wap.spdb.com.cn/mspmk-web-accountcenter/QueryMyAccounts.ah"
	urlQueryFiveDetails          = "https://wap.spdb.com.cn/mspmk-web-accountcenter/QueryFiveDetails.ah"
	urlQueryPaymentHistoryDetail = "https://wap.spdb.com.cn/mspmk-web-account/QueryPaymentHistoryDetail.ah"
	urlQueryRemitOutBankDetail   = "https://wap.spdb.com.cn/mspmk-web-account/QueryRemitOutBankDetail.ah"
	urlQueryDeptList             = "https://wap.spdb.com.cn/mspmk-web-transfer/QueryDeptList.ah"
	urlQueryBankByAcctNo         = "https://wap.spdb.com.cn/mspmk-web-transfer/QueryBankByAcctNo.ah"
	urlQuerySIMSignStatus        = "https://wap.spdb.com.cn/mspmk-web-transfer/QuerySIMSignStatus.ah"
	urlCheckPaymentCardStatus    = "https://wap.spdb.com.cn/mspmk-web-transfer/CheckPaymentCardStatus.ah"
	urlNetQueryCharge            = "https://wap.spdb.com.cn/mspmk-web-transfer/NetQueryCharge.ah"
	urlRemitOutCharge            = "https://wap.spdb.com.cn/mspmk-web-transfer/RemitOutCharge.ah"
	urlTransferInBankConfirm     = "https://wap.spdb.com.cn/mspmk-web-transfer/TransferInBankConfirm.ah"
	urlCheckBlackPayeeAcctNo     = "https://wap.spdb.com.cn/mspmk-web-transfer/CheckBlackPayeeAcctNo.ah"
	urlQueryUserIsOverLmt        = "https://wap.spdb.com.cn/mspmk-web-transfer/QueryUserIsOverLmt.ah"
	urlSendMobilePwdTransfer     = "https://wap.spdb.com.cn/mspmk-web-transfer/SendMobilePwdTransfer.ah"
	urlNetTransferOutToBank      = "https://wap.spdb.com.cn/mspmk-web-transfer/NetTransferOutToBank.ah"
	urlRemitOutRes               = "https://wap.spdb.com.cn/mspmk-web-transfer/RemitOutRes.ah"
	urlTransferInBank            = "https://wap.spdb.com.cn/mspmk-web-transfer/TransferInBank.ah"
	urlQueryNetTransferRes       = "https://wap.spdb.com.cn/mspmk-web-transfer/QueryNetTransferRes.ah"
	urlAFDSMonInfoUdtRt          = "https://wap.spdb.com.cn/mspmk-web-transfer/AFDSMonInfoUdtRt.ah"
	urlAuthMethodQry             = "https://wap.spdb.com.cn/mspmk-web-transferauth/AuthMethodQry.ah"
	successCode                  = "AAAAAAA"
)

var rsaPubKey *rsa.PublicKey

func init() {
	rsaPubKey = &rsa.PublicKey{}
	rsaPubKey.N, _ = new(big.Int).SetString("D9981D3E83CC2D0E7CE8869EEF3CD73F6A987BC7CB97F078E3502A10AD560B1DE62895"+
		"482C324437551A1606B8B1535E653964FB9638C87FE212ECCC592ACD6320CE32D86FAE87D0D60B463E5CAC0B1F6C32CEB5C20601BB08D"+
		"2DCA85107220719254AD971964B2A8D98D106C3EC64D4E263851D724C635C63B0E3729DCD5B13", 16)
	rsaPubKey.E = 65537

}
