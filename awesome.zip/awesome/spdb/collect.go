package spdb

import (
	"awesome/tools"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/go-http-utils/headers"
)

func (b *Bank) collectStart() {
	header := b.baseHeader()
	(*header)["channel"] = []string{"08"}
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	resp, err := tools.DoHTTPPost(b.Client, urlETrksw, nil, header, nil)
	if err != nil {
		b.Errorf("etrksw err=%+v", err)
		return
	}

	b.Info("etrksw >>>>>>> " + string(resp))
}

func (b *Bank) appDelegate() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	t := uint32(b.StartTimeStamp/1000) - tools.Timestamp()
	c := &map[string]interface{}{
		"event_type":  "BTN",
		"event_value": "活跃统计-前端显示",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/AppDelegate.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "启动页",
		"event_context": map[string]string{
			"from":          "启动页",
			"appversion":    appVersion,
			"PfMasterId":    b.MasterID,
			"PfStartTime":   b.StartTime,
			"PfDisplayTime": strconv.Itoa(int(t)),
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("appDelegate err=%+v", err)
		return
	}

	b.Info("appDelegate >>>>>>> " + string(resp))
}

func (b *Bank) home() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "TAB",
		"event_value": "我的",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Root/PNCRootTabBarController.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "启动页",
		"event_context": map[string]string{
			"from":       "我的",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("home err=%+v", err)
		return
	}

	b.Info("home >>>>>>> " + string(resp))
}

func (b *Bank) preLogin() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "BTN",
		"event_value": "登录-预登录",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Login/SPDBLoginViewController.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "登录",
		"event_context": map[string]string{
			"from":       "登录",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("preLogin err=%+v", err)
		return
	}

	b.Info("preLogin >>>>>>> " + string(resp))
}

func (b *Bank) alertAnswer() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "ALERTBTN",
		"event_value": "接听动态密码",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Base/newAlertView/UIAlertView+ShowAlert.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "系统提示",
		"event_context": map[string]string{
			"from":       "系统提示",
			"appversion": appVersion,
			"alert_msg":  "动态密码将通过95528电话语音外呼向您播报。",
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("alertAnswer err=%+v", err)
		return
	}

	b.Info("alertAnswer >>>>>>> " + string(resp))
}

func (b *Bank) binding() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "BindingInterfaceViewController",
		"event_value": "设备绑定_接听动态密码",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m_SheBeiBangDing_JieTingDongTaiMiMa",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m",
		"event_context": map[string]string{
			"from":       "首页",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("binding err=%+v", err)
		return
	}

	b.Info("binding >>>>>>> " + string(resp))
}

func (b *Bank) alertConfirm() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "ALERTBTN",
		"event_value": "确定",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "PNCBank/PNCBank/PNCBank/ViewController/Base/newAlertView/UIAlertView+ShowAlert.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": fmt.Sprintf("您尾号为%s的手机号码将接到95528的来电，请及时接听", b.Account[len(b.Account)-4:]),
		"event_context": map[string]string{
			"from":       fmt.Sprintf("您尾号为%s的手机号码将接到95528的来电，请及时接听", b.Account[len(b.Account)-4:]),
			"appversion": appVersion,
			"alert_msg":  "",
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("alertConfirm err=%+v", err)
		return
	}

	b.Info("alertConfirm >>>>>>> " + string(resp))
}

func (b *Bank) inputCode() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "BindingInterfaceViewController",
		"event_value": "设备绑定_动态码输入",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m_SheBeiBangDing_DongTaiMaShuRu",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m",
		"event_context": map[string]string{
			"from":       "设备绑定",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("inputCode err=%+v", err)
		return
	}

	b.Info("inputCode >>>>>>> " + string(resp))
}

func (b *Bank) confirmCode() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "BindingInterfaceViewController",
		"event_value": "设备绑定_确认",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m_SheBeiBangDing_QueRen",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "/PNCBank/PNCBank/PNCBank/ViewController/Login/BindingInterface/BindingInterfaceViewController.m",
		"event_context": map[string]string{
			"from":       "设备绑定",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("confirmCode err=%+v", err)
		return
	}

	b.Info("confirmCode >>>>>>> " + string(resp))
}

func (b *Bank) login() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "BTN",
		"event_value": "登录-登录",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Login/SPDBLoginViewController.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "登录",
		"event_context": map[string]string{
			"login_type": "密码",
			"from":       "登录",
			"appversion": appVersion,
		},
		"session_id": "",
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": "",
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("confirmCode err=%+v", err)
		return
	}

	b.Info("confirmCode >>>>>>> " + string(resp))
}

func (b *Bank) loginSuccess() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "",
		"event_value": "",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "https://wap.spdb.com.cn/mspmk-cli-customerchannel/#/MyChannel/ChannelHome",
		"event":    "pageLoad",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "登录",
		"event_context": map[string]string{
			"startLoad_time": tools.TimeFmtEx4(),
			"appversion":     appVersion,
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("confirmCode err=%+v", err)
		return
	}

	b.Info("confirmCode >>>>>>> " + string(resp))
}

func (b *Bank) shouye() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "TAB",
		"event_value": "首页",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/Root/PNCRootTabBarController.m",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "首页",
		"event_context": map[string]string{
			"appversion": appVersion,
			"from":       "我的",
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("shouye err=%+v", err)
		return
	}

	b.Info("shouye >>>>>>> " + string(resp))
}

func (b *Bank) menu() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "10_首页_菜单_点击",
		"event_value": "DanJi_CaiDan_ShouYe",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "/PNCBank/PNCBank/PNCBank/ViewController/DynamicUI/managerModel/JumpHelp/MenuJumpHelp.m_CD",
		"event":    "click",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "/PNCBank/PNCBank/PNCBank/ViewController/DynamicUI/managerModel/JumpHelp/MenuJumpHelp.m",
		"event_context": map[string]string{
			"from":         "首页菜单我的账户",
			"appversion":   appVersion,
			"id":           "10_首页_菜单_点击",
			"menu_name":    "我的账户",
			"menu_picture": "new_wodezhanghu.png",
			"menu_url":     "appNew/01/01_M_new.jsp?OsType=@osType&APP_VERSION=@appVersion&from=shouye",
			"menu_code":    "MB0003",
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("menu err=%+v", err)
		return
	}

	b.Info("menu >>>>>>> " + string(resp))
}

func (b *Bank) appNew() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	c := &map[string]interface{}{
		"event_type":  "",
		"event_value": "",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "appNew/01/01_M_new.jsp",
		"event":    "pageLoad",
		"time":     tools.TimeFmtEx4(),
		"url":      "",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "",
		"event_context": map[string]string{
			"appversion":     appVersion,
			"startLoad_time": tools.TimeFmtEx4(),
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("menu err=%+v", err)
		return
	}

	b.Info("menu >>>>>>> " + string(resp))
}

func (b *Bank) pageTime() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	width := strconv.Itoa(tools.ScreenWidthPt(b.HardwareInfo.SystemVersion))
	height := strconv.Itoa(tools.ScreenHeightPt(b.HardwareInfo.SystemVersion))
	version, _ := strconv.Atoi(appVersion)
	c := &map[string]interface{}{
		"event_type":  "pageTime",
		"event_value": "",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "appNew/01/01_M_new.jsp",
		"event":    "pageTime",
		"time":     tools.TimeFmtEx4(),
		"url":      "https://wap.spdb.com.cn/pmclient/appNew/01/01_M_new.jsp",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "我的账户-账户总览",
		"event_context": map[string]interface{}{
			"webviewOffsetY": "0.00",
			"onload":         tools.TimestampEx() - int64(tools.RandIntn(30000)),
			"auto_flag":      1,
			"referrer":       "",
			"unload":         tools.TimestampEx(),
			"appversion":     version,
			"webviewWidth":   width,
			"webviewOffsetX": "0.00",
			"clientWidth":    width,
			"clientHeight":   height,
			"webviewHeight":  height,
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	resp, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("pageTime err=%+v", err)
		return
	}

	b.Info("pageTime >>>>>>> " + string(resp))
}

func (b *Bank) touch() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	w := tools.ScreenWidthPt(b.HardwareInfo.SystemVersion)
	width := strconv.Itoa(w)
	h := tools.ScreenHeightPt(b.HardwareInfo.SystemVersion)
	height := strconv.Itoa(h)

	px := 185 + tools.RandIntn(15)
	py := 360 + tools.RandIntn(30)
	cx := 360 + tools.RandIntn(30)
	cy := 185 + tools.RandIntn(15)
	version, _ := strconv.Atoi(appVersion)
	c := &map[string]interface{}{
		"event_type":  "touchstart",
		"event_value": "",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "appNew/01/01_M_new.jsp",
		"event":    "touchstart",
		"time":     tools.TimeFmtEx4(),
		"url":      "https://wap.spdb.com.cn/pmclient/appNew/01/01_M_new.jsp",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "我的账户-账户总览",
		"event_context": map[string]interface{}{
			"webviewOffsetY": "0.00",
			"onload":         tools.TimestampEx() - int64(tools.RandIntn(30000)),
			"auto_flag":      1,
			"referrer":       "",
			"unload":         tools.TimestampEx(),
			"appversion":     version,
			"webviewWidth":   width,
			"webviewOffsetX": "0.00",
			"clientWidth":    width,
			"clientHeight":   height,
			"webviewHeight":  height,
			"contentHeight":  h,
			"contentWidth":   w,
			"pageX":          px,
			"pageY":          py,
			"clientY":        cy,
			"clientX":        cx,
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	_, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("touchstart err=%+v", err)
		return
	}

	c = &map[string]interface{}{
		"event_type":  "touchend",
		"event_value": "",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "appNew/01/01_M_new.jsp",
		"event":    "touchend",
		"time":     tools.TimeFmtEx4(),
		"url":      "https://wap.spdb.com.cn/pmclient/appNew/01/01_M_new.jsp",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "我的账户-账户总览",
		"event_context": map[string]interface{}{
			"webviewOffsetY": "0.00",
			"onload":         tools.TimestampEx() - int64(tools.RandIntn(30000)),
			"auto_flag":      1,
			"referrer":       "",
			"unload":         tools.TimestampEx(),
			"appversion":     version,
			"webviewWidth":   width,
			"webviewOffsetX": "0.00",
			"clientWidth":    width,
			"clientHeight":   height,
			"webviewHeight":  height,
			"contentHeight":  h,
			"contentWidth":   w,
			"pageX":          px,
			"pageY":          py,
			"clientY":        cy,
			"clientX":        cx,
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ = json.Marshal(c)

	_, err = tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("touchend err=%+v", err)
		return
	}
}

func (b *Bank) slide() {
	header := b.baseHeader()
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")

	w := tools.ScreenWidthPt(b.HardwareInfo.SystemVersion)
	width := strconv.Itoa(w)
	h := tools.ScreenHeightPt(b.HardwareInfo.SystemVersion)
	height := strconv.Itoa(h)

	version, _ := strconv.Atoi(appVersion)
	c := &map[string]interface{}{
		"event_type":  "pageEnd",
		"event_value": "滑到底部",
		"position": map[string]string{
			"longitude": "",
			"latitude":  "",
		},
		"channel":  "08",
		"page_tag": "appNew/WDZH_NEW/bankCardDetail.jsp",
		"event":    "pageEnd",
		"time":     tools.TimeFmtEx4(),
		"url":      "https://wap.spdb.com.cn/pmclient/appNew/WDZH_NEW/bankCardDetail.jsp",
		"browser": map[string]string{
			"browser_lang":    "zh-Hans-CN",
			"browser_name":    "AppleWebKit",
			"browser_version": "605.1.15",
		},
		"view": "账户详情",
		"event_context": map[string]interface{}{
			"webviewHeight":  height,
			"webviewWidth":   width,
			"appversion":     version,
			"webviewOffsetX": "0.00",
			"clientWidth":    width,
			"clientHeight":   height,
			"webviewOffsetY": "0.00",
		},
		"session_id": b.sessionID,
		"client": map[string]string{
			"os":   "iOS " + b.HardwareInfo.SystemVersion,
			"mac":  "02:00:00:00:00:00",
			"ip":   b.IPAddr,
			"imei": b.IMEI,
		},
		"user": map[string]string{
			"master_id": b.MasterID,
			"user_mark": fmt.Sprintf("%d%s", b.StartTimeStamp, b.UDID),
		},
		"event_object": "",
	}

	data, _ := json.Marshal(c)

	_, err := tools.DoHTTPPost(b.Client, urlETrack, nil, header, data)
	if err != nil {
		b.Errorf("slide err=%+v", err)
		return
	}
}
