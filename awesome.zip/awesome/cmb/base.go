package cmb

import (
	"awesome/tools"
	"awesome/tools/gmsm/sm3"
	"bytes"
	"crypto/hmac"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"github.com/robertkrimen/otto"
	"io/ioutil"
	"net/http"
	"sort"
	"strconv"
	"strings"

	"github.com/go-http-utils/headers"
)

var secBase64Encoder *base64.Encoding

func init() {
	secBase64Encoder = base64.NewEncoding("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789*-").WithPadding('_')
}

func hmacSha1AndB64(in string, key string) string {
	hmac1 := hmac.New(sha1.New, []byte(key))
	hmac1.Write([]byte(in))
	md := hmac1.Sum(nil)
	return base64.StdEncoding.EncodeToString(md)
}

func hmacSm3(in string, key string) string {
	hmac1 := hmac.New(sm3.New, []byte(key))
	hmac1.Write([]byte(in))
	md := hmac1.Sum(nil)
	return fmt.Sprintf("%x", md)
}

// 对aes key 进行的加密
func rsaEncryptWithClientNo(in, clientNo string) string {
	prefix := "11111"
	if len(clientNo) > 5 {
		prefix = clientNo[len(clientNo)-5:]
	}
	in = "AAA" + prefix + in
	out, _ := tools.RSAEncrypt([]byte(in), rsaPasswordPub)
	return secBaseEncode(out)
}

// 对sm4 key 进行的加密
func sm2Encrypt(in string) string {
	out, _ := tools.SM2Encrypt([]byte(in), sm2PubX, sm2PubY)
	return base64.StdEncoding.EncodeToString(out)
}

func sm2EncryptWithSid(in, sid string) string {
	in = "AAAB" + sid[len(sid)-5:] + tools.RandString(3) + in
	out, _ := tools.SM2Encrypt([]byte(in), sm2PasswordPubX, sm2PasswordPubY)
	return fmt.Sprintf("%X", out)
}

func secBaseEncode(in []byte) string {
	return secBase64Encoder.EncodeToString(in)
}

func aesEcbEncryptUse2018Key(in []byte) []byte {
	aesKey := aes2018Key + string(bytes.Repeat([]byte{0x30}, 32-len(aes2018Key)))
	en, _ := tools.AESECBEncrypt(in, []byte(aesKey))
	return en
}

func sm4CBCEncryptUseLogKey(in []byte) string {
	en, _ := tools.SM4CBCEncrypt(in, []byte(sm4LogKey), []byte(sm4LogKey))
	return base64.StdEncoding.EncodeToString(en)
}

//func jsonMarshal(t interface{}) ([]byte, error) {
//	buffer := &bytes.Buffer{}
//	encoder := json.NewEncoder(buffer)
//	encoder.SetEscapeHTML(false)
//	err := encoder.Encode(t)
//	return buffer.Bytes(), err
//}

func (b *Bank) userAgent() string {
	apptag := 20
	if tools.IsPhoneX(b.HardwareInfo.Model) {
		apptag = 40
	}
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")

	return fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MPBank/%s iPhone/%s Scale/2.0 AID/%s SID/%s WebView/WKWebView APPTag/1.0(N;%d;LIGHT;1.0;321)",
		sysVer, cfBundleVersion, b.HardwareInfo.SystemVersion, b.getAid(), b.getSid(), apptag)

}

func (b *Bank) genAppID() string {
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "")
	sysVer = sysVer + string(bytes.Repeat([]byte{0x30}, 6-len(sysVer)))
	timestamp := tools.TimeFmtEx0()
	r := tools.RandHexString(3)

	appID := "1D" + sysVer + timestamp + r + b.IDFV[16:]

	newMd := hmacSha1AndB64(appID, newAppHmacSha1Key)

	appID += newMd[len(newMd)-8:]

	oldMd := hmacSha1AndB64(appID, oldAppHmacSha1Key)

	return appID + oldMd[len(oldMd)-8:]
}

func (b *Bank) genInnerID() string {
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "")
	sysVer = sysVer + string(bytes.Repeat([]byte{0x30}, 8-len(sysVer)))
	timestamp := tools.TimeFmt()

	innerID := "100" + sysVer + timestamp[2:] + b.IDFV + "0"

	md := hmacSha1AndB64(innerID, oldAppHmacSha1Key)

	return innerID + md[len(md)-4:]
}

func (b *Bank) genPushID() string {
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "")
	sysVer = sysVer + string(bytes.Repeat([]byte{0x30}, 8-len(sysVer)))

	return "a00" + sysVer + b.IDFV[:32] + tools.RandHexString(21)
}

func (b *Bank) getAid() string {
	if b.aid == "" {
		b.aid = hmacSha1AndB64(b.AppID, oldAppHmacSha1Key)
	}
	return b.aid
}

func (b *Bank) getSid() string {
	if b.sid == "" {
		b.sid = hmacSha1AndB64(b.AppID+tools.TimeFmt()+tools.RandString(8), oldAppHmacSha1Key)
	}
	return b.sid
}

func (b *Bank) getGeneralData() string {
	general := &generalData{}
	general.Version = cfBundleVersion
	// general.MenuHash = b.MenuHash
	// general.FuncListHash = b.FuncListHash
	// general.MerchantHash = "N"
	general.TotalTryAccountAll = "1"
	general.TotalTryAccount = "1"
	general.TotalTryTimesPeriod = "1"
	if b.UID != "" {
		general.TotalLoginAccount = "1"
	} else {
		general.TotalLoginAccount = "0"
	}
	general.BasicData.NetWorkInfo.PhoneNum = "###"
	general.BasicData.NetWorkInfo.ISP = b.HardwareInfo.Carrier
	general.BasicData.NetWorkInfo.SSID = ""
	general.BasicData.NetWorkInfo.NetworkType = "WIFI"
	general.BasicData.NetWorkInfo.WifiConnected.WifiSecure = "0"
	general.BasicData.NetWorkInfo.WifiConnected.WifiSSID = ""
	general.BasicData.NetWorkInfo.WifiConnected.WifiBSSID = ""
	general.BasicData.NetWorkInfo.WifiConnected.WifiRSSI = "-9999"
	general.BasicData.NetWorkInfo.BSSID = ""

	general.BasicData.LocationInfo.Latitude = ""
	general.BasicData.LocationInfo.Longitude = ""
	general.BasicData.LocationInfo.City = ""
	general.BasicData.LocationInfo.LbsAltitude = ""

	general.BasicData.ServerInfo.ServerTime = b.serverTime

	general.BasicData.NetShieldInfo.OtherData.Value = "{\"SSLCertData\":[]}"
	general.BasicData.NetShieldInfo.PWModelData.Value = "{\"RhuthmData\":[0,0],\"AutoOpsDetData\":[]}"
	general.BasicData.NetShieldInfo.ShieldData.Value = b.getShieldData()

	timestamp := tools.TimeFmt()
	general.BasicData.AppInfo.ReduceAPPID = b.getAid()
	general.BasicData.AppInfo.RealAppID = b.AppID
	general.BasicData.AppInfo.IsAppDebug = "N"
	general.BasicData.AppInfo.InnerID = b.InnerID
	general.BasicData.AppInfo.PushMSGID = b.PushID
	general.BasicData.AppInfo.CnlCode = "MPH"
	general.BasicData.AppInfo.AppID = hmacSm3(fmt.Sprintf("%s|%s|%s", b.AppID, b.clientNo, timestamp), HmacSm3Key)
	general.BasicData.AppInfo.IsRunningInEmulator = "N"
	general.BasicData.AppInfo.TimeStamp = timestamp
	general.BasicData.AppInfo.Release = "true"

	general.BasicData.DeviceFPCode = b.DeviceFPCode

	if b.UID != "" {
		general.BasicData.LoginPageTrail = "lgd-"
	} else {
		general.BasicData.LoginPageTrail = "lgf-lge-"
	}

	general.BasicData.DeviceInfo.DPANID = ""
	general.BasicData.DeviceInfo.Platform = "iphone"
	general.BasicData.DeviceInfo.ROMVolume = b.ROMVolume
	general.BasicData.DeviceInfo.TelecomPhoneToken.Mobiletoken = base64.StdEncoding.EncodeToString([]byte("{\"CM\":\"\",\"CU\":\"\",\"CT\":\"\"}"))
	general.BasicData.DeviceInfo.TelecomPhoneToken.Mobiletype = "UN" // unknown
	general.BasicData.DeviceInfo.IsRoot = "N"
	general.BasicData.DeviceInfo.CPUModel = "arm64 v8"
	general.BasicData.DeviceInfo.IDFA = b.IDFA
	general.BasicData.DeviceInfo.IDFVORIGIN = b.IDFV
	general.BasicData.DeviceInfo.CardSlotInfo.SIMInfo.MCC = "###"
	general.BasicData.DeviceInfo.CardSlotInfo.SIMInfo.IMEIIDFA = "IDFA"
	general.BasicData.DeviceInfo.CardSlotInfo.SIMInfo.IDFVSIM = b.IDFV
	general.BasicData.DeviceInfo.CardSlotInfo.SIMInfo.MNC = "#"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenScaledDensity = "-9999"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenXdpi = "-9999"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenColorDepth = "-9999"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenHeight = strconv.Itoa(tools.Height(b.HardwareInfo.ScreenSize))
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenYdpi = "-9999"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenWidth = strconv.Itoa(tools.Width(b.HardwareInfo.ScreenSize))
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenDensity = "-9999"
	general.BasicData.DeviceInfo.DeviceScreenInfo.ScreenAvailableHeight = "-9999"
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	general.BasicData.DeviceInfo.OSUserAgent = fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", sysVer)
	general.BasicData.DeviceInfo.IMSI = "###"
	general.BasicData.DeviceInfo.MobileModel = b.HardwareInfo.Model
	general.BasicData.DeviceInfo.RAMVolume = b.RAMVolume
	general.BasicData.DeviceInfo.PhoneNickName = b.HardwareInfo.OwnerName
	general.BasicData.DeviceInfo.MobileProducer = "Apple Inc."
	general.BasicData.DeviceInfo.SystemVersion = b.HardwareInfo.SystemVersion
	general.BasicData.DeviceInfo.IDFV = b.IDFV
	general.BasicData.DeviceInfo.DeviceName = b.HardwareInfo.OwnerName
	general.BasicData.DeviceInfo.DeviceType = "D"

	general.LoginTypeSettingInfo.TouchIdSettingInfo = "4"
	general.LoginTypeSettingInfo.GestureSettingInfo = "2"

	general.AgreementVersion = "version=1.5"

	general.HealthCodeData = ""

	general.HealthCodeCounter = ""

	// 去掉 <GeneralData></GeneralData>
	generalM, _ := xml.Marshal(general)
	generalS := strings.ReplaceAll(string(generalM), "<GeneralData>", "")
	generalS = strings.ReplaceAll(generalS, "</GeneralData>", "")

	return generalS
}

func (b *Bank) getSecData() string {
	sec := &secData{}
	sec.DeviceInfo.SystemVersion = b.HardwareInfo.SystemVersion
	sec.DeviceInfo.RAMVolume = b.RAMVolume
	sec.DeviceInfo.IsRoot = "N"
	sec.DeviceInfo.PhoneNickName = b.HardwareInfo.OwnerName
	sec.DeviceInfo.IDFV = b.IDFV
	sec.DeviceInfo.TelecomPhoneToken.Mobiletoken = base64.StdEncoding.EncodeToString([]byte("{}"))
	sec.DeviceInfo.TelecomPhoneToken.Mobiletype = "UN" // unknown
	sec.DeviceInfo.CPUModel = "arm64 v8"
	sec.DeviceInfo.MobileProducer = "Apple Inc."
	sec.DeviceInfo.DeviceScreenInfo.ScreenScaledDensity = "-9999"
	sec.DeviceInfo.DeviceScreenInfo.ScreenXdpi = "-9999"
	sec.DeviceInfo.DeviceScreenInfo.ScreenColorDepth = "-9999"
	sec.DeviceInfo.DeviceScreenInfo.ScreenHeight = strconv.Itoa(tools.Height(b.HardwareInfo.ScreenSize))
	sec.DeviceInfo.DeviceScreenInfo.ScreenYdpi = "-9999"
	sec.DeviceInfo.DeviceScreenInfo.ScreenWidth = strconv.Itoa(tools.Width(b.HardwareInfo.ScreenSize))
	sec.DeviceInfo.DeviceScreenInfo.ScreenDensity = "-9999"
	sec.DeviceInfo.DeviceScreenInfo.ScreenAvailableHeight = "-9999"
	sec.DeviceInfo.DPANID = ""
	sec.DeviceInfo.IMSI = "###"
	sec.DeviceInfo.IDFVORIGIN = b.IDFV
	sec.DeviceInfo.ROMVolume = b.ROMVolume
	sec.DeviceInfo.CardSlotInfo.SIMInfo.MCC = "###"
	sec.DeviceInfo.CardSlotInfo.SIMInfo.IMEIIDFA = "IDFA"
	sec.DeviceInfo.CardSlotInfo.SIMInfo.IDFVSIM = b.IDFV
	sec.DeviceInfo.CardSlotInfo.SIMInfo.MNC = "#"
	sysVer := strings.ReplaceAll(b.HardwareInfo.SystemVersion, ".", "_")
	sec.DeviceInfo.OSUserAgent = fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile\\/15E148", sysVer)
	sec.DeviceInfo.IDFA = b.IDFA
	sec.DeviceInfo.DeviceType = "D"
	sec.DeviceInfo.MobileModel = b.HardwareInfo.Model
	sec.DeviceInfo.DeviceName = b.HardwareInfo.OwnerName

	sec.AppInfo.ReduceAPPID = b.getAid()
	sec.AppInfo.RealAppID = b.AppID
	sec.AppInfo.IsAppDebug = "N"
	sec.AppInfo.InnerID = b.InnerID
	sec.AppInfo.PushMSGID = b.PushID
	sec.AppInfo.CnlCode = "MPH"
	timestamp := tools.TimeFmt()
	sec.AppInfo.AppID = hmacSha1AndB64(fmt.Sprintf("%s|%s|%s", b.AppID, b.clientNo, timestamp), oldAppHmacSha1Key)
	sec.AppInfo.IsRunningInEmulator = "N"
	sec.AppInfo.TimeStamp = timestamp
	sec.AppInfo.Release = "true"

	sec.LocationInfo.Latitude = ""
	sec.LocationInfo.Longitude = ""
	sec.LocationInfo.City = ""
	sec.LocationInfo.LbsAltitude = ""

	sec.NetWorkInfo.PhoneNum = "###"
	sec.NetWorkInfo.ISP = b.HardwareInfo.Carrier
	sec.NetWorkInfo.SSID = ""
	sec.NetWorkInfo.NetworkType = "WIFI"
	sec.NetWorkInfo.WifiConnected.WifiSecure = "0"
	sec.NetWorkInfo.WifiConnected.WifiSSID = ""
	sec.NetWorkInfo.WifiConnected.WifiBSSID = ""
	sec.NetWorkInfo.WifiConnected.WifiRSSI = "-9999"
	sec.NetWorkInfo.BSSID = ""

	// 去掉 <SecData></SecData>
	secM, _ := xml.Marshal(sec)
	secS := strings.ReplaceAll(string(secM), "<SecData>", "")
	secS = strings.ReplaceAll(secS, "</SecData>", "")

	return secS
}

func (b *Bank) getShieldData() string {
	shield, _ := json.Marshal(&map[string]interface{}{
		"DevData": map[string]string{
			"HasSim":     "true",
			"Status":     "discharging",
			"IDFV":       b.IDFV,
			"DeviceName": b.HardwareInfo.Model,
			"AppSumNo":   "",
			"FinanceNo":  "",
			"Level":      fmt.Sprintf("%.2f", 0.8+tools.RandFloat(0.2)), // 电量
			"IDFA":       b.IDFA,
		},
		"SecData": []string{"false", "false", "false", "false"},
	})

	return string(shield)
}

func (b *Bank) addBaseHeaders() *http.Header {
	header := &http.Header{
		"DeviceType":    {"D"},
		"PBClient":      {"cmbpb-iphone"},
		"SID":           {b.getSid()},
		"AID":           {b.getAid()},
		"ClientVersion": {cfBundleVersion},
		"SystemVersion": {b.HardwareInfo.SystemVersion},
	}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.UserAgent, b.userAgent())
	return header
}

func (b *Bank) encryptBody(postData []byte) (key, postStr, origKey string) {
	// 生成aes key
	aesKey := tools.RandString(32)
	// 加密aes Key
	key = rsaEncryptWithClientNo(aesKey, b.clientNo)
	// aes加密数据
	postData, _ = tools.AESECBEncrypt(postData, []byte(aesKey))
	postStr = base64.StdEncoding.EncodeToString(postData)

	return key, postStr, aesKey
}

func (b *Bank) encryptBodyB(postData []byte) (key, postStr, origKey string) {
	// 生成sm4 key
	sm4Key := tools.RandString(16)
	// 加密sm4 Key
	key = sm2Encrypt(sm4Key)
	// sm4加密数据
	postData, _ = tools.SM4CBCEncrypt(postData, []byte(sm4Key), []byte(sm4Key))
	postStr = base64.StdEncoding.EncodeToString(postData)

	return key, postStr, sm4Key
}

func (b *Bank) parseLoginResp(data []byte, origKey string) *loginResp {
	respObj := &loginResp{}

	respData := &responseData{}
	err := xml.Unmarshal(data, respData)
	if err != nil {
		logger.Errorf("login respData xml.Unmarshal err=%+v", err)
		return respObj
	}
	// 先base64
	resp, _ := base64.StdEncoding.DecodeString(respData.LoginRoot)
	if respData.IsEncrypted == "Y" {
		// 需要解密
		resp, _ = tools.SM4CBCDecrypt(resp, []byte(origKey), []byte(origKey))
	}

	if respData.IsCompressored == "Y" {
		// 需要解压
		resp, err = tools.GZipUncompress(resp)
		if err != nil {
			logger.Errorf("login GZipUncompress err=%+v", err)
			return respObj
		}
	}

	logger.Info("login parse >>>>>>>> \r\n" + string(resp))

	err = xml.Unmarshal([]byte("<LoginResp>"+string(resp)+"</LoginResp>"), respObj)
	if err != nil {
		logger.Errorf("login xml.Unmarshal err=%+v data=\r\n%+v\r\n", err, resp)
	}
	return respObj
}

func randKeyAndIv() (string, string) {
	rndBytes := []byte("0123456789ABCDEF")
	rndBytesLen := len(rndBytes)
	buffer1 := make([]byte, 16)
	buffer2 := make([]byte, 16)
	for i := 0; i < 16; i++ {
		buffer1[i] = rndBytes[tools.RandIntn(rndBytesLen)]
	}
	for i := 0; i < 16; i++ {
		buffer2[i] = rndBytes[tools.RandIntn(rndBytesLen)]
	}
	return string(buffer1), string(buffer2)
}

func deviceFPEncrypt(info, key, iv string) (string, error) {
	js := "./cmb/bin/sm4.js"
	jsBytes, err := ioutil.ReadFile(js)
	if err != nil {
		panic(err)
	}
	vm := otto.New()
	_, err = vm.Run(string(jsBytes))
	if err != nil {
		return "", err
	}
	enData, err := vm.Call("kb", nil, info, key, iv)
	if err != nil {
		return "", err
	}

	return enData.String(), nil
}

func deviceHash(info string) (string, error) {
	js := "./cmb/bin/frms-fingerprint.js"
	jsBytes, err := ioutil.ReadFile(js)
	if err != nil {
		panic(err)
	}
	vm := otto.New()
	_, err = vm.Run(string(jsBytes))
	if err != nil {
		return "", err
	}
	hash, err := vm.Call("Ya", nil, info)
	if err != nil {
		return "", err
	}

	return hash.String(), nil
}

func allHashCode(info map[string]string) (string, error) {
	js := "./cmb/bin/frms-fingerprint.js"
	jsBytes, err := ioutil.ReadFile(js)
	if err != nil {
		panic(err)
	}
	vm := otto.New()
	_, err = vm.Run(string(jsBytes))
	if err != nil {
		return "", err
	}

	b64Encoder := base64.NewEncoding("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_").WithPadding(base64.NoPadding)

	keys := make([]string, 0)
	for k := range info {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	str := ""
	for _, v := range keys {
		str = fmt.Sprintf("%s%s%s", str, v, info[v])
	}

	jsStr, err := vm.Call("calcHash", nil, str)
	if err != nil {
		return "", err
	}

	str = jsStr.String()
	s256 := sha256.New()
	s256.Write([]byte(str))
	md := s256.Sum(nil)
	mdStr := b64Encoder.EncodeToString(md)

	jsStr, err = vm.Call("mb", nil, mdStr)
	if err != nil {
		return "", err
	}

	str = jsStr.String()
	s256 = sha256.New()
	s256.Write([]byte(str))
	md = s256.Sum(nil)
	mdStr = b64Encoder.EncodeToString(md)
	return mdStr, nil
}
