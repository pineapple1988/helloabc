package cmb

import "encoding/xml"

type baseEncryptResp struct {
	ErrCode      string `json:"ErrCode"`
	IsEncrypted  string `json:"IsEncrypted"`
	IsCompressed string `json:"IsCompressed"`
	Content      string `json:"Content"`
}

type getClientCfgPostData struct {
	XMLName       xml.Name `xml:"PostData"`
	Text          string   `xml:",chardata"`
	DeviceType    string   `xml:"DeviceType"`
	MenuHash      string   `xml:"MenuHash"`
	FuncListHash  string   `xml:"FuncListHash"`
	MerchantHash  string   `xml:"MerchantHash"`
	Version       string   `xml:"Version"`
	AppID         string   `xml:"AppID"`
	InnerID       string   `xml:"InnerID"`
	SystemVersion string   `xml:"SystemVersion"`
	ExtraInfo     struct {
		Text         string `xml:",chardata"`
		DeviceModel  string `xml:"DeviceModel"`
		DeviceVendor string `xml:"DeviceVendor"`
	} `xml:"ExtraInfo"`
}

type getClientCfgResp struct {
	XMLName                xml.Name `xml:"GetClientCfgResp"`
	Text                   string   `xml:",chardata"`
	ERRNO                  string   `xml:"ERRNO"`
	VipHomeMsgBoxOpen      string   `xml:"vipHomeMsgBoxOpen"`
	PublishRedPointsCfgURL string   `xml:"PublishRedPointsCfgUrl"`
	FootPrint              struct {
		Text             string `xml:",chardata"`
		FootPrintWebURL  string `xml:"FootPrintWebUrl"`
		DisableFootPrint string `xml:"DisableFootPrint"`
	} `xml:"FootPrint"`
	AppletWebSwitch            string `xml:"AppletWebSwitch"`
	WKWebViewMinSupportVersion string `xml:"WKWebViewMinSupportVersion"`
	DisableAppWebfont          string `xml:"DisableAppWebfont"`
	ARModelURL                 string `xml:"ARModelUrl"`
	PBGreetCfgNew              struct {
		Text string `xml:",chardata"`
		Nav  string `xml:"Nav"`
		Acp  string `xml:"Acp"`
	} `xml:"PBGreetCfgNew"`
	LoginAuthName          string   `xml:"LoginAuthName"`
	PicURLPrefix           string   `xml:"PicUrlPrefix"`
	PicURLPrefix750        string   `xml:"PicUrlPrefix750"`
	H5MonitorURL           string   `xml:"H5MonitorURL"`
	ErrPageURL             string   `xml:"ErrPageUrl"`
	FeedbackURL            string   `xml:"FeedbackUrl"`
	ResetDebitCardPwd      string   `xml:"ResetDebitCardPwd"`
	ResetCreditCardPwd     string   `xml:"ResetCreditCardPwd"`
	NetPayURL              string   `xml:"NetPayUrl"`
	DisableWebRequestCache string   `xml:"DisableWebRequestCache"`
	MobileLogServerURL     string   `xml:"MobileLogServerUrl"`
	MobileLogExServerURL   string   `xml:"MobileLogExServerUrl"`
	GetDataAsynRequest     string   `xml:"GetDataAsynRequest"`
	SetGesturePwdURL       string   `xml:"SetGesturePwdUrl"`
	WXBindQueryURL         []string `xml:"WXBindQueryUrl"`
	AppleBindQueryURL      string   `xml:"AppleBindQueryUrl"`
	MarketingCfgURLNew     string   `xml:"MarketingCfgUrlNew"`
	Adver                  struct {
		Text             string `xml:",chardata"`
		HomePageAdverURL string `xml:"HomePageAdverUrl"`
		FortuneAdverURL  string `xml:"FortuneAdverUrl"`
	} `xml:"Adver"`
	AuthInfo struct {
		Text string `xml:",chardata"`
		Auth []struct {
			Text     string `xml:",chardata"`
			AuthName string `xml:"AuthName"`
			LoginURL string `xml:"LoginURL"`
		} `xml:"Auth"`
	} `xml:"AuthInfo"`
	LoginAccountControl struct {
		Text       string `xml:",chardata"`
		TryAccount struct {
			Text     string `xml:",chardata"`
			SaveDays string `xml:"SaveDays"`
		} `xml:"TryAccount"`
		LoginAccount struct {
			Text     string `xml:",chardata"`
			SaveDays string `xml:"SaveDays"`
		} `xml:"LoginAccount"`
		TryPeriod struct {
			Text          string `xml:",chardata"`
			PeriodSeconds string `xml:"Period_Seconds"`
		} `xml:"TryPeriod"`
	} `xml:"LoginAccountControl"`
	WifiTransit         string `xml:"WifiTransit"`
	RegUserURL          string `xml:"RegUserUrl"`
	ResetUserPwd        string `xml:"ResetUserPwd"`
	HeadImageSettingURL string `xml:"HeadImageSettingUrl"`
	PasteboardURL       string `xml:"PasteboardUrl"`
	PasteboardSwitch    string `xml:"PasteboardSwitch"`
	ServersConfig       struct {
		Text   string `xml:",chardata"`
		Server []struct {
			Text        string `xml:",chardata"`
			ServerName  string `xml:"ServerName,attr"`
			IsKeyServer string `xml:"IsKeyServer,attr"`
			ServerID    string `xml:"ServerId,attr"`
			ConfigSrc   string `xml:"ConfigSrc"`
		} `xml:"Server"`
	} `xml:"ServersConfig"`
	GetWangDunPluginInfo struct {
		Text                string `xml:",chardata"`
		GetWangDunPluginDex struct {
			Text    string `xml:",chardata"`
			URL     string `xml:"Url"`
			Version string `xml:"Version"`
			MD5     string `xml:"MD5"`
		} `xml:"GetWangDunPluginDex"`
		GetWangDunPluginDB struct {
			Text    string `xml:",chardata"`
			URL     string `xml:"Url"`
			Version string `xml:"Version"`
			MD5     string `xml:"MD5"`
		} `xml:"GetWangDunPluginDB"`
		TipLevel string `xml:"TipLevel"`
	} `xml:"GetWangDunPluginInfo"`
	QrCodeFilter struct {
		Text   string `xml:",chardata"`
		Router struct {
			Text   string   `xml:",chardata"`
			Name   string   `xml:"Name,attr"`
			Filter []string `xml:"Filter"`
		} `xml:"Router"`
	} `xml:"QrCodeFilter"`
	FingerSettingURL string `xml:"FingerSettingUrl"`
	HomeTabCfg       struct {
		Text       string `xml:",chardata"`
		WebContent struct {
			Text   string `xml:",chardata"`
			Common string `xml:"Common"`
			Honour string `xml:"Honour"`
		} `xml:"WebContent"`
		Adver string `xml:"Adver"`
	} `xml:"HomeTabCfg"`
	FinancialTabCfg struct {
		Text          string `xml:",chardata"`
		TopWebContent struct {
			Text   string `xml:",chardata"`
			Common struct {
				Text   string `xml:",chardata"`
				FuncID string `xml:"FuncId"`
			} `xml:"Common"`
		} `xml:"TopWebContent"`
		WebContent struct {
			Text   string `xml:",chardata"`
			Common string `xml:"Common"`
		} `xml:"WebContent"`
	} `xml:"FinancialTabCfg"`
	LifeTabCfg struct {
		Text       string `xml:",chardata"`
		WebContent struct {
			Text      string `xml:",chardata"`
			Common    string `xml:"Common"`
			Common730 string `xml:"Common730"`
		} `xml:"WebContent"`
	} `xml:"LifeTabCfg"`
	SearchCfg struct {
		Text                       string `xml:",chardata"`
		OpenSearchLocalAIRecognite string `xml:"OpenSearchLocalAIRecognite"`
		SearchHistoryAndHotWordURL string `xml:"SearchHistoryAndHotWordUrl"`
		SearchURL                  string `xml:"SearchUrl"`
		HotWordURL                 string `xml:"HotWordUrl"`
		ShouldUseNativeSearch      string `xml:"ShouldUseNativeSearch"`
		WebSearchURL               string `xml:"WebSearchUrl"`
		NewSearchSupportMinVersion string `xml:"NewSearchSupportMinVersion"`
	} `xml:"SearchCfg"`
	MineTabCfg struct {
		Text       string `xml:",chardata"`
		WebContent struct {
			Text   string `xml:",chardata"`
			FuncID string `xml:"FuncId"`
		} `xml:"WebContent"`
		GetMyInfoData string `xml:"GetMyInfoData"`
	} `xml:"MineTabCfg"`
	LogCfg struct {
		Text                    string `xml:",chardata"`
		LogSyncSrvURL           string `xml:"LogSyncSrvURL"`
		LogSendNetWorkType      string `xml:"LogSendNetWorkType"`
		LogSendPendingTime      string `xml:"LogSendPendingTime"`
		LogComTimeOut           string `xml:"LogComTimeOut"`
		LogMaxCacheCmbApplog    string `xml:"LogMaxCacheCmbApplog"`
		LogMaxCacheTalkingdata  string `xml:"LogMaxCacheTalkingdata"`
		LogSendMaxSize          string `xml:"LogSendMaxSize"`
		LogSendFailRestCount    string `xml:"LogSendFailRestCount"`
		LogSendInBgRestCount    string `xml:"LogSendInBgRestCount"`
		EnableCmbAppLog         string `xml:"EnableCmbAppLog"`
		EnableTalkingData       string `xml:"EnableTalkingData"`
		EnableClientDataMonitor string `xml:"EnableClientDataMonitor"`
		EnableOutsideLog        string `xml:"EnableOutsideLog"`
	} `xml:"LogCfg"`
	LoginAgreementURL string `xml:"LoginAgreementUrl"`
	ScanConfig        struct {
		Text     string `xml:",chardata"`
		ScanShow struct {
			Text string `xml:",chardata"`
			Item []struct {
				Text            string `xml:",chardata"`
				FuncName        string `xml:"funcName,attr"`
				Title           string `xml:"Title,attr"`
				Enable          string `xml:"Enable"`
				EnableBeginTime string `xml:"EnableBeginTime"`
				EnableEndTime   string `xml:"EnableEndTime"`
				AdText          string `xml:"AdText"`
				AdBeginTime     string `xml:"AdBeginTime"`
				AdEndTime       string `xml:"AdEndTime"`
				IsDefault       string `xml:"IsDefault"`
				EachScanSecond  string `xml:"EachScanSecond"`
				ScanFailedTips  string `xml:"ScanFailedTips"`
				Src             string `xml:"Src"`
			} `xml:"Item"`
		} `xml:"ScanShow"`
	} `xml:"ScanConfig"`
	PreLoginURL                    string `xml:"PreLoginUrl"`
	LoginOut                       string `xml:"LoginOut"`
	ShowScanRecordFlag             string `xml:"ShowScanRecordFlag"`
	GestureLoginURLV1              string `xml:"GestureLoginUrlV1"`
	FirstLoginRouteURL             string `xml:"FirstLoginRouteUrl"`
	AccountLoginURLV1              string `xml:"AccountLoginUrlV1"`
	SMSCodeLoginURLV1              string `xml:"SMSCodeLoginUrlV1"`
	RequestSMSCodeURL              string `xml:"RequestSMSCodeUrl"`
	RequestVoiceCodeURL            string `xml:"RequestVoiceCodeUrl"`
	FaceVerifyLoginURL             string `xml:"FaceVerifyLoginUrl"`
	FingerLoginURLV1               string `xml:"FingerLoginUrlV1"`
	DisableFaceVerifyLoginEntrance string `xml:"DisableFaceVerifyLoginEntrance"`
	NewLoginMinSupportVersion      string `xml:"NewLoginMinSupportVersion"`
	AppLoginURLWXLogin             string `xml:"AppLoginUrl_WXLogin"`
	AppLoginURLAppleLogin          string `xml:"AppLoginUrl_AppleLogin"`
	CustomerServiceURL             string `xml:"CustomerServiceUrl"`
	ARServerURL                    string `xml:"ARServerURL"`
	ARLotteryRule                  string `xml:"ARLotteryRule"`
	HomeTabXiaozhaoURL             string `xml:"HomeTabXiaozhaoUrl"`
	ReferenceTabCfg60              struct {
		Text       string `xml:",chardata"`
		WebContent struct {
			Text   string `xml:",chardata"`
			Common struct {
				Text      string `xml:",chardata"`
				Follow    string `xml:"Follow"`
				Recommend string `xml:"Recommend"`
				Develop   string `xml:"Develop"`
				MixedWeb  string `xml:"MixedWeb"`
			} `xml:"Common"`
			Honour struct {
				Text      string `xml:",chardata"`
				Follow    string `xml:"Follow"`
				Recommend string `xml:"Recommend"`
				Develop   string `xml:"Develop"`
				MixedWeb  string `xml:"MixedWeb"`
			} `xml:"Honour"`
		} `xml:"WebContent"`
	} `xml:"ReferenceTabCfg60"`
	ReferenceFullWebMinSupportVersion string `xml:"ReferenceFullWebMinSupportVersion"`
	LifeFullWebMinSupportVersion      string `xml:"LifeFullWebMinSupportVersion"`
	ModifyPhoneNo                     string `xml:"ModifyPhoneNo"`
	ShowXiaozhaoBtn                   string `xml:"ShowXiaozhaoBtn"`
	PBGreetURLNew                     string `xml:"PBGreetUrlNew"`
	APPInnerCfgURL                    string `xml:"APPInnerCfgUrl"`
	NewFunctionEntranceSwitch         string `xml:"NewFunctionEntranceSwitch"`
	FPLoginFilter                     struct {
		Text                string `xml:",chardata"`
		FPMAFTWhiteList     string `xml:"FPMAFTWhiteList"`
		FPMAFTWhiteListTips string `xml:"FPMAFTWhiteListTips"`
	} `xml:"FPLoginFilter"`
	AssistChatGrayModelSwitch string `xml:"AssistChatGrayModelSwitch"`
	AIAssistCfg               struct {
		Text        string `xml:",chardata"`
		BaseURL     string `xml:"BaseUrl"`
		CloseAssist string `xml:"CloseAssist"`
	} `xml:"AIAssistCfg"`
	ScanConfig620 struct {
		Text        string `xml:",chardata"`
		ScanShow620 struct {
			Text string `xml:",chardata"`
			Item []struct {
				Text            string `xml:",chardata"`
				FuncName        string `xml:"funcName,attr"`
				Title           string `xml:"Title,attr"`
				Enable          string `xml:"Enable"`
				EnableBeginTime string `xml:"EnableBeginTime"`
				EnableEndTime   string `xml:"EnableEndTime"`
				AdText          string `xml:"AdText"`
				AdBeginTime     string `xml:"AdBeginTime"`
				AdEndTime       string `xml:"AdEndTime"`
				Src             string `xml:"Src"`
				NormalIcon      string `xml:"NormalIcon"`
				SelectedIcon    string `xml:"SelectedIcon"`
			} `xml:"Item"`
		} `xml:"ScanShow620"`
		ScanMonitorCfg700 struct {
			Text              string `xml:",chardata"`
			TriggerLogTimeOut string `xml:"TriggerLogTimeOut"`
			LogUserMinID      string `xml:"LogUserMinID"`
			LogUserMaxID      string `xml:"LogUserMaxID"`
		} `xml:"ScanMonitorCfg700"`
		ScanMonitorCfg710 struct {
			Text              string `xml:",chardata"`
			TriggerLogTimeOut string `xml:"TriggerLogTimeOut"`
			LogUserMinID      string `xml:"LogUserMinID"`
			LogUserMaxID      string `xml:"LogUserMaxID"`
		} `xml:"ScanMonitorCfg710"`
	} `xml:"ScanConfig620"`
	MerchantSwitch     string `xml:"MerchantSwitch"`
	ScreenShotGrayTest string `xml:"ScreenShotGrayTest"`
	ScreenShotCfg650   struct {
		Text string `xml:",chardata"`
		Item []struct {
			Text       string `xml:",chardata"`
			Action     string `xml:"Action,attr"`
			Title      string `xml:"Title,attr"`
			Enable     string `xml:"Enable"`
			Icon       string `xml:"Icon"`
			EnableEdit string `xml:"EnableEdit"`
			EditTips   string `xml:"EditTips"`
		} `xml:"Item"`
	} `xml:"ScreenShotCfg650"`
	ClientCfgFileLoadCfg struct {
		Text                       string `xml:",chardata"`
		CfgFileAsyncLoad           string `xml:"CfgFileAsyncLoad"`
		CfgFileLastUpdateLimitTime string `xml:"CfgFileLastUpdateLimitTime"`
	} `xml:"ClientCfgFileLoadCfg"`
	DynamicFuncConfigURL     string `xml:"DynamicFuncConfigUrl"`
	ServiceGuideSwitch       string `xml:"ServiceGuideSwitch"`
	ServiceGuideURL          string `xml:"ServiceGuideUrl"`
	AppRateMinSupportVersion string `xml:"AppRateMinSupportVersion"`
	AppRateNeedGrayTest      string `xml:"AppRateNeedGrayTest"`
	NfcCardJumpURL           string `xml:"NfcCardJumpUrl"`
	BusinessLicenseURL       string `xml:"BusinessLicenseUrl"`
	AppWebfontURL            string `xml:"AppWebfontUrl"`
	FunctionIDInterchange720 struct {
		Text string `xml:",chardata"`
		Item []struct {
			Text  string `xml:",chardata"`
			OldID string `xml:"OldID,attr"`
			NewID string `xml:"NewID,attr"`
		} `xml:"Item"`
	} `xml:"FunctionIDInterchange720"`
	PrivacyAgreementURL string `xml:"PrivacyAgreementUrl"`
	TPAppCallWhiteList  string `xml:"TPAppCallWhiteList"`
	StepUploadURL       string `xml:"StepUploadUrl"`
	MenuHash            string `xml:"MenuHash"`
	FuncListHash        string `xml:"FuncListHash"`
	UserExternalNetIP   string `xml:"UserExternalNetIP"`
	APPUpgradeInfo      struct {
		Text           string `xml:",chardata"`
		AppUpgradeFlag string `xml:"AppUpgradeFlag"`
		AppUpgradeTips string `xml:"AppUpgradeTips"`
		TimeStamp      string `xml:"TimeStamp"`
	} `xml:"APPUpgradeInfo"`
	UpdateTimeForLog struct {
		Text           string `xml:",chardata"`
		ServerSysTime1 string `xml:"ServerSysTime1"`
		ServerSysTime2 string `xml:"ServerSysTime2"`
		ServerTagName  string `xml:"ServerTagName"`
	} `xml:"UpdateTimeForLog"`
	HCEKeyInfo struct {
		Text          string `xml:",chardata"`
		PublicKeyCert string `xml:"publicKeyCert"`
		EncryptedKey  string `xml:"encryptedKey"`
	} `xml:"HCEKeyInfo"`
}

type otherAppConfigResp struct {
	XMLName  xml.Name `xml:"OtherAppConfig"`
	Text     string   `xml:",chardata"`
	AuthInfo struct {
		Text string `xml:",chardata"`
		Auth []struct {
			Text     string `xml:",chardata"`
			AuthName string `xml:"AuthName"`
			LoginURL string `xml:"LoginURL"`
		} `xml:"Auth"`
	} `xml:"AuthInfo"`
	FuncListHash string `xml:"FuncListHash"`
	MenuHash     string `xml:"MenuHash"`
}

type domainResp struct {
	ErrCode string `json:"errCode"`
	ErrMsg  string `json:"errMsg"`
	Hash    string `json:"hash"`
}

type menuResp struct {
	RecommendMenu struct {
		HomePage struct {
			MenuHash string `json:"MenuHash"`
			MenuData string `json:"MenuData"`
		} `json:"HomePage"`
		AllPage struct {
			MenuHash string `json:"MenuHash"`
			MenuData string `json:"MenuData"`
		} `json:"AllPage"`
		FinancialPage struct {
			MenuHash string `json:"MenuHash"`
			MenuData string `json:"MenuData"`
		} `json:"FinancialPage"`
	} `json:"RecommendMenu"`
}

type preLoginPostData struct {
	XMLName             xml.Name `xml:"PostData"`
	Text                string   `xml:",chardata"`
	DeviceType          string   `xml:"DeviceType"`
	AppID               string   `xml:"AppID"`
	Version             string   `xml:"Version"`
	SystemVersion       string   `xml:"SystemVersion"`
	InnerID             string   `xml:"InnerID"`
	IsRunningInEmulator string   `xml:"IsRunningInEmulator"`
	IsRoot              string   `xml:"IsRoot"`
	MobileProducer      string   `xml:"MobileProducer"`
	MobileModel         string   `xml:"MobileModel"`
	CPUModel            string   `xml:"CPUModel"`
	IMEI                string   `xml:"IMEI"`
	IMSI                string   `xml:"IMSI"`
	IDFA                string   `xml:"IDFA"`
	IDFV                string   `xml:"IDFV"`
	NetworkType         string   `xml:"NetworkType"`
	SSID                string   `xml:"SSID"`
	BSSID               string   `xml:"BSSID"`
	City                string   `xml:"City"`
	AppSessionID        string   `xml:"AppSessionID"`
	HealthCodeData      string   `xml:"HealthCodeData"`
	HealthCodeKey       string   `xml:"HealthCodeKey"`
}

type preLoginResp struct {
	XMLName xml.Name `xml:"PreLoginResp"`
	Text    string   `xml:",chardata"`
	Root    struct {
		Text             string `xml:",chardata"`
		ClientNo         string `xml:"ClientNo"`
		SessionID        string `xml:"SessionId"`
		Msid             string `xml:"msid"`
		HealthCodeResult string `xml:"HealthCodeResult"`
	} `xml:"root"`
	ServerTime     string `xml:"ServerTime"`
	ServerSysTime1 string `xml:"ServerSysTime1"`
	ServerSysTime2 string `xml:"ServerSysTime2"`
	ServerTagName  string `xml:"ServerTagName"`
}

type secData struct {
	XMLName    xml.Name `xml:"SecData"`
	Text       string   `xml:",chardata"`
	DeviceInfo struct {
		Text              string `xml:",chardata"`
		SystemVersion     string `xml:"SystemVersion"`
		RAMVolume         string `xml:"RAMVolume"`
		IsRoot            string `xml:"isRoot"`
		PhoneNickName     string `xml:"PhoneNickName"`
		IDFV              string `xml:"IDFV"`
		TelecomPhoneToken struct {
			Text        string `xml:",chardata"`
			Mobiletoken string `xml:"mobiletoken"`
			Mobiletype  string `xml:"mobiletype"`
		} `xml:"TelecomPhoneToken"`
		CPUModel         string `xml:"CPUModel"`
		MobileProducer   string `xml:"MobileProducer"`
		DeviceScreenInfo struct {
			Text                  string `xml:",chardata"`
			ScreenScaledDensity   string `xml:"ScreenScaledDensity"`
			ScreenXdpi            string `xml:"ScreenXdpi"`
			ScreenColorDepth      string `xml:"ScreenColorDepth"`
			ScreenHeight          string `xml:"ScreenHeight"`
			ScreenYdpi            string `xml:"ScreenYdpi"`
			ScreenWidth           string `xml:"ScreenWidth"`
			ScreenDensity         string `xml:"ScreenDensity"`
			ScreenAvailableHeight string `xml:"ScreenAvailableHeight"`
		} `xml:"DeviceScreenInfo"`
		DPANID       string `xml:"DPANID"`
		IMSI         string `xml:"IMSI"`
		IDFVORIGIN   string `xml:"IDFV_ORIGIN"`
		ROMVolume    string `xml:"ROMVolume"`
		CardSlotInfo struct {
			Text    string `xml:",chardata"`
			SIMInfo struct {
				Text     string `xml:",chardata"`
				MCC      string `xml:"MCC"`
				IMEIIDFA string `xml:"IMEI_IDFA"`
				IDFVSIM  string `xml:"IDFV_SIM"`
				MNC      string `xml:"MNC"`
			} `xml:"SIMInfo"`
		} `xml:"CardSlotInfo"`
		OSUserAgent string `xml:"OSUserAgent"`
		IDFA        string `xml:"IDFA"`
		DeviceType  string `xml:"DeviceType"`
		MobileModel string `xml:"MobileModel"`
		DeviceName  string `xml:"DeviceName"`
	} `xml:"DeviceInfo"`
	AppInfo struct {
		Text                string `xml:",chardata"`
		ReduceAPPID         string `xml:"ReduceAPPID"`
		RealAppID           string `xml:"RealAppID"`
		IsAppDebug          string `xml:"IsAppDebug"`
		InnerID             string `xml:"InnerID"`
		PushMSGID           string `xml:"PushMSGID"`
		CnlCode             string `xml:"CnlCode"`
		AppID               string `xml:"AppID"`
		IsRunningInEmulator string `xml:"IsRunningInEmulator"`
		TimeStamp           string `xml:"TimeStamp"`
		Release             string `xml:"Release"`
	} `xml:"AppInfo"`
	LocationInfo struct {
		Text        string `xml:",chardata"`
		Latitude    string `xml:"Latitude"`
		Longitude   string `xml:"Longitude"`
		City        string `xml:"City"`
		LbsAltitude string `xml:"LbsAltitude"`
	} `xml:"LocationInfo"`
	NetWorkInfo struct {
		Text          string `xml:",chardata"`
		PhoneNum      string `xml:"PhoneNum"`
		ISP           string `xml:"ISP"`
		SSID          string `xml:"SSID"`
		NetworkType   string `xml:"NetworkType"`
		WifiConnected struct {
			Text       string `xml:",chardata"`
			WifiSecure string `xml:"WifiSecure"`
			WifiSSID   string `xml:"WifiSSID"`
			WifiBSSID  string `xml:"WifiBSSID"`
			WifiRSSI   string `xml:"WifiRSSI"`
		} `xml:"WifiConnected"`
		BSSID string `xml:"BSSID"`
	} `xml:"NetWorkInfo"`
}

type generalData struct {
	XMLName             xml.Name `xml:"GeneralData"`
	Text                string   `xml:",chardata"`
	Version             string   `xml:"Version"`
	TotalTryAccountAll  string   `xml:"TotalTryAccountAll"`
	TotalTryAccount     string   `xml:"TotalTryAccount"`
	TotalTryTimesPeriod string   `xml:"TotalTryTimesPeriod"`
	TotalLoginAccount   string   `xml:"TotalLoginAccount"`
	BasicData           struct {
		Text        string `xml:",chardata"`
		NetWorkInfo struct {
			Text          string `xml:",chardata"`
			PhoneNum      string `xml:"PhoneNum"`
			ISP           string `xml:"ISP"`
			SSID          string `xml:"SSID"`
			NetworkType   string `xml:"NetworkType"`
			WifiConnected struct {
				Text       string `xml:",chardata"`
				WifiSecure string `xml:"WifiSecure"`
				WifiSSID   string `xml:"WifiSSID"`
				WifiBSSID  string `xml:"WifiBSSID"`
				WifiRSSI   string `xml:"WifiRSSI"`
			} `xml:"WifiConnected"`
			BSSID string `xml:"BSSID"`
		} `xml:"NetWorkInfo"`
		LocationInfo struct {
			Text        string `xml:",chardata"`
			Latitude    string `xml:"Latitude"`
			Longitude   string `xml:"Longitude"`
			City        string `xml:"City"`
			LbsAltitude string `xml:"LbsAltitude"`
		} `xml:"LocationInfo"`
		ServerInfo struct {
			Text       string `xml:",chardata"`
			ServerTime string `xml:"ServerTime"`
		} `xml:"ServerInfo"`
		NetShieldInfo struct {
			Text      string `xml:",chardata"`
			OtherData struct {
				Value string `xml:",innerxml"`
			} `xml:"OtherData"`
			PWModelData struct {
				Value string `xml:",innerxml"`
			} `xml:"PWModelData"`
			ShieldData struct {
				Value string `xml:",innerxml"`
			} `xml:"ShieldData"`
		} `xml:"NetShieldInfo"`
		AppInfo struct {
			Text                string `xml:",chardata"`
			ReduceAPPID         string `xml:"ReduceAPPID"`
			RealAppID           string `xml:"RealAppID"`
			IsAppDebug          string `xml:"IsAppDebug"`
			InnerID             string `xml:"InnerID"`
			PushMSGID           string `xml:"PushMSGID"`
			CnlCode             string `xml:"CnlCode"`
			AppID               string `xml:"AppID"`
			IsRunningInEmulator string `xml:"IsRunningInEmulator"`
			TimeStamp           string `xml:"TimeStamp"`
			Release             string `xml:"Release"`
		} `xml:"AppInfo"`
		DeviceFPCode   string `xml:"DeviceFPCode"`
		LoginPageTrail string `xml:"LoginPageTrail"`
		DeviceInfo     struct {
			Text              string `xml:",chardata"`
			DPANID            string `xml:"DPANID"`
			Platform          string `xml:"Platform"`
			ROMVolume         string `xml:"ROMVolume"`
			TelecomPhoneToken struct {
				Text        string `xml:",chardata"`
				Mobiletoken string `xml:"mobiletoken"`
				Mobiletype  string `xml:"mobiletype"`
			} `xml:"TelecomPhoneToken"`
			IsRoot       string `xml:"isRoot"`
			CPUModel     string `xml:"CPUModel"`
			IDFA         string `xml:"IDFA"`
			IDFVORIGIN   string `xml:"IDFV_ORIGIN"`
			CardSlotInfo struct {
				Text    string `xml:",chardata"`
				SIMInfo struct {
					Text     string `xml:",chardata"`
					MCC      string `xml:"MCC"`
					IMEIIDFA string `xml:"IMEI_IDFA"`
					IDFVSIM  string `xml:"IDFV_SIM"`
					MNC      string `xml:"MNC"`
				} `xml:"SIMInfo"`
			} `xml:"CardSlotInfo"`
			DeviceScreenInfo struct {
				Text                  string `xml:",chardata"`
				ScreenScaledDensity   string `xml:"ScreenScaledDensity"`
				ScreenXdpi            string `xml:"ScreenXdpi"`
				ScreenColorDepth      string `xml:"ScreenColorDepth"`
				ScreenHeight          string `xml:"ScreenHeight"`
				ScreenYdpi            string `xml:"ScreenYdpi"`
				ScreenWidth           string `xml:"ScreenWidth"`
				ScreenDensity         string `xml:"ScreenDensity"`
				ScreenAvailableHeight string `xml:"ScreenAvailableHeight"`
			} `xml:"DeviceScreenInfo"`
			OSUserAgent    string `xml:"OSUserAgent"`
			IMSI           string `xml:"IMSI"`
			MobileModel    string `xml:"MobileModel"`
			RAMVolume      string `xml:"RAMVolume"`
			PhoneNickName  string `xml:"PhoneNickName"`
			MobileProducer string `xml:"MobileProducer"`
			SystemVersion  string `xml:"SystemVersion"`
			IDFV           string `xml:"IDFV"`
			DeviceName     string `xml:"DeviceName"`
			DeviceType     string `xml:"DeviceType"`
		} `xml:"DeviceInfo"`
	} `xml:"BasicData"`
	LoginTypeSettingInfo struct {
		Text               string `xml:",chardata"`
		TouchIdSettingInfo string `xml:"TouchIdSettingInfo"`
		GestureSettingInfo string `xml:"GestureSettingInfo"`
	} `xml:"LoginTypeSettingInfo"`
	AgreementVersion  string `xml:"AgreementVersion"`
	HealthCodeData    string `xml:"HealthCodeData"`
	HealthCodeCounter string `xml:"HealthCodeCounter"`
}

type smsLoginReq struct {
	Key       string `json:"Key"`
	PostData  string `json:"PostData"`
	ExtraData string `json:"ExtraData"` // extraData
}

type smsLoginResp struct {
	Code string `json:"Code"`
	Data struct {
		ActionType string `json:"ActionType"`
		AlertParam struct {
			Title   string `json:"Title"`
			Msg     string `json:"Msg"`
			Buttons []struct {
				Text       string `json:"Text"`
				ActionType string `json:"ActionType"`
				URL        string `json:"Url"`
				LogCode    string `json:"LogCode"`
			} `json:"Buttons"`
		} `json:"AlertParam"`
	} `json:"Data"`
}

type verifyData struct {
	XMLName      xml.Name `xml:"verifyData"`
	Text         string   `xml:",chardata"`
	SignString   string   `xml:"signString"`
	VerifyResult string   `xml:"verifyResult"`
	Device       struct {
		Text        string `xml:",chardata"`
		DeviceType  string `xml:"deviceType"`
		MobileBrand string `xml:"mobileBrand"`
		Version     string `xml:"version"`
		MobileIMEI  string `xml:"mobileIMEI"`
		MobileIMSI  string `xml:"mobileIMSI"`
		MobileMAC   string `xml:"mobileMAC"`
		Longitude   string `xml:"longitude"`
		Latitude    string `xml:"latitude"`
		Accuracy    string `xml:"accuracy"`
	} `xml:"device"`
	FaceData struct {
		Text            string `xml:",chardata"`
		FaceImg         string `xml:"faceImg"`
		FaceImgHash     string `xml:"faceImgHash"`
		HackerDetectStr string `xml:"hackerDetectStr"`
	} `xml:"faceData"`
}

type authToken struct {
	XMLName       xml.Name `xml:"AuthToken"`
	Text          string   `xml:",chardata"`
	ResultType    string   `xml:"ResultType"`
	AuthData      string   `xml:"AuthData"`
	EncryptedType string   `xml:"EncryptedType"`
	AuthName      string   `xml:"AuthName"`
	AuthSignature string   `xml:"AuthSignature"`
	Timastamp     string   `xml:"Timastamp"`
}

type loginResp struct {
	XMLName                xml.Name `xml:"LoginResp"`
	Text                   string   `xml:",chardata"`
	HasOneNetLoginPassword string   `xml:"HasOneNetLoginPassword"`
	HasDebitCard           string   `xml:"HasDebitCard"`
	HasCreditCard          string   `xml:"HasCreditCard"`
	LoginType              string   `xml:"LoginType"`
	OuterToken             struct {
		Text      string `xml:",chardata"`
		AuthToken authToken
	} `xml:"OuterToken"`
	UID                string `xml:"UID"`
	UIDSM              string `xml:"UID_SM"`
	NamePlusID         string `xml:"NamePlusID"`
	NamePlusIDSM       string `xml:"NamePlusID_SM"`
	Name               string `xml:"Name"`
	Sex                string `xml:"Sex"`
	UserRealNameAuthed string `xml:"UserRealNameAuthed"`
	UserBankCardNum    string `xml:"UserBankCardNum"`
	UserSurName        string `xml:"UserSurName"`
	UserRealName       string `xml:"UserRealName"`
	InnerToken         struct {
		Text         string `xml:",chardata"`
		ApplyFlag    string `xml:"ApplyFlag"`
		ApplyMessage string `xml:"ApplyMessage"`
		AuthResponse struct {
			Text             string `xml:",chardata"`
			AuthResponseHead struct {
				Text        string `xml:",chardata"`
				AuthVersion string `xml:"AuthVersion"`
			} `xml:"AuthResponseHead"`
			AuthResponseBody struct {
				Text           string `xml:",chardata"`
				CipherToken    string `xml:"CipherToken"`
				AuthTimestamp  string `xml:"AuthTimestamp"`
				ValidityPeriod string `xml:"ValidityPeriod"`
				AuthInfo       struct {
					Text     string `xml:",chardata"`
					AuthItem []struct {
						Text         string `xml:",chardata"`
						AuthName     string `xml:"AuthName"`
						ServerPrefix string `xml:"ServerPrefix"`
					} `xml:"AuthItem"`
				} `xml:"AuthInfo"`
			} `xml:"AuthResponseBody"`
		} `xml:"AuthResponse"`
	} `xml:"InnerToken"`
	ServerSysTime1 string `xml:"ServerSysTime1"`
	ServerSysTime2 string `xml:"ServerSysTime2"`
	ServerTagName  string `xml:"ServerTagName"`
}

type baseResp struct {
	Code string
	Data interface{}
}

type pollingQueryResultResp struct {
	XMLName xml.Name `xml:"Response"`
	Text    string   `xml:",chardata"`
	Head    struct {
		Text   string `xml:",chardata"`
		Code   string `xml:"Code"`
		ErrMsg string `xml:"ErrMsg"`
	} `xml:"Head"`
	Body struct {
		Text  string `xml:",chardata"`
		Value string `xml:"Value"`
	} `xml:"Body"`
}

type qrcodeVerifyLoginResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			ErrCode      string `json:"ErrCode"`
			DispMsg      string `json:"DispMsg"`
			VerifyResult string `json:"VerifyResult"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type responseData struct {
	XMLName        xml.Name `xml:"ResponseData"`
	Text           string   `xml:",chardata"`
	IsEncrypted    string   `xml:"IsEncrypted"`
	IsCompressored string   `xml:"IsCompressored"`
	LoginRoot      string   `xml:"LoginRoot"`
}

type loginResponse struct {
	TarSvr string `json:"TarSvr"`
	PrcCod string `json:"PrcCod"`
	RtnCod string `json:"RtnCod"`
	ErrMsg string `json:"ErrMsg"`
	InfBdy struct {
		LoginFlag    string `json:"LoginFlag"`
		LoginMessage string `json:"LoginMessage"`
		LoadFlag     string `json:"LoadFlag"`
		ServerURL    string `json:"ServerURL"`
		ClientNo     string `json:"ClientNo"`
		ErrPage      string `json:"ErrPage"`
	} `json:"InfBdy"`
}
type myMenuResp struct {
	ScoreNum struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
		Pic        string `json:"pic"`
		PicID      string `json:"picID"`
		Name       string `json:"name"`
	} `json:"ScoreNum"`
	TicketNum struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
	} `json:"TicketNum"`
	BankCardNum struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
		Pic        string `json:"pic"`
		PicID      string `json:"picID"`
	} `json:"BankCardNum"`
	RemindInfo struct {
		URL      string `json:"url"`
		Content1 string `json:"content1"`
		Content2 string `json:"content2"`
		Datatype string `json:"datatype"`
		Func     string `json:"func"`
		TODOSTS  string `json:"TODOSTS"`
	} `json:"RemindInfo"`
	RemindNum struct {
		Count string `json:"count"`
	} `json:"RemindNum"`
	UserName struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
	} `json:"UserName"`
	LastLoginTime struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
	} `json:"LastLoginTime"`
	UserIDLevel struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
	} `json:"UserIdLevel"`
	CustomerID struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
		ValueSM    string `json:value_SM`
	} `json:"CustomerID"`
	ABTestInfo struct {
		ResultCode string `json:"resultCode"`
		MenuIDSet  string `json:"menuIdSet"`
		CustomCfg  string `json:"customCfg"`
	} `json:"ABTestInfo"`
	AvatarHeadImage struct {
		ResultCode string `json:"resultCode"`
		NickName   string `json:"NickName"`
	} `json:"AvatarHeadImage"`
	AsynchronousOpen struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
		Mode       string `json:"mode"`
	} `json:"AsynchronousOpen"`
	Tips struct {
		ResultCode string `json:"resultCode"`
		Value      string `json:"value"`
		Mobile     string `json:"Mobile"`
		Action     string `json:"action"`
	} `json:"Tips"`
	CMBCard struct {
		ResultCode    string `json:"resultCode"`
		IsHaveCMBCard string `json:"isHaveCMBCard"`
	} `json:"CMBCard"`
}

type cardListResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			ErrCode     string `json:"ErrCode"`
			TrxDateList struct {
				ShowDateListDatas []struct {
					Text  string `json:"text"`
					Value string `json:"value"`
				} `json:"ShowDateListDatas"`
				SelectIndex string `json:"SelectIndex"`
			} `json:"TrxDateList"`
			TrxCardList struct {
				ShowCardListDatas []struct {
					Name       string `json:"name"`
					Bank       string `json:"bank"`
					AccountUID string `json:"accountUID"`
					Display    string `json:"display"`
					SortIndex  string `json:"sortIndex,omitempty"`
					Account    string `json:"account,omitempty"`
					Type       string `json:"type,omitempty"`
				} `json:"ShowCardListDatas"`
				SelectIndex string `json:"SelectIndex"`
			} `json:"TrxCardList"`
			CardNum            string `json:"CardNum"`
			CmbCardNum         string `json:"CmbCardNum"`
			IsContainDebitCard string `json:"IsContainDebitCard"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type ajaxBaseResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			ErrCode string `json:"ErrCode"`
			DispMsg string `json:"DispMsg"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type billListResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			MonthSummaryList struct {
				MonthSummaryRecord []struct {
					DateMonth    string `json:"DateMonth"`
					Month        string `json:"Month"`
					Year         string `json:"Year"`
					TotalIn      string `json:"TotalIn"`
					TotalOut     string `json:"TotalOut"`
					CardType     string `json:"CardType"`
					CardUID      string `json:"CardUid"`
					BudgetUserd  string `json:"BudgetUserd"`
					BudgetLeft   string `json:"BudgetLeft"`
					BudgetAmount string `json:"BudgetAmount"`
					Budget       string `json:"Budget"`
					CurMonthFlag string `json:"CurMonthFlag"`
					SumBalance   string `json:"SumBalance"`
					ACardBalance string `json:"ACardBalance"`
					CCardBalance string `json:"CCardBalance"`
					EncryCardNo  string `json:"EncryCardNo"`
				} `json:"MonthSummaryRecord"`
				ErrCode string `json:"ErrCode"`
			} `json:"monthSummaryList"`
			TransactionList struct {
				TransactionRecord []struct {
					TrxLevel1       string `json:"TrxLevel1"`
					TrxLevel2       string `json:"TrxLevel2"`
					TrxLevel3       string `json:"TrxLevel3"`
					TrxLevel2Desc   string `json:"TrxLevel2Desc"`
					CardType        string `json:"CardType"`
					TrxFlag         string `json:"TrxFlag"`
					TrxAmount       string `json:"TrxAmount"`
					TrxAmount400    string `json:"TrxAmount400"`
					CurrencyCode    string `json:"CurrencyCode"`
					TrxDes          string `json:"TrxDes"`
					TrxNo           string `json:"TrxNo"`
					TrxTime         string `json:"TrxTime"`
					DetailType      string `json:"DetailType"`
					SelfTrxFlag     string `json:"SelfTrxFlag"`
					EnterAcountFlag string `json:"EnterAcountFlag"`
					RtFlag          string `json:"RtFlag"`
					DisplayCard     string `json:"DisplayCard"`
					DateMonth       string `json:"DateMonth"`
					DisplayAmout    string `json:"DisplayAmout"`
					DB1Code         string `json:"DB1Code"`
					PicFlag         string `json:"PicFlag"`
					AmountLength    int    `json:"AmountLength"`
					TrxDate         string `json:"TrxDate"`
					BalanceAmount   string `json:"BalanceAmount"`
					DataDate        string `json:"DataDate"`
					TrxMonth        string `json:"TrxMonth"`
					NotModifyFlag   bool   `json:"NotModifyFlag"`
					HaveModifyFlag  bool   `json:"HaveModifyFlag"`
					DisplayCardHalf string `json:"DisplayCardHalf"`
					RMBAMT          string `json:"RMB_AMT"`
					QUACOD          string `json:"QUA_COD"`
					MCH2DES         string `json:"MCH2_DES"`
					EncryCardNo     string `json:"EncryCardNo"`
					OherCardName    string `json:"OherCardName"`
					CurrencySymbol  string `json:"CurrencySymbol"`
					IsCustomTrans   string `json:"IsCustomTrans"`
					UserDes         string `json:"UserDes"`
					EncryEacID      string `json:"EncryEacId"`
					CreditTransType string `json:"CreditTransType"`
					TrxTimeNew      string `json:"TrxTimeNew"`
				} `json:"TransactionRecord"`
				ErrCode string `json:"ErrCode"`
			} `json:"transactionList"`
			TransactionByDateList struct {
				TransactionByDates []struct {
					TransactionByDate []struct {
						TrxLevel1       string `json:"TrxLevel1"`
						TrxLevel2       string `json:"TrxLevel2"`
						TrxLevel3       string `json:"TrxLevel3"`
						TrxLevel2Desc   string `json:"TrxLevel2Desc"`
						CardType        string `json:"CardType"`
						TrxFlag         string `json:"TrxFlag"`
						TrxAmount       string `json:"TrxAmount"`
						TrxAmount400    string `json:"TrxAmount400"`
						CurrencyCode    string `json:"CurrencyCode"`
						TrxDes          string `json:"TrxDes"`
						TrxNo           string `json:"TrxNo"`
						TrxTime         string `json:"TrxTime"`
						DetailType      string `json:"DetailType"`
						SelfTrxFlag     string `json:"SelfTrxFlag"`
						EnterAcountFlag string `json:"EnterAcountFlag"`
						RtFlag          string `json:"RtFlag"`
						DisplayCard     string `json:"DisplayCard"`
						DateMonth       string `json:"DateMonth"`
						DisplayAmout    string `json:"DisplayAmout"`
						DB1Code         string `json:"DB1Code"`
						PicFlag         string `json:"PicFlag"`
						AmountLength    int    `json:"AmountLength"`
						TrxDate         string `json:"TrxDate"`
						BalanceAmount   string `json:"BalanceAmount"`
						DataDate        string `json:"DataDate"`
						TrxMonth        string `json:"TrxMonth"`
						NotModifyFlag   bool   `json:"NotModifyFlag"`
						HaveModifyFlag  bool   `json:"HaveModifyFlag"`
						DisplayCardHalf string `json:"DisplayCardHalf"`
						RMBAMT          string `json:"RMB_AMT"`
						QUACOD          string `json:"QUA_COD"`
						MCH2DES         string `json:"MCH2_DES"`
						EncryCardNo     string `json:"EncryCardNo"`
						OherCardName    string `json:"OherCardName"`
						CurrencySymbol  string `json:"CurrencySymbol"`
						IsCustomTrans   string `json:"IsCustomTrans"`
						UserDes         string `json:"UserDes"`
						EncryEacID      string `json:"EncryEacId"`
						CreditTransType string `json:"CreditTransType"`
						TrxTimeNew      string `json:"TrxTimeNew"`
					} `json:"TransactionByDate"`
					TrxDate  string `json:"TrxDate"`
					TrxMonth string `json:"TrxMonth"`
				} `json:"TransactionByDates"`
				ErrCode string `json:"ErrCode"`
			} `json:"transactionByDateList"`
			TransactionByMonthList struct {
				TransactionByMonths []struct {
					TransactionByDates []struct {
						TransactionByDate []struct {
							TrxLevel1       string `json:"TrxLevel1"`
							TrxLevel2       string `json:"TrxLevel2"`
							TrxLevel3       string `json:"TrxLevel3"`
							TrxLevel2Desc   string `json:"TrxLevel2Desc"`
							CardType        string `json:"CardType"`
							TrxFlag         string `json:"TrxFlag"`
							TrxAmount       string `json:"TrxAmount"`
							TrxAmount400    string `json:"TrxAmount400"`
							CurrencyCode    string `json:"CurrencyCode"`
							TrxDes          string `json:"TrxDes"`
							TrxNo           string `json:"TrxNo"`
							TrxTime         string `json:"TrxTime"`
							DetailType      string `json:"DetailType"`
							SelfTrxFlag     string `json:"SelfTrxFlag"`
							EnterAcountFlag string `json:"EnterAcountFlag"`
							RtFlag          string `json:"RtFlag"`
							DisplayCard     string `json:"DisplayCard"`
							DateMonth       string `json:"DateMonth"`
							DisplayAmout    string `json:"DisplayAmout"`
							DB1Code         string `json:"DB1Code"`
							PicFlag         string `json:"PicFlag"`
							AmountLength    int    `json:"AmountLength"`
							TrxDate         string `json:"TrxDate"`
							BalanceAmount   string `json:"BalanceAmount"`
							DataDate        string `json:"DataDate"`
							TrxMonth        string `json:"TrxMonth"`
							NotModifyFlag   bool   `json:"NotModifyFlag"`
							HaveModifyFlag  bool   `json:"HaveModifyFlag"`
							DisplayCardHalf string `json:"DisplayCardHalf"`
							RMBAMT          string `json:"RMB_AMT"`
							QUACOD          string `json:"QUA_COD"`
							MCH2DES         string `json:"MCH2_DES"`
							EncryCardNo     string `json:"EncryCardNo"`
							OherCardName    string `json:"OherCardName"`
							CurrencySymbol  string `json:"CurrencySymbol"`
							IsCustomTrans   string `json:"IsCustomTrans"`
							UserDes         string `json:"UserDes"`
							EncryEacID      string `json:"EncryEacId"`
							CreditTransType string `json:"CreditTransType"`
							TrxTimeNew      string `json:"TrxTimeNew"`
						} `json:"TransactionByDate"`
						TrxDate  string `json:"TrxDate"`
						TrxMonth string `json:"TrxMonth"`
					} `json:"TransactionByDates"`
					TrxMonth string `json:"TrxMonth"`
				} `json:"TransactionByMonths"`
				ErrCode string `json:"ErrCode"`
			} `json:"transactionByMonthList"`
			ErrCode          string `json:"ErrCode"`
			TRXGRPTAB        string `json:"TRX_GRP_TAB"`
			TRXLSTSIT        string `json:"TRX_LST_SIT"`
			LSTFNYFLG        string `json:"LST_FNY_FLG"`
			TRXLSTTAB        string `json:"TRX_LST_TAB"`
			DATDTE           string `json:"DAT_DTE"`
			UPDFLG           string `json:"UPD_FLG"`
			LSTFNYMON        string `json:"LST_FNY_MON"`
			LastTrxDate      string `json:"LastTrxDate"`
			LastTrxMonth     string `json:"LastTrxMonth"`
			MoreTrxData      string `json:"MoreTrxData"`
			SelectedCardType string `json:"SelectedCardType"`
			IsShowBalance    string `json:"IsShowBalance"`
			ESTRXSIT         string `json:"ES_TRX_SIT"`
			ESFNYFLG         string `json:"ES_FNY_FLG"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type loginInfo struct {
	XMLName     xml.Name `xml:"LoginInfo"`
	Text        string   `xml:",chardata"`
	AID         string   `xml:"AID"`
	Model       string   `xml:"Model"`
	Manufacture string   `xml:"Manufacture"`
	Lat         string   `xml:"lat"`
	Lng         string   `xml:"lng"`
	Logined     string   `xml:"Logined"`
	LoginID     string   `xml:"LoginID"`
	LoginType   string   `xml:"LoginType"`
	ServerAuth  struct {
		Text      string `xml:",chardata"`
		AuthToken authToken
	} `xml:"ServerAuth"`
	ClientNo string `xml:"ClientNo"`
}

type netPayPreLoginResp struct {
	XMLName xml.Name `xml:"Response"`
	Head    struct {
		Code   string `xml:"Code"`
		ErrMsg string `xml:"ErrMsg"`
	} `xml:"Head"`
	Body string `xml:"Body"`
}

type netPayGetQRUrlResp struct {
	XMLName xml.Name `xml:"Response"`
	Text    string   `xml:",chardata"`
	Head    struct {
		Text   string `xml:",chardata"`
		Code   string `xml:"Code"`
		ErrMsg string `xml:"ErrMsg"`
	} `xml:"Head"`
	Body struct {
		Text string `xml:",chardata"`
		QRNo string `xml:"QRNo"`
	} `xml:"Body"`
}

type deviceFPCodeRes struct {
	CookieCode string `json:"cookieCode"`
	Dfp        string `json:"dfp"`
	Exp        string `json:"exp"`
}

type routeResp struct {
	Code string `json:"Code"`
	Data struct {
		ActionType string `json:"ActionType"`
		LoginParam struct {
			LoginType     string `json:"loginType"`
			EncType       string `json:"encType"`
			CustomUIParam struct {
				LoginID               string `json:"loginId"`
				LoginIDType           string `json:"loginIdType"`
				UIType                string `json:"UIType"`
				Title                 string `json:"title"`
				Description           string `json:"description"`
				AfterLoginAction      string `json:"afterLoginAction"`
				AfterLoginActionParam string `json:"afterLoginActionParam"`
				Trans2SrvParam        string `json:"trans2SrvParam"`
			} `json:"customUIParam"`
		} `json:"LoginParam"`
	} `json:"Data"`
}

type queryBankResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			IsMatchCardBin       string  `json:"IsMatchCardBin"`
			IsMatchBranch        string  `json:"IsMatchBranch"`
			InnBkn               string  `json:"InnBkn"`
			BnkName              string  `json:"BnkName"`
			ImdBkn               string  `json:"ImdBkn"`
			ImdSpc               string  `json:"ImdSpc"`
			CmbCty               string  `json:"CmbCty"`
			IsMatchRealTime      string  `json:"IsMatchRealTime"`
			PbcBkn               string  `json:"PbcBkn"`
			RealTimeOn           string  `json:"RealTimeOn"`
			BigTransferOn        string  `json:"BigTransferOn"`
			SmallTransferOn      string  `json:"SmallTransferOn"`
			BeginTime            string  `json:"BeginTime"`
			EndTime              string  `json:"EndTime"`
			CCLPayee             string  `json:"CCLPayee"`
			BStandCard           string  `json:"BStandCard"`
			NeedFillCty          string  `json:"NeedFillCty"`
			PublicAcc            string  `json:"PublicAcc"`
			BigCurDateType       string  `json:"BigCurDateType"`
			BigNextDateType      string  `json:"BigNextDateType"`
			BigRemarkTime        string  `json:"BigRemarkTime"`
			SmallChannelLimit    float64 `json:"SmallChannelLimit"`
			RealtimeChannelLimit float64 `json:"RealtimeChannelLimit"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type queryDataInfo struct {
	XMLName xml.Name `xml:"Response"`
	Text    string   `xml:",chardata"`
	Version string   `xml:"Version"`
	Content struct {
		Text        string `xml:",chardata"`
		GeneralData struct {
			Text           string `xml:",chardata"`
			BusssinessType string `xml:"BusssinessType"`
			SessionId      string `xml:"SessionId"`
			Token          string `xml:"Token"`
			ServerTime     string `xml:"ServerTime"`
		} `xml:"GeneralData"`
		ParamData struct {
			Text string `xml:",chardata"`
			UID  string `xml:"UID"`
		} `xml:"ParamData"`
	} `xml:"Content"`
	Signature string `xml:"Signature"`
}

type fpVerify struct {
	XMLName     xml.Name `xml:"FPVerify"`
	Text        string   `xml:",chardata"`
	GeneralData struct {
		Text           string `xml:",chardata"`
		BusssinessType string `xml:"BusssinessType"`
		SessionID      string `xml:"SessionId"`
		Token          string `xml:"Token"`
		ServerTime     string `xml:"ServerTime"`
	} `xml:"GeneralData"`
	ResultData struct {
		Text          string `xml:",chardata"`
		FPSupport     string `xml:"FPSupport"`
		SystemFPSetup string `xml:"SystemFPSetup"`
		GlobalFPSetup string `xml:"GlobalFPSetup"`
		TransFPSetup  string `xml:"TransFPSetup"`
		LoginFPSetup  string `xml:"LoginFPSetup"`
	} `xml:"ResultData"`
}

type queryVerifyResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			Sucess       string `json:"Sucess"`
			Error        string `json:"Error"`
			NextStep     string `json:"NextStep"`
			CustID       string `json:"CustID"`
			PhoneNo      string `json:"PhoneNo"`
			AddressMatch string `json:"AddressMatch"`
			PayeeCard    string `json:"PayeeCard"`
			Money        string `json:"Money"`
			VTMData      string `json:"VTMData"`
			ReturnURL    string `json:"ReturnURL"`
			FingerInfo   struct {
				Content   string `json:"Content"`
				Signature string `json:"Signature"`
			} `json:"FingerInfo"`
			IsFirstFingerVerify string `json:"IsFirstFingerVerify"`
			PayeeName           string `json:"PayeeName"`
			BankName            string `json:"BankName"`
			More30WRemark       string `json:"More30WRemark"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type smsVerifyResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			Sucess              string `json:"Sucess"`
			Error               string `json:"Error"`
			VerifyType          string `json:"VerifyType"`
			NextStep            string `json:"NextStep"`
			FingerInfo          string `json:"FingerInfo"`
			IsFirstFingerVerify string `json:"IsFirstFingerVerify"`
			More30WRemark       string `json:"More30WRemark"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type submitResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			Sucess          string `json:"Sucess"`
			Error           string `json:"Error"`
			BusTrxDat       string `json:"BusTrxDat"`
			BusTrxSet       string `json:"BusTrxSet"`
			BusCfmTim       string `json:"BusCfmTim"`
			FeeAmount       string `json:"FeeAmount"`
			FeeConfirm      string `json:"FeeConfirm"`
			BusTrxMod       string `json:"BusTrxMod"`
			AppendTypeLimit string `json:"AppendTypeLimit"`
			TranID          string `json:"TranId"`
			CurrencyCode    string `json:"CurrencyCode"`
			BusTrxSetNew    string `json:"BusTrxSetNew"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}

type transferResp struct {
	SysResult struct {
		SysCode int `json:"$SysCode$"`
		Content struct {
			ErrCode      string `json:"ErrCode"`
			BusPrcRst    string `json:"BusPrcRst"`
			Package      string `json:"Package"`
			TransCacheID string `json:"TransCacheId"`
		} `json:"$Content$"`
	} `json:"$SysResult$"`
}
