package cmb

import (
	"awesome/tools"
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"github.com/twmb/murmur3"
	"net/http"
	"net/url"
	"strings"

	"github.com/go-http-utils/headers"
)

func (b *Bank) getClientCfg() *getClientCfgResp {
	respObj := &getClientCfgResp{}

	header := b.addBaseHeaders()

	postObj := &getClientCfgPostData{
		DeviceType:    "D",
		MenuHash:      b.MenuHash,
		FuncListHash:  b.FuncListHash,
		MerchantHash:  "N",
		Version:       cfBundleVersion,
		AppID:         b.AppID,
		InnerID:       b.InnerID,
		SystemVersion: b.HardwareInfo.SystemVersion,
	}
	postObj.ExtraInfo.DeviceModel = b.HardwareInfo.Model
	postObj.ExtraInfo.DeviceVendor = "Apple Inc."

	postData, _ := xml.Marshal(postObj)

	key, postStr, sm4Key := b.encryptBodyB(postData)

	req := &url.Values{}
	req.Set("DeviceType", "D")
	req.Set("EncryptedType", "B")
	req.Set("Version", cfBundleVersion)
	req.Set("key", key)
	req.Set("postdata", postStr)

	resp, err := tools.DoHTTPPostForm(b.c, urlGetClientCfg, nil, header, []byte(req.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("getClientCfg doHTTPPOST出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return respObj
	}

	encryptResp := &baseEncryptResp{}
	err = json.Unmarshal(resp, encryptResp)
	if err != nil {
		logger.Error(">>>>>>>>getClientCfg baseResp json.Unmarshal resp=\r\n" + hex.Dump(resp))
		return respObj
	}

	if len(encryptResp.Content) <= 0 {
		logger.Error(">>>>>>>>getClientCfg 没有获取到Content Content=\r\n")
		return respObj
	}

	content, err := base64.StdEncoding.DecodeString(encryptResp.Content)
	if err != nil {
		logger.Errorf(">>>>>>>>getClientCfg base64.StdEncoding.DecodeString Content err=%+v content=%+v resp=\r\n", err, encryptResp.Content)
		return respObj
	}

	if encryptResp.IsEncrypted == "Y" {
		// 需要解密
		content, err = tools.SM4CBCDecrypt(content, []byte(sm4Key), []byte(sm4Key))
		if err != nil {
			logger.Errorf(">>>>>>>>getClientCfg tools.SM4CBCDecrypt Content err=%+v content=%+v sm4Key=%+v resp=\r\n", err, hex.Dump(content), sm4Key)
			return respObj
		}
	}

	if encryptResp.IsCompressed == "Y" {
		// 需要解压缩
		content, err = tools.GZipUncompress(content)
		if err != nil {
			logger.Errorf(">>>>>>>>getClientCfg tools.GZipUncompress err=%+v content=%+v", err, hex.Dump(content))
			return respObj
		}
	}

	respData := "<GetClientCfgResp>" + string(content) + "</GetClientCfgResp>"

	//logger.Info(">>>>>>>>getClientCfg\r\n" + respData)

	err = xml.Unmarshal([]byte(respData), respObj)
	if err != nil {
		logger.Errorf("getClientCfg xml.Unmarshal err=%+v data=\r\n%+v\r\n", err, respData)
	}

	return respObj
}

func (b *Bank) preLogin() *preLoginResp {
	respObj := &preLoginResp{}

	query := &url.Values{}

	header := b.addBaseHeaders()

	postObj := &preLoginPostData{
		DeviceType:          "D",
		AppID:               b.AppID,
		Version:             cfBundleVersion,
		SystemVersion:       b.HardwareInfo.SystemVersion,
		InnerID:             b.InnerID,
		IsRunningInEmulator: "N",
		IsRoot:              "N",
		MobileProducer:      "Apple Inc.",
		MobileModel:         b.HardwareInfo.Model,
		CPUModel:            "arm64 v8",
		IMEI:                "",
		IMSI:                "",
		IDFA:                b.IDFA,
		IDFV:                b.IDFV,
		NetworkType:         "WIFI",
		SSID:                "",
		BSSID:               "",
		City:                "",
		AppSessionID:        b.sid,
		HealthCodeData:      "",
		HealthCodeKey:       "",
	}

	postData, _ := xml.Marshal(postObj)

	logger.Info(">>>>>>>>preLogin req = " + string(postData))

	key, postStr, _ := b.encryptBodyB(postData)

	req := &url.Values{}
	req.Set("DeviceType", "D")
	req.Set("Version", cfBundleVersion)
	req.Set("command", "PRE_LOGIN")
	req.Set("postdata", postStr)
	req.Set("key", key)
	req.Set("EncryptedType", "B")

	resp, err := tools.DoHTTPPostForm(b.c, urlPreLogin, query, header, []byte(req.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("preLogin doHTTPPOST出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return respObj
	}

	respData := "<PreLoginResp>" + string(resp) + "</PreLoginResp>"

	logger.Info(">>>>>>>>preLogin resp = " + respData)

	err = xml.Unmarshal([]byte(respData), respObj)
	if err != nil {
		logger.Errorf("preLogin xml.Unmarshal err=%+v data=\r\n%+v\r\n", err, respData)
	}

	return respObj
}

func (b *Bank) firstLoginRoute() *routeResp {
	respObj := &routeResp{}

	query := &url.Values{}
	query.Set("clientNo", b.clientNo)

	header := b.addBaseHeaders()

	exData, _ := json.Marshal(&map[string]string{
		"IsRoot":              "N",
		"NetworkType":         "WIFI",
		"ShieldData":          b.getShieldData(),
		"IsRunningInEmulator": "N",
		"CPUModel":            "arm64 v8",
		"IDFA":                b.IDFA,
		"City":                "",
		"IMSI":                "",
		"BSSID":               "",
		"Longitude":           "",
		"MobileModel":         b.HardwareInfo.Model,
		"SSID":                "",
		"IMEI":                "",
		"DeviceFPCode":        "",
		"MobileProducer":      "Apple Inc.",
		"Latitude":            "",
		"SystemVersion":       b.HardwareInfo.SystemVersion,
		"InnerID":             b.InnerID,
		"Version":             cfBundleVersion,
		"IDFV":                b.IDFV,
		"DeviceType":          "D",
		"AppID":               b.AppID,
	})

	postData, _ := json.Marshal(&map[string]string{
		"LoginId": b.Account,
		//"EncryptedType": "B",
		"ExtraData": string(exData),
	})

	key, postStr, _ := b.encryptBodyB(postData)
	reqData, _ := json.Marshal(&map[string]string{
		"Key":      key,
		"PostData": postStr,
	})

	resp, err := tools.DoHTTPPostJSON(b.c, urlFirstLoginRoute, query, header, reqData)
	if err != nil || resp == nil {
		logger.Errorf("firstLoginRoute doHttpPOSTJson 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return nil
	}

	logger.Infof("firstLoginRoute resp Decrypt before>>>>>>>> %s", string(resp))
	resp, _ = base64.StdEncoding.DecodeString(string(resp))
	// 解密
	resp, err = tools.SM4CBCDecrypt(resp, []byte(sm4ConstKey), []byte(sm4ConstKey))

	logger.InfoJSON("firstLoginRoute resp Decrypt after>>>>>>>>", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("firstLoginRoute json.Unmarshal err=%+v data=\r\n%+v\r\n", err, resp)
	}

	return respObj
}

func (b *Bank) deviceFPCodeDownload() string {
	query := &url.Values{}
	query.Set("custID", "MPH")
	query.Set("serviceUrl", "https://dfpgw.paas.cmbchina.com/public/generate/jsonp")
	query.Set("channel", "IOS")
	query.Set("ts", tools.TimeFmt()[:8])

	header := &http.Header{}
	header.Set(headers.ContentType, "text/plain")
	header.Set(headers.Accept, "*/*")
	header.Set(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.UserAgent, b.userAgent())

	resp, err := tools.DoHTTPGet(b.c, urlDeviceDFCodeDownloadJs, query, header)
	if err != nil || resp == nil {
		logger.Errorf("deviceFPCodeDownload doHttpPOSTJson 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	logger.Info("deviceFPCodeDownload resp >>>>>>>>" + string(resp))

	return string(resp)
}

func (b *Bank) deviceFPCodePost() *deviceFPCodeRes {
	respObj := &deviceFPCodeRes{}

	query := &url.Values{}
	query.Set("channel", "IOS")

	header := &http.Header{}
	header.Set(headers.ContentType, "text/plain")
	header.Set(headers.Origin, "null")
	header.Set(headers.Accept, "*/*")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "gzip, deflate, br")
	header.Set(headers.UserAgent, b.userAgent())

	deviceNameHash, err := deviceHash(b.HardwareInfo.OwnerName)
	if err != nil {
		logger.Errorf("deviceHash 出错err=%+v OwnerName=%s deviceNameHash=%s", err, b.HardwareInfo.OwnerName, deviceNameHash)
		return respObj
	}

	// wapSmartID 计算
	str1 := fmt.Sprintf("32%d,%d-480not availableiPhone5,true,true", tools.ScreenHeightPt(b.HardwareInfo.Model), tools.ScreenWidthPt(b.HardwareInfo.Model))
	str2 := fmt.Sprintf("%s falsezh-CN32not available2not available%d,%d%d,%d-480Asia/Shanghaierrorerrortruefalsetruenot availableiPhonefalsefalsefalsefalsefalse5,true,trueArial,Arial Hebrew,Arial Rounded MT Bold,Courier,Courier New,Georgia,Helvetica,Helvetica Neue,Palatino,Times,Times New Roman,Trebuchet MS,Verdana%s",
		b.userAgent(),
		tools.ScreenHeightPt(b.HardwareInfo.Model), tools.ScreenWidthPt(b.HardwareInfo.Model), tools.ScreenHeightPt(b.HardwareInfo.Model), tools.ScreenWidthPt(b.HardwareInfo.Model),
		b.AudioFP)
	//35.10893253237009+tools.RandFloat(0.01))
	mm3 := murmur3.SeedNew128(31, 31)
	_, _ = mm3.Write([]byte(str1))
	md1 := mm3.Sum(nil)
	mm3 = murmur3.SeedNew128(31, 31)
	_, _ = mm3.Write([]byte(str2))
	md2 := mm3.Sum(nil)

	wapSmartID := fmt.Sprintf("%x%x", md1[:8], md2[8:])

	infoMap := map[string]string{
		"IDFA":            b.IDFA,
		"IDFV":            b.IDFVFP,
		"appVersion":      cfBundleVersion,
		"availableSystem": fmt.Sprintf("%d", b.DiskSpace-(tools.RandInt63()%(1*1024*1024*1024)+8*1024*1024*1024)),
		"batteryLevel":    fmt.Sprintf("%d", 100-tools.RandIntn(20)),
		"batteryStatus":   "1",
		"brightness":      fmt.Sprintf("%f", tools.RandFloat(0.3)+0.5),
		"carrier":         url.QueryEscape(b.HardwareInfo.Carrier),
		"cloakTags":       "000000",
		"cookieCode":      b.CookieCode,
		"custID":          "MPH",
		"debugTags":       "[0,1]",
		"deviceNameHash":  deviceNameHash,
		"isCydia":         "0",
		"isDebug":         "0",
		"isMulti":         "0",
		"isProxy":         "0",
		"isRooted":        "0",
		"isVM":            "0",
		"isVPN":           "0",
		"language":        "zh-Hans",
		"localCode":       b.LocalIP,
		"model":           b.HardwareInfo.Model,
		"multiTags":       "0",
		"networkCountry":  "CN",
		"networkOperator": "460" + b.HardwareInfo.CarrierCode,
		"networkType":     "WiFi",
		"packageName":     "com.cmbchina.MPBBank",
		"platform":        "IOS",
		"resolution":      fmt.Sprintf("[%d,%d]", tools.Width(b.HardwareInfo.ScreenSize), tools.Height(b.HardwareInfo.ScreenSize)),
		"rootedTags":      "[0,0,0]",
		"sdkVersion":      sdkVersion,
		"startupTime":     fmt.Sprintf("%d", b.StartupTime),
		"timezone":        "Asia/Shanghai",
		"timezoneOffset":  "+480",
		"totalMemory":     fmt.Sprintf("%d", b.PhysicalMemory),
		"totalSystem":     fmt.Sprintf("%d", b.DiskSpace),
		"version":         b.HardwareInfo.SystemVersion,
		"vmTags":          "0",
		"wapSmartID":      wapSmartID,
		"wifiEnable":      "1",
	}

	hashCode, err := allHashCode(infoMap)
	if err != nil {
		logger.Errorf("allHashCode 出错err=%+v", err)
		return respObj
	}
	infoMap["hashCode"] = hashCode
	infoMap["algID"] = b.AlgID
	infoMap["timestamp"] = fmt.Sprintf("%d", tools.TimestampEx())

	info, _ := json.Marshal(infoMap)

	key, iv := randKeyAndIv()
	enInfo, err := deviceFPEncrypt(string(info), key, iv)
	if err != nil {
		logger.Errorf("deviceFPEncrypt 出错err=%+v info=%s key=%s iv=%s enInfo=%s", err, string(info), key, iv, enInfo)
		return respObj
	}

	reqData, _ := json.Marshal(&map[string]interface{}{
		"bsk":       key + iv,
		"inputItem": enInfo,
		"bse":       1,
	})

	resp, err := tools.DoHTTPPost(b.c, urlDeviceDFCode, query, header, reqData)
	if err != nil || resp == nil {
		logger.Errorf("deviceFPCodePost doHttpPOSTJson 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return nil
	}

	logger.InfoJSON("deviceFPCodePost resp >>>>>>>>", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("deviceFPCodePost json.Unmarshal err=%+v data=\r\n%+v\r\n", err, resp)
	}

	return respObj
}

func (b *Bank) accountLogin() (*baseResp, string) {
	respObj := &baseResp{}

	query := &url.Values{}
	query.Set("clientNo", b.clientNo)

	header := b.addBaseHeaders()

	postData, _ := json.Marshal(&map[string]interface{}{
		"LoginData": map[string]interface{}{
			"LoginID":     b.Account,
			"LoginMethod": "pwd",
			"VerifyData": map[string]string{
				"Pwd":      sm2EncryptWithSid(b.LoginPwd, b.getSid()),
				"ExtraPwd": "",
			},
		},
		"CallLoginFunc": "",
		"GeneralData":   b.getGeneralData(),
	})
	key, postStr, origKey := b.encryptBodyB(postData)

	extra, _ := json.Marshal(&map[string]string{
		"LoginValue":               b.Account,
		"CurrentLoginOneNetUID":    b.UID,
		"CurrentLoginOneNetUID_SM": b.UIDSM,
	})

	reqData, _ := json.Marshal(&map[string]string{
		"EncryptedType": "B",
		"ExtraData":     sm4CBCEncryptUseLogKey(extra),
		"Key":           key,
		"PostData":      postStr,
	})

	resp, err := tools.DoHTTPPostJSON(b.c, urlAccountLogin, query, header, reqData)
	if err != nil || resp == nil {
		logger.Errorf("accountLogin doHttpPOSTJson 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return respObj, origKey
	}

	logger.InfoJSON(">>>>>>>>accountLogin", string(resp))

	err = json.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("accountLogin json.Unmarshal err=%+v", err)

	}
	return respObj, origKey
}

func (b *Bank) otherLogin(u, token string) *loginResponse {
	respObj := &loginResponse{}

	query := &url.Values{}

	header := b.addBaseHeaders()

	req := &url.Values{}
	req.Set("CipherToken", token)
	req.Set("AppID", b.getAid())
	req.Set("HealthCodeInfo", "")
	req.Set("latitude", "")
	req.Set("longitude", "")

	resp, err := tools.DoHTTPPostForm(b.c, u, query, header, []byte(req.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("otherLogin doHTTPPOST出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return nil
	}

	logger.Info("otherLogin >>>>>>> " + string(resp))

	if err = json.Unmarshal(resp, respObj); err != nil {
		logger.Errorf("otherLogin json.Unmarshal出现错误 err=%+v", err)
	}

	return respObj
}

func (b *Bank) vtmLogin() string {
	loginID := aesEcbEncryptUse2018Key([]byte(b.Account))

	query := &url.Values{}
	query.Set("loginId", base64.StdEncoding.EncodeToString(loginID))
	query.Set("clientNo", b.clientNo)
	query.Set("version", cfBundleVersion)
	query.Set("behavior_entryid", "lgg007002")

	header := b.addBaseHeaders()

	resp, err := tools.DoHTTPGet(b.c, urlVtmLogin, query, header)
	if err != nil || resp == nil {
		logger.Errorf("vtmLogin DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}
	logger.Infof("%s>>>>>>>>%s", "vtmLogin", string(resp))
	// 返回的是一个html
	return string(resp)
}

func (b *Bank) pushIDQuery(clientNO string) {
	query := &url.Values{}
	query.Set("AuthName", "PAccountNotice")
	query.Set("version", cfBundleVersion)
	query.Set("DeviceType", "D")
	query.Set("ClientNo", clientNO)

	header := b.addBaseHeaders()

	resp, err := tools.DoHTTPGet(b.c, urlPushIDQuery, query, header)
	if err != nil || resp == nil {
		logger.Errorf("pushIDQuery DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return
	}

	logger.Info("pushIDQuery >>>>>>> " + string(resp))
}

func (b *Bank) myMenuQuery(clientNO, req string) {
	query := &url.Values{}
	query.Set("AuthName", "GExternal")
	query.Set("ClientNo", clientNO)

	header := b.addBaseHeaders()

	aesKey := dynamicAesKey + string(bytes.Repeat([]byte{0x30}, 32-len(dynamicAesKey)))
	enPostData, _ := tools.AESECBEncrypt([]byte(req), []byte(aesKey))
	bPostData := base64.StdEncoding.EncodeToString(enPostData)
	bPostData = strings.ReplaceAll(bPostData, "+", "%2B")
	bPostData = strings.ReplaceAll(bPostData, "-", "%2F")
	bPostData = strings.ReplaceAll(bPostData, "=", "%3D")

	resp, err := tools.DoHTTPPostForm(b.c, urlMyMenuQuery, query, header, []byte("requestData="+bPostData))
	if err != nil || resp == nil {
		logger.Errorf("myMenuQuery DoHttpPostForm 出现错误 err=%+v", err)
		return
	}

	respB, _ := base64.StdEncoding.DecodeString(string(resp))
	respD := tools.AESECBDecrypt(respB, []byte(aesKey))

	logger.Info("myMenuQuery >>>>>>> " + string(respD))
	respObj := &myMenuResp{}
	_ = json.Unmarshal(respD, respObj)
	if respObj.CustomerID.Value != "" && respObj.CustomerID.Value != "0" {
		logger.Info("<<<<更新了CustomerID>>>>" + respObj.CustomerID.Value)
		b.CustomerID = respObj.CustomerID.Value
	}
	if respObj.CustomerID.ValueSM != "" && respObj.CustomerID.ValueSM != "0" {
		logger.Info("<<<<更新了CustomerIDSM>>>>" + respObj.CustomerID.ValueSM)
		b.CustomerIDSM = respObj.CustomerID.ValueSM
	}

}

func (b *Bank) getPage(u string) string {
	header := b.addBaseHeaders()

	resp, err := tools.DoHTTPGet(b.c, u, nil, header)
	if err != nil || resp == nil {
		logger.Errorf("getPage DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	resp, _ = tools.GBK2UTF8(resp)
	logger.Info("page >>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) verifyTrustyDevicePage(u string) string {
	header := b.addBaseHeaders()

	resp, err := tools.DoHTTPGet(b.c, u, nil, header)
	if err != nil || resp == nil {
		logger.Errorf("verifyTrustyDevicePage DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	logger.Info("verifyTrustyDevicePage >>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) qrCodeVerifyPage() string {
	form := &url.Values{}
	form.Set("Command", "")
	form.Set("behavior_entryid", "djx001004")
	form.Set("ClientNo", b.clientNo)

	header := &http.Header{}
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, fmt.Sprintf(urlSelectVerify, b.clientNo, cfBundleVersion, b.clientNo))
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")

	resp, err := tools.DoHTTPPostForm(b.c, urlQRcodeVerify+"?LoginRedirect=RTDRedirect", nil, header, []byte(form.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("qrCodeVerifyPage DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	logger.Info("qrCodeVerifyPage >>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) pollingQueryResult(uid string) *pollingQueryResultResp {
	respObj := &pollingQueryResultResp{}

	form := &url.Values{}
	form.Set("TrxID", uid)
	form.Set("TrxName", "QRCodeGLogin")

	header := &http.Header{}
	header.Set(headers.Origin, "https://mobile.cmbchina.com")
	header.Set(headers.Referer, urlQRcodeVerify+"?LoginRedirect=RTDRedirect")
	header.Set(headers.Accept, "*/*")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")

	resp, err := tools.DoHTTPPostForm(b.c, urlPollingQueryResult, nil, header, []byte(form.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("pollingQueryResult DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return respObj
	}

	logger.Info("pollingQueryResult >>>>>>> " + string(resp))
	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("pollingQueryResult xml.Unmarshal 出现错误 err=%+v resp=\r\n%+v", err, hex.Dump(resp))
	}

	return respObj
}

func (b *Bank) qrcodeVerifyLogin(uid string) *qrcodeVerifyLoginResp {
	respObj := &qrcodeVerifyLoginResp{}
	refer := urlQRcodeVerify + "?LoginRedirect=RTDRedirect"
	req := fmt.Sprintf("$RequestMode$=1&UIID=%s&loginTrail=%s&ClientNo=%s&Command=COMMOND_VERIFY",
		uid, "lgf-lge-djx-qbm-qbm-lge-djx-qbm-qbm-lge-djx-qbm-lge-djx-qbm-", b.clientNo)

	resp := b.ajax(urlQRcodeVerify, req, refer)

	logger.Info("qrcodeVerifyLogin >>>>>>> " + resp)
	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("qrcodeVerifyLogin json.Unmarshal err=%+v", err)
	}

	return respObj
}

func (b *Bank) verifyTrustyDevice(code, refer string) string {
	form := &url.Values{}
	form.Set("MsgVerifyCode", code)
	form.Set("Command", "CMD_CheckMsg")
	form.Set("behavior_entryid", "ntr003001")
	form.Set("ClientNo", b.clientNo)

	header := &http.Header{}
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")

	resp, err := tools.DoHTTPPostForm(b.c, urlVerifyTrust, nil, header, []byte(form.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("verifyTrustyDevice DoHttpGet 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	logger.Info("verifyTrustyDevice >>>>>>> " + string(resp))
	// 解析response
	prefix := "response = \""
	start := strings.Index(string(resp), prefix)
	if start == -1 {
		return ""
	}
	resp = resp[start+len(prefix):]
	end := strings.Index(string(resp), "\"")
	if end == -1 {
		return ""

	}
	resp = resp[:end]
	response, err := url.PathUnescape(string(resp))
	if err != nil {
		logger.Errorf("verifyTrustyDevice url.PathUnescape 出现错误 err=%+v resp=%+v", err, string(resp))
		return ""
	}

	resp, err = base64.StdEncoding.DecodeString(response)
	if err != nil {
		logger.Errorf("verifyTrustyDevice base64.StdEncoding.DecodeString 出现错误 err=%+v resp=%+v", err, response)
		return ""
	}
	return string(resp)
}

func (b *Bank) ajax(u, req, refer string) string {
	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.XRequestedWith, "XMLHttpRequest")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded; charset=UTF-8")
	header.Set(headers.Origin, "https://mobile.cmbchina.com")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	resp, err := tools.DoHTTPPost(b.c, u, nil, header, []byte(req))
	if err != nil || resp == nil {
		logger.Errorf("ajax DoHttpPost 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
		return ""
	}

	return string(resp)
}

func (b *Bank) queryExpectLoanAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlQueryExpectLoanAjax, req, refer)
	logger.Info("queryExpectLoanAjax >>>>>>>>> " + resp)
}

func (b *Bank) queryMyRecommendAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlQueryMyRecommendAjax, req, refer)
	logger.Info("queryMyRecommendAjax >>>>>>>>> " + resp)
}

func (b *Bank) incomeExpenseAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlIncomeExpenseAjax, req, refer)
	logger.Info("incomeExpenseAjax >>>>>>>>> " + resp)
}

func (b *Bank) myChannelRecommendAjax(clientNO, refer string) {
	time := url.QueryEscape(tools.TimeFmtEx3())
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&Device=D&CurrentTime=%s&ClientNo=%s&Command=",
		time, clientNO)
	resp := b.ajax(urlMyChannelRecommendAjax, req, refer)
	logger.Info("myChannelRecommendAjax >>>>>>>>> " + resp)
}

func (b *Bank) as01Ajax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlAs01Ajax, req, refer)
	logger.Info("as01Ajax >>>>>>>>> " + resp)
}

func (b *Bank) myLoanAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlMyLoanAjax, req, refer)
	logger.Info("myLoanAjax >>>>>>>>> " + resp)
}

func (b *Bank) creditStateAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlCreditStateAjax, req, refer)
	logger.Info("creditStateAjax >>>>>>>>> " + resp)
}

func (b *Bank) onlineStoreAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&CityName=&Lat=&Lon=&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlOnlineStoreAjax, req, refer)
	logger.Info("onlineStoreAjax >>>>>>>>> " + resp)
}

func (b *Bank) yestDayIncomeAjax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlYestDayIncomeAjax, req, refer)
	logger.Info("yestDayIncomeAjax >>>>>>>>> " + resp)
}

func (b *Bank) as03Ajax(clientNO, refer string) {
	req := fmt.Sprintf("$RequestMode$=1&RateForbid=N&RateControl=AVMC&ClientNo=%s&Command=", clientNO)
	resp := b.ajax(urlAs03Ajax, req, refer)
	logger.Info("as03Ajax >>>>>>>>> " + resp)
}

func (b *Bank) cardList(refer string) *cardListResp {
	respObj := &cardListResp{}

	req := fmt.Sprintf("$RequestMode$=1&DateMonth=&AccountUID=&ClientNo=%s&Command=CREATCARDANDDATE", b.dTransactionClientNO)
	resp := b.ajax(urlGeneralBillAjax, req, refer)

	logger.InfoJSON("cardList >>>>>>>>>>>> ", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("cardList json.Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) queryBaseCode(refer string) *ajaxBaseResp {
	respObj := &ajaxBaseResp{}

	req := fmt.Sprintf("$RequestMode$=1&ClientNo=%s&Command=QUERYBASECODE", b.dTransactionClientNO)
	resp := b.ajax(urlGeneralBillAjax, req, refer)

	logger.InfoJSON("queryBaseCode >>>>>>>>>>>> ", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("queryBaseCode json.Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) queryRedFlag(refer string) *ajaxBaseResp {
	respObj := &ajaxBaseResp{}

	req := fmt.Sprintf("$RequestMode$=1&ClientNo=%s&Command=QUERYREDFLAG", b.dTransactionClientNO)
	resp := b.ajax(urlGeneralBillAjax, req, refer)

	logger.InfoJSON("queryRedFlag >>>>>>>>>>>> ", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("queryRedFlag json.Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) billList(month, cardNo, refer string, last *billListResp) *billListResp {
	respObj := &billListResp{}

	var req string
	if last == nil {
		req = fmt.Sprintf("$RequestMode$=1&DateMonth=%s&CardNo=%s&ClientNo=%s&Command=QUERYTRXINFOLIST",
			month, cardNo, b.dTransactionClientNO)
	} else {
		// 翻页
		values := url.Values{}
		values.Set("DateMonth", last.SysResult.Content.LSTFNYMON)
		values.Set("CardNo", cardNo)
		values.Set("LST_FNY_FLG", last.SysResult.Content.LSTFNYFLG)
		values.Set("LST_FNY_MON", last.SysResult.Content.LSTFNYMON)
		values.Set("TRX_LST_SIT", last.SysResult.Content.TRXLSTSIT)
		values.Set("TRX_GRP_TAB", last.SysResult.Content.TRXGRPTAB)
		values.Set("TRX_LST_TAB", last.SysResult.Content.TRXLSTTAB)
		values.Set("ES_TRX_SIT", last.SysResult.Content.ESTRXSIT)
		values.Set("ES_FNY_FLG", last.SysResult.Content.ESFNYFLG)
		values.Set("DAT_DTE", last.SysResult.Content.DATDTE)
		req = fmt.Sprintf("$RequestMode$=1&ClientNo=%s&%s&Command=QUERYTRXINFOLIST", b.dTransactionClientNO, values.Encode())
	}

	resp := b.ajax(urlGeneralBillAjax, req, refer)

	logger.Infof("billList>>>>>>>>>>>> %s", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("billList json.Unmarshal err=%+v", err)
	}
	return respObj
}

func (b *Bank) netPayPreLogin(clientNo, serialNo, refer string) *netPayPreLoginResp {
	respObj := &netPayPreLoginResp{}

	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	loginInfoObj := &loginInfo{
		AID:         b.aid,
		Model:       b.HardwareInfo.Model,
		Manufacture: "Apple Inc.",
		Lat:         "",
		Lng:         "",
		Logined:     "Y",
		LoginID:     b.Account,
		LoginType:   "D",
		ClientNo:    b.clientNo,
	}
	loginInfoObj.ServerAuth.AuthToken = *b.serverAuthToken

	loginInfoData, _ := xml.Marshal(loginInfoObj)
	// 去掉<LoginInfo></LoginInfo>
	loginInfoStr := strings.ReplaceAll(string(loginInfoData), "<LoginInfo>", "")
	loginInfoStr = strings.ReplaceAll(loginInfoStr, "</LoginInfo>", "")
	// rc4 加密
	loginInfoData, _ = tools.CCCryptRC4Encrypt([]byte(loginInfoStr), []byte(netPayRc4Key))

	securityInfoStr := b.getSecData()
	// aes 加密
	aesKey := secAesKey + string(bytes.Repeat([]byte{0x30}, 32-len(secAesKey)))
	securityInfoData, _ := tools.AESECBEncrypt([]byte(securityInfoStr), []byte(aesKey))

	historyUserInfoStr := fmt.Sprintf(`<accountNumList><accountNum type="D">%s</accountNum></accountNumList>`, b.Account)
	historyUserInfoData, _ := tools.AESECBEncrypt([]byte(historyUserInfoStr), []byte(aesKey))

	v := &url.Values{}
	v.Set("ClientNo", clientNo)
	v.Set("SerialNo", serialNo)
	v.Set("LoginInfo", fmt.Sprintf("%x", loginInfoData))
	v.Set("SecurityInfo", base64.StdEncoding.EncodeToString(securityInfoData))
	v.Set("HistoryUserInfo", base64.StdEncoding.EncodeToString(historyUserInfoData))

	resp, err := tools.DoHTTPPost(b.c, urlMobileQRPreLogin, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("netPayPreLogin DoHttpPost 出现错误 err=%+v", err)
		return respObj
	}

	logger.Info("netPayPreLogin >>>>>>>> " + string(resp))

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("netPayPreLogin xml.Unmarshal 出现错误 err=%+v resp=\r\n%+v", err, hex.Dump(resp))
	}

	return respObj
}

func (b *Bank) netPayGetQR(clientNo, serialNo, refer string) {
	header := &http.Header{}
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	v := &url.Values{}
	v.Set("ClientNo", clientNo)
	v.Set("SerialNo", serialNo)

	resp, err := tools.DoHTTPPost(b.c, urlMobileQRGetQR, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("netPayGetQR DoHttpPost 出现错误 err=%+v", err)
		return
	}
	resp, _ = tools.GBK2UTF8(resp)
	logger.Info("netPayGetQR >>>>>>>> " + string(resp))
}

func (b *Bank) netPayGetDefaultCard(clientNo, serialNo, refer string) {
	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	v := &url.Values{}
	v.Set("ClientNo", clientNo)
	v.Set("SerialNo", serialNo)
	v.Set("DefaultCardList", "")

	resp, err := tools.DoHTTPPost(b.c, urlMobileQRGetDefaultCard, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("netPayGetDefaultCard DoHttpPost 出现错误 err=%+v", err)
		return
	}
	resp, _ = tools.GBK2UTF8(resp)
	logger.Info("netPayGetDefaultCard >>>>>>>> " + string(resp))
}

func (b *Bank) netPayGetQRUrl(amount, clientNo, serialNo, refer string) *netPayGetQRUrlResp {
	respObj := &netPayGetQRUrlResp{}

	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	v := &url.Values{}
	v.Set("ClientNo", clientNo)
	v.Set("SerialNo", serialNo)
	v.Set("AmountInput", amount)

	resp, err := tools.DoHTTPPost(b.c, urlMobileQRGetQRUrl, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("netPayGetQRUrl DoHttpPost 出现错误 err=%+v", err)
		return respObj
	}

	resp, _ = tools.GBK2UTF8(resp)

	logger.Info("netPayGetQRUrl >>>>>>>> " + string(resp))

	err = xml.Unmarshal(resp, respObj)
	if err != nil {
		logger.Errorf("netPayGetQRUrl xml.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump(resp))
	}

	return respObj
}

func (b *Bank) netPayQueryResult(qrCode, clientNo, serialNo, refer string) string {

	header := &http.Header{}
	header.Set(headers.Accept, "*/*")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	v := &url.Values{}
	v.Set("ClientNo", clientNo)
	v.Set("SerialNo", serialNo)
	v.Set("QRNo", qrCode)

	resp, err := tools.DoHTTPPost(b.c, urlMobileQRQueryResult, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("netPayGetQRUrl DoHttpPost 出现错误 err=%+v", err)
		return ""
	}

	logger.Info("netPayGetQRUrl >>>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) goTranInfo(u, srcCardUID, refer string) string {
	header := b.addBaseHeaders()
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

	v := &url.Values{}
	v.Set("Command", "")
	v.Set("AccountUID", srcCardUID)
	v.Set("rtnURL", urlTransferHome)
	v.Set("behavior_entryid", "trn001001")
	v.Set("_urlrefer", refer)

	resp, err := tools.DoHTTPPostForm(b.c, u, nil, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("goTranInfo DoHttpPostForm 出现错误 err=%+v", err)
		return ""
	}

	logger.Info("goTranInfo >>>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) queryBankInfo(srcCardUID, destCardNo, destName, refer string) *queryBankResp {
	respObj := &queryBankResp{}

	form := &url.Values{}
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("Command", "CMD_QUERYBANKNAMEAJAX")
	form.Set("AccountUID", srcCardUID)
	form.Set("TransCacheID", b.transCacheID)
	form.Set("OtherAccountNo", destCardNo)
	form.Set("OtherAccountName", destName)
	bankInfo := b.ajax(urlTranInfo, fmt.Sprintf("$RequestMode$=1&%s", form.Encode()), refer)
	logger.InfoJSON("查询银行返回 >>>>>>> ", bankInfo)

	err := json.Unmarshal([]byte(bankInfo), respObj)
	if err != nil {
		logger.Errorf("queryBankInfo json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(bankInfo)))
	}

	return respObj
}

func (b *Bank) queryVerify(srcCardUID, bankShortCode, bankCode, destCardNo, destName, amount, remark, queryData, refer string) (*queryVerifyResp, string, string, string) {
	respObj := &queryVerifyResp{}

	data, err := base64.StdEncoding.DecodeString(queryData)
	if err != nil {
		logger.Errorf("queryVerify base64 DecodeString err=%+v, queryData=%s", err, queryData)
		return respObj, "", "", ""
	}
	// 解密
	data = tools.AESECBDecrypt(data, []byte(queryTouchIDAESKey))
	qdi := &queryDataInfo{}
	err = xml.Unmarshal([]byte("<Response>"+string(data)+"</Response>"), qdi)
	if err != nil {
		logger.Errorf("queryVerify queryDataInfo xml.Unmarshal err=%+v, data=%s", err, "<Response>"+string(data)+"</Response>")
		return respObj, "", "", ""
	}
	fp := &fpVerify{}
	fp.GeneralData.BusssinessType = qdi.Content.GeneralData.BusssinessType
	fp.GeneralData.SessionID = qdi.Content.GeneralData.SessionId
	fp.GeneralData.Token = qdi.Content.GeneralData.Token
	fp.GeneralData.ServerTime = qdi.Content.GeneralData.ServerTime
	fp.ResultData.FPSupport = "Y"
	fp.ResultData.SystemFPSetup = "N"
	fp.ResultData.GlobalFPSetup = "N"
	fp.ResultData.TransFPSetup = "N"
	fp.ResultData.LoginFPSetup = "N"

	data, _ = xml.Marshal(fp)
	dataS := strings.ReplaceAll(string(data), "<FPVerify>", "")
	dataS = strings.ReplaceAll(dataS, "</FPVerify>", "")
	// 加密
	key, postStr, _ := b.encryptBody([]byte(dataS))

	form := &url.Values{}
	form.Set("SendMessage", "0")
	if b.isSmallBank {
		form.Set("PayeeBankValue", b.categoryBankNameCode)
		form.Set("PayeeRealTimeBank", "")
		form.Set("PayeeBranchBankName", b.branchBankName)
		form.Set("PayeeBranchBankNo", b.branchBankName)
		form.Set("PayeeProvince", b.province)
		form.Set("PayeeProvinceValue", b.province)
		form.Set("PayeeCity", b.city)
		form.Set("PayeeCityValue", b.cityValue)
	} else {
		form.Set("PayeeBankValue", bankShortCode)
		form.Set("PayeeRealTimeBank", bankCode)
		form.Set("PayeeBranchBankName", "")
		form.Set("PayeeBranchBankNo", "")
		form.Set("PayeeProvince", "")
		form.Set("PayeeProvinceValue", "")
		form.Set("PayeeCity", "")
		form.Set("PayeeCityValue", "")
	}
	form.Set("NormalTransferMode", "")
	form.Set("AccountUID", srcCardUID)
	form.Set("PayeeName", destName)
	form.Set("PayeeMobileNo", "")
	if b.isSameBank {
		form.Set("PayeeTransferMode", "0")
	} else if b.isSmallBank {
		form.Set("PayeeTransferMode", "1")
	} else {
		form.Set("PayeeTransferMode", "2")
	}
	form.Set("TransCacheID", b.transCacheID)
	form.Set("Action", "SaveTransInfo")
	form.Set("PayeeAccountNo", destCardNo)
	form.Set("TransMoney", amount)
	form.Set("ReturnUrl", "/NormalTransfer/TF_TranInfo.aspx")
	form.Set("CoinType", "100")
	form.Set("TransRemark", remark)
	if b.isSameBank {
		form.Set("ModeMenu", "R-N")
	} else if b.isSmallBank {
		form.Set("ModeMenu", "2H-N")
	} else {
		form.Set("ModeMenu", "R-2H-N")
	}
	if b.isSmallBank {
		form.Set("SelectedMode", "2H")
	} else {
		form.Set("SelectedMode", "R")
	}
	form.Set("BManualSelected", "")
	form.Set("CheckDuplicate", "N") // 检查重复转账
	form.Set("RandomKey", key)
	form.Set("EncryptData", postStr)
	form.Set("SupportFaceID", "N")
	form.Set("SystemVersion", b.HardwareInfo.SystemVersion)

	deviceFPCode := ""
	if b.DeviceFPCode != "" {
		en, _ := tools.SM4CBCEncrypt([]byte(b.DeviceFPCode), []byte(sm4TransferDeviceKey), []byte(sm4TransferDeviceKey))
		deviceFPCode = base64.StdEncoding.EncodeToString(en)
		form.Set("DeviceFPCode", deviceFPCode)
	}

	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("Command", "CMD_QUERYVERIFYAJAX")
	verifyInfo := b.ajax(urlTranInfo, fmt.Sprintf("$RequestMode$=1&%s", form.Encode()), refer)
	logger.InfoJSON("查询验证方式 >>>>>>> ", verifyInfo)

	err = json.Unmarshal([]byte(verifyInfo), respObj)
	if err != nil {
		logger.Errorf("queryVerify json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(verifyInfo)))
	}

	// 重复转账确认 直接在这里弄了
	if respObj.SysResult.Content.NextStep == "remark" {
		form.Set("CheckDuplicate", "N")
		verifyInfo = b.ajax(urlTranInfo, fmt.Sprintf("$RequestMode$=1&%s", form.Encode()), refer)
		logger.InfoJSON("确认重复转账后再次 查询验证方式 >>>>>>> ", verifyInfo)
		err = json.Unmarshal([]byte(verifyInfo), respObj)
		if err != nil {
			logger.Errorf("确认重复转账 queryVerify json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(verifyInfo)))
		}
	}
	return respObj, key, postStr, deviceFPCode
}

func (b *Bank) goVerifySmsPage(srcCardUID, bankShortCode, bankCode, destCardNo, destName, amout, remark, refer,
	key, postStr, deviceFPCode, transIDNew string) string {
	header := &http.Header{}
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	header.Set(headers.Origin, "https://mobile.cmbchina.com")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, refer)

	form := &url.Values{}
	form.Set("SendMessage", "0")
	if b.isSmallBank {
		form.Set("PayeeBankValue", b.categoryBankNameCode)
		form.Set("PayeeRealTimeBank", "")
		form.Set("PayeeBranchBankName", b.branchBankName)
		form.Set("PayeeBranchBankNo", b.branchBankName)
		form.Set("PayeeProvince", b.province)
		form.Set("PayeeProvinceValue", b.province)
		form.Set("PayeeCity", b.city)
		form.Set("PayeeCityValue", b.cityValue)
	} else {
		form.Set("PayeeBankValue", bankShortCode)
		form.Set("PayeeRealTimeBank", bankCode)
		form.Set("PayeeBranchBankName", "")
		form.Set("PayeeBranchBankNo", "")
		form.Set("PayeeProvince", "")
		form.Set("PayeeProvinceValue", "")
		form.Set("PayeeCity", "")
		form.Set("PayeeCityValue", "")
	}
	form.Set("NormalTransferMode", "")
	form.Set("UBTransferMode", "")
	form.Set("AccountUID", srcCardUID)
	form.Set("PayeeName", destName)
	form.Set("PayeeMobileNo", "")
	if b.isSameBank {
		form.Set("PayeeTransferMode", "0")
	} else if b.isSmallBank {
		form.Set("PayeeTransferMode", "1")
	} else {
		form.Set("PayeeTransferMode", "2")
	}
	form.Set("TransCacheID", b.transCacheID)
	form.Set("Action", "SaveTransInfo")
	form.Set("PayeeAccountNo", destCardNo)
	form.Set("TransMoney", amout)
	form.Set("ReturnUrl", "/NormalTransfer/TF_TranInfo.aspx")
	form.Set("CoinType", "100")
	form.Set("TransRemark", remark)
	if b.isSameBank {
		form.Set("ModeMenu", "R-N")
	} else if b.isSmallBank {
		form.Set("ModeMenu", "2H-N")
	} else {
		form.Set("ModeMenu", "R-2H-N")
	}
	if b.isSmallBank {
		form.Set("SelectedMode", "2H")
	} else {
		form.Set("SelectedMode", "R")
	}
	form.Set("BManualSelected", "")
	form.Set("CheckDuplicate", "N")
	form.Set("RandomKey", key)
	form.Set("EncryptData", postStr)
	form.Set("SupportFaceID", "N")
	form.Set("SystemVersion", b.HardwareInfo.SystemVersion)
	form.Set("MsgVerifyCmd", "CMD_MSG_SEND")
	form.Set("Command", "CMD_OPENMSGPAGE")
	if deviceFPCode != "" {
		form.Set("DeviceFPCode", deviceFPCode)
	}
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("TransID_New", transIDNew)
	form.Set("behavior_entryid", "ctr001006")
	form.Set("behavior_urlstatus", "next")

	resp, err := tools.DoHTTPPost(b.c, urlTranInfo, nil, header, []byte(form.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("goTranInfo DoHttpPostForm 出现错误 err=%+v", err)
		return ""
	}

	logger.Info("goTranInfo >>>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) doMsgVerify(code string) *smsVerifyResp {
	respObj := &smsVerifyResp{}

	form := &url.Values{}
	form.Set("MsgFlag_", b.msgFlag)
	form.Set("MsgCode", code)
	form.Set("MsgTips_", b.msgTips)
	form.Set("verifyHiddenChoice", "sms")
	form.Set("smsHiddenSendedOnce", "true")
	form.Set("OtpCode", "")
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("AccountUID", b.transferCardUID)
	form.Set("TransCacheID", b.transCacheID)
	form.Set("CurLatitude", "")
	form.Set("CurLongitude", "")
	form.Set("Command", "CMD_DOMSGVERIFY")

	bankInfo := b.ajax(urlTranInfo, fmt.Sprintf("$RequestMode$=1&%s", form.Encode()), urlTranInfo)
	logger.InfoJSON("doMsgVerify >>>>>>> ", bankInfo)

	err := json.Unmarshal([]byte(bankInfo), respObj)
	if err != nil {
		logger.Errorf("doMsgVerify json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(bankInfo)))
	}

	return respObj
}

func (b *Bank) doSubmit() *submitResp {
	respObj := &submitResp{}

	form := &url.Values{}
	form.Set("TransPwd", sm2EncryptWithSid(b.PayPwd, b.getSid()))
	form.Set("_encType", "S")
	form.Set("_RBKeyboardSecurity", "TransPwd")
	form.Set("AccountUID", b.transferCardUID)
	form.Set("TransCacheID", b.transCacheID)
	form.Set("SendCodeFlag", "SendCodeFlag")
	form.Set("PwdValue", "12")
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("Command", "OnCommand_DoAjaxSubmit")
	form.Set("TransID_New", b.transIDNew)

	resp := b.ajax(urlTranInfo, fmt.Sprintf("$RequestMode$=1&%s", tools.Form2Str(form)), urlTranInfo)
	logger.InfoJSON("doSubmit >>>>>>> ", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("doSubmit json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(resp)))
	}

	return respObj
}

func (b *Bank) goQueryResultPage(transIDNew string) string {
	header := &http.Header{}
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	header.Set(headers.AcceptLanguage, "zh-cn")
	header.Set(headers.AcceptEncoding, "br,gzip,deflate")
	header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	header.Set(headers.Origin, "https://mobile.cmbchina.com")
	header.Set(headers.UserAgent, b.userAgent())
	header.Set(headers.Referer, fmt.Sprintf(urlTranInfo+"?DeviceType=D&ClientNo=%s&version=%s", b.dTransferClientNO, cfBundleVersion))

	form := &url.Values{}
	form.Set("Command", "CMD_TRANSUCESS")
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("TransID_New", transIDNew)
	form.Set("behavior_entryid", "trc001006")

	resp, err := tools.DoHTTPPost(b.c, urlQueryTransferResult, nil, header, []byte(form.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("goQueryResultPage DoHttpPost 出现错误 err=%+v", err)
		return ""
	}

	logger.Info("goQueryResultPage >>>>>>>> " + string(resp))

	return string(resp)
}

func (b *Bank) doQuery() *transferResp {
	respObj := &transferResp{}

	form := &url.Values{}
	form.Set("ClientNo", b.dTransferClientNO)
	form.Set("Command", "CMD_QUERYRESULTAJAX")

	resp := b.ajax(urlQueryTransferResult, fmt.Sprintf("$RequestMode$=1&%s", form.Encode()), urlQueryTransferResult)
	logger.InfoJSON("doQuery >>>>>>> ", resp)

	err := json.Unmarshal([]byte(resp), respObj)
	if err != nil {
		logger.Errorf("doQuery json.Unmarshal 出现错误 err=%+v resp=%+v", err, hex.Dump([]byte(resp)))
	}

	return respObj
}

func (b *Bank) doQueryFailResult() string {
	query := &url.Values{}
	query.Set("DeviceType", "D")
	query.Set("ClientNo", b.dTransferClientNO)
	query.Set("version", cfBundleVersion)

	header := b.addBaseHeaders()
	header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

	v := &url.Values{}
	v.Set("Command", "CMD_QUERYRESULT")
	v.Set("_urlrefer", urlQueryTransferResult)

	resp, err := tools.DoHTTPPostForm(b.c, urlQueryTransferResult, query, header, []byte(v.Encode()))
	if err != nil || resp == nil {
		logger.Errorf("doQueryFailResult DoHttpPostForm 出现错误 err=%+v", err)
		return ""
	}
	logger.Info("doQueryFailResult >>>>>>>> " + string(resp))
	return string(resp)
}
