package cmb

import (
	"awesome/tools"
	"awesome/tools/base"
	"bufio"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// Bank 招商银行
type Bank struct {
	c                      *http.Client
	Account                string `json:"account"`  // 账号，手机号
	LoginPwd               string `json:"loginPwd"` // 登陆密码
	PayPwd                 string `json:"payPwd"`   // 支付密码
	IDFV                   string `json:"IDFV"`
	IDFVFP                 string `json:"IDFV_FP"`
	IDFA                   string `json:"IDFA"`
	AppID                  string `json:"appId"`
	InnerID                string `json:"innerId"`
	PushID                 string `json:"pushId"`
	MenuHash               string `json:"menuHash"` // 第一次安装后返回的
	FuncListHash           string `json:"funcListHash"`
	AlgID                  string `json:"algID"`
	DeviceFPCode           string `json:"deviceFPCode"` // 这个是服务返回的
	DeviceFPCodeExpireTime int64  `json:"deviceFPCodeExpireTime"`
	AudioFP                string `json:"audioFP"`
	CookieCode             string `json:"cookieCode"`
	QRMenuHash             string `json:"qrMenuHash"`
	QRFuncListHash         string `json:"qrFuncListHash"`
	NetPayMenuHash         string `json:"netPayMenuHash"`
	NetPayFuncListHash     string `json:"netPayFuncListHash"`
	HomePageMenuHash       string `json:"homePageMenuHash"`
	AllPageMenuHash        string `json:"allPageMenuHash"`
	FinancialPageMenuHash  string `json:"financialPageMenuHash"`
	RAMVolume              string `json:"RAMVolume"` // 内存容量
	ROMVolume              string `json:"ROMVolume"`
	DiskSpace              int64  `json:"diskSpace"`
	PhysicalMemory         int64  `json:"physicalMemory"`
	LocalIP                string `json:"localIP"`
	StartupTime            uint32 `json:"startupTime"`
	UID                    string `json:"UID"`
	UIDSM                  string `json:"UID_SM"`
	DataHash               string `json:"dataHash"`
	CustomerID             string `json:"customerId"`
	CustomerIDSM           string `json:"customerId_SM"`
	aid                    string
	sid                    string
	clientNo               string
	serverTime             string
	dTransactionClientNO   string
	dTransferClientNO      string
	qrCodeClientNo         string
	qrCodeSerialNo         string
	loginAesKey            string
	transCacheID           string
	transIDNew             string
	msgFlag                string
	msgTips                string
	transferCardUID        string
	isSameBank             bool // 是否是同行转账
	isSmallBank            bool // 收否是小银行转账
	categoryBankName       string
	categoryBankNameCode   string
	province               string
	city                   string
	cityValue              string
	branchBankName         string
	branchBankNo           string

	cipherToken     string
	serverAuthToken *authToken
	HardwareInfo    HardwareInfo `json:"hardwareInfo"`
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion string `json:"systemVersion"` // 系统版本
	Model         string `json:"model"`         // 设备类型
	ScreenSize    string `json:"screenSize"`    // 分辨率
	Scale         string `json:"scale"`
	Carrier       string `json:"carrier"` // 运营商
	CarrierCode   string `json:"carrierCode"`
	DeviceName    string `json:"deviceName"` // 设备名称  iPhone7
	OwnerName     string `json:"ownerName"`  // 设备用户名 jj的 iPhone
}

// New 创建一个新的账号
func New(account, loginPwd, payPwd string) *Bank {
	b := &Bank{
		Account:      account,
		LoginPwd:     loginPwd,
		PayPwd:       payPwd,
		HardwareInfo: HardwareInfo{},
	}
	b.IDFV = tools.NewUUIDUpper()
	b.IDFVFP = tools.NewUUIDUpper()
	b.IDFA = tools.NewUUIDUpper()

	b.AudioFP = fmt.Sprintf("%.14f", 35.00893253237009+float64(tools.RandFloat(0.2)))

	b.HardwareInfo.SystemVersion = tools.NewSysVersion()
	b.HardwareInfo.Model = tools.NewModel()
	b.HardwareInfo.DeviceName = tools.PhoneName(b.HardwareInfo.Model)
	b.HardwareInfo.ScreenSize = tools.ScreenPx(b.HardwareInfo.Model)
	b.HardwareInfo.Scale = tools.Scale(b.HardwareInfo.Model)
	b.HardwareInfo.Carrier = tools.CarrierByPhoneNum(b.Account)
	b.HardwareInfo.CarrierCode = tools.CarrierCode(b.HardwareInfo.Carrier)
	b.HardwareInfo.OwnerName = tools.NewOwnerName()
	//b.HardwareInfo.CarrierCode = "460" + tools.CarrierCode(b.HardwareInfo.Carrier)

	// 内存大小 单位是GB
	b.PhysicalMemory = tools.PhysicalMemory(b.HardwareInfo.Model) - (tools.RandInt63()%250*1024*1024 + 50*1024*1024)
	physicalMemory := float32(b.PhysicalMemory) / (1024 * 1024 * 1024)
	b.RAMVolume = fmt.Sprintf("%.2f", physicalMemory-(tools.RandFloat(0.06)+0.02))
	// 磁盘大小 单位是GB
	b.DiskSpace = tools.NewDiskSpace(b.HardwareInfo.Model) - (tools.RandInt63()%1*1024*1024*1024 + 200*1024*1024)
	diskSpace := float32(b.DiskSpace) / (1024 * 1024 * 1024)
	b.ROMVolume = fmt.Sprintf("%.2f", diskSpace-(float32(tools.RandIntn(10))+rand.Float32()+1.8))
	b.LocalIP = tools.NewIPV4()
	// 开始初始化app生成的全局唯一数据
	b.MenuHash = "N"
	b.FuncListHash = "N"
	b.QRMenuHash = "N"
	b.QRFuncListHash = "N"
	b.NetPayMenuHash = "N"
	b.NetPayFuncListHash = "N"
	b.HomePageMenuHash = "N"
	b.AllPageMenuHash = "N"
	b.FinancialPageMenuHash = "N"
	b.AppID = b.genAppID()
	b.InnerID = b.genInnerID()
	b.PushID = b.genPushID()

	b.Save()
	return b
}

// Save 保存账号信息
func (b *Bank) Save() {
	path := "./cmb/bin/" + b.Account + ".json"
	tools.SaveJSON2File(path, b)
}

// NewHTTPClient 需要服务端来实现，用来创建新的client
func (b *Bank) NewHTTPClient() *http.Client {
	j, _ := cookiejar.New(nil)

	// u, _ := url.Parse("http://127.0.0.1:9090")
	u, _ := url.Parse("http://127.0.0.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
		},
		Timeout: time.Second * 10,
		Jar:     j,
	}
}

// Login 登陆
// 没有做刷脸验证
// 登陆->安全设置->常用设备管理->关闭登陆保护 就不会出现刷脸
func (b *Bank) Login() base.LoginResultCode {
	// 创建一个新的
	b.c = b.NewHTTPClient()
	// log
	logger.Prefix = fmt.Sprintf("[CMB][%s]", b.Account)
	// 重置一些数据
	b.aid = ""
	b.sid = ""
	if b.StartupTime == 0 || tools.RandIntn(10) == 0 {
		b.StartupTime = tools.Timestamp()
	}

	clientCfgResp := b.getClientCfg()
	if clientCfgResp.FuncListHash != "" && clientCfgResp.MenuHash != "" {
		logger.Info("getClientCfg 更新 FuncListHash和MenuHash")
		b.MenuHash = clientCfgResp.MenuHash
		b.FuncListHash = clientCfgResp.FuncListHash
	}

	time.Sleep(time.Duration(rand.Int31n(6000)+3000) * time.Millisecond)

	// 进入登陆界面
	preResp := b.preLogin()
	time.Sleep(time.Duration(rand.Int31n(4000)+3000) * time.Millisecond)
	if preResp.ServerTime == "" || preResp.Root.ClientNo == "" {
		logger.Error("没有获取到ServerTime和ClientNo")
		return base.LoginResultFail
	}
	b.serverTime = preResp.ServerTime
	b.clientNo = preResp.Root.ClientNo
	//b.AlgID = "H7rkKbu8TK"
	if b.AlgID == "" {
		// 需要去下载frms-fingerprint.js
		jsText := b.deviceFPCodeDownload()
		// 获取到algID
		b.AlgID = getHtmlText(jsText, `key:"algID",value:"`)
		if b.AlgID == "" {
			logger.Error("未获取到AlgID无法继续")
			return base.LoginResultFail
		}
		b.Save()
	}

	curTime := tools.TimestampEx()
	if b.DeviceFPCodeExpireTime <= curTime {
		// 更新DeviceFPCode
		fpRes := b.deviceFPCodePost()
		if fpRes.CookieCode != "" {
			b.CookieCode = fpRes.CookieCode
		}
		if fpRes.Dfp != "" {
			b.DeviceFPCode = fpRes.Dfp
		}
		if fpRes.Exp != "" {
			b.DeviceFPCodeExpireTime, _ = strconv.ParseInt(fpRes.Exp, 10, 64)
		}
		b.Save()
	}

	if b.UID == "" {
		// 第一次登陆
		// 输入账号点击注册/登陆
		time.Sleep(time.Duration(rand.Int31n(4000)+2000) * time.Millisecond)
		preResp = b.preLogin()
		if preResp.ServerTime == "" || preResp.Root.ClientNo == "" {
			logger.Error("没有获取到ServerTime和ClientNo")
			return base.LoginResultFail
		}

		route := b.firstLoginRoute()
		if route.Code != "0000" {
			logger.Error("首次登陆Route返回了错误")
			return base.LoginResultFail
		}
	}

	login := &loginResp{}
	baseLogin, origKey := b.accountLogin()
	logger.Infof("loginSM4Key ---> %s", origKey)
	if baseLogin.Code == "0000" {
		login = b.parseLoginResp([]byte(baseLogin.Data.(string)), origKey)
	} else if baseLogin.Code == "0010" {
		// {
		//		"Code": "0010",
		//		"Data": {
		//			"ActionType": "JumpUrl",
		//			"Url": "https://mobile.cmbchina.com/GLogin/Login/VtmVerifyKit.aspx?LoginRedirect=RTDRedirect&VtmType=avtm" -> 人脸验证
		//		}
		//  }
		// {
		//		"Code": "0010",
		//		"Data": {
		//			"ActionType": "JumpUrl",
		//			"Url": "https://mobile.cmbchina.com/GLogin/Login/SelectVerify.aspx?LoginRedirect=RTDRedirect" -> 选择认证方式
		//		}
		// 	}
		// {
		//		"Code": "0010",
		//		"Data": {
		//			"ActionType": "JumpUrl",
		//			"Url": "https://mobile.cmbchina.com/GLogin/Login/VerifyTrustyDevice.aspx?LoginRedirect=RTDRedirect" -> 短信认证
		//		}
		//	}
		// 判断是何种方式
		jumpUrl := baseLogin.Data.(map[string]interface{})["Url"]
		strJumpUrl := jumpUrl.(string)
		if strings.Contains(strJumpUrl, "SelectVerify.aspx") {
			// 选择登陆方式
			b.verifyTrustyDevicePage(fmt.Sprintf(urlSelectVerify, b.clientNo, cfBundleVersion, b.clientNo))
			page := b.qrCodeVerifyPage()
			// 解析出uid
			uid := getHtmlText(page, `varUID="`)
			qrcode := extractQRCode(page)
			if uid == "" || qrcode == "" {
				logger.Errorf("登陆设备认证未获取全uid=%s, qrcode=%s,无法继续登陆", uid, qrcode)
				return base.LoginResultFail
			}
			logger.Infof("id=%s, qrcode=%s", uid, qrcode)

			// 下发qrcode去让小白扫码登陆，小白扫码不能从相册扫码需要用另外的手机，这里是轮训, 时间限制在5分钟
			for i := 0; i < 5*20; i++ {
				time.Sleep(3 * time.Second)
				result := b.pollingQueryResult(uid)
				if result.Head.Code != "00" {
					logger.Errorf("登陆设备认证轮训是否扫码出现错误 msg=%s", result.Head.ErrMsg)
					return base.LoginResultFail
				}
				switch result.Body.Value {
				case "02":
					logger.Info("登陆设备认证轮训扫码 已扫")
				case "05":
					logger.Info("登陆设备认证轮训扫码 点击了确认授权")
					// 提交登陆
					qrcodeLoginRes := b.qrcodeVerifyLogin(uid)
					if qrcodeLoginRes.SysResult.Content.ErrCode == "0" {
						if qrcodeLoginRes.SysResult.Content.VerifyResult == "true" {
							msg, _ := url.QueryUnescape(qrcodeLoginRes.SysResult.Content.DispMsg)
							msgBytes, _ := base64.StdEncoding.DecodeString(msg)
							login = b.parseLoginResp(msgBytes, origKey)
							return b.loginComplete(login)
						} else {
							logger.Error("登陆设备认证扫码成功提交信息成功，但是认证结果失败了")
							return base.LoginResultFail
						}
					} else if qrcodeLoginRes.SysResult.Content.ErrCode == "1000" {
						logger.Errorf("登陆设备认证扫码成功提交信息出错 errMsg=%s", qrcodeLoginRes.SysResult.Content.DispMsg)
						return base.LoginResultFail
					} else if qrcodeLoginRes.SysResult.Content.ErrCode == "2000" {
						logger.Error("登陆设备认证扫码成功提交信息出错 errMsg=当前网络不稳定或采用了动态IP")
						return base.LoginResultFail
					} else if qrcodeLoginRes.SysResult.Content.ErrCode == "3000" {
						logger.Errorf("登陆设备认证扫码成功提交信息出错 errMsg=需要继续认证 url=%s", qrcodeLoginRes.SysResult.Content.DispMsg)
						return base.LoginResultFail
					} else {
						logger.Error("登陆设备认证扫码成功提交信息出错")
						return base.LoginResultFail
					}
				case "04":
					logger.Info("登陆设备认证轮训扫码 出现其他异常")
					return base.LoginResultFail
				case "07":
					logger.Info("登陆设备认证轮训扫码 未获得授权")
					return base.LoginResultFail
				}
			}
		} else { // 这里包括刷脸和短信登陆 就直接走短信登陆
			// 需要进行短信验证
			b.verifyTrustyDevicePage(fmt.Sprintf(urlVerifyTrustyDevice, b.clientNo, cfBundleVersion))
			// 需要记录一下登陆包加密key，在验证短信后需要使用
			b.loginAesKey = origKey
			return base.LoginResultFailNeedSms
		}
	} else {
		logger.Error("登陆未知错误，需要检查")
		return base.LoginResultFail
	}

	return b.loginComplete(login)
}

// LoginVerifySMS 登陆短信验证码校验
func (b *Bank) LoginVerifySMS(code string) base.LoginResultCode {
	logger.Info("获取到短信 -> " + code)

	resp := b.verifyTrustyDevice(code, fmt.Sprintf(urlVerifyTrustyDevice, b.clientNo, cfBundleVersion))
	if resp == "" {
		return base.LoginResultFailWrongSms
	}

	login := b.parseLoginResp([]byte(resp), b.loginAesKey)

	return b.loginComplete(login)
}

func (b *Bank) loginComplete(resp *loginResp) base.LoginResultCode {
	if resp.UID == "" {
		logger.Error("登陆步骤走完了，没有返回UID，无法继续")
		return base.LoginResultFail
	}
	b.UID = resp.UID
	b.UIDSM = resp.UIDSM

	// 其他的登陆
	pAccountNoticeLogin := b.otherLogin(urlPAccountNoticeLogin, resp.InnerToken.AuthResponse.AuthResponseBody.CipherToken)
	if pAccountNoticeLogin.InfBdy.ClientNo == "" {
		logger.Error("PAccountNoticeLogin没有获取到ClientNo")
		return base.LoginResultFail
	}

	dAccountViewLogin := b.otherLogin(urlDAccountViewLogin, resp.InnerToken.AuthResponse.AuthResponseBody.CipherToken)
	if dAccountViewLogin.InfBdy.ClientNo == "" {
		logger.Error("DAccountViewLogin没有获取到ClientNo")
		return base.LoginResultFail
	}

	gExternalLogin := b.otherLogin(urlGExternalLogin, resp.InnerToken.AuthResponse.AuthResponseBody.CipherToken)
	if gExternalLogin.InfBdy.ClientNo == "" {
		logger.Error("GExternalLogin没有获取到ClientNo")
		return base.LoginResultFail
	}

	//b.pushIDQuery(pAccountNoticeLogin.ClientNo)

	//clientCfgResp := b.getClientCfg()
	//if clientCfgResp.FuncListHash != "" && clientCfgResp.MenuHash != "" {
	//	logger.Info("getClientCfg 更新 FuncListHash和MenuHash")
	//	b.MenuHash = clientCfgResp.MenuHash
	//	b.FuncListHash = clientCfgResp.FuncListHash
	//}
	//
	//otherCfgResp := b.otherAppConfig(urlQRCfg, b.QRMenuHash, b.QRFuncListHash)
	//if otherCfgResp.FuncListHash != "" && otherCfgResp.MenuHash != "" {
	//	logger.Info("otherAppConfig QR 更新 FuncListHash和MenuHash")
	//	b.QRMenuHash = otherCfgResp.MenuHash
	//	b.QRFuncListHash = otherCfgResp.FuncListHash
	//}
	//
	//otherCfgResp = b.otherAppConfig(urlNetPayCfg, b.NetPayMenuHash, b.NetPayFuncListHash)
	//if otherCfgResp.FuncListHash != "" && otherCfgResp.MenuHash != "" {
	//	logger.Info("otherAppConfig NetPay 更新 FuncListHash和MenuHash")
	//	b.NetPayMenuHash = otherCfgResp.MenuHash
	//	b.NetPayFuncListHash = otherCfgResp.FuncListHash
	//}

	//	b.myMenuQuery(gExternalLogin.ClientNo, `{
	// "ScoreNum" : "N",
	// "TicketNum" : "N",
	// "UserName" : "Y",
	// "LastLoginTime" : "Y",
	// "BankCardNum" : "N",
	// "RemindNum" : "N"
	//}`)
	//
	//	u, _ := url.Parse(urlAVMyChannel)
	//	query := &url.Values{}
	//	query.Set("behavior_entryid", "LGD001003")
	//	query.Set("DeviceType", "D")
	//	query.Set("ClientNo", dAccountViewLogin.ClientNo)
	//	u.RawQuery = query.Encode()
	//	us := u.String()
	//	b.getPage(us)
	//
	//	b.myMenuQuery(gExternalLogin.ClientNo, `{
	// "CMBCard" : "Y",
	// "ScoreNum" : "Y",
	// "TicketNum" : "Y",
	// "BankCardNum" : "Y",
	// "RemindNum" : "Y",
	// "RemindInfo" : "Y"
	//}`)
	//
	//	b.myMenuQuery(gExternalLogin.ClientNo, `{
	//  "UserIdLevel" : "Y",
	//  "CallLoginFunc" : "",
	//  "AsynchronousOpen" : "Y",
	//  "ABTestInfo" : "N",
	//  "CounterData" : "",
	//  "CustomerID" : "Y",
	//  "Tips" : "N",
	//  "AvatarHeadImage" : "",
	//  "CUSTOM_INFO" : ""
	//}`)
	//
	//	b.queryExpectLoanAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.queryMyRecommendAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.incomeExpenseAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.myChannelRecommendAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.as01Ajax(dAccountViewLogin.ClientNo, us)
	//
	//	b.myLoanAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.creditStateAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.onlineStoreAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.yestDayIncomeAjax(dAccountViewLogin.ClientNo, us)
	//
	//	b.as03Ajax(dAccountViewLogin.ClientNo, us)

	// 登陆账单查询相关的服务
	time.Sleep(time.Duration(rand.Int31n(4000)+2000) * time.Millisecond)
	dTransactionLogin := b.otherLogin(urlDTransactionLogin, resp.InnerToken.AuthResponse.AuthResponseBody.CipherToken)
	if dTransactionLogin.InfBdy.ClientNo == "" {
		logger.Error("dTransactionLogin没有获取到ClientNo")
		return base.LoginResultFail
	}
	// 保存一下
	b.cipherToken = resp.InnerToken.AuthResponse.AuthResponseBody.CipherToken
	b.dTransactionClientNO = dTransactionLogin.InfBdy.ClientNo
	b.serverAuthToken = &resp.OuterToken.AuthToken
	return base.LoginResultSuccess
}

// CardList 查询卡列表，获取到卡的UID
func (b *Bank) CardList() *cardListResp {
	u, _ := url.Parse(urlGeneralBill)
	query := &url.Values{}
	query.Set("DeviceType", "D")
	query.Set("ClientNo", b.dTransactionClientNO)
	query.Set("msid", b.dTransactionClientNO)
	query.Set("version", cfBundleVersion)
	query.Set("behavior_entryid", "stp004002")
	u.RawQuery = query.Encode()
	us := u.String()
	//b.getPage(us)

	return b.cardList(us)
}

// BillList 给定月份返回当前月份以及之前月份的账单 翻页就指定last参数，是上次拉单返回的
func (b *Bank) BillList(month, cardUID string, last *billListResp) *billListResp {
	u, _ := url.Parse(urlGeneralBill)
	query := &url.Values{}
	query.Set("DeviceType", "D")
	query.Set("ClientNo", b.dTransactionClientNO)
	query.Set("msid", b.dTransactionClientNO)
	query.Set("version", cfBundleVersion)
	query.Set("behavior_entryid", "stp004002")
	u.RawQuery = query.Encode()
	us := u.String()

	//if last == nil {
	//	b.getPage(us)
	// 这里返回的页面超过5分钟就会要求你进行重登陆了
	// <div class="hmp_half_page_title">登录超时，请重新登录</div>
	//}

	//if needReLogin {
	//	// 登陆账单查询相关的服务
	//	// <LoginResponse><LoginFlag>1</LoginFlag><LoginMessage>登录超时#L6</LoginMessage><LoadFlag>0</LoadFlag><ServerURL></ServerURL><ClientNo></ClientNo><ErrPage>https://mobile.cmbchina.com/DTransaction/monitor.aspx?View=TokenLoginFail&ErrMsg=%e7%99%bb%e5%bd%95%e8%b6%85%e6%97%b6%23L6</ErrPage></LoginResponse>
	//
	//	dTransactionLogin := b.otherLogin(urlDTransactionLogin, b.cipherToken)
	//	if dTransactionLogin.ClientNo == "" || dTransactionLogin.ErrPage != "" || dTransactionLogin.LoadFlag != "0" {
	//		// 这里就代表超时了，需要重新登陆
	//		logger.Error("查询账单 需要重新登陆")
	//		return nil
	//	}
	//	b.dTransactionClientNO = dTransactionLogin.ClientNo
	//}

	// 增加一个包 没这个包 拉不到单
	baseCode := b.queryBaseCode(us)
	if baseCode.SysResult.Content.ErrCode != "Success" {
		logger.Errorf("查询账单 queryBaseCode 出现错误 err=%s, code=%s", baseCode.SysResult.Content.ErrCode, baseCode.SysResult.Content.DispMsg)
	}

	return b.billList(month, cardUID, us, last)
}

// Transfer 转账
// amount 字符串必须是%.2f
// categoryBankName 村镇银行
// categoryBankNameCode 320
// province 福建
// city     福州 cityValue     3501
// branchBankName 福建连江恒欣村镇银行股份有限公司
// branchBankNo   320391000019
func (b *Bank) Transfer(srcCardUID, destCardNo, destName, amount, remark string,
	categoryBankName, categoryBankNameCode, province, city, cityValue, branchBankName, branchBankNo string) base.TransferResultCode {
	b.isSameBank = false
	b.isSmallBank = false

	b.categoryBankName = categoryBankName
	b.categoryBankNameCode = categoryBankNameCode
	b.province = province
	b.city = city
	b.cityValue = cityValue
	b.branchBankName = branchBankName
	b.branchBankNo = branchBankNo
	if b.branchBankNo != "" {
		b.isSmallBank = true
	}

	// 保存一下当前转账的卡
	b.transferCardUID = srcCardUID

	// 登陆转账服务
	dTransferLogin := b.otherLogin(urlDTransferLogin, b.cipherToken)
	if dTransferLogin.InfBdy.ClientNo == "" || dTransferLogin.InfBdy.ErrPage != "" || dTransferLogin.InfBdy.LoadFlag != "0" {
		// 这里就代表超时了，需要重新登陆
		logger.Error("dTransferLogin没有获取到ClientNo")
		return base.TransferResultFail
	}
	b.dTransferClientNO = dTransferLogin.InfBdy.ClientNo

	u := fmt.Sprintf(urlTransferHome+"?DeviceType=D&ClientNo=%s&msid=%s&version=%s&behavior_entryid=stp004003",
		b.dTransferClientNO, b.dTransferClientNO, cfBundleVersion)
	b.getPage(u)
	//req := fmt.Sprintf("$RequestMode$=1&AccountUID=%s&ClientNo=%s&Command=CMD_QUERYREMINDERTRANS", srcCardUID, b.dTransferClientNO)
	//logger.Info("CMD_QUERYREMINDERTRANS >>>>>>>>>> " + b.ajax(urlTransferQueryAjax, req, u))
	//req = fmt.Sprintf("$RequestMode$=1&AccountUID=%s&ClientNo=%s&Command=CMD_QUERYHOMENOTICE", srcCardUID, b.dTransferClientNO)
	//logger.Info("CMD_QUERYHOMENOTICE >>>>>>>>>> " + b.ajax(urlTransferQueryAjax, req, u))
	//req = fmt.Sprintf("$RequestMode$=1&AccountUID=%s&ClientNo=%s&Command=CMD_QUERYRELATION", srcCardUID, b.dTransferClientNO)
	//logger.Info("CMD_QUERYRELATION >>>>>>>>>> " + b.ajax(urlTransferQueryAjax, req, u))

	time.Sleep(time.Duration(rand.Int31n(2000)+2000) * time.Millisecond)
	uTranInfo := fmt.Sprintf(urlTranInfo+"?DeviceType=D&ClientNo=%s&msid=%s&version=%s",
		b.dTransferClientNO, b.dTransferClientNO, cfBundleVersion)
	tranInfo := b.goTranInfo(uTranInfo, srcCardUID, u)
	// 获取transCacheID
	b.transCacheID = extractTransCacheID(tranInfo)
	b.transIDNew = extractTransIDNew(tranInfo)
	queryData := extractQueryData(tranInfo)
	if b.transCacheID == "" || b.transIDNew == "" || queryData == "" {
		logger.Errorf("没有获取transCacheID||transIDNew||queryData transCacheID=%+v, transIDNew=%+v, queryData=%+v，无法继续",
			b.transCacheID, b.transIDNew, queryData)
		return base.TransferResultFail
	}

	// 查询银行名称
	bank := b.queryBankInfo(srcCardUID, destCardNo, destName, uTranInfo)
	if bank.SysResult.Content.ImdBkn == "" && !b.isSmallBank {
		logger.Error("没有获取到银行code，无法继续")
		return base.TransferResultFail
	}
	if strings.Contains(bank.SysResult.Content.BnkName, "招商银行") {
		b.isSameBank = true
	}
	// 查询下一步验证方式
	verify, key, postStr, deviceFPCode := b.queryVerify(srcCardUID, bank.SysResult.Content.InnBkn, bank.SysResult.Content.ImdBkn,
		destCardNo, destName, amount, remark, queryData, uTranInfo)

	if verify.SysResult.Content.Sucess != "Y" {
		logger.Errorf("查询验证出现错误=%s", verify.SysResult.Content.Error)
		return base.TransferResultFail
	}

	if verify.SysResult.Content.NextStep == "smsandotp" {
		logger.Info("转账需要短信和密码")
		smsPage := b.goVerifySmsPage(srcCardUID, bank.SysResult.Content.InnBkn, bank.SysResult.Content.ImdBkn, destCardNo,
			destName, amount, remark, uTranInfo, key, postStr, deviceFPCode, b.transIDNew)
		b.transIDNew = extractTransIDNew(smsPage)
		if b.transIDNew == "" {
			logger.Error("第二次获取transIDNew为空，无法继续")
			return base.TransferResultFail
		}
		b.msgFlag = extractMsgFlag(smsPage)
		b.msgTips = extractMsgTips(smsPage)
		if b.msgFlag == "" || b.msgTips == "" {
			b.msgFlag = "110000"
			b.msgTips = fmt.Sprintf("短信验证码已发送至%s*****%s。如您长时间未收到，请点击按钮重新获取。", b.Account[:3], b.Account[len(b.Account)-3:])
		}

		logger.Info("转账请输入短信:")
		br := bufio.NewReader(os.Stdin)
		code, _, _ := br.ReadLine()
		resCode := b.TransferVerifySMS(string(code))
		if resCode == base.TransferResultSuccess {
			resCode = b.transferVerifyPWD()
		}
		return resCode
	} else if verify.SysResult.Content.NextStep == "confirm_sms" {
		logger.Info("转账需要 风险确认 -> 短信和密码")
		smsPage := b.goVerifySmsPage(srcCardUID, bank.SysResult.Content.InnBkn, bank.SysResult.Content.ImdBkn, destCardNo,
			destName, amount, remark, uTranInfo, key, postStr, deviceFPCode, b.transIDNew)
		b.transIDNew = extractTransIDNew(smsPage)
		if b.transIDNew == "" {
			logger.Error("第二次获取transIDNew为空，无法继续")
			return base.TransferResultFail
		}
		b.msgFlag = extractMsgFlag(smsPage)
		b.msgTips = extractMsgTips(smsPage)
		if b.msgFlag == "" || b.msgTips == "" {
			b.msgFlag = "110000"
			b.msgTips = fmt.Sprintf("短信验证码已发送至%s*****%s。如您长时间未收到，请点击按钮重新获取。", b.Account[:3], b.Account[len(b.Account)-3:])
		}

		logger.Info("转账请输入短信:")
		br := bufio.NewReader(os.Stdin)
		code, _, _ := br.ReadLine()
		resCode := b.TransferVerifySMS(string(code))
		if resCode == base.TransferResultSuccess {
			resCode = b.transferVerifyPWD()
		}
		return resCode
	} else if verify.SysResult.Content.NextStep == "pwd" {
		logger.Info("转账只需要密码")
		return b.transferVerifyPWD()
	} else if verify.SysResult.Content.NextStep == "confirm" {
		logger.Info("转账需要 风险确认 -> 密码")
		return b.transferVerifyPWD()
	} else if verify.SysResult.Content.NextStep == "open" {
		logger.Error("尚未开通电子银行转账功能")
		return base.TransferResultFail
	} else if verify.SysResult.Content.NextStep == "modify" {
		logger.Error("转账超限")
		return base.TransferResultFail
	} else if verify.SysResult.Content.NextStep == "bigvtm" {
		logger.Error("本次转账的金额超过限额")
		return base.TransferResultFail
	} else if verify.SysResult.Content.NextStep == "confirm_avtm_sms" {
		// 人脸识别
		logger.Error("转账需要 风险确认 -> 人脸识别 -> 短信")
		return base.TransferResultFail
	} else if verify.SysResult.Content.NextStep == "confirm_avtm" {
		// 人脸识别
		logger.Error("转账需要 风险确认 -> 人脸识别")
		return base.TransferResultFail
	} else if verify.SysResult.Content.NextStep == "avtm" || verify.SysResult.Content.NextStep == "vtm" {
		// 人脸识别
		logger.Error("转账需要人脸识别")
		return base.TransferResultFailNeedImage
	}

	logger.Errorf("未知的验证方式组合,需要优化 NextStep=%s", verify.SysResult.Content.NextStep)
	return base.TransferResultFail
}

// TransferVerifySMS 转账验证短信
func (b *Bank) TransferVerifySMS(code string) base.TransferResultCode {
	logger.Info("收到短信 >>>>> " + code)
	if len(code) != 6 {
		logger.Errorf("短信验证码长度不对 code=%s", code)
		return base.TransferResultFail
	}
	// 验证短信
	verify := b.doMsgVerify(code)
	if verify.SysResult.Content.Sucess != "Y" {
		logger.Errorf("短信验证出现错误 err=%s", verify.SysResult.Content.Error)
		if strings.Contains(verify.SysResult.Content.Error, "ErrCode:02") {
			return base.TransferResultFailWrongSms
		}
		return base.TransferResultFail
	}

	if verify.SysResult.Content.NextStep != "pwd" {
		logger.Errorf("短信验证完成，下一步居然不是pwd nextStep=%s", verify.SysResult.Content.NextStep)
		return base.TransferResultFail
	}

	return base.TransferResultSuccess
}

func (b *Bank) transferVerifyPWD() base.TransferResultCode {
	// 验证密码
	submit := b.doSubmit()
	if submit.SysResult.Content.Sucess != "Y" {
		logger.Errorf("密码验证出现错误 err=%s", submit.SysResult.Content.Error)
		if strings.Contains(submit.SysResult.Content.Error, "密码有误") {
			return base.TransferResultFailWrongPwd
		}
		return base.TransferResultFail
	}

	time.Sleep(time.Duration(rand.Int31n(1000)+1000) * time.Millisecond)
	// 转账完成，开始查询结果
	result := b.goQueryResultPage(submit.SysResult.Content.TranID)
	if b.isSameBank {
		// 如果是同行，上面就已经给出结果了
		// todo...没有测试到失败的卡，需要去测试
		if strings.Contains(result, "转账成功") {
			return base.TransferResultSuccess
		}
		return base.TransferResultUnknown
	}
	for i := 0; i < 5; i++ {
		time.Sleep(6 * time.Second)
		resp := b.doQuery()
		if resp.SysResult.Content.ErrCode == "400" {
			// 已有转账结果
			if resp.SysResult.Content.BusPrcRst == "S" {
				// 成功
				return base.TransferResultSuccess
			}

			// 失败,会返回一个带有错误信息的html
			b.doQueryFailResult()
			return base.TransferResultFail
		} else if resp.SysResult.Content.ErrCode == "600" {
			continue
		} else {
			logger.Errorf("查询结果出现错误，需要重新登陆查询账单确认是否转账成功 ErrCode=%s", resp.SysResult.Content.ErrCode)
			return base.TransferResultUnknown
		}
	}

	logger.Error("查询转账结果超时")
	return base.TransferResultUnknown
}

// CreateQRCode 生成并返回encode过的二维码，使用时需要进行decode
func (b *Bank) CreateQRCode(amount string) string {
	u := fmt.Sprintf(urlMobileQR, cfBundleVersion)
	qrPage := b.getPage(u)
	// 解析出ClientNo和SerialNo
	b.qrCodeClientNo = extractClientNo(qrPage)
	b.qrCodeSerialNo = extractSerialNo(qrPage)
	if b.qrCodeClientNo == "" || b.qrCodeSerialNo == "" {
		logger.Error("二维码界面未获取到ClientNo或SerialNo")
		return ""
	}

	b.netPayPreLogin(b.qrCodeClientNo, b.qrCodeSerialNo, u)
	b.netPayGetQR(b.qrCodeClientNo, b.qrCodeSerialNo, u)
	b.netPayGetDefaultCard(b.qrCodeClientNo, b.qrCodeSerialNo, urlMobileQRGetQR)
	if amount == "" {
		amount = "0.00"
	}
	qr := b.netPayGetQRUrl(amount, b.qrCodeClientNo, b.qrCodeSerialNo, urlMobileQRGetQR)

	return qr.Body.QRNo
}

// QueryResult 轮训二维码扫码结果，1秒一次 qrCode必须是CreateQRCode返回的原始数据
func (b *Bank) QueryResult(qrCode string) string {
	return b.netPayQueryResult(qrCode, b.qrCodeClientNo, b.qrCodeSerialNo, urlMobileQRGetQR)
}

func extractTransCacheID(html string) string {
	prefix := "TransCacheID: \""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\",")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractTransIDNew(html string) string {
	prefix := "id=\"TransID_New\" value=\""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\"")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractQueryData(html string) string {
	fetchDataRegexp := regexp.MustCompile(`id: "querystatus",[\s]*?action: "query",[\s]*?data:\s*?"(.+?)"`)

	resultArray := fetchDataRegexp.FindStringSubmatch(html)
	if len(resultArray) == 2 {
		return strings.TrimSpace(resultArray[1])
	}
	return ""
}

func extractMsgFlag(html string) string {
	prefix := "_MsgFlag_\" value=\""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\"")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractMsgTips(html string) string {
	prefix := "_MsgTips_\" value=\""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\"")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractClientNo(html string) string {
	prefix := "id=\"ClientNo\" value=\""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\"")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractSerialNo(html string) string {
	prefix := "id=\"SerialNo\" value=\""
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start+len(prefix):]
	end := strings.Index(html, "\"")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func extractQRCode(html string) string {
	prefix := "https://t.cmbchina.com"
	start := strings.Index(html, prefix)
	if start == -1 {
		return ""
	}
	html = html[start:]
	end := strings.Index(html, "'")
	if end != -1 {
		return html[:end]
	}
	return ""
}

func getHtmlText(html, prefix string) string {
	html = strings.ReplaceAll(html, " ", "")
	ss := strings.Split(html, prefix)
	if len(ss) >= 2 {
		ss = strings.Split(ss[1], "\"")
		if len(ss) >= 2 {
			return ss[0]
		}
	}

	return ""
}
