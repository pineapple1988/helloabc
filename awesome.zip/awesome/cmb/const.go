package cmb

import (
	"awesome/tools/log2"
	"crypto/rsa"
	"math/big"
)

const (
	urlGetClientCfg           = "https://mobile.cmbchina.com/GExternal/ClientConfigLoad/GetClientCfg.aspx"
	urlDeviceDFCode           = "https://dfpgw.paas.cmbchina.com/public/generate/post"
	urlDeviceDFCodeDownloadJs = "https://dfpgw.paas.cmbchina.com/public/downloads/frms-fingerprint.js"
	urlQRCfg                  = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?GetAppConfig"
	urlNetPayCfg              = "https://netpay.cmbchina.com/netpayment/BaseHttp.dll?GetAppConfig"
	urlFirstLoginRoute        = "https://mobile.cmbchina.com/GLogin/Login/FirstLoginRoute.aspx"
	urlVerifyTrustyDevice     = "https://mobile.cmbchina.com/GLogin/Login/VerifyTrustyDevice.aspx?LoginRedirect=RTDRedirect&ClientNo=%s&version=%s&behavior_entryid=lge005001"
	urlVerifyTrust            = "https://mobile.cmbchina.com/GLogin/Login/VerifyTrustyDevice.aspx"
	urlSelectVerify           = "https://mobile.cmbchina.com/GLogin/Login/SelectVerify.aspx?LoginRedirect=RTDRedirect&ClientNo=%s&version=%s&DeviceType=D&behavior_entryid=lge002001&msid=%s"
	urlPollingQueryResult     = "https://polling.paas.cmbchina.com/PollingQueryResult"
	urlQRcodeVerify           = "https://mobile.cmbchina.com/GLogin/Login/QRcodeVerify.aspx"
	urlPreLogin               = "https://mobile.cmbchina.com/GLogin/Login/PreLogin.aspx"
	urlSendSMS                = "https://mobile.cmbchina.com/GLogin/Login/SendSMS.aspx"
	urlSMSLogin               = "https://mobile.cmbchina.com/GLogin/Login/SMSLogin.aspx"
	urlVtmLogin               = "https://mobile.cmbchina.com/GLogin/Login/VtmLogin.aspx"
	urlGetDomainsInfo         = "https://mobile.cmbchina.com/GExternal/UserInfoDataLoad/AppLauchAsynReqst/GetDomainsInfo.aspx"
	urlLogSrv                 = "https://mobile.cmbchina.com/GExternal/UserInfoDataLoad/AppLauchAsynReqst/LogSyncSrv.aspx"
	urlDynamic                = "https://mobile.cmbchina.com/GExternal/UserInfoDataLoad/AppLauchAsynReqst/DynamicFuncRequest.aspx"
	urlAccountLogin           = "https://mobile.cmbchina.com/GLogin/Login/AccountLogin.aspx"
	urlPAccountNoticeLogin    = "https://mobile.cmbchina.com/PAccountNotice/Login.aspx"
	urlDAccountViewLogin      = "https://mobile.cmbchina.com/DAccountView/Login.aspx"
	urlGExternalLogin         = "https://mobile.cmbchina.com/GExternal/Login.aspx"
	urlDTransactionLogin      = "https://mobile.cmbchina.com/DTransaction/Login.aspx"
	urlPushIDQuery            = "https://mobile.cmbchina.com/PAccountNotice/AccountNotice/CMBPushIDQuery.aspx"
	urlAVMyChannel            = "https://mobile.cmbchina.com/DAccountView/AccountView/AV_MyChannel.aspx"
	urlMyMenuQuery            = "https://mobile.cmbchina.com/GExternal/UserInfoDataLoad/AfterLoginAsynReqst/MyMenuQuery.aspx"
	urlQueryExpectLoanAjax    = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/QueryExpectLoanAjax.aspx"
	urlQueryMyRecommendAjax   = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/QueryMyRecommendAjax.aspx"
	urlIncomeExpenseAjax      = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/IncomeExpenseAjax.aspx"
	urlMyChannelRecommendAjax = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/MyChannelRecommendAjax.aspx"
	urlAs01Ajax               = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/As01Ajax.aspx"
	urlMyLoanAjax             = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/MyLoanAjax.aspx"
	urlCreditStateAjax        = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/CreditStateAjax.aspx"
	urlOnlineStoreAjax        = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/OnlineStoreAjax.aspx"
	urlYestDayIncomeAjax      = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/YestDayIncomeAjax.aspx"
	urlAs03Ajax               = "https://mobile.cmbchina.com/DAccountView/AvAjaxHelper/As03Ajax.aspx"
	urlGeneralBill            = "https://mobile.cmbchina.com/DTransaction/AccountBill/AB_GeneralBill.aspx"
	urlGeneralBillAjax        = "https://mobile.cmbchina.com/DTransaction/AccountBill/AB_GeneralBill.aspx"
	urlMobileQR               = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_Entry&version=%s&showtopbar=false&behavior_entryid=qrp004002"
	urlMobileQRPreLogin       = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_PreLogin"
	urlMobileQRGetQR          = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_GetQR"
	urlMobileQRGetDefaultCard = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_GetDefaultCard"
	urlMobileQRGetQRUrl       = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_GetQRUrl"
	urlMobileQRQueryResult    = "https://netpay.cmbchina.com/mobile-qr/BaseHttp.dll?MB_CCQRPay_QueryResult"
	urlDTransferLogin         = "https://mobile.cmbchina.com/DTransfer/Login.aspx"
	urlTransferHome           = "https://mobile.cmbchina.com/DTransfer/Home/TF_Home.aspx"
	urlTransferQueryAjax      = "https://mobile.cmbchina.com/DTransfer/TF_Transfer_AjaxQuery.aspx"
	urlTranInfo               = "https://mobile.cmbchina.com/DTransfer/NormalTransfer/TF_TranInfo.aspx"
	urlQueryTransferResult    = "https://mobile.cmbchina.com/DTransfer/NormalTransfer/TF_QueryTransferResult.aspx"
)

const (
	cfBundleVersion      = "9.3.0"
	sdkVersion           = "5.0.1.1"
	newAppHmacSha1Key    = "cmb@hmac"
	oldAppHmacSha1Key    = "xxmaccmb"
	HmacSm3Key           = "9cjCRalCzwe3#FRWeJkiPJKwJYg^Z$U3wU^QyV3L5o*zqDs8JC35UA6WU!cULaf*"
	aes2018Key           = "cmb@bank@2018"
	sm4LogKey            = "5KrOf8|Rq~Ih9q=,"
	sm4ConstKey          = "bhNi?@)3B]vQHs.?"
	sm4HealthCodeKey     = "YGj|IKuH$HzrZd2l"
	sm4TransferDeviceKey = "G(QD7LY%}&/@kRs_"
	dynamicAesKey        = "cmb@bank"
	secAesKey            = "xxccmmbb"
	netPayRc4Key         = "JVhDSy8-&#Fsj83bdgfJ"
	queryTouchIDAESKey   = "Tvxtz@20150000000000000000000000"
)

var logger *log2.MyLog
var rsaPasswordPub *rsa.PublicKey
var certFPs []string

const sm2PubX = "1977a0f2e9a1b090193cc39a777768771297d2c11a3426bcd7955ab9b5086854"
const sm2PubY = "1ad5b65f88ac1f17d149e08738c9350853791508f2c6a0e3524f6e1eb3c20688"
const sm2PasswordPubX = "51CAE4F8D345599B7C124DD2447B742929B1833233686ACE22309A9A2C88CF45"
const sm2PasswordPubY = "EC549333E77B7F46307A8CCCE15DC7C0C4BBC2099270D0E38406BB53467ED440"

func init() {
	logger = &log2.MyLog{Prefix: ""}

	rsaPasswordPub = &rsa.PublicKey{}
	rsaPasswordPub.N, _ = new(big.Int).SetString("B489A09AB62D585894F7E6F2F946534374041D2FF4A8D570AD896D22BC038B5"+
		"7F2C7195D12B90CD6EB9D5C3FB5ED4CC79A07E550424917F845FE71662E924179", 16)
	rsaPasswordPub.E = 65537

	certFPs = []string{
		"1fb86b1168ec743154062e8c9cc5b171a4b7ccb4",
		"1d4713ac3fd0e7a8d4462cda89fe4c813a5fb708",
		"a8985d3a65e5e5c4b2d7d66d40c6dd2fb19c5436",
	}

}
