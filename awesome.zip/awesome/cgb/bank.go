package cgb

import (
	"bytes"

	"github.com/4kills/go-zlib"
)

// Bank 广发银行
type Bank struct {
}

// TongdunZLibCompress 同盾特殊zlib压缩
func TongdunZLibCompress(in []byte) ([]byte, error) {
	buf := bytes.Buffer{}
	w := zlib.NewWriter(&buf)
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	out := buf.Bytes()

	header := out[:2]
	body := out[2 : len(out)-4]
	end := out[len(out)-4:]
	for i := 0; i < len(header); i++ {
		header[i] = header[i] & ^byte(6*i+0x11) | byte(6*i+0x11) & ^(header[i])
	}
	for i := 0; i < len(body); i++ {
		body[i] = (body[i]) & ^byte(6*i+0x11) | byte(6*i+0x11) & ^(body[i])
	}

	alder1 := uint16(end[0])<<8 + uint16(end[1])
	alder2 := uint16(end[2])<<8 + uint16(end[3])
	alder1 = ^alder1&0xDEFA | alder1&0x2105
	alder2 = ^alder2&0x1DF5 | alder2&0xE20A
	end[0] = byte(alder1 >> 8)
	end[1] = byte(alder1)
	end[2] = byte(alder2 >> 8)
	end[3] = byte(alder2)

	for i := 0; i < len(end); i++ {
		end[i] = (end[i]) & ^byte(6*i+0x11) | byte(6*i+0x11) & ^(end[i])
	}

	return out, nil
}
