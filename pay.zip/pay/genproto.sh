#!/bin/sh
protoc --proto_path=./proto/alipaymsg --go_out=./proto/alipaymsg ./proto/alipaymsg/*.proto