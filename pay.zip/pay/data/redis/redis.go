package redis

import (
	"encoding/json"
	"errors"
	"pay/utils/config"
	"pay/utils/logger"
	"time"

	"github.com/gomodule/redigo/redis"
)

var (
	redisPool *redis.Pool
)

var (
	errKeyNotFound   = errors.New("key not found")
	errFieldNotFound = errors.New("field not found")
)

func getConnection() (redis.Conn, error) {
	c := redisPool.Get()
	return c, c.Err()
}

// InitRedis 初始化redis连接池
func InitRedis(cfg *config.RedisConfig) error {
	redisPool = &redis.Pool{
		MaxIdle:     5,
		MaxActive:   200,
		IdleTimeout: 180 * time.Second,
		Dial: func() (redis.Conn, error) {
			return redis.Dial("tcp", cfg.DBHost,
				redis.DialPassword(cfg.DBPass),
				redis.DialDatabase(cfg.DBIndex))
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			if time.Since(t) < time.Minute {
				return nil
			}
			_, err := c.Do("PING")
			if err != nil {
				logger.Errorf("Redis ping错误: %+v.", err)
			}
			return err
		},
	}

	// 尝试连接
	c := redisPool.Get()
	defer c.Close()

	if err := c.Err(); err != nil {
		redisPool = nil
		return err
	}

	return nil
}

// Set 设置key
func Set(key string, value string) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("SET", key, value)

	return err
}

// SetObject 设置object
func SetObject(key string, obj interface{}) error {
	j, err := json.Marshal(obj)
	if err != nil {
		return err
	}

	return Set(key, string(j))
}

// Get 获取key
func Get(key string) (string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return "", err
	}

	reply, err := c.Do("GET", key)
	if err != nil {
		return "", nil
	}

	if reply == nil {
		return "", errKeyNotFound
	}

	return string(reply.([]byte)), nil
}

// GetObject 获取object
func GetObject(key string, obj interface{}) error {
	j, err := Get(key)
	if err != nil {
		return err
	}

	return json.Unmarshal([]byte(j), obj)
}

// Del 删除key
func Del(key string) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("DEL", key)
	return err
}

// HSet 设置hash
func HSet(key string, field string, value string) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("HSET", key, field, value)
	return err
}

// HSetObject 缓存object对象
func HSetObject(key string, field string, obj interface{}) error {
	j, err := json.Marshal(obj)
	if err != nil {
		return err
	}

	return HSet(key, field, string(j))
}

// HGet 获取hash
func HGet(key string, field string) (string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return "", err
	}

	reply, err := c.Do("HGET", key, field)
	if err != nil {
		return "", err
	}

	if reply == nil {
		return "", errFieldNotFound
	}

	return string(reply.([]byte)), nil
}

// HGetObject 获取object对象
func HGetObject(key string, field string, obj interface{}) error {
	j, err := HGet(key, field)
	if err != nil {
		return err
	}

	return json.Unmarshal([]byte(j), obj)
}

// HMSet 设置多个hash
func HMSet(key string, values *map[string]string) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("HMSET", redis.Args{}.Add(key).AddFlat(*values)...)

	return err
}

// HMGet 获取多个hash
func HMGet(key string, fields *[]string) (*map[string]string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return nil, err
	}

	reply, err := c.Do("HMGET", redis.Args{}.Add(key).AddFlat(*fields)...)
	if err != nil {
		return nil, err
	}

	if reply == nil {
		return nil, errFieldNotFound
	}

	values, err := redis.Values(reply, err)
	if err != nil {
		return nil, err
	}

	if len(values) <= 0 {
		return nil, nil
	}

	res := make(map[string]string)
	for k, v := range values {
		if k < len(*fields) {
			res[(*fields)[k]] = string(v.([]byte))
		}
	}

	return &res, nil
}

// HGetAll 获取所有hash
func HGetAll(key string) (*map[string]string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return nil, err
	}

	reply, err := c.Do("HGETALL", key)
	if err != nil {
		return nil, err
	}

	if reply == nil {
		return nil, errFieldNotFound
	}

	values, err := redis.Values(reply, err)
	if len(values) <= 0 {
		return nil, nil
	}

	res := make(map[string]string)
	for k, v := range values {
		if k%2 == 0 {
			key = string(v.([]byte))
		} else {
			res[key] = string(v.([]byte))
		}
	}

	return &res, nil
}

// HDel 删除hash
func HDel(key string, fields *[]string) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("HDEL", redis.Args{}.Add(key).AddFlat(*fields)...)

	return err
}

// HExists 是否存在hash
func HExists(key string, field string) (bool, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return false, err
	}

	reply, err := c.Do("HEXISTS", key, field)
	if err != nil {
		return false, err
	}

	value, ok := reply.(int64)
	if !ok {
		return false, nil
	}

	if value != 0 {
		return true, nil
	}

	return false, nil
}

// HLen hash长度
func HLen(key string) (int64, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return 0, err
	}

	reply, err := c.Do("HLEN", key)
	if err != nil {
		return 0, errKeyNotFound
	}

	value, ok := reply.(int64)
	if !ok {
		return 0, errKeyNotFound
	}

	return value, nil
}

// HKeys 获取所有hash的key
func HKeys(key string) (*[]string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return nil, err
	}

	reply, err := c.Do("HKEYS", key)
	if err != nil {
		return nil, errKeyNotFound
	}

	values, err := redis.Values(reply, err)
	if len(values) <= 0 {
		return nil, nil
	}

	var res []string
	for _, v := range values {
		res = append(res, string(v.([]byte)))
	}

	return &res, nil
}

// HVals 获取所有hash的value
func HVals(key string) (*[]string, error) {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return nil, err
	}

	reply, err := c.Do("HVALS", key)
	if err != nil {
		return nil, errKeyNotFound
	}

	values, err := redis.Values(reply, err)
	if len(values) <= 0 {
		return nil, nil
	}

	var res []string
	for _, v := range values {
		res = append(res, string(v.([]byte)))
	}

	return &res, nil
}

// PExpire 设置过期时间, 毫秒
func PExpire(key string, t int) error {
	c, err := getConnection()
	defer c.Close()

	if err != nil {
		return err
	}

	_, err = c.Do("PEXPIRE", key, t)

	return err
}
