package redis

import (
	"pay/utils/config"
	"testing"
)

var cfg = &config.RedisConfig{
	DBHost:  "127.0.0.1:6379",
	DBPass:  "aa123456",
	DBIndex: 0,
}

func Test_Get_Set(t *testing.T) {
	const (
		testKey   = "TestKey"
		testValue = "TestValue"
	)

	if err := InitRedis(cfg); err != nil {
		t.Fatalf("连接redis数据库失败, 错误: %+v.", err)
	}

	if err := Set(testKey, testValue); err != nil {
		t.Fatalf("Set失败: %+v.", err)
	}

	value, err := Get(testKey)
	if err != nil {
		t.Fatalf("Get失败: %+v.", err)
	}

	if value != testValue {
		t.Fatalf("取出值: %+v != %+v.", value, testValue)
	}

	if err := Del(testKey); err != nil {
		t.Fatalf("Del失败: %+v.", err)
	}
}

func Test_HGet_HSet(t *testing.T) {
	const (
		testKey   = "TestHashKey"
		testField = "TestHashField"
		testValue = "TestHashValue"
	)

	if err := InitRedis(cfg); err != nil {
		t.Fatalf("连接redis数据库失败, 错误: %+v.", err)
	}

	if err := HSet(testKey, testField, testValue); err != nil {
		t.Fatalf("HSet失败: %+v.", err)
	}

	value, err := HGet(testKey, testField)
	if err != nil {
		t.Fatalf("HGet失败: %+v.", err)
	}

	if value != testValue {
		t.Fatalf("取出值: %+v != %+v.", value, testValue)
	}

	exists, err := HExists(testKey, testField)
	if err != nil {
		t.Fatalf("HExists失败: %+v.", err)
	}

	if !exists {
		t.Fatalf("HExists失败, 存在的Key返回False.")
	}

	len, err := HLen(testKey)
	if err != nil {
		t.Fatalf("HLen失败: %+v", err)
	}

	if len != 1 {
		t.Fatalf("HLen返回值: %+v不等于1.", len)
	}

	if err := Del(testKey); err != nil {
		t.Fatalf("DEL失败: %+v.", err)
	}

	exists, err = HExists(testKey, testField)
	if err != nil {
		t.Fatalf("HExists失败: %+v.", err)
	}

	if exists {
		t.Fatalf("HExists失败, 不存在的Key返回True.")
	}

	len, err = HLen(testKey)
	if err != nil {
		t.Fatalf("HLen失败: %+v", err)
	}

	if len != 0 {
		t.Fatalf("HLen返回值: %+v不等于0.", len)
	}
}

func Test_HMGET_HMSET(t *testing.T) {
	const testKey = "TestHMKey"
	testData := map[string]string{
		"TestField1": "TestValue1",
		"TestField2": "TestValue2",
		"TestField3": "TestValue3",
	}

	if err := InitRedis(cfg); err != nil {
		t.Fatalf("连接redis数据库失败, 错误: %+v.", err)
	}

	if err := HMSet(testKey, &testData); err != nil {
		t.Fatalf("HMSET失败: %+v.", err)
	}

	var fields []string
	for k := range testData {
		fields = append(fields, k)
	}

	value, err := HMGet(testKey, &fields)
	if err != nil {
		t.Fatalf("HMGET失败: %+v.", err)
	}

	len1 := len(testData)
	len2 := len(*value)
	if len1 != len2 {
		t.Fatalf("取出值长度: %+v不等于原始长度: %+v.", len2, len1)
	}

	fatal := false
	for k, v := range *value {
		n, ok := testData[k]
		if ok {
			t.Logf("Key: %+v, 原始数据: %+v, 取出数据: %+v.", k, n, v)
			if v != n {
				fatal = true
			}
		} else {
			t.Logf("取出Key: %+v不在原始数据中.", k)
			fatal = true
		}
	}

	if fatal {
		t.Fatal("取出值校验失败.")
	}

	HKeys(testKey)
	HVals(testKey)

	if err := Del(testKey); err != nil {
		t.Fatalf("DEL失败: %+v.", err)
	}
}
