package syncmgr

import (
	"encoding/json"
	"fmt"
	"pay/api"
	"pay/data/redis"
	"pay/proto/alipaymsg"
	"pay/utils/alipayutils"
	"pay/utils/logger"
	"strconv"

	"github.com/golang/protobuf/proto"
)

const (
	alipaySyncInfoKey = "AlipaySyncInfo"
	apSyncConfigs     = "APSyncConfigs"
	apUplinkConfigs   = "APUplinkConfigs"
	apBucketConfigs   = "APBucketConfigs"
)

// SyncKeyInfo 结构
type SyncKeyInfo struct {
	Biz     string `json:"biz"`
	Type    string `json:"type"`
	Enum    string `json:"enum"`
	UpsKey  string `json:"upskey"`
	Cmd     string `json:"cmd"`
	SyncKey int64  `json:"syncKey"`
}

// SyncMgr 结构
type SyncMgr struct {
	Account  string                    `json:"account"`
	Platform string                    `json:"platform"`
	KeyInfo  map[string][]*SyncKeyInfo `json:"keyInfo"`
}

// NewSyncMgr 新建SyncMgr管理
func NewSyncMgr(account string, platform string) *SyncMgr {
	mgr := &SyncMgr{
		Account:  account,
		Platform: platform,
		KeyInfo:  make(map[string][]*SyncKeyInfo),
	}

	return mgr
}

func createSyncKeyInfo(sci *SyncConfigInfo) *SyncKeyInfo {
	ski := &SyncKeyInfo{
		Biz:     sci.Biz,
		Enum:    sci.Enum,
		Type:    sci.Type,
		UpsKey:  sci.UpsKey,
		Cmd:     "1",
		SyncKey: 0,
	}

	if sci.Cmd == "NotPersistence" {
		ski.Cmd = "0"
	}

	return ski
}

func (mgr *SyncMgr) findSyncKeyInfoWithBizName(name string) *SyncKeyInfo {
	syncList, ok := mgr.KeyInfo[apSyncConfigs]
	if ok {
		for _, item := range syncList {
			if item.Biz == name {
				return item
			}
		}
	}

	bucketList, ok := mgr.KeyInfo[apBucketConfigs]
	if ok {
		for _, item := range bucketList {
			if item.Biz == name {
				return item
			}
		}
	}

	return nil
}

// Load 从缓存加载sync信息
func (mgr *SyncMgr) Load() {
	field := fmt.Sprintf("%s_%s", mgr.Account, mgr.Platform)
	exists, err := redis.HExists(alipaySyncInfoKey, field)

	// 没有尝试从设备服务读取
	if err != nil || !exists {
		data, err := api.AccountGetExtInfo(mgr.Account, api.GetPlatformCode(mgr.Platform))
		if err == nil && data != "" {
			if err := redis.HSet(alipaySyncInfoKey, field, data); err != nil {
				exists = true
			}
		}
	}

	// 存在尝试读取
	if exists {
		value, err := redis.HGet(alipaySyncInfoKey, field)
		if err == nil {
			if err = json.Unmarshal([]byte(value), mgr); err == nil {
				return
			}

			logger.Errorf("[SyncMgr]反序列错误, 帐号: %+v, 平台: %+v, 信息: %+v, 错误: %+v.",
				mgr.Account, mgr.Platform, value, err)

		} else {
			logger.Errorf("[SyncMgr]读取缓存信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
				mgr.Account, mgr.Platform, err)
		}
	}

	// 读取失败重新生成
	createConfig := func(sci []SyncConfigInfo) []*SyncKeyInfo {
		ski := []*SyncKeyInfo{}
		for _, v := range sci {
			key := createSyncKeyInfo(&v)
			ski = append(ski, key)
		}

		return ski
	}

	mgr.KeyInfo[apSyncConfigs] = createConfig(syncInfo.APSyncConfigs)
	mgr.KeyInfo[apUplinkConfigs] = createConfig(syncInfo.APUplinkConfigs)
	mgr.KeyInfo[apBucketConfigs] = createConfig(syncInfo.APBucketConfigs)

	mgr.Save()
}

// Save 保存sync信息到缓存
func (mgr *SyncMgr) Save() error {
	json, err := json.Marshal(mgr)
	if err != nil {
		logger.Errorf("[SyncMgr]序列化数据错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			mgr.Account, mgr.Platform, err)
		return err
	}

	jsonStr := string(json)

	api.AccountUploadExtInfo(mgr.Account, api.GetPlatformCode(mgr.Platform), jsonStr)

	field := fmt.Sprintf("%s_%s", mgr.Account, mgr.Platform)
	if err := redis.HSet(alipaySyncInfoKey, field, jsonStr); err != nil {
		logger.Errorf("[SyncMgr]缓存用户信息失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			mgr.Account, mgr.Platform, err)
		return err
	}

	return nil
}

// GetSyncKeyInfo 获取sync信息
func (mgr *SyncMgr) GetSyncKeyInfo(second bool) []*alipaymsg.KeyValuePairs {
	list := []*alipaymsg.KeyValuePairs{}

	createKeyValuePairs := func(ski *SyncKeyInfo, prefix string) *alipaymsg.KeyValuePairs {
		r := &alipaymsg.KeyValuePairs{}
		r.Key = proto.String(prefix + ski.Enum)
		if ski.SyncKey == 0 || ski.SyncKey == 1 {
			r.Value = proto.String(strconv.Itoa(int(ski.SyncKey)))
		} else {
			if second {
				r.Value = proto.String(alipayutils.C10To64(ski.SyncKey))
			} else {
				r.Value = proto.String("0")
			}
		}

		return r
	}

	sync := mgr.KeyInfo[apSyncConfigs]
	for _, v := range sync {
		if v.UpsKey == "1" && v.Cmd == "1" && v.Type == "device" {
			kv := createKeyValuePairs(v, "1_")
			list = append(list, kv)
		}
	}

	bucket := mgr.KeyInfo[apBucketConfigs]
	for _, v := range bucket {
		if second {
			if v.Type == "device" {
				kv := createKeyValuePairs(v, "2_")
				list = append(list, kv)
			}
		} else {
			kv := createKeyValuePairs(v, "2_")
			list = append(list, kv)
		}
	}

	syncVer := &alipaymsg.KeyValuePairs{
		Key:   proto.String("syncVer"),
		Value: proto.String("6"),
	}

	syncNew := &alipaymsg.KeyValuePairs{
		Key:   proto.String("syncIsNew"),
		Value: proto.String("1"),
	}

	if second {
		syncNew.Value = proto.String("1")
	}

	list = append(list, syncVer, syncNew)

	return list
}

// UpdateSyncData 更新sync信息
func (mgr *SyncMgr) UpdateSyncData(bizSyncData []*alipaymsg.ProtoBizSyncData, bucketSyncInfo *alipaymsg.ProtoBucketSyncInfo) {
	changed := false
	if bizSyncData != nil {
		for _, item := range bizSyncData {
			ski := mgr.findSyncKeyInfoWithBizName(item.GetBizName())
			if ski == nil {
				continue
			}

			ski.SyncKey = item.GetSyncKey()
			changed = true

			upskey := ski.UpsKey == "1"
			cmd := ski.Cmd == "1"

			if item.GetMultiDevice() == upskey && item.GetPersistentBiz() == cmd {
				continue
			}

			if item.GetMultiDevice() {
				ski.UpsKey = "1"
			} else {
				ski.UpsKey = "0"
			}

			if item.GetPersistentBiz() {
				ski.Cmd = "1"
			} else {
				ski.Cmd = "0"
			}
		}
	}

	if bucketSyncInfo != nil && bucketSyncInfo.GetSyncKey() != 0 {
		ski := mgr.findSyncKeyInfoWithBizName(bucketSyncInfo.GetBucketName())
		if ski != nil {
			ski.SyncKey = bucketSyncInfo.GetSyncKey()
			if bucketSyncInfo.GetMultiDevice() {
				ski.UpsKey = "1"
			} else {
				ski.UpsKey = "0"
			}

			changed = true
		}
	}

	if changed {
		mgr.Save()
	}
}
