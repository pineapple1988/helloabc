package syncmgr

import (
	"io/ioutil"

	"github.com/DHowett/go-plist"
)

// SyncConfigInfo 结构
type SyncConfigInfo struct {
	Biz    string `plist:"biz"`
	Type   string `plist:"type"`
	Enum   string `plist:"enum"`
	UpsKey string `plist:"upskey"`
	Cmd    string `plist:"cmd"`
}

// SyncInfo 结构
type SyncInfo struct {
	APSyncConfigs   []SyncConfigInfo `plist:"APSyncConfigs"`
	APUplinkConfigs []SyncConfigInfo `plist:"APUplinkConfigs"`
	APBucketConfigs []SyncConfigInfo `plist:"APBucketConfigs"`
}

var (
	syncInfo *SyncInfo
)

// LoadSyncInfo 从文件加载sync信息
func LoadSyncInfo(filename string) error {
	syncInfo = &SyncInfo{}

	buffer, err := ioutil.ReadFile(filename)
	if err != nil {
		return err
	}

	_, err = plist.Unmarshal(buffer, syncInfo)

	return err
}
