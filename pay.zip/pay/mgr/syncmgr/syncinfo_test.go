package syncmgr

import (
	"fmt"
	"testing"
)

func TestLoadSyncInfo(t *testing.T) {
	if err := LoadSyncInfo("../../data/syncinfo.plist"); err != nil {
		t.Fatalf("加载syncinfo.plist错误: %+v.", err)
	}

	fmt.Println(syncInfo.APSyncConfigs)
	fmt.Println(syncInfo.APUplinkConfigs)
	fmt.Println(syncInfo.APBucketConfigs)
}
