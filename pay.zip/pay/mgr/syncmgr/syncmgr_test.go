package syncmgr

import (
	"pay/data/redis"
	"pay/utils/config"
	"testing"
)

func TestSyncMgr(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1",
		DBPort: 6379,
		DBPass: "aa123456",
	}

	if err := redis.InitRedis(cfg); err != nil {
		t.Fatalf("连接redis数据库失败, 错误: %+v.", err)
	}

	if err := LoadSyncInfo("../../data/syncinfo.plist"); err != nil {
		t.Fatalf("加载syncinfo.plist错误: %+v.", err)
	}

	mgr := NewSyncMgr("test", "ios")
	mgr.Load()
}
