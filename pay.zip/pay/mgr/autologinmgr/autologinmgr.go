package autologinmgr

import (
	"encoding/json"
	"pay/mgr/accmgr"
	"pay/pay"
	"pay/utils/logger"
	"sync"
	"time"
)

func autoLoginRoutine(list *map[string]string) {
	cnt := len(*list)
	cur := 0
	wg := sync.WaitGroup{}
	logger.Infof("[autologinmgr]开始自动上号, 帐号数量: %d.", cnt)
	for _, v := range *list {
		cur++
		accInfo := pay.LoginSuccessInfo{}
		if err := json.Unmarshal([]byte(v), &accInfo); err != nil {
			logger.Warnf("[autologinmgr]无法反序列化帐号数据: %+v, 错误: %+v.", v, err)
			continue
		}

		logger.Infof("[autologinmgr]开始自动上号, 帐号: %s, 类型: %d, 平台: %d [%d/%d].",
			accInfo.Account, accInfo.AccType, accInfo.Platform, cur, cnt)

		go func(wg *sync.WaitGroup, accInfo *pay.LoginSuccessInfo, cur int) {
			wg.Add(1)
			defer func() {
				wg.Done()
			}()

			// 已在帐号列表, 代表已上号
			acc := accmgr.GetAccount(accInfo.AccType, accInfo.Account)
			if acc != nil {
				logger.Infof("[autologinmgr]帐号已在上号列表, 帐号: %s, 类型: %d, 平台: %d.",
					accInfo.Account, accInfo.AccType, accInfo.Platform)
				return
			}

			// 创建帐号, 密码为空
			acc, err := accmgr.CreateAccount(accInfo.Account, "", "", accInfo.AccType, accInfo.Platform)
			if err != nil {
				logger.Warnf("[autologinmgr]无法创建帐号, 帐号: %s, 类型: %d, 平台: %d.",
					accInfo.Account, accInfo.AccType, accInfo.Platform)
				return
			}

			// 添加到帐号管理器
			if err := accmgr.AddAccount(accInfo.AccType, acc); err != nil {
				logger.Warnf("[autologinmgr]无法将帐号添加到账号管理器, 帐号: %s, 类型: %d, 平台: %d.",
					accInfo.Account, accInfo.AccType, accInfo.Platform)
				return
			}

			var r *pay.ResultInfo
			for i := 0; i < 3; i++ {
				r = acc.Login(20000)

				needBreak := r.Code == pay.ErrCodeSuccess ||
					r.Code == pay.ErrCodeLoginPadding ||
					r.Code == pay.ErrCodeNeedSMSCode ||
					r.Code == pay.ErrCodeInvalidIDPWD ||
					r.Code == pay.ErrCodeCardBlock ||
					r.Code == pay.ErrCodeAccountRisk ||
					r.Code == pay.ErrCodeLoginOtherDevice

				if needBreak {
					break
				}

				logger.Infof("[autologinmgr]自动上号错误, 稍候重试, 帐号: %s, 类型: %d, 平台: %d, 代码: %d, 信息: %s.",
					accInfo.Account, accInfo.AccType, accInfo.Platform, r.Code, r.Msg)
				time.Sleep(time.Second * 3)
			}

			logger.Infof("[autologinmgr]自动上号返回, 帐号: %s, 代码: %d, 信息: %s [%d/%d].",
				accInfo.Account, r.Code, r.Msg, cur, cnt)
		}(&wg, &accInfo, cur)

		time.Sleep(time.Millisecond * 500)
	}

	wg.Wait()
	logger.Info("[autologinmgr]自动上结束.")
}

// StartLogin 自动上号
func StartLogin() error {
	list, err := pay.GetLoginSuccessList()
	if err != nil {
		return err
	}

	if list != nil {
		go autoLoginRoutine(list)
	} else {
		logger.Info("[autologinmgr]自动上号帐号列表为空.")
	}

	return nil
}
