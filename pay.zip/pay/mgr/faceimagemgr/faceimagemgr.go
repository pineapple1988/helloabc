package faceimagemgr

import (
	"fmt"
	"io/ioutil"
	"os"
	"pay/utils/logger"
)

const (
	basePath = "./data/faceimage"
)

// FaceImageInfo 刷脸图片信息
type FaceImageInfo struct {
	Hash string
	Type string
}

// LoadFaceImage 加载刷脸图片数据
func LoadFaceImage(account, hash string) (string, error) {
	name := fmt.Sprintf("%s/%s/%s.dat", basePath, account, hash)
	file, err := os.Open(name)
	if err != nil {
		logger.Errorf("[faceimagemgr]LoadFaceImage打开文件[%+v]错误: %+v.", name, err)
		return "", err
	}

	buf, err := ioutil.ReadAll(file)
	if err != nil {
		logger.Errorf("[faceimagemgr]LoadFaceImage读取文件数据错误, hash： %+v, 错误: %+v.", hash, err)
		return "", nil
	}

	return string(buf), nil
}

// SaveFaceImage 保存刷脸图片数据
func SaveFaceImage(account, hash, data string) error {
	path := fmt.Sprintf("%s/%s", basePath, account)
	name := fmt.Sprintf("%s/%s.dat", path, hash)
	if err := os.MkdirAll(path, os.ModePerm); err != nil {
		logger.Errorf("[faceimagemgr]SaveFaceImage创建目录[%+v]错误: %+v.", path, err)
		return err
	}

	file, err := os.Create(name)
	if err != nil {
		logger.Errorf("[faceimagemgr]SaveFaceImage创建文件[%+v]错误: %+v.", name, err)
		return err
	}

	defer file.Close()

	if _, err := file.WriteString(data); err != nil {
		logger.Errorf("[faceimagemgr]SaveFaceImage写入文件数据错误, hash: %+v, 错误: %+v.", hash, err)
		return err
	}

	return nil
}
