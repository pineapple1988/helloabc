package cookiemgr

import (
	"fmt"
)

// CookieMgr 结构
type CookieMgr struct {
	cookies map[string]*Cookie
}

var (
	mgr *CookieMgr
)

func init() {
	mgr = &CookieMgr{
		cookies: make(map[string]*Cookie),
	}
}

// GetUserCookie 取用户Cookie对象
func GetUserCookie(prefix, account, platform string) *Cookie {
	key := fmt.Sprintf("%s_%s_%s", prefix, account, platform)
	cookie, ok := mgr.cookies[key]
	if ok {
		return cookie
	}

	cookie = NewCookie(prefix, account, platform)
	mgr.cookies[key] = cookie
	return cookie
}
