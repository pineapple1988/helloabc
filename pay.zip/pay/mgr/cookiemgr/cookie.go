package cookiemgr

import (
	"encoding/json"
	"fmt"
	"pay/api"
	"pay/data/redis"
	"pay/utils"
	"pay/utils/logger"
	"strings"
)

// Cookie 结构
type Cookie struct {
	Prefix   string            `json:"-"`
	Account  string            `json:"account"`
	Platform string            `json:"platform"`
	SaveTime int64             `json:"saveTime"`
	Cookie   map[string]string `json:"cookie"`
}

// NewCookie 新建Cookie对象
func NewCookie(prefix string, account string, platform string) *Cookie {
	c := &Cookie{
		Prefix:   prefix,
		Account:  account,
		Platform: platform,
		Cookie:   make(map[string]string),
	}

	return c
}

// Load 从缓存加载Cookie数据
func (c *Cookie) Load() error {
	field := fmt.Sprintf("%s_%s", c.Account, c.Platform)
	exists, err := redis.HExists(c.Prefix, field)

	if err != nil || !exists {
		data, err := api.AccountGetCookie(c.Account, api.GetPlatformCode(c.Platform))
		if err == nil && data != "" {
			if err := redis.HSet(c.Prefix, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		value, err := redis.HGet(c.Prefix, field)
		if err != nil {
			logger.Errorf("[Cookie]加载缓存Cookie错误: %+v.", err)
			return err
		}

		cookie := &Cookie{}
		err = json.Unmarshal([]byte(value), cookie)
		if err != nil {
			logger.Errorf("[Cookie]反序列化Cookie错误: %+v, 数据: %+v.", err, value)
			return err
		}

		for k, v := range cookie.Cookie {
			c.Cookie[k] = v
		}
	}

	return nil
}

// Save 保存Cookie数据到缓存
func (c *Cookie) Save() error {
	c.SaveTime = utils.GetTimeStampEx()
	field := fmt.Sprintf("%s_%s", c.Account, c.Platform)
	json, err := json.Marshal(c)
	if err != nil {
		logger.Errorf("[Cookie]序列化Cookie错误: %+v.", err)
		return err
	}

	jsonStr := string(json)

	api.AccountUploadCookie(c.Account, api.GetPlatformCode(c.Platform), jsonStr)

	if err := redis.HSet(c.Prefix, field, jsonStr); err != nil {
		logger.Errorf("[Cookie]缓存Cookie错误: %+v, 数据: %+v.", err, jsonStr)
		return err
	}

	return nil
}

// GetCookie 取Cookie数据
func (c *Cookie) GetCookie(key string) string {
	if v, ok := c.Cookie[key]; ok {
		return v
	}

	return ""
}

// SetCookie 设置Cookie数据
func (c *Cookie) SetCookie(key, cookie string, save bool) {
	c.Cookie[key] = cookie
	if save {
		c.Save()
	}

}

// UpdateCookie 更新Cookie数据
func (c *Cookie) UpdateCookie(str string) {
	cookies := strings.Split(str, ";")
	changed := false
	for _, cookie := range cookies {
		arr := strings.Split(strings.TrimSpace(cookie), "=")
		if len(arr) > 1 {
			key := arr[0]
			value := arr[1]
			value = strings.ReplaceAll(value, `"`, ``)
			if key != "" && value != "" {
				ck, exists := c.Cookie[key]
				if !exists || ck != value {
					c.Cookie[key] = value
					changed = true

					logger.Debugf("[Cookie]UpdateCookie, acc: %+v, key: %+v, value: %+v.", c.Account, key, value)
				}
			}
		}
	}

	if changed {
		c.Save()
	}
}

// DelCookie 删除Cookie数据
func (c *Cookie) DelCookie(key string) {
	if _, ok := c.Cookie[key]; ok {
		delete(c.Cookie, key)
		c.Save()
	}
}
