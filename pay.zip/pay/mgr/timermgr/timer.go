package timermgr

import (
	"pay/utils"
)

type timerInfo struct {
	id       int
	interval int
	repeat   bool
	param    interface{}
	t        int64
}

type timer struct {
	handler TimerHandler
	info    map[int]*timerInfo
}

func newTimer(handler TimerHandler) *timer {
	t := &timer{
		handler: handler,
		info:    make(map[int]*timerInfo),
	}

	return t
}

func (t *timer) setTimer(id int, interval int, repeat bool, param interface{}) bool {
	info, ok := t.info[id]
	if !ok {
		info = &timerInfo{
			id:       id,
			interval: interval,
			repeat:   repeat,
			param:    param,
			t:        utils.GetTimeStampEx(),
		}
		t.info[id] = info
	} else {
		info.interval = interval
		info.repeat = repeat
		info.param = param
		info.t = utils.GetTimeStampEx()
	}

	return true
}

func (t *timer) killTimer(id int) {
	delete(t.info, id)
}

func (t *timer) isEmpty() bool {
	return len(t.info) == 0
}

func (t *timer) update(time int64) {
	r := []int{}
	for k, v := range t.info {
		if (time - v.t) > int64(v.interval) {
			go t.handler.OnTimer(k, v.param)
			if v.repeat {
				v.t = time
			} else {
				r = append(r, k)
			}
		}
	}

	for id := range r {
		delete(t.info, id)
	}
}
