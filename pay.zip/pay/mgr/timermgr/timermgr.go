package timermgr

import (
	"pay/utils"
	"sync"
	"time"
)

// TimerHandler 定时器事件接口
type TimerHandler interface {
	OnTimer(id int, param interface{})
}

// TimerMgr 结构
type TimerMgr struct {
	l sync.Mutex
	t map[TimerHandler]*timer
}

var (
	mgr *TimerMgr
)

func init() {
	mgr = &TimerMgr{
		l: sync.Mutex{},
		t: make(map[TimerHandler]*timer),
	}

	go timerRoutine()
}

// SetTimer 设置定时器
func SetTimer(handler TimerHandler, id int, interval int, repeat bool, param interface{}) bool {
	mgr.l.Lock()
	defer mgr.l.Unlock()

	timer, ok := mgr.t[handler]
	if !ok {
		timer = newTimer(handler)
		mgr.t[handler] = timer
	}

	return timer.setTimer(id, interval, repeat, param)
}

// KillTimer 删除定时器
func KillTimer(handler TimerHandler, id int) {
	mgr.l.Lock()
	defer mgr.l.Unlock()

	timer, ok := mgr.t[handler]
	if ok {
		timer.killTimer(id)
		if timer.isEmpty() {
			delete(mgr.t, handler)
		}
	}
}

func timerProcess() {
	mgr.l.Lock()
	defer mgr.l.Unlock()

	time := utils.GetTimeStampEx()
	rmList := []TimerHandler{}

	for k, v := range mgr.t {
		v.update(time)
		if v.isEmpty() {
			rmList = append(rmList, k)
		}
	}

	for _, v := range rmList {
		delete(mgr.t, v)
	}
}

func timerRoutine() {
	for {
		timerProcess()
		time.Sleep(time.Millisecond * 10)
	}
}
