package accmgr

import (
	"pay/pay"
	"payserver/common/model"
)

// AccOperator Account操作接口
type AccOperator interface {
	GetAccount() string
	Login(timeout int) *pay.ResultInfo
	Logout() *pay.ResultInfo
	ResetPassword(password, payPassword string) *pay.ResultInfo
	SendCode() *pay.ResultInfo
	VerifyCode(code string) *pay.ResultInfo
	CardList() *pay.ResultInfo
	Balance() *pay.ResultInfo
	BillList(req *model.AccountBillListReq) *pay.ResultInfo
	Transfer(req *model.AccountTransferReq) *pay.ResultInfo
	TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo
	Event(event int, data string) *pay.ResultInfo
	SetCardNo(cardNo string)
}
