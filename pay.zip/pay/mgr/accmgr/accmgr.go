package accmgr

import (
	"errors"
	"pay/pay/alipay"
	"pay/pay/bcm"
	"pay/pay/cbc"
	"pay/pay/ccb"
	"pay/pay/ceb"
	"pay/pay/cib"
	"pay/pay/pingan"
	"pay/pay/psbc"
	"pay/pay/pufa"
	"pay/pay/ysf"
	"payserver/common"
)

var (
	alipayMgr *AlipayMgr
	bankMgr   *BankMgr
)

func init() {
	alipayMgr = &AlipayMgr{
		list: make(map[string]*alipay.Account, 0),
	}

	bankMgr = &BankMgr{
		list: make(map[int](map[string]AccOperator)),
	}
}

// GetAlipayMgr 取支付宝帐号管理器
func GetAlipayMgr() *AlipayMgr {
	return alipayMgr
}

// GetBankMgr 取银行帐号管理器
func GetBankMgr() *BankMgr {
	return bankMgr
}

// CreateAccount 创建帐号
func CreateAccount(account, password, payPassword string, acctype, platform int) (AccOperator, error) {
	plt := common.GetPlatformName(platform)

	switch acctype {
	case common.AccountTypeAlipay:
		return alipay.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeWechat:
	case common.AccountTypeYSF:
		return ysf.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeICBC:
	case common.AccountTypeABC:
	case common.AccountTypeCCB:
		return ccb.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeCBC:
		return cbc.NewAccount(account, password, payPassword, plt)
	case common.AccountTypePAYH:
		return pingan.NewAccount(account, password, payPassword, plt)
	case common.AccountTypePUFA:
		return pufa.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeCIB:
		return cib.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeBCM:
		return bcm.NewAccount(account, password, payPassword, plt)
	case common.AccountTypeCEB:
		return ceb.NewAccount(account, password, payPassword, plt)
	case common.AccountTypePSBC:
		return psbc.NewAccount(account, password, payPassword, plt)
	}

	return nil, nil
}

// AddAccount 添加帐号
func AddAccount(acctype int, acc AccOperator) error {
	switch acctype {
	case common.AccountTypeAlipay:
		{
			account, ok := acc.(*alipay.Account)
			if !ok {
				return errors.New("无法将帐号类型转换为alipay帐号")
			}

			alipayMgr.Add(account)
		}
	case common.AccountTypeWechat:
		{

		}
	default:
		bankMgr.Add(acctype, acc)
	}

	return nil
}

// GetAccount 取帐号
func GetAccount(acctype int, account string) AccOperator {
	switch acctype {
	case common.AccountTypeAlipay:
		acc := alipayMgr.Get(account)
		if acc != nil {
			return acc
		}

		return nil
	case common.AccountTypeWechat:
	default:
		return bankMgr.Get(acctype, account)
	}

	return nil
}
