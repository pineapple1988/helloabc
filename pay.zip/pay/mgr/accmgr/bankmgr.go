package accmgr

import "sync"

// BankMgr 银行帐号管理器
type BankMgr struct {
	list map[int](map[string]AccOperator)
	lock sync.RWMutex
}

// Add 添加银行帐号
func (mgr *BankMgr) Add(accType int, acc AccOperator) {
	mgr.lock.Lock()
	defer mgr.lock.Unlock()

	accMap, exists := mgr.list[accType]
	if !exists {
		accMap = map[string]AccOperator{}
		mgr.list[accType] = accMap
	}

	accMap[acc.GetAccount()] = acc
}

// Del 删除银行帐号
func (mgr *BankMgr) Del(accType int, account string) {
	mgr.lock.Lock()
	defer mgr.lock.Unlock()

	accMap, exists := mgr.list[accType]
	if exists {
		delete(accMap, account)
	}
}

// Get 取银行帐号
func (mgr *BankMgr) Get(accType int, account string) AccOperator {
	mgr.lock.RLock()
	defer mgr.lock.RUnlock()

	accMap, exists := mgr.list[accType]
	if !exists {
		return nil
	}

	acc, exists := accMap[account]
	if exists {
		return acc
	}

	return nil
}
