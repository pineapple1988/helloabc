package accmgr

import (
	"pay/pay/alipay"
	"sync"
)

// AlipayMgr 支付宝帐号管理
type AlipayMgr struct {
	list map[string]*alipay.Account
	lock sync.RWMutex
}

// Add 添加支付宝帐号
func (mgr *AlipayMgr) Add(acc *alipay.Account) {
	mgr.lock.Lock()
	mgr.list[acc.Account] = acc
	mgr.lock.Unlock()
}

// Del 删除支付宝帐号
func (mgr *AlipayMgr) Del(account string) {
	mgr.lock.Lock()
	delete(mgr.list, account)
	mgr.lock.Unlock()
}

// Get 取支付宝帐号
func (mgr *AlipayMgr) Get(account string) *alipay.Account {
	mgr.lock.RLock()
	defer mgr.lock.RUnlock()

	acc, exists := mgr.list[account]
	if exists {
		return acc
	}

	return nil
}
