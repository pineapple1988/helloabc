package utils

var (
	iphoneModelArray = []string{
		"iPhone7,2", "iPhone7,1", // 6, 6p
		"iPhone8,1", "iPhone8,2", "iPhone8,4", // 6s, 6sp, se
		"iPhone9,1", "iPhone9,2", "iPhone9,3", "iPhone9,4", // 7, 7p
		"iPhone10,1", "iPhone10,4", "iPhone10,2", "iPhone10,5", // 8, 8p
		"iPhone10,3", "iPhone10,6", // x
	}

	iphoneNameArray = []string{
		"iPhone 6", "iPhone 6 Plus",
		"iPhone 6s", "iPhone 6s Plus", "iPhone SE",
		"iPhone 7", "iPhone 7 Plus", "iPhone 7", "iPhone 7 Plus",
		"iPhone 8", "iPhone 8", "iPhone 8 Plus", "iPhone 8 Plus",
		"iPhone X", "iPhone X",
	}

	iphoneScreenSizeArray = []string{
		"375*667", "414*736",
		"375*667", "414*736", "320*568",
		"375*667", "414*736", "375*667", "414*736",
		"375*667", "375*667", "414*736", "414*736",
		"375*812", "375*812",
	}

	iphoneOSVerArray = []string{
		"11.1", "11.1.1", "11.1.2",
		"11.2", "11.2.1", "11.2.2", "11.2.5", "11.2.6",
		"11.3", "11.3.1",
		"11.4", "11.4.1",
		"12.0", "12.0.1",
		"12.1", "12.1.1", "12.1.2", "12.1.3", "12.1.4",
	}

	iphoneOSFirmwareArray = []string{
		"15B93", "15B150", "15B202",
		"15C114", "15C153", "15C202", "15D60", "15D100",
		"15E216", "15E302",
		"15F79", "15G77",
		"16A366", "16A404",
		"16B92", "16C50", "16C104", "16D39", "16D57",
	}
)

// GetIPhoneModel 获取随机的iphone类型
// 返回类型, 名字, 分辨率
func GetIPhoneModel() (string, string, string) {
	idx := RandIntn(len(iphoneModelArray))
	return iphoneModelArray[idx], iphoneNameArray[idx], iphoneScreenSizeArray[idx]
}

// GetIPhoneOSVersion 获取随机的iphone系统版本号
func GetIPhoneOSVersion() string {
	return iphoneOSVerArray[RandIntn(len(iphoneOSVerArray))]
}

// GetIPhoneOSFirmware 获取随机的iphone系统版本固件
func GetIPhoneOSFirmware(ver string) string {
	for i := 0; i < len(iphoneOSFirmwareArray); i++ {
		if ver == iphoneOSVerArray[i] {
			return iphoneOSFirmwareArray[i]
		}
	}
	return ""
}
