package utils

// ProxyInfo 代理信息
type ProxyInfo struct {
	URI  string `json:"uri"`
	User string `json:"user"`
	Pass string `json:"pass"`
}
