package logger

import (
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"
)

const (
	infoPrefix  = "[INFO ] - "
	warnPrefix  = "[WARN ] - "
	errorPrefix = "[ERROR] - "
	debugPrefix = "[DEBUG] - "
	ginPrefix   = "[GIN  ] - "
	transPrefix = "[TRANS] - "
	endLine     = "\r\n"
)

var (
	logNormal   *log.Logger
	logError    *log.Logger
	logGin      *log.Logger
	logTransfer *log.Logger
	logDir      string
	logFlags    = log.LstdFlags | log.Lmicroseconds
	debugMode   = false
	dayOfYear   int
)

func checkNewDay() error {
	t := time.Now()
	today := t.YearDay()

	// 当时间天数改变时要重新生成日志文件
	if dayOfYear == 0 || dayOfYear != today {
		// 重新创建日志文件目录
		path := fmt.Sprintf("%s/%.4d%.2d%.2d", logDir, t.Year(), t.Month(), t.Day())
		if err := os.MkdirAll(path, 0777); err != nil {
			fmt.Printf("无法创建日志目录: %s.\n", path)
			return err
		}

		// 创建普通日志文件
		fileNormal, err := os.OpenFile(path+"/log.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
		if err != nil {
			return err
		}

		// 创建错误日志文件
		fileError, err := os.OpenFile(path+"/error.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
		if err != nil {
			return err
		}

		// 创建gin日志文件
		fileGin, err := os.OpenFile(path+"/gin.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
		if err != nil {
			return err
		}

		// 创建转帐日志文件
		fileName := fmt.Sprintf("%s/transfer/transfer_%.4d%.2d%.2d.txt", logDir, t.Year(), t.Month(), t.Day())
		fileTransfer, err := os.OpenFile(fileName, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
		if err != nil {
			return err
		}

		// 创建日志
		logNormal = log.New(io.MultiWriter(fileNormal, os.Stdout), "", logFlags)
		logError = log.New(io.MultiWriter(fileNormal, fileError, os.Stderr), "", logFlags)
		logGin = log.New(io.MultiWriter(fileGin, os.Stdout), "", logFlags)
		logTransfer = log.New(io.MultiWriter(fileTransfer, fileNormal, os.Stdout), "", logFlags)

		dayOfYear = today
	}

	return nil
}

// SetDebug 设置调试模式, 调试模式下记录行数
func SetDebug() {
	logFlags = log.LstdFlags | log.Lmicroseconds | log.Llongfile
	debugMode = true
}

// SetDir 设置日志输出目录
func SetDir(dir string) {
	logDir = strings.TrimSuffix(dir, "/")
	logDir = strings.TrimSuffix(dir, `\`)

	os.MkdirAll(logDir+"/transfer", 0777)
}

// Info 普通日志
func Info(str string) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := infoPrefix + str + endLine
	logNormal.Output(2, logStr)
}

// Infof 普通日志
func Infof(format string, v ...interface{}) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := infoPrefix + format + endLine
	logNormal.Output(2, fmt.Sprintf(logStr, v...))
}

// Warn 警告日志
func Warn(str string) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := warnPrefix + str + endLine
	logNormal.Output(2, logStr)
}

// Warnf 警告日志
func Warnf(format string, v ...interface{}) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := warnPrefix + format + endLine
	logNormal.Output(2, fmt.Sprintf(logStr, v...))
}

// Error 错误日志
func Error(str string) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := errorPrefix + str + endLine
	logError.Output(2, logStr)
}

// Errorf 错误日志
func Errorf(format string, v ...interface{}) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := errorPrefix + format + endLine
	logError.Output(2, fmt.Sprintf(logStr, v...))
}

// Debug 调试日志
func Debug(str string) {
	if !debugMode {
		return
	}

	if err := checkNewDay(); err != nil {
		return
	}

	logStr := debugPrefix + str + endLine
	logNormal.Output(2, logStr)
}

// Debugf 调试日志
func Debugf(format string, v ...interface{}) {
	if !debugMode {
		return
	}

	if err := checkNewDay(); err != nil {
		return
	}

	logStr := debugPrefix + format + endLine
	logNormal.Output(2, fmt.Sprintf(logStr, v...))
}

// LogGin gin日志
func LogGin(str string) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := ginPrefix + str + endLine
	logGin.Output(2, logStr)
}

// LogTransfer 转帐日志
func LogTransfer(format string, v ...interface{}) {
	if err := checkNewDay(); err != nil {
		return
	}

	logStr := transPrefix + format + endLine
	logTransfer.Output(2, fmt.Sprintf(logStr, v...))
}
