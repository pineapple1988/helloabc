package utils

import (
	"encoding/binary"
	"io"
)

// ByteArray 结构
type ByteArray struct {
	buf      []byte
	posWrite int
	posRead  int
	endian   binary.ByteOrder
}

// ByteArrayEndian 默认大端序
var ByteArrayEndian binary.ByteOrder = binary.BigEndian

// NewByteArray 创建新的ByteArray, 默认大端序
func NewByteArray(bytes []byte) *ByteArray {
	var ba *ByteArray
	if len(bytes) > 0 {
		ba = &ByteArray{buf: bytes}
	} else {
		ba = &ByteArray{}
	}

	ba.endian = binary.BigEndian

	return ba
}

// Length 长度
func (ba *ByteArray) Length() int {
	return len(ba.buf)
}

// Available 可读长度
func (ba *ByteArray) Available() int {
	return ba.Length() - ba.posRead
}

// SetEndian 设置大小端序
func (ba *ByteArray) SetEndian(endian binary.ByteOrder) {
	ba.endian = endian
}

// GetEndian 取大小端序
func (ba *ByteArray) GetEndian() binary.ByteOrder {
	if ba.endian == nil {
		return ByteArrayEndian
	}
	return ba.endian
}

func (ba *ByteArray) grow(l int) {
	if l == 0 {
		return
	}
	space := len(ba.buf) - ba.posWrite
	if space >= l {
		return
	}

	needGrow := l - space
	bufGrow := make([]byte, needGrow)

	ba.buf = append(ba.buf, bufGrow...)
}

// SetWritePos 设置写位置
func (ba *ByteArray) SetWritePos(pos int) error {
	if pos > ba.Length() {
		ba.posWrite = ba.Length()
		return io.EOF
	}

	ba.posWrite = pos
	return nil
}

// SetWriteEnd 设置写位置到尾部
func (ba *ByteArray) SetWriteEnd() {
	ba.SetWritePos(ba.Length())
}

// GetWritePos 取写位置
func (ba *ByteArray) GetWritePos() int {
	return ba.posWrite
}

// SetReadPos 设置读位置
func (ba *ByteArray) SetReadPos(pos int) error {
	if pos > ba.Length() {
		ba.posRead = ba.Length()
		return io.EOF
	}

	ba.posRead = pos
	return nil
}

// SetReadEnd 设置读位置到尾部
func (ba *ByteArray) SetReadEnd() {
	ba.SetReadPos(ba.Length())
}

// GetReadPos 取读位置
func (ba *ByteArray) GetReadPos() int {
	return ba.posRead
}

// Seek 移动读写位置
func (ba *ByteArray) Seek(pos int) error {
	err := ba.SetWritePos(pos)
	ba.SetReadPos(pos)

	return err
}

// Reset 重置数据
func (ba *ByteArray) Reset() {
	ba.buf = []byte{}
	ba.Seek(0)
}

// Bytes 取内容字节集
func (ba *ByteArray) Bytes() []byte {
	return ba.buf
}

// BytesAvailable 取可读字节内容
func (ba *ByteArray) BytesAvailable() []byte {
	return ba.buf[ba.posRead:]
}

// Write 写数据
func (ba *ByteArray) Write(bytes []byte) (l int, err error) {
	len := len(bytes)
	if len <= 0 {
		return 0, nil
	}

	ba.grow(len)

	l = copy(ba.buf[ba.posWrite:], bytes)
	ba.posWrite += l

	return l, nil
}

// WriteBytes 写入字节集
func (ba *ByteArray) WriteBytes(bytes []byte) (l int, err error) {
	return ba.Write(bytes)
}

// WriteByte 写入byte
func (ba *ByteArray) WriteByte(v byte) {
	binary.Write(ba, ba.endian, &v)
}

// WriteInt8 写入int8
func (ba *ByteArray) WriteInt8(v int8) {
	binary.Write(ba, ba.endian, &v)
}

// WriteInt16 写入int16
func (ba *ByteArray) WriteInt16(v int16) {
	binary.Write(ba, ba.endian, &v)
}

// WriteUInt16 写入uint16
func (ba *ByteArray) WriteUInt16(v uint16) {
	binary.Write(ba, ba.endian, &v)
}

// WriteInt32 写入int32
func (ba *ByteArray) WriteInt32(v int32) {
	binary.Write(ba, ba.endian, &v)
}

// WriteUInt32 写入uint32
func (ba *ByteArray) WriteUInt32(v uint32) {
	binary.Write(ba, ba.endian, &v)
}

// WriteInt64 写入int64
func (ba *ByteArray) WriteInt64(v int64) {
	binary.Write(ba, ba.endian, &v)
}

// WriteUInt64 写入uint64
func (ba *ByteArray) WriteUInt64(v uint64) {
	binary.Write(ba, ba.endian, &v)
}

// WriteFloat32 写入float32
func (ba *ByteArray) WriteFloat32(v float32) {
	binary.Write(ba, ba.endian, &v)
}

// WriteFloat64 写入float64
func (ba *ByteArray) WriteFloat64(v float64) {
	binary.Write(ba, ba.endian, &v)
}

// WriteBool 写入bool
func (ba *ByteArray) WriteBool(v bool) {
	var b byte
	if v {
		b = 1
	} else {
		b = 0
	}

	ba.WriteByte(b)
}

// WriteString 写入字符串, 添加\0结束符
func (ba *ByteArray) WriteString(v string) {
	if v != "" {
		ba.WriteBytes([]byte(v))
	}
	ba.WriteByte(0)
}

// WriteUTF 写入utf8字符串
func (ba *ByteArray) WriteUTF(v string) {
	ba.WriteInt16(int16(len(v)))
	ba.WriteBytes([]byte(v))
}

// Read 读取数据
func (ba *ByteArray) Read(bytes []byte) (l int, err error) {
	if len(bytes) == 0 {
		return
	}
	if len(bytes) > ba.Length()-ba.posRead {
		return 0, io.EOF
	}
	l = copy(bytes, ba.buf[ba.posRead:])
	ba.posRead += l

	return l, nil
}

// ReadBytes 读取字节集
func (ba *ByteArray) ReadBytes(bytes []byte, length int, offset int) (l int, err error) {
	return ba.Read(bytes[offset : offset+length])
}

// ReadByte 读取byte
func (ba *ByteArray) ReadByte() (b byte, err error) {
	bytes := make([]byte, 1)
	_, err = ba.ReadBytes(bytes, 1, 0)

	if err == nil {
		b = bytes[0]
	}

	return
}

// ReadInt8 读取int8
func (ba *ByteArray) ReadInt8() (ret int8, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadInt16 读取int16
func (ba *ByteArray) ReadInt16() (ret int16, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadUInt16 读取uint16
func (ba *ByteArray) ReadUInt16() (ret uint16, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadInt32 读取int32
func (ba *ByteArray) ReadInt32() (ret int32, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadUInt32 读取uint32
func (ba *ByteArray) ReadUInt32() (ret uint32, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadInt64 读取int64
func (ba *ByteArray) ReadInt64() (ret int64, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadUInt64 读取uint64
func (ba *ByteArray) ReadUInt64() (ret uint64, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadFloat32 读取float32
func (ba *ByteArray) ReadFloat32() (ret float32, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadFloat64 读取float64
func (ba *ByteArray) ReadFloat64() (ret float64, err error) {
	err = binary.Read(ba, ba.endian, &ret)
	return
}

// ReadBool 读取bool
func (ba *ByteArray) ReadBool() (ret bool, err error) {
	var bb byte
	bb, err = ba.ReadByte()
	if err == nil {
		if bb == 1 {
			ret = true
		} else {
			ret = false
		}
	} else {
		ret = false
	}
	return
}

// ReadString 读取字符串
func (ba *ByteArray) ReadString() string {
	bytes := []byte{}
	for {
		b, err := ba.ReadByte()
		if err != nil || b == 0 {
			break
		}

		bytes = append(bytes, b)
	}

	return string(bytes)
}

func (ba *ByteArray) readStringEx(length int) (ret string, err error) {
	bytes := make([]byte, length)
	_, err = ba.ReadBytes(bytes, length, 0)
	if err == nil {
		ret = string(bytes)
	} else {
		ret = ""
	}
	return
}

// ReadUTF 读取utf8字符串
func (ba *ByteArray) ReadUTF() (ret string, err error) {
	var l int16
	l, err = ba.ReadInt16()

	if err != nil {
		return "", err
	}

	return ba.readStringEx(int(l))
}
