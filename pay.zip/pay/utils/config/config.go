package config

import (
	"io/ioutil"

	"gopkg.in/yaml.v2"
)

// 线路模式
const (
	LineTypeInternal = iota
	LineTypePublic
)

// Config 配置信息
type Config struct {
	Redis               RedisConfig    `yaml:"redis"`
	Node                NodeConfig     `yaml:"node"`
	App                 AppConfig      `yaml:"app"`
	Proxys              []*ProxyConfig `yaml:"proxys"`
	ServiceAddr         string         `yaml:"serviceaddr"`
	SyncInfoFile        string         `yaml:"syncinfofile"`
	DeviceService       string         `yaml:"deviceservice"`
	UseTLS              bool           `yaml:"usetls"`
	UseProxy            bool           `yaml:"useproxy"`
	UseLocalProxy       bool           `yaml:"uselocalproxy"`
	LocalProxyMode      int            `yaml:"localproxymode"`
	LocalProxyUserCount int            `yaml:"localproxyusercount"`
	ProxyLineType       int            `yaml:"proxylinetype"`
}

// RedisConfig 配置信息
type RedisConfig struct {
	DBHost  string `yaml:"host"`
	DBPass  string `yaml:"pass"`
	DBIndex int    `yaml:"dbidx"`
}

// NodeConfig 节点配置
type NodeConfig struct {
	GUID    string `yaml:"guid"`
	Name    string `yaml:"name"`
	AccType int    `yaml:"acctype"`
	MaxUser int    `yaml:"maxuser"`
	URL     string `yaml:"url"`
}

// AppConfig app配置
type AppConfig struct {
	AppID  string `yaml:"appid"`
	AppKey string `yaml:"appkey"`
	SecKey string `yaml:"seckey"`
}

// ProxyConfig 本地代理服务器配置
type ProxyConfig struct {
	PublicURI   string `yaml:"public"`
	InternalURI string `yaml:"internal"`
	UserName    string `yaml:"username"`
	Password    string `yaml:"password"`
}

var (
	cfg   = &Config{}
	debug = false
)

// NewConfig 从文件加载新的配置信息
func NewConfig(fileName string) (*Config, error) {
	data, err := ioutil.ReadFile(fileName)
	if err != nil {
		return nil, err
	}

	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, err
	}

	return cfg, nil
}

// GetRedisConfig 获取redis配置信息
func GetRedisConfig() *RedisConfig {
	return &cfg.Redis
}

// GetNodeConfig 获取node配置信息
func GetNodeConfig() *NodeConfig {
	return &cfg.Node
}

// GetAppConfig 取app配置信息
func GetAppConfig() *AppConfig {
	return &cfg.App
}

// GetProxyConfig 取本地代理服务器配置
func GetProxyConfig() []*ProxyConfig {
	return cfg.Proxys
}

// SetDebug 设置是否调试模式
func SetDebug(v bool) {
	debug = v
}

// IsDebug 是否调试模式
func IsDebug() bool {
	return debug
}

// IsUseTLS 是否启用tls模式
func IsUseTLS() bool {
	return cfg.UseTLS
}

// IsUseProxy 是否启用代理服务器
func IsUseProxy() bool {
	return cfg.UseProxy
}

// IsUseLocalProxy 是否使用本地代理配置
func IsUseLocalProxy() bool {
	return cfg.UseLocalProxy
}

// GetLocalProxyMode 取本地代理使用模式
func GetLocalProxyMode() int {
	return cfg.LocalProxyMode
}

// GetLocalProxyUserCount 取本地代理每个ip允许帐号数量
func GetLocalProxyUserCount() int {
	return cfg.LocalProxyUserCount
}

// GetProxyLineType 取代理线路模式
func GetProxyLineType() int {
	return cfg.ProxyLineType
}
