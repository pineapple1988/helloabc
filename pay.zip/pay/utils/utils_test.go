package utils

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"math/rand"
	"testing"
	"time"
)

func TestNewUUID(t *testing.T) {
	for i := 0; i < 10; i++ {
		uuid, err := NewUUID(i%2 != 0)
		if err != nil {
			t.Fatalf("生成UUID错误: %+v.", err)
		}

		fmt.Println(uuid)
	}
}

func TestNewRandString(t *testing.T) {
	for i := 0; i < 10; i++ {
		fmt.Println(NewRandString(10, false))
	}
}

func TestNewMacAddress(t *testing.T) {
	for i := 0; i < 10; i++ {
		fmt.Println(NewMacAddress())
	}
}

func TestPKCS7Padding(t *testing.T) {
	buffer := []byte{1, 2, 3, 4, 5, 6}
	buffer = PKCS7Padding(buffer, 16)
	fmt.Println(buffer)

	buffer, err := PKCS7Trimming(buffer)
	if err != nil {
		t.Fatal(err)
	}
	fmt.Println(buffer)
}

func TestAESEncDec(t *testing.T) {
	key := []byte{0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c}
	iv := []byte{0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f}
	in := []byte{
		0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a,
		0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03, 0xac, 0x9c, 0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51,
		0x30, 0xc8, 0x1c, 0x46, 0xa3, 0x5c, 0xe4, 0x11, 0xe5, 0xfb, 0xc1, 0x19, 0x1a, 0x0a, 0x52, 0xef,
		0xf6, 0x9f, 0x24, 0x45, 0xdf, 0x4f, 0x9b, 0x17, 0xad, 0x2b, 0x41, 0x7b, 0xe6, 0x6c, 0x37, 0x10,
	}

	out := []byte{
		0x76, 0x49, 0xab, 0xac, 0x81, 0x19, 0xb2, 0x46, 0xce, 0xe9, 0x8e, 0x9b, 0x12, 0xe9, 0x19, 0x7d,
		0x50, 0x86, 0xcb, 0x9b, 0x50, 0x72, 0x19, 0xee, 0x95, 0xdb, 0x11, 0x3a, 0x91, 0x76, 0x78, 0xb2,
		0x73, 0xbe, 0xd6, 0xb8, 0xe3, 0xc1, 0x74, 0x3b, 0x71, 0x16, 0xe6, 0x9e, 0x22, 0x22, 0x95, 0x16,
		0x3f, 0xf1, 0xca, 0xa1, 0x68, 0x1f, 0xac, 0x09, 0x12, 0x0e, 0xca, 0x30, 0x75, 0x86, 0xe1, 0xa7,
	}

	enc, err := AESCBCEncrypt(in, key, iv)
	if err != nil {
		t.Fatalf("加密错误: %+v", err)
	}

	for i := 0; i < len(out); i++ {
		if enc[i] != out[i] {
			fmt.Println(enc)
			fmt.Println(out)
			t.Fatalf("加密数据校验失败.")
		}
	}

	dec, err := AESCBCDecrypt(enc, key, iv)
	if err != nil {
		t.Fatalf("解密错误: %+v.", err)
	}

	if !bytes.Equal(dec, in) {
		fmt.Println(dec)
		fmt.Println(in)
		t.Fatal("解密数据校验失败.")
	}
}

func Test3DESEncDec(t *testing.T) {





	key := []byte{
		0x56, 0x7B, 0x58, 0xA4, 0x9A, 0xDC, 0xDF, 0x0E, 0xDB, 0x1A, 0x41, 0x03, 0x42, 0x6E, 0x23, 0x86,
		0x61, 0x1F, 0x23, 0x71, 0x75, 0x18, 0x3F, 0x4A}
	iv := []byte{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}
	in := []byte{0xE5, 0x86, 0xAF, 0xE4, 0xBC, 0x9F}
	out := []byte{0x53, 0x40, 0x51, 0x24, 0xd8, 0x3c, 0xf9, 0x88}

	enc, err := TripleDESCBCEncrypt(in, key, iv)
	if err != nil {
		t.Fatalf("加密错误: %+v", err)
	}

	for i := 0; i < len(out); i++ {
		if enc[i] != out[i] {
			fmt.Println(base64.StdEncoding.EncodeToString(enc))
			fmt.Println(out)
			t.Fatalf("加密数据校验失败.")
		}
	}

	dec, err := TripleDESCBCDecrypt(enc, key, iv)
	if err != nil {
		t.Fatalf("解密错误: %+v.", err)
	}

	if !bytes.Equal(dec, in) {
		fmt.Println(dec)
		fmt.Println(in)
		t.Fatal("解密数据校验失败.")
	}
}

func TestReverseSlice(t *testing.T) {
	arr1 := []byte{1, 2, 3, 4, 5, 6}
	arr2 := []int{1, 2, 3, 4, 5, 6}
	arr3 := []string{"1", "2", "3", "4", "5", "6"}

	ReverseSlice(arr1)
	ReverseSlice(arr2)
	ReverseSlice(arr3)

	fmt.Println(arr1)
	fmt.Println(arr2)
	fmt.Println(arr3)
	fmt.Println(nil)
}

func TestMD5(t *testing.T) {
	md5 := "e10adc3949ba59abbe56e057f20f883e"
	str := MD5String("123456")
	if str != md5 {
		t.Fatalf("MD5String失败, 正确值: %+v, 算法值:%+v.", md5, str)
	}

	str = MD5Buffer([]byte{0x31, 0x32, 0x33, 0x34, 0x35, 0x36})
	if str != md5 {
		t.Fatalf("MD5Buffer失败, 正确值: %+v, 算法值:%+v.", md5, str)
	}
}

func TestGetTimeStamp(t *testing.T) {
	fmt.Printf("GetTimeStamp: %+v.\n", GetTimeStamp())
	fmt.Printf("GetTimeStampEx: %+v.\n", GetTimeStampEx())
}

func TestZlib(t *testing.T) {
	data := "test compress data."
	arr, err := ZLibCompress([]byte(data))
	if err != nil {
		t.Fatalf("压缩数据失败, 错误: %+v.", err)
	}

	fmt.Println(arr)

	arr, err = ZLibUncompress(arr)
	if err != nil {
		t.Fatalf("解压数据失败, 错误: %+v.", err)
	}

	if string(arr) != data {
		t.Fatalf("解压数据校验失败, 原始数据: %+v, 解压数据: %+v.", data, string(arr))
	}
}

func TestTimeStr(t *testing.T) {
	fmt.Println(GetTimeStr())
	fmt.Println(GetTimeStrEx())
}

func TestAndroidDevice(t *testing.T) {
	rand.Seed(time.Now().Unix())
	for i := 0; i < 10; i++ {
		fmt.Println(GetAndroidDevice())
	}
}
