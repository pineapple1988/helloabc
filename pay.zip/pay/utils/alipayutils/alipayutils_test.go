package alipayutils

import (
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/url"
	"pay/utils"
	"testing"
	"time"

	"golang.org/x/net/proxy"
)

func TestGenerateUTDID(t *testing.T) {
	for i := 0; i < 10; i++ {
		fmt.Println(NewUTDID("d6fc3a4a06adbde89223bvefedc24fecde188aaa9161"))
	}
}

func TestC10To64(t *testing.T) {
	for i := 0; i < 100; i++ {
		j := int64(utils.RandInt(100000, 0x7FFFFFFF))
		str := C10To64(j)
		fmt.Println(j, "==>", str)
		k := C64To10(str)
		if k != j {
			t.Fatalf("C10To64测试失败, 原始值: %+v, 转换值: %+v, 还原值: %+v.",
				j, str, k)
		}
	}
}

func TestSOCKS5(t *testing.T) {
	dialer, err := proxy.SOCKS5("tcp", "127.0.0.1:8080", &proxy.Auth{User: "user", Password: "pass"}, &net.Dialer{Timeout: time.Second * 2})
	if err != nil {
		t.Fatalf("代理连接失败: %+v.", err)
	}

	httpTransport := &http.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
		},
		TLSHandshakeTimeout: time.Second * 3,
	}
	httpClient := &http.Client{Transport: httpTransport}
	// set our socks5 as the dialer
	httpTransport.Dial = dialer.Dial
	if resp, err := httpClient.Get("https://www.google.com"); err != nil {
		log.Fatalln(err)
	} else {
		defer resp.Body.Close()
		body, _ := ioutil.ReadAll(resp.Body)
		fmt.Printf("%s\n", body)
	}

}

func TestSerialize(t *testing.T) {
	for i := 0; i < 1000000; i++ {
		n := utils.RandIntn(260000000)
		buf := SerializeLen(int32(n))
		x, k := DeserializeLen(buf, 0)
		if k == 0 {
			t.Errorf("反序列化失败, n: %+v, buf: %+v.", n, buf)
			break
		}

		if x != int32(n) {
			t.Errorf("反序列化后结果不正确, 原始值: %+v, 序列化数据: %+v, 反序列化值: %+v.", n, buf, x)
			break
		}

		//t.Logf("%+v==>%+v==>%+v.", n, buf, x)
	}

	// SerializeLen1(128)
	//SerializeLen(128)
}

func TestSerialize1(t *testing.T) {
	//buf := []byte{144, 2, 11, 16, 4, 8, 14, 32}
	buf := []byte{144, 8, 152, 104, 24, 1, 32, 1, 56, 2, 64, 18, 31, 139, 8, 0, 0, 0, 0, 0, 0}

	x, k := DeserializeLen(buf, 1)
	if k == 0 {
		t.Errorf("反序列化失败, n: %+v, buf: %+v.", k, buf)
	}

	fmt.Println(x)

	x, k = DeserializeLen(buf, 1+k)
	if k == 0 {
		t.Errorf("反序列化失败, n: %+v, buf: %+v.", k, buf)
	}

	fmt.Println(x)
}

func Test(t *testing.T) {
	v := url.QueryEscape("支付宝")
	fmt.Println(v)

	fmt.Println(`{"32":{"2":{"22":"1.0.0","1":"1.0.0","23":"0xFFFFFFFF"},"0":{}},`)
}
