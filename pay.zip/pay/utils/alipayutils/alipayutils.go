package alipayutils

import (
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"math"
	"pay/cport"
	"pay/utils"
)

// NewUTDID 新建随机UTDID
func NewUTDID(key string) (string, error) {
	ts := utils.GetTimeStamp()
	r := utils.RandInt(0x10000000, 0x7FFFFFFF)
	uuid, err := utils.NewUUID(true)
	if err != nil {
		return "", err
	}
	hc := HashCode(uuid)

	ba := utils.NewByteArray(nil)
	ba.WriteInt32(int32(ts))
	ba.WriteInt32(int32(r))
	ba.WriteByte(3)
	ba.WriteByte(0)
	ba.WriteUInt32(hc)

	hmac := HMACBase64Value(ba.Bytes(), key)
	ba.WriteUInt32(HashCode(hmac))

	return base64.StdEncoding.EncodeToString(ba.Bytes()), nil
}

// HashCode 计算字符串的hashcode
func HashCode(str string) uint32 {
	if str == "" {
		return 0
	}

	b := []byte(str)
	var r uint32
	for i := 0; i < len(b); i++ {
		r = uint32(b[i]) + 31*r
	}

	return r
}

// HMACBase64Value 计算hmac值
func HMACBase64Value(in []byte, key string) string {
	h := hmac.New(sha1.New, []byte(key))
	h.Write(in)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

/*
func SerializeLen(len int) []byte {
	ba := utils.NewByteArray([]byte{})
	a1 := len & 0x7F
	a2 := 2 * len & 0x7F00
	a3 := 4 * len & 0x7F0000
	a4 := len & 0xFE00000

	if a4 > 0 {
		ba.WriteByte(byte((len >> 21) | 0x80))
		ba.WriteByte(byte((a3 >> 16) | 0x80))
		ba.WriteByte(byte((a2 >> 8) | 0x80))
		ba.WriteByte(byte(a1))
	} else if a3 > 0 {
		ba.WriteByte(byte((a3 >> 16) | 0x80))
		ba.WriteByte(byte((a2 >> 8) | 0x80))
		ba.WriteByte(byte(a1))
	} else if a2 > 0 {
		ba.WriteByte(byte((a2 >> 8) | 0x80))
		ba.WriteByte(byte(a1))
	} else if a1 > 0 {
		ba.WriteByte(byte(a1))
	} else {
		ba.WriteByte(0)
	}

	return ba.Bytes()
}
*/

// SerializeLen 序列化长度
func SerializeLen(x int32) []byte {
	buf := []byte{}
	if x > 127 {
		b := false
		for n := uint32(21); n > 0; n -= 7 {
			k := (x >> n) & 0x7F
			if k != 0 || b {
				buf = append(buf, uint8(k|0x80))
				b = true
			}
		}
	}

	buf = append(buf, byte(x&0x7f))

	return buf
}

/*
func DeserializeLen(ba *utils.ByteArray) uint {
	var len uint
	if ba == nil || ba.Available() == 0 {
		return 0
	}

	a1, _ := ba.ReadByte()
	if a1 > 0x80 {
		a2, _ := ba.ReadByte()
		if a2 > 0x80 {
			a3, _ := ba.ReadByte()
			if a3 > 0x80 {
				a4, _ := ba.ReadByte()
				//len = uint(a4) | (uint(a3&0x7f) << 7) | (uint(a2&0x7F)<<14)&0xFFFFC07F | (uint(a1&0x7F)<<21)&0xFFE03FFF
				len = uint(a4) | (uint(a3&0x7f) << 7) | (uint(a2&0x7F) << 14) | (uint(a1&0x7F) << 21)
			} else {
				//len = uint(a3) | (uint(a2&0x7f) << 7) | (uint(a1&0x7F)<<14)&0xFFFFC07F
				len = uint(a3) | (uint(a2&0x7f) << 7) | (uint(a1&0x7F) << 14)
			}
		} else {
			len = uint(a2) | (uint(a1&0x7F) << 7)
		}
	} else {
		len = uint(a1)
	}

	return len
}
*/

// DeserializeLen 反序列化长度
func DeserializeLen(buf []byte, pos int) (x int32, n int) {
	for shift := 0; shift < 4; shift++ {
		if (n + pos) >= len(buf) {
			return 0, 0
		}
		b := int32(buf[n+pos])
		n++
		x = (x << 7) | (b & 0x7F)
		if (b & 0x80) == 0 {
			return x, n
		}
	}

	return 0, 0
}

// C10To64 值转字符串
func C10To64(value int64) string {
	str := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")
	arr := []byte{}

	for value > 0 {
		arr = append(arr, str[value&0x3F])
		value >>= 6
	}

	utils.ReverseSlice(arr)
	return string(arr)
}

// C64To10 字符串转值
func C64To10(value string) int64 {
	if value == "" {
		return 0
	}

	str := []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")
	r := int64(0)
	arr := []byte(value)
	c := 0
	l := len(arr)
	var i int64
	for c < len(arr) {
		i = 0
		for arr[c] != str[i] {
			i++
			if i >= 64 {
				return r
			}
		}
		l--
		r = r + int64(math.Pow(64, float64(l)))*i
		c++
	}

	return r
}

// MiniwuaEncrypt miniwua字符串加密
func MiniwuaEncrypt(str string, key, iv []byte) (string, error) {
	arr, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		return "", err
	}

	buf := []byte{0x13, 0x7F, 0x40, 0x24, 0x00}
	buf[0] = byte(utils.RandInt(0x10, 0xFF))
	buf[1] = byte(utils.RandInt(0x10, 0xFF))

	buf = append(buf, arr...)
	arr = []byte{0x8A, 0x16, 0x00, 0x44, 0x22, 0x80}
	buf = append(buf, arr...)

	idx := 0
	for i := 5; i < len(buf); i++ {
		buf[i] ^= buf[idx]
		idx ^= 1
	}

	b := []byte{0, 0, 0, 1}
	b = append(b, buf...)

	d, err := utils.AESCBCEncrypt(b, key, iv)
	if err != nil {
		return "", err
	}

	return "HHnB_" + base64.StdEncoding.EncodeToString(d), nil
}

// NotString 字符串转byte
func NotString(inStr string) []byte {
	out := make([]byte, len(inStr))
	for k, v := range inStr {
		out[k] = (byte)(0x100 - v)
	}
	return out
}

// PasswordEncrypt 密码加密
func PasswordEncrypt(password string, key []byte) (string, error) {
	in := []byte(password)
	buf, err := utils.RSAEncrypt(in, key)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(buf), nil
}

// PayPasswordEncrypt 支付密码加密
func PayPasswordEncrypt(payPassword, payTS string, key []byte) (string, error) {
	in := []byte(payPassword + payTS)
	buf, err := utils.RSAEncrypt(in, key)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(buf), nil
}

// EncryptAndSign 加密并签名
func EncryptAndSign(in, key []byte) string {
	arr := cport.EncryptAndSign(in)
	h := hmac.New(sha1.New, key)
	h.Write(in)
	return string(arr) + fmt.Sprintf("%x", h.Sum(nil))
}

// CFStringHash 字符串hash
func CFStringHash(str string) uint64 {
	return cport.CFStringHash(str)
}
