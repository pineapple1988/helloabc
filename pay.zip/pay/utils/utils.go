package utils

import (
	"bytes"
	"compress/gzip"
	"compress/zlib"
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"crypto/md5"
	r "crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"math/big"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"pay/utils/logger"
	"reflect"
	"strconv"
	"strings"
	"time"

	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"

	uuid "github.com/satori/go.uuid"
)

const (
	// RSA的默认E
	defaultExponent   = 65537
	passwordEncDecKey = "2058e79e66539be9"
	passwordEncDecIV  = "8a6f2805b4515ac1"
)

var (
	errWrongDataSize = errors.New("错误的数据大小")
	errWrongIVSize   = errors.New("错误的向量大小")
	errWrongNumber   = errors.New("错误的数值")
	errPKCS7Trimming = errors.New("PKCS7去除填充失败")
)

var (
	rnd         *rand.Rand
	rndBytes    []byte
	rndBytesLen int
)

func init() {
	rnd = rand.New(rand.NewSource(time.Now().UnixNano()))
	rndBytes = []byte("0123456789abcdefghijklmnopqrstuvwsyz")
	rndBytesLen = len(rndBytes)
}

// NewUUID 生成一个新的UUID
func NewUUID(upper bool) (string, error) {
	uuid, err := uuid.NewV4()
	if err != nil {
		return "", err
	}

	str := uuid.String()
	if upper {
		str = strings.ToUpper(str)
	}

	return str, nil
}

// NewUUID1 生成一个新的UUID1
func NewUUID1(upper bool) string {
	uuid, err := uuid.NewV4()
	if err != nil {
		return ""
	}

	str := uuid.String()
	if upper {
		str = strings.ToUpper(str)
	}

	return str
}

// NewRandString 生成一个新的随机字符串
func NewRandString(cnt int, upper bool) string {
	buffer := []byte{}
	for i := 0; i < cnt; i++ {
		buffer = append(buffer, rndBytes[rnd.Intn(rndBytesLen)])
	}

	str := string(buffer)
	if upper {
		str = strings.ToUpper(str)
	}

	return str
}

// NewMacAddress 生成一个新的随机mac地址
func NewMacAddress() string {
	arr := []string{}
	for i := 0; i < 6; i++ {
		n := rnd.Intn(255)
		if i == 0 && n%2 != 0 {
			n++
		}

		arr = append(arr, fmt.Sprintf("%.2x", n))
	}

	return strings.Join(arr, ":")
}

// NewCarrierName 生成随机运营商
func NewCarrierName() string {
	carrierName := []string{"中国移动", "中国联通", "中国电信"}
	return carrierName[RandIntn(len(carrierName))]
}

// RandIntn 生成一个0~n的随机数
func RandIntn(n int) int {
	return rnd.Intn(n)
}

// RandInt 生成min~max区间的随机数
func RandInt(min, max int) int {
	if min > max || min == 0 || max == 0 {
		return 0
	}

	return rnd.Intn(max-min) + min
}

// PKCS7Padding PKCS7填充
func PKCS7Padding(in []byte, blockSize int) []byte {
	padding := blockSize - len(in)%blockSize
	if padding == 0 {
		padding = blockSize
	}

	buffer := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(in, buffer...)
}

// PKCS7Trimming PKCS7去除填充
func PKCS7Trimming(in []byte) ([]byte, error) {
	if len(in) <= 0 {
		return nil, errPKCS7Trimming
	}

	padding := in[len(in)-1]
	if int(padding) > len(in) {
		return nil, errPKCS7Trimming
	}
	return in[:len(in)-int(padding)], nil
}

// AESECBEncrypt AESEBC加密, 使用PKCS7填充
func AESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = PKCS7Padding(in, c.BlockSize())

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)
		out = append(out, dst...)
	}

	return out, nil
}

// AESECBDecrypt AESEBC解密, 并去除PKCS7填充
func AESECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)
		out = append(out, dst...)
	}

	return PKCS7Trimming(out)
}

// AESCBCEncrypt AESCBC加密, 使用PKCS7填充
func AESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	in = PKCS7Padding(in, c.BlockSize())
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// AESCBCDecrypt AESCBC解密, 并去除PKCS7填充
func AESCBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	out, err = PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// TripleDESECBEncrypt 3DESECB加密, 使用PKCS7填充
func TripleDESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	in = PKCS7Padding(in, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

// TripleDESECBDecrypt 3DESECB解密, 并去除PKCS7填充
func TripleDESECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	out, err = PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// TripleDESCBCEncrypt 3DESCBC加密, 使用PKCS7填充
func TripleDESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	in = PKCS7Padding(in, c.BlockSize())
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// TripleDESCBCDecrypt 3DESCBC解密, 并去除PKCS7填充
func TripleDESCBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	out, err = PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// DESCBCEncrypt DESCBC加密, 使用PKCS7填充
func DESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	in = PKCS7Padding(in, c.BlockSize())
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// DESCBCDecrypt DESCBC解密, 并去除PKCS7填充
func DESCBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	out, err = PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// PublicKeyFromBytes 通过字节集生成公钥, e为0时默认使用65537
func PublicKeyFromBytes(n []byte, e int) *rsa.PublicKey {
	if e == 0 {
		e = defaultExponent
	}

	return &rsa.PublicKey{
		N: new(big.Int).SetBytes(n),
		E: e,
	}
}

// PublicKeyFromString 通过字符串生成公钥, e为0时默认使用65537
func PublicKeyFromString(n string, e int, base int) (*rsa.PublicKey, error) {
	i, ok := new(big.Int).SetString(n, base)
	if !ok {
		return nil, errWrongNumber
	}

	if e == 0 {
		e = defaultExponent
	}

	return &rsa.PublicKey{
		N: i,
		E: e,
	}, nil
}

// RSAEncryptPKCS1v15 RSA加密, 并用PKCS1, V1.5填充
func RSAEncryptPKCS1v15(in []byte, key *rsa.PublicKey) ([]byte, error) {
	k := ((key.N.BitLen() + 7) / 8) - 11
	data := []byte{}

	for {
		if len(in) > k {
			arr := in[:k]
			arr, err := rsa.EncryptPKCS1v15(r.Reader, key, arr)

			if err != nil {
				return nil, err
			}

			data = append(data, arr...)
			in = in[k:]
		} else {
			arr, err := rsa.EncryptPKCS1v15(r.Reader, key, in)
			if err != nil {
				return nil, err
			}

			data = append(data, arr...)

			break
		}
	}

	return data, nil
}

// RSAEncrypt RSA加密
func RSAEncrypt(in []byte, key []byte) ([]byte, error) {
	pub := PublicKeyFromBytes(key, 65537)
	return RSAEncryptPKCS1v15(in, pub)
}

// ReverseSlice 反转切片
func ReverseSlice(s interface{}) {
	size := reflect.ValueOf(s).Len()
	if size <= 0 {
		return
	}

	swap := reflect.Swapper(s)
	for i, j := 0, size-1; i < j; i, j = i+1, j-1 {
		swap(i, j)
	}
}

// MD5Buffer 计算字节集的md5值
func MD5Buffer(b []byte) string {
	h := md5.New()
	_, err := h.Write(b)
	if err != nil {
		return ""
	}

	return fmt.Sprintf("%x", h.Sum(nil))
}

// MD5String 计算字符串的md5值
func MD5String(s string) string {
	return MD5Buffer([]byte(s))
}

// ZLibCompress zlib压缩数据
func ZLibCompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	w := zlib.NewWriter(&out)
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

//byte数组拷贝
func BlockCopy(src []byte, srcOffset int, dst []byte, dstOffset, count int) (bool, error) {
	srcLen := len(src)
	if srcOffset > srcLen || count > srcLen || srcOffset+count > srcLen {
		return false, errors.New("源缓冲区 索引超出范围")
	}
	dstLen := len(dst)
	if dstOffset > dstLen || count > dstLen || dstOffset+count > dstLen {
		return false, errors.New("目标缓冲区 索引超出范围")
	}
	index := 0
	for i := srcOffset; i < srcOffset+count; i++ {
		dst[dstOffset+index] = src[srcOffset+index]
		index++
	}
	return true, nil
}
// ZLibUncompress zlib解压数据
func ZLibUncompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	r, err := zlib.NewReader(bytes.NewReader(in))
	if err != nil {
		return nil, err
	}

	if _, err := io.Copy(&out, r); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// GZipCompress gzip压缩数据
func GZipCompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	w := gzip.NewWriter(&out)
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// GZipUncompress gzip解压数据
func GZipUncompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	r, err := gzip.NewReader(bytes.NewBuffer(in))
	if err != nil {
		return nil, err
	}

	if _, err := io.Copy(&out, r); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// GetTimeStamp 取时间戳, 秒级
func GetTimeStamp() uint {
	return uint(time.Now().Unix())
}

// GetTimeStampEx 取时间戳, 毫秒级
func GetTimeStampEx() int64 {
	return int64(time.Now().UnixNano() / 1000000)
}

// GetTimeStr 取时间字符串, 到秒
func GetTimeStr() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

//GetDateStr 取日期字符串
func GetDateStr() string {
	t := time.Now()
	return fmt.Sprintf("%.4d-%.2d-%.2d",
		t.Year(), t.Month(), t.Day(),
	)
}

//GetDateStr1 取日期字符串，没有符号
func GetDateStr1() string {
	t := time.Now()
	return fmt.Sprintf("%.4d%.2d%.2d",
		t.Year(), t.Month(), t.Day())
}

// GetTimeStrEx 取时间字符串, 到毫秒
func GetTimeStrEx() string {
	t := time.Now()
	return fmt.Sprintf("%.4d-%.2d-%.2d %.2d:%.2d:%.2d:%.3d",
		t.Year(), t.Month(), t.Day(),
		t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000000)
}

// GetTimeDateStrEx 取时间日期
func GetTimeDateStrEx() string {
	t := time.Now()
	return fmt.Sprintf("%.4d-%.2d-%.2d",
		t.Year(), t.Month(), t.Day())
}

//GetTimeTimeStrEx 取时间当前时间
func GetTimeTimeStrEx() string {
	t := time.Now()
	return fmt.Sprintf("%.2d:%.2d:%.2d:%.3d",
		t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000000)
}

// GetTimeStrEx1 取时间字符串, 到毫秒没有符号
func GetTimeStrEx1() string {
	t := time.Now()
	return fmt.Sprintf("%.4d%.2d%.2d%.2d%.2d%.2d%.3d",
		t.Year(), t.Month(), t.Day(),
		t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000000)
}

// URLEncode URL编码
func URLEncode(v string) string {
	return url.QueryEscape(v)
}

// URLDecode URL解码
func URLDecode(v string) string {
	str, err := url.QueryUnescape(v)
	if err != nil {
		return v
	}

	return str
}

// PasswordEncrypt 密码加密
func PasswordEncrypt(pass string) string {
	in := []byte(pass)
	key := []byte(passwordEncDecKey)
	iv := []byte(passwordEncDecIV)

	data, err := AESCBCEncrypt(in, key, iv)
	if err != nil {
		return pass
	}

	return base64.StdEncoding.EncodeToString(data)
}

// PasswordDecrypt 密码解密
func PasswordDecrypt(pass string) string {
	in, err := base64.StdEncoding.DecodeString(pass)
	if err != nil {
		return pass
	}

	key := []byte(passwordEncDecKey)
	iv := []byte(passwordEncDecIV)

	data, err := AESCBCDecrypt(in, key, iv)
	if err != nil {
		return pass
	}

	return string(data)
}

// GetLocalIPAddress 取本地ip地址
func GetLocalIPAddress() string {
	netInterfaces, err := net.Interfaces()
	if err != nil {
		return "127.0.0.1"
	}

	for i := 0; i < len(netInterfaces); i++ {
		if (netInterfaces[i].Flags & net.FlagUp) != 0 {
			addrs, _ := netInterfaces[i].Addrs()
			for _, address := range addrs {
				if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
					return ipnet.IP.String()
				}
			}
		}
	}

	return "127.0.0.1"
}

// NewLocalIPAddress 生成一个随机本地ip地址
func NewLocalIPAddress() string {
	return fmt.Sprintf("192.168.%d.%d", RandInt(1, 20), RandInt(1, 254))
}

// GBK2UTF8 将gbk编码转成utf-8编码
func GBK2UTF8(s []byte) ([]byte, error) {
	t := transform.NewReader(bytes.NewReader(s), simplifiedchinese.GBK.NewDecoder())
	d, err := ioutil.ReadAll(t)
	if err != nil {
		return nil, err
	}

	return d, nil
}

// HTTPGetBody 取http响应数据
func HTTPGetBody(resp *http.Response) (string, error) {
	// http状态码
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("提交数据响应错误, 状态码: %d", resp.StatusCode)
	}

	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		var err error
		if body, err = gzip.NewReader(body); err != nil {
			return "", err
		}
	}

	data, err := ioutil.ReadAll(body)
	if err != nil {
		return "", err
	}

	// 如果有gbk编码转成utf8
	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "GBK") || strings.Contains(ct, "gbk") {
		var err error
		if data, err = GBK2UTF8(data); err != nil {
			return "", err
		}
	}

	return string(data), nil
}

// DoHTTP 进行http操作
func DoHTTP(c *http.Client, req *http.Request) (string, error) {
	if c == nil {
		return "", errors.New("http客户端为空")
	}

	if req == nil {
		return "", errors.New("http请求为空")
	}

	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()

	return HTTPGetBody(resp)
}

// Bytes2String 字节数组转换为字符串, 去掉未尾的0
func Bytes2String(buf []byte) string {
	if buf == nil || len(buf) < 1 {
		return ""
	}

	for i := len(buf) - 1; i > 0; i-- {
		if buf[i] != 0 {
			return string(buf[:i+1])
		}
	}

	return ""
}

// ReplaceWhiteSpace 替换掉空白字符
func ReplaceWhiteSpace(str string) string {
	str = strings.ReplaceAll(str, "\n", "")
	str = strings.ReplaceAll(str, "\t", "")
	str = strings.ReplaceAll(str, " ", "")
	return str
}



func Exist(path string) bool {
	_, err := os.Stat(path)
	if err != nil && os.IsNotExist(err) {
		return false
	}
	return true
}

func LoadJsonFromFile(path string, v interface{}) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		logger.Errorf("LoadJsonFromFile ioutil.ReadFile err %+v.", err)
	}

	if err = json.Unmarshal(data, v); err != nil {
		logger.Errorf("LoadJsonFromFile json.Unmarshal err %+v.", err)
	}
}

func SaveJson2File(path string, v interface{}) {
	infoBytes, err := json.MarshalIndent(v, "", "\t")
	if err != nil {
		logger.Errorf("SaveJson2File json.MarshalIndent err %+v.", err)
	}

	err = ioutil.WriteFile(path, infoBytes, 0644)
	if err != nil {
		logger.Errorf("SaveJson2File ioutil.WriteFile err %+v.", err)
	}
}


//float32 转 String工具类，保留6位小数
func FloatToString(input_num float32) string {
	// to convert a float number to a string
	return strconv.FormatFloat(float64(input_num), 'f', 6, 64)

}
