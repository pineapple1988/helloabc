package utils

import "math/rand"

var (
	androidDeviceArray = [][]string{
		{"Nexus 4", "5.1.1", "occam"},
		{"Nexus 5", "6.0.1", "hammerhead"},
		{"Nexus 5X", "8.1.0", "bullhead"},
		{"Nexus 6", "8.1.0", "angler"},
		{"Nexus 6P", "8.1.0", "angler"},
		{"Nexus 9 WiFi", "7.1.1", "volantis"},
		{"Nexus 9 LTE", "7.1.1", "volantisg"},
		{"Nexus 10", "5.1.1", "mantaray"},
		{"Pixel", "8.1.0", "sailfish"},
		{"Pixel XL", "8.1.0", "marlin"},
		{"Pixel 2", "8.1.0", "walleye"},
		{"Pixel 2 XL", "8.1.0", "taimen"},
		{"Pixel 3", "9", "blueline"},
		{"Pixel 3 XL", "9", "crosshatch"},
		{"Honor 6X", "8.0.0", "BLN-AL10"},
		{"Honor 8X", "8.1.0", "JSN-L21RU"},
		{"Honor 9", "8.0.0", "STF-L09"},
		{"Mate 10", "8.0.0", "ALP-L29"},
		{"Mate 10 Pro", "8.0.0", "BLA-L29"},
		{"Mate 20 Pro", "9", "LYA-L29"},
		{"P8 Lite", "8.0.0", "PRA-LX1"},
		{"P9 Lite", "7.0", "VNS-L31"},
		{"P9 Plus", "7.0", "VIE-L09"},
		{"P20", "9", "EML-L29"},
		{"P20 Lite", "8.0.0", "ANE-LX1"},
		{"P20 Pro", "8.1.0", "CLT-L29"},
		{"Mi 8", "8.1.0", "dipper"},
		{"Mi 9T", "9", "davinci_eea"},
		{"Mi A2", "8.1.0", "jasmine"},
		{"Mi Max", "6.0.1", "helium"},
		{"Mi Max 2", "7.1.1", "oxygen"},
		{"Mi Max 3", "9", "nitrogen"},
		{"Mi Mix 2S", "8.0.0", "polaris"},
		{"Mi Note 2", "7.0", "scorpio"},
		{"Mi Note 3", "8.1.0", "jason"},
		{"Redmi Go", "8.1.0", "tiare"},
		{"Redmi K20 Pro", "9", "raphael"},
		{"Redmi Note 5 Pro", "8.1.0", "whyred"},
		{"Redmi Note 7 Pro", "9", "violet"},
	}
)

// GetAndroidDevice 取安卓设备
// 返回型号, 版本, 内部名称
func GetAndroidDevice() (string, string, string) {
	n := len(androidDeviceArray)
	arr := androidDeviceArray[rand.Intn(n)]

	return arr[0], arr[1], arr[2]
}
