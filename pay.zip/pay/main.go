package main

import (
	"flag"
	"os"
	"os/signal"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/autologinmgr"
	"pay/mgr/syncmgr"
	"pay/service"
	"pay/utils/config"
	"pay/utils/logger"
	"syscall"

	"github.com/json-iterator/go/extra"
)

var (
	logDir      = flag.String("logdir", "./log", "指定日志输出目录.")
	cfgFileName = flag.String("cfg", "./config.yml", "指定应用的配置文件名.")
	debug       = flag.Bool("debug", false, "以调试模式启动应用.")
	help        = flag.Bool("help", false, "显示帮助信息.")
)

func init() {
	extra.RegisterFuzzyDecoders()
}

func main() {
	flag.Parse()

	if *help {
		flag.Usage()
		return
	}

	logger.SetDir(*logDir)

	if *debug {
		logger.SetDebug()
		config.SetDebug(true)
		logger.Info("[main]以调试模式启动应用.")
	}

	logger.Infof("[main]以配置文件[%+v]启动应用.", *cfgFileName)

	// 加载配置文件
	cfg, err := config.NewConfig(*cfgFileName)
	if err != nil {
		logger.Errorf("[main]加载配置文件[%+v]失败.", *cfgFileName)
		return
	}
	logger.Info("[main]加载配置文件成功.")

	// 连接缓存服务
	if err := redis.InitRedis(&cfg.Redis); err != nil {
		logger.Errorf("[main]连接redis数据库失败, 错误: %+v.", err)
		return
	}
	logger.Info("[main]连接redis服务器成功.")

	// 加载syncinfo.plist
	if err := syncmgr.LoadSyncInfo(cfg.SyncInfoFile); err != nil {
		logger.Errorf("[main]加载[%+v]失败, 错误: %+v.", cfg.SyncInfoFile, err)
		return
	}
	logger.Info("[main]加载syncinfo.plist文件成功.")

	// 初始化设备服务api
	api.SetConfig(cfg)
	if err := api.Init(); err != nil {
		logger.Errorf("[main]设备服务api初始化失败, 错误: %+v.", err)
	} else {
		logger.Info("[main]初始化设备服务api成功.")
	}
	// Service服务
	if err := service.ListenAndServe(cfg.ServiceAddr); err != nil {
		logger.Errorf("[main]监听Service服务失败, 错误: %+v.", err)
		return
	}
	logger.Info("[main]监听Service服务成功.")

	//自动上号
	if err := autologinmgr.StartLogin(); err != nil {
		logger.Errorf("[main]自动上号过程失败, 错误: %+v.", err)
		return
	}

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGKILL, syscall.SIGTERM)
	<-quit

	logger.Info("[main]开始关闭服务器.")
	service.Shutdown()
}
