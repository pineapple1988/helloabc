package conn

import (
	"crypto/tls"
	"io"
	"net"
	"pay/utils"
	"pay/utils/logger"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/net/proxy"
)

const (
	stateNone       = 0
	stateConnecting = 1
	stateConnected  = 2
)

// Connection 连接结构体
type Connection struct {
	conn     net.Conn
	addr     string
	useTLS   bool
	useProxy bool
	proxy    utils.ProxyInfo
	hanler   Handler
	state    int32
	sendCh   chan []byte
	wg       sync.WaitGroup
	exiting  bool
}

// NewConnection 新建网络连接
func NewConnection(
	addr string,
	useTLS bool,
	handler Handler,
) *Connection {
	c := &Connection{
		addr:     addr,
		useTLS:   useTLS,
		useProxy: false,
		hanler:   handler,
		wg:       sync.WaitGroup{},
	}

	return c
}

func (c *Connection) setConnectState(state int) {
	atomic.StoreInt32(&c.state, int32(state))
}

func (c *Connection) getConnectState() int {
	return int(c.state)
}

// IsConnected 返回是否已经成功连接服务器
func (c *Connection) IsConnected() bool {
	return c.state == stateConnected
}

// Start 开始网络连接
func (c *Connection) Start() {
	if c.getConnectState() != stateNone {
		return
	}

	c.setConnectState(stateConnecting)
	c.hanler.OnConnecting()

	var conn net.Conn
	if c.useProxy {
		uri := strings.TrimPrefix(c.proxy.URI, "socks5://")
		d, err := proxy.SOCKS5(
			"tcp",
			uri,
			&proxy.Auth{
				User:     c.proxy.User,
				Password: c.proxy.Pass},
			proxy.Direct)
		if err != nil {
			c.hanler.OnConnected(false, err)
			c.setConnectState(stateNone)
			return
		}

		_c, err := d.Dial("tcp", c.addr)
		if err != nil {
			c.hanler.OnConnected(false, err)
			c.setConnectState(stateNone)
			return
		}

		conn = _c
	} else {
		_c, err := net.Dial("tcp", c.addr)
		if err != nil {
			c.hanler.OnConnected(false, err)
			c.setConnectState(stateNone)
			return
		}
		conn = _c
	}

	if c.useTLS {
		conn = tls.Client(
			conn,
			&tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			})
	}

	c.sendCh = make(chan []byte, 10)
	c.conn = conn
	c.setConnectState(stateConnected)
	c.hanler.OnConnected(true, nil)
	c.wg = sync.WaitGroup{}
	c.exiting = false

	go c.sendRoutine()
	go c.recvRoutine()
}

// Stop 停止网络连接
func (c *Connection) Stop() {
	if c.getConnectState() != stateConnected {
		return
	}

	c.conn.Close()

	logger.Debug("[Connection]等待收发协程退出.")

	c.exiting = true
	c.wg.Wait()
	c.setConnectState(stateNone)

	logger.Debug("[Connection]停止网络连接成功.")
}

// SetProxy 设置代理服务器
func (c *Connection) SetProxy(pi *utils.ProxyInfo) {
	if pi != nil && pi.URI != "" {
		c.proxy.URI = pi.URI
		c.proxy.User = pi.User
		c.proxy.Pass = pi.Pass
		c.useProxy = true
	} else {
		c.useProxy = false
	}
}

// Send 发送数据
func (c *Connection) Send(data []byte) {
	if !c.IsConnected() {
		return
	}

	if data != nil && len(data) > 0 {
		c.sendCh <- data
	}
}

func (c *Connection) sendRoutine() {
	c.wg.Add(1)

	buffer := []byte{}
	for data := range c.sendCh {
		if data == nil || len(data) == 0 {
			logger.Info("[Connection]发送空数据, 退出发送循环.")
			break
		}

		//fmt.Printf("[Connection]发包, 长度: %+v, 数据: %+v.\n", len(data), data)

		if len(buffer) == 0 {
			n, err := c.conn.Write(data)
			if err != nil {
				logger.Errorf("[Connection]写入数据错误: %+v.", err)
				break
			}

			if n < len(data) {
				buffer = data[n:]
			}
		} else {
			buffer = append(buffer, data...)
			n, err := c.conn.Write(buffer)
			if err != nil {
				logger.Errorf("[Connection]写入数据错误: %+v.", err)
				break
			}

			if n < len(buffer) {
				buffer = buffer[n:]
			} else {
				buffer = []byte{}
			}
		}
	}

	c.wg.Done()

	logger.Info("[Connection]结束数据发送协程.")
}

func (c *Connection) recvRoutine() {
	c.wg.Add(1)

	buffer := make([]byte, 4096)
	for {
		c.conn.SetReadDeadline(time.Now().Add(time.Millisecond * 1000))
		len, err := c.conn.Read(buffer)
		if err != nil {
			// 超时未退出时继续循环
			if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
				if !c.exiting {
					continue
				}
			}

			if err == io.EOF {
				logger.Infof("[Connection]网络连接已关闭.")
			} else {
				logger.Errorf("[Connection]读取数据错误: %+v.", err)
			}

			// 通知发送协程退出
			c.sendCh <- nil

			defer func() {
				c.setConnectState(stateNone)
				c.hanler.OnError(err)
				c.conn.Close()
				close(c.sendCh)
			}()

			break
		}

		//fmt.Printf("[Connection]收包, 长度: %+v, 数据: %+v.\n", len, buffer[:len])

		if len > 0 {
			c.hanler.OnReceived(buffer[:len])
		} else {
			logger.Warnf("[Connection]接收数据大小异常, 长度: %+v, 错误: %+v.", len, err)
		}
	}

	c.wg.Done()

	logger.Info("[Connection]结束数据接收协程.")
}
