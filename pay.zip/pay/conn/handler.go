package conn

// Handler 网络事件接口
type Handler interface {
	// OnConnecting 正在连接中
	OnConnecting()

	// OnConnected 连接成功或失败
	OnConnected(ok bool, err error)

	// OnReceived 接收到网络数据
	OnReceived(data []byte)

	// OnError 连接出现错误
	OnError(err error)
}
