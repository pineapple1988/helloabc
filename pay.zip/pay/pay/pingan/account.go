package pingan

import (
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strings"
	"sync/atomic"
	"time"
)

// Account 平安银行帐号
type Account struct {
	Account               string          `json:"account"`
	Password              string          `json:"password"`
	PayPassword           string          `json:"payPassword"`
	Platform              string          `json:"platform"`
	DeviceData            string          `json:"deviceData"`
	DeviceID              string          `json:"deviceID"`
	DeviceToken           string          `json:"deviceToken"`
	CardNo                string          `json:"cardNo"`
	HardwareInfo          HardwareInfo    `json:"hardwareInfo"`
	Proxy                 utils.ProxyInfo `json:"proxy"`
	http                  *http.Client
	jar                   *cookiejar.Jar
	bindToken             string
	isBindDevice          string
	bankCardSign          string
	transferTradeNo       string
	transferReqToken      string
	loginStatus           int32
	loginPadding          int32
	lastPing              int64
	transferOrderNo       string
	transferTargetAccount string
	transferTargetName    string
	transferComment       string
	loginFailCount        int
	smscodeFailCount      int
	payPasswordFailCount  int
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	WIFIName             string `json:"wifiName"`             // wifi名字
	WIFIMac              string `json:"wifiMac"`              // wifiMac地址
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // 设备的名字
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace string `json:"availableSystemSpace"` // 可用穷疯
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
	CDataToken           string `json:"cdataToken"`
	CDataAdsID           string `json:"cdataAdsId"`
	CDataName            string `json:"cdataName"`
	CDataVendorID        string `json:"cdataVendorId"`
	CDataDeviceID        string `json:"cdataDeviceId"`
	FPDataA6             string `json:"fpDataA6"`
}

func (acc *Account) newHardwareInfo(platform string) {
	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.Carrier = utils.NewCarrierName()
	h.CellularIP = utils.NewLocalIPAddress()
	h.CDataToken, _ = utils.NewUUID(true)
	h.CDataAdsID, _ = utils.NewUUID(true)
	h.CDataName = fmt.Sprintf("%s iPhone", utils.NewRandString(3+rand.Intn(5), true))
	h.CDataVendorID, _ = utils.NewUUID(true)
	h.CDataDeviceID, _ = utils.NewUUID(true)
	h.FPDataA6, _ = utils.NewUUID(true)

	if platform == common.PlatformNameIOS {
		h.SystemVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()
		h.AvailableSystemSpace = fmt.Sprintf("%d", 21249343488+utils.RandInt(1000000, 9999999))
		h.TotalSystemSpace = "31989469184"
		h.TotalMemory = "2099249152"

	} else if platform == common.PlatformNameAndroid {

	}
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[PINGAN]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(paAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(paAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			if acc.DeviceData == "" {
				uuid, _ := utils.NewUUID(true)
				md5 := md5.New()
				md5.Write([]byte(uuid))
				deviceData := fmt.Sprintf("h%x", md5.Sum(nil))
				hash := sha1.New()
				hash.Write([]byte(deviceData))
				deviceID := fmt.Sprintf("AUUID_%x", hash.Sum(nil))
				sha256 := sha256.New()
				sha256.Write([]byte(fmt.Sprintf("%d%s", time.Now().Unix(), deviceID)))
				acc.DeviceData = deviceData
				acc.DeviceID = deviceID
				acc.DeviceToken = fmt.Sprintf("%x", sha256.Sum(nil))
				acc.newHardwareInfo(platform)
				acc.save()
			}

			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			return acc, nil
		}

		logger.Errorf("[PINGAN]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	uuid, _ := utils.NewUUID(true)
	md5 := md5.New()
	md5.Write([]byte(uuid))
	deviceData := fmt.Sprintf("h%x", md5.Sum(nil))
	hash := sha1.New()
	hash.Write([]byte(deviceData))
	deviceID := fmt.Sprintf("AUUID_%x", hash.Sum(nil))
	sha256 := sha256.New()
	sha256.Write([]byte(fmt.Sprintf("%d%s", time.Now().Unix(), deviceID)))
	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		DeviceData:  deviceData,
		DeviceID:    deviceID,
		DeviceToken: fmt.Sprintf("%x", sha256.Sum(nil)),
		Proxy:       utils.ProxyInfo{},
	}

	acc.newHardwareInfo(platform)

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[PINGAN]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(paAccountKey, field)
	if err != nil {
		logger.Errorf("[PINGAN]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[PINGAN]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[PINGAN]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(paAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[PINGAN]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypePAYH)
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypePAYH)
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypePAYH, code, reason)
}

func (acc *Account) onPwdLoginFail(msg string) *pay.ResultInfo {
	pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypePAYH)

	// 密码错误
	if strings.Contains(msg, "用户名或密码错误") {
		logger.Errorf("[PINGAN][%+v]登录失败, 帐号或密码错误.", acc.Account)

		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePAYH)
		acc.loginFailCount++
		if acc.loginFailCount >= 3 {
			// 帐号登录密码错误次数过多
			acc.loginFailCount = 0
			acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
			logger.Errorf("[PINGAN][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
		}

		return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
	}

	acc.loginFailCount = 0

	// 风控
	if strings.Contains(msg, "您的账户存在风险") {
		acc.freeze(pay.FreezeCodeAccountRisk, pay.FreezeMsgAccountRisk)
		logger.Errorf("[PINGAN][%+v]登录失败, 帐号存在风险.", acc.Account)
		return pay.Error(pay.ErrCodeAccountRisk, pay.ErrMsgAccountRisk, nil)
	}

	// 其它错误
	logger.Errorf("[PINGAN][%+v]登录失败, 错误: %s.", acc.Account, msg)

	return pay.Error(pay.ErrCodeLoginError, msg, nil)
}

func (acc *Account) checkOnline(ts int64) {
	if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 300 {
		// 检测代理服务器
		if config.IsUseProxy() {
			pi, _ := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
			if pi != nil {
				if acc.setProxy(pi.URI, pi.User, pi.Pass) {
					acc.http = pay.CreateHTTPClient(pi, acc.jar)
				}
			}
		}

		// _, err := acc.queryBalance()
		// if err == errLoginTimeout {
		// 	acc.doRelogin()
		// }

		acc.lastPing = ts
	}
}

func (acc *Account) selectCard(balance *queryBalanceRes) error {
	if balance == nil || len(balance.Data.AcctInfoList) <= 0 {
		return pay.ErrNoHaveCardList
	}

	if acc.CardNo == "" {
		acc.bankCardSign = balance.Data.AcctInfoList[0].CardInfo.BankCardSign
		logger.Infof("[PINGAN][%+v]未指定银行卡号, 默认选择第一张, 标识: %+v.", acc.Account, acc.bankCardSign)
		return nil
	}

	for _, v := range balance.Data.AcctInfoList {
		no := v.CardInfo.BankCardMask[len(v.CardInfo.BankCardMask)-4:]
		if strings.HasSuffix(acc.CardNo, no) {
			acc.bankCardSign = v.CardInfo.BankCardSign
			logger.Infof("[PINGAN][%+v]选定指定银行卡号, 卡号: %+v, 标识: %+v.", acc.Account, acc.CardNo, acc.bankCardSign)
			return nil
		}
	}

	logger.Errorf("[PINGAN][%+v]没有找到指定的银行卡号: %s.", acc.Account, acc.CardNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.CardNo)
}

func (acc *Account) doRelogin() error {
	if err := acc.generateBindToken(); err != nil {
		logger.Errorf("[PINGAN][%+v]重登录获取绑定token错误: %+v.", acc.Account, err)
		return err
	}

	pwdLogin, err := acc.userPwdLogin()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]重登录操作错误: %+v.", acc.Account, err)
		return err
	}

	if pwdLogin.ResponseCode != resCodeSuccess {
		res := acc.onPwdLoginFail(pwdLogin.ResponseMsg)
		return errors.New(res.Msg)
	}

	// 要绑定
	if pwdLogin.IsBindDevice == "0" {
		acc.loginStatus = pay.LoginStatusNone
		pay.AccountKickout(acc.Account, acc.Platform, common.AccountTypePAYH)
		logger.Errorf("[PINGAN][%+v]重登录需要重新绑定设备.", acc.Account)
		return pay.ErrNeedBindDevice
	}

	loginData, err := acc.initLoginData()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]重登录初始化登录数据错误: %+v.", acc.Account, err)
		return err
	}

	if loginData.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]重登录初始化登录数据失败: %s.", acc.Account, loginData.ResponseMsg)
		return errors.New(loginData.ResponseMsg)
	}

	return nil
}

func isSamePhoneNumber(number1, number2 string) bool {
	if len(number1) != len(number2) {
		return false
	}

	for i := 0; i < len(number1); i++ {
		if number1[i] == '*' || number2[i] == '*' {
			continue
		}

		if number1[i] != number2[i] {
			return false
		}
	}

	return true
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	// case pay.LoginStatusWaitCode:
	// 	logger.Infof("[PINGAN][%+v]等待验证码登录.", acc.Account)
	// 	return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	case pay.LoginStatusSuccess:
		logger.Infof("[PINGAN][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[PINGAN][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	if config.IsUseProxy() {
		// 代理服务器
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	if err := acc.generateBindToken(); err != nil {
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	pwdLogin, err := acc.userPwdLogin()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]登录错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if pwdLogin.ResponseCode != resCodeSuccess {
		return acc.onPwdLoginFail(pwdLogin.ResponseMsg)
	}

	loginData, err := acc.initLoginData()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]初始化登录数据错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if loginData.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]初始化登录数据失败: %s.", acc.Account, loginData.ResponseMsg)
		return pay.Error(pay.ErrCodeLoginError, loginData.ResponseMsg, nil)
	}

	// 要绑定
	if acc.isBindDevice == "0" {
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypePAYH)

		logger.Infof("[PINGAN][%+v]需要进行设备ID绑定.", acc.Account)

		otpSend, err := acc.ucCoreOtpSend("")
		if err != nil {
			logger.Errorf("[PINGAN][%+v]发送登录验证码错误.", acc.Account)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if !isSamePhoneNumber(acc.Account, otpSend.MaskTelNo) {
			logger.Infof("[PINGAN][%+v]发送号码[%+v]与登录号码[%+v]不一致, 重新发送.", acc.Account, otpSend.MaskTelNo, acc.Account)
			time.Sleep(time.Millisecond * 2000)
			otpSend, err = acc.ucCoreOtpSend("1")
			if err != nil {
				logger.Errorf("[PINGAN][%+v]更改号码发送登录验证码错误.", acc.Account)
				return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
			}
		}

		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	balance, err := acc.queryBalance()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]登录查询余额数据错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if err := acc.selectCard(balance); err != nil {
		logger.Errorf("[PINGAN][%+v]选择银行卡错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	acc.onLoginSuccess()
	logger.Infof("[PINGAN][%+v]登录成功.", acc.Account)
	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypePAYH)

	logger.Infof("[PINGAN][%+v]退出成功.", acc.Account)
	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[PINGAN][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[PINGAN][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {
		// 等待状态是绑定操作
		acc.generateBindToken()
		acc.userPwdLogin()
		acc.initLoginData()

		otpSend, err := acc.ucCoreOtpSend("")
		if err != nil {
			logger.Errorf("[PINGAN][%+v]发送绑定设备验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if !isSamePhoneNumber(acc.Account, otpSend.MaskTelNo) {
			logger.Infof("[PINGAN][%+v]发送号码[%+v]与登录号码[%+v]不一致, 重新发送.", acc.Account, otpSend.MaskTelNo, acc.Account)
			time.Sleep(time.Millisecond * 2000)
			otpSend, err = acc.ucCoreOtpSend("1")
			if err != nil {
				logger.Errorf("[PINGAN][%+v]更改号码发送登录验证码错误.", acc.Account)
				return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
			}
		}
	} else if acc.loginStatus == pay.LoginStatusSuccess {
		// 登录状态是转帐操作
		if acc.transferTradeNo != "" && acc.transferReqToken != "" {
			otpSend, err := acc.commonOTPSend(acc.transferTradeNo)
			if err != nil {
				logger.Errorf("[PINGAN][%+v]发送转帐验证码操作错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
			}

			if otpSend.ResponseCode != resCodeSuccess {
				logger.Errorf("[PINGAN][%+v]发送验证码失败, 代码: %+v, 信息: %+v.", acc.Account, otpSend.ResponseCode, otpSend.ResponseMsg)
				return pay.Error(pay.ErrCodeSendCodeError, otpSend.ResponseMsg, nil)
			}
		} else {
			return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
		}
	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus == pay.LoginStatusWaitCode {
		// 等待状态是绑定操作
		bindDevice, err := acc.bindDevice(code)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]校验验证码操作错误: %+v.", acc.Account, err)
			// 会话失效必须重来
			if err == pay.ErrSessionTimeout {
				acc.loginStatus = pay.LoginStatusNone
				api.ReportAccStateNone(acc.Account, acc.Platform, common.AccountTypePAYH)
				return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
			}

			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if bindDevice.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]校验登录验证码失败: %s.", acc.Account, bindDevice.ResponseMsg)

			if strings.Contains(bindDevice.ResponseMsg, "动态密码错误") {
				acc.smscodeFailCount++
				if acc.smscodeFailCount >= 3 {
					acc.smscodeFailCount = 0
					acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
					logger.Errorf("[PINGAN][%+v]登录连续验证码错误, 临时冻结帐号.", acc.Account)
				}
			}

			// 会话失效必须重来
			if bindDevice.ResponseCode == "682002" {
				acc.loginStatus = pay.LoginStatusNone
				api.ReportAccStateNone(acc.Account, acc.Platform, common.AccountTypePAYH)
			}

			return pay.Error(pay.ErrCodeSMSCodeError, bindDevice.ResponseMsg, nil)
		}

		acc.smscodeFailCount = 0

		balance, err := acc.queryBalance()
		if err != nil {
			logger.Errorf("[PINGAN][%+v]验证码登录查询余额数据错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if err := acc.selectCard(balance); err != nil {
			logger.Errorf("[PINGAN][%+v]选择银行卡错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()
		logger.Infof("[PINGAN][%+v]校验短信验证码登录成功.", acc.Account)
	} else if acc.loginStatus == pay.LoginStatusSuccess {
		// 登录状态是转帐操作
	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PINGAN][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.queryBalance()
	if err != nil {
		logger.Errorf("[PINGAN][%+v]查询余额错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[PINGAN][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]查询余额失败, 代码: %+v, 信息: %+v.", acc.Account, balance.ResponseCode, balance.ResponseMsg)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.ResponseMsg, nil)
	}

	for _, v := range balance.Data.AcctInfoList {
		if v.CardInfo.BankCardSign == acc.bankCardSign {
			res := model.AccountBalanceRes{}
			res.Code = common.ErrCodeSuccess
			res.Msg = common.ErrMsgSuccess
			res.Data.Amount = v.CardInfo.TotalBalance
			res.Data.AmountAvailable = v.CardInfo.TotalBalance

			logger.Infof("[PINGAN][%+v]查询余额成功, 标识: %s, 余额: %s.", acc.Account, acc.bankCardSign, res.Data.Amount)
			return pay.Success(&res)
		}
	}

	logger.Errorf("[PINGAN][%+v]没有找到余额信息, 卡号: %s, 标识: %s.", acc.Account, acc.CardNo, acc.bankCardSign)
	return pay.Error(pay.ErrCodeGetBalanceError, fmt.Sprintf("没有找到银行卡号[%s]的余额信息", acc.CardNo), nil)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PINGAN][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// dateTimeToUnix时间字符串转成unix时间戳
func dateTimeToUnix(dt string) int {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("2006-01-02 15:04:05", dt, loc)
	if err != nil {
		return 0
	}

	return int(tmp.Unix())
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[PINGAN][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 1
	totalPage := 1

	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}

	for {
		tranList, err := acc.queryTranList(startDate, endDate, page)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]查询帐单错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PINGAN][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
				}

				return acc.doBillList(req, false)
			}

			return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
		}

		if tranList.ResponseCode != resCodeSuccess {
			if page == 1 {
				logger.Errorf("[PINGAN][%+v]查询帐单列表失败, 代码: %+v, 信息: %+v.", acc.Account, tranList.ResponseCode, tranList.ResponseMsg)
				return pay.Error(pay.ErrCodeGetBillListError, tranList.ResponseMsg, nil)
			}

			break
		}

		exit := false
		for _, item := range tranList.Data.ResultValue {
			if item.TranAmt == "" {
				continue
			}

			// 时间查询判断条件
			if req.TimeType == common.TimeTypeByTime {
				ts := dateTimeToUnix(item.TranTime)
				if ts == 0 || ts > req.EndTime {
					continue
				}

				if ts < req.StartTime {
					exit = true
					break
				}
			}

			info := model.AccountBillListInfo{
				TradeNo:      item.TranSysNo,
				TradeTime:    item.TranTime,
				Amount:       item.TranAmt,
				AmountRemain: item.Balance,
				Comment:      item.UserRemark,
			}

			if item.IPFlag == "1" {
				// 支出
				info.TradeType = "0"
				info.TargetAccount = item.ToAcctNo
				info.TargetName = item.ToClientName
				info.TargetBankName = item.ToBankName
			} else if item.IPFlag == "0" {
				// 收入
				info.TradeType = "1"
				info.TargetAccount = item.FromAcctNo
				info.TargetName = item.FromClientName
				info.TargetBankName = item.FromBankName
			} else {
				logger.Errorf("[PINGAN][%+v]查询帐单出现未知的记帐方式: %+v.", acc.Account, item.IPFlag)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.IPFlag == "0" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.IPFlag == "1" {
					res.Data = append(res.Data, info)
				}
			}
		}

		if exit {
			break
		}

		if page == 1 {
			totalPage = tranList.Data.Count/10 + 1
		}

		if page >= totalPage {
			break
		}

		page++
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PINGAN][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBillList(req, true)
}

func (acc *Account) confirmTransfer(req *model.AccountTransferReq) *pay.ResultInfo {
	transferConfirm, body, err := acc.transferNewConfirm(acc.transferReqToken, acc.transferTradeNo, "Y")
	if err != nil {
		logger.Errorf("[PINGAN][%+v]转帐确认错误: %+v.", acc.Account, err)

		// 网络超时不确定有没有完成转帐
		if err == pay.ErrOperationTimeout {
			return pay.Error(pay.ErrCodeTransferStatusUnknow, pay.ErrMsgTransferStatusUnknow, nil)
		}

		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if transferConfirm.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]转帐确认失败, 代码: %+v, 信息: %+v.", acc.Account, transferConfirm.ResponseCode, transferConfirm.ResponseMsg)
		return pay.Error(pay.ErrCodeTransferError, transferConfirm.ResponseMsg, nil)
	}

	if transferConfirm.Data.Status == "0" {
		logger.Errorf("[PINGAN][%+v]转帐状态不正确, 状态: %+v, 信息: %+v.", acc.Account, transferConfirm.Data.Status, transferConfirm.Data.MsgExtend)
		return pay.Error(pay.ErrCodeTransferError, transferConfirm.Data.MsgExtend, nil)
	}

	status := common.TransferStatusProcessing
	for i := 0; i < 5; i++ {
		time.Sleep(time.Second * 2)
		result, err := acc.queryResult(transferConfirm.Data.OrderSerialNo)
		if err != nil {
			continue
		}

		if result.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]查询转帐状态失败, 流水号: %+v, 代码: %+v, 信息: %+v.", acc.Account, transferConfirm.Data.OrderSerialNo, result.ResponseCode, result.ResponseMsg)
			continue
		}

		if result.Data.Status == "0" {
			status = common.TransferStatusFail
			logger.Infof("[PINGAN][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.", acc.Account, transferConfirm.Data.OrderSerialNo, result.Data.MsgExtend)

			msg := result.Data.MsgExtend
			if result.Data.Msg != "" {
				msg += result.Data.Msg
			}
			// 冻结情况
			if strings.Contains(msg, blockByInfoNotComplete) {
				acc.freeze(pay.FreezeCodeCardError, msg)
				return pay.Error(pay.ErrCodeCardBlock, result.Data.MsgExtend, nil)
			}

			if strings.Contains(msg, blockByDubiousTrade) {
				acc.freeze(pay.FreezeCodeCardError, msg)
				return pay.Error(pay.ErrCodeCardBlock, result.Data.MsgExtend, nil)
			}

			return pay.Error(pay.ErrCodeTransferError, msg, nil)
		}

		if result.Data.Status == "1" {
			status = common.TransferStatusSuccess
			logger.Infof("[PANGAN][%+v]查询转帐状态成功, 流水号: %+v, 信息: %+v.", acc.Account, transferConfirm.Data.OrderSerialNo, result.Data.RouteTips)
			break
		}

		if result.Data.Status == "2" {
			logger.Infof("[PANGAN][%+v]查询转帐状态尚未确定, 流水号: %+v.", acc.Account, transferConfirm.Data.OrderSerialNo)
			continue
		}

		logger.Warnf("[PINGAN][%+v]未知的转帐状态, 流水号: %+v, 状态: %+v.", acc.Account, transferConfirm.Data.OrderSerialNo, result.Data.Status)
	}

	acc.transferTradeNo = ""
	acc.transferReqToken = ""

	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData
	res.Status = status

	if status == common.TransferStatusProcessing {
		res.Code = pay.ErrCodeTransferStatusUnknow
		res.Msg = pay.ErrMsgTransferStatusUnknow
	}

	res.Data.TradeNo = transferConfirm.Data.OrderSerialNo
	res.Data.TradeType = "0"
	res.Data.Amount = transferConfirm.Data.Amount
	res.Data.AmountRemain = "未知"

	balance, err := acc.queryBalance()
	if err == nil && len(balance.Data.AcctInfoList) > 0 {
		for _, v := range balance.Data.AcctInfoList {
			if v.CardInfo.BankCardSign == acc.bankCardSign {
				res.Data.AmountRemain = v.CardInfo.TotalBalance
			}
		}
	}

	res.Data.TargetAccount = acc.transferTargetAccount
	res.Data.TargetName = acc.transferTargetName
	res.Data.TargetBankName = transferConfirm.Data.ToBankName
	res.Data.Comment = acc.transferComment

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypePAYH,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		status)

	logger.LogTransfer("[PINGAN][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		acc.transferTargetName,
		acc.transferTargetAccount,
		res.Data.Amount,
		status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if req.SMSCode == "" {
		bankInfo, err := acc.queryAllBankInfo(req.TargetAccount)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]查询目标帐号银行信息错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PINGAN][%+v]转帐重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			logger.Errorf("[PINGAN][%+v]查询目标银行信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if bankInfo.Code != "000" {
			logger.Errorf("[PINGAN][%+v]查询目标银行信息失败, 代码: %+v, 信息: %+v.", acc.Account, bankInfo.Code, bankInfo.Message)
			return pay.Error(pay.ErrCodeTransferError, bankInfo.Message, nil)
		}

		bankCode := ""
		bankNo := ""
		bankName := ""

		if bankInfo.Object.BankCode != "" && bankInfo.Object.UnionBankCode != "" {
			bankCode = bankInfo.Object.BankCode
			bankNo = bankInfo.Object.UnionBankCode
			bankName = bankInfo.Object.BankName
		} else if req.BankName != "" {
			res, err := api.NodeQueryBankInfo(req.BankName)
			if err != nil {
				bankName = req.BankName
			} else {
				bankCode = res.BankCode
				bankNo = res.BankNo
				bankName = res.BankName
			}
		}

		if bankCode == "" || bankNo == "" {
			logger.Warnf("[PINGAN][%+v]查询到暂不支持的银行, 卡号: %+v, 银行名字: %+v, BankCode: %+v, BankNo: %+v.",
				acc.Account, req.TargetAccount, bankName, bankCode, bankNo)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		relation, err := acc.validateBindRelation(acc.bankCardSign, req.TargetAccount, bankName)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]验证绑定关系错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if relation.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]验证绑定关系失败, 代码: %+v, 信息: %+v.", acc.Account, relation.ResponseCode, relation.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, relation.ResponseMsg, nil)
		}

		timeliness, err := acc.getTransferTimeliness(req.TargetAccount, req.Amount, bankNo, bankCode)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]转帐Timeliness查询错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if timeliness.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINAN][%+v]转帐Timeliness查询失败, 代码: %+v, 信息: %+v.", acc.Account, timeliness.ResponseCode, timeliness.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, timeliness.ResponseMsg, nil)
		}

		payInfo, err := encPayInfo(req.TargetAccount, req.Amount)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]加密支付信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrEncRequestData.Error(), nil)
		}

		verifyInfo, err := encVerifyInfo(req.TargetAccount, req.Amount, acc.bankCardSign)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]加密校验信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrEncRequestData.Error(), nil)
		}

		route, err := acc.transferRoute(payInfo, req.TargetName, bankCode, bankName, acc.bankCardSign, bankNo, req.Comment, verifyInfo, "3", "")
		if err != nil {
			logger.Errorf("[PINGAN][%+v]生成转帐信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if route.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]生成转帐信息失败, 代码: %+v, 信息: %+v.", acc.Account, route.ResponseCode, route.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, route.ResponseMsg, nil)
		}

		if route.Data.BaoOrderNo == "" || route.Data.ReqToken == "" {
			cardTerm := route.Data.CardTerm
			if cardTerm != "" {
				logger.Errorf("[PINGAN][%+v]生成转帐订单失败: %+v.", acc.Account, cardTerm)
				// 挂失状态
				if strings.Contains(cardTerm, "挂失状态") {
					acc.freeze(pay.FreezeCodeCardError, cardTerm)
					return pay.Error(pay.ErrCodeCardReportLost, cardTerm, nil)
				}

				// 止付状态
				if strings.Contains(cardTerm, "止付状态") {
					acc.freeze(pay.FreezeCodeCardError, cardTerm)
					return pay.Error(pay.ErrCodeCardBlock, cardTerm, nil)
				}

				return pay.Error(pay.ErrCodeTransferError, cardTerm, nil)
			}

			if route.Data.InstallCertMsg != "" {
				// 要安全工具
				logger.Errorf("[PINGAN][%+v]生成转帐订单失败: %+v.", acc.Account, route.Data.InstallCertMsg)
				return pay.Error(pay.ErrCodeTransferError, route.Data.InstallCertMsg, nil)
			}

			logger.Errorf("[PINGAN][%+v]生成转帐订单失败: %+v.", acc.Account, route)
			return pay.Error(pay.ErrCodeTransferError, "生成转帐订单失败, 请检查帐号状态", nil)
		}

		acc.transferTradeNo = route.Data.BaoOrderNo
		acc.transferReqToken = route.Data.ReqToken
		acc.transferOrderNo = req.OrderNo
		acc.transferTargetAccount = req.TargetAccount
		acc.transferTargetName = req.TargetName
		acc.transferComment = req.Comment

		logger.Infof("[PINGAN][%+v]生成支付订单, 流水号: %s, token: %s.", acc.Account, acc.transferTradeNo, acc.transferReqToken)

		sm2Info, err := encSM2(acc.getPayPassword())
		if err != nil {
			logger.Errorf("[PINGAN][%+v]支付密码SM2加密错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrEncRequestData.Error(), nil)
		}

		payPass, err := encLoginPwd(acc.getPayPassword())
		if err != nil {
			logger.Errorf("[PINGAN][%+v]支付密码RSA加密错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrEncRequestData.Error(), nil)
		}

		commonPwd := "CN-S" + sm2Info + "|" + payPass
		verifyType := "3"
		if route.Data.IsNeedOtp == "0" {
			verifyType = "1"
			logger.Infof("[PINGAN][%+v]免验证码支付模式.", acc.Account)
		}

		passwordCheck, err := acc.commonPasswordCheck(commonPwd, acc.transferTradeNo, verifyType)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]验证支付密码操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if passwordCheck.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]验证支付密码失败, 代码: %+v, 信息: %+v.", acc.Account, passwordCheck.ResponseCode, passwordCheck.ResponseMsg)

			if strings.Contains(passwordCheck.ResponseMsg, blockByReportLost) {
				return pay.Error(pay.ErrCodeCardReportLost, blockByReportLost, nil)
			}

			acc.payPasswordFailCount++
			if acc.payPasswordFailCount >= 3 {
				acc.payPasswordFailCount = 0
				acc.freeze(pay.FreezeCodePayPasswordError, pay.FreezeMsgPayPasswordError)
				logger.Errorf("[PINGAN][%+v]支付密码连续错误, 临时冻结帐号.", acc.Account)
			}

			return pay.Error(pay.ErrCodeTransferError, passwordCheck.ResponseMsg, nil)
		}

		acc.payPasswordFailCount = 0

		// 直接可以转帐
		if route.Data.IsNeedOtp == "0" {
			return acc.confirmTransfer(req)
		}

		otpSend, err := acc.commonOTPSend(acc.transferTradeNo)
		if err != nil {
			logger.Errorf("[PINGAN][%+v]发送支付验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if otpSend.ResponseCode != resCodeSuccess {
			logger.Errorf("[PINGAN][%+v]发送支付验证码失败, 代码: %+v, 信息: %+v.", acc.Account, otpSend.ResponseCode, otpSend.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, otpSend.ResponseMsg, nil)
		}

		logger.Infof("[PINGAN][%+v]发送验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	if acc.transferTradeNo == "" || acc.transferReqToken == "" {
		logger.Warnf("[PINGAN][%+v]尚未生成支付订单.", acc.Account)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrNotCreateOrderNo.Error(), nil)
	}

	otpCheck, err := acc.commonOTPCheck(acc.transferTradeNo, req.SMSCode)
	if err != nil {
		logger.Errorf("[PINGAN][%+v]校验验证码错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if otpCheck.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]校验验证码失败, 代码: %+v, 信息: %+v.", acc.Account, otpCheck.ResponseCode, otpCheck.ResponseMsg)
		if strings.Contains(otpCheck.ResponseMsg, "验证码输入错误") {
			acc.smscodeFailCount++
			if acc.smscodeFailCount >= 3 {
				acc.smscodeFailCount = 0
				acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
				logger.Errorf("[PINGAN][%+v]转帐连续验证码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return pay.Error(pay.ErrCodeTransferError, otpCheck.ResponseMsg, nil)
	}

	acc.smscodeFailCount = 0

	return acc.confirmTransfer(req)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PINGAN][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	// 支付密码检测
	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[PINGAN][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	return acc.doTransfer(req, true)
}

func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	result, err := acc.queryResult(req.TradeNo)
	if err != nil {
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[PINGAN][%+v]查询转帐状态重新登录帐号错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
			}

			return acc.doTransferStatus(req, false)
		}

		logger.Errorf("[PINGAN][%+v]查询转帐状态错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
	}

	if result.ResponseCode != resCodeSuccess {
		logger.Errorf("[PINGAN][%+v]查询转帐状态失败, 代码: %+v, 信息: %+v.", acc.Account, result.ResponseCode, result.ResponseMsg)
		return pay.Error(pay.ErrCodeTransferStatusError, result.ResponseMsg, nil)
	}

	status := common.TransferStatusNone
	if result.Data.Status == "0" {
		status = common.TransferStatusFail
	} else if result.Data.Status == "1" {
		status = common.TransferStatusSuccess
	} else if result.Data.Status == "2" {
		status = common.TransferStatusProcessing
	} else {
		logger.Errorf("[PINGAN][%+v]查询转帐状态未知状态: %+v.", acc.Account, result.Data.Status)
		return pay.Error(pay.ErrCodeTransferStatusError, fmt.Sprintf("未知的转帐状态: %+v", result.Data.Status), nil)
	}

	res := model.AccountTransferStatusRes{}
	res.Status = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Status = status

	if status != common.TransferStatusProcessing {
		api.NodeTransferStatus(req.TradeNo, status)
		logger.LogTransfer("[PINGAN][%+v]转帐流水号[%+v]状态更新为: %+v.", acc.Account, req.TradeNo, status)
	}

	return pay.Success(&res)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[PINGAN][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PINGAN][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
