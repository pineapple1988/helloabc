package pingan

type bindTokenRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	BindToken    string `json:"bindToken"`
}

type userPwdLoginRes struct {
	AESBecifNo             string `json:"aesBecifNo"`
	BankType               string `json:"bankType"`
	BFlag                  string `json:"bflag"`
	BFlag4                 string `json:"bflag4"`
	BrcpSessionTicket      string `json:"brcpSessionTicket"`
	CertificateType        string `json:"certificateType"`
	ClientSafeToolsLevel   string `json:"clientSafeToolsLevel"`
	EncryBecifNo           string `json:"encryBecifNo"`
	EncryMid               string `json:"encryMid"`
	IsBindDevice           string `json:"isBindDevice"`
	IsFrequentlyUsedDevice string `json:"isFrequentlyUsedDevice"`
	LicenseFlag            string `json:"licenseFlag"`
	MergeAccountFlag       string `json:"mergeAccountFlag"`
	Mid                    string `json:"mid"`
	OpenTools              string `json:"openTools"`
	ResponseCode           string `json:"responseCode"`
	ResponseMsg            string `json:"responseMsg"`
	SetTool                string `json:"setTool"`
	Sl                     string `json:"sl"`
	ToaModifyFlag          string `json:"toaModifyFlag"`
	Token                  string `json:"token"`
	UFlag                  string `json:"uflag"`
	UFlag4                 string `json:"uflag4"`
	UserType               string `json:"userType"`
}

type initLoginDataRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	RetCode      string `json:"retCode"`
	ErrMsg       string `json:"errMsg"`
	ResponseBody struct {
		UserType         string `json:"userType"`
		NoticeBindFlag   string `json:"noticeBindFlag"`
		ClientNo         string `json:"clientNo"`
		PartyNo          string `json:"partyNo"`
		BecifNO          string `json:"becifNO"`
		BankType         string `json:"bankType"`
		LoginSessionFlag string `json:"loginSessionFlag"`
		UserID           string `json:"userId"`
		WhiteUser        string `json:"whiteUser"`
		AssetInfo        struct {
			LoginTime string `json:"loginTime"`
			WhiteUser string `json:"whiteUser"`
			RankCode  string `json:"rankCode"`
			CardCode  string `json:"cardCode"`
			SSOSign   string `json:"ssoSign"`
		} `json:"assetInfo"`
		LoginOtpBindFlag     string `json:"loginOtpBindFlag"`
		AccessK              string `json:"access_k"`
		AccessT              string `json:"access_t"`
		AccessSign           string `json:"access_sign"`
		AesKey               string `json:"aes_key"`
		SendOtpFlag          string `json:"sendOtpFlag"`
		CurrServiceTime      string `json:"currServiceTime"`
		IsBind               string `json:"isBind"`
		ToaPartyNo           string `json:"toaPartyNo"`
		Alias                string `json:"alias"`
		BankUserName         string `json:"bankUserName"`
		TelephoneNum         string `json:"telephoneNum"`
		TelephoneNumMask     string `json:"telephoneNumMask"`
		LoginName            string `json:"loginName"`
		CardType             string `json:"cardType"`
		CardTypeCode         string `json:"cardTypeCode"`
		CardNo               string `json:"cardNo"`
		CardNoMask           string `json:"cardNoMask"`
		Sex                  string `json:"sex"`
		PreferredTool        string `json:"preferredTool"`
		IsSetTool            string `json:"isSetTool"`
		OpenTools            string `json:"openTools"`
		FirstLogonFlag       string `json:"firstLogonFlag"`
		FirstOrangeLogonFlag string `json:"firstOrangeLogonFlag"`
		UserName             string `josn:"userName"`
	} `json:"responseBody"`
}

type ucCoreOptSendRes struct {
	ResponseCode      string `json:"responseCode"`
	ResponseMsg       string `json:"responseMsg"`
	MaskTelNo         string `json:"maskTelNo"`
	BrcpSessionTicket string `json:"brcpSesstionTicket"`
}

type bindDeviceRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
}

type acctInfo struct {
	CardInfo struct {
		AccountFlag string `json:"accountFlag"`
		AccountType string `json:"accountType"`
		//AutoRedeemLimitList []string `json:"autoRedeemLimitList"`
		BankCardAlias   string   `json:"bankCardAlias"`
		BankCardMask    string   `json:"bankCardMask"`
		BankCardSign    string   `json:"bankCardSign"`
		BankCode        string   `json:"bankCode"`
		BankName        string   `json:"bankName"`
		BindCardFlag    string   `json:"bindCardFlag"`
		CardBusTypeList []string `json:"cardBusTypeList"`
		CardFaceType    string   `json:"cardFaceType"`
		CardLevel       string   `json:"cardLevel"`
		CardMedia       string   `json:"cardMedia"`
		CardType        string   `json:"cardType"`
		FaceCheck       string   `json:"faceCheck"`
		HqFinaNetBal    string   `json:"hqFinaNetBal"`
		HQNetBalance    string   `json:"hqNetBalance"`
		HqPureNetBal    string   `json:"hqPureNetBal"`
		IsAdded         string   `json:"isAdded"`
		OpenCity        string   `json:"openCity"`
		OpenDate        string   `json:"openDate"`
		OrgAddr         string   `json:"orgAddr"`
		OrgName         string   `json:"orgName"`
		ParentCode      string   `json:"parentCode"`
		PBCAcctType     string   `json:"pbcAcctType"`
		PreferBussType  string   `json:"preferBussType"`
		PreferCcy       string   `json:"preferCcy"`
		RitianliFlag    string   `json:"ritianliFlag"`
		SameBankFlag    string   `json:"sameBankFlag"`
		TotalBalance    string   `json:"totalBalance"`
	} `json:"cardInfo"`
}

type queryBalanceRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		AcctInfoList []acctInfo `json:"acctInfoList"`
	} `json:"data"`
}

type billInfo struct {
	UserRemark     string `josn:"userRemark"`
	ToBankName     string `json:"toBankName"`
	AvailBalance   string `json:"availBalance"`
	TranDate       string `json:"tranDate"`
	ToBranchName   string `json:"toBranchName"`
	Remark         string `json:"remark"`
	ToClientName   string `json:"toClientName"`
	TranSysNo      string `json:"tranSysNo"`
	CurrType       string `json:"currType"`
	FixedDepositSN string `json:"fixedDepositSN"`
	Balance        string `json:"balance"`
	BranchID       string `json:"branchId"`
	RemarkFlag     string `json:"remarkFlag"`
	FromAcctSign   string `json:"fromAcctSign"`
	FromAcctNo     string `json:"fromAcctNo"`
	TranFlag       string `json:"tranFlag"`
	TranTime       string `json:"tranTime"`
	LedgerBalance  string `json:"ledgerBalance"`
	ValueDate      string `json:"valueDate"`
	TranAmt        string `json:"tranAmt"`
	IsWriteOff     bool   `json:"isWriteOff"`
	ToAcctFlag     string `json:"toAcctFlag"`
	IPFlag         string `json:"ipFlag"`
	FromBranchName string `json:"fromBranchName"`
	FromClientName string `json:"fromClientName"`
	AccNum         string `json:"accNum"`
	ToAcctNo       string `json:"toAcctNo"`
	TranCode       string `json:"tranCode"`
	ToAcctBankNo   string `json:"toAcctBankNo"`
	FromBankName   string `json:"fromBankName"`
}

type queryTranListRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		Count       int        `json:"count"`
		ResultKey   string     `json:"result_key"`
		ResultValue []billInfo `json:"result_value"`
	} `json:"data"`
}

type queryAllBankInfoRes struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	Success bool   `json:"success"`
	Object  struct {
		AdditionalCardType  string  `json:"additionalCardType"`
		BankCode            string  `json:"bankCode"`
		BankIcoPicID        string  `json:"bankIcoPicId"`
		BankName            string  `json:"bankName"`
		CardBin             string  `json:"cardBin"`
		CardNo              string  `json:"cardNo"`
		CardType            string  `json:"cardType"`
		DailyLimit          float32 `json:"dailyLimit"`
		IsPaBank            string  `json:"isPaBank"`
		IsSupportAuth       string  `json:"isSupportAuth"`
		IsSupportTransferIn string  `json:"isSupportTransferIn"`
		SingleLimit         float32 `json:"singleLimit"`
		UnionBankCode       string  `json:"unionBankCode"`
	} `json:"object"`
}

type validateBindRelationRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		BankCardMask   string `json:"bankCardMask"`
		BankCardSign   string `json:"bankCardSign"`
		BankCode       string `json:"bankCode"`
		BankName       string `json:"bankName"`
		IsBind         string `json:"isBind"`
		IsChangeStatus string `json:"isChangeStatus"`
	} `json:"data"`
}

type transferTimelinessRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		IsNewProcess string `json:"isNewProcess"`
	} `json:"data"`
}

type transferRouteRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		AccountType       string `json:"accountType"`
		BankCardMask      string `json:"bankCardMask"`
		BankCardSign      string `json:"bankCardSign"`
		BaoOrderNo        string `json:"baoOrderNo"`
		CertBankCardMask  string `json:"certBankCardMask"`
		CertBankCardSign  string `json:"certBankCardSign"`
		IsNeedAFR         string `json:"isNeedAFR"`
		IsNeedFingerprint string `json:"isNeedFingerprint"`
		IsNeedOtp         string `json:"isNeedOtp"`
		IsNeedValidCert   string `json:"isNeedValidCert"`
		IsNeedVerifyToken string `json:"isNeedVerifyToken"`
		LimitConfirmFlag  string `json:"limitConfirmFlag"`
		ReqToken          string `json:"reqToken"`
		ValidateFaceFlag  string `json:"validateFaceFlag"`
		CardTerm          string `json:"cardTerm"`
		InstallCertMsg    string `json:"installCertMsg"`
	} `json:"data"`
}

type commonPasswordCheckRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		OverallResultOfSecTool string `json:"overallResultOfSecTool"`
	} `json:"data"`
}

type commonOTPSendRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		AccountType string `json:"accountType"`
		OtpMobile   string `json:"otpMobile"`
	}
}

type commonOTPCheckRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		OverallResultOfSecTool string `json:"overallResultOfSecTool"`
	}
}

type transferNewConfirmRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		ToBankName       string `json:"toBankName"`
		Ccy              string `json:"ccy"`
		ReceiveDate      string `json:"receiveDate"`
		Status           string `json:"status"`
		IsSuspend        string `json:"isSuspend"`
		OrderSerialNo    string `json:"orderSerialNo"`
		DetailSwitch     string `json:"detailSwitch"`
		WxNoticeFlag     string `json:"wxNoticeFlag"`
		RouteID          string `json:"routeId"`
		Amount           string `json:"amount"`
		SmallFreeOtpFlag string `json:"smallFreeOtpFlag"`
		MsgExtend        string `json:"msgExtend"`
		IsCanCancel      string `json:"isCanCancel"`
		ToBankCardMask   string `json:"toBankCardMask"`
		RouteTips        string `json:"routeTips"`
	} `json:"data"`
}

type queryResultRes struct {
	ResponseCode string `json:"responseCode"`
	ResponseMsg  string `json:"responseMsg"`
	Data         struct {
		MsgExtend    string `json:"msgExtend"`
		Ccy          string `json:"ccy"`
		Status       string `json:"status"`
		DetailSwitch string `json:"detailSwitch"`
		WxNoticeFlag string `json:"wxNoticeFlag"`
		RouteTips    string `json:"routeTips"`
		RecAccNo     string `json:"recAccNo"`
		Msg          string `json:"msg"`
	}
}

// type cData struct {
// 	Btime            int     `json:"Btime"`
// 	Adsenable        int     `json:"ads.enable"`
// 	AdsID            *string `json:"ads.id"`
// 	AppName          string  `json:"app.name"`
// 	AppVer           string  `json:"app.ver"`
// 	Appid            string  `json:"appid"`
// 	AppstoreID       string  `json:"appstoreId"`
// 	BatLevel         int     `json:"batLevel"`
// 	BatStatus        string  `json:"batStatus"`
// 	BlueMac          string  `json:"blueMac"`
// 	Cellno           string  `json:"cellno"`
// 	ClientAppList    string  `json:"clientAppList"`
// 	ClientIP         string  `json:"clientIp"`
// 	ClientSensorInfo string  `json:"clientSensorInfo"`
// 	CPUCount         int     `json:"cpu.count"`
// 	CurrentTime      string  `json:"currentTime"`
// 	Dbggdb           string  `json:"dbg.gdb"`
// 	DeviceID         string  `json:"deviceId"`
// 	Dish             int     `json:"dis.h"` //分辨率高度
// 	Disorient        int     `json:"dis.orient"`
// 	Disw             int     `json:"dis.w"`
// 	Diskintsize      int     `json:"disk.in.tsize"`
// 	Diskinusize      int     `json:"disk.in.usize"`
// 	DNS1             string  `json:"dns1"`
// 	EventType        string  `json:"eventType"`
// 	Gatway           string  `json:"gatway"`
// 	ImeiID           string  `json:"imeiId"`
// 	ImsiID           string  `json:"imsiId"`
// 	IsBatUsage       bool    `json:"isBatUsage"`
// 	LocalizedModel   string  `json:"localizedModel"`
// 	Location         string  `json:"location"`
// 	Memtsz           int     `json:"mem.tsz"`
// 	Model            string  `json:"model"`
// 	Name             string  `json:"name"`
// 	Nettype          string  `json:"net_type"`
// 	NetworkOperator  string  `json:"networkOperator"`
// 	PhoneNo          string  `json:"phoneNo"`
// 	Pin              string  `json:"pin"`
// 	Root             int     `json:"root"`
// 	Scrbri           int     `json:"scr_bri"`
// 	SdkVersion       string  `json:"sdk_version"`
// 	SimSerial        string  `json:"simSerial"`
// 	SysName          string  `json:"sysName"`
// 	SystemVersion    string  `json:"systemVersion"`
// 	Template         string  `json:"template"`
// 	TimeZ            string  `json:"timeZ"`
// 	Token            string  `json:"token"`
// 	Tokenctime       uint    `json:"token_ctime"`
// 	TypeName         string  `json:"typeName"`
// 	VearP            string  `json:"v.earP"`
// 	Vsys             string  `json:"v.sys"`
// 	VendorID         string  `json:"vendor_id"`
// 	WifiIP           string  `json:"wifiIp"`
// 	WifiMac          string  `json:"wifiMac"`
// 	WifisID          string  `json:"wifi_sid"`
// }

// type eeee8 struct{
// 	E9          int  `json:"e9"`
// 	g3          int  `json:"g3"`
// }

// type paFingerprint struct {
// 	a1          string  `json:"a1"`
// 	a2          string  `json:"a2"`
// 	a3          string  `json:"a3"`
// 	a4          string  `json:"a4"`
// 	a5          string  `json:"a5"`
// 	a6          string  `json:"a6"`
// 	a8          int  `json:"a8"`
// 	b1          string  `json:"b1"`
// 	b7          string  `json:"b7"`
// 	b8          string  `json:"b8"`
// 	E8          eeee8  `json:"e8"`
// 	f2          string  `json:"f2"`
// 	g5          string  `json:"g5"`
// 	G6          string  `json:"g6"`
// 	G7          string  `json:"g7"`
// 	G8          string  `json:"g8"`
// 	g9          string  `json:"g9"`
// 	h1          string  `json:"h1"`
// 	h2          string  `json:"h2"`
// 	h3          string  `json:"h3"`
// 	h4          string  `json:"h4"`
// 	h5          string  `json:"h5"`
// 	h6          string  `json:"h6"`
// 	h7          string  `json:"h7"`
// 	h8          string  `json:"h8"`
// 	111111111111          string  `json:"111111111111"`
// 	111111111111          string  `json:"111111111111"`
// 	111111111111          string  `json:"111111111111"`
// 	111111111111          string  `json:"111111111111"`
// 	111111111111          string  `json:"111111111111"`

// 	111111111111          string  `json:"111111111111"`
// }
