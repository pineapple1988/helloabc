package pingan

import (
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	"pay/data/redis"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"testing"

	"github.com/tjfoc/gmsm/sm2"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	acc, err := NewAccount("13172235783", "aa343599", "343599", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	r := acc.Login(20000)
	if r == nil {
		t.Fatal("尚未实现登录接口.")
	}

	if r.Code != 0 {
		t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	}
}

func TestData(t *testing.T) {
	str := `nJdzpKDAVBb1ygsN+EouRHP9n6MKvXueXESmMyCpJrTkKxfqFEMxaYO7FO5iszqGLuF0Peyiwyf6MHRLD7e75KnkcBC04A0egv9J/Ody3vu0tJJxlZlpDPW5DhyHiedtb0nsXxSszjxQMEpdk43q7CS2NDmA6iYbzKUuv5EPVsY+G1NvHfwf0cqQGJcGVWdGFiqpBTEKWAv6yUF+0cXp6o+FMUq2CCSzTBW4uLk5mgNQKWB0tSmEMVxysjtlzv06dkeTdknzfzMEndORpFxQeCHVMtsil8GYjYuhrpHbOB6lm3h2YtCnpmrKkktDj0wcHWazO7+238rfrJ3PXJ+nTgyKpzUrzXgsLlkfu/jmNBe63jeyNk4fwjif9QpU7HyUdiWRDTlumiWPm7xm4Y53YQHhj9zm/nOBN8rxLbEXcYRg99hjAbRpMnRNGsgJhONSN7qUmxLahoFdO8Svcqasx3Vfm2BDVYWCRnDS/ZqITBXRVbWDdaVKVudXBwvx1YYFhi/bRNw+wzOFEma96GpMFUwqbWzwGPc8G5kYNUtzp5btBgePe7ursPvg/G0KLo09WfKBqWgaxiDnj1KvjxVfOV8dSfgWDWGh1CJeYhgeiN8XeRe78u+MqxpIdA8K5VPygdEi3+wLWabgrH/xMeEdehBH7FQ7qMPnALZYyzv5m6mWPOT+D9oRyQGIYU+N0KCrDg2aIWCMZ4cu5TO8P9zLSJjGLFFy5x90sKAXFGdASjJVZie11nVJdQP6PzY4UxoCb3aA4IgGwP3bX6i23oMjsSHH6EuU5UDaWGBqAoY4MG5kZwD/8RgNZ5d6DOZqfVc0IJ1jg58a2ydP/kPT/k+NbNWm0TIpO1OXO2yjK9LeBOzRi/uIGpTmgzKLeET3gU2EURefl/QcfSj9HtMrU4JXIgSo6un3ht49eiG3H5f9Y40c/JDyBIXY1NOh+4JOEE4dBddpqBoPZUVmvFFDHrsKscebO/ew7p3hAK4vYAWfzJ+t8iqOUcLUvk3RlW0wJuEnJjvUsODnVN8DEQLUhgrXp+Jx6HVeX5izjMzEns9c3yirlUGoEBblOQBs0qMUL9Evpu7/vkBTP0r1QGxsxYN8JqFG01n6n20blJxDb68zBLceJ3b6dX8ayPEU+9KodoZWKLjF27i7dxewCT9CVdCF8KIxcGHRsELdhYdbCIn+BREw6SxoT0gpnkaI/EOVJ3UnhImM7EwS/AmxvuOmH4VRRA1wlPuDUpXoJMb4/9ceLEn0VY3TCuk8/ksv5lW3TDPXRqIGBB1/7oArvgdp89sQ2caERojJCkRySBhT0GTBp/15ma+nVyx9e6qKq1H3McbejPui33WX0lcn+enhBCVxpHB6efdoys3PtQHafx9vBq6W8+g9jbLAEpQE2+RKRgNu6T37gfk5oOocRm29//Rk6n5atedgnjEM6c1WwdYvWT1ygi7ZP+qeyfhDNe7wJbjEls75vyz/h8G/t1vBLqQ/LkFCCsMzvTGQ9L4TKZr2tgxA5cEU1iXllliuJK75cezLVP/7od6vXS4h1x4BJnLFY+c7JWnrQP4Auf8G1TAKjdpG3S7J6PMA5KvjF1CB1rH4qKE4Me2fmJemfavXMwgOJj/AxwbbXJkOt5qWpgZo1gNXT4MSdUSCZYXHvZBtfMXB7FV8Tk1hy46F3DB7LW0mW/xwYDMD586gynZvcTNdaDmGzkPlBe8LabZ5gCEDNbU5+YgTeFyA26b8HII1NndETbAUq+Lkomo3jf8q7jplplNOEcyNBcnxQzlg/GYDuGqeyUwVW1Hb2coc3Zf00u0DvvY361MyNlOX4z+OPue4yAQdq6jByY59GMi3rdXVCgEuUu1Ck33/1LYawDYA/7zt2EzFYyLIWsCPDVyYU/OPho8=`
	//str := `AAAGBPE3AAAAgABOGMEXmsrQz82Oo5kHwz5TpTuOO/UeI8H6024vMoErVJciuXWGs1OiAUZCrUiAFjyebN3EygOQiX9B3elH3wNBgZ6yW6RAUGyjP8UNOBhk2Vx72cnx0v9UZmNogR7bbKR074vCwdS7Ee+lwlom5O7tTvDT7H0qlD2pOLamjRBUOmiYjPi9iLba2AM2NmgAxRFaZ6xYK0yM5fV0FT49Z6FTZFFtRBJck72HmCotr5V4NpH+ecaREfqtJluxG6INE1ViASKdGSDrXd9sS1ZcSzn5NDq7DPenFJizOczj2ZBpNVb1p22A6rzft/wBZWoGt/1dCdvH0fJ3FrPiaK9hhLhzl9/UaVBJI9LyNhOBh29zWRuwt9F2BMgbWiRPv7S1nwLQM0nzDHIkg8INGeD36PwpZ42MUIA4BZM9dgR28HrM14UhZnGyv38Tv8pUE0EzEeldKdiKj4VKN7tHpjx3Y3VgH2LHrxDO4/PFNe8VAPzagbdkaexWEOH32xCbDM+Jk0TC7Zp+2Vpek8YBVM5QhktT/n6bF8xnkb9aI/xIH9pa+rG7E6ydeZNzoZD6w6+fH8nYqhudq/yxk+HMasv7CYsAD1FzcB8fq7x1YHFXqQqnYhi+YkD2etqs5gxWravpY4cFoh7VEzLk+3V/uujkkjOlKQzU6Hthebxd5nGITGhzpBi4nvN7Qy6ipnQYKiAoL3+LXHtNpMVvcGg8KZng+kp01qdtTt3WREl77BMvnVlAi9khL70aF65RvUES46OSjJqzdA79oV4/QBgBQYT5CZO7Nz7rKVLRk9oldlKw7tY5VxQeyM1Z0YSEfIl24TLPz121zlo/dbmzusLIqu/bgpvHAbV8xZ9xygBNw+Bxw1tAbsPy55+9rJT2vOrwa9AmfELDX8PVe5ImoSDSjgCcpvm/M99Nno6CTZ+T3KxcdM0qEVn+s5JC/qgbApwDRBXzeYCanGPKr/R/y9wW+V08gqFJOoTGGBhfDrQStGia9+TZjUANk3PVZtA+HJDAlr+uyPWoadPfxyr5w9g1ZA6SQ5qR0OgbuDaIPHewOFmrphRK/s6L3oC8G3UTMwNipqy+IJNi2t8jrYaoX5qWgtzKY7W6x3EudlWP1Yu100Ke803VbQnp1XUdp6Tlw9DUnrz+xSBfAgxqaIISh7Qvt7jkea5SjVkDPuiniHX0x3TbYhIBr+S0gM1zlSy+qyNdeZTPvIVQhw/aeZwb7NO5MBOxMZiZ/CQlr3Gnc7T6Efd2xFrlqpx2jTjwb+mszdb2CjcivdPseeTHFEapQraqQ2PpoSjrbO3mO5fd70+Mvq2uk5Os0ZFEKQ0RV212uRyoA8J7CwgRHwXvv8ZzJfenomNCmvBPsejeXOvXUxlIbuIko1tFRFAZNo0qiiZSoVV2zGWaFNZkEMJ0yFtT0Q+DQt4ldGdq28doaFz2iVT2rmr1/WVGluPWYO6LdtTBlD0J+R28Zpj5fpsevaTZ+EcHywwIQY8H5YI9KHQzrfpn0xtMGEmY0Dp+ZSBzGZEhfuwGAfP422pQzt/xWlMWgFbKPMySM8q1Qfdzzmozx6Y5i7Xe2eXqR22Okkehw2yUcWgsJbYiC7LSiW4+UanKXANN5Nf9zqynrkWDDIy7B78NKksrBDVUEDc9SaspUCN371gnyeiGQjSjrIZm+JQ8pxXGBjnFaBpTAggmMaPpJHBGxF8NE66kSQ/VZruNGTKEFS8dpgvfiT4qontvTHK6BrZRy5j7NXbcDPa7zo7dpvZqN+61DICrJF8dRMxXLnwnbugE0II5ntGRCcce0M8msVX092EpbEwi2/lDIb6saHUy8a/VwFWKDtyTe37+UBbQiL+ZMbMBPQtR0Yj/XD3hhO3vKTOQvHiBkr/FMW0IvBh8OTJx26txolCIqzxpbv5kcA3vo1hyY4UADX6fZyKIdxPa4xF57qLyHJx/CNLr+/H9V6xttKzFlm64zO7TqNFlChvTfaqA2vpGtjpaPxhwkyACqSai2I7HFwjDQgxCQyiE5WPtFNOgJQDS0BP6rgsPisv+FxuR2A==`
	buf, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		t.Fatalf("base64解密错误: %+v.\n", err)
	}

	t.Logf("buf len = %+v, %X.\n", len(buf), buf)

	out, err := aesECBDecrypt(buf, []byte("OkqDu3nfoVGNIyQA"))
	if err != nil {
		t.Fatalf("解密失败: %+v.\n", err)
	}

	t.Logf("decrypted: %+v.\n", string(out))
}

func TestEncryptDeviceID(t *testing.T) {
	//str := `Ezu7xbEKwSVD8vnxOd0PFyBa/Ivsl+9B6C8En949LeoOGiwrrB3iCtC+Tx1U1V9Ij2q0pcN3t+HVPL4naO/8Bg==`
	str := `Ab9Gi+ai2ZbDp6tth5Oyr4XH2TyGHyp0Z4RUMmedw9YGCjNFWCe/s5m6UeEom85o2/e89JinWeCspbXXMKQ0Mg==`
	buf, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		t.Fatalf("base64解密失败: %+v\n", err)
	}

	out, err := aesECBDecrypt(buf, []byte(aesKey))
	if err != nil {
		t.Fatalf("aes解密失败: %+v.\n", err)
	}

	t.Logf("解密数据: %s.\n", string(out))
}

func TestSM2(t *testing.T) {
	data, err := encSM2("123456")
	if err != nil {
		t.Fatalf("sm2加密错误: %+v.\n", err)
	}

	fmt.Println(data)

	pass := "343599"
	ts := fmt.Sprintf("%d", utils.GetTimeStampEx())
	str := fmt.Sprintf("%.2d%s%.2d%s", len(ts), ts, len(pass), pass)
	fmt.Println(str)
}

func TestSM2Key(t *testing.T) {
	pri, err := sm2.GenerateKey()
	if err != nil {
		t.Fatalf("生成key错误: %+v.\n", err)
	}

	fmt.Println(pri.PublicKey.X.Text(16) + pri.PublicKey.Y.Text(16))
	fmt.Println(pri.D.Text(16))

	// pri, pub, err := sm2.GenerateKey(rand.Reader)
	// if err != nil {
	// 	t.Fatalf("生成key错误: %+v.\n", err)
	// }

	// fmt.Println(hex.EncodeToString(pub.GetRawBytes()))
	// fmt.Println(hex.EncodeToString(pri.GetRawBytes()))
}

func TestSM2Decode(t *testing.T) {
	// key, _ := hex.DecodeString("8c266d0ce1ff43b82e938b1d9c6133c31f4690ed4a7635c8a4a63278412fed83")
	// data, _ := hex.DecodeString("04F20886B2923280FC0FC882D85EC649F59394A6994B2E637E82D48C339D16788803B004C97B289272930E74528774D3E1896E97F323BF174504BF8CA1D1E21C2D7956DDE75F6F56718A913BD7B920F5F8E48B61A2BB33B76C571A2DE51678EC688660A370068D0C3FA2E345AD995BFEDA999AF1953E25FA")
	// pri, err := sm2.RawBytesToPrivateKey(key)
	// if err != nil {
	// 	t.Fatalf("private key错误: %+v.", err)
	// }

	// data, err = sm2.Decrypt(pri, data)
	// if err != nil {
	// 	t.Fatalf("解密错误: %+v.", err)
	// }

	// fmt.Println(string(data))

	data, _ := hex.DecodeString("045EBA5D9F48A53D00E0D6CEB4C287FA9B580D7A78E794045A43E3484305073050293968F6163E185D08D99C504A6E9E7B00057E514201E21EDD01CB42EBCD7DD11A284E1EA4D16F0C430D69649F513B79BD5FE8930F37BE58A9E694C4549607B06D24F6EFEC5C8483B8D60AC5CE4379F2836CB7BB60C149")

	pri := new(sm2.PrivateKey)
	pri.Curve = sm2.P256Sm2()
	pri.D, _ = new(big.Int).SetString("d6fdde19dd7370f03128b7f117c3a1745dd284836332190384ba17665bbb31b2", 16)
	data, err := pri.Decrypt(data)
	if err != nil {
		t.Fatalf("sm2解密 错误: %+v.\n", err)
	}


	fmt.Println(string(data))

	fmt.Println(utils.PasswordEncrypt("343599"))
}

func TestCallSo(t *testing.T) {

}
