package pingan

import (
	"bytes"
	"crypto/aes"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/x509"
	"encoding/base64"
	"encoding/binary"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"pay/utils"

	"github.com/howeyc/crc16"

	"github.com/tjfoc/gmsm/sm2"
)

func aesECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = utils.PKCS7Padding(in, c.BlockSize())

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)
		out = append(out, dst...)
	}

	return out, nil
}

func aesECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errors.New("数据长度不正确")
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)
		out = append(out, dst...)
	}

	return utils.PKCS7Trimming(out)
}

func rsaEncrypt(msg []byte, pub *rsa.PublicKey) ([]byte, error) {
	k := pub.Size()
	if len(msg) > k-2 {
		return nil, rsa.ErrMessageTooLong
	}

	// 随机填充数据
	em := make([]byte, k)
	for i := 0; i < len(em); i++ {
		v := byte(utils.RandIntn(255))
		if v == 0 {
			v = 0x42
		}

		em[i] = v
	}

	h := len(msg)
	em[0] = byte(48 + h/10)
	em[1] = byte(48 + h%10)

	for i := 0; i < h; i++ {
		em[i+2] = msg[i]
	}

	m := new(big.Int).SetBytes(em)
	c := new(big.Int)
	e := big.NewInt((int64(pub.E)))

	c.Exp(m, e, pub.N)

	return c.Bytes(), nil
}

func encDeviceID(deviceID string) (string, error) {
	data, err := aesECBEncrypt([]byte("1_1_"+deviceID), []byte(aesKey))
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(data), nil
}

func encLoginPwd(pass string) (string, error) {
	pub, err := utils.PublicKeyFromString(rsaLogin, 65537, 16)
	if err != nil {
		return "", err
	}

	data, err := rsaEncrypt([]byte(pass), pub)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%X", data), nil
}

func encPayInfo(cardNo, amount string) (string, error) {
	pub, err := utils.PublicKeyFromString(rsaCard, 65537, 16)
	if err != nil {
		return "", err
	}

	data, err := rsaEncrypt([]byte(cardNo+"|"+amount), pub)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%X", data), nil
}

func encVerifyInfo(cardNo, amount, cardSign string) (string, error) {
	h := sha1.New()
	_, err := h.Write([]byte(amount + cardNo + cardSign))
	if err != nil {
		return "", err
	}

	data := h.Sum(nil)

	return base64.StdEncoding.EncodeToString(data), nil
}

func encSM2(pass string) (string, error) {
	ts := fmt.Sprintf("%d", utils.GetTimeStampEx())
	str := fmt.Sprintf("%.2d%s%.2d%s", len(ts), ts, len(pass), pass)

	// key, err := hex.DecodeString(sm2Key)
	// if err != nil {
	// 	return "", err
	// }

	// pub, err := sm2.RawBytesToPublicKey(key)
	// if err != nil {
	// 	return "", err
	// }

	// data, err := sm2.Encrypt(pub, []byte(str))
	// if err != nil {
	// 	return "", err
	// }

	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()
	pub.X, _ = new(big.Int).SetString(sm2KeyX, 16)
	pub.Y, _ = new(big.Int).SetString(sm2KeyY, 16)

	data, err := pub.Encrypt([]byte(str))
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%X", data[1:]), nil
}

func encAESKey(key []byte) ([]byte, error) {
	block, _ := pem.Decode([]byte(cdataPublicKey))
	publicKeyInterface, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}

	publicKey := publicKeyInterface.(*rsa.PublicKey)
	return utils.RSAEncryptPKCS1v15(key, publicKey)
}

func encCData(data []byte) (string, error) {
	arr := bytes.NewBuffer([]byte{})
	// 生成aeskey
	uuid, _ := utils.NewUUID(true)
	key := []byte(uuid[:16])

	// 加密key
	aesKey, err := encAESKey(key)
	if err != nil {
		return "", err
	}

	// 写入key
	binary.Write(arr, binary.BigEndian, int32(len(aesKey)))
	arr.Write(aesKey)

	// aes加密数据
	data, err = aesECBDecrypt(data, key)
	if err != nil {
		return "", nil
	}

	arr.Write(data)

	// 取出所有数据
	data = arr.Bytes()

	// 清空
	arr.Reset()

	// 写入长度
	binary.Write(arr, binary.BigEndian, int32(len(data)))
	// 写入crc
	binary.Write(arr, binary.LittleEndian, crc16.ChecksumCCITTFalse(data))
	// 写入数据
	arr.Write(data)

	return base64.StdEncoding.EncodeToString(arr.Bytes()), nil
}
