package pingan

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"time"

	jsoniter "github.com/json-iterator/go"

	"github.com/go-http-utils/headers"
)

func (acc *Account) fillHeader(req *http.Request) {
	version := acc.HardwareInfo.SystemVersion
	version1 := strings.Replace(version, ".", "_", -1)
	screenSize := acc.HardwareInfo.ScreenSize
	screenXY := strings.Split(screenSize, "*")
	screenSize = screenXY[1] + "*" + screenXY[0]
	usragent := fmt.Sprintf("User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/%s %s AladdinHybrid/3.5.2 (PAEBank %s) subContracting/%s deviceId/%s deviceType/1 networkState/WIFI  device-dpr/2 device-dr/%s",
		version1, utils.GetIPhoneOSFirmware(version), acc.HardwareInfo.DeviceName, appVersion, subContracting, acc.DeviceID, screenSize)

	// fmt.Println(usragent)
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set("X-Aladdin-Version", "3.5.2")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("X-Plugin-Version", "6.0.6")
	req.Header.Set("X-App-Version", appVersion)
	req.Header.Set("X-Plugin-Name", "member")

	req.Header.Set(headers.UserAgent, usragent)
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")

	req.Header.Set(headers.CacheControl, "no-cache")
	if req.Method == http.MethodPost {
		req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=utf-8") //x-www-form-urlencoded")
	}
}

func (acc *Account) getCData() []byte {
	// {
	// 	"sdk_version" : "IOS-4.6",
	// 	"wifiIp" : "192.168.8.110",
	// 	"systemVersion" : "12.4",
	// 	"Btime" : 233399,
	// 	"blueMac" : "",
	// 	"sysName" : "iphone",
	// 	"disk.in.tsize" : 62438516,
	// 	"currentTime" : "2019-11-19 22:03:00",
	// 	"token" : "93F80DBA-F3E6-478E-ABC8-9D2DE6734253",
	// 	"batStatus" : "full",
	// 	"eventType" : "dev_finger",
	// 	"imsiId" : "",
	// 	"ads.enable" : 1,
	// 	"clientSensorInfo" : "",
	// 	"template" : "as_packet",
	// 	"wifiMac" : "",
	// 	"scr_bri" : 44,
	// 	"pin" : "",
	// 	"dbg.gdb" : -1,
	// 	"location" : "",
	// 	"phoneNo" : "",
	// 	"app.ver" : "4.23.1",
	// 	"clientIp" : "10.171.166.252",
	// 	"dis.w" : 1125,
	// 	"appid" : "",
	// 	"dns1" : "192.168.8.1",
	// 	"ads.id" : "EB707E26-9549-4118-9AAB-053E892E4D31",
	// 	"timeZ" : "Asia\/Taipei",
	// 	"name" : "iPhone Work",
	// 	"dis.h" : 2436,
	// 	"net_type" : "CTRadioAccessTechnologyLTE",
	// 	"isBatUsage" : "true",
	// 	"clientAppList" : "",
	// 	"disk.in.usize" : 17173792,
	// 	"vendor_id" : "6EC681AE-AB60-4B0B-98BC-AC9639D3A424",
	// 	"wifi_sid" : "",
	// 	"v.earP" : -1,
	// 	"dis.orient" : 0,
	// 	"root" : 1,
	// 	"token_ctime" : "1574170077",
	// 	"deviceId" : "93F80DBA-F3E6-478E-ABC8-9D2DE6734253",
	// 	"mem.tsz" : 2890752,
	// 	"imeiId" : "",
	// 	"localizedModel" : "iPhone",
	// 	"v.sys" : -1,
	// 	"appstoreId" : -1,
	// 	"batLevel" : 100,
	// 	"app.name" : "com.pingan.creditcard",
	// 	"cellno" : "",
	// 	"gatway" : "192.168.8.1",
	// 	"model" : "iPhone",
	// 	"cpu.count" : 6,
	// 	"typeName" : "iPhone10,6",
	// 	"networkOperator" : "46697",
	// 	"simSerial" : ""
	// }

	screenArr := strings.Split(acc.HardwareInfo.ScreenSize, "*")
	screenW, _ := strconv.Atoi(screenArr[0])
	screenH, _ := strconv.Atoi(screenArr[1])
	ipArr := strings.Split(acc.HardwareInfo.CellularIP, ".")
	cdata := map[string]interface{}{
		"sdk_version":      "IOS-4.6",
		"wifiIp":           acc.HardwareInfo.CellularIP,
		"systemVersion":    acc.HardwareInfo.SystemVersion,
		"Btime":            20000 + rand.Intn(40000),
		"blueMac":          "",
		"sysName":          "iphone",
		"disk.in.tsize":    62438516,
		"currentTime":      time.Now().Format("2006-01-02 15:04:05"),
		"token":            acc.HardwareInfo.CDataToken,
		"batStatus":        "full",
		"eventType":        "dev_finger",
		"imsiId":           "",
		"ads.enable":       1,
		"clientSensorInfo": "",
		"template":         "as_packet",
		"wifiMac":          "",
		"scr_bri":          40 + 10*rand.Intn(5), // 屏幕亮度
		"pin":              "",
		"dbg.gdb":          -1,
		"location":         "",
		"phoneNo":          "",
		"app.ver":          appVersion,
		"clientIp":         "",
		"dis.w":            screenW,
		"appid":            "",
		"dns1":             fmt.Sprintf("%s.%s.%s.1", ipArr[0], ipArr[1], ipArr[2]),
		"ads.id":           acc.HardwareInfo.CDataAdsID,
		"timeZ":            "Asia/Shanghai",
		"name":             acc.HardwareInfo.CDataName,
		"dis.h":            screenH,
		"net_type":         "",
		"isBatUsage":       "true",
		"clientAppList":    "",
		"disk.in.usize":    12000000 + rand.Intn(5000000),
		"vendor_id":        acc.HardwareInfo.CDataVendorID,
		"wifi_sid":         "",
		"v.earP":           -1,
		"dis.orient":       0,
		"root":             0,
		"token_ctime":      fmt.Sprintf("%d", time.Now().Unix()),
		"deviceId":         acc.HardwareInfo.CDataDeviceID,
		"mem.tsz":          2890752,
		"imeiId":           "",
		"localizedModel":   "iPhone",
		"v.sys":            -1,
		"appstoreId":       -1,
		"batLevel":         50 + rand.Intn(50),
		"app.name":         "com.pingan.creditcard",
		"cellno":           "",
		"gatway":           fmt.Sprintf("%s.%s.%s.1", ipArr[0], ipArr[1], ipArr[2]),
		"model":            "iPhone",
		"cpu.count":        6,
		"typeName":         acc.HardwareInfo.Model,
		"networkOperator":  "",
		"simSerial":        "",
	}

	arr, _ := json.Marshal(cdata)

	return arr
}

func (acc *Account) getPaFingerprint() string {
	screenArr := strings.Split(acc.HardwareInfo.ScreenSize, "*")
	fpData := map[string]interface{}{
		"a1": "com.pingan.creditcard",
		"a2": appVersion,
		"a3": "1.5.1", // 什么版本
		"a4": "I",
		"a5": acc.HardwareInfo.SystemVersion,
		"a6": acc.HardwareInfo.FPDataA6,
		"a8": 0,
		"b1": "wifi",
		"b7": "",
		"b8": "",
		"e8": map[string]int{
			"e9": 0,
			"g3": 0,
		},
		"f2": time.Now().Unix()*1000 + int64(rand.Intn(1000)),
		"g5": acc.HardwareInfo.CDataVendorID,
		"g6": acc.HardwareInfo.Model,
		"g7": acc.HardwareInfo.CDataName,
		"g8": 2,
		"g9": 16777228, // 什么鬼
		"h1": 1,
		"h2": fmt.Sprintf("%s*%s", screenArr[1], screenArr[0]),
		"h3": 63937040384, //好像是存储大小 64G?
		"h4": 46351081472 + rand.Intn(1073741824),
		"h5": 7,
		"h6": "zh-Hans-CN",
		"h7": 1,
		"h8": 2,
		"i1": "CN",
		"i2": time.Now().Unix() - int64(12354+rand.Intn(1000)),
		"i3": []string{
			"zh_Hans-Pinyin@sw=Pinyin-Simplified",
			"zh_Hans-Pinyin@sw=Pinyin10-Simplified",
			"en_US",
		},
		"j8": 0,
		"l1": 0,
		"l2": 2,
		"l3": []string{
			"PAEBank",
			"ALDLFScreenAV",
			"libPATestDylib.d",
			"libbz2.1.0.d",
			"libSystem.B.d",
			"libobjc.A.d",
			"libc++abi.d",
			"libc++.1.d",
			"libiconv.2.d",
			"libcharset.1.d",
			"libicucore.A.d",
			"libresolv.9.d",
			"libstdc++.6.d",
			"libxml2.2.d",
			"libz.1.d",
			"libMobileGestalt.d",
			"libenergytrace.d",
			"libbsm.0.d",
			"libarchive.2.d",
			"liblzma.5.d",
			"libnetwork.d",
			"libpcap.A.d",
			"libcoretls.d",
			"libcoretls_cfhelpers.d",
			"libsqlite3.d",
			"libapple_nghttp2.d",
			"libCRFSuite.d",
			"liblangid.d",
			"libcompression.d",
			"libate.d",
			"libauthinstall.d",
			"libamsupport.d",
			"libReverseProxyDevice.d",
			"libSERestoreInfo.d",
			"libutil.d",
			"libAccessibility.d",
			"libFosl_dynamic.d",
			"libtailspin.d",
			"libdscsym.d",
			"libCTGreenTeaLogger.d",
			"libAudioStatistics.d",
			"libAWDSupportFramework.d",
			"libprotobuf.d",
			"libprotobuf-lite.d",
			"libTelephonyUtilDynamic.d",
			"liblockdown.d",
			"libmis.d",
			"libcupolicy.d",
			"libcmph.d",
			"libmecab_em.d",
			"libgermantok.d",
			"libThaiTokenizer.d",
			"libChineseTokenizer.d",
			"libtidy.A.d",
			"libheimdal-asn1.d",
			"libsandbox.1.d",
			"libMatch.1.d",
			"libnetworkextension.d",
			"libboringssl.d",
			"libusrtcp.d",
			"libtzupdate.d",
			"libIOAccessoryManager.d",
			"libsysdiagnose.d",
			"libmecabra.d",
			"libAXSpeechManager.d",
			"libAXSafeCategoryBundle.d",
			"libxslt.1.d",
			"libobjc-trampolines.d",
			"liblog_network.d",
		},
	}

	arr, _ := json.Marshal(fpData)
	arr, _ = aesECBEncrypt(arr, []byte(fpKey))

	return base64.StdEncoding.EncodeToString(arr)
}

func (acc *Account) generateBindToken() error {
	u := fmt.Sprintf("%s?deviceId=%s&channelId=netbank&responseDataType=JSON&subContracting=%s",
		urlGenerateBindToken, acc.DeviceID, subContracting)
	req, err := http.NewRequest("GET", u, nil)
	if err != nil {
		logger.Errorf("[PINGAN]generateBindToken创建http请求错误: %+v.", err)
		return pay.ErrCreateHTTPRequest
	}

	acc.fillHeader(req)

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[PINGAN]generateBindToken http操作错误: %+v.", err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return pay.ErrOperationTimeout
		}

		return pay.ErrOperationError
	}

	logger.Debugf("[PINGAN]generateBindToken返回: %s.", body)

	res := bindTokenRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[PINGAN]generateBindToken响应数据反序列化错误: %+v.", err)
		return pay.ErrUnmarshalResponseData
	}

	if res.ResponseCode != resCodeSuccess {
		logger.Warnf("[PINGAN]generateBindToken返回失败, 代码: %s, 信息: %s.", res.ResponseCode, res.ResponseMsg)
		return errors.New(res.ResponseMsg)
	}

	acc.bindToken = res.BindToken

	return nil
}

func (acc *Account) postData(url, data string, res interface{}) (string, error) {
	// 创建请求
	req, err := http.NewRequest("POST", url, strings.NewReader(data))
	if err != nil {
		logger.Errorf("[PINGAN][%+v]创建http请求错误, url: %s, data: %s, err: %+v.", acc.Account, url, data, err)
		return "", pay.ErrCreateHTTPRequest
	}

	// 填充头部
	acc.fillHeader(req)

	// http操作
	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[PINGAN][%+v]http操作错误, url: %s, data: %s, err: %+v.", acc.Account, url, data, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	logger.Debugf("[PINGAN][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, url, data, body)

	if strings.TrimSpace(body) == "" {
		logger.Warnf("[PINGAN][%+v]登录会话超时.", acc.Account)
		return "", pay.ErrSessionTimeout
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			logger.Errorf("[PINGAN][%+v]反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (acc *Account) userPwdLogin() (*userPwdLoginRes, error) {
	loginPwd, err := encLoginPwd(acc.getPassword())
	if err != nil {
		logger.Errorf("[PINGTAN][%+v]加密用户密码错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	encDeviceID, err := encDeviceID(acc.DeviceID)
	if err != nil {
		logger.Errorf("[PINGAN][%+v]加密DeviceID错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	cdata, err := encCData(acc.getCData())
	if err != nil {
		logger.Errorf("[PINGAN][%+v]加密cdata数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	values := url.Values{}
	values.Set("userId", acc.Account)
	values.Set("loginPwd", loginPwd)
	values.Set("deviceToken", acc.DeviceToken)
	values.Set("appId", appID)
	values.Set("appVersion", appVersion)
	values.Set("channelId", "netbank")
	values.Set("partnerId", "")
	values.Set("mahId", "")
	values.Set("deviceName", "iPhone")
	values.Set("deviceVersion", acc.HardwareInfo.DeviceName)
	values.Set("deviceId", acc.DeviceID)
	values.Set("encryptDeviceId", encDeviceID)
	values.Set("deviceType", "ios")
	values.Set("osVerdion", acc.HardwareInfo.SystemVersion)
	values.Set("vcode", "6666")
	values.Set("pwdEncryptionType", "0")
	values.Set("bindToken", acc.bindToken)
	values.Set("cdata", cdata)
	values.Set("paFingerprint", acc.getPaFingerprint())
	values.Set("subContracting", subContracting)

	res := userPwdLoginRes{}
	if _, err := acc.postData(urlUserPwdLogin, values.Encode(), &res); err != nil {
		return nil, err
	}

	// 是否绑定设备
	acc.isBindDevice = res.IsBindDevice

	return &res, nil
}

func (acc *Account) initLoginData() (*initLoginDataRes, error) {
	values := url.Values{}
	values.Set("channelId", "netbank")

	res := initLoginDataRes{}
	if _, err := acc.postData(urlInitLoginData, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) ucCoreOtpSend(reSend string) (*ucCoreOptSendRes, error) {
	values := url.Values{}
	values.Set("appId", appID)
	values.Set("appVersion", appVersion)
	values.Set("channelId", "netbank")
	values.Set("deviceId", acc.DeviceID)
	values.Set("deviceType", "ios")
	values.Set("deviceVersion", acc.HardwareInfo.DeviceName)
	values.Set("msgType", "4")
	values.Set("reSend", reSend)
	values.Set("deviceToken", deviceToken)
	values.Set("deviceName", "iPhone")
	values.Set("mobileNo", "")
	values.Set("ibdMobileNo", "")
	values.Set("subContracting", subContracting)

	res := ucCoreOptSendRes{}
	if _, err := acc.postData(urlOTPSend3, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) bindDevice(code string) (*bindDeviceRes, error) {
	values := url.Values{}
	values.Set("channelId", "netbank")
	values.Set("deviceId", acc.DeviceID)
	values.Set("deviceType", "ios")
	values.Set("deviceVersion", acc.HardwareInfo.DeviceName)
	values.Set("deviceToken", deviceToken)
	values.Set("deviceName", "iPhone")
	values.Set("otpCode", code)
	values.Set("isFrequentlyUsedDevice", "0")
	values.Set("bindToken", "")
	values.Set("subContracting", subContracting)

	res := bindDeviceRes{}
	if _, err := acc.postData(urlBindDevice, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryBalance() (*queryBalanceRes, error) {
	values := url.Values{}
	values.Set("whiteFlag", "1")

	res := queryBalanceRes{}
	if _, err := acc.postData(urlQueryBalanceInfo, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryTranList(startDate, endDate string, page int) (*queryTranListRes, error) {
	values := url.Values{}
	values.Set("accNum", acc.bankCardSign)
	values.Set("bankType", "0")
	values.Set("currType", "RMB")
	values.Set("startDate", startDate)
	values.Set("endDate", endDate)
	values.Set("pageIndex", strconv.Itoa(page))
	values.Set("pageSize", "10")

	res := queryTranListRes{}
	if _, err := acc.postData(urlQueryTranList, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryAllBankInfo(cardNo string) (*queryAllBankInfoRes, error) {
	values := url.Values{}
	values.Set("cardNo", cardNo)

	res := queryAllBankInfoRes{}
	if _, err := acc.postData(urlQueryAllBankInfo, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) validateBindRelation(cardSign, account, name string) (*validateBindRelationRes, error) {
	values := url.Values{}
	values.Set("outBankCardSign", cardSign)
	values.Set("rollBankCardSign", account)
	values.Set("rollBankClientName", name)

	res := validateBindRelationRes{}
	if _, err := acc.postData(urlValidateBindRelation, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getTransferTimeliness(cardNo, amount, unionBankCode, bankCode string) (*transferTimelinessRes, error) {
	values := url.Values{}
	values.Set("amount", amount)
	values.Set("unionBankCode", unionBankCode)
	values.Set("recAcctNo", cardNo)
	values.Set("executeType", "0")
	values.Set("bankCode", bankCode)

	res := transferTimelinessRes{}
	if _, err := acc.postData(urlGetTransferTimeliness, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) transferRoute(payInfo, name, bankCode, bankName, cardSign, unionBankCode, comment, verifyInfo, executeType, limitConfirmFlag string) (*transferRouteRes, error) {
	values := url.Values{}
	values.Set("deviceId", acc.DeviceID)
	values.Set("deviceModel", acc.HardwareInfo.DeviceName)
	values.Set("appVersion", appVersion)
	values.Set("isSupportedFingerprint", "0")
	values.Set("isInstallCert", "0")
	values.Set("payeeInfo", payInfo)
	values.Set("transferVersion", "20180607")
	values.Set("accountName", name)
	values.Set("assistantUnionBank", "")
	values.Set("bankCode", bankCode)
	values.Set("bankName", bankName)
	values.Set("channelType", "4")
	values.Set("cityCode", "")
	values.Set("cityName", "")
	values.Set("currType", "RMB")
	values.Set("fromBankCardSign", cardSign)
	values.Set("isNeedBind", "0")
	values.Set("provinceCode", "")
	values.Set("provinceName", "")
	values.Set("subBranchBankName", "")
	values.Set("unionBankCode", unionBankCode)
	values.Set("userRemark", comment)
	values.Set("recMobileNo", "")
	values.Set("verifyInfo", verifyInfo)
	values.Set("executeType", executeType)
	values.Set("isFromPok", "1")
	values.Set("suspectedLaunderingOrderNo", "")

	res := transferRouteRes{}
	if _, err := acc.postData(urlTransferRoute, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) commonPasswordCheck(pass, orderNo, verifyType string) (*commonPasswordCheckRes, error) {
	values := url.Values{}
	values.Set("password", pass)
	values.Set("orderNo", orderNo)
	values.Set("verifyType", verifyType)

	res := commonPasswordCheckRes{}
	if _, err := acc.postData(urlCommonPasswordCheck, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) commonOTPSend(orderNo string) (*commonOTPSendRes, error) {
	values := url.Values{}
	values.Set("orderNo", orderNo)
	values.Set("verifyType", "3")

	res := commonOTPSendRes{}
	if _, err := acc.postData(urlCommonOTPSend, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) commonOTPCheck(orderNo, code string) (*commonOTPCheckRes, error) {
	values := url.Values{}
	values.Set("otp", code)
	values.Set("orderNo", orderNo)
	values.Set("verifyType", "3")

	res := commonOTPCheckRes{}
	if _, err := acc.postData(urlCommonOTPCheck, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) transferNewConfirm(reqToken, orderNo, duplicateConfirmFlag string) (*transferNewConfirmRes, string, error) {
	values := url.Values{}
	values.Set("rejectConfirmFlag", "")
	values.Set("duplicateConfirmFlag", duplicateConfirmFlag)
	values.Set("repeatSubmitFlag", "")
	values.Set("appVersion", appVersion)
	values.Set("channelType", "4")
	values.Set("reqToken", reqToken)
	values.Set("baoOrderNo", orderNo)

	res := transferNewConfirmRes{}
	body, err := acc.postData(urlTransferNewConfirm, values.Encode(), &res)
	if err != nil {
		return nil, "", err
	}

	return &res, body, nil
}

func (acc *Account) queryResult(orderSerialNo string) (*queryResultRes, error) {
	values := url.Values{}
	values.Set("orderSerialNo", orderSerialNo)

	res := queryResultRes{}
	if _, err := acc.postData(urlQueryResult, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}
