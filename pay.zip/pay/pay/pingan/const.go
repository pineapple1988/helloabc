package pingan

const (
	paAccountKey        = "PINGANAccount"
	paCookieKey         = "PINGANCookie"
	platformIOS         = "ios"
	platformAndroid     = "android"
	appID               = "com.pingan.creditcard"
	appVersion          = "4.25.0"
	subContracting      = "AppStore"
	deviceType          = "ios"
	deviceToken         = "0ccf719017f805f0c87d31fa1e6fad77424e0cb7146aa14c7b1457201f4d47a0"
	resCodeSuccess      = "000000"
	timerUpdate         = 1000
	timerUpdateInterval = 1000
)

const (
	rsaLogin       = "BB955F6C6185B341C1A42EBF1FF9971B273878DBDAB252A0F1C305EBB529E116D807E0108BE6EDD47FF8DC5B6720FFE7F413CBB4ACDFB4C6BE609A5D60F5ADB261690A77755E058D4D9C0EC4FC2F5EB623DEBC88896003FBD8AFC4C3990828C66062A6D6CE509A2B0F8E06C4E332673FB86D235164B62B6110C1F1E0625B20ED"
	rsaCard        = "B58B78770584C572039DDDCC56744E77FF57005C75E870956FF510F23DF028A9ABCFDE60B1DE98035007396FDD126FB1016A8D1D902634464D5727CD769E381FADC0761D26847EC6CEE07F435447AA9F712509CF010FCEDF2671B59F8E35D2B209B8FEC40A402A4A38219EC992ED6DBEA8D9C7C2A5A9C4AE7FF3A913BE04BCEB"
	sm2KeyX        = "76D26598B8F8FBAFB714DC2324DDC8184B384F9FFAA8F9BF0B87BFD5EC1DCF20"
	sm2KeyY        = "2753FBFBCB99D89A2A356FEC8216765702B50C0C4F92C85D01EB42719B30238C"
	aesKey         = "a2b7f63cad25648d"
	cdataKey       = "2DC59AE1-AECB-46"
	fpKey          = "OkqDu3nfoVGNIyQA"
	cdataPublicKey = "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChrjU60beCTmSQ84T0B3AYAg8y+9xh3oK3Ay9JvD+GnXAzffa7poSQ4xYYvO96yqG+K8sDSDI13IjKiP/V36rONGO94U/X59EqXDhgyRLM14hsyiUAtzEstf0W/+uP1KALP8lTEM0O6MwhC/zx+Ju921FO3tJIZtwn8S8E12EPzQIDAQAB\n-----END PUBLIC KEY-----\n"
)

const (
	urlGenerateBindToken     = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-login-web.generateBindToken.do" //更新成ios
	urlUserPwdLogin          = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-login.userPwd-login.do"         //更新成ios
	urlInitLoginData         = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-ibank.initLoginData.do"         //更新成ios
	urlOTPSend3              = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-core.otp-send3.do"              //更新成ios
	urlBindDevice            = "https://rmb.pingan.com.cn/brcp/uc/cust/uc-member.bind-device.do"          //更新成ios
	urlQueryBalanceInfo      = "https://rmb.pingan.com.cn/brop/acct/cust/qry/qryBalanceInfo.do"           //IOS没找到这个包
	urlQueryAllBankInfo      = "https://rmb.pingan.com.cn/brac/ia/acctweb/rest/queryAllBankInfo"          //IOS没找到这个包
	urlValidateBindRelation  = "https://rmb.pingan.com.cn/brop/acct/cust/traf/validateBindRelation.do"    //更新成ios
	urlGetTransferTimeliness = "https://rmb.pingan.com.cn/brop/acct/cust/traf/getTransferTimeliness.do"   //更新成ios
	urlTransferRoute         = "https://rmb.pingan.com.cn/brop/acct/cust/traf/transferRouteFP.do"         //更新成ios  channelType 这里是4 安卓是5
	urlCommonPasswordCheck   = "https://rmb.pingan.com.cn/brop/acct/cust/traf/commonPasswordCheck.do"     //更新成ios
	urlCommonOTPSend         = "https://rmb.pingan.com.cn/brop/acct/cust/traf/commonOTPSend.do"           //更新成ios
	urlCommonOTPCheck        = "https://rmb.pingan.com.cn/brop/acct/cust/traf/commonOTPCheck.do"          //更新成ios
	urlTransferNewConfirm    = "https://rmb.pingan.com.cn/brop/acct/cust/traf/transferNewConfirmFP.do"    //更新成ios
	urlQueryTranList         = "https://rmb.pingan.com.cn/brop/acct/cust/qry/qryTranList.do"              //这个没更新截包里面没有
	urlQueryResult           = "https://rmb.pingan.com.cn/brop/acct/cust/traf/queryResult.do"             //更新成ios
)

const (
	blockByInfoNotComplete = "个人信息不全导致暂停非柜面转账业务"
	blockByDubiousTrade    = "存在加强账户监测的可疑交易账户"
	blockByReportLost      = "您的账户已挂失"
)
