package bcm

import (
	"crypto/aes"
	cryptoRand "crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	"math/rand"
	"pay/pay/bcm/cryptoutils"
	"pay/utils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"time"

	"github.com/tjfoc/gmsm/sm2"
	"github.com/tjfoc/gmsm/sm4"
)

// @update 密码映射表
const (
	constPayPwdKeysMapForNumber0 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAu3cRRO6qmWZVzDMi3YiIneiHAAABGElEQVQoz8WRzy4DURTGPyZo06IVe1L2RsJS9A0q8QBT8QDTjTUrK4nGC1hYWWksrbyBV/AIGqpMop/z594Kuu9vMWd+c+98c+ccGDuNxmaKMecUio2oDzQGXdcSA0P3S0Y6qpVMVpq4l/KhPkN+9aRuS4J+o0UeQlkj16XkZNN8lzwAErIPY5b8BMp6FWxlBCyRL0AIKCy+FnyLTLGsqU5Lk5/IM1e79YeGbVXvBZ8T1xA3i27/8drU/frX+Z8n/U83+L74v34sku2ffj1iXrvu5BxY199ck4zvQHU855IP9C42bI989fHfmJ+SHX88TG18vrEs9Rao5OQo7mO/njG+t8BAkcZzOcdwqiemq4gkV0f1lQtM4hu69vSagXYf3AAAAABJRU5ErkJggg=="
	constPayPwdKeysMapForNumber1 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAKlBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnobgeY4AAAADXRSTlMARLt3ZiLdzO6IVTMRxaP8XQAAAERJREFUKM9jwAkWGweg8GvvCiBzWe+i8pnR+HtR+ay5qHyJu8h8Hqe7SHznSbV3kfm6QDYpfGdjIDBDcw/TKH9Y86EAAEeyYwPMrmRxAAAAAElFTkSuQmCC"
	constPayPwdKeysMapForNumber2 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAd2ZEEbvumSJV3YgzzKrEq9DrAAABCElEQVQoz22RsU0DQRBFF/kQdoDgaICLEBnQgYUEAQlGFOCE/EoA0QB0QAkmIMcxCUgkZAQUYAwyIBv5eXY959k9+Serp5n/Z27OLVV2kG/1DQ/fgZ+PClslQefKl6g2A65SaRL4EUa77roL3Ao2JKrwr6RczNu/Q98xDOV51hzfOA72sc25cq7HRPkuBMK/8qk4vetTeUP5pcYd5RvPzTwvLG/fqXReO8ImTI108bS9E+Ea0DfMBvAVlZ+Ae8MVwaFho6dXUrNk82blnbT7SHBks1qlmlV7wEO62KtLyr/taDRQROWTdG+3nZazUq9iH/IX83p1FftJZ/lC/uixJL7Ggxp3U65rBgkS4kbuc0BfAAAAAElFTkSuQmCC"
	constPayPwdKeysMapForNumber3 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAuxFEdzPuzFXdmYhmqiJ3imbUAAABPklEQVQoz22SPy8EQRTAx7mLwvmzlAo6UUgkJ1oSCo3cJjQqCur7CIf4AMIHWA3tUaj5Br6A5JRCwYrsnXPn5+3szOzcxS/ZN/nt7Ly8eW+VpnS6sRkqx1uE8GS1SMZFpoU6hhvt81h+tDehc6JeGsCR6DC00twlOXYm6xCc23NtWfZAtrMPO7JUJWbUiSXO0jZ+DxLhw3g19XHJ6rtkmTTepCXVViqhqbsmmT1G4df3R30hx6vUPWdlu7IFTFmVooQD1e93A8608yDQbx5Uzk4NuspjEZJnK6aRl74vwKfv5YEEBTsB5TVwVR5XlfbvPn8Hd8uInprIq5TWfqmxvJ/FdGBlCcZlcvtpV5PQ/RdregqH2lcgkdQjwJXsHpOdLNWAOIhcP3axdLM8DaNxaOq41tpbUpbl22BmXf3HH+f06aO0zUD0AAAAAElFTkSuQmCC"
	constPayPwdKeysMapForNumber4 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAu3fuEd2IMyLMqlVEZpkA6lweAAAAoElEQVQoz83RsQnCUBhF4RcRE407GB5YShqLdCqSPdwgI1g4iCPoJo4gjhAkBkU4PrS5f8DCztN9cLvrvpZ4bxyBcW4dYz3suLIeY11yNT5wUac0K/WOZ6SesFH3aJbqLa0T9/dk6gF3pz7RqvsLMvUozNVnCnUS5uqI2qlzCnUMmbrk4dQVc3UKR/U6zNU5N/9uCt7PgrX6V3f//19/egE5U7kINDbBGgAAAABJRU5ErkJggg=="
	constPayPwdKeysMapForNumber5 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAu3dmRIgR3e4imVUzqswsG7TrAAABGElEQVQoz42QPU7DQBCFN4FEQgpEvgCOjECiQEEUtIloaOkpYsEF4AQWP324QbgB3CA01DmCuQEYC9khgo+sx168S8NrVt9KM/PeU3/V8oyeNHcxGmqeOTx1uM+3Ne/zZu2PeLEY7uu4Cr06N2Fo2YOwzg0ya12XxOIJ7xZPWahnn+S05D7zY7SuZW1Miui24FeM9sUuXAV7EbAQu9yEy9eHfPmuQBKK7yJYy8QbwFypzlHwG+RD1dQeO0ke4M5y7jQxcZrq/ocPgt2KZzqRT1rxQO8f8VlxDPozDwXX4Ks4eiK8jh5tQGrGL6SPnuQXuyPIDpU6j8q4GwCXm1AW044RVYebY8H8UYnOIoBsxwTpbHvellTj6gfhU95IHDAAOQAAAABJRU5ErkJggg=="
	constPayPwdKeysMapForNumber6 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAd0S7Zu7dETOIIsyZqlVFh1xDAAABWklEQVQoz22Rv0oDQRDGxxjNRdGYQkmXcKiITcRUVrGyFcFCLIw+wR2ClY0WFnaC9h74AOIT3OET+AbBJ4iJuYt/op+zs3MmhPyKW37szszud2RZLhbX6Z9ME8yTrzpTh3CkvgJlWzSLlK74FZCUyFkE4oA15wELZuWmEa8T6blJoMfLGW/bMcAvL2UkZGnik7+ePS4770QOcKx+6q5Juxv1tGtl2AsADfPITRjX1ddV8UN07QHJsw5p0wOETfX5hqi95z06LSh99jq6DSR37qsngbDHiM3BLFcdGgcOyHDOBdYv7Hv5QGC8TZZdnmC8pz4FbHAIeFGfA96orHHZJL+MV9QzQIdaI14d8YLcUsia+tlBfnnTPz/Id9rMd0yRRiWjQ3yrh0Agt460XKLlhn2fJCl8kPwwnPiU27EBSgGSWij56TWUiIRV1X2y5JZE93xKubytbZVoHH81kQsJ/qG7EgAAAABJRU5ErkJggg=="
	constPayPwdKeysMapForNumber7 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAu3fuESLdZlXMqohEM5n+k1RhAAAAr0lEQVQoz5WQSw4BURBFXwsSn6RZgd5BmxhKS4ysgoG53gE7YCcswQ4MLIAt+Mf3mN5Xb8KdnaTq1kk5m6ipyV2MJvmbJVs+iqWMhfKAe0+5RVexBrnyPGgbK0cwU055mPGOGU/89pMnM+GmWICRct/Ipf56MeNo1i/KZdh71438kqsnD09T91auGLshrHw7W4/TwEGxTmD/Uq7C2ZxvK8fQUN4ZnY35/TR4Jmv3Y75mxJTqzAKZuwAAAABJRU5ErkJggg=="
	constPayPwdKeysMapForNumber8 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAdxG7RMyZ7t0iZqqIM1WEDii3AAABT0lEQVQoz22RTy8DYRDGpxsaKppWJHXrHjgjvWuPbsTNQbYJV1mOEsniC6xvwMXBifgCdRM3PoKTo8qWLSWP+bPvRtM+l5nfZp55Z2ZJtVitzvvk5F2B9THn+BWqtGJYFNAKs3TgtCVYAHDcoucY+BG+AD797Ps5xxBoq69uSYTU+kwBJ0TTZjPDF9EE0BOybJRn//MvB+A993d1vL7xJHDLYQOouPdbHGaAb8FyhIFuHwBr3DfM9qElWbUR5ftSbfge3oJx/9F4HU5aUJIsEb81uAGwx3s+cFzhGAE7RJw0dfJiVqZZSrQMHAnZYJdst7a2SZvqelV3wE1q6rquQZc5cVwYx52h+gPp57t+MuCbPJq/dy/znGUcAE9iGuT2RP8ftnXcEOjZmdN9/l4D26XM7hHLPdQXwulOuRxneEimUqB46lMm72W3sXpN4/QHR+oZiwiIFI0AAAAASUVORK5CYII="
	constPayPwdKeysMapForNumber9 = "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtBAMAAABL8MaSAAAAMFBMVEUAAAAANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnoANnqoxo9aAAAAD3RSTlMAd+5EuzMRmSLM3YhVqmZGyzNAAAABU0lEQVQoz22RvUrDUBTHj8Z++NVaHFyEvoCQqghugnTVBBdHg7or+ADt5uLgJG5xEcc4OLkovkAfQQdfoDHSRpG/95x7borF35CbHwnnnP+5JFw0GptUUH2E4S5ULXcg/ETW96Dcinq+8zTUz+lZVH0HcMkeA9d8vgB9c9SAXAqVfKTmZQYYkrAFLBD1gHvr88AN0ROgg3jAJ1GAL1J89PmROQ/4lbsoTaRjjmjMW5Rg4PyVPUDuPOGBRv1LYO8Bp9Yr4pPAh84vXpE9SD7xqjlWbP6Unbtit8v7eRCvQMmP2SWxcGVKt4zPJbr+unWqxawtOgG69oZWG4uRDCA6ypf/8Y5GdSS8iqP1DdWS7PegKDIr+68X+Q/lZqaK/E1pP+Hye5DyZR/pG/saMNTfsmeifdh0NA1DextAZoeP4QK7vpZvUs591kFIDm+pvbMc0X/8AsD/DU4uHx3rAAAAAElFTkSuQmCC"
)

// SM2PublicKey 通过配置文件SharkCMDSM2PublicKey加密得到的
var SM2PublicKey []byte = []byte{0xb7, 0xef, 0xba, 0x8b, 0xc1, 0xc3, 0xfd, 0xb1, 0xf4, 0x33, 0xca, 0x1a, 0x48, 0x3b, 0x88, 0x78,
	0x08, 0x3f, 0xdc, 0xf9, 0x94, 0x26, 0x65, 0x5a, 0x7c, 0x44, 0xd2, 0x00, 0x5a, 0x56, 0x02, 0x6d,
	0xa1, 0xd4, 0x76, 0xad, 0x20, 0xc2, 0xeb, 0x7e, 0x5f, 0x2a, 0x82, 0xa2, 0x49, 0x99, 0x69, 0xbb,
	0x4a, 0xc7, 0x62, 0x92, 0xf0, 0x67, 0xa8, 0xf0, 0xdc, 0x9e, 0x65, 0x2b, 0x15, 0x6f, 0x6c, 0xcf}

// SM2PublicKeyData .
var SM2PublicKeyData []byte

// 生成SM2加密后的密文
func generateSM2PublicKeyData(encodeKey []byte, SM2Key []byte) []byte {
	x := SM2Key[0:32]
	y := SM2Key[32:]
	data, _ := SM2Encrypt(encodeKey, x, y)
	return []byte(data)
}

// SM2Encrypt SM2加密
func SM2Encrypt(data []byte, x, y []byte) ([]byte, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()

	pub.X = new(big.Int).SetBytes(x)
	pub.Y = new(big.Int).SetBytes(y)

	//fmt.Printf("%v\n", pub.Curve.IsOnCurve(pub.X, pub.Y)) // 验证是否为sm2的曲线

	data, err := pub.Encrypt(data)
	if err != nil {
		return nil, err
	}

	return data[1:], nil
}

// generateRandomEncodeKey 生成sm4用的随机EncodeKey
func generateRandomEncodeKey() []byte {
	//以时间作为初始化种子
	rand.Seed(time.Now().UnixNano())

	var encodeKeyBytes []byte
	for i := 0; i < 16; i++ {
		randInt := rand.Intn(95) //0x5F

		// 生成[32,127)之间的随机数
		encodeKeyBytes = append(encodeKeyBytes, byte(randInt+32))
	}

	return encodeKeyBytes
}

// SM4ECBEncrypt SM4 ECB模式加密
func SM4ECBEncrypt(buf, key []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	buf = utils.PKCS7Padding(buf, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(buf); i += c.BlockSize() {
		src := buf[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

///////////////////////
// 登录及支付密码加密
///////////////////////

func generateRandomAESKey(keyLength int) []byte {
	//以时间作为初始化种子
	rand.Seed(time.Now().UnixNano())

	var encodeKeyBytes []byte
	for i := 0; i < keyLength; i++ {
		randInt := rand.Intn(95) //0x5F

		// 生成[32,127)之间的随机数
		encodeKeyBytes = append(encodeKeyBytes, byte(randInt+32))
	}
	return encodeKeyBytes
}

// BytesToHexString 将Bytes转换为大写的16进制字符串
func BytesToHexString(data []byte) string {
	return strings.ToUpper(hex.EncodeToString(data))
}

// RSAEncrypt RSA加密
func RSAEncrypt(origData []byte, publicKey string) ([]byte, error) {
	// 将字符串公钥Base64_Decode
	publicKeyBytes, err := base64.StdEncoding.DecodeString(publicKey)
	if err != nil {
		return nil, err
	}
	// 解析公钥
	pubInterface, err := x509.ParsePKIXPublicKey(publicKeyBytes)
	if err != nil {
		return nil, err
	}
	// 类型断言
	pub := pubInterface.(*rsa.PublicKey)

	//加密
	return rsa.EncryptPKCS1v15(cryptoRand.Reader, pub, origData)
}

// AESECBEncryptBase AES ECB模式加密
func AESECBEncryptBase(password string, key []byte, size int) (string, error) {
	// size 只有16 24 32三种取值, 分别对应128 192 256
	tool := cryptoutils.NewAesTool(key, size)
	encryptedData, err := tool.AESECBEncrypt([]byte(password))
	if err != nil {
		return "", nil
	}

	encryptedString := BytesToHexString(encryptedData)
	return encryptedString, nil

}

// AES256ECBEncrypt AES ECB 256加密
func AES256ECBEncrypt(password string, key []byte) (string, error) {
	return AESECBEncryptBase(password, key, 32)
}

// AES128ECBEncrypt AES ECB 128加密
func AES128ECBEncrypt(password string, key []byte) (string, error) {
	return AESECBEncryptBase(password, key, 16)
}

// DecryptAES128ECB ECB模式解密
func DecryptAES128ECB(data, key []byte) []byte {
	cipher, _ := aes.NewCipher([]byte(key))
	decrypted := make([]byte, len(data))
	size := 16

	for bs, be := 0, size; bs < len(data); bs, be = bs+size, be+size {
		cipher.Decrypt(decrypted[bs:be], data[bs:be])
	}

	return decrypted
}

// DecryptAES256ECB ECB模式解密
func DecryptAES256ECB(data, key []byte) []byte {
	cipher, _ := aes.NewCipher([]byte(key))
	decrypted := make([]byte, len(data))
	size := 32

	for bs, be := 0, size; bs < len(data); bs, be = bs+size, be+size {
		cipher.Decrypt(decrypted[bs:be], data[bs:be])
	}

	return decrypted
}

// encryptLoginPassword 登录密码加密
func encryptLoginPassword(password string, publicKey string) (string, error) {

	randomKey := generateRandomAESKey(32) //生成32字节的key

	paramAESEncrypted, err := utils.AESECBEncrypt([]byte(password), randomKey)
	if err != nil {
		return "", fmt.Errorf("AES加密错误: %+v", err)
	}

	paramAES := BytesToHexString(paramAESEncrypted)

	encryptedData, err := RSAEncrypt(randomKey, publicKey)
	if err != nil {
		return "", fmt.Errorf("RSA加密错误: %+v", err)
	}
	paramRSA := BytesToHexString(encryptedData)

	if len(paramAES) != 32 {
		return "", fmt.Errorf("AES加密校验错误, 不正确的长度: %d", len(paramAES))
	}

	if len(paramRSA) != 512 {
		return "", fmt.Errorf("RSA加密校验错误, 不正确的长度: %d", len(paramRSA))
	}

	return fmt.Sprintf("%s %s", paramAES, paramRSA), nil
}

// encryptPayPassword 支付密码加密
func encryptPayPassword(password string, keyMapsInfo *modelPayPasswordKeyMaps) (string, error) {

	password = strings.TrimSpace(password)

	publicKey := keyMapsInfo.PublicKey
	keys := keyMapsInfo.Keys

	//从密码表中取对应的值
	newPassword := ""
	for i := 0; i < len(password); i++ {
		currentNo, err := strconv.Atoi(password[i : i+1])
		if err != nil {
			return "", fmt.Errorf("支付密码格式错误，只能为纯数字密码: %s", password)
		}
		newPassword += keyMapsInfo.CorrectedKeys[currentNo]
	}

	randomKey := generateRandomAESKey(32)

	paramAESEncrypted, err := utils.AESECBEncrypt([]byte(newPassword), randomKey)

	if err != nil {
		return "", fmt.Errorf("AES加密错误: %+v", err)
	}
	paramAES := BytesToHexString(paramAESEncrypted)

	encryptedData, err := RSAEncrypt(randomKey, publicKey)
	if err != nil {
		return "", fmt.Errorf("RSA加密错误: %+v", err)
	}
	paramRSA := BytesToHexString(encryptedData)

	if len(paramAES) != 32 {
		return "", fmt.Errorf("AES加密校验错误, 不正确的长度: %d", len(paramAES))
	}

	if len(paramRSA) != 512 {
		return "", fmt.Errorf("RSA加密校验错误, 不正确的长度: %d", len(paramRSA))
	}

	logger.Debugf("[BCM]加密后的支付密码字符串 %s %s:%s:%s", paramAES, paramRSA, publicKey, keys)

	return fmt.Sprintf("%s %s:%s:%s", paramAES, paramRSA, publicKey, keys), nil
}
