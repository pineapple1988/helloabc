package bcm

import (
	"pay/utils"
)

// HardwareInfo 硬件信息
type HardwareInfo struct {
	CFNetworkVersion string // CFNetwork版本
	DarwinVersion    string // Darwin内核版本
	DeviceModel      string // 注册设备第一个包需要用到的 设备型号 "iPhone9,2"
	OSVersion        string // 注册设备第一个包需要用到的 系统版本 "10.3.3"
	HardwareUUID1    string // 注册设备第一个包需要用到的
	HardwareUUID2    string // 注册设备第一个包需要用到的
	GUID             string //
	VIDTicket        string //
	DeviceID         string //
}

var deviceModelArray = []string{
	"iPhone9,1", "iPhone9,2", "iPhone9,3", "iPhone9,4", // 7, 7p
	"iPhone10,1", "iPhone10,4", "iPhone10,2", "iPhone10,5", // 8, 8p
	"iPhone10,3", "iPhone10,6", // x
}

var osVersionArray = []string{
	"11.1", "11.1.2", "11.2", "11.2.1", "11.2.2", "11.2.5", "11.2.6", "11.3", "11.3.1", "11.4", "11.4.1",
	"12.0", "12.0.1", "12.1", "12.1.1", "12.1.2", "12.1.3", "12.1.4", "12.2", "12.3", "12.3.2", "12.4", "12.4.1", "12.4.2", "12.4.3",
	"13.0", "13.1", "13.1.1", "13.1.2", "13.1.3", "13.2", "13.2.2", "13.3", "13.3.1",
}

// GenerateNewHardware 生成一组新的设备信息 @todo CFNetworkVersion的版本号绑定
func (acc *Account) GenerateNewHardware() {

	acc.CFNetworkVersion = "894"
	acc.DeviceModel = deviceModelArray[utils.RandIntn(len(deviceModelArray))] // 随机一个手机型号 "iPhone9,2"
	acc.OSVersion = osVersionArray[utils.RandIntn(len(osVersionArray))]       // 随机一个系统版本 "12.4.1"
	acc.DarwinVersion = OSKernelArray[acc.OSVersion].KernelVersion            // 根据对应的系统找寻对应的Darwin版本

	acc.HardwareUUID1 = utils.NewUUID1(true)
	acc.HardwareUUID2 = utils.NewUUID1(true)
}
