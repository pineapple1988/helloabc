package cryptoutils

import (
	"fmt"
	"testing"
)

//测试AES ECB 加密解密
func TestEncryptDecrypt(t *testing.T) {
	key := []byte{0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F}
	blockSize := 16
	tool := NewAesTool(key, blockSize)
	encryptData, _ := tool.AESECBEncrypt([]byte("32334erew32"))
	fmt.Println(encryptData)
	decryptData, _ := tool.AESECBDecrypt(encryptData)
	fmt.Println(string(decryptData))
}

func transTimeToTime(time string) string {

	if len(time) == 14 {
		formattedTime := time[0:4] + "-" + time[4:6] + "-" + time[6:8] + " " + time[8:10] + ":" + time[10:12] + ":" + time[12:14]
		return formattedTime
	}
	return ""
}

func TestTime(t *testing.T) {
	//20200103210409
	//2020-01-03 21:04:09
	zzz := transTimeToTime("20200103210409")
	fmt.Println(zzz)

}
