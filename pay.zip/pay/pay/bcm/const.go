package bcm

// App
const (
	constAppVersion         = "4.0.0.7"                                                                                          // App Store中的版本号
	constClientVersion      = "IP-UMP-4.0.0-000000"                                                                              // clientVersion
	constHashs              = "ba8c48087d37d4b9e907db11c002f3b679ce57a3,2020010216,2020011023,/annual_account/ndzd/NAA0001.html" // -[BCMAdMB0303Api setHashs:]下断
	constIMEI               = "13131312123113132"                                                                                // 默认的IMEI
	constSharkCMDProductKey = "app-87wnhc41qu"
)

const (
	constUnknowUUID = "03037720010303443961324165937552"
	constVIDTicket  = "020133f0de1610c25f6ad8771bff95bfcf0db9b45faff52648020133f0d6161c4141313931313236323032373338303031303030303236313739393026203033303231393131323632303237333830303130303030323631373938393034414732"
)

// BCMServerConfigProd
const (
	constH5PageURL         = "https://download1.bankcomm.com/mobs4-inner/offline"
	constH5PageURLExternal = "https://mbank.95559.com.cn:8088/offline"
	constMTAUrl            = "https://mbank.95559.com.cn:30027"
	constQAPMAppKey        = "12345678-17098"
	constQAPMHost          = "https://mbank.95559.com.cn:30025"
)

// SharkCenterConfig
const (
	constSharkCMDProductID = "4909"
	//constSharkCMDProductKey   = "app-0r2jeyp990" 废弃的，以app里调试出来的为准
	constSharkCMDSM2PublicKey = "8a2c534af28a6b1320e09521ec0a6763cb0abcd68f675a922ec45f8696b0f057f71b20432e8b40a0ede7fb5a9d1d3f236b082589db28e269669fdaf4aab6808f"
	constSharkCMDURL          = "http://mbank.95559.com.cn:30013/"
)

// Hardware
const (
	constCFNetworkVersion = "894" // CFNetwork库版本, 一般App每个版本这个值是固定的
)

const (
	bcmAccountKey       = "BCMAccount"
	bcmCookieKey        = "BCMCookie"
	timerUpdate         = 1000
	timerUpdateInterval = 5000
)

// TRAN_SUCCESS 状态
const (
	constTranStatusSuccess = "Success"
	constTranStatusFailed  = "Failed"
	constTranStatusEmpty   = "Empty" // 返回结果为空
)

/*
 * @update 几个文件的初始化版本号，每次更新版本后这里是需要修改的
 * 这里的几个参数需要从压缩包里的config.json里获取, 每个版本都是不同的, 每次更新版本后第二个包里对应的版本号也要对应的做修改
 */
const (
	initVersionForStatic   = 4585 // static
	initVersionForLife     = 4562 // life
	initVersionForLoanHome = 4350 // loan_home
	initVersionForHP       = 4347 // HP
	initVersionForTransfer = 4578 // transfer
	initVersionForLogin    = 4557 // login
	initVersionForAccount  = 4342 // account
)

const (
	urlUserHello     = "https://mobile.95559.com.cn:8093/user/hello"
	urlUserExchange  = "https://mobile.95559.com.cn:8093/user/exchange"
	urlUserHandShake = "https://mobile.95559.com.cn:8093/user/handshake"
	urlChannelRun    = "https://mobile.95559.com.cn:8093/channel_s/run"
)

const (
	appName             = "ebank"
	cfBundleDisplayName = "交通银行"
	cfBundleVersion     = "3.3.13"
	resVersion          = "4.0"
	strKeymapDecodeFail = "解码键盘映射数据错误"
)
