package bcm

// 文件列表单个Item信息
type modelFileInfoItem struct {
	Name           string // 名字
	ID             int16  // ID号
	CurrentVersion int32  // 当前版本
}

// 单个卡的信息, 包含余额及可用余额信息
type modelDebitCardListItem struct {
	Account          string `json:"account"`
	AccBalance       string `json:"accBalance"`
	AccUsableBalance string `json:"accUsableBalance"`
	DebtAsset        string `json:"debtAsset"`
	CurrentUnusable  string `json:"currentUnusable"`
}

// 单个银行卡的各项信息, 包含限额信息
type modelBankCardInfo struct {
	CardNo              string  `json:"cardNo"` // 卡号
	AccountBalance      string  `json:"accBal"` // 余额 "164.35"
	AvailableBalance    string  `json:"avaBal"` //  可用余额 "164.35"
	RealCardNo          string  `json:"realCardNo"`
	CardType            string  `json:"cardType"`
	HoldName            string  `json:"holdName"`
	CertType            string  `json:"certType"`
	CertNo              string  `json:"certNo"` // 身份证号
	BranchNo            string  `json:"branchNo"`
	Outlets             string  `json:"outlets"`
	SignNet             string  `json:"signNet"`
	Self                bool    `json:"self"`
	DayMaxPenAmount     int32   `json:"dayMaxPenAmount"`     // 110
	DayUseablePenAmount int32   `json:"dayUseablePenAmount"` // 110
	TodayTransferLimit  float64 `json:"todayTransferLimit"`  // 50000.00
	UseableLimit        float64 `json:"useableLimit"`        // 50000.00
	YearUseableAmt      float64 `json:"yearUseableAmt"`      // 117999982.98
	SingleTransferLimit float64 `json:"singleTransferLimit"` // 50000.00
	NowTransferedTotal  float64 `json:"nowTransferedTotal"`  // 0.00
	IsAccountUsble      string  `json:"isAccountUsble"`      // "1"
}

// 获取银行名及代号信息
type modelTargetBankBaseInfo struct {
	BankNo   string `json:"code"`
	BankName string `json:"bankName"`
	BankType string `json:"type"`
	/*
		ToOpenBankNo string `json:"code"`
		ToOpenBank   string `json:"bankName"`
		ToPartyID    string `json:"code"`
		ToParty      string `json:"bankName"`
	*/
}

// 获取银行Extra信息
type modelTargetBankExtraInfo struct {
	ToOpenAreaNo       string `json:"toOpenAreaNo"`
	ToOpenArea         string `json:"toOpenAreaName"`
	ToOpenCityNo       string `json:"toOpenCityNo"`
	ToOpenCity         string `json:"toOpenCityName"`
	ToOpenNetSpotNo    string `json:"toOpenNetSpotNo"`
	ToOpenNetSpot      string `json:"toOpenNetSpotName"`
	IsSupportSuperBank string `json:"isSupportSuperBank"`
	ToBankType         string `json:"type"`
}

// 格式化成文本后的限额信息
type modelTransferLimitInfo struct {
	LogBalance          string
	YearUseableAmt      string
	DayUseablePenAmount string
	UseableLimit        string
	SingleTransferLimit string
	NowTransferedTotal  string
}

// 构造转账信息返回的
type modelBuildTransferInfoResponse struct {
	ImageCode           string `json:"imageCode"`           // "5zpyv74m"
	XToken              string `json:"x-token"`             // "5zpyv74m"
	RiskLevel           int    `json:"riskLevel"`           // 0
	TransferConfirmType string `json:"type"`                // "B"=同行 "D"=跨行
	SpeChkResult        string `json:"speChkResult"`        //
	NeedFaceRecognition bool   `json:"needFaceRecognition"` // false
	IsNeedAuth          string `json:"isNeedAuth"`          // "true"
}

type modelTransferExtraParams struct {
	HfeRateCode string // "hfeRateCode": "000090",
	FeePayMode  string // "feePayMode": "0",
	RealFee     string // "realFee": "0.00",
	FeeTcaNo    string // feeTcaNo
}

// 支付密码返回的映射表等
type modelPayPasswordKeyMaps struct {
	Keys          string `json:"keys"`
	PublicKey     string `json:"publicKey"`
	CorrectedKeys map[int]string
}

// 确认转账返回的几个关键参数
type modelConfirmTransferResponse struct {
	SequenceNo   string `json:"sequenceNo"`   // 流水号
	TransferType string `json:"transferType"` // 转账类型
	IsSuccess    string `json:"isSuccess"`    // 确认转账成功时这里的值为0
	TranSum      string `json:"transum"`      // 转账金额
	Balance      string `json:"balance"`      // 余额
	ToCardNo     string `json:"toCardNo"`     // 收款方账号
	ToAccName    string `json:"toAccName"`    // 收款人姓名
	RcvBankName  string `json:"rcvBankName"`  // 收款银行
	Remark       string `json:"remark"`       // 备注
}

////////////////////////////////////////////////////////////////////
// BillList
////////////////////////////////////////////////////////////////////

// 账单列表中单个账单的信息结构
type modelBillInfo struct {
	OppAc      string `json:"oppAc"`
	Amount     string `json:"amount"`
	DealTime   string `json:"dealTime"`
	Balance    string `json:"balance"`
	OppAcNme   string `json:"oppAcNme"`
	OnLoanFlag string `json:"onLoanFlag"`
	WebTime    string `json:"webTime"`
	Remark     string `json:"remark"`
	TxnBrpla   string `json:"txnBrpla"`
	DealType   string `json:"dealType"`
	DcFlag     string `json:"dcFlg"`
	OppBnkNme  string `json:"oppBnkNme"`
}
