package bcm

// iOS版本号和内核版本应该是一一对应的
// 版本号从这里获取: https://www.theiphonewiki.com/wiki/Kernel

import "errors"

// ItemKernelInfo 用于存放内核相关信息的结构
type ItemKernelInfo struct {
	KernelVersion string
	ReleaseDate   string
	XnuVersion    string
	Arm           string
}

// OSKernelArray 用来存放系统版本及对应内核信息的数组
var OSKernelArray = map[string]ItemKernelInfo{
	"9.0": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Thu Aug  20 13:11:13 PDT 2015",
		XnuVersion:    "root:xnu-3248.1.3~1",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.0.1": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Thu Aug  20 13:11:13 PDT 2015",
		XnuVersion:    "root:xnu-3248.1.3~1",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.0.2": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Thu Aug  20 13:11:13 PDT 2015",
		XnuVersion:    "root:xnu-3248.1.3~1",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.1 beta": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Sat Aug 29 17:41:04 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.27~10",
		Arm:           "RELEASE_ARM_S5L8940X",
	},

	"9.1 beta 2": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Mon Sep 14 01:24:55 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.38~3",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},
	"9.1 beta 3": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Sep 25 17:14:21 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.41~11",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.1 beta 4": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Oct 2 14:07:07 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.42~4",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.1 beta 5": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Oct 2 14:07:07 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.42~4",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.1": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Oct 2 14:07:07 PDT 2015",
		XnuVersion:    "root:xnu-3248.10.42~4",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2 beta": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Sun Oct 18 23:34:30 PDT 2015",
		XnuVersion:    "root:xnu-3248.20.33.0.1~7",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.2 beta 3": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Nov  6 22:12:13 PST 2015",
		XnuVersion:    "root:xnu-3248.21.1~2",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2 beta 4": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Nov 13 16:08:07 PST 2015",
		XnuVersion:    "root:xnu-3248.21.2~1",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Fri Nov 13 16:08:07 PST 2015",
		XnuVersion:    "root:xnu-3248.21.2~1",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2.1 beta": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Wed Dec  9 22:19:38 PST 2015",
		XnuVersion:    "root:xnu-3248.31.3~2",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2.1 beta 2": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Wed Dec  9 22:19:38 PST 2015",
		XnuVersion:    "root:xnu-3248.31.3~2",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.2.1": ItemKernelInfo{
		KernelVersion: "15.0.0",
		ReleaseDate:   "Wed Dec  9 22:19:38 PST 2015",
		XnuVersion:    "root:xnu-3248.31.3~2",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.3 beta": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Tue Jan  5 21:24:25 PST 2016",
		XnuVersion:    "root:xnu-3248.40.155.1.1~3",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.3 beta 1.1": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Tue Jan  5 21:24:25 PST 2016",
		XnuVersion:    "root:xnu-3248.40.155.1.1~3",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.3 beta 2": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Tue Jan  19 00:18:39 PST 2016",
		XnuVersion:    "root:xnu-3248.40.166.0.1~10",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3 beta 3": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Sun Jan  31 22:48:58 PST 2016",
		XnuVersion:    "root:xnu-3248.40.173.0.1~13",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3 beta 4": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Sun Feb 14 23:17:56 PST 2016",
		XnuVersion:    "root:xnu-3248.41.3~16",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3 beta 5": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Sun Feb 22 01:48:23 PST 2016",
		XnuVersion:    "root:xnu-3248.41.4~36",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3 beta 6": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Sun Feb 22 01:48:23 PST 2016",
		XnuVersion:    "root:xnu-3248.41.4~36",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3 beta 7": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Fri Feb 19 13:54:52 PST 2016",
		XnuVersion:    "root:xnu-3248.41.4~28",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Fri Feb 19 13:54:52 PST 2016",
		XnuVersion:    "root:xnu-3248.41.4~28",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.1": ItemKernelInfo{
		KernelVersion: "15.4.0",
		ReleaseDate:   "Fri Feb 19 13:54:52 PST 2016",
		XnuVersion:    "root:xnu-3248.41.4~28",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.2 beta": ItemKernelInfo{
		KernelVersion: "15.5.0",
		ReleaseDate:   "Thu Mar 31 17:49:02 PDT 2016",
		XnuVersion:    "root:xnu-3248.50.18~19",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.2 beta 2": ItemKernelInfo{
		KernelVersion: "15.5.0",
		ReleaseDate:   "Tue Apr 5 15:12:03 PDT 2016",
		XnuVersion:    "root:xnu-3248.50.20~12",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.2 beta 3": ItemKernelInfo{
		KernelVersion: "15.5.0",
		ReleaseDate:   "Mon Apr 18 16:44:07 PDT 2016",
		XnuVersion:    "root:xnu-3248.50.21~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.2 beta 4": ItemKernelInfo{
		KernelVersion: "15.5.0",
		ReleaseDate:   "Mon Apr 18 16:44:07 PDT 2016",
		XnuVersion:    "root:xnu-3248.50.21~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.2": ItemKernelInfo{
		KernelVersion: "15.5.0",
		ReleaseDate:   "Mon Apr 18 16:44:07 PDT 2016",
		XnuVersion:    "root:xnu-3248.50.21~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.3 beta": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Tue May 17 19:53:27 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.3~3",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.3.3 beta 2": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Tue May 31 19:52:45 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.4~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"9.3.3 beta 3": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Thu Jun 16 18:08:00 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.8~1/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.3.3 beta 4": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Mon Jun 20 20:10:21 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.9~1/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.3.3 beta 5": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Mon Jun 20 20:10:21 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.9~1/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.3.3": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Mon Jun 20 20:10:21 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.9~1/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.3.4": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Mon Jun 20 20:10:21 PDT 2016",
		XnuVersion:    "root:xnu-3248.60.9~1/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"9.3.5": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Fri Aug 19 10:37:56 PDT 2016",
		XnuVersion:    "root:xnu-3248.61.1~1",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"9.3.6": ItemKernelInfo{
		KernelVersion: "15.6.0",
		ReleaseDate:   "Fri Aug 19 10:37:56 PDT 2016",
		XnuVersion:    "root:xnu-3248.61.1~1",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"10.0 beta": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed May 25 21:19:24 PDT 2016",
		XnuVersion:    "root:xnu-3705.0.0.2.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 2": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Tue Jun 28 21:38:14 PDT 2016",
		XnuVersion:    "root:xnu-3757~291",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 3": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Sat Jul 9 23:57:18 PDT 2016",
		XnuVersion:    "root:xnu-3777.0.0.0.1~28",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 4": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed Jul 27 19:44:34 PDT 2016",
		XnuVersion:    "root:xnu-3789.1.4.2.1~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 5": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Fri Aug 5 22:15:30 PDT 2016",
		XnuVersion:    "root:xnu-3789.1.24~11",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 6": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed Aug 10 21:55:58 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.2~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 7": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed Aug 10 21:55:58 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.2~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0 beta 8": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed Aug 10 21:55:58 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.2~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Wed Aug 10 22:33:10 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.2~3",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"10.0.1 GM": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Sun Aug 28 20:36:54 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.4~3",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0.1": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Sun Aug 28 20:36:54 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.4~3",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.0.2": ItemKernelInfo{
		KernelVersion: "16.0.0",
		ReleaseDate:   "Sun Aug 28 20:36:54 PDT 2016",
		XnuVersion:    "root:xnu-3789.2.4~3",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1 beta": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Fri Sep 16 03:53:22 PDT 2016",
		XnuVersion:    "root:xnu-3789.20.46~54",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1 beta 2": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Thu Sep 29 21:56:12 PDT 2016",
		XnuVersion:    "root:xnu-3789.22.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1 beta 3": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Thu Sep 29 21:56:12 PDT 2016",
		XnuVersion:    "root:xnu-3789.22.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1 beta 4": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Thu Sep 29 21:56:12 PDT 2016",
		XnuVersion:    "root:xnu-3789.22.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Thu Sep 29 21:56:12 PDT 2016",
		XnuVersion:    "root:xnu-3789.22.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.1.1": ItemKernelInfo{
		KernelVersion: "16.1.0",
		ReleaseDate:   "Thu Sep 29 21:56:12 PDT 2016",
		XnuVersion:    "root:xnu-3789.22.3~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Sun Oct 23 20:18:32 PDT 2016",
		XnuVersion:    "root:xnu-3789.30.76~6",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 2": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Tue Nov 1 22:23:11 PDT 2016",
		XnuVersion:    "root:xnu-3789.30.86~54",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 3": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Mon Nov 7 22:58:42 PST 2016",
		XnuVersion:    "root:xnu-3789.30.92~36",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 4": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Mon Nov 7 19:32:10 PST 2016",
		XnuVersion:    "root:xnu-3789.30.92~29",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 5": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Tue Nov 29 21:40:09 PST 2016",
		XnuVersion:    "root:xnu-3789.32.1~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 6": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Tue Nov 29 21:40:09 PST 2016",
		XnuVersion:    "root:xnu-3789.32.1~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2 beta 7": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Tue Nov 29 21:40:09 PST 2016",
		XnuVersion:    "root:xnu-3789.32.1~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Tue Nov 29 21:40:09 PST 2016",
		XnuVersion:    "root:xnu-3789.32.1~4",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2.1 beta": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Thu Dec 1 19:49:21 PST 2016",
		XnuVersion:    "root:xnu-3789.42.1~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2.1 beta 2": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Thu Dec 15 22:41:46 PST 2016",
		XnuVersion:    "root:xnu-3789.42.2~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2.1 beta 3": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Thu Dec 15 22:41:46 PST 2016",
		XnuVersion:    "root:xnu-3789.42.2~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2.1 beta 4": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Thu Dec 15 22:41:46 PST 2016",
		XnuVersion:    "root:xnu-3789.42.2~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.2.1": ItemKernelInfo{
		KernelVersion: "16.3.0",
		ReleaseDate:   "Thu Dec 15 22:41:46 PST 2016",
		XnuVersion:    "root:xnu-3789.42.2~1",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3 beta": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Mon Jan 16 21:43:53 PST 2017",
		XnuVersion:    "root:xnu-3789.50.189~28",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"10.3 beta 2": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Tue Jan 31 21:09:24 PST 2017",
		XnuVersion:    "root:xnu-3789.50.195.1.1~2/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"10.3 beta 3": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Fri Feb 10 22:11:20 PST 2017",
		XnuVersion:    "root:xnu-3789.50.208~47/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"10.3 beta 4": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:48:09 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~9",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3 beta 5": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:48:09 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~9",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3 beta 6": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:48:09 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~9",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3 beta 7": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:48:09 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~9",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:22:54 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~7",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.1": ItemKernelInfo{
		KernelVersion: "16.5.0",
		ReleaseDate:   "Thu Feb 23 23:22:54 PST 2017",
		XnuVersion:    "root:xnu-3789.52.2~7",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2 beta": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Mon Mar 20 22:28:31 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.12~10",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2 beta 2": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Tue Apr 4 21:19:08 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.15~13",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2 beta 3": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Tue Apr 11 22:03:42 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.20~11",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2 beta 4": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Mon Apr 17 20:33:39 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.24~25/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2 beta 5": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Mon Apr 17 20:33:39 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.24~25/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.2": ItemKernelInfo{
		KernelVersion: "16.6.0",
		ReleaseDate:   "Mon Apr 17 17:33:34 PDT 2017",
		XnuVersion:    "root:xnu-3789.60.24~24/",
		Arm:           "RELEASE_ARM_S8000",
	},

	"10.3.3 beta": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Mon May  8 21:45:24 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.9~13/",
		Arm:           "RELEASE_ARM64_T7000",
	},

	"10.3.3 beta 2": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Wed May 24 22:28:55 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.11~6/",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"10.3.3 beta 3": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Tue Jun  6 21:56:23 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.15~6/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"10.3.3 beta 4": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Thu Jun 15 22:48:15 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.16~6/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.3 beta 5": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Thu Jun 15 22:48:16 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.16~6/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"10.3.3 beta 6": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Thu Jun 15 18:33:36 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.16~4/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.3": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Thu Jun 15 18:33:36 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.16~4/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"10.3.4": ItemKernelInfo{
		KernelVersion: "16.7.0",
		ReleaseDate:   "Wed Jul 26 11:08:56 PDT 2017",
		XnuVersion:    "root:xnu-3789.70.16~21/",
		Arm:           "RELEASE_ARM_S5L8950X",
	},

	"11.0 beta": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Sat May 27 21:47:07 PDT 2017",
		XnuVersion:    "root:xnu-4397.0.0.2.4~1/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0 beta 2": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Tue Jun 13 21:19:50 PDT 2017",
		XnuVersion:    "root:xnu-4481.0.0.2.1~1/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0 beta 3": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Thu Jun 29 22:31:39 PDT 2017",
		XnuVersion:    "root:xnu-4532.0.0.0.1~30/",
		Arm:           "RELEASE_ARM64_T7000",
	},

	"11.0 beta 4": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Thu Jul 20 19:49:59 PDT 2017",
		XnuVersion:    "root:xnu-4556.0.0.2.5~1/",
		Arm:           "RELEASE_ARM64_S5L8960X",
	},

	"11.0 beta 5": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Tue Aug  1 21:11:37 PDT 2017",
		XnuVersion:    "root:xnu-4570.1.24.2.3~1/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 beta 6": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Wed Aug  9 22:41:48 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.3~8/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 beta 7": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Aug 18 20:14:27 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~84/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 beta 8": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Aug 18 20:14:27 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~84/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 beta 9": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Aug 18 20:14:27 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~84/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 beta 10": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Aug 18 20:14:27 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~84/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.0 GM": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Sep  1 14:59:17 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~167/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Sep  1 14:59:17 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~167/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0.1": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Sep  1 14:59:17 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~167/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0.2": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Sep  1 14:59:17 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~167/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.0.3": ItemKernelInfo{
		KernelVersion: "17.0.0",
		ReleaseDate:   "Fri Sep  1 14:59:17 PDT 2017",
		XnuVersion:    "root:xnu-4570.2.5~167/",
		Arm:           "RELEASE_ARM64_S8000",
	},

	"11.1 beta": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Sun Sep 17 22:21:07 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.55~10/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1 beta 2": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Sat Sep 30 23:14:15 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1 beta 3": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Sat Sep 30 23:14:15 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1 beta 4": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Fri Sep 29 18:14:51 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~4/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1 beta 5": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Fri Sep 29 18:14:51 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~4/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Fri Sep 29 18:14:51 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~4/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1.1": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Fri Sep 29 18:14:51 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~4/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.1.2": ItemKernelInfo{
		KernelVersion: "17.2.0",
		ReleaseDate:   "Fri Sep 29 18:14:51 PDT 2017",
		XnuVersion:    "root:xnu-4570.20.62~4/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Wed Oct 25 19:27:20 PDT 2017",
		XnuVersion:    "root:xnu-4570.30.79~22/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta 2": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Sun Oct 29 17:18:38 PDT 2017",
		XnuVersion:    "root:xnu-4570.30.85~18/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta 3": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 22:29:20 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta 4": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 22:29:20 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta 5": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 22:29:20 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2 beta 6": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 21:19:16 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 21:19:16 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.1": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 21:19:16 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.2": ItemKernelInfo{
		KernelVersion: "17.3.0",
		ReleaseDate:   "Mon Nov  6 21:19:16 PST 2017",
		XnuVersion:    "root:xnu-4570.32.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Sat Dec  2 21:26:33 PST 2017",
		XnuVersion:    "root:xnu-4570.40.6~8/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 2": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Wed Dec 13 22:51:57 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 3": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Wed Dec 13 22:51:57 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 4": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Wed Dec 13 22:51:57 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 5": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Wed Dec 13 22:51:57 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 6": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Wed Dec 13 22:51:57 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5 beta 7": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Fri Dec  8 19:35:51 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.5": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Fri Dec  8 19:35:51 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.2.6": ItemKernelInfo{
		KernelVersion: "17.4.0",
		ReleaseDate:   "Fri Dec  8 19:35:51 PST 2017",
		XnuVersion:    "root:xnu-4570.40.9~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Sat Jan 13 00:03:04 PST 2018",
		XnuVersion:    "root:xnu-4570.50.243~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta 2": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Fri Jan 26 22:56:33 PST 2018",
		XnuVersion:    "root:xnu-4570.50.257~6/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta 3": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Sat Feb 10 17:01:35 PST 2018",
		XnuVersion:    "root:xnu-4570.50.279~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta 4": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Sat Feb 24 20:24:10 PST 2018",
		XnuVersion:    "root:xnu-4570.50.294~5/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta 5": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Tue Mar  6 20:47:58 PST 2018",
		XnuVersion:    "root:xnu-4570.52.2~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3 beta 6": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Tue Mar  6 20:47:58 PST 2018",
		XnuVersion:    "root:xnu-4570.52.2~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.3": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Tue Mar 13 21:32:11 PDT 2018",
		XnuVersion:    "root:xnu-4570.52.2~8/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.3.1": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Tue Mar 13 21:32:11 PDT 2018",
		XnuVersion:    "root:xnu-4570.52.2~8/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"11.4 beta": ItemKernelInfo{
		KernelVersion: "17.5.0",
		ReleaseDate:   "Sun Mar 25 20:49:19 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.10.0.1~16/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4 beta 2": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Thu Apr  5 22:33:56 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.16~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4 beta 3": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Sun Apr 22 03:29:53 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.19~25/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4 beta 4": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Tue May  1 16:16:12 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.21~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4 beta 5": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Tue May  1 16:16:12 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.21~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4 beta 6": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Tue May  1 16:16:12 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.21~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4": ItemKernelInfo{
		KernelVersion: "17.6.0",
		ReleaseDate:   "Mon Apr 30 18:48:32 PDT 2018",
		XnuVersion:    "root:xnu-4570.60.21~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1 beta": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Mon May 21 19:02:13 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.14~16/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1 beta 2": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Sun Jun  3 20:38:12 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.19~13/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1 beta 3": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Tue Jun 12 20:37:30 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.24~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1 beta 4": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Tue Jun 12 20:37:30 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.24~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1 beta 5": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Tue Jun 12 20:37:30 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.24~9/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"11.4.1": ItemKernelInfo{
		KernelVersion: "17.7.0",
		ReleaseDate:   "Mon Jun 11 19:06:27 PDT 2018",
		XnuVersion:    "root:xnu-4570.70.24~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Fri May 25 21:25:37 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.199.12.3~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 2": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Jun 13 21:04:46 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.249.22.3~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 3": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Tue Jun 26 21:06:03 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.274.32.3~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 4": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Mon Jul  9 21:17:19 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.304.42.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 5": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Jul 25 22:51:45 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.327.52.1~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 6": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Aug  1 21:11:01 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.342.62.3~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 7": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Sun Aug  5 21:44:00 PDT 2018",
		XnuVersion:    "root:xnu-4903.200.354~11/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 8": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Fri Aug 10 21:57:57 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.1~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 9": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Aug 15 21:51:15 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 10": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Aug 15 21:51:15 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 11": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Aug 15 21:51:15 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 beta 12": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Wed Aug 15 21:51:15 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0 GM": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Tue Aug 14 22:07:16 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Tue Aug 14 22:07:16 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.0.1": ItemKernelInfo{
		KernelVersion: "18.0.0",
		ReleaseDate:   "Tue Aug 14 22:07:16 PDT 2018",
		XnuVersion:    "root:xnu-4903.202.2~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1 beta": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Mon Sep 10 22:05:56 PDT 2018",
		XnuVersion:    "root:xnu-4903.220.42~21/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1 beta 2": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Sun Sep 23 20:16:38 PDT 2018",
		XnuVersion:    "root:xnu-4903.220.48~40/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1 beta 3": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Wed Oct  3 02:49:20 PDT 2018",
		XnuVersion:    "root:xnu-4903.222.1~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1 beta 4": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Tue Oct  9 18:52:50 PDT 2018",
		XnuVersion:    "root:xnu-4903.222.4~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1 beta 5": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Tue Oct 16 22:15:34 PDT 2018",
		XnuVersion:    "root:xnu-4903.222.5~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Tue Oct 16 21:02:33 PDT 2018",
		XnuVersion:    "root:xnu-4903.222.5~1/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1.1 beta": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Thu Oct 25 21:36:46 PDT 2018",
		XnuVersion:    "root:xnu-4903.230.15~8/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1.1 beta 2": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Sat Nov  3 03:45:48 PDT 2018",
		XnuVersion:    "root:xnu-4903.232.1~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1.1 beta 3": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Mon Nov 12 21:07:36 PST 2018",
		XnuVersion:    "root:xnu-4903.232.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.1": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Mon Nov 12 20:32:01 PST 2018",
		XnuVersion:    "root:xnu-4903.232.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.2 beta": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Sun Dec  2 20:53:08 PST 2018",
		XnuVersion:    "root:xnu-4903.240.8~8/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.1.2": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Mon Nov 12 20:32:01 PST 2018",
		XnuVersion:    "root:xnu-4903.232.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.3 beta 2": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Sun Dec 16 20:44:43 PST 2018",
		XnuVersion:    "root:xnu-4903.240.10~8/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.3 beta 3": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Wed Dec 19 22:27:19 PST 2018",
		XnuVersion:    "root:xnu-4903.242.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.3 beta 4": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Wed Dec 19 22:27:19 PST 2018",
		XnuVersion:    "root:xnu-4903.242.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.3": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Wed Dec 19 20:28:53 PST 2018",
		XnuVersion:    "root:xnu-4903.242.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.1.4": ItemKernelInfo{
		KernelVersion: "18.2.0",
		ReleaseDate:   "Wed Dec 19 20:28:53 PST 2018",
		XnuVersion:    "root:xnu-4903.242.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Sun Jan 13 21:01:59 PST 2019",
		XnuVersion:    "root:xnu-4903.250.305~10/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta 2": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Wed Jan 30 19:26:26 PST 2019",
		XnuVersion:    "root:xnu-4903.250.319~58/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta 3": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Sun Feb 10 20:48:56 PST 2019",
		XnuVersion:    "root:xnu-4903.250.336.0.1~10/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta 4": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Sun Feb 24 21:50:15 PST 2019",
		XnuVersion:    "root:xnu-4903.250.349~13/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta 5": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Tue Mar  5 21:34:09 PST 2019",
		XnuVersion:    "root:xnu-4903.252.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2 beta 6": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Tue Mar  5 21:34:09 PST 2019",
		XnuVersion:    "root:xnu-4903.252.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.2": ItemKernelInfo{
		KernelVersion: "18.5.0",
		ReleaseDate:   "Tue Mar  5 19:52:18 PST 2019",
		XnuVersion:    "root:xnu-4903.252.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.3 beta": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Mon Mar 18 23:03:29 PDT 2019",
		XnuVersion:    "root:xnu-4903.260.65.100.1~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.3 beta 2": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Mon Apr  1 21:12:58 PDT 2019",
		XnuVersion:    "root:xnu-4903.260.74.100.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.3 beta 3": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 18 19:45:13 PDT 2019",
		XnuVersion:    "root:xnu-4903.260.85.0.2~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.3 beta 4": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 23:57:27 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.3 beta 5": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 23:57:27 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.3 beta 6": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 23:57:27 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~3/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.3": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 22:14:10 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.3.1 (12F203)": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 22:14:10 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.3.1 (12F8202)": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu May  9 15:45:33 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~4/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"12.3.2": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Thu Apr 25 22:14:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.262.2~2/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.4 beta": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Tue May  7 23:38:12 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.19.100.1~3/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 2": ItemKernelInfo{
		KernelVersion: "18.6.0",
		ReleaseDate:   "Tue May  7 23:38:12 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.19.100.1~3/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 3": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Tue May 21 01:53:36 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.29~10/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 4": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Wed Jun  5 21:04:51 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.37~24/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 5": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Fri Jun 14 21:12:14 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.38~24/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 6": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Tue Jun 25 22:53:57 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.47~11/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4 beta 7": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Tue Jun 25 22:53:57 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.47~11/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Fri Jun 21 22:24:16 PDT 2019",
		XnuVersion:    "root:xnu-4903.270.47~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"12.4.1": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Mon Aug 19 22:24:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.272.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4.2": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Mon Aug 19 22:24:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.272.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"12.4.3": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Mon Aug 19 22:24:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.272.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue May 21 03:52:25 PDT 2019",
		XnuVersion:    "root:xnu-6041.0.0.112.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Sun Jun  9 18:57:16 PDT 2019",
		XnuVersion:    "root:xnu-6110.0.0.120.8~3/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 3": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Thu Jun 27 20:08:29 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.13.132.4~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 4": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Jul  9 00:52:55 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.59.0.2~63/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 5": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Sun Jul 21 19:17:20 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.98.0.2~30/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 6": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Jul 30 23:56:43 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.103.8~3/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 7": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Fri Aug  9 23:13:23 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.103.11~2/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 beta 8": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Thu Aug 15 21:21:27 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.103.12~3/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0 GM": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Mon Aug 19 22:24:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.272.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.0": ItemKernelInfo{
		KernelVersion: "18.7.0",
		ReleaseDate:   "Mon Aug 19 22:24:08 PDT 2019",
		XnuVersion:    "root:xnu-4903.272.1~1/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.1 beta": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Sun Aug 18 23:18:25 PDT 2019",
		XnuVersion:    "root:xnu-6153.0.166~14/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"13.1 beta 2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Thu Aug 29 23:02:07 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.2~5/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.1 beta 3": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Fri Sep  6 09:12:32 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"13.1 beta 4": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Fri Sep  6 09:12:32 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~7/",
		Arm:           "RELEASE_ARM64_T8015",
	},

	"13.1": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Sep  3 21:52:14 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~2/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.1.1": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Sep  3 21:52:14 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~2/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.1.2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Sep  3 21:52:14 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~2/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.1.3": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Tue Sep  3 21:52:14 PDT 2019",
		XnuVersion:    "root:xnu-6153.2.3~2/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.2 beta": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Sun Sep 22 21:45:32 PDT 2019",
		XnuVersion:    "root:xnu-6153.40.121.0.1~23/",
		Arm:           "RELEASE_ARM64_T8020",
	},

	"13.2 beta 2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Thu Oct  3 23:49:24 PDT 2019",
		XnuVersion:    "root:xnu-6153.40.150.100.1~1/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.2 beta 3": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Fri Oct 11 02:14:05 PDT 2019",
		XnuVersion:    "root:xnu-6153.42.1~3/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"13.2 beta 4": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Fri Oct 11 02:14:05 PDT 2019",
		XnuVersion:    "root:xnu-6153.42.1~3/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"13.2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Wed Oct  9 22:42:11 PDT 2019",
		XnuVersion:    "root:xnu-6153.42.1~1/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.2.2": ItemKernelInfo{
		KernelVersion: "19.0.0",
		ReleaseDate:   "Wed Oct  9 22:42:11 PDT 2019",
		XnuVersion:    "root:xnu-6153.42.1~1/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.3 beta": ItemKernelInfo{
		KernelVersion: "19.2.0",
		ReleaseDate:   "Thu Oct 31 02:33:36 PDT 2019",
		XnuVersion:    "root:xnu-6153.60.58.0.1~22/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"13.3 beta 2": ItemKernelInfo{
		KernelVersion: "19.2.0",
		ReleaseDate:   "Wed Nov  6 02:29:57 PST 2019",
		XnuVersion:    "root:xnu-6153.60.66~54/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.3 beta 3": ItemKernelInfo{
		KernelVersion: "19.2.0",
		ReleaseDate:   "Tue Nov 12 22:06:16 PST 2019",
		XnuVersion:    "root:xnu-6153.60.66~63/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.3 beta 4": ItemKernelInfo{
		KernelVersion: "19.2.0",
		ReleaseDate:   "Tue Nov 12 22:06:16 PST 2019",
		XnuVersion:    "root:xnu-6153.60.66~63/",
		Arm:           "RELEASE_ARM64_T8030",
	},

	"13.3": ItemKernelInfo{
		KernelVersion: "19.2.0",
		ReleaseDate:   "Mon Nov 4 17:44:49 PST 2019",
		XnuVersion:    "root:xnu-6153.60.66~39/",
		Arm:           "RELEASE_ARM64_T8010",
	},

	"13.3.1": ItemKernelInfo{
		KernelVersion: "19.3.0",
		ReleaseDate:   "Sun Dec 8 21:03:13 PST 2019",
		XnuVersion:    "root:xnu-6153.80.8.0.1~13/",
		Arm:           "RELEASE_ARM64_T8010",
	},
}

// GetOSTargetKernelVersion 获取指定iOS版本的对应内核版本
func GetOSTargetKernelVersion(osVerison string) (string, error) {
	value, ok := OSKernelArray[osVerison]
	if ok {
		return value.KernelVersion, nil
	}
	return "", errors.New("Unknown os version")
}
