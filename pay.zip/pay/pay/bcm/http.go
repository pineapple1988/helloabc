package bcm

import (
	"bytes"
	"compress/gzip"
	"errors"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"pay/pay"
	"pay/pay/bcm/codec/CSSharkBase"
	"pay/utils/logger"
	"time"

	"pay/pay/bcm/codec"

	"github.com/go-http-utils/headers"
	jsoniter "github.com/json-iterator/go"
)

// 基础发包函数
func (acc *Account) httpPostSharkCommand(data []byte) ([]byte, error) {
	url := constSharkCMDURL
	//logger.Debugf("[BCM]httpPost, url: %s, req body: %s.", url, string(data))
	req, err := http.NewRequest("POST", url, bytes.NewReader(data))
	if err != nil {
		logger.Errorf("[BCM]httpPostSharkCommand: 创建http请求错误: %+v.", err)
		return nil, err
	}

	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("Bocom/%s CFNetwork/%s Darwin/%s", constAppVersion, acc.CFNetworkVersion, acc.DarwinVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")

	resp, err := acc.http.Do(req)
	if err != nil {
		logger.Errorf("[BCM][%+v]httpPostSharkCommand: http操作错误: %+v.", acc.Account, err)

		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			/*
				fmt.Println("===============================")
				fmt.Println("==  pay.ErrOperationTimeout  ==")
				fmt.Println("===============================")
			*/
			return nil, pay.ErrOperationTimeout
		}

		// return pay.ErrOperationError

		return nil, err
	}
	defer resp.Body.Close()

	// http状态码
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("[BCM]httpPostSharkCommand: 提交数据响应错误, 状态码: %d", resp.StatusCode)
	}

	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if body, err = gzip.NewReader(body); err != nil {
			logger.Errorf("[BCM]httpPostSharkCommand: gzip解压失败: %+v.", err)
			return nil, err
		}
	}

	respData, err := ioutil.ReadAll(body)
	if err != nil {
		logger.Errorf("[BCM]httpPostSharkCommand: ioutil.ReadAll错误: %+v.", err)
		return nil, err
	}
	// logger.Debugf("[BCM]httpPost, url: %s, res body: %s.", url, body)

	return respData, nil
}

///////////////////////////////////////////////////////////////////////////////
// === 几组逻辑打包
///////////////////////////////////////////////////////////////////////////////

// 启动时发的包
func (acc *Account) httpInitApp() (authKey string, err error) {
	logger.Debugf("[BCM][STEP_IN]httpInitApp")

	// 先初始化版本号信息
	acc.FileListDb = map[string]modelFileInfoItem{
		"static": modelFileInfoItem{
			Name:           "static",
			ID:             1239,
			CurrentVersion: initVersionForStatic,
		},
		"life": modelFileInfoItem{
			Name:           "life",
			ID:             1190,
			CurrentVersion: initVersionForLife,
		},
		"loan_home": modelFileInfoItem{
			Name:           "loan_home",
			ID:             1196,
			CurrentVersion: initVersionForLoanHome,
		},
		"HP": modelFileInfoItem{
			Name:           "HP",
			ID:             1182,
			CurrentVersion: initVersionForHP,
		},
		"transfer": modelFileInfoItem{
			Name:           "transfer",
			ID:             1245,
			CurrentVersion: initVersionForTransfer,
		},
		"login": modelFileInfoItem{
			Name:           "login",
			ID:             1200,
			CurrentVersion: initVersionForLogin,
		},
		"account": modelFileInfoItem{
			Name:           "account",
			ID:             1137,
			CurrentVersion: initVersionForAccount,
		},
	}

	authKey, err = acc.pkgInitAppAsFirstPackage()
	if err != nil {
		return "", err
	}
	return authKey, nil
}

// 获取该账户下所有银行卡的信息
func (acc *Account) httpGetDebitCardList() ([]modelDebitCardListItem, error) {
	logger.Debugf("[BCM][STEP_IN]httpGetDebitCardList")

	if err := acc.pkgSwitchToAccountPage(); err != nil {
		logger.Errorf("httpGetDebitCardList: 切换到账号首页失败, 信息: %+v", err)
		return nil, err
	}

	debitCardList, err := acc.pkgGetDebitCardList()
	if err != nil {
		logger.Errorf("httpGetDebitCardList: 获取卡列表失败, 信息: %+v", err)
		return nil, err
	}

	return debitCardList, nil
}

///////////////////////////////////////////////////////////////////////////////
// === 注册设备的流程
// 第一个包中生成两组UUID及一组设备信息, 在返回包里获得GUID
// 第二个包附带上刚才生成的GUID, 在返回包里获取VIDTicket
// 第三个包带上GUID及VIDTicket, 在返回包里获取DeviceID
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// === No. 01 首个设备绑定的包, 返回的是GUID
///////////////////////////////////////////////////////////////////////////////
// 对结构化非字符串类型的RegisterDevice进行序列化转换
func getRegisterDeviceBytes(paramsStruct CSSharkBase.RegisterDeviceContainer) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

func (acc *Account) pkgRegisterDeviceGetGUID() (authKey string, GUIDString string, err error) { //done
	logger.Debugf("[BCM][STEP_IN]pkgRegisterDeviceGetGUID")

	// 关键包重置计数器
	acc.SequenceNumber = 0
	acc.ListSequenceNumber = 0

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: "",
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var deviceInfo = CSSharkBase.RegisterDeviceContainer{
		CSSharkBase.RegisterDevice{
			Unknow0:     3, // 0
			Unknow1:     3,
			Unknow2:     301,
			Unknow3:     6177,
			Unknow4:     "",
			UnknowUUID1: acc.HardwareUUID1,
			UnknowUUID2: acc.HardwareUUID2,
			Unknow7:     "",
			RDStruct: CSSharkBase.RegisterDeviceUnknowStruct{
				Unknow1: 4,
				Unknow2: 0,
				Unknow3: 0,
			},
			DeviceModel: acc.DeviceModel, // @todo
			OSVersion:   acc.OSVersion,
			Unknow11:    0,
			Unknow12:    "",
			Unknow13:    "",
			Unknow14:    "",
		},
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     3,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getRegisterDeviceBytes(deviceInfo),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    nil,
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    "",
			Unknow3: "",
			Unknow4: "",
			Unknow5: 4,
			Unknow6: 0,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   0,
				VIDTicket: "",
			},
		},
		List: seqRequestList,
	}

	authKey, decryptedData, err := acc.RegisterDeviceAndGetResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return "", "", err
	}

	if authKey == "" {
		return "", "", errors.New("pkgRegisterDeviceGetGUID: 获取authKey错误, authKey不能为空")
	}

	if len(decryptedData.List) <= 0 {
		return "", "", errors.New("pkgRegisterDeviceGetGUID: 返回的List数据解析失败")
	}

	structGUID := CSSharkBase.ResponseGUIDBytes{}
	if err := structGUID.ReadFrom(codec.NewReader(decryptedData.List[0].Unknow5)); err != nil {
		// do nothing
		return "", "", errors.New("pkgRegisterDeviceGetGUID: 解析GUID失败")
	}

	GUIDString = structGUID.GUID
	if GUIDString == "" {
		return "", "", errors.New("pkgRegisterDeviceGet: GUID不能为空")
	}

	return authKey, GUIDString, nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 02 获取VIDTicket
///////////////////////////////////////////////////////////////////////////////

func getRDParamsStructBytes(paramsStruct CSSharkBase.RDParamsStruct) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}
func getRDParamsStructOneBytes(paramsStruct CSSharkBase.RDParamsStructOne) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

func (acc *Account) pkgRegisterDeviceGetVIDTicket(tmpGUID string) (VIDTicket string, err error) { //done
	logger.Debugf("[BCM][STEP_IN]pkgRegisterDeviceGetVIDTicket")

	var seqNum int32 = acc.getSequenceNumber()
	var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var rdParamsChild = CSSharkBase.RDParamsStructOne{
		Unknow0: CSSharkBase.RDParamsStructTwo{
			Unknow0: 0,
			Unknow1: 0,
			Unknow2: 0,
			Unknow3: 0,
			Unknow4: "",
			Unknow5: "",
			Unknow6: "",
			Unknow7: "",
			Unknow8: CSSharkBase.RDParamsStructThree{
				Unknow0: 0,
				Unknow1: 0,
				Unknow2: 0,
			},
			Unknow9:  "",
			Unknow10: "",
			Unknow11: 0,
			Unknow12: "",
			Unknow13: "",
			Unknow14: "",
		},
		Unknow1: "",
		Unknow2: "",
	}

	var rdParam = CSSharkBase.RDParamsStruct{
		Unknow0: 2,
		Unknow1: getRDParamsStructOneBytes(rdParamsChild),
	}
	sashimiSeqNum := baselineListSeqNum

	data1 := url.Values{}
	sashimiSeqNum1 := sashimiSeqNum + 1
	data1.Set("ecifNo", "")
	data1.Set("clientVersion", acc.ClientVersion)
	data1.Set("tranCode", "SC0201")
	data1.Set("isWap", "0")
	data1.Set("contractNo", "")
	data1.Set("MSessionId", "")
	data1.Set("diviceId", "")
	queryData1 := data1.Encode()

	data2 := url.Values{}
	sashimiSeqNum2 := sashimiSeqNum1 + 1
	data2.Set("ecifNo", "")
	data2.Set("alias", "")
	data2.Set("targetPageCode", "")
	data2.Set("clientVersion", acc.ClientVersion)
	data2.Set("isWap", "0")
	data2.Set("contractNo", "")
	data2.Set("processCode", "CU0007")
	data2.Set("pageCode", "")
	data2.Set("MSessionId", "")
	data2.Set("queryFlag", "recharge_unable_version")
	data2.Set("diviceId", "")
	queryData2 := data2.Encode()

	// @todo 这里对序号进行一下复位
	acc.ListSequenceNumber = sashimiSeqNum2

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5010,
			ListSequence: sashimiSeqNum,
			Unknow2:      0,
			Params:       getRDParamsStructBytes(rdParam),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum1,
			Unknow2:      0,
			Params:       []uint8(queryData1),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SC0201"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum2,
			Unknow2:      0,
			Params:       []uint8(queryData2),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("CU0007"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    tmpGUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 0, // @todo_Unknow6
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   0,
				VIDTicket: "",
			},
		},
		List: seqRequestList,
	}

	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return "", err
	}

	if len(decryptedData.List) <= 0 {
		return "", errors.New("pkgRegisterDeviceGetVIDTicket: 返回的List数据解析失败")
	}

	VIDTicket = ""
	alreadyGotMSessionID := false

	for _, item := range decryptedData.List {
		if item.ListSequence == sashimiSeqNum {

			structVIDTicketContainer := CSSharkBase.ResponseVIDTicketContainer{}
			if err := structVIDTicketContainer.ReadFrom(codec.NewReader(item.Unknow5)); err != nil {
				return "", errors.New("解析VIDTicketContainer失败")
			}

			structVIDTicket := CSSharkBase.ResponseVIDTicket{}
			if err := structVIDTicket.ReadFrom(codec.NewReader(structVIDTicketContainer.Data1)); err != nil {
				return "", errors.New("解析VIDTicket失败")
			}

			if structVIDTicket.VIDTicket != "" {
				VIDTicket = structVIDTicket.VIDTicket
			}
		}

		// MSessionID的获取逻辑: 遍历第一个返回包的所有MSessionID,第一个出现的即为会话MSessionID
		if getTranStatus(item.Unknow5) == constTranStatusSuccess {
			if (getHeadItem(item.Unknow5, "MSessionId").ToString() != "") && (alreadyGotMSessionID == false) {
				acc.MSessionID = getHeadItem(item.Unknow5, "MSessionId").ToString()
				alreadyGotMSessionID = true
			}
		}

	}

	if VIDTicket == "" {
		return "", errors.New("pkgRegisterDeviceGetVIDTicket: VIDTicket不能为空")
	}

	if (acc.MSessionID == "") || (alreadyGotMSessionID == false) {
		return "", errors.New("pkgRegisterDeviceGetVIDTicket: 未能成功获取MSessionId")
	}

	return VIDTicket, nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 03 获取DeviceID
///////////////////////////////////////////////////////////////////////////////

func getRequestVIDTicketBytes(paramsStruct CSSharkBase.RequestVIDTicket) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

func (acc *Account) pkgSendDeviceInfoAndGetDeviceID(tmpGUID string, tmpVIDTicket string) (string, error) { //done
	logger.Debugf("[BCM][STEP_IN]pkgSendDeviceInfoAndGetDeviceID")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var paramVIDTicket = CSSharkBase.RequestVIDTicket{
		Unknow0:   2,
		VIDTicket: tmpVIDTicket,
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5011,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getRequestVIDTicketBytes(paramVIDTicket),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    nil,
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    tmpGUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 0,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2, // @update 下次对包的时候着重注意这里, 前面两个包这里的值是0
				VIDTicket: tmpVIDTicket,
			},
		},
		List: seqRequestList,
	}

	// 无需解析返回包
	decryptedData, err := acc.RegisterDeviceAndGetDeviceID(seqReqData, seqHeadStruct)
	if err != nil {
		return "", err
	}

	if len(decryptedData.List) <= 0 {
		return "", errors.New("返回的List数据解析失败")
	}

	structDeviceID := CSSharkBase.ResponseDeviceIDBytes{}
	if err := structDeviceID.ReadFrom(codec.NewReader(decryptedData.List[0].Unknow5)); err != nil {
		return "", errors.New("解析DeviceID失败")
	}

	DeviceID := structDeviceID.DeviceID
	if DeviceID == "" {
		return "", errors.New("DeviceID不能为空")
	}

	return DeviceID, nil
}

///////////////////////////////////////////////////////////////////////////////
// === 到这里设备就注册完成了
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// === No. 1 启动时的包, 同时获取了Key, 返回参数为authKey及error
///////////////////////////////////////////////////////////////////////////////

// 这种是在已存在GUID/DeviceID时发的包, 即首次启动的握手包, 需要从这个包里获取authKey
func (acc *Account) pkgInitAppAsFirstPackage() (authKey string, err error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgInitAppAsFirstPackage")

	// 关键包重置计数器
	acc.SequenceNumber = 0
	acc.ListSequenceNumber = 0
	acc.MSessionID = ""
	acc.SecAuthKey = ""

	var seqNum int32 = acc.getSequenceNumber()
	var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: "",
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	sashimiSeqNum := baselineListSeqNum
	data.Set("ecifNo", "")
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("tranCode", "SC0201")
	data.Set("isWap", "0")
	data.Set("contractNo", "")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	// ===***SpecialStruct1***=== @todo
	sashimiSeqNum1 := sashimiSeqNum + 1
	var seqParams = CSSharkBase.CheckForFileListUpdates{
		Unknow0: 1, // @todo 这个参数为1则请求全部列表, 一般只有首个包这里的值为1
		Unknow1: 0,
		Unknow2: 1,
		Unknow3: 0,
		List: []CSSharkBase.FileItemForQuery{
			CSSharkBase.FileItemForQuery{
				Name:           "static",
				Unknow1:        0,
				CurrentVersion: initVersionForStatic,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "life",
				Unknow1:        0,
				CurrentVersion: initVersionForLife,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "loan_home",
				Unknow1:        0,
				CurrentVersion: initVersionForLoanHome,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "HP",
				Unknow1:        0,
				CurrentVersion: initVersionForHP,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "transfer",
				Unknow1:        0,
				CurrentVersion: initVersionForTransfer,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "login",
				Unknow1:        0,
				CurrentVersion: initVersionForLogin,
			},
		},
	}

	data2 := url.Values{}
	sashimiSeqNum2 := sashimiSeqNum1 + 1
	data2.Set("ecifNo", "")
	data2.Set("alias", "")
	data2.Set("targetPageCode", "")
	data2.Set("clientVersion", acc.ClientVersion)
	data2.Set("isWap", "0")
	data2.Set("contractNo", "")
	data2.Set("processCode", "CU0007")
	data2.Set("pageCode", "")
	data2.Set("MSessionId", acc.MSessionID)
	data2.Set("queryFlag", "recharge_unable_version")
	data2.Set("diviceId", acc.DeviceID)
	queryData2 := data2.Encode()

	data3 := url.Values{}
	sashimiSeqNum3 := sashimiSeqNum2 + 1
	data3.Set("ecifNo", "")
	data3.Set("clientVersion", acc.ClientVersion)
	data3.Set("isWap", "0")
	data3.Set("contractNo", "")
	data3.Set("processCode", "MB0702")
	data3.Set("MSessionId", acc.MSessionID)
	data3.Set("diviceId", acc.DeviceID)
	queryData3 := data3.Encode()

	data4 := url.Values{}
	sashimiSeqNum4 := sashimiSeqNum3 + 1
	data4.Set("pageSize", "1")
	data4.Set("clientVersion", acc.ClientVersion)
	data4.Set("targetCode", "querySearchDefaultWord")
	data4.Set("ecifNo", "")
	data4.Set("isWap", "0")
	data4.Set("processCode", "FM0002")
	data4.Set("MSessionId", acc.MSessionID)
	data4.Set("diviceId", acc.DeviceID)
	queryData4 := data4.Encode()

	data5 := url.Values{}
	sashimiSeqNum5 := sashimiSeqNum4 + 1
	data5.Set("processCode", "MB0002")
	data5.Set("isWap", "0")
	data5.Set("clientVersion", acc.ClientVersion)
	data5.Set("diviceId", acc.DeviceID)
	data5.Set("ecifNo", "")
	data5.Set("MSessionId", acc.MSessionID)
	queryData5 := data5.Encode()

	data6 := url.Values{}
	sashimiSeqNum6 := sashimiSeqNum5 + 1
	data6.Set("ecifNo", "")
	data6.Set("clientVersion", acc.ClientVersion)
	data6.Set("tranCode", "SY0033")
	data6.Set("isWap", "0")
	data6.Set("contractNo", "")
	data6.Set("processCode", "SY0033")
	data6.Set("MSessionId", acc.MSessionID)
	data6.Set("diviceId", acc.DeviceID)
	queryData6 := data6.Encode()

	data7 := url.Values{}
	sashimiSeqNum7 := sashimiSeqNum6 + 1
	data7.Set("ecifNo", "")
	data7.Set("alias", "")
	data7.Set("clientVersion", acc.ClientVersion)
	data7.Set("isWap", "0")
	data7.Set("contractNo", "")
	data7.Set("processCode", "SY1018")
	data7.Set("MSessionId", acc.MSessionID)
	data7.Set("diviceId", acc.DeviceID)
	queryData7 := data7.Encode()

	data8 := url.Values{}
	sashimiSeqNum8 := sashimiSeqNum7 + 1
	data8.Set("ecifNo", "")
	data8.Set("alias", "")
	data8.Set("isHome", "1")
	data8.Set("targetPageCode", "NAC2001")
	data8.Set("clientVersion", acc.ClientVersion)
	data8.Set("isWap", "0")
	data8.Set("contractNo", "")
	data8.Set("processCode", "ZY0003")
	data8.Set("pageCode", "NAC2001")
	data8.Set("MSessionId", acc.MSessionID)
	data8.Set("diviceId", acc.DeviceID)
	queryData8 := data8.Encode()

	data9 := url.Values{}
	sashimiSeqNum9 := sashimiSeqNum8 + 1
	data9.Set("ecifNo", "")
	data9.Set("clientVersion", acc.ClientVersion)
	data9.Set("isWap", "0")
	data9.Set("flag", "1")
	data9.Set("processCode", "SY0034")
	data9.Set("srcPageCode", "NWM0001")
	data9.Set("MSessionId", acc.MSessionID)
	data9.Set("diviceId", acc.DeviceID)
	queryData9 := data9.Encode()

	data10 := url.Values{}
	sashimiSeqNum10 := sashimiSeqNum9 + 1
	data10.Set("ecifNo", "")
	data10.Set("alias", "")
	data10.Set("targetPageCode", "")
	data10.Set("clientVersion", acc.ClientVersion)
	data10.Set("tranCode", "ME0009")
	data10.Set("isWap", "0")
	data10.Set("contractNo", "")
	data10.Set("processCode", "ME0009")
	data10.Set("pageCode", "")
	data10.Set("MSessionId", acc.MSessionID)
	data10.Set("diviceId", acc.DeviceID)
	queryData10 := data10.Encode()

	data11 := url.Values{}
	sashimiSeqNum11 := sashimiSeqNum10 + 1
	data11.Set("customerNo", "")
	data11.Set("isClearUnread", "0")
	data11.Set("diviceId", acc.DeviceID)
	data11.Set("clientVersion", acc.ClientVersion)
	data11.Set("tranCode", "ME0016")
	data11.Set("isWap", "0")
	data11.Set("MSessionId", acc.MSessionID)
	data11.Set("processCode", "ME0016")
	data11.Set("contractNo", "")
	data11.Set("ecifNo", "")
	data11.Set("page", "1")
	data11.Set("pageSize", "1000")
	queryData11 := data11.Encode()

	data12 := url.Values{}
	sashimiSeqNum12 := sashimiSeqNum11 + 1
	data12.Set("MSessionId", acc.MSessionID)
	data12.Set("ecifNo", "")
	data12.Set("processCode", "PS0005")
	queryData12 := data12.Encode()

	data13 := url.Values{}
	sashimiSeqNum13 := sashimiSeqNum12 + 1
	data13.Set("ecifNo", "")
	data13.Set("clientVersion", acc.ClientVersion)
	data13.Set("isWap", "0")
	data13.Set("hashs", acc.hashs) // @update
	data13.Set("processCode", "MB0303")
	data13.Set("MSessionId", acc.MSessionID)
	data13.Set("diviceId", acc.DeviceID)
	queryData13 := data13.Encode()

	acc.ListSequenceNumber = sashimiSeqNum13

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum,
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SC0201"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     5001,
			ListSequence: sashimiSeqNum1,
			Unknow2:      0,
			Params:       getSeqParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum2,
			Unknow2:      0,
			Params:       []uint8(queryData2),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("CU0007"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum3,
			Unknow2:      0,
			Params:       []uint8(queryData3),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0702"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum4,
			Unknow2:      0,
			Params:       []uint8(queryData4),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("FM0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum5,
			Unknow2:      0,
			Params:       []uint8(queryData5),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum6,
			Unknow2:      0,
			Params:       []uint8(queryData6),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0033"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum7,
			Unknow2:      0,
			Params:       []uint8(queryData7),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY1018"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum8,
			Unknow2:      0,
			Params:       []uint8(queryData8),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ZY0003"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum9,
			Unknow2:      0,
			Params:       []uint8(queryData9),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0034"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum10,
			Unknow2:      0,
			Params:       []uint8(queryData10),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0009"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum11,
			Unknow2:      0,
			Params:       []uint8(queryData11),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0016"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum12,
			Unknow2:      0,
			Params:       []uint8(queryData12),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0005"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: sashimiSeqNum13,
			Unknow2:      0,
			Params:       []uint8(queryData13),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0303"),
			Unknow6:      1,
		},
	}

	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: "",
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	authKey, decryptedData, err := acc.PackAndGetDecryptedResponseWithAuthKey(seqReqData, seqHeadStruct)
	if err != nil {
		return "", err
	}

	if authKey == "" {
		return "", errors.New("pkgInitAppAsFirstPackage获取authKey错误: authKey不能为空")
	}

	if len(decryptedData.List) <= 0 {
		return "", errors.New("pkgInitAppAsFirstPackage返回的List数据解析失败")
	}

	alreadyGotMSessionID := false // 是否已经获取到了MSessionId

	// 解析出各种文件的最新版本号, 并将获取到的文件最新版本号信息存入acc.FileListDb
	for _, item := range decryptedData.List {

		// logger.Debugf("[BCM]pkgInitAppAsFirstPackage, 序号: %d, 原始返回内容: %s.", item.ListSequence, string(item.Unknow5))

		// 如果取不到这个值，则为文件列表形式的，按照文件列表解析, 这里的"TRAN_SUCCESS"要做特殊逻辑判断
		if item.ListSequence != sashimiSeqNum1 && getTranStatus(item.Unknow5) == constTranStatusEmpty {
			updatedFileList := CSSharkBase.FileInfoList{}
			if err := updatedFileList.ReadFrom(codec.NewReader(item.Unknow5)); err != nil {
				// do nothing
			}

			if len(updatedFileList.List) > 0 {
				for _, fileItem := range updatedFileList.List {

					tmpItem := modelFileInfoItem{
						Name:           fileItem.Name,
						ID:             fileItem.ID,
						CurrentVersion: int32(fileItem.CurrentVersion),
					}

					if fileItem.Name != "" && fileItem.CurrentVersion > 0 {
						// 先判断是否比初始版本的版本号更加新，如果是则更新
						if fileItem.Name == "static" || fileItem.Name == "life" || fileItem.Name == "loan_home" || fileItem.Name == "HP" || fileItem.Name == "transfer" || fileItem.Name == "login" || fileItem.Name == "account" {
							if int32(fileItem.CurrentVersion) <= acc.FileListDb[fileItem.Name].CurrentVersion {
								// do nothing
							} else {
								acc.FileListDb[fileItem.Name] = tmpItem
							}
						} else {
							acc.FileListDb[fileItem.Name] = tmpItem
						}
					}
				}
			}
		}

		// 仅当是首次握手包的时候才需要MSessionID
		// MSessionID的获取逻辑: 遍历第一个返回包的所有MSessionID,第一个出现的即为会话MSessionID
		if getTranStatus(item.Unknow5) == constTranStatusSuccess {
			if (getHeadItem(item.Unknow5, "MSessionId").ToString() != "") && (alreadyGotMSessionID == false) {
				acc.MSessionID = getHeadItem(item.Unknow5, "MSessionId").ToString()
				alreadyGotMSessionID = true
			}
		}

	}

	if (acc.MSessionID == "") || (alreadyGotMSessionID == false) {
		return "", errors.New("pkgInitAppAsFirstPackage未能成功获取MSessionId")
	}

	return authKey, nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 2 在首页点"登录注册"的包, 会检查是否有更新资源
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToLoginPage() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToLoginPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var seqParams = CSSharkBase.CheckForFileListUpdates{
		Unknow0: 0,
		Unknow1: 0,
		Unknow2: 1,
		Unknow3: 0,
		List: []CSSharkBase.FileItemForQuery{
			CSSharkBase.FileItemForQuery{
				Name:           "login",
				Unknow1:        0,
				CurrentVersion: initVersionForLogin,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "static",
				Unknow1:        0,
				CurrentVersion: initVersionForStatic,
			},
		},
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5001,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getSeqParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("pkgSwitchToLoginPage返回的List数据解析失败")
	}
	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 3 点击输入密码的那个框触发的包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgTriggerForInputPassword() (publicKey string, err error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgTriggerForInputPassword")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB1995")
	data.Set("isWap", "0")
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("diviceId", acc.DeviceID)
	data.Set("ecifNo", "")
	data.Set("MSessionId", acc.MSessionID)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB1995"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return "", err
	}

	if len(decryptedData.List) <= 0 {
		return "", errors.New("返回的List数据解析失败")
	}
	logger.Debugf("[BCM]pkgTriggerForInputPassword, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		fmt.Println("No.3", getHeadItem(decryptedData.List[0].Unknow5).ToString()) // @debug

		publicKey = getBodyItem(decryptedData.List[0].Unknow5, "publicKey").ToString()

		if publicKey != "" {
			return publicKey, nil
		}
		return "", fmt.Errorf("publicKey长度为空")

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		rspErrorMsg := getErrorMsg(decryptedData.List[0].Unknow5)
		return "", errors.New(rspErrorMsg)
	}

	return "", errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 6 输入密码后点击登录, bool是账号密码是否验证通过，这里验证通过了也不一定能成功登录(比如换了新设备需要获取手机验证码)
// 第三个参数为ERROR_MESSAGE
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgDoLogin(publicKey string) (bool, string, error) { // @todo
	logger.Debugf("[BCM][STEP_IN]pkgDoLogin")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	loginPassword, err := encryptLoginPassword(acc.getPassword(), publicKey)
	if err != nil {
		return false, "", err
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB0000")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NLG0001")
	data.Set("targetPageCode", "NLG0001")
	data.Set("contractNo", "")
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NLG0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("password", loginPassword)
	data.Set("alias", acc.alias) // @todo
	data.Set("IMEI", "13131312123113132")
	data.Set("changeUserFlag", "0")
	data.Set("paramTrackCode", "MB0000")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0000"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return false, "", err
	}

	if len(decryptedData.List) <= 0 {
		return false, "", errors.New("返回的List数据解析失败")
	}
	logger.Debugf("[BCM]pkgDoLogin, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		acc.ecifNo = getBodyItem(decryptedData.List[0].Unknow5, "ecifNo").ToString()
		acc.contractNo = getBodyItem(decryptedData.List[0].Unknow5, "contractNo").ToString()

		//"contractNo"//: "2030730160",

		return true, "", nil
	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()

		fmt.Println(getHeadItem(decryptedData.List[0].Unknow5).ToString()) // @debug
		logger.Errorf("[BCM][%+v]登录失败, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
		return false, errMessage, errors.New(getErrorMsg(decryptedData.List[0].Unknow5))
	}

	return false, "", errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 7 检查是否是在新设备上登录的(通过changedDiviceFlag=1，如果是则需要获取手机验证码
// 返回值为true: 需要获取手机验证码, 返回值为false则可以直接免手机验证登录
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgCheckIsChangedDevice() (bool, error) { // todo
	logger.Debugf("[BCM][STEP_IN]pkgCheckIsChangedDevice")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB0008")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NLG0001")
	data.Set("targetPageCode", "NLG0001")
	data.Set("contractNo", "")
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NLG0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("loginflag", "")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0008"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return false, err
	}

	if len(decryptedData.List) <= 0 {
		return false, errors.New("返回的List数据解析失败")
	}
	logger.Debugf("[BCM]pkgCheckIsChangedDevice, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		if getBodyItem(decryptedData.List[0].Unknow5, "changedDiviceFlag").ToString() == "1" {
			return true, nil
		}
	}

	return false, nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 800 点击获取短信验证码触发的包, 首次登录时无需点击获取验证码按钮会自动触发一次
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSendLoginSmsCode() (bool, string, error) { // todo
	logger.Debugf("[BCM][STEP_IN]pkgSendLoginSmsCode")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB0202")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TLG1A01")
	data.Set("targetPageCode", "TLG1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TLG1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("tranUnAuthStt", "1")
	data.Set("targetCode", "MB0011")
	data.Set("teleNo", "")
	data.Set("usrMobileNo", "")
	data.Set("cardNo", "")
	data.Set("useLoginMobile", "1")
	data.Set("loginCheck", "1")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0202"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return false, "", err
	}

	if len(decryptedData.List) <= 0 {
		return false, "", errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgSendLoginSmsCode, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		if getBodyItem(decryptedData.List[0].Unknow5, "dynCodeSeq").ToString() != "" {
			return true, "", nil
		}
	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()
		logger.Errorf("[BCM][%+v]发送登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
		return false, errMessage, errors.New(errMessage)
	}

	return false, "未定义的错误", errors.New("未定义的错误")

	// actionCode:MB0202
	/* index:0, actionCode: MB0202
	   {
	     "RSP_BODY": {
	       "dynCodeSeq": "86",
	     },
	     "RSP_HEAD": {
	       "TRAN_SUCCESS": "1",
	     }
	   }

	*/

}

///////////////////////////////////////////////////////////////////////////////
// === No. 900 校验验证码是否通过
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgVerifyLoginSmsCode(smsCode string) (bool, string, error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgVerifyLoginSmsCode")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB0011")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TLG1A01")
	data.Set("targetPageCode", "TLG1A01")
	data.Set("contractNo", "")
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TLG1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("scode", smsCode)
	data.Set("isNotice", "")
	data.Set("isAuth", "")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0011"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return false, "", err
	}

	if len(decryptedData.List) <= 0 {
		return false, "", errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgVerifyLoginSmsCode, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		return true, "", nil
	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {

		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()
		logger.Errorf("[BCM][%+v]校验登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
		return false, errMessage, errors.New(errMessage)
	}

	return false, "未定义的错误", errors.New("未定义的错误")

	// 校验成功时的返回值
	// actionCode:MB0011
	/* index:0, actionCode: MB0011
	   {
	     "RSP_BODY": {
	       "targetPageCode": "TLG1A01",
	       "diviceId": "03021911262027380010000261798904",
	       "isWap": "0",
	       "scode": "301637",
	       "fivePointLost": "0",
	       "User-Agent": "Apache-HttpClient/4.5.2 (Java/1.8.0_191)",
	       "locale": "en_US",
	       "pageCode": "TLG1A01",
	       "isAuth": "",
	       "ninePageCode": "TLG1A01",
	       "processCode": "MB0011",
	     },
	     "RSP_HEAD": {
	       "TRAN_SUCCESS": "1",
	       "MSessionId": "18626244ffffff31db8d2fa7b8bb65d8"
	     }
	   }

	*/

	// 校验失败时的返回值
	// actionCode:
	/* index:0, actionCode:
	   {
	     "RSP_BODY": {},
	     "RSP_HEAD": {
	       "diviceId": "03021911262027380010000261798904",
	       "BUTTON_LEFT": "再试一次",
	       "TRAN_SUCCESS": "0",
	       "ERROR_MESSAGE": "您输入的短信动态密码有误。",
	       "TEMPLATE_NO": "01",
	       "PAGECODE": "TLG1A01",
	       "clientVersion": "",
	       "ERRORCODE_FOR_QUERY": "TLG1A0102",
	       "ERROR_CODE": "MOBS0004SY0005",
	       "SHOW_CODE": "TLG1A01023MiQ5bM01"
	     }
	   }

	*/

}

///////////////////////////////////////////////////////////////////////////////
// === No. 8 登录后发的包, 无需解析
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo8() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo8")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MB0051")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NLG0001")
	data.Set("targetPageCode", "NLG0001")
	data.Set("contractNo", "")
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NLG0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0051"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgSeqNo8, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 9 无需解析
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo9() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo9")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("ecifNo", acc.ecifNo)
	data.Set("alias", acc.alias)
	data.Set("targetPageCode", "")
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("isWap", "0")
	data.Set("contractNo", acc.contractNo)
	data.Set("processCode", "MB0051")
	data.Set("pageCode", "")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	data1 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data1.Set("ecifNo", acc.ecifNo)
	data1.Set("clientVersion", acc.ClientVersion)
	data1.Set("isWap", "0")
	data1.Set("contractNo", acc.contractNo)
	data1.Set("processCode", "AC0102")
	data1.Set("MSessionId", acc.MSessionID)
	data1.Set("diviceId", acc.DeviceID)
	queryData1 := data1.Encode()

	data2 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data2.Set("ecifNo", acc.ecifNo)
	data2.Set("clientVersion", acc.ClientVersion)
	data2.Set("targetPageCode", "MB0104")
	data2.Set("isWap", "0")
	data2.Set("contractNo", acc.contractNo)
	data2.Set("processCode", "MB0104")
	data2.Set("MSessionId", acc.MSessionID)
	data2.Set("diviceId", acc.DeviceID)
	queryData2 := data2.Encode()

	data3 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data3.Set("ecifNo", acc.ecifNo)
	data3.Set("alias", acc.alias)
	data3.Set("targetPageCode", "NAC2001")
	data3.Set("clientVersion", acc.ClientVersion)
	data3.Set("isWap", "0")
	data3.Set("contractNo", acc.contractNo)
	data3.Set("processCode", "ME0021")
	data3.Set("pageCode", "NAC2001")
	data3.Set("MSessionId", acc.MSessionID)
	data3.Set("isOnlyQry", "1")
	data3.Set("diviceId", acc.DeviceID)
	queryData3 := data3.Encode()

	data4 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data4.Set("ecifNo", acc.ecifNo)
	data4.Set("alias", acc.alias)
	data4.Set("targetPageCode", "NAC2001")
	data4.Set("clientVersion", acc.ClientVersion)
	data4.Set("isWap", "0")
	data4.Set("contractNo", acc.contractNo)
	data4.Set("processCode", "ME0024")
	data4.Set("pageCode", "NAC2001")
	data4.Set("MSessionId", acc.MSessionID)
	data4.Set("isOnlyQry", "1")
	data4.Set("diviceId", acc.DeviceID)
	queryData4 := data4.Encode()

	data5 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data5.Set("diviceId", acc.DeviceID)
	data5.Set("clientVersion", acc.ClientVersion)
	data5.Set("tranCode", "")
	data5.Set("isWap", "0")
	data5.Set("pageCode", "SYP0001")
	data5.Set("processCode", "RC0110")
	data5.Set("MSessionId", acc.MSessionID)
	data5.Set("alias", acc.alias)
	data5.Set("contractNo", acc.contractNo)
	data5.Set("ecifNo", acc.ecifNo)
	data5.Set("page", "1")
	data5.Set("pageSize", "10")
	queryData5 := data5.Encode()

	data6 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data6.Set("ecifNo", acc.ecifNo)
	data6.Set("clientVersion", acc.ClientVersion)
	data6.Set("tranCode", "SY0033")
	data6.Set("isWap", "0")
	data6.Set("contractNo", acc.contractNo)
	data6.Set("processCode", "SY0033")
	data6.Set("MSessionId", acc.MSessionID)
	data6.Set("diviceId", acc.DeviceID)
	queryData6 := data6.Encode()

	data7 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data7.Set("ecifNo", acc.ecifNo)
	data7.Set("alias", acc.alias)
	data7.Set("targetPageCode", "")
	data7.Set("clientVersion", acc.ClientVersion)
	data7.Set("isWap", "0")
	data7.Set("contractNo", acc.contractNo)
	data7.Set("processCode", "PL0002")
	data7.Set("pageCode", "")
	data7.Set("MSessionId", acc.MSessionID)
	data7.Set("diviceId", acc.DeviceID)
	queryData7 := data7.Encode()

	data8 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data8.Set("ecifNo", acc.ecifNo)
	data8.Set("alias", acc.alias)
	data8.Set("clientVersion", acc.ClientVersion)
	data8.Set("isWap", "0")
	data8.Set("contractNo", acc.contractNo)
	data8.Set("processCode", "AM0018")
	data8.Set("MSessionId", acc.MSessionID)
	data8.Set("diviceId", acc.DeviceID)
	queryData8 := data8.Encode()

	data9 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data9.Set("ecifNo", acc.ecifNo)
	data9.Set("clientVersion", acc.ClientVersion)
	data9.Set("isWap", "0")
	data9.Set("contractNo", acc.contractNo)
	data9.Set("processCode", "ZY0002")
	data9.Set("MSessionId", acc.MSessionID)
	data9.Set("diviceId", acc.DeviceID)
	queryData9 := data9.Encode()

	data10 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data10.Set("customerNo", acc.contractNo)
	data10.Set("isClearUnread", "0")
	data10.Set("diviceId", acc.DeviceID)
	data10.Set("clientVersion", acc.ClientVersion)
	data10.Set("tranCode", "ME0016")
	data10.Set("isWap", "0")
	data10.Set("MSessionId", acc.MSessionID)
	data10.Set("processCode", "ME0016")
	data10.Set("contractNo", acc.contractNo)
	data10.Set("ecifNo", acc.ecifNo)
	data10.Set("page", "1")
	data10.Set("pageSize", "1000")
	queryData10 := data10.Encode()

	data11 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data11.Set("ecifNo", acc.ecifNo)
	data11.Set("alias", acc.alias)
	data11.Set("targetPageCode", "NAC2001")
	data11.Set("clientVersion", acc.ClientVersion)
	data11.Set("isWap", "0")
	data11.Set("contractNo", acc.contractNo)
	data11.Set("processCode", "ME0021")
	data11.Set("pageCode", "NAC2001")
	data11.Set("MSessionId", acc.MSessionID)
	data11.Set("isOnlyQry", "1")
	data11.Set("diviceId", acc.DeviceID)
	queryData11 := data11.Encode()

	data12 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data12.Set("ecifNo", acc.ecifNo)
	data12.Set("alias", acc.alias)
	data12.Set("targetPageCode", "")
	data12.Set("clientVersion", acc.ClientVersion)
	data12.Set("isWap", "0")
	data12.Set("contractNo", acc.contractNo)
	data12.Set("processCode", "ME0011")
	data12.Set("iswap", "0")
	data12.Set("MSessionId", acc.MSessionID)
	data12.Set("pageCode", "")
	data12.Set("diviceId", acc.DeviceID)
	queryData12 := data12.Encode()

	data13 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data13.Set("MSessionId", acc.MSessionID)
	data13.Set("ecifNo", acc.ecifNo)
	data13.Set("processCode", "PS0005")
	queryData13 := data13.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0051"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData1),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0102"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData2),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0104"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData3),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0021"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData4),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0024"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData5),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("RC0110"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData6),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0033"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData7),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PL0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData8),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AM0018"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData9),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ZY0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData10),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0016"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData11),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0021"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData12),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0011"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData13),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0005"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 10 登录成功后发送一次这个包, 这个包发送了一个时间戳, 以及ecifNo, 无需解析返回值
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo10() { // done
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo10")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	// ===***SpecialStruct2***===
	var specialItem = CSSharkBase.SpecialParamsListItem{
		Unknow0:   3,
		Unknow1:   1033,
		Unknow2:   0,
		Unknow3:   0,
		EcifNo:    acc.ecifNo,
		Unknow4:   0,
		Unknow5:   0,
		Timestamp: int32(time.Now().Unix()), //1577109832, // @todo 时间戳
	}

	var seqParams = CSSharkBase.SpecialParamsStruct{
		Unknow0: 3,
		List: [][]uint8{
			getSpecialParamsItemBytes(specialItem),
		},
		Unknow2: 3,
		Unknow3: 0,
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     30,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getSpecialParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}
	// ===== Response 无需解析，返回值为空
	acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
}

///////////////////////////////////////////////////////////////////////////////
// === No. 11
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo11() error {
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo11")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "MG0107")
	data.Set("isWap", "0")
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("diviceId", acc.DeviceID)
	data.Set("ecifNo", acc.ecifNo)
	data.Set("MSessionId", acc.MSessionID)
	queryData := data.Encode()

	data1 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data1.Set("ecifNo", acc.ecifNo)
	data1.Set("alias", acc.alias)
	data1.Set("targetPageCode", "")
	data1.Set("clientVersion", acc.ClientVersion)
	data1.Set("isWap", "0")
	data1.Set("contractNo", acc.contractNo)
	data1.Set("processCode", "OD0003")
	data1.Set("pageCode", "")
	data1.Set("MSessionId", acc.MSessionID)
	data1.Set("evenType", "4") // @todo
	data1.Set("diviceId", acc.DeviceID)
	queryData1 := data1.Encode()

	data2 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data2.Set("ecifNo", acc.ecifNo)
	data2.Set("alias", acc.alias)
	data2.Set("targetPageCode", "")
	data2.Set("clientVersion", acc.ClientVersion)
	data2.Set("queryType", "1")
	data2.Set("contractNo", acc.contractNo)
	data2.Set("processCode", "CO0001")
	data2.Set("pageCode", "")
	data2.Set("MSessionId", acc.MSessionID)
	data2.Set("isWap", "0")
	data2.Set("diviceId", acc.DeviceID)
	queryData2 := data2.Encode()

	data3 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data3.Set("ecifNo", "")
	data3.Set("alias", "")
	data3.Set("targetPageCode", "")
	data3.Set("clientVersion", acc.ClientVersion)
	data3.Set("isWap", "0")
	data3.Set("contractNo", "")
	data3.Set("processCode", "AM0008")
	data3.Set("pageCode", "")
	data3.Set("MSessionId", acc.MSessionID)
	data3.Set("diviceId", acc.DeviceID)
	queryData3 := data3.Encode()

	data4 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data4.Set("processCode", "MB0701")
	data4.Set("contractNo", acc.contractNo)
	data4.Set("agreeType", "1")
	data4.Set("MSessionId", acc.MSessionID)
	data4.Set("isWap", "0")
	queryData4 := data4.Encode()

	/* 这里有指纹识别的信息, 先删掉
	data5.Set("processCode", "SY2002")
	*/

	data6 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data6.Set("ecifNo", acc.ecifNo)
	data6.Set("alias", acc.alias)
	data6.Set("targetPageCode", "")
	data6.Set("clientVersion", acc.ClientVersion)
	data6.Set("isWap", "0")
	data6.Set("contractNo", acc.contractNo)
	data6.Set("processCode", "MB0051")
	data6.Set("pageCode", "")
	data6.Set("MSessionId", acc.MSessionID)
	data6.Set("diviceId", acc.DeviceID)
	queryData6 := data6.Encode()

	data7 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data7.Set("ecifNo", acc.ecifNo)
	data7.Set("clientVersion", acc.ClientVersion)
	data7.Set("isWap", "0")
	data7.Set("contractNo", acc.contractNo)
	data7.Set("processCode", "AC0102")
	data7.Set("MSessionId", acc.MSessionID)
	data7.Set("diviceId", acc.DeviceID)
	queryData7 := data7.Encode()

	data8 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data8.Set("ecifNo", acc.ecifNo)
	data8.Set("clientVersion", acc.ClientVersion)
	data8.Set("targetPageCode", "MB0104")
	data8.Set("isWap", "0")
	data8.Set("contractNo", acc.contractNo)
	data8.Set("processCode", "MB0104")
	data8.Set("MSessionId", acc.MSessionID)
	data8.Set("diviceId", acc.DeviceID)
	queryData8 := data8.Encode()

	data9 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data9.Set("ecifNo", acc.ecifNo)
	data9.Set("alias", acc.alias)
	data9.Set("targetPageCode", "NAC2001")
	data9.Set("clientVersion", acc.ClientVersion)
	data9.Set("isWap", "0")
	data9.Set("contractNo", acc.contractNo)
	data9.Set("processCode", "ME0021")
	data9.Set("pageCode", "NAC2001")
	data9.Set("MSessionId", acc.MSessionID)
	data9.Set("isOnlyQry", "1")
	data9.Set("diviceId", acc.DeviceID)
	queryData9 := data9.Encode()

	data10 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data10.Set("ecifNo", acc.ecifNo)
	data10.Set("alias", acc.alias)
	data10.Set("targetPageCode", "NAC2001")
	data10.Set("clientVersion", acc.ClientVersion)
	data10.Set("isWap", "0")
	data10.Set("contractNo", acc.contractNo)
	data10.Set("processCode", "ME0024")
	data10.Set("pageCode", "NAC2001")
	data10.Set("MSessionId", acc.MSessionID)
	data10.Set("isOnlyQry", "1")
	data10.Set("diviceId", acc.DeviceID)
	queryData10 := data10.Encode()

	data11 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data11.Set("diviceId", acc.DeviceID)
	data11.Set("clientVersion", acc.ClientVersion)
	data11.Set("tranCode", "")
	data11.Set("isWap", "0")
	data11.Set("pageCode", "SYP0001")
	data11.Set("processCode", "RC0110")
	data11.Set("MSessionId", acc.MSessionID)
	data11.Set("alias", acc.alias)
	data11.Set("contractNo", acc.contractNo)
	data11.Set("ecifNo", acc.ecifNo)
	data11.Set("page", "1")
	data11.Set("pageSize", "10")
	queryData11 := data11.Encode()

	data12 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data12.Set("ecifNo", acc.ecifNo)
	data12.Set("clientVersion", acc.ClientVersion)
	data12.Set("tranCode", "SY0033")
	data12.Set("isWap", "0")
	data12.Set("contractNo", acc.contractNo)
	data12.Set("processCode", "SY0033")
	data12.Set("MSessionId", acc.MSessionID)
	data12.Set("diviceId", acc.DeviceID)
	queryData12 := data12.Encode()

	data13 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data13.Set("ecifNo", acc.ecifNo)
	data13.Set("alias", acc.alias)
	data13.Set("targetPageCode", "")
	data13.Set("clientVersion", acc.ClientVersion)
	data13.Set("isWap", "0")
	data13.Set("contractNo", acc.contractNo)
	data13.Set("processCode", "PL0002")
	data13.Set("pageCode", "")
	data13.Set("MSessionId", acc.MSessionID)
	data13.Set("diviceId", acc.DeviceID)
	queryData13 := data13.Encode()

	data14 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data14.Set("ecifNo", acc.ecifNo)
	data14.Set("alias", acc.alias)
	data14.Set("clientVersion", acc.ClientVersion)
	data14.Set("isWap", "0")
	data14.Set("contractNo", acc.contractNo)
	data14.Set("processCode", "AM0018")
	data14.Set("MSessionId", acc.MSessionID)
	data14.Set("diviceId", acc.DeviceID)
	queryData14 := data14.Encode()

	data15 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data15.Set("ecifNo", acc.ecifNo)
	data15.Set("clientVersion", acc.ClientVersion)
	data15.Set("isWap", "0")
	data15.Set("contractNo", acc.contractNo)
	data15.Set("processCode", "ZY0002")
	data15.Set("MSessionId", acc.MSessionID)
	data15.Set("diviceId", acc.DeviceID)
	queryData15 := data15.Encode()

	data16 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data16.Set("customerNo", "2030730160") // @todo
	data16.Set("isClearUnread", "0")
	data16.Set("diviceId", acc.DeviceID)
	data16.Set("clientVersion", acc.ClientVersion)
	data16.Set("tranCode", "ME0016")
	data16.Set("isWap", "0")
	data16.Set("MSessionId", acc.MSessionID)
	data16.Set("processCode", "ME0016")
	data16.Set("contractNo", acc.contractNo)
	data16.Set("ecifNo", acc.ecifNo)
	data16.Set("page", "1")
	data16.Set("pageSize", "1000")
	queryData16 := data16.Encode()

	data17 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data17.Set("ecifNo", acc.ecifNo)
	data17.Set("alias", acc.alias)
	data17.Set("targetPageCode", "NAC2001")
	data17.Set("clientVersion", acc.ClientVersion)
	data17.Set("isWap", "0")
	data17.Set("contractNo", acc.contractNo)
	data17.Set("processCode", "ME0021")
	data17.Set("pageCode", "NAC2001")
	data17.Set("MSessionId", acc.MSessionID)
	data17.Set("isOnlyQry", "1")
	data17.Set("diviceId", acc.DeviceID)
	queryData17 := data17.Encode()

	data18 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data18.Set("ecifNo", acc.ecifNo)
	data18.Set("alias", acc.alias)
	data18.Set("targetPageCode", "")
	data18.Set("clientVersion", acc.ClientVersion)
	data18.Set("isWap", "0")
	data18.Set("contractNo", acc.contractNo)
	data18.Set("processCode", "ME0011")
	data18.Set("iswap", "0")
	data18.Set("MSessionId", acc.MSessionID)
	data18.Set("pageCode", "")
	data18.Set("diviceId", acc.DeviceID)
	queryData18 := data18.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MG0107"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData1),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("OD0003"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData2),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("CO0001"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData3),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AM0008"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData4),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0701"),
			Unknow6:      1,
		},
		/*
						CSSharkBase.RequestList{
			ListType:      0,
							ListSequence: acc.getListSequenceNumber(),
							Unknow2:      0,
							Params:       []uint8(queryData5),
							ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
							HeaderMap:    getSeqMapHeader("SY2002"),
							Unknow6:      1,
						},
		*/
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData6),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0051"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData7),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0102"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData8),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("MB0104"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData9),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0021"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData10),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0024"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData11),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("RC0110"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData12),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0033"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData13),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PL0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData14),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AM0018"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData15),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ZY0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData16),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0016"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData17),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0021"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData18),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("ME0011"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}

	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 12
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo12() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo12")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("ecifNo", acc.ecifNo)
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("isWap", "0")
	data.Set("contractNo", acc.contractNo)
	data.Set("processCode", "PS0004")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0004"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析返回包
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 14 无需解析返回包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo14() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo14")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("orderCustomize", "%5B%7B%22Title%22%3A%22%E4%B8%BA%E6%88%91%E6%8E%A8%E8%8D%90%5C%2F%E6%88%91%E7%9A%84%E5%85%B3%E6%B3%A8%22%2C%22Type%22%3A%220%22%2C%22ItemCode%22%3A%22GG0001%22%7D%2C%7B%22Title%22%3A%22%E6%88%91%E7%9A%84%E6%B4%BB%E5%8A%A8%22%2C%22Type%22%3A%222%22%2C%22ItemCode%22%3A%22GG0003%22%7D%2C%7B%22Title%22%3A%22%E4%BA%A4%E9%93%B6%E7%9B%B4%E6%92%AD%E9%97%B4%22%2C%22Type%22%3A%226%22%2C%22ItemCode%22%3A%22JJ0002%22%7D%5D")
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("ecifNo", acc.ecifNo)
	data.Set("isWap", "0")
	data.Set("contractNo", acc.contractNo)
	data.Set("processCode", "PS0003")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0003"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析返回包
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 15
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSeqNo15() error {
	logger.Debugf("[BCM][STEP_IN]pkgSeqNo15")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("ecifNo", acc.ecifNo)
	data.Set("alias", acc.alias)
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("isWap", "0")
	data.Set("contractNo", acc.contractNo)
	data.Set("processCode", "PS0001")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	data1 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data1.Set("ecifNo", acc.ecifNo)
	data1.Set("alias", acc.alias)
	data1.Set("clientVersion", acc.ClientVersion)
	data1.Set("isWap", "0")
	data1.Set("contractNo", acc.contractNo)
	data1.Set("processCode", "PS0002")
	data1.Set("MSessionId", acc.MSessionID)
	data1.Set("diviceId", acc.DeviceID)
	queryData1 := data1.Encode()

	data2 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data2.Set("ecifNo", acc.ecifNo)
	data2.Set("clientVersion", acc.ClientVersion)
	data2.Set("userId", acc.contractNo) // @todo "2030730160"
	data2.Set("isWap", "0")
	data2.Set("processCode", "HA0005")
	data2.Set("MSessionId", acc.MSessionID)
	data2.Set("diviceId", acc.DeviceID)
	queryData2 := data2.Encode()

	data3 := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data3.Set("ecifNo", acc.ecifNo)
	data3.Set("alias", acc.alias)
	data3.Set("IMEI", "131313131313")
	data3.Set("clientVersion", acc.ClientVersion)
	data3.Set("isWap", "0")
	data3.Set("contractNo", acc.contractNo)
	data3.Set("processCode", "SY1017")
	data3.Set("MSessionId", acc.MSessionID)
	data3.Set("diviceId", acc.DeviceID)
	queryData3 := data3.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0001"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData1),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("PS0002"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData2),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("HA0005"),
			Unknow6:      1,
		},
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData3),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY1017"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析返回包
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 16 点击"账户查询"触发的包, 转到账户查询首页触发的查询文件更新的包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToAccountPage() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToAccountPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var seqParams = CSSharkBase.CheckForFileListUpdates{
		Unknow0: 0,
		Unknow1: 0,
		Unknow2: 1,
		Unknow3: 0,
		List: []CSSharkBase.FileItemForQuery{
			CSSharkBase.FileItemForQuery{
				Name:           "account",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["account"].CurrentVersion,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "static",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["static"].CurrentVersion,
			},
		},
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5001,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getSeqParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
	}

	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== 无需解析返回值
	_, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 17 点击"账户查询"触发的包, 获取可用卡的列表及余额信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetDebitCardList() ([]modelDebitCardListItem, error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgGetDebitCardList")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "AC0001")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NAC0001")
	data.Set("targetPageCode", "NAC0001")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NAC0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0001"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	debitCardList := []modelDebitCardListItem{}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgGetDebitCardList, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		myAccountListString := getBodyItem(decryptedData.List[0].Unknow5, "myAccountList").ToString()

		err := jsoniter.Unmarshal([]byte(myAccountListString), &debitCardList)
		if err != nil {
			return nil, err
		}
		return debitCardList, nil

	}

	return nil, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 31 在首页点击转账, 先获取transfer及static相关的js及html是否有更新
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetDiffForTransferAndStatic() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgGetDiffForTransferAndStatic")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var seqParams = CSSharkBase.CheckForFileListUpdates{
		Unknow0: 0,
		Unknow1: 0,
		Unknow2: 1,
		Unknow3: 0,
		List: []CSSharkBase.FileItemForQuery{
			CSSharkBase.FileItemForQuery{
				Name:           "transfer",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["transfer"].CurrentVersion,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "static",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["static"].CurrentVersion,
			},
		},
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5001,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getSeqParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	_, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 32 在首页点击转账, 切换到转账导航首页
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToTransferMainPage() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToTransferMainPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0001")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR0001")
	data.Set("targetPageCode", "NTR0001")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("payeelistAbstract", "")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0001"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 33 在首页点击转账, 成功切换到转账首页发的确认包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToTransferMainPageDone() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToTransferMainPageDone")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "SY0034")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR0001")
	data.Set("targetPageCode", "NTR0001")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR0001")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("srcPageCode", "NTR0001")
	data.Set("flag", "0")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0034"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 34 在转账页点击转账到银行账号, 从这个包的返回值里获取了每天当天转账限额等一系列信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToTransferToBankCardPage() ([]modelBankCardInfo, error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToTransferToBankCardPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0002")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("tranFlag", "1")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0002"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgSwitchToTransferToBankCardPage, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	accListString := getBodyItem(decryptedData.List[0].Unknow5, "accList").ToString()

	accList := []modelBankCardInfo{}

	parseArrayError := jsoniter.Unmarshal([]byte(accListString), &accList)
	if parseArrayError != nil { // don't forget handle errors
		logger.Debugf("[BCM]CheckSessionStatus: 反序列化accList失败, 错误内容: %+v.", parseArrayError)
		return nil, parseArrayError
	}

	if len(accList) <= 0 {
		logger.Debugf("[BCM]CheckSessionStatus: 无可用的银行卡, accList为空.")
		return nil, errors.New("无可用的银行卡")
	}

	return accList, nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 40 输入卡号前6位触发的获取银行bankNo信息的包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetBankBaseInfoWithBankCardNoFirst6Digits(firstSixDigitsNumber string) (*modelTargetBankBaseInfo, error) { // @todo
	logger.Debugf("[BCM][STEP_IN]pkgGetBankBaseInfoWithBankCardNoFirst6Digits")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0025")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("account", firstSixDigitsNumber) // "621785"
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0025"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	logger.Debugf("[BCM]pkgGetBankBaseInfoWithBankCardNoFirst6Digits, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		targetBankBaseInfo := &modelTargetBankBaseInfo{}

		err := jsoniter.Unmarshal(getBodyItemToBytes(decryptedData.List[0].Unknow5), targetBankBaseInfo)
		if err != nil {
			return nil, err
		}

		logger.Debugf("[BCM]pkgGetBankBaseInfoWithBankCardNoFirst6Digits, 银行BankNo信息: %+v.", targetBankBaseInfo)

		return targetBankBaseInfo, nil
	}

	return nil, errors.New("获取银行bankNo失败")

	// actionCode:TR0025
	/* index:0, actionCode: TR0025
	   {
	     "RSP_BODY": {
	       "code": "104100000004",
	       "bankName": "中国银行",
	       "type": "104",
	     }
	   }
	*/

}

///////////////////////////////////////////////////////////////////////////////
// === No. 41 通过上一步获取到的银行bankNo进一步查询银行信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetBankExtraInfoWithBankNo(bankCodeNumber string) (*modelTargetBankExtraInfo, error) { // done
	logger.Debugf("[BCM][STEP_IN]pkgGetBankExtraInfoWithBankNo")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0044")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("bankNo", bankCodeNumber)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0044"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	logger.Debugf("[BCM]pkgGetBankExtraInfoWithBankNo, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		//return nil

		targetBankExtraInfo := &modelTargetBankExtraInfo{}

		err := jsoniter.Unmarshal(getBodyItemToBytes(decryptedData.List[0].Unknow5), targetBankExtraInfo)
		if err != nil {
			return nil, err
		}
		return targetBankExtraInfo, nil
	}

	return nil, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 42 获取转账目标的银行卡的相关信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetTargetBankCardInfo(targetAccount string) error { // done
	logger.Debugf("[BCM][STEP_IN]pkgGetTargetBankCardInfo")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "CR0001")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("account", targetAccount)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("CR0001"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}

	logger.Debugf("[BCM]pkgGetTargetBankCardInfo, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		return nil
	}

	return errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 43 根据上一个包构造转账信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgBuildTransferInfo(limitInfo *modelTransferLimitInfo) (*modelBuildTransferInfoResponse, error) { // @todo
	logger.Debugf("[BCM][STEP_IN]pkgBuildTransferInfo")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0009")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("logBalance", limitInfo.LogBalance)
	data.Set("type", "")
	data.Set("cardNo", acc.useCardNo)
	data.Set("toCardNo", acc.transferTargetAccount)
	data.Set("toAccName", acc.transferTargetName)
	data.Set("recAccNo", "")
	data.Set("transum", acc.transferAmount) // 转账金额

	data.Set("toOpenBankNo", acc.toOpenBankNo)
	data.Set("toOpenBank", acc.toOpenBank)
	data.Set("toOpenAreaNo", acc.toOpenAreaNo)
	data.Set("toOpenArea", acc.toOpenArea)
	data.Set("toOpenCityNo", acc.toOpenCityNo)
	data.Set("toOpenCity", acc.toOpenCity)
	data.Set("toOpenNetSpotNo", acc.toOpenNetSpotNo)
	data.Set("toOpenNetSpot", acc.toOpenNetSpot)
	data.Set("toPartyId", acc.toPartyID)
	data.Set("toParty", acc.toParty)

	data.Set("sendSmsFlag", "0")
	data.Set("toMobile", "")
	data.Set("remark", acc.transferComment)
	data.Set("riskFlag", "0")
	data.Set("tranTimeFlag", "0")
	data.Set("isOutTenMyriad", "false")

	//这里都是float64的, 需要进行格式化输出
	data.Set("yearUseableAmt", limitInfo.YearUseableAmt)
	data.Set("dayUseablePenAmount", limitInfo.DayUseablePenAmount)
	data.Set("useableLimit", limitInfo.UseableLimit)
	data.Set("singleTransferLimit", limitInfo.SingleTransferLimit)
	data.Set("nowTransferedTotal", limitInfo.NowTransferedTotal)

	data.Set("continueTranFlag", "0")
	data.Set("continueChangeCard", "0")
	data.Set("isSupportSuperBank", acc.isSupportSuperBank)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0009"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	logger.Debugf("[BCM]pkgBuildTransferInfo, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		buildTransferInfoResponse := &modelBuildTransferInfoResponse{}

		err := jsoniter.Unmarshal(getBodyItemToBytes(decryptedData.List[0].Unknow5), buildTransferInfoResponse)
		if err != nil {
			return nil, err
		}
		return buildTransferInfoResponse, nil

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()

		return nil, fmt.Errorf("[%+v]构造转账信息返回结果失败, 代码: %+v, 信息: %+v", acc.Account, errCode, errMessage) // @todo
	}

	return nil, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 44 processCode=TR0012 获取转账需要的一些必要参数
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetTransferExtraParams() (*modelTransferExtraParams, error) {
	logger.Debugf("[BCM][STEP_IN]pkgGetTransferExtraParams")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0012")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NTR1A01")
	data.Set("targetPageCode", "NTR1A01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NTR1A01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("cardNo", acc.useCardNo)
	data.Set("toCardNo", acc.transferTargetAccount)
	data.Set("toAccName", acc.transferTargetName)
	data.Set("type", acc.toBankType)
	data.Set("recAccNo", "")
	data.Set("transum", acc.transferAmount)
	data.Set("toOpenBankNo", acc.toOpenBankNo)
	data.Set("feePayMode", acc.feePayMode)
	data.Set("toOpenBank", acc.toOpenBank)
	data.Set("toOpenCityNo", acc.toOpenCityNo)
	data.Set("changeFlag", "")
	//data.Set("cardType", acc.cardType)
	data.Set("cardType", "")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0012"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	logger.Debugf("[BCM]pkgGetTransferExtraParams, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		extraParams := &modelTransferExtraParams{}

		if getBodyItem(decryptedData.List[0].Unknow5, "hfeRateCode").ToString() != "" {
			extraParams.HfeRateCode = getBodyItem(decryptedData.List[0].Unknow5, "hfeRateCode").ToString()
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "feePayMode").ToString() != "" {
			extraParams.FeePayMode = getBodyItem(decryptedData.List[0].Unknow5, "feePayMode").ToString()
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "realFee").ToString() != "" {
			extraParams.RealFee = getBodyItem(decryptedData.List[0].Unknow5, "realFee").ToString()
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "realFee").ToString() != "" {
			extraParams.FeeTcaNo = getBodyItem(decryptedData.List[0].Unknow5, "feeTcaNo").ToString()
		}

		return extraParams, nil

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()

		return nil, fmt.Errorf("[%+v]构造转账信息返回结果失败, 代码: %+v, 信息: %+v", acc.Account, errCode, errMessage)
	}

	return nil, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 45 跳到输入交易密码的那个页面触发的获取转账验证码的包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSendTransferSmsCode() (bool, error) { // todo
	logger.Debugf("[BCM][STEP_IN]pkgSendTransferSmsCode")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0395")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TTR1C01")
	data.Set("targetPageCode", "TTR1C01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TTR1C01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("tranUnAuthStt", "1")
	data.Set("targetCode", "TR0013")
	data.Set("teleNo", "")
	data.Set("usrMobileNo", acc.alias)
	data.Set("preText", "")
	data.Set("smsText", "")
	data.Set("cardNo", "")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0395"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return false, err
	}

	if len(decryptedData.List) <= 0 {
		return false, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return false, errSession
	}

	logger.Debugf("[BCM]pkgSendTransferSmsCode, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		if getBodyItem(decryptedData.List[0].Unknow5, "dynCodeSeq").ToString() != "" {
			return true, nil
		}
	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {

		rspErrorMsg := getErrorMsg(decryptedData.List[0].Unknow5)
		return false, errors.New(rspErrorMsg)
	}

	return false, errors.New("未定义的错误")

	// actionCode:TR0395
	/* index:0, actionCode: TR0395
	   {
	     "RSP_BODY": {
	       "targetPageCode": "TTR1C01",
	       "contractNo": "2030730160",
	       "preText": "",
	       "cardNo": "",
	       "smsText": "",
	       "dynCodeSeq": "15",
	       "isWap": "0",
	       "tranUnAuthStt": "1",
	       "dynMobile": "188********",
	       "teleNo": "",
	       "status": "0"
	     },
	   }
	*/

}

///////////////////////////////////////////////////////////////////////////////
// === No. 55 点击输入交易密码框触发的
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgTriggerForInputPayPassword() (*modelPayPasswordKeyMaps, error) {
	logger.Debugf("[BCM][STEP_IN]pkgTriggerForInputPayPassword")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("ecifNo", acc.ecifNo)
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("isWap", "0")
	data.Set("encryptType", "default")
	data.Set("processCode", "TR0397")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0397"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, err
	}

	if len(decryptedData.List) <= 0 {
		return nil, errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, errSession
	}

	logger.Debugf("[BCM]pkgTriggerForInputPayPassword, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		jsonBytes := decryptedData.List[0].Unknow5

		// 读取相关参数
		keys := getBodyItem(jsonBytes, "keys").ToString()
		publicKey := getBodyItem(jsonBytes, "publicKey").ToString()
		keyMapsBytes := getBodyItemToBytes(jsonBytes, "keyMaps")

		if len(keys) != 10 {
			fmt.Println("映射表长度不正确")
			return nil, fmt.Errorf("映射表长度不正确, 错误的长度: %d", len(keys))
		}

		// 读取keyMaps映射表
		var rspKeyMaps []string

		err := jsoniter.Unmarshal(keyMapsBytes, &rspKeyMaps)
		if err != nil {
			return nil, fmt.Errorf("键盘映射表反序列化错误: %+v", err)
		}

		var correctKeysMap map[int]string

		correctKeysMap = make(map[int]string)

		for i := 0; i < len(rspKeyMaps); i++ {
			switch rspKeyMaps[i] {
			case constPayPwdKeysMapForNumber0:
				correctKeysMap[0] = keys[i : i+1]
			case constPayPwdKeysMapForNumber1:
				correctKeysMap[1] = keys[i : i+1]
			case constPayPwdKeysMapForNumber2:
				correctKeysMap[2] = keys[i : i+1]
			case constPayPwdKeysMapForNumber3:
				correctKeysMap[3] = keys[i : i+1]
			case constPayPwdKeysMapForNumber4:
				correctKeysMap[4] = keys[i : i+1]
			case constPayPwdKeysMapForNumber5:
				correctKeysMap[5] = keys[i : i+1]
			case constPayPwdKeysMapForNumber6:
				correctKeysMap[6] = keys[i : i+1]
			case constPayPwdKeysMapForNumber7:
				correctKeysMap[7] = keys[i : i+1]
			case constPayPwdKeysMapForNumber8:
				correctKeysMap[8] = keys[i : i+1]
			case constPayPwdKeysMapForNumber9:
				correctKeysMap[9] = keys[i : i+1]
			}
		}

		keyMapsInfo := &modelPayPasswordKeyMaps{
			Keys:          keys,
			PublicKey:     publicKey,
			CorrectedKeys: correctKeysMap,
		}

		return keyMapsInfo, nil

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		rspErrorMsg := getErrorMsg(decryptedData.List[0].Unknow5)
		return nil, errors.New(rspErrorMsg)
	}

	return nil, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === No. 56 点击确认转账触发的包, 这里同时提交了转账验证码
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgDoConfirmTransfer(smsCode string) (*modelConfirmTransferResponse, string, string, error) {
	logger.Debugf("[BCM][STEP_IN]pkgDoConfirmTransfer")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	encryptedPayPassword, err := encryptPayPassword(acc.getPayPassword(), acc.keyMapsInfo)
	if err != nil {
		return nil, "", "", err
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0013")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TTR1C01")
	data.Set("targetPageCode", "TTR1C01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TTR1C01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("page_name", "转账汇款")
	data.Set("cardNo", acc.useCardNo)
	data.Set("type", acc.transferConfirmType)
	data.Set("toCardNo", acc.transferTargetAccount)
	data.Set("toAccName", acc.transferTargetName)
	data.Set("recAccNo", "")
	data.Set("transum", acc.transferAmount)
	data.Set("toOpenBankNo", acc.toOpenBankNo)
	data.Set("toOpenBank", acc.toOpenBank)
	data.Set("toOpenAreaNo", acc.toOpenAreaNo)
	data.Set("toOpenArea", acc.toOpenArea)
	data.Set("toOpenCityNo", acc.toOpenCityNo)
	data.Set("toOpenCity", acc.toOpenCity)
	data.Set("toOpenNetSpotNo", acc.toOpenNetSpotNo)
	data.Set("toOpenNetSpot", acc.toOpenNetSpot)
	data.Set("toPartyId", acc.toPartyID)
	data.Set("toParty", acc.toParty)
	data.Set("sendSmsFlag", "0")
	data.Set("remark", acc.transferComment)
	data.Set("feePayMode", acc.feePayMode)
	data.Set("realFee", acc.realFee)
	data.Set("feeTcaNo", acc.feeTcaNo)
	data.Set("hfeRateCode", acc.hfeRateCode)
	data.Set("password", encryptedPayPassword)
	data.Set("confirmReTranRisk", "")
	data.Set("imageCode", acc.imageCode)
	data.Set("sign", "")
	data.Set("scode", smsCode) // @todo 转账验证码
	data.Set("authMode", "0")
	data.Set("speChkResult", "")
	data.Set("confirmFlag", "")
	data.Set("confirmReason", "")
	data.Set("cardType", "")
	data.Set("tranTimeFlag", "0")
	data.Set("isSelfAccount", "false")
	data.Set("continueTranFlag", "")
	data.Set("isSupportSuperBank", acc.isSupportSuperBank)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0013"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	tranStatus := ""

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, tranStatus, "", err
	}

	if len(decryptedData.List) <= 0 {
		return nil, tranStatus, "", errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, tranStatus, "", errSession
	}

	logger.Debugf("[BCM]pkgDoConfirmTransfer, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	// 需要获取的三个值
	// sequenceNo
	// transferType
	// isSuccess

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {

		body := getBodyItem(decryptedData.List[0].Unknow5).ToString()

		tranStatus = "1"

		confirmTransferResponse := &modelConfirmTransferResponse{}

		err := jsoniter.Unmarshal(getBodyItemToBytes(decryptedData.List[0].Unknow5), confirmTransferResponse)
		if err != nil {
			return nil, tranStatus, body, err
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "sequenceNo").ToString() != "" {
			confirmTransferResponse.SequenceNo = getBodyItem(decryptedData.List[0].Unknow5, "sequenceNo").ToString()
		} else {
			return nil, tranStatus, body, errors.New("获取确认转账sequenceNo失败")
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "transferType").ToString() != "" {
			confirmTransferResponse.TransferType = getBodyItem(decryptedData.List[0].Unknow5, "transferType").ToString()
		} else {
			return nil, tranStatus, body, errors.New("获取确认转账transferType失败")
		}

		if getBodyItem(decryptedData.List[0].Unknow5, "isSuccess").ToString() != "" {
			confirmTransferResponse.IsSuccess = getBodyItem(decryptedData.List[0].Unknow5, "isSuccess").ToString()
		}

		return confirmTransferResponse, tranStatus, body, nil

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		body := getBodyItem(decryptedData.List[0].Unknow5).ToString()
		tranStatus = "0"

		errMessage := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_MESSAGE").ToString()
		errCode := getHeadItem(decryptedData.List[0].Unknow5, "ERROR_CODE").ToString()

		return nil, tranStatus, body, fmt.Errorf("[%+v]构造转账信息返回结果失败, 代码: %+v, 信息: %+v", acc.Account, errCode, errMessage)
	}

	return nil, tranStatus, "", fmt.Errorf("[%+v]构造转账信息返回结果失败, 未定义的错误", acc.Account)
}

///////////////////////////////////////////////////////////////////////////////
// === No. 57 请求跳到转账成功页面的包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgTriggerForRequestSuccessfulTransferPage() error { // done
	logger.Debugf("[BCM][STEP_IN]pkgTriggerForRequestSuccessfulTransferPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "SY0034")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TTR1D01")
	data.Set("targetPageCode", "TTR1D01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TTR1D01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("srcPageCode", "TTR1D01")
	data.Set("flag", "0")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("SY0034"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgTriggerForRequestSuccessfulTransferPage, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil

}

///////////////////////////////////////////////////////////////////////////////
// === No. 58 跳转到最终成功转账的结果页
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToSuccessfulTransferPage() error {
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToSuccessfulTransferPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "TR0032")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "TTR1D01")
	data.Set("targetPageCode", "TTR1D01")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "TTR1D01")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")

	data.Set("cardNo", acc.useCardNo)
	data.Set("toCardNo", acc.transferTargetAccount)
	data.Set("toAccName", acc.transferTargetName)
	data.Set("transum", acc.transferAmount)

	data.Set("toOpenAreaNo", acc.toOpenAreaNo)
	data.Set("toOpenCityNo", acc.toOpenCityNo)
	data.Set("transferType", acc.transferType) // @todo
	data.Set("rcvBankCode", acc.toOpenBankNo)
	data.Set("rcvBankName", acc.toOpenBank)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("TR0032"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}

	logger.Debugf("[BCM]pkgSwitchToSuccessfulTransferPage, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		return nil

	} else if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusFailed {
		rspErrorMsg := getErrorMsg(decryptedData.List[0].Unknow5)
		return errors.New(rspErrorMsg)
	}

	return errors.New("未定义的错误")
}

//////////////////////////////////////////////////////
// 账单
////////////

///////////////////////////////////////////////////////////////////////////////
// === No. 19 切换到交易明细首页
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgSwitchToBillPage() error {
	logger.Debugf("[BCM][STEP_IN]pkgSwitchToBillPage")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "AC0000")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NAC0002")
	data.Set("targetPageCode", "NAC0002")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NAC0002")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("accountType", "1")
	data.Set("queryBalance", "0")
	data.Set("qryFaceflag", "1")
	data.Set("flag", "10") // @todo
	data.Set("lossFlag", "1")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0000"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgSwitchToBillPage, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 20 默认拉取一遍当月的流水
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetDefaultBillList() error {
	logger.Debugf("[BCM][STEP_IN]pkgGetDefaultBillList")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "AC0004")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NAC0002")
	data.Set("targetPageCode", "NAC0002")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NAC0002")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("account", acc.useCardNo)
	data.Set("month", "")
	data.Set("currency", "CNY")
	data.Set("page", "1")
	data.Set("pageSize", "20")
	data.Set("dateFlag", "0")
	data.Set("beginRecord", "")
	data.Set("lastPage", "")
	data.Set("DCFlag", "")
	data.Set("tradePlace", "")
	data.Set("tradeWay", "")
	data.Set("tradeBank", "")
	data.Set("tradeBankFlag", "")
	data.Set("accName", "")
	data.Set("accNo", "")
	data.Set("remark", "")
	data.Set("bankName", "false")
	data.Set("tradeBankNameInput", "")
	data.Set("tradeAccountNameInput", "")
	data.Set("summaryInput", "")
	data.Set("code", "0004")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0004"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	if len(decryptedData.List) <= 0 {
		return errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgGetDefaultBillList, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return errSession
	}
	return nil
}

///////////////////////////////////////////////////////////////////////////////
// === No. 21 获取一遍最新文件改动信息
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetDiffForAccountAndStatic() { // done
	logger.Debugf("[BCM][STEP_IN]pkgGetDiffForAccountAndStatic")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	var seqParams = CSSharkBase.CheckForFileListUpdates{
		Unknow0: 0,
		Unknow1: 0,
		Unknow2: 1,
		Unknow3: 0,
		List: []CSSharkBase.FileItemForQuery{
			CSSharkBase.FileItemForQuery{
				Name:           "account",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["account"].CurrentVersion,
			},
			CSSharkBase.FileItemForQuery{
				Name:           "static",
				Unknow1:        0,
				CurrentVersion: acc.FileListDb["static"].CurrentVersion,
			},
		},
	}

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     5001,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       getSeqParamsBytes(seqParams),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    []byte{0x08, 0x0C, 0x18, 0x0C, 0x28, 0x0C, 0x36, 0x00},
			Unknow6:      0,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response 无需解析
	acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)

}

///////////////////////////////////////////////////////////////////////////////
// === No. 22 按时间筛选交易明细  和第24个包只有页码不同(page=2)
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgGetBillListByTime(startDate, endDate string, page int) (billList []modelBillInfo, isLastPage bool, err error) {
	logger.Debugf("[BCM][STEP_IN]pkgGetBillListByTime")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("processCode", "AC0005")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("isWap", "0")
	data.Set("pageCode", "NAC0002")
	data.Set("targetPageCode", "NAC0002")
	data.Set("contractNo", acc.contractNo)
	data.Set("diviceId", acc.DeviceID)
	data.Set("method", "")
	data.Set("ninePageCode", "NAC0002")
	data.Set("fivePointLost", "0")
	data.Set("cardDateLost", "0")
	data.Set("account", acc.useCardNo)
	data.Set("month", "")
	data.Set("currency", "CNY")
	data.Set("page", fmt.Sprintf("%d", page))
	data.Set("pageSize", "20")
	data.Set("dateFlag", "1")
	data.Set("beginRecord", "")
	data.Set("lastPage", "")
	data.Set("DCFlag", "")
	data.Set("tradePlace", "")
	data.Set("tradeWay", "")
	data.Set("tradeBank", "")
	data.Set("tradeBankFlag", "")
	data.Set("accName", "")
	data.Set("accNo", "")
	data.Set("remark", "")
	data.Set("bankName", "false")
	data.Set("tradeBankNameInput", "")
	data.Set("tradeAccountNameInput", "")
	data.Set("summaryInput", "")
	data.Set("code", "0005")
	data.Set("beginDate", startDate)
	data.Set("monthValue", "")
	data.Set("endDate", endDate)
	data.Set("blanceFlag", "0")
	data.Set("changeColorflag", "true")
	data.Set("leftTextFlag", "true")
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("AC0005"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// ===== Response
	decryptedData, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return nil, true, err
	}

	billList = []modelBillInfo{}

	if len(decryptedData.List) <= 0 {
		return nil, true, errors.New("返回的List数据解析失败")
	}

	logger.Debugf("[BCM]pkgGetBillListByTime, 原始返回内容: %s.", string(decryptedData.List[0].Unknow5))

	if _, errSession := acc.CheckSessionStatus(decryptedData.List); errSession != nil {
		return nil, true, errSession
	}

	if getTranStatus(decryptedData.List[0].Unknow5) == constTranStatusSuccess {
		accountDetailsList := getBodyItem(decryptedData.List[0].Unknow5, "accountDetailsList").ToString()

		err := jsoniter.Unmarshal([]byte(accountDetailsList), &billList)
		if err != nil {
			return nil, true, err
		}
		if getBodyItem(decryptedData.List[0].Unknow5, "page", "lastPage").ToString() == "F" {
			// 不是最后一页
			isLastPage = false
		} else if getBodyItem(decryptedData.List[0].Unknow5, "page", "lastPage").ToString() == "T" {
			// 最后一页
			isLastPage = true
		} else {
			if getBodyItem(decryptedData.List[0].Unknow5, "endFlag").ToString() == "0" {
				isLastPage = true
			} else if getBodyItem(decryptedData.List[0].Unknow5, "endFlag").ToString() == "1" {
				isLastPage = false
			} else {
				isLastPage = true
			}
		}

		return billList, isLastPage, nil
	}

	return nil, true, errors.New("未定义的错误")
}

///////////////////////////////////////////////////////////////////////////////
// === 心跳包，只有当成功登录后才发心跳包
///////////////////////////////////////////////////////////////////////////////

func (acc *Account) pkgHeartBeat() error { //done
	logger.Debugf("[BCM][STEP_IN]pkgHeartBeat")

	var seqNum int32 = acc.getSequenceNumber()
	// var baselineListSeqNum int32 = acc.getListSequenceNumber()

	var seqHeadStruct = CSSharkBase.RequestPacketHeadStruct{
		Unknow0:       20,
		UnknowAuthKey: acc.SecAuthKey,
		Unknow2:       0,
		Unknow3:       "",
		Unknow4:       2,
		SeqNo:         seqNum,
		Unknow6:       0,
	}

	data := url.Values{}
	//sashimiSeqNum := sashimiSeqNum +
	data.Set("ecifNo", acc.ecifNo)
	data.Set("clientVersion", acc.ClientVersion)
	data.Set("tranCode", "LM0011")
	data.Set("isWap", "0")
	data.Set("contractNo", acc.contractNo)
	data.Set("processCode", "LM0011")
	data.Set("MSessionId", acc.MSessionID)
	data.Set("diviceId", acc.DeviceID)
	queryData := data.Encode()

	var seqRequestList = []CSSharkBase.RequestList{
		CSSharkBase.RequestList{
			ListType:     0,
			ListSequence: acc.getListSequenceNumber(),
			Unknow2:      0,
			Params:       []uint8(queryData),
			ZeroTag:      CSSharkBase.ZeroTagStruct{Unknow0: 0},
			HeaderMap:    getSeqMapHeader("LM0011"),
			Unknow6:      1,
		},
	}
	var seqReqData = CSSharkBase.RequestShark{
		SeqNo:   seqNum,
		Unknow1: 0,
		Unknow2: CSSharkBase.RequestSharkUnknowStruct1{
			Unknow0: 1,
			Unknow1: 0,
			GUID:    acc.GUID,
			Unknow3: "",
			Unknow4: acc.SecAuthKey,
			Unknow5: 4,
			Unknow6: 14,
			Unknow7: 0,
			Unknow8: 0,
			Unknow9: "",
			Unknow10: CSSharkBase.UnknowStruct2{
				Unknow0:   2,
				VIDTicket: acc.VIDTicket,
			},
		},
		List: seqRequestList,
	}

	// 无需解析返回包
	_, err := acc.PackAndGetDecryptedResponse(seqReqData, seqHeadStruct)
	if err != nil {
		return err
	}

	return nil
}
