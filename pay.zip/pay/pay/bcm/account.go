package bcm

import (
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strings"
	"sync/atomic"
	"time"
)

// Account 交通银行帐号
type Account struct {
	Account     string `json:"account"`
	Password    string `json:"password"`
	PayPassword string `json:"payPassword"`
	Platform    string `json:"platform"`

	// 设备信息, 除最后三个外都需要随机化
	CFNetworkVersion string // CFNetwork版本
	DarwinVersion    string // Darwin内核版本
	DeviceModel      string // 注册设备第一个包需要用到的 设备型号 "iPhone9,2"
	OSVersion        string // 注册设备第一个包需要用到的 系统版本 "10.3.3"
	HardwareUUID1    string // 注册设备第一个包需要用到的
	HardwareUUID2    string // 注册设备第一个包需要用到的
	GUID             string //
	VIDTicket        string //
	DeviceID         string // 设备ID

	CardNo string `json:"cardNo"`

	SequenceNumber     int32 // 当前Shark包序号，默认从1开始
	ListSequenceNumber int32 // 当前Shark包中List序号，默认从1开始

	EncodeKey     []byte
	ClientVersion string // IP-UMP-4.0.0-000000
	SecAuthKey    string // "BnwdUh+FfjqfX1GnLe8NVzM3MjYwNjkxOTI0NzE3NjAy"
	MSessionID    string //
	hashs         string //
	alias         string // 手机号 @todo 初次赋值

	FileListDb map[string]modelFileInfoItem // 用来存储所有最新版本的文件的版本号信息，从第一个包的返回数据里获取

	// @todo @remove 对包序号加锁
	generatePackageSequence int32
	generateListSequence    int32

	debitCardList []modelDebitCardListItem // 所有卡的列表

	//SystemVersion string          `json:"systemVersion"`
	//ScreenSize    string          `json:"screenSize"`
	UserID string          `json:"userId"`
	Proxy  utils.ProxyInfo `json:"proxy"`
	http   *http.Client
	jar    *cookiejar.Jar

	// 支付密码键盘映射
	keyMapsInfo *modelPayPasswordKeyMaps

	useCardNo            string
	lastPing             int64
	loginStatus          int32
	loginPadding         int32
	loginFailCount       int
	smscodeFailCount     int
	payPasswordFailCount int
	transferPadding      int32

	transferConfirmType string // 转账类型

	contractNo    string // ""
	customerNo    string // ""
	ecifNo        string // ""
	flag          int    // 1
	isClearUnread int    // 0
	isWap         int    // 0

	// 转账银行
	bankNo   string
	bankName string

	// 转帐目标
	transferTargetAccount string
	transferTargetName    string
	transferAmount        string
	transferComment       string
	transferOrderNo       string

	// 转帐参数
	/*
		confirmReTranRisk bool
	*/
	toBankType         string
	toOpenBank         string
	toOpenBankNo       string
	toOpenArea         string
	toOpenAreaNo       string
	toOpenCity         string
	toOpenCityNo       string
	toOpenNetSpot      string
	toOpenNetSpotNo    string
	toParty            string
	toPartyID          string
	isSupportSuperBank string

	imageCode    string
	hfeRateCode  string
	feePayMode   string
	realFee      string
	feeTcaNo     string
	transferType string
	speChkResult string
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case common.PlatformNameIOS, common.PlatformNameAndroid:
	default:
		{
			logger.Errorf("[BCM]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(bcmAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(bcmAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			return acc, nil
		}

		logger.Errorf("[BCM]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	if len(strings.TrimSpace(account)) != 11 {
		return nil, errors.New("用于登录手机银行的手机号格式有误")
	}

	/*
		fmt.Println("=== account")
		fmt.Println(account)
	*/

	acc.alias = strings.TrimSpace(account)

	acc.SequenceNumber = 0     // 初始化Shark包序号
	acc.ListSequenceNumber = 0 // 初始化Shark包中List的序号
	acc.FileListDb = make(map[string]modelFileInfoItem)

	acc.ClientVersion = constClientVersion
	acc.hashs = constHashs // @update

	// 生成一组硬件设备信息
	acc.GenerateNewHardware()

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[BCM]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	// case pay.LoginStatusWaitCode:
	// logger.Infof("[BCM][%+v]等待验证码登录.", acc.Account)
	// return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)

	case pay.LoginStatusSuccess:
		logger.Infof("[BCM][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[BCM][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[BCM][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}
		acc.jar, _ = cookiejar.New(nil)
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.jar, _ = cookiejar.New(nil)
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	if len(acc.getPassword()) == 0 {
		logger.Errorf("[BCM][%+v]登录密码不能为空.")
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeBCM)
		return pay.Error(pay.ErrCodeInvalidIDPWD, "登录密码不能为空.", nil)
	}

	// @important 每次启动重置这项
	acc.SecAuthKey = ""
	acc.MSessionID = ""
	acc.EncodeKey = generateRandomEncodeKey()

	// 数据完整性校验
	if acc.alias == "" {
		acc.alias = acc.Account
	}

	if acc.DeviceID == "" {
		/////////////////////////////////////////////////////////////////////////////////
		// 测试设备生成 @remove
		/////////////////////////////////////////////////////////////////////////////////

		authKey0, tmpGUID, err := acc.pkgRegisterDeviceGetGUID()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}
		acc.SecAuthKey = authKey0

		tmpVIDTicket, err := acc.pkgRegisterDeviceGetVIDTicket(tmpGUID)
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		tmpDeviceID, err := acc.pkgSendDeviceInfoAndGetDeviceID(tmpGUID, tmpVIDTicket)
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		// 设置硬件信息
		acc.GUID = tmpGUID
		acc.VIDTicket = tmpVIDTicket
		acc.DeviceID = tmpDeviceID

		if err := acc.save(); err != nil {
			return pay.Error(pay.ErrCodeLoginError, "存储生成的GUID/DeviceID等硬件信息失败", nil)
		}

		// 初始化App,无需获取authKey
		/*
			dropped, err := acc.httpInitApp(false)
			if err != nil {
				return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
			}

			if len(dropped) > 0 {
			}
		*/

		authKey, err := acc.httpInitApp()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}
		acc.SecAuthKey = authKey

	} else {

	}

	// 初始化App获取authKey及最新文件版本号
	authKey, err := acc.httpInitApp()
	if err != nil {
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}
	acc.SecAuthKey = authKey

	// 模拟切换到登录页
	if err := acc.pkgSwitchToLoginPage(); err != nil {
		logger.Errorf("[BCM][%+v]切换到登录页失败: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, "切换到登录页失败", nil)
	}

	// 模拟触发登录页密码输入键盘
	loginRSAPublicKey, err := acc.pkgTriggerForInputPassword()
	if err != nil {
		logger.Errorf("[BCM][%+v]触发登录页密码键盘失败: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, "触发登录页密码键盘失败", nil)
	}

	passwordOK, errMsg, err := acc.pkgDoLogin(loginRSAPublicKey)
	if err != nil {
		logger.Errorf("[BCM][%+v]登录操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if passwordOK == false {

		// 密码验证失败
		logger.Errorf("[BCM][%+v]登录失败, 信息: %+v.", acc.Account, errMsg)

		// 这里需要根据如下内容做一个账号冻结策略 具体的文字判断内容需要再次抓包
		if strings.Contains(errMsg, "密码错误") || strings.Contains(errMsg, "密码输入有误") || strings.Contains(errMsg, "密码连续错误") || strings.Contains(errMsg, "密码错误次数已达最大值") {
			acc.loginFailCount++
			if acc.loginFailCount >= 2 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[BCM][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		if strings.Contains(errMsg, "用户名或密码输入有误") {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeBCM)
		}

		return pay.Error(pay.ErrCodeLoginError, errMsg, nil)
	}

	acc.loginFailCount = 0

	// 密码验证通过, 接下来验证是否是在新设备上登录的
	isChangedDevice, err := acc.pkgCheckIsChangedDevice()
	if err != nil {
		logger.Errorf("[BCM][%+v]验证是否是在新设备上登录操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, "无法验证是否是在新设备上登录", nil)
	}

	// 是在新设备上登录的，则需要获取验证码
	if isChangedDevice == true {
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypeBCM)

		logger.Infof("[BCM][%+v]需要验证码进行登录.", acc.Account)

		sendSmsStatus, errMsg, err := acc.pkgSendLoginSmsCode()
		if err != nil {
			logger.Errorf("[BCM][%+v]发送登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, "发送登录验证码错误", nil)
		}

		if sendSmsStatus != true {
			return pay.Error(pay.ErrCodeLoginError, errMsg, nil)
		}

		logger.Infof("[BCM][%+v]发送登录验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	// @todo 这里其实就登录成功了，还需要发一些登录成功后的包

	// 登录成功后设置一张默认卡
	debitCardList, err := acc.httpGetDebitCardList()
	if err != nil {
		logger.Errorf("[BCM][%+v]登录获取卡信息错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if err := acc.selectCard(debitCardList); err != nil {
		logger.Errorf("[BCM][%+v]无法选择指定的银行卡: %+v", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	acc.onLoginSuccess()

	logger.Infof("[BCM][%+v]用户登录成功.", acc.Account)
	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeBCM)
	api.ReportAccStateLogout(acc.Account, acc.Platform, common.AccountTypeBCM)

	logger.Infof("[BCM][%+v]退出成功.", acc.Account)

	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[BCM][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[BCM][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {

		sendSmsStatus, errMsg, err := acc.pkgSendLoginSmsCode()

		if err != nil {
			logger.Errorf("[BCM][%+v]发送登录验证码错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout {
				acc.loginStatus = pay.LoginStatusNone
				api.ReportAccStateNone(acc.Account, acc.Platform, common.AccountTypeBCM)
				return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
			}

			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if sendSmsStatus != true {
			return pay.Error(pay.ErrCodeLoginError, errMsg, nil)
		}

		logger.Infof("[BCM][%+v]发送登录验证码成功.", acc.Account)

	} else if acc.loginStatus == pay.LoginStatusSuccess {

	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {

		verifySmsStatus, errMsg, err := acc.pkgVerifyLoginSmsCode(code)
		if err != nil {
			logger.Errorf("[BCM][%+v]校验登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, "校验验证码操作错误", nil)
		}

		if verifySmsStatus != true {

			if strings.Contains(errMsg, "短信动态密码有误") {
				acc.smscodeFailCount++
				if acc.smscodeFailCount >= 3 {
					acc.smscodeFailCount = 0
					acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
					logger.Errorf("[BCM][%+v]登录连续验证码错误, 临时冻结帐号.", acc.Account)
				}
			}

			return pay.Error(pay.ErrCodeSMSCodeError, errMsg, nil)
		}

		acc.smscodeFailCount = 0

		// @todo 这里其实就登录成功了，还需要发一些登录成功后的包

		// 登录成功后设置一张默认卡
		debitCardList, err := acc.httpGetDebitCardList()
		if err != nil {
			logger.Errorf("[BCM][%+v]登录获取卡信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if err := acc.selectCard(debitCardList); err != nil {
			logger.Errorf("[BCM][%+v]选择银行卡错误: %+v", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()

		logger.Infof("[BCM][%+v]校验登录验证码成功.", acc.Account)

	} else if acc.loginStatus == pay.LoginStatusSuccess {

	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[BCM][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[BCM][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[BCM][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBillList(req, true)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[BCM][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[BCM][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	return acc.doTransfer(req, true)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[BCM][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[BCM][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
