package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//UnknowMap strcut implement
type UnknowMap struct {
	Header   map[string]string `json:"Header"`
	Unknow1  map[string]string `json:"Unknow1"`
	Unknow2  map[string]string `json:"Unknow2"`
	TranCode string            `json:"TranCode"`
}

func (st *UnknowMap) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *UnknowMap) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err, have = _is.SkipTo(codec.MAP, 0, false)
	if err != nil {
		return err
	}
	if have {
		err = _is.Read_int32(&length, 0, true)
		if err != nil {
			return err
		}
		st.Header = make(map[string]string)
		for i0, e0 := int32(0), length; i0 < e0; i0++ {
			var k0 string
			var v0 string

			err = _is.Read_string(&k0, 0, false)
			if err != nil {
				return err
			}

			err = _is.Read_string(&v0, 1, false)
			if err != nil {
				return err
			}

			st.Header[k0] = v0
		}
	}

	err, have = _is.SkipTo(codec.MAP, 1, false)
	if err != nil {
		return err
	}
	if have {
		err = _is.Read_int32(&length, 0, true)
		if err != nil {
			return err
		}
		st.Unknow1 = make(map[string]string)
		for i1, e1 := int32(0), length; i1 < e1; i1++ {
			var k1 string
			var v1 string

			err = _is.Read_string(&k1, 0, false)
			if err != nil {
				return err
			}

			err = _is.Read_string(&v1, 1, false)
			if err != nil {
				return err
			}

			st.Unknow1[k1] = v1
		}
	}

	err, have = _is.SkipTo(codec.MAP, 2, false)
	if err != nil {
		return err
	}
	if have {
		err = _is.Read_int32(&length, 0, true)
		if err != nil {
			return err
		}
		st.Unknow2 = make(map[string]string)
		for i2, e2 := int32(0), length; i2 < e2; i2++ {
			var k2 string
			var v2 string

			err = _is.Read_string(&k2, 0, false)
			if err != nil {
				return err
			}

			err = _is.Read_string(&v2, 1, false)
			if err != nil {
				return err
			}

			st.Unknow2[k2] = v2
		}
	}

	err = _is.Read_string(&st.TranCode, 3, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *UnknowMap) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require UnknowMap, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *UnknowMap) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.WriteHead(codec.MAP, 0)
	if err != nil {
		return err
	}
	err = _os.Write_int32(int32(len(st.Header)), 0)
	if err != nil {
		return err
	}
	for k3, v3 := range st.Header {

		err = _os.Write_string(k3, 0)
		if err != nil {
			return err
		}

		err = _os.Write_string(v3, 1)
		if err != nil {
			return err
		}
	}

	err = _os.WriteHead(codec.MAP, 1)
	if err != nil {
		return err
	}
	err = _os.Write_int32(int32(len(st.Unknow1)), 0)
	if err != nil {
		return err
	}
	for k4, v4 := range st.Unknow1 {

		err = _os.Write_string(k4, 0)
		if err != nil {
			return err
		}

		err = _os.Write_string(v4, 1)
		if err != nil {
			return err
		}
	}

	err = _os.WriteHead(codec.MAP, 2)
	if err != nil {
		return err
	}
	err = _os.Write_int32(int32(len(st.Unknow2)), 0)
	if err != nil {
		return err
	}
	for k5, v5 := range st.Unknow2 {

		err = _os.Write_string(k5, 0)
		if err != nil {
			return err
		}

		err = _os.Write_string(v5, 1)
		if err != nil {
			return err
		}
	}

	err = _os.Write_string(st.TranCode, 3)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *UnknowMap) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
