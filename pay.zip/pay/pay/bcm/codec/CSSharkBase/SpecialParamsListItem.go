package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//SpecialParamsListItem strcut implement
type SpecialParamsListItem struct {
	Unknow0   int32  `json:"Unknow0"`
	Unknow1   int16  `json:"Unknow1"`
	Unknow2   int32  `json:"Unknow2"`
	Unknow3   int32  `json:"Unknow3"`
	EcifNo    string `json:"EcifNo"`
	Unknow4   int32  `json:"Unknow4"`
	Unknow5   int32  `json:"Unknow5"`
	Timestamp int32  `json:"Timestamp"`
}

func (st *SpecialParamsListItem) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *SpecialParamsListItem) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = _is.Read_int32(&st.Unknow0, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_int16(&st.Unknow1, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow2, 2, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow3, 3, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.EcifNo, 4, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow4, 6, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow5, 7, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Timestamp, 8, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *SpecialParamsListItem) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require SpecialParamsListItem, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *SpecialParamsListItem) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.Write_int32(st.Unknow0, 0)
	if err != nil {
		return err
	}

	err = _os.Write_int16(st.Unknow1, 1)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow2, 2)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow3, 3)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.EcifNo, 4)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow4, 6)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow5, 7)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Timestamp, 8)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *SpecialParamsListItem) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
