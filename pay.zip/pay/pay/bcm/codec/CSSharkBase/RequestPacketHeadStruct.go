package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//RequestPacketHeadStruct strcut implement
type RequestPacketHeadStruct struct {
	Unknow0       int32  `json:"Unknow0"`
	UnknowAuthKey string `json:"UnknowAuthKey"`
	Unknow2       int32  `json:"Unknow2"`
	Unknow3       string `json:"Unknow3"`
	Unknow4       int32  `json:"Unknow4"`
	SeqNo         int32  `json:"SeqNo"`
	Unknow6       int32  `json:"Unknow6"`
}

func (st *RequestPacketHeadStruct) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *RequestPacketHeadStruct) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = _is.Read_int32(&st.Unknow0, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.UnknowAuthKey, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow2, 2, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow3, 3, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow4, 4, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.SeqNo, 5, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow6, 6, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *RequestPacketHeadStruct) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require RequestPacketHeadStruct, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *RequestPacketHeadStruct) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.Write_int32(st.Unknow0, 0)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.UnknowAuthKey, 1)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow2, 2)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow3, 3)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow4, 4)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.SeqNo, 5)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow6, 6)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *RequestPacketHeadStruct) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
