package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//RegisterDevice strcut implement
type RegisterDevice struct {
	Unknow0     int32                      `json:"Unknow0"`
	Unknow1     int32                      `json:"Unknow1"`
	Unknow2     int16                      `json:"Unknow2"`
	Unknow3     int16                      `json:"Unknow3"`
	Unknow4     string                     `json:"Unknow4"`
	UnknowUUID1 string                     `json:"UnknowUUID1"`
	UnknowUUID2 string                     `json:"UnknowUUID2"`
	Unknow7     string                     `json:"Unknow7"`
	RDStruct    RegisterDeviceUnknowStruct `json:"RDStruct"`
	DeviceModel string                     `json:"DeviceModel"`
	OSVersion   string                     `json:"OSVersion"`
	Unknow11    int32                      `json:"Unknow11"`
	Unknow12    string                     `json:"Unknow12"`
	Unknow13    string                     `json:"Unknow13"`
	Unknow14    string                     `json:"Unknow14"`
}

func (st *RegisterDevice) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *RegisterDevice) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = _is.Read_int32(&st.Unknow0, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow1, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_int16(&st.Unknow2, 2, false)
	if err != nil {
		return err
	}

	err = _is.Read_int16(&st.Unknow3, 3, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow4, 4, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.UnknowUUID1, 5, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.UnknowUUID2, 6, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow7, 7, false)
	if err != nil {
		return err
	}

	err = st.RDStruct.ReadBlock(_is, 8, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.DeviceModel, 9, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.OSVersion, 10, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow11, 11, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow12, 12, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow13, 13, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow14, 14, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *RegisterDevice) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require RegisterDevice, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *RegisterDevice) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.Write_int32(st.Unknow0, 0)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow1, 1)
	if err != nil {
		return err
	}

	err = _os.Write_int16(st.Unknow2, 2)
	if err != nil {
		return err
	}

	err = _os.Write_int16(st.Unknow3, 3)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow4, 4)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.UnknowUUID1, 5)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.UnknowUUID2, 6)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow7, 7)
	if err != nil {
		return err
	}

	err = st.RDStruct.WriteBlock(_os, 8)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.DeviceModel, 9)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.OSVersion, 10)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow11, 11)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow12, 12)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow13, 13)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow14, 14)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *RegisterDevice) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
