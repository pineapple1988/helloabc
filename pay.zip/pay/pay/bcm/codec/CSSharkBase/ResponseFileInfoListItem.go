package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//ResponseFileInfoListItem strcut implement
type ResponseFileInfoListItem struct {
	Name           string `json:"Name"`
	ID             int16  `json:"ID"`
	CurrentVersion int16  `json:"CurrentVersion"`
	Unknow3        int32  `json:"Unknow3"`
	Unknow4        int32  `json:"Unknow4"`
	FileURL1       string `json:"FileURL1"`
	Hash1          string `json:"Hash1"`
	FileSize1      int32  `json:"FileSize1"`
	Unknow8        int32  `json:"Unknow8"`
	FileURL2       string `json:"FileURL2"`
	FileSize2      int32  `json:"FileSize2"`
	Hash2          string `json:"Hash2"`
	Unknow12       int32  `json:"Unknow12"`
	Unknow13       int32  `json:"Unknow13"`
	Unknow14       string `json:"Unknow14"`
	CompareURL     string `json:"CompareURL"`
	Unknow16       int32  `json:"Unknow16"`
	UnknowHash     string `json:"UnknowHash"`
}

func (st *ResponseFileInfoListItem) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *ResponseFileInfoListItem) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = _is.Read_string(&st.Name, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_int16(&st.ID, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_int16(&st.CurrentVersion, 2, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow3, 3, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow4, 4, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.FileURL1, 5, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Hash1, 6, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.FileSize1, 7, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow8, 8, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.FileURL2, 9, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.FileSize2, 10, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Hash2, 11, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow12, 12, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow13, 13, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow14, 14, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.CompareURL, 15, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow16, 16, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.UnknowHash, 17, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *ResponseFileInfoListItem) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require ResponseFileInfoListItem, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *ResponseFileInfoListItem) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.Write_string(st.Name, 0)
	if err != nil {
		return err
	}

	err = _os.Write_int16(st.ID, 1)
	if err != nil {
		return err
	}

	err = _os.Write_int16(st.CurrentVersion, 2)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow3, 3)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow4, 4)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.FileURL1, 5)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Hash1, 6)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.FileSize1, 7)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow8, 8)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.FileURL2, 9)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.FileSize2, 10)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Hash2, 11)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow12, 12)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow13, 13)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow14, 14)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.CompareURL, 15)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow16, 16)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.UnknowHash, 17)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *ResponseFileInfoListItem) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
