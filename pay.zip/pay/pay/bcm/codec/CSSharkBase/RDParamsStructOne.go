package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//RDParamsStructOne strcut implement
type RDParamsStructOne struct {
	Unknow0 RDParamsStructTwo `json:"Unknow0"`
	Unknow1 string            `json:"Unknow1"`
	Unknow2 string            `json:"Unknow2"`
}

func (st *RDParamsStructOne) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *RDParamsStructOne) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = st.Unknow0.ReadBlock(_is, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow1, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow2, 2, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *RDParamsStructOne) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require RDParamsStructOne, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *RDParamsStructOne) WriteTo(_os *codec.Buffer) error {
	var err error

	err = st.Unknow0.WriteBlock(_os, 0)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow1, 1)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow2, 2)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *RDParamsStructOne) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
