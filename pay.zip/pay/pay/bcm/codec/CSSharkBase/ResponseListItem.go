package CSSharkBase

import (
	"fmt"
	"pay/pay/bcm/codec"
)

//ResponseListItem strcut implement
type ResponseListItem struct {
	Unknow0      int16                    `json:"Unknow0"`
	Unknow1      int32                    `json:"Unknow1"`
	ListSequence int32                    `json:"ListSequence"`
	Unknow3      int32                    `json:"Unknow3"`
	Unknow4      int32                    `json:"Unknow4"`
	Unknow5      []uint8                  `json:"Unknow5"`
	Unknow6      ResponseListItemUnknown6 `json:"Unknow6"`
	Unknow7      []uint8                  `json:"Unknow7"`
	Unknow8      int32                    `json:"Unknow8"`
	Unknow9      string                   `json:"Unknow9"`
}

func (st *ResponseListItem) resetDefault() {
}

//ReadFrom reads  from _is and put into struct.
func (st *ResponseListItem) ReadFrom(_is *codec.Reader) error {
	var err error
	var length int32
	var have bool
	var ty byte
	st.resetDefault()

	err = _is.Read_int16(&st.Unknow0, 0, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow1, 1, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.ListSequence, 2, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow3, 3, false)
	if err != nil {
		return err
	}

	err = _is.Read_int32(&st.Unknow4, 4, false)
	if err != nil {
		return err
	}

	err, have, ty = _is.SkipToNoCheck(5, false)
	if err != nil {
		return err
	}
	if have {
		if ty == codec.LIST {
			err = _is.Read_int32(&length, 0, true)
			if err != nil {
				return err
			}
			st.Unknow5 = make([]uint8, length, length)
			for i0, e0 := int32(0), length; i0 < e0; i0++ {

				err = _is.Read_uint8(&st.Unknow5[i0], 0, false)
				if err != nil {
					return err
				}
			}
		} else if ty == codec.SIMPLE_LIST {

			err, _ = _is.SkipTo(codec.BYTE, 0, true)
			if err != nil {
				return err
			}
			err = _is.Read_int32(&length, 0, true)
			if err != nil {
				return err
			}
			err = _is.Read_slice_uint8(&st.Unknow5, length, true)
			if err != nil {
				return err
			}

		} else {
			err = fmt.Errorf("require vector, but not")
			if err != nil {
				return err
			}
		}
	}

	err = st.Unknow6.ReadBlock(_is, 6, false)
	if err != nil {
		return err
	}

	err, have, ty = _is.SkipToNoCheck(7, false)
	if err != nil {
		return err
	}
	if have {
		if ty == codec.LIST {
			err = _is.Read_int32(&length, 0, true)
			if err != nil {
				return err
			}
			st.Unknow7 = make([]uint8, length, length)
			for i1, e1 := int32(0), length; i1 < e1; i1++ {

				err = _is.Read_uint8(&st.Unknow7[i1], 0, false)
				if err != nil {
					return err
				}
			}
		} else if ty == codec.SIMPLE_LIST {

			err, _ = _is.SkipTo(codec.BYTE, 0, true)
			if err != nil {
				return err
			}
			err = _is.Read_int32(&length, 0, true)
			if err != nil {
				return err
			}
			err = _is.Read_slice_uint8(&st.Unknow7, length, true)
			if err != nil {
				return err
			}

		} else {
			err = fmt.Errorf("require vector, but not")
			if err != nil {
				return err
			}
		}
	}

	err = _is.Read_int32(&st.Unknow8, 8, false)
	if err != nil {
		return err
	}

	err = _is.Read_string(&st.Unknow9, 9, false)
	if err != nil {
		return err
	}

	_ = length
	_ = have
	_ = ty
	return nil
}

//ReadBlock reads struct from the given tag , require or optional.
func (st *ResponseListItem) ReadBlock(_is *codec.Reader, tag byte, require bool) error {
	var err error
	var have bool
	st.resetDefault()

	err, have = _is.SkipTo(codec.STRUCT_BEGIN, tag, require)
	if err != nil {
		return err
	}
	if !have {
		if require {
			return fmt.Errorf("require ResponseListItem, but not exist. tag %d", tag)
		}
		return nil

	}

	st.ReadFrom(_is)

	err = _is.SkipToStructEnd()
	if err != nil {
		return err
	}
	_ = have
	return nil
}

//WriteTo encode struct to buffer
func (st *ResponseListItem) WriteTo(_os *codec.Buffer) error {
	var err error

	err = _os.Write_int16(st.Unknow0, 0)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow1, 1)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.ListSequence, 2)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow3, 3)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow4, 4)
	if err != nil {
		return err
	}

	err = _os.WriteHead(codec.SIMPLE_LIST, 5)
	if err != nil {
		return err
	}
	err = _os.WriteHead(codec.BYTE, 0)
	if err != nil {
		return err
	}
	err = _os.Write_int32(int32(len(st.Unknow5)), 0)
	if err != nil {
		return err
	}
	err = _os.Write_slice_uint8(st.Unknow5)
	if err != nil {
		return err
	}

	err = st.Unknow6.WriteBlock(_os, 6)
	if err != nil {
		return err
	}

	err = _os.WriteHead(codec.SIMPLE_LIST, 7)
	if err != nil {
		return err
	}
	err = _os.WriteHead(codec.BYTE, 0)
	if err != nil {
		return err
	}
	err = _os.Write_int32(int32(len(st.Unknow7)), 0)
	if err != nil {
		return err
	}
	err = _os.Write_slice_uint8(st.Unknow7)
	if err != nil {
		return err
	}

	err = _os.Write_int32(st.Unknow8, 8)
	if err != nil {
		return err
	}

	err = _os.Write_string(st.Unknow9, 9)
	if err != nil {
		return err
	}

	return nil
}

//WriteBlock encode struct
func (st *ResponseListItem) WriteBlock(_os *codec.Buffer, tag byte) error {
	var err error
	err = _os.WriteHead(codec.STRUCT_BEGIN, tag)
	if err != nil {
		return err
	}

	st.WriteTo(_os)

	err = _os.WriteHead(codec.STRUCT_END, 0)
	if err != nil {
		return err
	}
	return nil
}
