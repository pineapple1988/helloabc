package bcm

import (
	"bytes"
	"compress/zlib"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"pay/pay"
	"pay/pay/bcm/codec/CSSharkBase"
	"pay/utils"
	"pay/utils/logger"
	"strings"

	"pay/pay/bcm/codec"

	jsoniter "github.com/json-iterator/go"
	"github.com/tjfoc/gmsm/sm4"
)

/////////////////////////////////////////////////////////////
// 解析返回数据取值的相关函数
/////////////////////////////////////////////////////////////

// getBodyItem 获取Body部分对应键的值
func getBodyItem(data []byte, path ...interface{}) jsoniter.Any {
	var args []interface{}
	args = append(args, "RSP_BODY")
	for i := 0; i < len(path); i++ {
		args = append(args, path[0])
	}

	return jsoniter.Get(data, args...)
}

// getHeadItem 获取Head部分对应键的值
func getHeadItem(data []byte, path ...interface{}) jsoniter.Any {
	var args []interface{}
	args = append(args, "RSP_HEAD")
	for i := 0; i < len(path); i++ {
		args = append(args, path[0])
	}

	return jsoniter.Get(data, args...)
}

// getTranStatus 获取包返回的TRAN_SUCCESS状态
func getTranStatus(data []byte) string {
	if jsoniter.Get(data, "RSP_HEAD", "TRAN_SUCCESS").ToString() == "1" {
		return constTranStatusSuccess
	} else if jsoniter.Get(data, "RSP_HEAD", "TRAN_SUCCESS").ToString() == "0" {
		return constTranStatusFailed
	}
	return constTranStatusEmpty
}

func getBodyItemToBytes(data []byte, path ...interface{}) []byte {
	jsonText := getBodyItem(data, path...).ToString()
	return []byte(jsonText)
}

// 存在错误则包裹成特定结构保存
func getErrorMsg(data []byte) string {

	if getHeadItem(data, "TRAN_SUCCESS").ToString() == "0" {
		type rspStruct struct {
			Identifier string `json:"identifier"` // 用于标记
			Code       string `json:"code"`
			Message    string `json:"message"`
			Data       string `json:"base64data"`
		}
		errCode := strings.TrimSpace(getHeadItem(data, "ERROR_CODE").ToString())
		errMessage := strings.TrimSpace(getHeadItem(data, "ERROR_MESSAGE").ToString())
		errPayload := base64.StdEncoding.EncodeToString(data)

		rspText := rspStruct{
			Identifier: "BCMErrorCollection",
			Code:       errCode,
			Message:    errMessage,
			Data:       errPayload,
		}

		json, err := json.Marshal(rspText)
		if err != nil {
			logger.Errorf("[ErrorHandler]序列化ResponseError错误: %+v.", err)
			return fmt.Sprintf("序列化ResponseError错误: %+v, 序列化内容: %s", err, errPayload)
		}
		return string(json)
	}
	return ""

}

/////////////////////////////////////////////////////////////
// Sequence Number Functions
/////////////////////////////////////////////////////////////

// getSequenceNumber 生成Shark包的序号，每次调用自动加1
func (acc *Account) getSequenceNumber() int32 {
	/*
		atomic.StoreInt32(&acc.generatePackageSequence, 1)
		defer func() {
			atomic.StoreInt32(&acc.generatePackageSequence, 0)
		}()
	*/

	acc.SequenceNumber = acc.SequenceNumber + 1
	return acc.SequenceNumber
}

// getListSequenceNumber 生成Shark包中List Item的序号，每次调用自动加1
func (acc *Account) getListSequenceNumber() int32 {
	/*
		atomic.StoreInt32(&acc.generateListSequence, 1)
		defer func() {
			atomic.StoreInt32(&acc.generateListSequence, 0)
		}()
	*/
	acc.ListSequenceNumber = acc.ListSequenceNumber + 1
	return acc.ListSequenceNumber
}

/////////////////////////////////////////////////////////////
// Convert To Bytes Functions
/////////////////////////////////////////////////////////////

// getSeqMapHeader 生成二进制的MapHeader(用于SIMPLE_LIST)
func getSeqMapHeader(tranCode string) []byte {
	var mapHeader = map[string]string{"Content-Type": "application/x-www-form-urlencoded; charset=utf-8; application/json"}
	var mapStruct = CSSharkBase.UnknowMap{
		Header:   mapHeader,
		TranCode: tranCode,
	}

	outputStream := codec.NewBuffer()
	mapStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

// 对结构化非字符串类型的Params进行序列化转换
func getSeqParamsBytes(paramsStruct CSSharkBase.CheckForFileListUpdates) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

// 对结构化非字符串类型的Special Params进行序列化转换
func getSpecialParamsBytes(paramsStruct CSSharkBase.SpecialParamsStruct) []byte {
	outputStream := codec.NewBuffer()
	paramsStruct.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

// 对结构化非字符串类型的Special Params Item进行序列化转换
func getSpecialParamsItemBytes(specialParamsListItem CSSharkBase.SpecialParamsListItem) []byte {
	outputStream := codec.NewBuffer()
	specialParamsListItem.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

/////////////////////////////////////////////////////////////
// Serialize Functions
/////////////////////////////////////////////////////////////

// CheckSessionStatus 检测登录状态
func (acc *Account) CheckSessionStatus(listData []CSSharkBase.ResponseListItem) (string, error) {

	if len(listData) < 1 {

	} else if len(listData) == 1 {

		if jsoniter.Get(listData[0].Unknow5, "RSP_HEAD", "TRAN_SUCCESS").ToString() == "0" {

			logger.Debugf("[BCM]CheckSessionStatus捕获错误状态, 内容: %s.", string(listData[0].Unknow5))

			errMessage := jsoniter.Get(listData[0].Unknow5, "RSP_HEAD", "ERROR_MESSAGE").ToString()
			errCode := jsoniter.Get(listData[0].Unknow5, "RSP_HEAD", "ERROR_CODE").ToString()
			outputMessage := fmt.Sprintf("Message: %s, ErrorCode: %s", errMessage, errCode)

			body := strings.TrimSpace(errMessage)

			if strings.Contains(body, "您的会话信息不存在或超时") || strings.Contains(body, "请先进行登录") || strings.Contains(body, "未登录或已超时") {
				logger.Warnf("[BCM][%+v]登录状态失效, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
				return outputMessage, pay.ErrSessionTimeout
			}

			if strings.Contains(body, "您已通过其它设备登录手机银行") {
				logger.Warnf("[BCM][%+v]已通过其它设备登录手机银行, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
				return outputMessage, pay.ErrNeedBindDevice
			}

			return outputMessage, nil
		}

	} else {
		for _, item := range listData {
			if jsoniter.Get(item.Unknow5, "RSP_HEAD", "TRAN_SUCCESS").ToString() == "0" {

				logger.Debugf("[BCM]CheckSessionStatus捕获错误状态, 内容: %s.", string(item.Unknow5))

				errMessage := jsoniter.Get(item.Unknow5, "RSP_HEAD", "ERROR_MESSAGE").ToString()
				errCode := jsoniter.Get(item.Unknow5, "RSP_HEAD", "ERROR_CODE").ToString()
				outputMessage := fmt.Sprintf("Message: %s, ErrorCode: %s", errMessage, errCode)

				body := strings.TrimSpace(errMessage)

				if strings.Contains(body, "您的会话信息不存在或超时") || strings.Contains(body, "请先进行登录") || strings.Contains(body, "未登录或已超时") {
					logger.Warnf("[BCM][%+v]登录状态失效, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
					return outputMessage, pay.ErrSessionTimeout
				}

				if strings.Contains(body, "您已通过其它设备登录手机银行") {
					logger.Warnf("[BCM][%+v]已通过其它设备登录手机银行, 代码: %+v, 信息: %+v.", acc.Account, errCode, errMessage)
					return outputMessage, pay.ErrNeedBindDevice
				}

			}

		}

	}

	return "", nil
}

// PackAndGetDecryptedResponse 序列化数据发包并获取解密后的返回信息
func (acc *Account) PackAndGetDecryptedResponse(requestShark CSSharkBase.RequestShark, headStruct CSSharkBase.RequestPacketHeadStruct) (*CSSharkBase.ResponseDecryptedPacket, error) {

	packedBytes, err := Pack(acc.EncodeKey, requestShark, headStruct, false)
	if err != nil {
		return nil, fmt.Errorf("[BCM]PackAndGetDecryptedResponse: Pack执行错误:%+v", err)
	}
	respStreamBytes, err := acc.httpPostSharkCommand(packedBytes)
	if err != nil {
		return nil, err
	}

	/*
		fmt.Println("=== PackAndGetDecryptedResponse Dump")
		fmt.Println(hex.Dump(respStreamBytes))
	*/

	decryptedBytes, err := ParseResponsePacketByTars(acc.EncodeKey, respStreamBytes)
	if err != nil {
		return nil, fmt.Errorf("[BCM]PackAndGetDecryptedResponse: 解包错误:%+v", err)
	}
	//return decryptedBytes, nil

	decryptedData := &CSSharkBase.ResponseDecryptedPacket{}
	if err := decryptedData.ReadFrom(codec.NewReader(decryptedBytes)); err != nil {
		fmt.Printf("readFrom err: %+v.", err)
		return nil, fmt.Errorf("[BCM]PackAndGetDecryptedResponse: 反序列化错误:%+v", err)
	}
	return decryptedData, nil

}

// RegisterDeviceAndGetResponse 序列化包并从返回结果中获取authKey, 一般是App首次启动时的第一个Shark包
func (acc *Account) RegisterDeviceAndGetResponse(requestShark CSSharkBase.RequestShark, headStruct CSSharkBase.RequestPacketHeadStruct) (string, *CSSharkBase.ResponseDecryptedPacket, error) {

	var authKey string = ""

	packedBytes, err := Pack(acc.EncodeKey, requestShark, headStruct, true)
	if err != nil {
		return authKey, nil, fmt.Errorf("[BCM]RegisterDeviceAndGetResponse: httpPostSharkCommand执行错误:%+v", err)
	}
	respStreamBytes, err := acc.httpPostSharkCommand(packedBytes)
	if err != nil {
		return authKey, nil, err
	}

	respData := CSSharkBase.ResponsePacket{}
	if err := respData.ReadFrom(codec.NewReader(respStreamBytes)); err != nil {
		return authKey, nil, fmt.Errorf("[BCM]RegisterDeviceAndGetResponse:反序列化ResponsePacket结构错误:%+v", err)
	}

	keyData := CSSharkBase.ResponsePacketUnknow1{}
	if err := keyData.ReadFrom(codec.NewReader(respData.Unknow1)); err != nil {
		return authKey, nil, fmt.Errorf("[BCM]RegisterDeviceAndGetResponse: 反序列化ResponsePacketUnknow1结构错误:%+v", err)
	}

	// 如果key不为空
	if keyData.Unknow0 != "" {
		authKey = keyData.Unknow0
	}

	decryptedBytes, err := ParseResponsePacketByTarsWithoutDecompress(acc.EncodeKey, respStreamBytes)
	if err != nil {
		return authKey, nil, fmt.Errorf("[BCM]RegisterDeviceAndGetResponse: 解包错误:%+v", err)
	}
	//return decryptedBytes, nil

	decryptedData := &CSSharkBase.ResponseDecryptedPacket{}
	if err := decryptedData.ReadFrom(codec.NewReader(decryptedBytes)); err != nil {
		fmt.Printf("readFrom err: %+v.", err)
		return authKey, nil, fmt.Errorf("[BCM]RegisterDeviceAndGetResponse: 反序列化错误:%+v", err)
	}
	return authKey, decryptedData, nil

}

// RegisterDeviceAndGetDeviceID ""
func (acc *Account) RegisterDeviceAndGetDeviceID(requestShark CSSharkBase.RequestShark, headStruct CSSharkBase.RequestPacketHeadStruct) (*CSSharkBase.ResponseDecryptedPacket, error) {

	packedBytes, err := Pack(acc.EncodeKey, requestShark, headStruct, false)
	if err != nil {
		return nil, errors.New("[BCM]RegisterDeviceAndGetDeviceID: Pack error")
	}
	respStreamBytes, err := acc.httpPostSharkCommand(packedBytes)
	if err != nil {
		return nil, err
	}

	respData := CSSharkBase.ResponsePacket{}
	if err := respData.ReadFrom(codec.NewReader(respStreamBytes)); err != nil {
		return nil, errors.New("[BCM]RegisterDeviceAndGetDeviceID: CSSharkBase.ResponsePacket反序列化错误")
	}

	keyData := CSSharkBase.ResponsePacketUnknow1{}
	if err := keyData.ReadFrom(codec.NewReader(respData.Unknow1)); err != nil {
		return nil, errors.New("[BCM]RegisterDeviceAndGetDeviceID: CSSharkBase.ResponsePacketUnknow1反序列化错误")
	}

	decryptedBytes, err := ParseResponsePacketByTarsWithoutDecompress(acc.EncodeKey, respStreamBytes)
	if err != nil {
		return nil, fmt.Errorf("[BCM]RegisterDeviceAndGetDeviceID: decrypt error: %+v", err)
	}

	decryptedData := &CSSharkBase.ResponseDecryptedPacket{}
	if err := decryptedData.ReadFrom(codec.NewReader(decryptedBytes)); err != nil {
		//fmt.Printf("readFrom err: %+v.", err)
		return nil, fmt.Errorf("[BCM]RegisterDeviceAndGetDeviceID: unserialize error: %+v", err)
	}
	return decryptedData, nil

}

// PackAndGetDecryptedResponseWithAuthKey 序列化包并从返回结果中获取authKey, 一般是App首次启动时的第一个Shark包
func (acc *Account) PackAndGetDecryptedResponseWithAuthKey(requestShark CSSharkBase.RequestShark, headStruct CSSharkBase.RequestPacketHeadStruct) (string, *CSSharkBase.ResponseDecryptedPacket, error) {

	var authKey string = ""

	packedBytes, err := Pack(acc.EncodeKey, requestShark, headStruct, true)
	if err != nil {
		return authKey, nil, errors.New("[BCM]PackAndGetDecryptedResponseWithAuthKey: Pack error")
	}
	respStreamBytes, err := acc.httpPostSharkCommand(packedBytes)
	if err != nil {
		return authKey, nil, err
	}

	respData := CSSharkBase.ResponsePacket{}
	if err := respData.ReadFrom(codec.NewReader(respStreamBytes)); err != nil {
		return authKey, nil, errors.New("[BCM]PackAndGetDecryptedResponseWithAuthKey: CSSharkBase.ResponsePacket反序列化错误")
	}

	keyData := CSSharkBase.ResponsePacketUnknow1{}
	if err := keyData.ReadFrom(codec.NewReader(respData.Unknow1)); err != nil {
		return authKey, nil, errors.New("[BCM]PackAndGetDecryptedResponseWithAuthKey: CSSharkBase.ResponsePacketUnknow1反序列化错误")
	}

	// 如果key不为空
	if keyData.Unknow0 != "" {
		authKey = keyData.Unknow0
	}

	decryptedBytes, err := ParseResponsePacketByTars(acc.EncodeKey, respStreamBytes)
	if err != nil {
		return authKey, nil, errors.New("[BCM]PackAndGetResponse: ParseResponsePacketByTars error")
	}
	//return decryptedBytes, nil

	decryptedData := &CSSharkBase.ResponseDecryptedPacket{}
	if err := decryptedData.ReadFrom(codec.NewReader(decryptedBytes)); err != nil {
		fmt.Printf("readFrom err: %+v.", err)
		return authKey, nil, errors.New("[BCM]PackAndGetResponse: ParseResponsePacketByTars unserialize error")
	}
	return authKey, decryptedData, nil

}

// ParseResponsePacketByTarsWithoutDecompress 根据Tars协议来解析包, 无需解压(仅用于获取设备ID等)
func ParseResponsePacketByTarsWithoutDecompress(encodeKey []byte, streamBytes []byte) ([]byte, error) {

	respData := CSSharkBase.ResponsePacket{}
	if err := respData.ReadFrom(codec.NewReader(streamBytes)); err != nil {
		fmt.Printf("readFrom err: %+v.", err)
		return nil, errors.New("ParseResponsePacketByTars: unserialize error")
	}

	c, _ := sm4.NewCipher(encodeKey)

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(respData.EncryptedData); i += c.BlockSize() {
		src := respData.EncryptedData[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	// 测试
	// fmt.Println(out)

	decryptedData, err := utils.PKCS7Trimming(out)
	if err != nil {
		return nil, errors.New("ParseResponsePacketByTarsWithoutDecompress: SM4去除填充错误")
	}

	return decryptedData, nil
}

// ParseResponsePacketByTars 根据Tars协议来解析包
func ParseResponsePacketByTars(encodeKey []byte, streamBytes []byte) ([]byte, error) {

	respData := CSSharkBase.ResponsePacket{}
	if err := respData.ReadFrom(codec.NewReader(streamBytes)); err != nil {
		fmt.Printf("readFrom err: %+v.", err)
		return nil, errors.New("ParseResponsePacketByTars: unserialize error")
	}

	c, _ := sm4.NewCipher(encodeKey)

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(respData.EncryptedData); i += c.BlockSize() {
		src := respData.EncryptedData[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	unpaddingBytes, err := utils.PKCS7Trimming(out)
	if err != nil {
		return nil, errors.New("ParseResponsePacketByTars: SM4去除填充错误")
	}

	decryptedBytes, err := utils.ZLibUncompress(unpaddingBytes)
	// @debug ioutil.WriteFile("/tmp/zzz.txt", decryptedBytes, 0666)

	if err != nil {
		return nil, errors.New("ParseResponsePacketByTars: uncompress error")
	}

	return decryptedBytes, nil
}

// ZLibCompressWithLevel zlib压缩数据
func ZLibCompressWithLevel(in []byte, level int) ([]byte, error) {
	out := bytes.Buffer{}
	w, err := zlib.NewWriterLevel(&out, level)
	if err != nil {
		return nil, err
	}
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// Pack 打包Shark数据
// 加密流程
// Tars(1) -> zlib -> SM4 -> Tars(2)
// param requestShark: 第一次序列化的结构体
// param headStruct: 最后一遍序列化的结构体中的HeadStruct
func Pack(encodeKey []byte, requestShark CSSharkBase.RequestShark, headStruct CSSharkBase.RequestPacketHeadStruct, needSM2Key bool) ([]byte, error) {
	//encodeKey := generateRandomEncodeKey()
	//fmt.Println(encodeKey, string(encodeKey))

	// Tars(1)
	firstTars := codec.NewBuffer()
	requestShark.WriteTo(firstTars)
	firstTarsBytes := firstTars.ToBytes()

	ioutil.WriteFile("/tmp/step1.txt", firstTarsBytes, 0666) //写入文件

	// zlib
	//zlibCompressedBytes, err := utils.ZLibCompress(firstTarsBytes)
	zlibCompressedBytes, err := ZLibCompressWithLevel(firstTarsBytes, 4)
	if err != nil {
		fmt.Println(err)
	}

	// SM4
	SM4EncryptedBytes, err := SM4ECBEncrypt(zlibCompressedBytes, encodeKey)
	if err != nil {

	}

	/*
		for j := -2; j < 10; j++ {
			zlibCompressedBytes0, err := ZLibCompressWithLevel(firstTarsBytes, j)
			if err != nil {
				fmt.Println(err)
			}

			// SM4
			SM4EncryptedBytes0, _ := SM4ECBEncrypt(zlibCompressedBytes0, encodeKey)
			fmt.Printf("level:%d,zlib len:%d, sm4 len:%d\n", j, len(zlibCompressedBytes0), len(SM4EncryptedBytes0))
		}
	*/

	encryptedData := SM4EncryptedBytes
	//fmt.Println(hex.Dump(encryptedData))

	SM2PublicKeyData := generateSM2PublicKeyData(encodeKey, SM2PublicKey)

	structPublicKeyData := CSSharkBase.RequestPacketSM2PublicKeyData{
		Unknow0:            0,
		Data:               SM2PublicKeyData,
		SharkCMDProductKey: constSharkCMDProductKey, // "app-87wnhc41qu"
		Unknow1:            1,
	}

	var dstPackage CSSharkBase.RequestPacket

	if needSM2Key == true {
		dstPackage = CSSharkBase.RequestPacket{
			HeadStruct:    headStruct,
			PublicKeyData: ConvertPublicKeyDataToBytes(structPublicKeyData),
			EncryptedData: encryptedData,
		}
	} else {
		dstPackage = CSSharkBase.RequestPacket{
			HeadStruct:    headStruct,
			PublicKeyData: []byte{},
			EncryptedData: encryptedData,
		}
	}

	// Tars(2)
	lastTars := codec.NewBuffer()
	dstPackage.WriteTo(lastTars)
	outputBytes := lastTars.ToBytes()
	//fmt.Println(hex.Dump(outputBytes))
	return outputBytes, nil

}

// ConvertPublicKeyDataToBytes 将PublicKeyData转成Bytes
func ConvertPublicKeyDataToBytes(req CSSharkBase.RequestPacketSM2PublicKeyData) []byte {
	outputStream := codec.NewBuffer()
	req.WriteTo(outputStream)
	bs := outputStream.ToBytes()
	return bs
}

// PackRequestSharkPacket 用Tars序列化最后发出的包
func PackRequestSharkPacket(dstPackage CSSharkBase.RequestPacket) ([]byte, error) {
	outputStream := codec.NewBuffer()
	dstPackage.WriteTo(outputStream)
	outputBytes := outputStream.ToBytes()
	//fmt.Println(hex.Dump(outputBytes))
	return outputBytes, nil
}
