package bcm

import (
	"fmt"
	"strings"
	"time"
)

// 格式化拉单的日期，并对异常日期进行修正
func FormatTradeTime(dealTime string, webTime string) string {
	// 定义一个时间的范例格式
	const TimeLayout = "2006-01-02 15:04:05"

	// 格式化时间, 加上前导0 如将"2020-01-05 3:26:32"转换为"2020-01-05 03:26:32"
	dealTime = strings.ReplaceAll(dealTime, "/", "-")
	parsedTime, _ := time.Parse(TimeLayout, dealTime)
	formattedTime := fmt.Sprintf("%+v", parsedTime.Format(TimeLayout))

	/* webTime一组示例
	"webTime": "2020010714602",
	"webTime": "202001072847",
	"webTime": "202001072636",   // "2020-01-07 00:00:00"
	"webTime": "20200106231119",
	"webTime": "2020010532632",
	"webTime": "20200104232517",
	"webTime": "20200104224656",
	"webTime": "20200104215002",
	"webTime": "201912210",      // "2019-12-21 00:00:00"
	"webTime": "20191212123139",
	"webTime": "20191212123132",
	"webTime": "20191211150806",
	"webTime": "20191121153317",
	"webTime": "20191121153141",
	*/

	// 格式化后的正常长度是19
	if len(formattedTime) == 19 {

		// 这种情况下需要对比webTime进行格式化
		if formattedTime[11:19] == "00:00:00" {
			if len(webTime) == 9 {
				return formattedTime
			}

			// 对0点到1点之间的时间进行修正
			if len(webTime) == 12 {
				return webTime[0:4] + "-" + webTime[4:6] + "-" + webTime[6:8] + " 00:" + webTime[8:10] + ":" + webTime[10:12]
			}

			// 对1点到9点之间的时间进行修正
			if len(webTime) == 13 {
				return webTime[0:4] + "-" + webTime[4:6] + "-" + webTime[6:8] + " 0" + webTime[8:9] + ":" + webTime[9:11] + ":" + webTime[11:13]
			}

			// 对10点到23:59点之间的时间进行修正
			if len(webTime) == 14 {
				return webTime[0:4] + "-" + webTime[4:6] + "-" + webTime[6:8] + " " + webTime[8:10] + ":" + webTime[10:12] + ":" + webTime[12:14]
			}
		}

		return formattedTime
	}
	return dealTime
}
