package bcm

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strings"
	"sync/atomic"
	"time"
)

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeBCM)
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeBCM)
	acc.save()
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeBCM, code, reason)
}

func (acc *Account) onOtherDevice() {
	acc.loginStatus = pay.LoginStatusNone
	api.ReportAccStateKickout(acc.Account, acc.Platform, common.AccountTypeBCM)
	pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeBCM)
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

// 从缓存中读取账号信息
func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(bcmAccountKey, field)
	if err != nil {
		logger.Errorf("[BCM]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[BCM]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

// 将账号信息保存到缓存中
func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[BCM]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(bcmAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[BCM]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

// @done
func (acc *Account) selectCard(debitCardList []modelDebitCardListItem) error {

	if len(debitCardList) <= 0 {
		// 没有获取到数据
		logger.Warnf("[BCM][%+v]无法找到可用银行卡.", acc.Account)
		return pay.ErrNoHaveCardList
	}

	if acc.CardNo == "" {

		acc.useCardNo = debitCardList[0].Account
		logger.Infof("[BCM][%+v]未指定银行卡号, 默认选择第一张, 卡号: %s.", acc.Account, acc.useCardNo)
		return nil
	}
	for _, v := range debitCardList {
		if v.Account == acc.CardNo {
			acc.useCardNo = v.Account
			logger.Infof("[BCM][%+v]选定指定银行卡号, 卡号: %+v.", acc.Account, acc.useCardNo)
			return nil
		}
	}

	logger.Errorf("[BCM][%+v]没有找到指定的银行卡号: %s.", acc.Account, acc.CardNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.CardNo)

}

///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////

// dateTimeToUnix 时间字符串转成unix时间戳
func dateTimeToUnix(dt string) int {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("2006/01/02 15:04:05", dt, loc)
	if err != nil {
		return 0
	}

	return int(tmp.Unix())
}

//
func (acc *Account) checkOnline(ts int64) {
	/*
		if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 300 {
			// 检测代理服务器
			if config.IsUseProxy() {
				pi, _ := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
				if pi != nil {
					if acc.setProxy(pi.URI, pi.User, pi.Pass) {
						acc.http = pay.CreateHTTPClient(pi, acc.jar)
					}
				}
			}

			_, err := acc.queryBalance()
			if err != nil {
				if err == pay.ErrNeedBindDevice {
					acc.onOtherDevice()
					acc.lastPing = ts
					return
				}

				if err == pay.ErrSessionTimeout {
					acc.doRelogin()
				}
			}

			acc.lastPing = ts
		}
	*/
}

// 执行查询余额
func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	//balance, err := acc.queryBalance()

	debitCardList, err := acc.httpGetDebitCardList()

	if err != nil {
		logger.Errorf("[BCM][%+v]查询余额错误: %+v.", acc.Account, err)
		// 其它设备登录
		if err == pay.ErrNeedBindDevice {
			acc.onOtherDevice()
			return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
		}

		// 超时
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[BCM][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					acc.onOtherDevice()
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if len(debitCardList) <= 0 {
		// 没有获取到数据
		logger.Warnf("[BCM][%+v]无法找到可用银行卡.", acc.Account)
		return pay.Error(pay.ErrCodeGetBalanceError, "无法找到可用银行卡", nil)

	}

	for _, v := range debitCardList {
		if v.Account == acc.useCardNo {
			if v.AccUsableBalance == "0" && v.CurrentUnusable != "0" {
				acc.freeze(pay.FreezeCodeCardError, "卡内余额不可用状态")
				return pay.Error(pay.ErrCodeGetBalanceError, fmt.Sprintf("卡号可能被风控, 余额[%s]为不可用状态", v.CurrentUnusable), nil)
			}

			res := model.AccountBalanceRes{}
			res.Code = common.ErrCodeSuccess
			res.Msg = common.ErrMsgSuccess
			res.Data.Amount = v.AccUsableBalance
			res.Data.AmountAvailable = v.AccUsableBalance

			logger.Infof("[BCM][%+v]查询余额信息成功, 卡号: %s, 余额: %s.", acc.Account, acc.useCardNo, v.AccUsableBalance)
			return pay.Success(&res)
		}
	}

	logger.Errorf("[BCM][%+v]查询余额失败, 没有找到卡号[%s]的余额信息.", acc.Account, acc.useCardNo)
	return pay.Error(pay.ErrCodeGetBalanceError, "没有找到卡号[%s]的余额信息.", acc.useCardNo)
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[BCM][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 1
	list := []modelBillInfo{}

	for {
		billList, isLastPage, err := acc.pkgGetBillListByTime(startDate, endDate, page)

		if err != nil {
			logger.Errorf("[BCM][%+v]查询帐单错误: %+v.", acc.Account, err)

			// 其它设备登录
			if err == pay.ErrNeedBindDevice {
				acc.onOtherDevice()
				return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
			}

			// 超时
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[BCM][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						acc.onOtherDevice()
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
				}

				return acc.doBillList(req, false)
			}

			if len(list) > 0 {
				break
			}

			return pay.Error(pay.ErrCodeGetBillListError, pay.ErrMsgGetBillListError, nil)
		}

		for _, item := range billList {
			// 时间查询判断条件
			if req.TimeType == common.TimeTypeByTime {
				ts := dateTimeToUnix(item.DealTime)
				if ts == 0 || ts < req.StartTime || ts > req.EndTime {
					continue
				}
			}

			list = append(list, item)
		}

		// 结束了
		if isLastPage == true {
			break
		}

		if len(billList) < 10 {
			break
		}

		page++
		if page > 20 {
			break
		}
	}

	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess

	// 倒序输出
	for i := len(list) - 1; i >= 0; i-- {
		item := list[i]

		// 格式化时间, 加上前导0 如将"2020-01-05 3:26:32"转换为"2020-01-05 03:26:32"
		formattedTime := FormatTradeTime(item.DealTime, item.WebTime)

		info := model.AccountBillListInfo{
			TradeNo:        "",
			TradeTime:      formattedTime, // 格式化后的日期
			Amount:         item.Amount,
			AmountRemain:   item.Balance,
			TargetAccount:  item.OppAc,
			TargetName:     item.OppAcNme,
			TargetBankName: item.OppBnkNme,
			Comment:        item.Remark,
		}

		if item.DcFlag == "D" {
			info.TradeType = "0"
		} else if item.DcFlag == "C" {
			info.TradeType = "1"
		} else {
			logger.Errorf("[BCM][%+v]查询帐单出现未知的记帐方式, DCFlag: %+v.", acc.Account, item.DcFlag)
			continue
		}

		if req.QueryType == common.QueryTypeAll {
			res.Data = append(res.Data, info)
		} else if req.QueryType == common.QueryTypeIncome {
			if info.TradeType == "1" {
				res.Data = append(res.Data, info)
			}
		} else if req.QueryType == common.QueryTypePayout {
			if info.TradeType == "0" {
				res.Data = append(res.Data, info)
			}
		}
	}

	return pay.Success(&res)
}

//
func (acc *Account) doRelogin() error {
	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[BCM][%+v]重登录分配代理服务器错误: %+v.", acc.Account, err)
			return errors.New("分配代理服务器错误")
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}
		acc.jar, _ = cookiejar.New(nil)
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.jar, _ = cookiejar.New(nil)
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	// @important 每次启动重置这项
	acc.SecAuthKey = ""
	acc.MSessionID = ""
	acc.EncodeKey = generateRandomEncodeKey()

	// 数据完整性校验
	if acc.alias == "" {
		acc.alias = acc.Account
	}

	if acc.DeviceID == "" || acc.GUID == "" || acc.VIDTicket == "" {

		authKey0, tmpGUID, err := acc.pkgRegisterDeviceGetGUID()
		if err != nil {
			return err
		}
		acc.SecAuthKey = authKey0

		tmpVIDTicket, err := acc.pkgRegisterDeviceGetVIDTicket(tmpGUID)
		if err != nil {
			return err
		}

		tmpDeviceID, err := acc.pkgSendDeviceInfoAndGetDeviceID(tmpGUID, tmpVIDTicket)
		if err != nil {
			return err
		}

		// 设置硬件信息
		acc.GUID = tmpGUID
		acc.VIDTicket = tmpVIDTicket
		acc.DeviceID = tmpDeviceID

		if err := acc.save(); err != nil {
			return errors.New("重登录时存储生成的GUID/DeviceID等硬件信息失败")
		}

		/*
			// 初始化App,无需获取authKey
			dropped, err := acc.httpInitApp(false)
			if err != nil {
				return err
			}

			if len(dropped) > 0 {
			}
		*/

	}
	// 初始化App获取authKey及最新文件版本号
	authKey, err := acc.httpInitApp()
	if err != nil {
		return err
	}
	acc.SecAuthKey = authKey

	// 模拟切换到登录页
	if err := acc.pkgSwitchToLoginPage(); err != nil {
		logger.Errorf("[BCM][%+v]重登录切换到登录页失败: %+v.", acc.Account, err)
		return errors.New("重登录切换到登录页失败")
	}

	// 模拟触发登录页密码输入键盘
	loginRSAPublicKey, err := acc.pkgTriggerForInputPassword()
	if err != nil {
		logger.Errorf("[BCM][%+v]触发登录页密码键盘失败: %+v.", acc.Account, err)
		return errors.New("触发登录页密码键盘失败")
	}

	passwordOK, errMsg, err := acc.pkgDoLogin(loginRSAPublicKey)
	if err != nil {
		logger.Errorf("[BCM][%+v]重登录操作错误: %+v.", acc.Account, err)
		return err
	}

	if passwordOK == false {
		// 密码验证失败
		logger.Errorf("[BCM][%+v]重登录失败, 信息: %+v.", acc.Account, errMsg)

		// @todo 这里需要根据如下内容做一个账号冻结策略 具体的文字判断内容需要再次抓包
		if strings.Contains(errMsg, "密码错误") || strings.Contains(errMsg, "密码输入有误") || strings.Contains(errMsg, "密码连续错误") || strings.Contains(errMsg, "密码错误次数已达最大值") {
			acc.loginFailCount++
			if acc.loginFailCount >= 2 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[BCM][%+v]重登录连续密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return errors.New(errMsg)
	}

	// 密码验证通过, 接下来验证是否是在新设备上登录的
	isChangedDevice, err := acc.pkgCheckIsChangedDevice()
	if err != nil {
		logger.Errorf("[BCM][%+v]验证是否是在新设备上登录操作错误: %+v.", acc.Account, err)
		return errors.New("无法验证是否是在新设备上登录")
	}

	if isChangedDevice == true {
		return pay.ErrNeedBindDevice
	}

	acc.loginFailCount = 0

	logger.Infof("[BCM][%+v]用户重登录成功.", acc.Account)

	return nil
}

// @todo
func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if acc.transferPadding != 0 {
		return pay.Error(pay.ErrCodeTransferError, "转帐正在操作中, 请稍候再试", nil)
	}

	if req.SMSCode == "" {

		acc.pkgGetDiffForTransferAndStatic()
		acc.pkgSwitchToTransferMainPage()

		if err := acc.pkgSwitchToTransferMainPage(); err != nil {
			// 其它设备登录
			if err == pay.ErrNeedBindDevice {
				acc.onOtherDevice()
				return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
			}

			// 超时
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[BCM][%+v]转帐重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						acc.onOtherDevice()
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			logger.Errorf("[BCM][%+v]切换到转账导航首页错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if err := acc.pkgSwitchToTransferMainPageDone(); err != nil {
			logger.Errorf("[BCM][%+v]切换到转账导航首页后的确认包返回值错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		// 限额信息
		bankCardList, err := acc.pkgSwitchToTransferToBankCardPage()
		if err != nil {

			// 其它设备登录
			if err == pay.ErrNeedBindDevice {
				acc.onOtherDevice()
				return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
			}

			// 超时
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[BCM][%+v]转帐重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						acc.onOtherDevice()
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			logger.Errorf("[BCM][%+v]查询用户限额信息失败, 信息: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, "查询用户限额信息失败", nil)
		}

		limitInfo := &modelTransferLimitInfo{}
		for _, bankCardInfo := range bankCardList {
			if bankCardInfo.CardNo == acc.useCardNo {

				fmt.Println("===debug")
				// acc.cardType = bankCardInfo.CardType
				limitInfo.LogBalance = bankCardInfo.AvailableBalance                                // 可用余额
				limitInfo.YearUseableAmt = fmt.Sprintf("%f", bankCardInfo.YearUseableAmt)           // 117999982.98
				limitInfo.DayUseablePenAmount = fmt.Sprintf("%d", bankCardInfo.DayUseablePenAmount) // 110
				limitInfo.UseableLimit = fmt.Sprintf("%f", bankCardInfo.UseableLimit)               // 50000
				limitInfo.SingleTransferLimit = fmt.Sprintf("%f", bankCardInfo.SingleTransferLimit) // 50000
				limitInfo.NowTransferedTotal = fmt.Sprintf("%.2f", bankCardInfo.NowTransferedTotal) // 0.00

				if limitInfo.NowTransferedTotal == "0.00" {
					limitInfo.NowTransferedTotal = ""
				}

				break
			}
		}

		if limitInfo == nil {
			logger.Errorf("[BCM][%+v]没有找到卡号[%+v]的限额信息.", acc.Account, acc.useCardNo)
			return pay.Error(pay.ErrCodeTransferError, "无法找到用户限额信息", nil)
		}

		// 检查长度, 防止取前6位崩溃
		if len(req.TargetAccount) < 6 {
			return pay.Error(pay.ErrCodeTransferError, "用户卡号长度不正确", nil)
		}

		// 获取收款银行的bankNo
		targetBankBaseInfo, err := acc.pkgGetBankBaseInfoWithBankCardNoFirst6Digits(req.TargetAccount[:6]) //取银行卡前六位
		if err != nil {
			logger.Errorf("[BCM][%+v]获取收款方银行bankNo失败: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, "获取收款方银行bankNo失败", nil)
		}

		if targetBankBaseInfo.BankNo != "" && targetBankBaseInfo.BankName != "" && targetBankBaseInfo.BankType != "" {

			acc.bankNo = targetBankBaseInfo.BankNo
			acc.toOpenBankNo = targetBankBaseInfo.BankNo
			acc.toPartyID = targetBankBaseInfo.BankNo

			acc.bankName = targetBankBaseInfo.BankName
			acc.toOpenBank = targetBankBaseInfo.BankName
			acc.toParty = targetBankBaseInfo.BankName

			targetBankExtraInfo, err := acc.pkgGetBankExtraInfoWithBankNo(acc.bankNo)
			if err != nil {
				logger.Errorf("[BCM][%+v]查询目标银行信息错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			acc.toOpenAreaNo = targetBankExtraInfo.ToOpenAreaNo
			acc.toOpenArea = targetBankExtraInfo.ToOpenArea
			acc.toOpenCityNo = targetBankExtraInfo.ToOpenCityNo
			acc.toOpenCity = targetBankExtraInfo.ToOpenCity
			acc.toOpenNetSpotNo = targetBankExtraInfo.ToOpenNetSpotNo
			acc.toOpenNetSpot = targetBankExtraInfo.ToOpenNetSpot
			acc.isSupportSuperBank = targetBankExtraInfo.IsSupportSuperBank

			acc.toBankType = targetBankExtraInfo.ToBankType

		} else if req.BankName != "" {
			res, err := api.NodeQueryBankInfo(req.BankName)
			if err != nil {
				acc.toOpenBank = req.BankName
				acc.toOpenBankNo = ""
				acc.toOpenCity = ""
				acc.toOpenCityNo = ""
				acc.toOpenArea = ""
				acc.toOpenAreaNo = ""
				acc.toOpenNetSpot = ""
				acc.toOpenNetSpotNo = ""
				acc.isSupportSuperBank = ""
				acc.toParty = ""
				acc.toPartyID = ""

			} else {
				acc.toOpenBank = res.BankName
				acc.toOpenBankNo = res.BankNo
				acc.toOpenCity = ""
				acc.toOpenCityNo = ""
				acc.toOpenArea = ""
				acc.toOpenAreaNo = ""
				acc.toOpenNetSpot = ""
				acc.toOpenNetSpotNo = ""
				acc.isSupportSuperBank = "0"
				acc.toParty = ""
				acc.toPartyID = ""
			}
		}

		if acc.toOpenBank == "" && acc.toOpenBankNo == "" {
			logger.Warnf("[BCM][%+v]查询到暂不支持的银行, 卡号: %+v, 银行类型: %+v, 银行编码: %+v, 银行名字: %+v.",
				acc.Account,
				req.TargetAccount,
				targetBankBaseInfo.BankType,
				targetBankBaseInfo.BankNo,
				targetBankBaseInfo.BankName)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		// 传入值为对方银行卡号
		if err := acc.pkgGetTargetBankCardInfo(req.TargetAccount); err != nil {
			logger.Errorf("[BCM][%+v]获取收款方银行卡信息失败: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, "获取收款方银行卡信息失败", nil)
		}

		acc.transferTargetAccount = req.TargetAccount
		acc.transferTargetName = req.TargetName
		acc.transferAmount = req.Amount
		acc.transferComment = req.Comment
		acc.transferOrderNo = req.OrderNo

		// 生成订单
		transferBaseParams, err := acc.pkgBuildTransferInfo(limitInfo)
		if err != nil {
			logger.Errorf("[BCM][%+v]生成订单信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if transferBaseParams.NeedFaceRecognition {
			logger.Errorf("[BCM][%+v]需要刷脸才能进行转帐操作.", acc.Account)
			return pay.Error(pay.ErrCodeTransferError, "需要刷脸才能进行转帐操作", nil)
		}

		// @todo  这个参数改到第56个包才能获取到了 acc.transferType = order.Body.Type

		acc.imageCode = transferBaseParams.ImageCode
		acc.speChkResult = transferBaseParams.SpeChkResult
		//acc.riskLevel = transferBaseParams.RiskLevel

		// 同行为"B" 跨行为"D"
		acc.transferConfirmType = transferBaseParams.TransferConfirmType

		// 重复订单确认 @todo
		/*
			acc.confirmReTranRisk = false
			if transferBaseParams.RiskLevel != 0 {
				acc.confirmReTranRisk = true

				sameOrder, err := acc.queryTransferSameOrder()
				if err != nil {
					logger.Errorf("[BCM][%+v]确认重复订单错误: %+v.", acc.Account, err)
					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				if sameOrder.Head.TranSuccess != "1" {
					logger.Errorf("[BCM][%+v]确认重复订单失败, 代码: %+v, 信息: %+v.",
						acc.Account, sameOrder.Head.ErrCode, sameOrder.Head.ErrMsg)
				}

			}*/

		// 获取转账Extra参数信息
		transferExtraParams, err := acc.pkgGetTransferExtraParams()
		if err != nil {
			return pay.Error(pay.ErrCodeTransferError, "提交转账信息ExtraParams失败", nil)
		}

		acc.hfeRateCode = transferExtraParams.HfeRateCode
		acc.feePayMode = transferExtraParams.FeePayMode
		acc.realFee = transferExtraParams.RealFee
		acc.feeTcaNo = transferExtraParams.FeeTcaNo

		// 发送验证码
		sendSmsStatus, err := acc.pkgSendTransferSmsCode()
		if err != nil {
			logger.Errorf("[BCM][%+v]发送转账验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if sendSmsStatus != true {
			logger.Errorf("[BCM][%+v]发送转帐验证码失败, 信息: %+v.",
				acc.Account, err.Error())
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		logger.Infof("[BCM][%+v]发送转帐验证码成功.", acc.Account)
		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)

	}

	atomic.StoreInt32(&acc.transferPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.transferPadding, 0)
	}()

	if acc.imageCode == "" {
		logger.Warnf("[BCM][%+v]尚未生成支付订单.", acc.Account)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrNotCreateOrderNo.Error(), nil)
	}

	// 键盘
	keyMapsInfo, err := acc.pkgTriggerForInputPayPassword()
	if err != nil {
		logger.Errorf("[BCM][%+v]解码键盘映射数据错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, "解码支付密码加密密钥错误", nil)
	}
	acc.keyMapsInfo = keyMapsInfo

	// 开始转账
	transfer, _, body, err := acc.pkgDoConfirmTransfer(req.SMSCode)

	//transfer, body, err := acc.confirmTransfer(req.SMSCode)
	if err != nil {
		// timeout时要人工确认订单状态, 暂时返回处理中
		if err == pay.ErrOperationTimeout {
			logger.Warnf("[BCM][%+v]转帐操作超时, 需工人检查是否转帐成功, 转出卡号: %+v, 名字: %+v, 金额: %+v.",
				acc.Account, acc.transferTargetAccount, acc.transferTargetName, acc.transferAmount)

			res := model.AccountTransferRes{}
			res.Code = pay.ErrCodeTransferStatusUnknow
			res.Msg = pay.ErrMsgTransferStatusUnknow
			res.ExtData = req.ExtData
			res.Status = common.TransferStatusProcessing
			res.Data.TradeNo = ""
			res.Data.TradeType = "0"
			res.Data.Amount = acc.transferAmount
			res.Data.AmountRemain = ""
			res.Data.TargetAccount = acc.transferTargetAccount
			res.Data.TargetName = acc.transferTargetName
			res.Data.TargetBankName = acc.toOpenBank
			res.Data.Comment = acc.transferComment

			api.NodeLogTransfer(
				acc.Account,
				acc.Platform,
				common.AccountTypeBCM,
				acc.transferOrderNo,
				res.Data.TradeNo,
				res.Data.TargetAccount,
				res.Data.TargetName,
				res.Data.Amount,
				res.Data.AmountRemain,
				res.Status)

			logger.LogTransfer("[BCM][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
				acc.Account,
				res.Data.TargetName,
				res.Data.TargetAccount,
				res.Data.Amount,
				res.Status,
				acc.transferOrderNo,
				res.Data.TradeNo,
				"转帐操作超时, 需要人工核对转帐是否完成.")

			return pay.Success(&res)
		}

		// 失败
		logger.Errorf("[BCM][%+v]转帐操作失败, 信息: %+v.",
			acc.Account, err)

		// 内部止付
		if strings.Contains(err.Error(), "账户已内部止付") {
			acc.freeze(pay.FreezeCodeCardError, err.Error())
			return pay.Error(pay.ErrCodeCardBlock, err.Error(), nil)
		}

		// 验证码错误
		if strings.Contains(err.Error(), "您输入的短信动态密码有误") {
			acc.smscodeFailCount++
			if acc.smscodeFailCount >= 3 {
				acc.smscodeFailCount = 0
				acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
				logger.Errorf("[BCM][%+v]连续转帐验证码错误, 临时冻结帐号.", acc.Account)
			}
		}

		if strings.Contains(err.Error(), "您密码错误") {
			acc.payPasswordFailCount++
			if acc.payPasswordFailCount >= 2 {
				acc.payPasswordFailCount = 0
				acc.freeze(pay.FreezeCodePayPasswordError, pay.FreezeMsgPayPasswordError)
				logger.Errorf("[BCM][%+v]连续支付密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)

		/*
			logger.Errorf("[BCM][%+v]转帐操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, "转帐操作错误", nil)
		*/
	}

	if transfer.IsSuccess != "0" {
		logger.Errorf("[BCM][%+v]确认转帐操作失败, IsSuccess: %+v.", acc.Account, transfer.IsSuccess)
		return pay.Error(pay.ErrCodeTransferError, fmt.Sprintf("确认转帐操作失败, 代码: %s", transfer.IsSuccess), nil)
	}

	// 成功
	acc.imageCode = ""
	acc.smscodeFailCount = 0
	acc.payPasswordFailCount = 0

	res := model.AccountTransferRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.ExtData = req.ExtData

	res.Status = common.TransferStatusSuccess
	res.Data.TradeNo = transfer.SequenceNo
	res.Data.TradeType = "0"
	res.Data.Amount = transfer.TranSum
	res.Data.AmountRemain = transfer.Balance
	res.Data.TargetAccount = transfer.ToCardNo
	res.Data.TargetName = transfer.ToAccName
	res.Data.TargetBankName = transfer.RcvBankName
	res.Data.Comment = transfer.Remark

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypeBCM,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		res.Status)

	logger.LogTransfer("[BCM][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		res.Data.TargetName,
		res.Data.TargetAccount,
		res.Data.Amount,
		res.Status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)

	// 转帐后续操作
	go func() {
		acc.transferType = transfer.TransferType
		if err := acc.pkgTriggerForRequestSuccessfulTransferPage(); err != nil {

		}

		if err := acc.pkgSwitchToSuccessfulTransferPage(); err != nil {

		}
	}()

	return pay.Success(&res)
}

//
func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	return pay.Success(nil)
}
