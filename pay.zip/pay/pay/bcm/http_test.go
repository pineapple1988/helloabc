package bcm

import (
	"fmt"
	"pay/pay/bcm/codec"
	"pay/pay/bcm/codec/CSSharkBase"
	"testing"
	"time"
)

// 测试GUID的解析
func TestParseGUID(t *testing.T) {
	someBytes := []byte{0x06, 0x20, 0x30, 0x33, 0x30, 0x33, 0x37, 0x37, 0x32, 0x30, 0x30, 0x31, 0x30, 0x36, 0x31, 0x34, 0x30,
		0x33, 0x35, 0x32, 0x36, 0x31, 0x33, 0x32, 0x33, 0x38, 0x36, 0x37, 0x31, 0x35, 0x39, 0x38, 0x33, 0x33}

	structGUID := CSSharkBase.ResponseGUIDBytes{}
	if err := structGUID.ReadFrom(codec.NewReader(someBytes)); err != nil {
		// do nothing
		fmt.Println("err")
	}
	fmt.Println(structGUID)

}

func TestFormatBillDealTime(x *testing.T) {
	const TIME_LAYOUT = "2006-01-02 15:04:05"

	str := "2020-01-05 3:26:32"
	t, _ := time.Parse(TIME_LAYOUT, str)
	fmt.Println("2. Parse time: ", t)
	tStr := t.Format(TIME_LAYOUT)
	fmt.Println("3. Format time str: ", tStr)
}
