package pay

import "errors"

// 常用错误定义
var (
	// 网络操作超时错误
	ErrOperationTimeout = errors.New("调用银行接口请求超时, 请稍候重试")

	// 网络操作错误
	ErrOperationError = errors.New("网络操作错误, 请稍候重试")

	// 登录会话超时
	ErrSessionTimeout = errors.New("登录会话超时, 请重新登录")

	// 账号密码错误
	ErrWrongPsw = errors.New("登陆账号密码错误，请查验账号密码")

	// 需要输入验证码错误
	QRWrongPsw = errors.New("触发图形验证码，需要小白自行用手机登陆账号,输入图形验证码后成功登陆后，再用协议登陆账号")
	// 没有银行卡列表
	ErrNoHaveCardList = errors.New("该帐号没有银行卡列表")

	// 重新绑定设备
	ErrNeedBindDevice = errors.New("帐号已在其它设备登录, 请重新登录进行设备绑定")

	// 创建http请求错误
	ErrCreateHTTPRequest = errors.New("创建http请求错误")

	// 序列化请求数据错误
	ErrMarshalRequestData = errors.New("处理请求数据错误")

	// 反序列化响应数据错误
	ErrUnmarshalResponseData = errors.New("处理服务器响应数据错误")

	// 加密请求数据错误
	ErrEncRequestData = errors.New("加密请求数据错误")

	// 解密响应数据错误
	ErrDecRequestData = errors.New("解密响应数据错误")

	// 未生成支付订单
	ErrNotCreateOrderNo = errors.New("尚未生成支付订单")

	// 刷脸图片数据错误
	ErrFaceDataError = errors.New("处理刷脸图片数据错误")

	// 需要版本更新
	ErrUpgradeRequired = errors.New("检测到银行版本更新, 需要更新后才能操作")

	// 执行交易失败
	ErrBankTradeFail = errors.New("银行执行操作失败, 请稍候重试")
)
