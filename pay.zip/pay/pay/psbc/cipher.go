package psbc

import (
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	// "pay/pay/psbc/tjfoc/gmsm/cipher2"
	"pay/utils"
	"strconv"

	"pay/pay/psbc/tjfoc/gmsm/sm2"
	// "pay/pay/psbc/tjfoc/gmsm/sm3"
	// "pay/pay/psbc/tjfoc/gmsm/sm4"
	// "github.com/tjfoc/gmsm/sm2"
	"github.com/tjfoc/gmsm/sm3"
	"github.com/tjfoc/gmsm/sm4"
)

func reqecm1size(len int) int {
	var size int = 0

	if (len % 16) != 0 {

		size = (len + 16) - (len % 16)

	} else {
		size = len + 16
	}
	return size
}

func reqecm1(inPut []byte, inLen int, outLen int) []byte {

	var inOut = make([]byte, outLen)
	copy(inOut, inPut)
	//fmt.Println(copyLen)
	v4 := utils.NewRandString(outLen-inLen-1, false)
	v5 := []byte(v4)
	if inLen != outLen {
		inOut[inLen] = 29
		for i := 1; i < (outLen - inLen); i++ {
			inOut[i+inLen] = v5[i-1]%0x96 + 30
		}
	}
	return inOut
}

func reqecm3(inLen int, inPut []byte, OutLen int) []byte {

	var retOut = make([]byte, OutLen)
	//m2 生成16字节随机
	randstr := utils.NewRandString(16, false)
	randomByte := []byte(randstr)

	len := inLen / 16

	for i := 0; i < len; i++ {
		for j := 0; j < 16; j++ {
			retOut[i*16+j] = randomByte[j] ^ inPut[i*16+j]
		}
	}
	for k := 0; k < 16; k++ {
		retOut[inLen+k] = randomByte[k]
	}
	return retOut
}

// SM2Encrypt SM2加密
func SM2Encrypt(data []byte, x, y string, etype bool) ([]byte, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()

	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	out, err := pub.Encrypt(data, etype)
	// out, err := pub.Encrypt(data)
	if err != nil {
		return nil, err
	}

	return out, nil
}

//SM4Decrypt 解密
func SM4Decrypt(data []byte, key []byte) ([]byte, error) {
	c, _ := sm4.NewCipher(key)

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(data); i += c.BlockSize() {
		src := data[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

//SM4ECBEncrypt 加密
func SM4ECBEncrypt(buf, key []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	// buf = utils.PKCS7Padding(buf, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(buf); i += c.BlockSize() {
		src := buf[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

// //SM4ECBDecrypt 解密
// func SM4ECBDecrypt(in, key []byte) []byte {
// 	s4, err := sm4.NewCipher(key)
// 	if err != nil {
// 		return nil
// 	}

// 	out := make([]byte, len(in))

// 	c := cipher2.NewECBDecrypter(s4)
// 	c.CryptBlocks(out, in)

// 	return out
// }

//SM4ECBDecrypt 解密
func SM4ECBDecrypt(data []byte, key []byte) ([]byte, error) {
	c, _ := sm4.NewCipher(key)

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(data); i += c.BlockSize() {
		src := data[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

func requestPckageEncryp(bodyData []byte, sm4randKey string) []byte {

	sizeM1 := reqecm1size(len(bodyData))
	enM1 := reqecm1(bodyData, len(bodyData), sizeM1)
	enM3 := reqecm3(len(enM1), enM1, sizeM1+16)

	//sm3拼接数据
	dataSm3 := string(bodyData) + sm4randKey + "PSBC"
	enSM4, _ := SM4ECBEncrypt(enM3, []byte(sm4randKey))
	enSM3 := sm3.Sm3Sum([]byte(dataSm3))

	enSM2, _ := SM2Encrypt([]byte(sm4randKey), sm2X, sm2Y, true)

	pckageData := fmt.Sprintf("#01%x%c%x%c%X", enSM3, 29, enSM4, 29, enSM2)

	return []byte(pckageData)
}

func responsePckageDecrypt(respData string, sm4Key string) []byte {

	PCS := parserControl{}
	PCS.AppedingNum, _ = strconv.ParseInt(respData[1:3], 16, 32)
	PCS.MinRange, _ = strconv.ParseInt(respData[3:5], 16, 32)
	PCS.MaxRange, _ = strconv.ParseInt(respData[5:7], 16, 32)
	PCS.MixType, _ = strconv.ParseInt(respData[7:8], 16, 32)
	PCS.CryptNum, _ = strconv.ParseInt(respData[8:14], 16, 32)
	PCS.Data = []byte(respData[14:])
	RangeData := PCS.Data[PCS.MinRange:(PCS.MaxRange + PCS.MinRange)]
	lenMaxRange, _ := strconv.Atoi(strconv.FormatInt(PCS.MaxRange, 10))

	if PCS.MixType == 2 {
		for i := 2; i <= lenMaxRange; i += 2 {
			v16 := RangeData[i-1]
			RangeData[i-1] = RangeData[i-2]
			RangeData[i-2] = v16
		}
	}
	copy(PCS.Data[PCS.MinRange:], RangeData)
	sm4Put, _ := hex.DecodeString(string(PCS.Data[:PCS.CryptNum]))
	deData, _ := SM4ECBDecrypt(sm4Put, []byte(sm4Key))

	return deData
}

func encrypPWD(passworld string) string {

	strData := stringFordeviation(passworld)

	enData, _ := SM2Encrypt([]byte(strData), pwdsm2X, pwdsm2Y, false)

	PWD := base64.StdEncoding.EncodeToString(enData)

	return PWD
}

func stringFordeviation(password string) string {
	//随机1 - 99之间 一个值

	randInt := byte(utils.RandInt(1, 99))

	strv10 := ""
	passwordv9 := []byte(password)
	tmepInt := fmt.Sprintf("%02d", randInt)
	strv10 += tmepInt
	lenv5 := len(passwordv9)

	for i := 0; i < lenv5; i++ {
		v11 := passwordv9[i]
		var tmepHex = fmt.Sprintf("%02X", (randInt+v11)&0xFF)
		strv10 = strv10 + tmepHex
	}

	return strv10
}
