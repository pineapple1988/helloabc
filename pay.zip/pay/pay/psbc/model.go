package psbc

type parserControl struct {
	AppedingNum int64
	MinRange    int64
	MaxRange    int64
	MixType     int64
	CryptNum    int64
	Data        []byte
}

type blackList struct {
	MemuURLMd5 string `json:"MENU_URL_MD5"`
}

type resultAcctList struct {
	AccType       string `json:"ACCT_TYPE"`
	CardBookFlag  string `json:"CARD_BOOK_FLAG"`
	AcctNO        string `json:"ACCT_NO"`
	TransDate     string `json:"TRANS_DATE"`
	AccFun        string `json:"ACCT_FUN"`
	AccLastFour   string `json:"ACCT_LAST_FOUR"`
	SignType      string `json:"SIGN_TYPE"`
	SignChannel   string `json:"SIGN_CHANNEL"`
	AcctSignAddNO string `json:"ACCT_SIGNADDNO"`
	AcctClass     string `json:"ACCT_CLASS"`
	AcctAlias     string `json:"ACCT_ALIAS"`
	IsDefaultAcct string `json:"IS_DEFAULT_ACCT"`
}

//resExecuteLogin 登录包返回
type resExecuteLogin struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Result   struct {
		CuschlType          string           `json:"CUS_CHL_TYPE"`
		Mmxgbz              string           `json:"MMXGBZ"`
		Qzkhdj              string           `json:"QZKHDJ"`
		RiskLevel           string           `json:"riskLevel"`
		Riskstate           string           `json:"riskState"`
		BindStatus          int              `json:"BIND_STATUS"`
		IdtType             string           `json:"IDT_TYPE"`
		LoginPinUpdate      string           `json:"LOGINPINUPDATE"`
		OpenOrg             string           `json:"OPEN_ORG"`
		AccPropectStatus    string           `json:"ACCT_PROPECT_STATUS"`
		Token               string           `json:"token"`
		CustID              string           `json:"CUST_ID"`
		Sex                 string           `json:"SEX"`
		LoginStatus         string           `json:"LOGIN_STATUS"`
		LastClientInfo      string           `json:"LAST_CLIENT_INFO"`
		LogonResult         string           `json:"LOGON_RESULT"`
		TranPWDFlag         string           `json:"TRAN_PWD_FLAG"`
		IdtNO               string           `json:"IDT_NO"`
		LastLoginTime       string           `json:"LAST_LOGIN_TIME"`
		MemuGroup           string           `json:"MENU_GROUP"`
		CheckState          string           `json:"CHECK_STATE"`
		CustNO              string           `json:"CUST_NO"`
		AcctNO              string           `json:"ACCT_NO"`
		BlackList           []blackList      `json:"BLACK_LIST"`
		LoginNum            string           `json:"LOGIN_NUM"`
		List                []resultAcctList `json:"list"`
		RiskType            string           `json:"riskType"`
		CustType            string           `json:"CUST_TYPE"`
		CustMessage         string           `json:"CUST_MESSAGE"`
		LoginPinDate        string           `json:"LOGINPINDATE"`
		CustName            string           `json:"CUST_NAME"`
		LoginCode           string           `json:"LOGIN_CODE"`
		LoginDate           string           `json:"LOGINDATE"`
		ChlCheckType        string           `json:"CHL_CHECK_TYPE"`
		MobileNO            string           `json:"MOBILENO"`
		TranPinDate         string           `json:"TRANPINDATE"`
		CusChlStatus        string           `json:"CUS_CHL_STATUS"`
		SafesTyle           string           `json:"SAFES_TYLE"`
		LoginResultStatus   string           `json:"LOGIN_RESULT_STATUS"`
		LoginTime           string           `json:"LOGIN_TIME"`
		SystemDate          string           `json:"SYSTEM_DATE"`
		ServiceRootValidate string           `json:"SERVICE_ROOT_VALIDATE"`
	} `json:"result"`
}

type resGetNewSmsCode struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		RetCode        string `json:"retCode"`
		SendBusinessNo string `json:"sendBusinessNo"`
		ErrMsg         string `json:"errMsg"`
		TerminalNo     string `json:"terminalNo"`
		SmsCode        string `json:"SMS_CODE"`
	} `json:"result"`
}

type resGetNewCheckSmsCode struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		RetCode    string `json:"retCode"`
		ErrMsg     string `json:"errMsg"`
		TerminalNo string `json:"terminalNo"`
	} `json:"result"`
}

type resqueryFirstLoginFlag struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		FirstLoginFlag string `json:"firstLoginFlag"`
	} `json:"result"`
}

type resgetAccountQueryShowBal struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		DumpFlag        string `json:"DUMP_FLAG"`
		AcctName        string `json:"ACCT_NAME"`
		Index           string `json:"INDEX"`
		AcctCodeName    string `json:"ACCT_CODE_NAME"`
		DepositDeadline string `json:"DEPOSIT_DEADLINE"`
		UseableAmt      string `json:"USEABLE_AMT"`
		AcctClass       string `json:"ACCT_CLASS"`
		EndDate         string `json:"END_DATE"`
		AcctAmt         string `json:"ACCT_AMT"`
		AcctCodeNew     string `json:"ACCT_CODE_NEW"`
		AcctOpenDate    string `json:"ACCT_OPEN_DATE"`
		AcctCode        string `json:"ACCT_CODE"`
		AcctStatus      string `json:"ACCT_STATUS"`
	} `json:"result"`
}

type interTransfer struct {
	BusinessInfo   string `json:"businessInfo"`
	Remark         string `json:"remark"`
	PayBankName    string `json:"payBankName"`
	PayLineNum     string `json:"payLineNum"`
	SideLineName   string `json:"sideLineName"`
	SideLineNum    string `json:"sideLineNum"`
	InAcctName     string `json:"inAcctName"`
	InAcctNo       string `json:"inAcctNo"`
	ChlFlag        string `json:"chlFlag"`
	SloatFlag      string `json:"sloatFlag"`
	AccessFlag     string `json:"accessFlag"`
	TermID         string `json:"termId"`
	BalanceAmt     string `json:"balanceAmt"`
	TransAmt       string `json:"transAmt"`
	PostScript     string `json:"postScript"`
	PayAcctName    string `json:"payAcctName"`
	ProAcctNo      string `json:"proAcctNo"`
	TranTypeCode   string `json:"tranTypeCode"`
	TranTime       string `json:"tranTime"`
	TranSeqno      string `json:"tranSeqno"`
	TranTerminalNo string `json:"tranTerminalNo"`
	TranDept       string `json:"tranDept"`
	TranDate       string `json:"tranDate"`
}

type resqueryInterTransferDetail struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		InterTransferList []struct {
			InterTransfer interTransfer `json:"InterTransfer"`
		} `json:"interTransferList"`
		Dnum           string `json:"dnum"`
		RetCode        string `json:"retCode"`
		SendBusinessNo string `json:"sendBusinessNo"`
		ErrMsg         string `json:"errMsg"`
		TerminalNo     string `json:"terminalNo"`
		StartNum       string `json:"startNum"`
	} `json:"result"`
}

type resgetCardBinInfo struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		BankCode string `json:"BANK_CODE"`
		BankName string `json:"BANK_NAME"`
	} `json:"result"`
}

type resExecuteCheckAuthenticationWay struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Result   struct {
		AuthList  []string `json:"authList"`
		RiskAuths []string `json:"riskAuths"`
	} `json:"result"`
}

type resTransferSmsCode struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		RetCode        string `json:"retCode"`
		SendBusinessNo string `json:"sendBusinessNo"`
		ErrMsg         string `json:"errMsg"`
		TerminalNo     string `json:"terminalNo"`
		SmsCode        string `json:"SMS_CODE"`
	} `json:"result"`
}

type resgetAccountType struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		CardBookFlagName string `json:"CARD_BOOK_FLAG_NAME"`
		AccTypeName      string `json:"ACCT_TYPE_NAME"`
		AcctType         string `json:"ACCT_TYPE"`
		CardBookFlag     string `json:"CARD_BOOK_FLAG"`
	} `json:"result"`
}

type resExecuteTransfer struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		OprLogBUSITYPE     string `json:"oprLog_BUSI_TYPE"`
		SendBusinessNo     string `json:"sendBusinessNo"`
		AvailableBanlance  string `json:"availableBanlance"`
		ProBankName        string `json:"proBankName"`
		PayeeFlag          string `json:"payeeFlag"`
		BackPin            string `json:"backPin"`
		PayAcctNo          string `json:"payAcctNo"`
		BackNo             string `json:"backNo"`
		TransDate          string `json:"TRANS_DATE"`
		ProName            string `json:"proName"`
		Poundage           string `json:"poundage"`
		BusinessNo         string `json:"businessNo"`
		OprLogTransPrupose string `json:"oprLog_TRANS_PRUPOSE"`
		ReservedPoundage   string `json:"reservedPoundage"`
		AnotherPoundage    string `json:"anotherPoundage"`
		PayeeFlag1         string `json:"PAYEE_FLAG"`
		PayName            string `json:"payName"`
		TerminalNo         string `json:"terminalNo"`
		ProAcctNo          string `json:"proAcctNo"`
		ClearDate          string `json:"clearDate"`
		TransTime          string `json:"TRANS_TIME"`
		OprLogAccNo        string `json:"oprLog_AccNo"`
		TransAmt           string `json:"transAmt"`
		RetCode            string `json:"retCode"`
		ProAcctOpenNo      string `json:"proAcctOpenNo"`
		ErrMsg             string `json:"errMsg"`
		OpenAcctNo         string `json:"openAcctNo"`
	} `json:"result"`
}

type resexecuteLogout struct {
	SerialNo string `json:"serialNo"`
	Total    int    `json:"total"`
	Success  bool   `json:"success"`
	Message  string `json:"message"`
	Error    string `json:"error"`
	Result   struct {
		OprLogBUSITYPE     string `json:"oprLog_BUSI_TYPE"`
		SendBusinessNo     string `json:"sendBusinessNo"`
		AvailableBanlance  string `json:"availableBanlance"`
		ProBankName        string `json:"proBankName"`
		PayeeFlag          string `json:"payeeFlag"`
		BackPin            string `json:"backPin"`
		PayAcctNo          string `json:"payAcctNo"`
		BackNo             string `json:"backNo"`
		TransDate          string `json:"TRANS_DATE"`
		ProName            string `json:"proName"`
		Poundage           string `json:"poundage"`
		BusinessNo         string `json:"businessNo"`
		OprLogTransPrupose string `json:"oprLog_TRANS_PRUPOSE"`
		ReservedPoundage   string `json:"reservedPoundage"`
		AnotherPoundage    string `json:"anotherPoundage"`
		PayeeFlag1         string `json:"PAYEE_FLAG"`
		PayName            string `json:"payName"`
		TerminalNo         string `json:"terminalNo"`
		ProAcctNo          string `json:"proAcctNo"`
		ClearDate          string `json:"clearDate"`
		TransTime          string `json:"TRANS_TIME"`
		OprLogAccNo        string `json:"oprLog_AccNo"`
		TransAmt           string `json:"transAmt"`
		RetCode            string `json:"retCode"`
		ProAcctOpenNo      string `json:"proAcctOpenNo"`
		ErrMsg             string `json:"errMsg"`
		OpenAcctNo         string `json:"openAcctNo"`
	} `json:"result"`
}
