package psbc

const (
	psAccountKey    = "PSBCAccount"
	psCookieKey     = "PSBCCookie"
	platformIOS     = "ios"
	platformAndroid = "android"
	appVersion      = "5.0.1"

	sm2X    = "C7191C0C324E45AE4FC7CBA56567B631038D702815BD8E4619882EA465264B5B"
	sm2Y    = "F5932A4180077E64AEC9E4767AE9EC97A083DF7EA7A5D41677E1ED12F520F295"
	pwdsm2X = "E842C70157584DE6229FFE56A2CCABDBCFA01A7C5EF24B254638EFB650C9EE19"
	pwdsm2Y = "6B64788F09777F376F921B038A5BBFF2AFEBA0B81E63EB40DFCDFD1B46819BE1"

	timerUpdate         = 1000
	timerUpdateInterval = 1000
)

const (
	urlChannel = "https://mbank.psbc.com:80/mbank_f/channel/http.do"
)
