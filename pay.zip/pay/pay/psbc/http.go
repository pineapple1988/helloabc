package psbc

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"pay/utils"
	"pay/utils/logger"

	jsoniter "github.com/json-iterator/go"
)

func (acc *Account) fillHeader(req *http.Request) {
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Content-Type", "text/xml;charset=UTF-8")
	req.Header.Set("User-Agent", "iphone")
	req.Header.Set("Accept-Language", "zh-cn")
	req.Header.Set("Accept-Encoding", "br, gzip, deflate")
}

func (acc *Account) postHTTPData(req interface{}, res interface{}, needEncrypt bool) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[PSBC]postHTTPData序列化错误: %+v.", err)
		return "", err
	}

	logger.Infof("[PSBC][%+v]postHTTPData: %+v", acc.Account, string(arr))

	fmt.Println(string(arr))

	if needEncrypt {

		// body111 := requestPckageEncryp([]byte("11111111"), acc.sm4randKey)
		// fmt.Println("1111111111111111111")
		// fmt.Println(string(body111))
		// fmt.Println("2222222222222222222")

		// arr = requestPckageEncryp([]byte(arr), acc.sm4randKey)
		arr = requestPckageEncryp(arr, acc.sm4randKey)
	}

	fmt.Println(string(arr))

	r, err := http.NewRequest("POST", urlChannel, bytes.NewReader(arr))
	// r, err := http.NewRequest("POST", urlChannel, strings.NewReader(sendstr))
	if err != nil {
		logger.Errorf("[PSBC]postHTTPData创建http请求错误: %+v.", err)
		return "", err
	}

	acc.fillHeader(r)

	body, err := utils.DoHTTP(acc.http, r)
	if err != nil {
		fmt.Printf("%+v.", err)
		logger.Errorf("[PSBC]postHTTPData http操作错误: %+v.", err)
		return "", err
	}

	if needEncrypt {
		body = string(responsePckageDecrypt(body, acc.sm4randKey))
	}

	fmt.Println(body)

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), res); err != nil {
			logger.Errorf("[PSBC]postHTTPData反序列化响应数据错误: %+v.", err)
			return "", err
		}
	}

	return body, nil
}

func (acc *Account) executeLogin() (*resExecuteLogin, error) {
	pass := encrypPWD(acc.getPassword())

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "loginService/executeLogin",
			"_t":      fmt.Sprintf("%d", utils.GetTimeStampEx()),
		},
		"payload": map[string]interface{}{
			"CAPTCHA":              "",
			"APP_TYPE":             "001",
			"LOGIN_TYPE":           "1",
			"APP_VERSION":          appVersion,
			"X_LINE":               "0.000000",
			"CLIENT_OS":            "I",
			"MOBILE":               acc.Account,
			"MOBILE_PHONE_VERSION": acc.HardwareInfo.SystemVersion,
			"IS_REMMBER_NO":        "1",
			"PWD":                  pass,
			"IS_ACTIVATE":          "0",
			"CLIENT_NO":            acc.ClientID,
			// "CLIENT_NO": "5F16B482-9B53-4768-99CB-355C9B86DC95",
			"CLIENT_INFO":        acc.HardwareInfo.DeviceName,
			"CLIENT_TYPE":        "IP",
			"CLIENT_VER":         "4",
			"CLIENT_WIFI_FLAG":   "WIFI",
			"CLIENT_ROOT_FLAG":   "0",
			"FINGER_CHANGE_FLAG": "0",
			"CLIENT_IP":          "",
			"Y_LINE":             "0.000000",
		},
	}

	res := resExecuteLogin{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]executeLogin请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getNewSmsCode() (*resGetNewSmsCode, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "smsCodeService/getNewSmsCode",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "get",
			"options":    nil,
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"INDICATE":      "0",
			"sms_serv_code": "0",
			"targetCode":    "SBYZ100001",
		},
	}

	res := resGetNewSmsCode{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getNewSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getNewCheckSmsCode(code string) (*resGetNewCheckSmsCode, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "smsCodeService/getNewCheckSmsCode",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "get",
			"options":    nil,
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"INDICATE":      "0",
			"SMS_CODE":      code,
			"SMS_CODE_FLAG": "1",
			"sms_serv_code": "0",
			"targetCode":    "SBYZ100001",
		},
	}

	res := resGetNewCheckSmsCode{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getNewCheckSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryFirstLoginFlag() (*resqueryFirstLoginFlag, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "deviceBindService/queryFirstLoginFlag",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "query",
			"options":    nil,
			"staticData": "false",
		},
		"payload": map[string]interface{}{},
	}

	res := resqueryFirstLoginFlag{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]queryFirstLoginFlag请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//获取账户信息和余额
func (acc *Account) getAccountQueryShowBal() (*resgetAccountQueryShowBal, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctManageService/getAccountQueryShowBal",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "get",
			"options":    nil,
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"ACCT_NO":        acc.AcctNo,
			"CHECK_MARK":     "0",
			"PASS_WORD":      "0",
			"CARD_BOOK_FLAG": acc.CardBookFlag,
			"ACCT_CODE":      "",
			"INDEX":          0,
			"ACCT_TYPE":      acc.AcctType,
			"KHJG_FLAG":      "1",
		},
	}

	res := resgetAccountQueryShowBal{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getAccountQueryShowBal请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryInterTransferDetail(startDate, endDate string, page int) (*resqueryInterTransferDetail, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "acctManageService/queryInterTransferDetail",
			"_t":      fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":  "query",
			"options": map[string]interface{}{
				"allowCount": true,
				"start":      page,
				"limit":      10,
			},
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"payAcctNo":   acc.AcctNo,
			"startDate":   startDate,
			"endDate":     endDate,
			"payAcctFlag": "2",
			"NEW_BK_NO":   acc.acctCodeNew,
			"accessFlag":  "0",
			"transType":   "1",
			"MAXROW":      nil,
			// "allowCount":  true,
			// "start":       0,
			// "limit":       5,
		},
	}

	res := resqueryInterTransferDetail{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]queryInterTransferDetail请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//获取对方账户银行卡信息
func (acc *Account) getCardBinInfo(targetAccount string) (*resgetCardBinInfo, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctInfoService",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "getCardBinInfo",
			"options":    nil,
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"CARD_BIN": targetAccount,
		},
	}

	res := resgetCardBinInfo{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getCardBinInfo请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

// //获取所有银行卡信息
// func (acc *Account) getAllBankCardInfo(startDate, endDate string) (*resGetAllBankCardInfo, error) {

// 	data := map[string]interface{}{
// 		"header": map[string]interface{}{
// 			"service":    "receivingBankService",
// 			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
// 			"method":     "getRealTimeReceivingBank",
// 			"options":    nil,
// 			"staticdata": "false",
// 		},
// 		"payload": map[string]interface{}{
// 			"BANK_NAME": "",
// 			"OPER_TYPE": "1",
// 		},
// 	}

// 	res := resGetAllBankCardInfo{}

// 	_, err := acc.postHTTPData(&data, &res, true)
// 	if err != nil {
// 		logger.Errorf("[PSBC]getAllBankCardInfo请求错误: %+v.", err)
// 		return nil, err
// 	}

// 	return &res, nil
// }

//转账第1步: 获取交易认证方式
func (acc *Account) executeCheckAuthenticationWay() (*resExecuteCheckAuthenticationWay, error) {

	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]

	busiType := "1000"
	if acc.transferPayeeType == "0" {
		busiType = "1000"
	} else {
		busiType = "1002"
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "authService",
			"_t":      fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":  "executeCheckAuthenticationWay",
			"options": []string{
				"31",
			},
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"ACCT_NO":             acc.AcctNo, //付款账号
			"BUSI_TYPE":           busiType,   //根据 PAYEE_TYPE赋值 if PAYEE_TYPE == "0" {BUSI_TYPE == 1000} 2=1002
			"PAYEE_ACCT_NO":       acc.transferTargetAccount,
			"AUTH_LEVEL":          "RISK",
			"JYLX":                "1",
			"PAYEE_TYPE":          acc.transferPayeeType, //0行内转账  2跨行转账
			"INDICATE":            "31",
			"AMT":                 acc.transferAmount,
			"userName":            acc.transferTargetName, //"张强" //收款人名字
			"cardNo":              cardNo,                 //"4317"//取收款卡最后4位
			"last4MobileNo":       "",
			"sms_serv_code":       "31", //sms_serv_code == INDICATE
			"orderNo":             "",
			"chlCheckType":        "0",          //渠道凭证类型
			"isCheckPasteCardDia": "true",       // 若是使用贴膜卡做交易，增加此字段。不用不能加。目前只有转账和汇款用到。
			"isSIMCardDia":        "true",       // 若是使用SIM卡盾做交易，增加此字段。不用不能加。目前只有转账和汇款用到
			"targetCode":          "ZZ00000009", // 目标功能代码
			"tradeType":           "01",         //1-转账,2-支付,3-缴费,4-外汇
			"FINGER_FLAG":         "0",
		},
	}

	res := resExecuteCheckAuthenticationWay{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]executeCheckAuthenticationWay请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//转账第2步 提交转账订单获取转账交易短信验证码
func (acc *Account) getTransferSmsCode() (*resTransferSmsCode, error) {

	smsIndex := utils.RandInt(1000, 9999)
	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]

	busiType := "1000"
	if acc.transferPayeeType == "0" {
		busiType = "1000"
	} else {
		busiType = "1002"
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "smsCodeService/getNewSmsCode",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "get",
			"options":    []interface{}{},
			"staticData": "false",
		},
		"payload": map[string]interface{}{

			"ACCT_NO":             acc.AcctNo, //付款账号
			"BUSI_TYPE":           busiType,   //根据 PAYEE_TYPE赋值 if PAYEE_TYPE == "0" {BUSI_TYPE == 1000}
			"PAYEE_ACCT_NO":       acc.transferTargetAccount,
			"AUTH_LEVEL":          "RISK",
			"JYLX":                "1",
			"PAYEE_TYPE":          acc.transferPayeeType, //0行内转账  2跨行转账
			"INDICATE":            "31",
			"AMT":                 acc.transferAmount,
			"userName":            acc.transferTargetName, //"张强" //收款人名字
			"cardNo":              cardNo,                 //"4317"//取收款卡最后4位
			"last4MobileNo":       "",
			"sms_serv_code":       "31", //sms_serv_code == INDICATE
			"orderNo":             "",
			"chlCheckType":        "0",          //渠道凭证类型
			"isCheckPasteCardDia": "true",       // 若是使用贴膜卡做交易，增加此字段。不用不能加。目前只有转账和汇款用到。
			"isSIMCardDia":        "true",       // 若是使用SIM卡盾做交易，增加此字段。不用不能加。目前只有转账和汇款用到
			"targetCode":          "ZZ00000009", // 目标功能代码
			"tradeType":           "01",         //1-转账,2-支付,3-缴费,4-外汇
			"FINGER_FLAG":         "0",
			"smsIndex":            smsIndex,
		},
	}

	res := resTransferSmsCode{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getTransferSmsCode请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//如果是同行转账需要发这个包
func (acc *Account) getAccountType() (*resgetAccountType, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "acctManageService/getAccountType",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "get",
			"options":    []interface{}{},
			"staticData": "false",
		},
		"payload": map[string]interface{}{
			"ACCT_NO": acc.AcctNo, //付款账号
		},
	}

	res := resgetAccountType{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]getAccountType请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

//转账第3步 确认转账
func (acc *Account) executeTransfer(code string) (*resExecuteTransfer, string, error) {

	cardNo := acc.transferTargetAccount[len(acc.transferTargetAccount)-4:]

	payload := map[string]interface{}{
		"PAYEE_TYPE":       acc.transferPayeeType, //0行内转账  2跨行转账
		"ACCT_NO":          acc.AcctNo,            //付款账号
		"CARD_BOOK_FLAG":   acc.CardBookFlag,
		"TRANS_AMT":        acc.transferAmount,
		"PAYEE_ACCT_NO":    acc.transferTargetAccount,
		"PAYEE_NAME":       acc.transferTargetName,
		"ACTUAL_FEE":       "0.0",
		"POUNDAGERATIO":    "",
		"PAYEE_BANK_CODE":  acc.transferBankCode,
		"PAYEE_BANK_NAME":  acc.transferBankName,
		"ZZFS":             "0",
		"COMPANYOPENORGAN": "",
		"BUSITYPE":         acc.transferBusiType,
		"REMARK":           acc.transferComment,
		"OVERLIMITFLAG":    "0",
		"ACCT_CODE":        acc.acctCodeNew,
		"SMS_CODE_FLAG":    "1",
		"SMS_CODE":         code,
		"targetCode":       "ZZ00000009",
		"sms_serv_code":    "31",
		"YLPMMBZ":          "0",
		"IS_SAVE_PAYEE":    "1",
		"AMT":              acc.transferAmount,
		"userName":         acc.transferTargetName,
		"cardNo":           cardNo,
	}

	if acc.transferPayeeType == "0" {
		payload["PAYEE_ACCT_TYPE"] = acc.transferAcctType
		payload["PAYEE_ACCT_CARDFLAG"] = acc.transferCardBookFlag
	}

	//如果是CODE不需要密码验证
	if acc.transferAuthType == "SMS" {
		paypass := encrypPWD(acc.getPayPassword())
		payload["YMMBZ"] = "1"
		payload["JYMM"] = paypass
	}

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service":    "transferService/executeTransfer",
			"_t":         fmt.Sprintf("%d", utils.GetTimeStampEx()),
			"method":     "execute",
			"options":    []interface{}{},
			"staticData": "false",
		},
		"payload": payload,
	}

	res := resExecuteTransfer{}

	body, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]executeTransfer请求错误: %+v.", err)
		return nil, "", err
	}

	return &res, body, nil
}

//如果是同行转账需要发这个包
func (acc *Account) executeLogout() (*resexecuteLogout, error) {

	data := map[string]interface{}{
		"header": map[string]interface{}{
			"service": "loginService/executeLogout",
			"_t":      fmt.Sprintf("%d", utils.GetTimeStampEx()),
		},
		"payload": map[string]interface{}{
			"X_LINE": acc.AcctNo, //付款账号
		},
	}

	res := resexecuteLogout{}

	_, err := acc.postHTTPData(&data, &res, true)
	if err != nil {
		logger.Errorf("[PSBC]executeLogout请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}
