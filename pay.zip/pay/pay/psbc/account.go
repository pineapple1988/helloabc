package psbc

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
)

// Account 中国银行帐号
type Account struct {
	Account         string          `json:"account"`
	Password        string          `json:"password"`
	PayPassword     string          `json:"payPassword"`
	Platform        string          `json:"platform"`
	CardNo          string          `json:"cardNo"`
	MobileOperators string          `json:"mobileOperators"`
	ClientID        string          `json:"clientID"`
	TokenID         string          `json:"tokenID"`
	UserID          int             `json:"UserID"`
	HardwareInfo    HardwareInfo    `json:"hardwareInfo"`
	Proxy           utils.ProxyInfo `json:"proxy"`
	http            *http.Client
	jar             *cookiejar.Jar
	AesKey          []byte
	ConversationID  string
	Rs              string
	RandKey         []byte
	PassSM4Key      []byte
	PassSM4IV       []byte
	DeviceSM4Key    []byte
	DeviceSM4IV     []byte

	sm4randKey       string
	loginStatus      int32
	loginPadding     int32
	transferPadding  int32
	loginFailCount   int
	smscodeFailCount int
	AcctNo           string
	CardBookFlag     string
	AcctType         string
	acctCodeNew      string

	transferOrderNo       string
	transferTargetAccount string
	transferTargetName    string
	transferAmount        string
	transferComment       string
	transferBankCode      string
	transferBankName      string
	transferPayeeType     string
	transferBusiType      string
	transferAcctType      string
	transferCardBookFlag  string
	transferAuthType      string
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	WIFIName             string `json:"wifiName"`             // wifi名字
	WIFIMac              string `json:"wifiMac"`              // wifiMac地址
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // 设备的名字
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace string `json:"availableSystemSpace"` // 可用穷疯
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
	OSVersion            string `json:"osVersion"`            // 系统版本
	ScreenH              int    `json:"screenH"`              //屏幕高度
	ScreenW              int    `json:"screenW"`              //屏幕宽度
	ScreenPixel          string `json:"screenPixel"`
}

func (acc *Account) newHardwareInfo(platform string) {
	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.Carrier = utils.NewCarrierName()
	h.CellularIP = utils.NewLocalIPAddress()
	h.OSVersion = utils.GetIPhoneOSVersion()

	h.ScreenPixel = fmt.Sprintf("%d.000000*%d.000000", h.ScreenW*3, h.ScreenH*3)

	if platform == common.PlatformNameIOS {
		h.SystemVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()
		h.AvailableSystemSpace = fmt.Sprintf("%d", 21249343488+utils.RandInt(1000000, 9999999))
		h.TotalSystemSpace = "31989469184"
		h.TotalMemory = "2099249152"
		screenSize := acc.HardwareInfo.ScreenSize
		screenXY := strings.Split(screenSize, "*")

		h.ScreenW, _ = strconv.Atoi(screenXY[0])
		h.ScreenH, _ = strconv.Atoi(screenXY[1])

	} else if platform == common.PlatformNameAndroid {

	}
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[PSBC]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)
			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(psAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(psAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			if acc.ClientID == "" {
				acc.ClientID, _ = utils.NewUUID(true)

				acc.newHardwareInfo(platform)
				acc.save()
			}

			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			//运营商
			if acc.MobileOperators == "" {
				acc.MobileOperators = utils.NewCarrierName()
			}

			return acc, nil
		}

		logger.Errorf("[CBC]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	acc.newHardwareInfo(platform)
	acc.ClientID, _ = utils.NewUUID(true)

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CBC]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(psAccountKey, field)
	if err != nil {
		logger.Errorf("[PSBC]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[PSBC]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[PSBC]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(psAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[PSBC]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	// ts := time.Now().Unix()
	// if id == timerUpdate {
	// 	// acc.checkOnline(ts)
	// }
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCEB, code, reason)
}

func (acc *Account) selectCard(balance *resExecuteLogin) error {
	if balance == nil || len(balance.Result.List) <= 0 {
		return pay.ErrNoHaveCardList
	}

	if acc.CardNo == "" {

		acc.AcctNo = balance.Result.AcctNO
		acc.CardBookFlag = balance.Result.List[0].CardBookFlag
		acc.AcctType = balance.Result.List[0].AccType

		logger.Infof("[PSBC][%+v]未指定银行卡号, 默认选择第一张, 标识: %+v.", acc.Account, acc.AcctNo)
		return nil
	}

	for _, v := range balance.Result.List {
		no := v.AcctNO
		if acc.CardNo == no {
			acc.AcctNo = v.AcctNO
			acc.CardBookFlag = v.CardBookFlag
			acc.AcctType = v.AccType
			logger.Infof("[PSBC][%+v]选定指定银行卡号, 卡号: %+v, 标识: %+v.", acc.Account, acc.CardNo, acc.AcctNo)
			return nil
		}
	}

	logger.Errorf("[PSBC][%+v]没有找到指定的银行卡号: %s.", acc.Account, acc.AcctNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.AcctNo)
}

func (acc *Account) doRelogin() error {
	executelogin, err := acc.executeLogin()
	if err != nil {
		logger.Errorf("[PSBC][%+v]重登录错误: %+v", acc.Account, err)
		return err
	}

	if executelogin.Success == false {
		logger.Errorf("[PSBC][%+v]重登录失败, 信息: %+v.", acc.Account, executelogin.Message)
		if strings.Contains(executelogin.Message, "您的手机号或登录密码输入错误") {
			acc.loginFailCount++
			if acc.loginFailCount >= 3 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[PSBC][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
			}
		}
		return errors.New(executelogin.Message)
	}

	acc.loginFailCount = 0
	logger.Infof("[PSBC][%+v]用户重登录成功.", acc.Account)

	return nil
}

func (acc *Account) onLoginSuccess() {
	acc.loginStatus = pay.LoginStatusSuccess
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypePSBC)
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypePSBC)
}

//Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	switch acc.loginStatus {
	case pay.LoginStatusSuccess:
		logger.Infof("[PSBC][%+v]已在登录状态.", acc.Account)
		return pay.Success((nil))
	}

	if acc.loginPadding != 0 {
		logger.Infof("[PSBC][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}
	atomic.StoreInt32(&acc.loginPadding, 0)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	//代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[PSBC][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}
		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	acc.sm4randKey = utils.NewRandString(16, false)

	executelogin, err := acc.executeLogin()
	if err != nil {
		logger.Errorf("[PSBC][%+v]登录错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if executelogin.Success == false {
		logger.Errorf("[PSBC][%+v]登录失败, 信息: %+v.", acc.Account, executelogin.Message)
		return pay.Error(pay.ErrCodeLoginError, executelogin.Message, nil)
	}

	if err := acc.selectCard(executelogin); err != nil {
		logger.Errorf("[PSBC][%+v]选择银行卡错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	//帐号需要绑定
	if executelogin.Result.BindStatus == 0 {
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypePSBC)
		logger.Infof("[PSBC][%+v]需要进行设备ID绑定.", acc.Account)

		newsmsCode, err := acc.getNewSmsCode()
		if err != nil {
			logger.Errorf("[PSBC][%+v]发送登录验证码错误.", acc.Account)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if newsmsCode.Success == false {
			logger.Errorf("[PSBC][%+v]发送登录验证码失败, 信息: %+v.", acc.Account, newsmsCode.Message)
			return pay.Error(pay.ErrCodeSendCodeError, newsmsCode.Message, nil)
		}

		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	accountQueryShowBal, err := acc.getAccountQueryShowBal()
	if err != nil {
		logger.Errorf("[PSBC][%+v]查询余额错误: %+v", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if accountQueryShowBal.Success == false {
		logger.Errorf("[PSBC][%+v]查询余额失败, 信息: %+v.", acc.Account, accountQueryShowBal.Message)
		return pay.Error(pay.ErrCodeLoginError, accountQueryShowBal.Message, nil)
	}

	acc.acctCodeNew = accountQueryShowBal.Result.AcctCodeNew
	// fmt.Println("==============================================")

	// acc.transferTargetAccount = "6217000610002860807"
	// acc.transferTargetName = "丛建伟"
	// acc.transferAmount = "0.05"
	// acc.transferComment = "试着转"

	// cardBinInfo, err := acc.getCardBinInfo("6217000610002860807")

	// // acc.transferOrderNo = req.OrderNo

	// acc.transferBankCode = cardBinInfo.Result.BankCode
	// acc.transferBankName = cardBinInfo.Result.BankName

	// acc.executeCheckAuthenticationWay()
	// acc.getTransferSmsCode()

	logger.Infof("[CEB][%+v]用户登录成功.", acc.Account)
	acc.save()
	acc.onLoginSuccess()

	// if executelogin.Result.BindStatus == 0 {
	// 	acc.loginStatus = pay.LoginStatusWaitCode
	// 	_, err := acc.getNewSmsCode()
	// 	if err != nil {
	// 		logger.Errorf("[PSBC][%+v]getNewSmsCode获取登录验证码错误: %+v", acc.Account, err)
	// 		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	// 	}
	// }

	// if executelogin.Result.LoginStatus == "0" {
	// 	acc.loginStatus = pay.LoginStatusWaitCode
	// 	_, err := acc.getNewSmsCode()
	// 	if err != nil {
	// 		logger.Errorf("[PSBC][%+v]getNewSmsCode获取登录验证码错误: %+v", acc.Account, err)
	// 		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	// 	}
	// }

	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypePSBC)

	if acc.Proxy.URI != "" {
		pay.ReleaseProxy(acc.Proxy.URI)
		acc.setProxy("", "", "")
	}

	logger.Infof("[PSBC][%+v]退出成功.", acc.Account)

	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[PSBC][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[PSBC][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)
	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus == pay.LoginStatusWaitCode {
		getnewCheckSmsCode, err := acc.getNewCheckSmsCode(code)
		if err != nil {
			logger.Errorf("[PSBC][%+v]校验验证码操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}
		if getnewCheckSmsCode.Success == false {
			logger.Warnf("[PSBC][%+v]]校验登登录验证码失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, getnewCheckSmsCode.Error, getnewCheckSmsCode.Message)
			return pay.Error(pay.ErrCodeLoginError, getnewCheckSmsCode.Message, nil)
		}

		//查询设备是否第一次登录
		firstLoginFlag, err := acc.queryFirstLoginFlag()
		if err != nil {
			logger.Errorf("[PSBC][%+v]查询设备是否第一次登录错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if firstLoginFlag.Success == false {
			logger.Errorf("[PSBC][%+v]查询设备是否第一次登录失败, 代码: %+v.", acc.Account, firstLoginFlag.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, firstLoginFlag.Message, nil)
		}

		if firstLoginFlag.Result.FirstLoginFlag == "1" {

		}

		accountQueryShowBal, err := acc.getAccountQueryShowBal()
		if err != nil {
			logger.Errorf("[PSBC][%+v]查询余额错误: %+v", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if accountQueryShowBal.Success == false {
			logger.Errorf("[PSBC][%+v]查询余额失败, 信息: %+v.", acc.Account, accountQueryShowBal.Message)
			return pay.Error(pay.ErrCodeLoginError, accountQueryShowBal.Message, nil)
		}

		acc.acctCodeNew = accountQueryShowBal.Result.AcctCodeNew

		logger.Infof("[CEB][%+v]用户登录成功.", acc.Account)
		acc.save()
		acc.onLoginSuccess()

	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PSBC][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.getAccountQueryShowBal()
	if err != nil {
		logger.Errorf("[PSBC][%+v]查询余额错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeGetBalanceError, pay.ErrMsgGetBalanceError, nil)
	}

	if balance.Success != true {
		logger.Errorf("[PSBC][%+v]查询余额返回失败, 信息: %+v.", acc.Account, balance.Message)

		// 第一次时尝试重新登录
		if first && strings.Index(balance.Message, "重新登录") != -1 {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[PSBC][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeReloginError, pay.ErrMsgReloginError, nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, balance.Message, nil)
	}

	res := model.AccountBalanceRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data.Amount = balance.Result.AcctAmt
	res.Data.AmountAvailable = balance.Result.UseableAmt

	logger.Infof("[PSBC][%+v]查询余额成功, 余额: %+v, 可用余额: %+v.", acc.Account, balance.Result.AcctAmt, balance.Result.UseableAmt)

	return pay.Success(&res)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PSBC][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

func transTimeToTime(time string) string {

	if len(time) == 14 {
		formattedTime := time[0:4] + "-" + time[4:6] + "-" + time[6:8] + " " + time[8:10] + ":" + time[10:12] + ":" + time[12:14]
		return formattedTime
	}
	return ""
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[PSBC][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 0
	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}

	for {
		transList, err := acc.queryInterTransferDetail(startDate, endDate, page)
		if err != nil {
			logger.Errorf("[PSBC][%+v]查询帐单错误: %+v.", acc.Account, err)

		}
		if transList.Success == false {
			logger.Errorf("[PSBC][%+v]查询帐单失败, 信息: %+v.", transList.Message)
			if transList.Error == "401" {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PSBC][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					return pay.Error(pay.ErrCodeReloginError, pay.ErrMsgReloginError, nil)
				}
				return acc.doBillList(req, false)
			}

			return pay.Error(pay.ErrCodeGetBillListError, transList.Message, nil)
		}

		for _, item := range transList.Result.InterTransferList {

			info := model.AccountBillListInfo{
				TradeNo:      item.InterTransfer.TranSeqno,
				TradeTime:    transTimeToTime(item.InterTransfer.TranTime),
				Amount:       item.InterTransfer.TransAmt,
				AmountRemain: item.InterTransfer.BalanceAmt,
				Comment:      item.InterTransfer.Remark,
			}

			if item.InterTransfer.AccessFlag == "2" {
				// 支出
				info.TradeType = "0"
				info.TargetAccount = item.InterTransfer.InAcctNo
				info.TargetName = item.InterTransfer.InAcctName
				info.TargetBankName = item.InterTransfer.PayBankName
			} else if item.InterTransfer.AccessFlag == "1" {
				// 收入
				info.TradeType = "1"
				info.TargetAccount = item.InterTransfer.InAcctNo
				info.TargetName = item.InterTransfer.InAcctName
				info.TargetBankName = item.InterTransfer.PayBankName
			} else {
				logger.Errorf("[PSBC][%+v]查询帐单出现未知的记帐方式: %+v.", acc.Account, item.InterTransfer.AccessFlag)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.InterTransfer.AccessFlag == "2" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.InterTransfer.AccessFlag == "1" {
					res.Data = append(res.Data, info)
				}
			}
		}

		if transList.Result.Dnum == "10" {
			page += 10
		} else {
			break
		}
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PSBC][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}
	return acc.doBillList(req, true)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if acc.transferPadding != 0 {
		return pay.Error(pay.ErrCodeTransferError, "转帐正在操作中, 请稍候再试", nil)
	}

	acc.transferOrderNo = req.OrderNo
	acc.transferTargetAccount = req.TargetAccount
	acc.transferTargetName = req.TargetName
	acc.transferAmount = req.Amount
	acc.transferComment = req.Comment
	if req.SMSCode == "" {

		logger.Infof("[PSBC][%+v]第一次转账请求, 查询目标银行.", acc.Account)

		cardBinInfo, err := acc.getCardBinInfo(req.TargetAccount)
		if err != nil {
			logger.Errorf("[PSBC][%+v]查询目标银行信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if cardBinInfo.Success == false {
			logger.Errorf("[PSBC][%+v]查询目标银行信息失败, 信息: %+v.", cardBinInfo.Message)
			if cardBinInfo.Error == "401" {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PSBC][%+v]第一次转帐重新登录帐号错误: %+v.", acc.Account, err)
					return pay.Error(pay.ErrCodeReloginError, pay.ErrMsgReloginError, nil)
				}
				return acc.doTransfer(req, false)
			}

			return pay.Error(pay.ErrCodeTransferError, cardBinInfo.Message, nil)

		}

		acc.transferBankCode = cardBinInfo.Result.BankCode
		acc.transferBankName = cardBinInfo.Result.BankName
		//判断是否是同行转账
		if acc.transferBankCode == "403100000004" {
			acc.transferPayeeType = "0" //同行
			acc.transferBusiType = "1"

			//===同行需要用到
			accountType, err := acc.getAccountType()
			if err != nil {
				logger.Errorf("[PSBC][%+v]查询银行类型错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if accountType.Success == false {
				logger.Errorf("[PSBC][%+v]查询银行类型失败, 代码: %+v, 信息: %+v.", acc.Account, accountType.Error, accountType.Message)
				return pay.Error(pay.ErrCodeTransferError, accountType.Message, nil)
			}

			acc.transferAcctType = accountType.Result.AcctType
			acc.transferCardBookFlag = accountType.Result.CardBookFlag
			//===同行需要用到

		} else {
			acc.transferPayeeType = "2" //跨行
			acc.transferBusiType = "3"
		}

		checkAuthenticationWay, err := acc.executeCheckAuthenticationWay()
		if err != nil {
			logger.Errorf("[PSBC][%+v]获取交易认证方式错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgTransferError, nil)
		}

		if checkAuthenticationWay.Success == false {
			logger.Errorf("[PSBC][%+v]获取交易认证方式失败: %+v.", acc.Account, checkAuthenticationWay.Success)
			return pay.Error(pay.ErrCodeTransferError, checkAuthenticationWay.Message, nil)
		}

		acc.transferAuthType = checkAuthenticationWay.Result.AuthList[0]
		transferSmsCode, err := acc.getTransferSmsCode()
		if err != nil {
			logger.Errorf("[PSBC][%+v]发送短信验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, pay.ErrMsgSendCodeError, nil)
		}

		if transferSmsCode.Success == false {
			logger.Errorf("[PSBC][%+v]发送短信验证码失败, 信息: %+v.", acc.Account, transferSmsCode.Message)
			return pay.Error(pay.ErrCodeSendCodeError, transferSmsCode.Message, nil)
		}

		logger.Infof("[PSBC][%+v]发送转帐验证码成功.", acc.Account)
		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	logger.Infof("[PSBC][%+v]第二次转帐请求, 确认交易.", acc.Account)
	eTransfer, body, err := acc.executeTransfer(req.SMSCode)
	if err != nil {
		logger.Errorf("[PSBC][%+v]转账操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgTransferError, nil)
	}

	if eTransfer.Success == false {
		logger.Errorf("[PSBC][%+v]转账操作失败, 代码: %+v 信息: %+v.", acc.Account, eTransfer.Error, eTransfer.Message)
		return pay.Error(pay.ErrCodeTransferError, eTransfer.Message, nil)
	}

	logger.Infof("[PSBC][%+v]转账成功.", acc.Account)
	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData

	transDate := eTransfer.Result.TransDate + " " + eTransfer.Result.TransTime + ":00"
	transDate = strings.ReplaceAll(transDate, "/", "-")

	res.Data.TradeNo = eTransfer.Result.SendBusinessNo
	res.Data.TradeType = "0"
	res.Data.TradeTime = transDate
	res.Data.Amount = eTransfer.Result.TransAmt
	res.Data.AmountRemain = eTransfer.Result.AvailableBanlance
	res.Data.TargetAccount = eTransfer.Result.ProAcctNo
	res.Data.TargetName = eTransfer.Result.ProName
	res.Data.Comment = req.Comment

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypePSBC,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		res.Status)

	logger.LogTransfer("[PSBC][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		res.Data.TargetName,
		res.Data.TargetAccount,
		res.Data.Amount,
		res.Status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)
	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PSBC][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[PSBC][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}
	return acc.doTransfer(req, true)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[PSBC][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PSBC][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}
	return pay.Success(nil)

	// return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.AcctNo = cardNo
}
