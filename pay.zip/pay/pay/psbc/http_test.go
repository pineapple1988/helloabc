package psbc

import (
	"fmt"
	"pay/data/redis"
	"pay/utils/config"
	"pay/utils/logger"
	"testing"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	acc, err := NewAccount("13519018647", "qq121233", "188188", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	acc.Login(100)

	// acc.Login(100)
	// acc.readTif()

	//acc.AesKey = []byte(utils.NewRandString(16, false))
	// acc.loginIn()
	// acc.getPsnLoginForPassword()
	// acc.getToken()
	// acc.psnxGetRandomLoginPre()
	// acc.getImageCode()
	// acc.getPsnUCSendSMS(acc.VerifyCode)
	// acc.getPsnUCloginOrRegForMsg()

	// acc.getPsnUCSendSMS("1111")
	// acc.getPsnUCloginOrRegForMsg()

	// arr := acc.getWatcher()

	// rsakey, _ := acc.getRsaKey()
	// fmt.Println(rsakey)

	// fmt.Println(string(arr))
	// r := acc.Login(20000)
	// if r == nil {
	// 	t.Fatal("尚未实现登录接口.")
	// }

	// if r.Code != 0 {
	// 	t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	// }
}
