package cbc

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"errors"
	"math/big"
	"pay/utils"

	"github.com/tjfoc/gmsm/sm2"
	"github.com/tjfoc/gmsm/sm4"
)

var (
	errWrongDataSize = errors.New("错误的数据大小")
	errWrongIVSize   = errors.New("错误的向量大小")
	errWrongNumber   = errors.New("错误的数值")
	errPKCS7Trimming = errors.New("PKCS7去除填充失败")
)

// PKCS7Padding PKCS7填充
func PKCS7Padding(in []byte, blockSize int) []byte {
	padding := blockSize - len(in)%blockSize
	if padding == 0 {
		padding = blockSize
	}

	buffer := bytes.Repeat([]byte{byte(0)}, padding)
	return append(in, buffer...)
}

// AESCBCEncrypt AESCBC加密, 使用PKCS7填充
func AESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	in = PKCS7Padding(in, c.BlockSize())
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// SM2Encrypt SM2加密
func SM2Encrypt(data []byte, x, y []byte) ([]byte, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()

	pub.X = new(big.Int).SetBytes(x)
	pub.Y = new(big.Int).SetBytes(y)

	//fmt.Printf("%v\n", pub.Curve.IsOnCurve(pub.X, pub.Y)) // 验证是否为sm2的曲线

	data, err := pub.Encrypt(data)
	if err != nil {
		return nil, err
	}

	return data[1:], nil
}

//SM4Decrypt 解密
func SM4Decrypt(data []byte, key []byte) ([]byte, error) {
	c, _ := sm4.NewCipher(key)

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(data); i += c.BlockSize() {
		src := data[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

//SM4ECBEncrypt 加密
func SM4ECBEncrypt(buf, key []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	buf = utils.PKCS7Padding(buf, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(buf); i += c.BlockSize() {
		src := buf[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

// SM4CBCEncrypt SM4CBC加密, 使用PKCS7填充
func SM4CBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	in = utils.PKCS7Padding(in, c.BlockSize())
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// SM4CBCDecrypt SM4CBC解密, 并去除PKCS7填充
func SM4CBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errWrongIVSize
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	out, err = utils.PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}
