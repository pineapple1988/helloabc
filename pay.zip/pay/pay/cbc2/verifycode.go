package cbc

import (
	"fmt"
	"image"
	"image/color"
	"image/jpeg"
	"os"
	"strconv"
)

// LetterAttribute 字母属性
type LetterAttribute struct {
	BeginX          int
	EndX            int
	BeginY          int
	EndY            int
	BlackPixelCount int
}

// CaptchaLetters 验证码字母
type CaptchaLetters struct {
	A LetterAttribute
	B LetterAttribute
	C LetterAttribute
	D LetterAttribute
}

func split(img *image.RGBA, index int) {
	bounds := img.Bounds()
	width := bounds.Dx()
	height := bounds.Dy()

	/*
		for i := 0; i < width; i++ {
			for j := 0; j < height; j++ {
				r, _, _, _ := img.At(i, j).RGBA()
				if r == 65535 {
					fmt.Println("白色")
				} else {
					fmt.Println("黑色")
				}
			}
		}
	*/

	// 先进行纵向遍历，纵向间距超过5则判定为分隔开的字符
	var verticalBlank map[int]bool
	verticalBlank = make(map[int]bool)

	// 纵向一像素是否全部为空白
	for x := 0; x < width; x++ {

		isBlank := true //默认为空白的

		for y := 0; y < height; y++ {
			r, g, b, _ := img.At(x, y).RGBA()
			//fmt.Printf("[X : %d Y : %v] R : %v, G : %v, B : %v, A : %v  \n", x, y, r, g, b, a)

			if r >= 65000 && g >= 65000 && b >= 65000 {
				//pixelCountWhite += 1
			} else {
				//fmt.Printf("[X : %d Y : %v] R : %v, G : %v, B : %v, A : %v  \n", x, y, r, g, b, a)
				isBlank = false
				break
			}
		}

		if isBlank == true {
			verticalBlank[x] = true
		} else {
			verticalBlank[x] = false
		}
	}

	insCaptchaLetters := CaptchaLetters{}

	var lastVerticalIsBlank bool = true
	capturedXCount := 0
	for i := 0; i < width; i++ {
		//fmt.Printf("index: %d, isBlank: %v\n", i, verticalBlank[i])

		if verticalBlank[i] != lastVerticalIsBlank {
			if verticalBlank[i] == true {
				// end
				switch capturedXCount {
				case 1:
					insCaptchaLetters.A.EndX = i - 1
				case 2:
					insCaptchaLetters.B.EndX = i - 1
				case 3:
					insCaptchaLetters.C.EndX = i - 1
				case 4:
					insCaptchaLetters.D.EndX = i - 1
				}

			} else {
				// start
				capturedXCount++

				switch capturedXCount {
				case 1:
					insCaptchaLetters.A.BeginX = i
				case 2:
					insCaptchaLetters.B.BeginX = i
				case 3:
					insCaptchaLetters.C.BeginX = i
				case 4:
					insCaptchaLetters.D.BeginX = i
				}

			}

		}

		lastVerticalIsBlank = verticalBlank[i]

	}

	//fmt.Println(insCaptchaLetters)

	// A
	var ABeignBeginY bool = false
	for y := 0; y < height; y++ {
		for x := insCaptchaLetters.A.BeginX; x < insCaptchaLetters.A.EndX; x++ {
			r, g, b, _ := img.At(x, y).RGBA()

			if r >= 65000 && g >= 65000 && b >= 65000 {
				//pixelCountWhite += 1
			} else {
				if ABeignBeginY == false {
					ABeignBeginY = true
					insCaptchaLetters.A.BeginY = y
				}

				insCaptchaLetters.A.EndY = y

			}
		}
	}

	// B
	var BBeignBeginY bool = false
	for y := 0; y < height; y++ {
		for x := insCaptchaLetters.B.BeginX; x < insCaptchaLetters.B.EndX; x++ {
			r, g, b, _ := img.At(x, y).RGBA()

			if r >= 65000 && g >= 65000 && b >= 65000 {
				//pixelCountWhite += 1
			} else {
				if BBeignBeginY == false {
					BBeignBeginY = true
					insCaptchaLetters.B.BeginY = y
				}

				insCaptchaLetters.B.EndY = y

			}
		}
	}

	// C
	var CBeignBeginY bool = false
	for y := 0; y < height; y++ {
		for x := insCaptchaLetters.C.BeginX; x < insCaptchaLetters.C.EndX; x++ {
			r, g, b, _ := img.At(x, y).RGBA()

			if r >= 65000 && g >= 65000 && b >= 65000 {
				//pixelCountWhite += 1
			} else {
				if CBeignBeginY == false {
					CBeignBeginY = true
					insCaptchaLetters.C.BeginY = y
				}

				insCaptchaLetters.C.EndY = y

			}
		}
	}

	// D
	var DBeignBeginY bool = false
	for y := 0; y < height; y++ {
		for x := insCaptchaLetters.D.BeginX; x < insCaptchaLetters.D.EndX; x++ {
			r, g, b, _ := img.At(x, y).RGBA()

			if r >= 65000 && g >= 65000 && b >= 65000 {
				//pixelCountWhite += 1
			} else {
				if DBeignBeginY == false {
					DBeignBeginY = true
					insCaptchaLetters.D.BeginY = y
				}

				insCaptchaLetters.D.EndY = y

			}
		}
	}

	fmt.Println(insCaptchaLetters)

	newRgbaLetterA := image.NewRGBA(image.Rect(0, 0, insCaptchaLetters.A.EndX-insCaptchaLetters.A.BeginX+1, insCaptchaLetters.A.EndY-insCaptchaLetters.A.BeginY+1))
	for x := insCaptchaLetters.A.BeginX; x <= insCaptchaLetters.A.EndX; x++ {
		for y := insCaptchaLetters.A.BeginY; y <= insCaptchaLetters.A.EndY; y++ {
			colorRgb := img.At(x, y)
			r, g, b, a := colorRgb.RGBA()
			ru := uint8(r >> 8)
			gu := uint8(g >> 8)
			bu := uint8(b >> 8)
			au := uint8(a >> 8)

			i := x - insCaptchaLetters.A.BeginX
			j := y - insCaptchaLetters.A.BeginY
			newRgbaLetterA.SetRGBA(i, j, color.RGBA{ru, gu, bu, au})
		}
	}
	fileA, _ := os.Create("/Users/fish/Desktop/image/code" + strconv.Itoa(index) + "a.jpg") //创建文件
	defer fileA.Close()                                                                     //关闭文件
	jpeg.Encode(fileA, newRgbaLetterA, &jpeg.Options{100})

	newRgbaLetterB := image.NewRGBA(image.Rect(0, 0, insCaptchaLetters.B.EndX-insCaptchaLetters.B.BeginX+1, insCaptchaLetters.B.EndY-insCaptchaLetters.B.BeginY+1))
	for x := insCaptchaLetters.B.BeginX; x <= insCaptchaLetters.B.EndX; x++ {
		for y := insCaptchaLetters.B.BeginY; y <= insCaptchaLetters.B.EndY; y++ {
			colorRgb := img.At(x, y)
			r, g, b, a := colorRgb.RGBA()
			ru := uint8(r >> 8)
			gu := uint8(g >> 8)
			bu := uint8(b >> 8)
			au := uint8(a >> 8)

			i := x - insCaptchaLetters.B.BeginX
			j := y - insCaptchaLetters.B.BeginY
			newRgbaLetterB.SetRGBA(i, j, color.RGBA{ru, gu, bu, au})
		}
	}

	fileB, _ := os.Create("/Users/fish/Desktop/image/code" + strconv.Itoa(index) + "b.jpg") //创建文件
	defer fileB.Close()                                                                     //关闭文件
	jpeg.Encode(fileB, newRgbaLetterB, &jpeg.Options{100})

	newRgbaLetterC := image.NewRGBA(image.Rect(0, 0, insCaptchaLetters.C.EndX-insCaptchaLetters.C.BeginX+1, insCaptchaLetters.C.EndY-insCaptchaLetters.C.BeginY+1))

	for x := insCaptchaLetters.C.BeginX; x <= insCaptchaLetters.C.EndX; x++ {
		for y := insCaptchaLetters.C.BeginY; y <= insCaptchaLetters.C.EndY; y++ {
			colorRgb := img.At(x, y)
			r, g, b, a := colorRgb.RGBA()
			ru := uint8(r >> 8)
			gu := uint8(g >> 8)
			bu := uint8(b >> 8)
			au := uint8(a >> 8)

			i := x - insCaptchaLetters.C.BeginX
			j := y - insCaptchaLetters.C.BeginY
			newRgbaLetterC.SetRGBA(i, j, color.RGBA{ru, gu, bu, au})
		}
	}

	fileC, _ := os.Create("/Users/fish/Desktop/image/code" + strconv.Itoa(index) + "c.jpg") //创建文件
	defer fileC.Close()                                                                     //关闭文件
	jpeg.Encode(fileC, newRgbaLetterC, &jpeg.Options{100})

	newRgbaLetterD := image.NewRGBA(image.Rect(0, 0, insCaptchaLetters.D.EndX-insCaptchaLetters.D.BeginX+1, insCaptchaLetters.D.EndY-insCaptchaLetters.D.BeginY+1))
	for x := insCaptchaLetters.D.BeginX; x <= insCaptchaLetters.D.EndX; x++ {
		for y := insCaptchaLetters.D.BeginY; y <= insCaptchaLetters.D.EndY; y++ {
			colorRgb := img.At(x, y)
			r, g, b, a := colorRgb.RGBA()
			ru := uint8(r >> 8)
			gu := uint8(g >> 8)
			bu := uint8(b >> 8)
			au := uint8(a >> 8)

			i := x - insCaptchaLetters.D.BeginX
			j := y - insCaptchaLetters.D.BeginY
			newRgbaLetterD.SetRGBA(i, j, color.RGBA{ru, gu, bu, au})
		}
	}

	fileD, _ := os.Create("/Users/fish/Desktop/image/code" + strconv.Itoa(index) + "d.jpg") //创建文件
	defer fileD.Close()                                                                     //关闭文件
	jpeg.Encode(fileD, newRgbaLetterD, &jpeg.Options{100})
}

func clearImage(m image.Image) *image.RGBA {
	bounds := m.Bounds()
	dx := bounds.Dx()
	dy := bounds.Dy()
	newRgba := image.NewRGBA(bounds)
	//去杂点
	for i := 0; i < dx; i++ {
		for j := 0; j < dy; j++ {
			colorRgb := m.At(i, j)
			r, g, b, a := colorRgb.RGBA()
			// r = r >> 8
			// g = g >> 8
			// b = b >> 8
			// a = a >> 8
			ru := uint8(r >> 8)
			gu := uint8(g >> 8)
			bu := uint8(b >> 8)
			au := uint8(a >> 8)

			if ru == 128 && gu == 128 && bu == 128 {
				ru = 255
				gu = 255
				bu = 255
				au = 255
			} else if ru == 255 && gu == 255 && bu == 255 {
				ru = 255
				gu = 255
				bu = 255
				au = 255
			} else {
				ru = 0
				gu = 0
				bu = 0
				au = 255
			}

			newRgba.SetRGBA(i, j, color.RGBA{ru, gu, bu, au})
			// fmt.Printf("R=%d, G=%d, B=%d, A=%d\n", r, g, b, a)
		}
	}

	return newRgba
}
