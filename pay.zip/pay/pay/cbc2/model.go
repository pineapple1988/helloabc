package cbc

type hardInfo struct {
	DeviceModel              string  `json:"deviceModel"`
	IsJailBreak              bool    `json:"isJailBreak"`
	BatteryStatus            int     `json:"batteryStatus"`
	Country                  string  `json:"country"`
	CPUCoreNum               int     `json:"cpuCoreNum"`
	BatteryLevel             int     `json:"batteryLevel"`
	WifiMac                  string  `json:"wifiMac"`
	CellIPAddress            string  `json:"cellIPAddress"`
	SystemUpTime             int     `json:"systemUpTime"`
	TimeZone                 string  `json:"timeZone"`
	AppVersion               string  `json:"appVersion"`
	TotalMemory              int     `json:"totalMemory"`
	CarrierOperator          string  `json:"carrierOperator"`
	FreeDiskSpace            float32 `json:"freeDiskSpace"`
	WiFiIPAddress            string  `json:"wiFiIPAddress"`
	DiskSpace                float32 `json:"diskSpace"`
	CarrierMobileNetworkCode string  `json:"carrierMobileNetworkCode"`
	AppID                    string  `json:"appId"`
	CPUFrequency             int     `json:"cpuFrequency"`
	CarrierAllowVoip         bool    `json:"carrierAllowVoip"`
	ScreenH                  int     `json:"screenH"`
	OsVersion                string  `json:"osVersion"`
	InternetType             string  `json:"internetType"`
	WifiName                 string  `json:"wifiName"`
	CarrierIsoCountryCode    string  `json:"carrierIsoCountryCode"`
	ScreenBrightness         float32 `json:"screenBrightness"`
	DeviceType               string  `json:"deviceType"`
	Idfa                     string  `json:"idfa"`
}

type rspHeader struct {
	Msg    string `json:"msg"`
	Status int    `json:"status"`
}

type resToken struct {
	RspHeader rspHeader `json:"rsp_header"`
	RspBody   string    `json:"rsp_body"`
	TokenID   string    `json:"token_id"`
}

type header struct {
	Device     string `json:"device"`
	CipherType string `json:"cipherType"`
	Mac        string `json:"mac"`
	Serial     string `json:"serial"`
	Platform   string `json:"platform"`
	Local      string `json:"local"`
	Ext        string `json:"ext"`
	Version    string `json:"version"`
	Plugins    string `json:"plugins"`
	Page       string `json:"page"`
	Agent      string `json:"agent"`
}

type resPsnxGetRandomLoginPre struct {
	Result struct {
		ConversationID string `json:"conversationId"`
		Rs             string `json:"rs"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Arguments   string `json:"arguments"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnxGetRandom struct {
	Result struct {
		ConversationID string `json:"conversationId"`
		Rs             string `json:"rs"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Arguments   string `json:"arguments"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnUCSendSMS struct {
	Result struct {
		SmcTrigerInterval string `json:"smcTrigerInterval"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Arguments   string `json:"arguments"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnUCloginOrRegForMsg struct {
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

//短信验证码数据
type smsCodeDatas struct {
	TransferSmsCode string `json:"transferSmsCode"`
}

type resPsnLoginForPassword struct {
	Result struct {
		IsMobileGlobal     string `json:"isMobileGlobal"`
		IdentityExpType    string `json:"identityExpType"`
		Regtype            string `json:"regtype"`
		CombinStatus       string `json:"combinStatus"`
		CaMerchID          string `json:"caMerchId"`
		CertUID            string `json:"certUid"`
		DefaultSafety      int    `json:"defaultSafety"`
		SecurityLevel      int    `json:"securityLevel"`
		CustomerID         int    `json:"customerId"`
		CustomerType       string `json:"customerType"`
		CustomerName       string `json:"customerName"`
		IdentityNumber     string `json:"identityNumber"`
		IdentityType       string `json:"identityType"`
		SegmentID          int    `json:"segmentId"`
		Status             string `json:"status"`
		LoginName          string `json:"loginName"`
		CreateDate         string `json:"createDate"`
		LastModify         string `json:"lastModify"`
		LoginSecurityLevel int    `json:"loginSecurityLevel"`
		LoginDate          string `json:"loginDate"`
		LastLogin          string `json:"lastLogin"`
		LoginHint          string `json:"loginHint"`
		LoginStatus        int    `json:"loginStatus"`
		Gender             string `json:"gender"`
		Mobile             string `json:"mobile"`
		Channel            string `json:"channel"`
		CifNumber          string `json:"cifNumber"`
		OperatorID         string `json:"operatorId"`
		PreferredLang      string `json:"preferredLang"`
		IssueCADate        string `json:"issueCADate"`
		ChangePassDate     string `json:"changePassDate"`
		LoginErrorDate     string `json:"loginErrorDate"`
		TotalErrorTimes    string `json:"totalErrorTimes"`
		DailyErrorTimes    string `json:"dailyErrorTimes"`
		LoginIP            string `json:"loginIp"`
		MerchID            string `json:"merchId"`
		TokenID            string `json:"tokenId"`
		IssueTokenDate     string `json:"issueTokenDate"`
		TokenExpireDate    string `json:"tokenExpireDate"`
		SmcMerchID         string `json:"smcMerchId"`
		SmcTokenID         string `json:"smcTokenId"`
		SmcTokenDate       string `json:"smcTokenDate"`
		B2eIP              string `json:"b2eIp"`
		FeeMode            string `json:"feeMode"`
		Name               string `json:"name"`
		UserID             int    `json:"userId"`
		CertExpire         string `json:"certExpire"`
		KeyAlg             string `json:"keyAlg"`
		KeyLength          string `json:"keyLength"`
		HasBindingDevice   string `json:"hasBindingDevice"`
		CurrentDeviceFlag  string `json:"currentDeviceFlag"`
		QryCustType        string `json:"qryCustType"`
		HasRegFingerprint  string `json:"hasRegFingerprint"`
		SimCertUID         string `json:"simCertUid"`
		MobileCertUID      string `json:"mobileCertUid"`
		SotpCertUID        string `json:"sotpCertUid"`
		SoldierTag         string `json:"soldierTag"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnQueryUserLocateAuth struct {
	Result struct {
		IsSign bool `json:"isSign"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnCommonQuerySystemDateTime struct {
	Result struct {
		DateTme string `json:"dateTme"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnCommonQueryAllChinaBankAccount struct {
	Result []struct {
		AccountKey          string `json:"accountKey"`
		Ecard               string `json:"ecard"`
		AccountCatalog      string `json:"accountCatalog"`
		AccountID           int    `json:"accountId"`
		CurrencyCode2       string `json:"currencyCode2"`
		CardDescription     string `json:"cardDescription"`
		HasOldAccountFlag   string `json:"hasOldAccountFlag"`
		AccountName         string `json:"accountName"`
		AccountNumber       string `json:"accountNumber"`
		AccountIbkNum       string `json:"accountIbkNum"`
		AccountType         string `json:"accountType"`
		BranchID            int32  `json:"branchId"`
		NickName            string `json:"nickName"`
		AccountStatus       string `json:"accountStatus"`
		CustomerID          int32  `json:"customerId"`
		CurrencyCode        string `json:"currencyCode"`
		BranchName          string `json:"branchName"`
		CardDescriptionCode string `json:"cardDescriptionCode"`
		IsECashAccount      string `json:"isECashAccount"`
		IsMedicalAccount    string `json:"isMedicalAccount"`
		VerifyFactor        string `json:"verifyFactor"`
		FaceCode            string `json:"faceCode"`
		IsPensionAccount    string `json:"isPensionAccount"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}


type resPsnTransQuotaCharge struct {
	Result struct {
		QuotaAllowAmount string `json:"quotaAllowAmount"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}
type resPsnFinRecMonthBudgetQuery struct {
	Result struct {
		MonthBudget string `json:"monthBudget"`
	} `json:"result"`
	IsException bool `json:"_isException_"`
	Message     string `json:"message"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnMobileIsSignedAgent struct {
	Result struct {
		Flag string `json:"flag"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnQueryBankBranchInfo struct {
	Result struct {
		Bancs      string `json:"bancs"`
		BranchID   string `json:"branchId"`
		BranchName string `json:"branchName"`
		Ibknum     string `json:"ibknum"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnAssetBalanceQuery struct {
	Result struct {
		DepositAmt           string `json:"depositAmt"` //账户余额
		LoanAmt              string `json:"loanAmt"`
		FundAmt              string `json:"fundAmt"`
		TpccAmt              string `json:"tpccAmt"`
		XpadAmt              string `json:"xpadAmt"`
		BondAmt              string `json:"bondAmt"`
		IbasAmt              string `json:"ibasAmt"`
		ActGoldAmt           string `json:"actGoldAmt"`
		CardAmt              string `json:"cardAmt"`
		MetalAmt             string `json:"metalAmt"`
		AumAmt               string `json:"aumAmt"` //账户余额
		StockAmt             string `json:"stockAmt"`
		OtherAmt             string `json:"otherAmt"`
		ForexAmt             string `json:"forexAmt"`
		PltmAmt              string `json:"pltmAmt"`
		PadmAmt              string `json:"padmAmt"`
		JxjAmt               string `json:"jxjAmt"`
		Autd                 string `json:"autd"`
		IccdAmt              string `json:"iccdAmt"`
		MoneyAmt             string `json:"moneyAmt"`
		OtherBankAmt         string `json:"otherBankAmt"`
		CardLoanAmt          string `json:"cardLoanAmt"`
		CreditDep            string `json:"creditDep"`
		OtherBankLoan        string `json:"otherBankLoan"`
		OtherBankDep         string `json:"otherBankDep"`
		DepositFornAmt       string `json:"depositFornAmt"`
		JljAmt               string `json:"jljAmt"`
		CrudeOilAmt          string `json:"crudeOilAmt"`
		XpadGuaranteedAmt    string `json:"xpadGuaranteedAmt"`
		OffBalanceAmt        string `json:"offBalanceAmt"`
		FundFinanceAmt       string `json:"fundFinanceAmt"`
		FundIntelliInvestAmt string `json:"fundIntelliInvestAmt"`
		NewFundAmt           string `json:"newFundAmt"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPSNCreatConversation struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnAccountQueryAccountDetail struct {
	Result struct {
		AccountDetaiList []struct {
			CurrencyCode string `json:"currencyCode"`
			CashRemit string `json:"cashRemit"`
			BookBalance float64 `json:"bookBalance"`
			AvailableBalance float64 `json:"availableBalance"`
			VolumeNumber interface{} `json:"volumeNumber"`
			Type interface{} `json:"type"`
			InterestRate interface{} `json:"interestRate"`
			Status string `json:"status"`
			MonthBalance interface{} `json:"monthBalance"`
			CdNumber interface{} `json:"cdNumber"`
			CdPeriod interface{} `json:"cdPeriod"`
			OpenDate string `json:"openDate"`
			InterestStartsDate interface{} `json:"interestStartsDate"`
			InterestEndDate interface{} `json:"interestEndDate"`
			SettlementDate interface{} `json:"settlementDate"`
			ConvertType interface{} `json:"convertType"`
			PingNo interface{} `json:"pingNo"`
			HoldAmount interface{} `json:"holdAmount"`
			AppointStatus interface{} `json:"appointStatus"`
			SpplType interface{} `json:"spplType"`
			AvailableFund float64 `json:"availableFund"`
			FundsSource interface{} `json:"fundsSource"`
			IsFaceFlag string `json:"isFaceFlag"`
			IsSetDepFlag string `json:"isSetDepFlag"`
			ProductCode interface{} `json:"productCode"`
		} `json:"accountDetaiList"`
		IsPensionFlag string `json:"isPensionFlag"`
		AccOpenDate string `json:"accOpenDate"`
		AccountStatus string `json:"accountStatus"`
		AccountType string `json:"accountType"`
		AccOpenBank string `json:"accOpenBank"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnAccountQueryTransferDetail struct {
	Result struct {
		RecordNumber int `json:"recordNumber"`
		List         []struct {
			TransChnl          string  `json:"transChnl"`
			ChnlDetail         string  `json:"chnlDetail"`
			ChargeBack         bool    `json:"chargeBack"`
			PaymentDate        string  `json:"paymentDate"`
			Currency           string  `json:"currency"`
			CashRemit          string  `json:"cashRemit"`
			Amount             float32 `json:"amount"`  //转出数
			Balance            float32 `json:"balance"` //余额
			BusinessDigest     string  `json:"businessDigest"`
			FurInfo            string  `json:"furInfo"`
			PayeeAccountName   string  `json:"payeeAccountName"`
			PayeeAccountNumber string  `json:"payeeAccountNumber"`
			PaymentTime        string  `json:"paymentTime"`
			RealPaymentDate    string  `json:"realPaymentDate"`
			RealPaymentTime    string  `json:"realPaymentTime"`
		} `json:"List"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnTransPayeeListqueryForDim struct {
	Result struct {
		RecordCount int `json:"recordCount"`
		List        []struct {
			CccountIbkNum string `json:"accountIbkNum"`
			BankCode      string `json:"bankCode"`
			Swift         string `json:"swift"`
			PayeetID      string `json:"payeetId"`
			BankName      string `json:"bankName"`
			AccountName   string `json:"accountName"`
			AccountNumber string `json:"accountNumber"`
			Mobile        string `json:"mobile"`
			PayeeAlias    string `json:"payeeAlias"`
			Address       string `json:"address"`
			BankNum       string `json:"bankNum"`
			CountryCode   string `json:"countryCode"`
			PayBankCode   string `json:"payBankCode"`
			PayBankName   string `json:"payBankName"`
			PayeeCNName   string `json:"payeeCNName"`
			Postcode      string `json:"postcode"`
			RegionCode    string `json:"regionCode"`
			Type          string `json:"type"`
			BocFlag       string `json:"bocFlag"`
			CnapsCode     string `json:"cnapsCode"`
			IsAppointed   string `json:"isAppointed"`
			Score         string `json:"score"`
		} `json:"List"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnTransPayeeRecommend struct {
	Result struct {
		RecordCount int `json:"recordCount"`
		List        []struct {
			AccountIbkNum interface{} `json:"accountIbkNum"`
			BankCode      interface{} `json:"bankCode"`
			Swift         interface{} `json:"swift"`
			PayeetID      int         `json:"payeetId"`
			BankName      string      `json:"bankName"`
			AccountName   string      `json:"accountName"`
			AccountNumber string      `json:"accountNumber"`
			Mobile        interface{} `json:"mobile"`
			PayeeAlias    interface{} `json:"payeeAlias"`
			Address       string      `json:"address"`
			BankNum       interface{} `json:"bankNum"`
			CountryCode   interface{} `json:"countryCode"`
			PayBankCode   string      `json:"payBankCode"`
			PayBankName   string      `json:"payBankName"`
			PayeeCNName   interface{} `json:"payeeCNName"`
			Postcode      interface{} `json:"postcode"`
			RegionCode    interface{} `json:"regionCode"`
			Type          string      `json:"type"`
			BocFlag       string      `json:"bocFlag"`
			CnapsCode     string      `json:"cnapsCode"`
			IsAppointed   string      `json:"isAppointed"`
			Score         float64     `json:"score"`
		} `json:"list"`
	} `json:"result"`
	IsException bool `json:"_isException_"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`
	Message string `json:"message"`
	Code    string `json:"code"`
	Type    string `json:"type"`
}

type resPsnTransQuerySMSCharge struct {
	Result struct {
		SmsCharge string `json:"SmsCharge"`
	}
	ISException bool   `json:"_isException_"`
	Header      header `json:"header"`
}

type resPsnQueryBankInfobyCardBin struct {
	Result struct {
		CnapsCode string `json:"cnapsCode"`
		BankName  string `json:"bankName"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnQryBankInfoByCnaps struct {
	Result struct {
		DreccoName       string      `json:"dreccoName"`
		CnapsCode        string      `json:"cnapsCode"`
		Clscod           string      `json:"clscod"`
		SinglePointCnaps interface{} `json:"singlePointCnaps"`
		BankName         string      `json:"bankName"`
		Drecco           string      `json:"drecco"`
		Bkntyp           string      `json:"bkntyp"`
		BankCode         string      `json:"bankCode"`
	} `json:"result"`
	IsException bool `json:"_isException_"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`
	Message string `json:"message"`
	Code    string `json:"code"`
	Type    string `json:"type"`
}

type resPsnTransQuotaQuery struct {
	Result struct {
		QuotaAmount int `json:"quotaAmount"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnGetSecurityFactor struct {
	Result struct {
		CombinList []struct {
			ID int `json:"id"`
			Name string `json:"name"`
			SafetyFactorList []interface{} `json:"safetyFactorList"`
		} `json:"_combinList"`
		DefaultCombin struct {
			ID int `json:"id"`
			Name string `json:"name"`
			SafetyFactorList []interface{} `json:"safetyFactorList"`
		} `json:"_defaultCombin"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnTransBocTransferVerify struct {
	Result struct {
		ToAccountType string      `json:"toAccountType"`
		PlainData     interface{} `json:"_plainData"`
		FactorList    []struct {
			Field struct {
				Name string `json:"name"`
				Type string `json:"type"`
			} `json:"field"`
		} `json:"factorList"`
		SotpSequenceInt   interface{} `json:"sotpSequenceInt"`
		SmcTrigerInterval string      `json:"smcTrigerInterval"`
		NeedPassword      string      `json:"needPassword"`
		PayeeBankNum      string      `json:"payeeBankNum"`
		CertDN            interface{} `json:"_certDN"`
		SimSequenceInt    interface{} `json:"simSequenceInt"`
	} `json:"result"`
	IsException bool   `json:"_isException_"`
	Message     string `json:"message"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`
}
type resPsnAllAccountsQuery struct {
	Result struct {
		IrrelevantAccountList []struct {
		} `json:"irrelevantAccountList"`
		RelevantAccountList []struct {
			AccountKey          string `json:"accountKey"`
			Ecard               string `json:"ecard"`
			AccountCatalog      string `json:"accountCatalog"`
			AccountID           int    `json:"accountId"`
			CurrencyCode2       string `json:"currencyCode2"`
			CardDescription     string `json:"cardDescription"`
			HasOldAccountFlag   string `json:"hasOldAccountFlag"`
			AccountName         string `json:"accountName"`
			AccountNumber       string `json:"accountNumber"`
			AccountIbkNum       string `json:"accountIbkNum"`
			AccountType         string `json:"accountType"`
			BranchID            int    `json:"branchId"`
			NickName            string `json:"nickName"`
			AccountStatus       string `json:"accountStatus"`
			CustomerID          int    `json:"customerId"`
			CurrencyCode        string `json:"currencyCode"`
			BranchName          string `json:"branchName"`
			CardDescriptionCode string `json:"cardDescriptionCode"`
			IsECashAccount      string `json:"isECashAccount"`
			IsMedicalAccount    string `json:"isMedicalAccount"`
			VerifyFactor        string `json:"verifyFactor"`
			FaceCode            string `json:"faceCode"`
			IsPensionAccount    string `json:"isPensionAccount"`
		} `json:"relevantAccountList"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnEbpsRealTimePaymentConfirm struct {
	Result struct {
		PlainData  interface{} `json:"_plainData"`
		FactorList []struct {
			Field struct {
				Name string `json:"name"`
				Type string `json:"type"`
			} `json:"field"`
		} `json:"factorList"`
		SotpSequenceInt   interface{} `json:"sotpSequenceInt"`
		SmcTrigerInterval string      `json:"smcTrigerInterval"`
		CertDN            interface{} `json:"_certDN"`
		SimSequenceInt    interface{} `json:"simSequenceInt"`
	} `json:"result"`
	Header struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`

	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
}
type resPsnTransGetNationalTransferCommissionCharge struct {
	Result struct {
		PreCommissionCharge  int    `json:"preCommissionCharge"`
		PreSmsNoticeFee      int    `json:"preSmsNoticeFee"`
		NeedSmsNoticeFee     int    `json:"needSmsNoticeFee"`
		PreTransferFee       int    `json:"preTransferFee"`
		NeedTransferFee      int    `json:"needTransferFee"`
		NeedCommissionCharge int    `json:"needCommissionCharge"`
		GetChargeFlag        string `json:"getChargeFlag"`
		RemitSetMealFlag     string `json:"remitSetMealFlag"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPSNGetRandom struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnSvrRegisterDevicePre struct {
	Result struct {
		TransactionID         int `json:"transactionId"`
		FinalCommissionCharge int `json:"finalCommissionCharge"`
		BatSequence           int `json:"batSequence"`

		FactorList []struct {
			Field struct {
				Name string `json:"name"`
				Type string `json:"type"`
			} `json:"field"`
		} `json:"factorList"`
		SotpSequenceInt   string `json:"sotpSequenceInt"`
		SmcTrigerInterval string `json:"smcTrigerInterval"`
		CertDN            string `json:"_certDN"`
		SimSequenceInt    string `json:"simSequenceInt"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnSendSMSCodeToMobile struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPSNGetTokenID struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPSNCreatConversationLoginPre struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnSvrRegisterDeviceSubmit struct {
	Result      string `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnEbpsRealTimePaymentTransfer struct {
	Result struct {
		TransactionID         int64  `json:"transactionId"`
		FinalCommissionCharge float64    `json:"finalCommissionCharge"`
		BatSequence           int64    `json:"batSequence"`
		TransMonStatus        string `json:"transMonStatus"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnSingleTransQueryTransferRecord struct {
	Result struct {
		BatSeq                 string `json:"batSeq"`
		Status                 string `json:"status"`
		PaymentDate            string `json:"paymentDate"`
		PayeeAccountNumber     string `json:"payeeAccountNumber"`
		PayeeAccountName       string `json:"payeeAccountName"`
		PayerAccountNumber     string `json:"payerAccountNumber"`
		FeeCur                 string `json:"feeCur"`
		Amount                 string `json:"amount"`
		Channel                string `json:"channel"`
		TransactionID          string `json:"transactionId"`
		TransferType           string `json:"transferType"`
		ReturnCode             string `json:"returnCode"`
		CommissionCharge       string `json:"commissionCharge"`
		DefaultTimeForRealTime string `json:"defaultTimeForRealTime"`
		WaitTimeForRealTime    string `json:"waitTimeForRealTime"`
		ErrorCode              string `json:"errorCode"`
	} `json:"result"`
	IsException bool `json:"_isException_"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`

	Code    string `json:"code"`
	Type    string `json:"type"`
	Message string `json:"message"`
}

type resPsnQueryTransActivityStatus struct {
	Result struct {
		Amount          string   `json:"amount"`
		OwnerBankID     int      `json:"ownerBankId"`
		ActyURL         string   `json:"actyUrl"`
		CustomerID      int      `json:"customerId"`
		FirstSubmitDate string   `json:"firstSubmitDate"`
		ServiceID       string   `json:"serviceId"`
		ActyList        []string `json:"actyList"`
		CifNumber       string   `json:"cifNumber"`
		OwnerIbkNum     string   `json:"ownerIbkNum"`
		TicketInfo      string   `json:"ticketInfo"`
		ActType         string   `json:"actType"`
	} `json:"result"`
	Message     string `json:"message"`
	ISException bool   `json:"_isException_"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      header `json:"header"`
}

type resPsnTransGetBocTransferCommissionCharge struct {
	Result struct {
		PreCommissionCharge  int    `json:"preCommissionCharge"`
		PreSmsNoticeFee      int    `json:"preSmsNoticeFee"`
		NeedSmsNoticeFee     int    `json:"needSmsNoticeFee"`
		PreTransferFee       int    `json:"preTransferFee"`
		NeedTransferFee      int    `json:"needTransferFee"`
		NeedCommissionCharge int    `json:"needCommissionCharge"`
		GetChargeFlag        string `json:"getChargeFlag"`
		RemitSetMealFlag     string `json:"remitSetMealFlag"`
	} `json:"result"`
	IsException bool   `json:"_isException_"`
	Message     string `json:"message"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`
}

type resPsnTransBocTransferSubmit struct {
	Result struct {
		FromAccountNum        string      `json:"fromAccountNum"`
		FromAccountNickname   string      `json:"fromAccountNickname"`
		FromAccountType       string      `json:"fromAccountType"`
		FromIbkNum            string      `json:"fromIbkNum"`
		Amount                float64     `json:"amount"`
		BatSeq                int64       `json:"batSeq"`
		CommissionCharge      int         `json:"commissionCharge"`
		FinalCommissionCharge float64     `json:"finalCommissionCharge"`
		Currency              string      `json:"currency"`
		Status                string      `json:"status"`
		NeedCount             interface{} `json:"needCount"`
		Postage               float64     `json:"postage"`
		TransactionID         int64       `json:"transactionId"`
	} `json:"result"`
	IsException bool   `json:"_isException_"`
	Message     string `json:"message"`
	Code        string `json:"code"`
	Type        string `json:"type"`
	Header      struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`
}

// TransferResultInfo 转帐结果
type TransferResultInfo struct {
	CreditNO         string `json:"creditNo"`
	OriTransactionSN string `json:"oriTransactionSN"`
	EvtTraceIDEC     string `json:"evtTraceIdEc"`
	RcvPymtPsAccNO   string `json:"rcvPymtPsAccNo"` // 收款卡号
	ChnlCustNO       string `json:"chnlCustNo"`     // 身份证号
	PyPsnAccNO       string `json:"pyPsnAccNo"`     // 卡号
	RmtAmt           string `json:"rmtAmt"`
	DataDic          string `json:"dataDic"`
	TradeNo          string `json:"tradeNo"`
}

type resPsnFinRecQuery struct {
	Result struct {
		MonthSumList []struct {
			Month     string  `json:"month"`
			Direction string  `json:"direction"`
			MonthSum  float64 `json:"monthSum"`
		} `json:"monthSumList"`
		TransInAmount string `json:"transInAmount"`
		RetItems      string `json:"retItems"`
		TotalItems    string `json:"totalItems"`
		List          []struct {
			RecordID        string `json:"recordId"`
			AccountType     string `json:"accountType"`
			AccountNum      string `json:"accountNum"`
			Date            string `json:"date"`
			Time            string `json:"time"`
			Classify        string `json:"classify"`
			ClassifyID      string `json:"classifyId"`
			TransCat        string `json:"transCat"`
			TransMsg        string `json:"transMsg"`
			DebitCreditFlag string `json:"debitCreditFlag"`
			Amount          string `json:"amount"`
			OtherActName    string `json:"otherActName"`
			OtherCardNum    string `json:"otherCardNum"`
			OtherCardType   string `json:"otherCardType"`
			SumFlag         string `json:"sumFlag"`
			TransType       string `json:"transType"`
			MerName         string `json:"merName"`
			TransCurrency   string `json:"transCurrency"`
			TransAmount     string `json:"transAmount"`
		} `json:"list"`
		TransOutAmount string `json:"transOutAmount"`
	} `json:"result"`

	Header struct {
		Device     string `json:"device"`
		CipherType string `json:"cipherType"`
		Mac        string `json:"mac"`
		Serial     string `json:"serial"`
		Platform   string `json:"platform"`
		Local      string `json:"local"`
		Ext        string `json:"ext"`
		Version    string `json:"version"`
		Plugins    string `json:"plugins"`
		Page       string `json:"page"`
		Agent      string `json:"agent"`
	} `json:"header"`

	IsException bool   `json:"_isException_"`
	Message     string `json:"message"`
	Code        string `json:"code"`
	Type        string `json:"type"`
}
