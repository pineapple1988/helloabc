package huaxia5_2_6

const (
	mainUrl              = "https://mobile.hxb.com.cn:446/mgw.htm"
	generateUrl          = "https://ebank.cgbchina.com.cn/dfp/public/generate/post"
	phoneUrl             = "https://phone.abchina.com/nmbap"
	clickUrl             = "https://click.abchina.com/apm"
	bundleShortVersion   = "4.1.0"
	bundleVersion        = "5.0.4.2"

	sm2X                 = "704C1947C010C0F4DD95A9597DCE73CEB900870F804E5CB1E751B20F478BA4B5"
	sm2Y                 = "D521BCB53A75EB8FC249AFC31D08E2E6B978E02A2D4C69B0CE2E9727963D151D"
	appKey               = "0cf637b656843e4f411b80613807309a5907a0e4"
	productVersion       = "1.0.0.190909101115"
	AppId                = "907E920241038"
	productId            = "907E920241038_IOS"
	AppVersion           = "5.2.6"
)


const (
	cbcAccountKey       = "HuaXiaAccount"
	cbcCookieKey        = "HuaXiaCookie"
	cbcTransferInfoKey  = "HuaXiaTransferInfo"
	cbcTransferInfoExprieTime =  12 * 60 * 60 * 1000 // 缓存12小时
	platformIOS         = "ios"
	platformAndroid     = "android"
	timerUpdate         = 1000
	timerUpdateInterval = 1000
	appVersion          = "6.10.4(3.0.0)"
	sdkVersion          = "1.1.6"
	appSequence         = "19320"
	appVersionShort     = "5.2.6"
	userID = "295433053"
	headerXEmpCookie     = "X-Emp-Cookie"
	headerXEmpRedis      = "X-Emp-Redis"
	headerSetEmpRedis    = "Set-Emp-Redis"
	headerXEmpEigenvalue = "X-Emp-Eigenvalue"
	headerXEMPSignature  = "X-EMP-Signature"
	headerXEmpEncrypted  = "X-Emp-Encrypted"
)
