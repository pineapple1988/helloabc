package huaxia5_2_6




type HardwareInfo struct {
	IDFV         string `json:"idfv"`
	Account         string `json:"account"`
	AppCache         string `json:"appCache"`
	AppList         string `json:"appList"`
	AvailableSystem         string `json:"availableSystem"`
	Battery         string `json:"battery"`
	Brightness         string `json:"brightness"`
	Carrier         string `json:"carrier"`
	CellularIP         string `json:"cellularIP"`
	CustID         string `json:"custID"`
	Language         string `json:"language"`
	Model         string `json:"model"`
	NetworkType         string `json:"networkType"`
	Platform          string `json:"platform"`
	ScreenSize         string `json:"screenSize"`
	ScreenHigh         string `json:"screenHigh"`
	SdkVersion         string `json:"sdkVersion"`
	TotalMemory         string `json:"totalMemory"`
	TotalSystem         string `json:"totalSystem"`
	UserAgent         string `json:"userAgent"`
	WIFIName  		 string `json:"wifiName"`
	WIFIMac  	     string `json:"wifiMac"`
}
//DynamicMenuReq
type DynamicMenuReq struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			UNICODE string `json:"UNI_CODE"`
			VERSIONNO string `json:"VERSION_NO"`
			CustMobileToken string `json:"cust_mobile_token"`
			OSTYPE string `json:"OS_TYPE"`
			BUSICODE string `json:"BUSI_CODE"`
			MENUVERSION string `json:"MENU_VERSION"`
			APPVERSION string `json:"APP_VERSION"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type HomePageBankReq struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			HOMEPAGEVERSION string `json:"HOMEPAGE_VERSION"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type SupportReq struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			OsType string `json:"osType"`
			Mac string `json:"mac"`
			DeviceName string `json:"deviceName"`
			DeviceType string `json:"deviceType"`
			DeviceID string `json:"deviceID"`
			Imei string `json:"imei"`
			DeviceAliasName string `json:"deviceAliasName"`
			OsVersion string `json:"osVersion"`
			TransType string `json:"transType"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type GetTimeDifferenceReq struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			//HOMEPAGEVERSION string `json:"HOMEPAGE_VERSION"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type UpdateVersionReq struct {
	ClientID string `json:"clientId"`
	ProductID string `json:"productId"`
	ProductVersion string `json:"productVersion"`
	OsVersion string `json:"osVersion"`
	UserID string `json:"userId"`
	Did string `json:"did"`
	OsType string `json:"osType"`
	NetType string `json:"netType"`
	PrisonBreak int `json:"prisonBreak"`
	MobileBrand string `json:"mobileBrand"`
	MobileModel string `json:"mobileModel"`
	ExtInfos struct {
		PrisonBreakFlag string `json:"prisonBreakFlag"`
	} `json:"extInfos"`
}



type LoginBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			LgnNo string `json:"lgn_no"`
			ClientMac string `json:"client_mac"`
			YLine string `json:"yLine"`
			LocatCountry string `json:"locatCountry"`
			ClientVerNo string `json:"client_ver_no"`
			ClientOs string `json:"client_os"`
			AppVersion string `json:"app_version"`
			LocatCounty string `json:"locatCounty"`
			ClientMacOld string `json:"client_mac_old"`
			LgnPassword string `json:"lgn_password"`
			LocatProvince string `json:"locatProvince"`
			ClientNo string `json:"client_no"`
			IEMI string `json:"IEMI"`
			LgnType string `json:"lgn_type"`
			DeviceModel string `json:"device_model"`
			LocatCity string `json:"locatCity"`
			ClientInfo string `json:"client_info"`
			ClientType string `json:"client_type"`
			ClientIP string `json:"client_ip"`
			LgnTypeValue string `json:"lgn_type_value"`
			XLine string `json:"xLine"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type AutoBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
		} `json:"body"`
	} `json:"_requestBody"`
}

type GetBindNewDeviceBeforeResp struct {
	Head struct {
		HNONCE string `json:"H_NONCE"`
		HMSG string `json:"H_MSG"`
		HTIME string `json:"H_TIME"`
		HRSPSEQ string `json:"H_RSP_SEQ"`
		HTIMEOFFSET string `json:"H_TIME_OFFSET"`
		HCHNLID string `json:"H_CHNL_ID"`
		HRSPTIME string `json:"H_RSP_TIME"`
		HSTATUS string `json:"H_STATUS"`
	} `json:"head"`
	Body struct {
		MSG string `json:"MSG"`
		STATUS string `json:"STATUS"`
		FailTimeCount string `json:"failTimeCount"`
		AccountList []struct {
			AccountNo string `json:"account_no"`
			AccountName string `json:"account_name"`
			AccountType string `json:"account_type"`
			CardToken string `json:"card_token"`
		} `json:"accountList"`
		IsSign string `json:"isSign"`
	} `json:"body"`
}


type  BindCheckUploadSmsBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			Vcode string `json:"vcode"`
		} `json:"body"`
	} `json:"_requestBody"`
}
type CheckStatusBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			CardToken string `json:"card_token"`
			BussType string `json:"buss_type"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type BindCheckDownSmsBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			Password string `json:"password"`
			AccountType string `json:"account_type"`
			Token string `json:"token"`
			Vcode string `json:"vcode"`
			CardToken string `json:"card_token"`
			BindType string `json:"bind_type"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type MonthReceiptBillBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			Year int `json:"year"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type MonthReceiptBillDeatilBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			YearMonth string `json:"year_month"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type QueryReceiptBillBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			PageSize int `json:"page_size"`
			NextKey string `json:"next_key"`
			YearMonth string `json:"year_month"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type GetCardListsAmountBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			Type string `json:"type"`
			TransType string `json:"trans_type"`
		} `json:"body"`
	} `json:"_requestBody"`
}



type GetPayeeListBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			RecName string `json:"rec_name"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type QueryOwnAcctBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			RecAcct string `json:"rec_acct"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type BankListQuery struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			RecAcct string `json:"rec_acct"`
			TransferFlag string `json:"transfer_flag"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type GetCheckTypeBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			TransAmt string `json:"trans_amt"`
			TranType string `json:"tran_type"`
			CardCreateTime string `json:"card_create_time"`
			LocatCountyCode string `json:"locatCountyCode"`
			CreateTime string `json:"create_time"`
			LocatCounty string `json:"locatCounty"`
			Imei string `json:"imei"`
			CardCreateDate string `json:"card_create_date"`
			CardType string `json:"card_type"`
			LocatCityCode string `json:"locatCityCode"`
			RecBankType string `json:"rec_bank_type"`
			AcctBal string `json:"acct_bal"`
			BankCode string `json:"bankCode"`
			LocatCountryCode string `json:"locatCountryCode"`
			RecName string `json:"rec_name"`
			BankName string `json:"bankName"`
			LocatDistrict string `json:"locatDistrict"`
			LocatProvinceCode string `json:"locatProvinceCode"`
			RecAcct string `json:"rec_acct"`
			CardToken string `json:"card_token"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type SendSmsBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			RecName string `json:"rec_name"`
			TransAmt string `json:"trans_amt"`
			RecAcct string `json:"rec_acct"`
			Smsid string `json:"smsid"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type CheckSmsBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HNONCE string `json:"H_NONCE"`
			HTIME string `json:"H_TIME"`
			HCHNLID string `json:"H_CHNL_ID"`
		} `json:"head"`
		Body struct {
			RecAcct string `json:"rec_acct"`
			RecName string `json:"rec_name"`
			TransAmt string `json:"trans_amt"`
			Vcode string `json:"vcode"`
			Smsid string `json:"smsid"`
		} `json:"body"`
	} `json:"_requestBody"`
}


//短信验证码数据
type smsCodeDatas struct {
	TransferSmsCode string `json:"transferSmsCode"`
}

type CrossLineLiquidationBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			TransAmt string `json:"trans_amt"`
			TranType string `json:"tran_type"`
			IsAction string `json:"isAction"`
			AddHigh string `json:"addHigh"`
			AntiFrandTradeNo string `json:"antiFrandTradeNo"`
			AgainTransferFlag string `json:"againTransferFlag"`
			Imei string `json:"imei"`
			CheckFlag string `json:"checkFlag"`
			Smsid string `json:"smsid"`
			LocatCounty string `json:"locatCounty"`
			TransferType string `json:"transfer_type"`
			AdressBankCode string `json:"adressBankCode"`
			CustName string `json:"cust_name"`
			SuggestAction string `json:"suggestAction"`
			UseCloud string `json:"use_cloud"`
			RecBankType string `json:"rec_bank_type"`
			BankCode string `json:"bankCode"`
			AcctNo string `json:"acct_no"`
			Token string `json:"token"`
			RecName string `json:"rec_name"`
			BankName string `json:"bankName"`
			RecMobile string `json:"rec_mobile"`
			Postscript string `json:"postscript"`
			CardBankCode string `json:"cardBankCode"`
			UseAntiFrand string `json:"useAntiFrand"`
			Password string `json:"password"`
			RecAcct string `json:"rec_acct"`
			LocatDistrict string `json:"locatDistrict"`
			CardToken string `json:"card_token"`
		} `json:"body"`
	} `json:"_requestBody"`
}


type QueryRecBankTypeBody struct {
	RequestBody struct {
		Head struct {
			HTIMEOFFSET string `json:"H_TIME_OFFSET"`
			HCHNLID string `json:"H_CHNL_ID"`
			HTIME string `json:"H_TIME"`
			HNONCE string `json:"H_NONCE"`
		} `json:"head"`
		Body struct {
			BankCode string `json:"bank_code"`
		} `json:"body"`
	} `json:"_requestBody"`
}

type GetCardListsAmountResp struct {
	Head struct {
		HNONCE string `json:"H_NONCE"`
		HMSG string `json:"H_MSG"`
		HTIME string `json:"H_TIME"`
		HRSPSEQ string `json:"H_RSP_SEQ"`
		HTIMEOFFSET string `json:"H_TIME_OFFSET"`
		HCHNLID string `json:"H_CHNL_ID"`
		HRSPTIME string `json:"H_RSP_TIME"`
		HSTATUS string `json:"H_STATUS"`
	} `json:"head"`
	Body struct {
		MSG string `json:"MSG"`
		CardLists []struct {
			CardNo string `json:"card_no"`
			OpenBranch string `json:"open_branch"`
			CardAlias string `json:"card_alias"`
			MainSignFlag string `json:"main_sign_flag"`
			RelateAccount string `json:"relate_account"`
			CardType string `json:"card_type"`
			AcctAvaiBal string `json:"acctAvaiBal"`
			Acctlevelflag string `json:"Acctlevelflag"`
			CardToken string `json:"card_token"`
			BinTpye string `json:"bin_tpye"`
			CreateDate string `json:"create_date"`
			CreateTime string `json:"create_time"`
			CardStatus string `json:"CardStatus"`
			CustName string `json:"cust_name"`
			SteadWinAcctAvaiBal string `json:"steadWinAcctAvaiBal"`
			CurrentAcctAvaiBal string `json:"currentAcctAvaiBal"`
		} `json:"cardLists"`
		STATUS string `json:"STATUS"`
	} `json:"body"`
}

type BankListQueryResp struct {
	Head struct {
		HNONCE string `json:"H_NONCE"`
		HMSG string `json:"H_MSG"`
		HTIME string `json:"H_TIME"`
		HRSPSEQ string `json:"H_RSP_SEQ"`
		HTIMEOFFSET string `json:"H_TIME_OFFSET"`
		HCHNLID string `json:"H_CHNL_ID"`
		HRSPTIME string `json:"H_RSP_TIME"`
		HSTATUS string `json:"H_STATUS"`
	} `json:"head"`
	Body struct {
		BankLogoURL string `json:"bankLogoUrl"`
		MSG string `json:"MSG"`
		RecName string `json:"rec_name"`
		PayeeBankAddrssCode string `json:"payee_bank_addrss_code"`
		PayeeBankName string `json:"payee_bank_name"`
		ClearBankList []struct {
			OwnCode string `json:"own_code"`
			BankCode string `json:"bank_code"`
			BranchCode string `json:"branch_code"`
			BankName string `json:"bank_name"`
			AliasName string `json:"alias_name"`
			FirstLetter string `json:"first_letter"`
			RecBankType string `json:"rec_bank_type"`
		} `json:"clearBankList"`
		PayeeBankAddrss string `json:"payee_bank_addrss"`
		AliasName string `json:"alias_name"`
		PayeeType string `json:"payee_type"`
		RemarkOne string `json:"remark_one"`
		ExchangBank string `json:"exchang_bank"`
		RecAcct string `json:"rec_acct"`
		STATUS string `json:"STATUS"`
		HotList []interface{} `json:"hotList"`
		DayLimitAmt string `json:"day_limit_amt"`
		SecretFree string `json:"secret_free"`

	} `json:"body"`
}