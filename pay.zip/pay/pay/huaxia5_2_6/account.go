package huaxia5_2_6

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"payserver/common"
	"strconv"
	"strings"
)

type Account struct {
	MobileNo         string `json:"mobileNo"`
	CardNo           string `json:"cardNo"`
	LoginPwd         string `json:"loginPwd"`
	PayPwd           string `json:"payPwd"`
	UUID             string `json:"uuid"`
	DeviceSerial     string `json:"deviceSerial"`
	DeviceToken      string `json:"deviceToken"`  //Cookie: JSESSIONID/devicetoken/uuid/equipment_id/deviceCode/uuidVal
	Model            string `json:"model"`
	RandomNum        string `json:"randomNum"`
	ClientVersion    string `json:"clientVersion"`
	WholeMenuVersion string `json:"wholeMenuVersion"`
	ActiveState      string `json:"activeState"`
	custMobileToken  string `json:"custMobileToken"`
	HardwareInfo    HardwareInfo    `json:"hardwareInfo"`
	AccountNoSequence           string `json:"accountNoSequence"`
	ClientType            string `json:"clientType"`
	IpAddress            string `json:"ipAddress"`
	AppVersionNo            string `json:"appVersionNo"`
	Version            string `json:"version"`
	SrcSysId            string `json:"srcSysId"`
	TerminalMachinInfo            string `json:"terminalMachinInfo"`
	MobileType            string `json:"mobileType"`  //mediaType
	DeviceOS            string `json:"deviceOS"`
	UTDID            string `json:"utdid"`
	BrandName            string `json:"brandName"`
	VersionNo            string `json:"versionNo"`
	Type            string `json:"type"`
	AppId            string `json:"appId"`
	PackageName      string `json:"packageName"`
	SessionID        string `json:"sessionID"`
	DFP        string `json:"dfp"`
	Random        string `json:"random"`

}

type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	WIFIName             string `json:"wifiName"`             // wifi名字
	WIFIMac              string `json:"wifiMac"`              // wifiMac地址
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // 设备的名字
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace string `json:"availableSystemSpace"` // 可用穷疯
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
	OSVersion            string `json:"osVersion"`            // 系统版本
	ScreenH              int    `json:"screenH"`              //屏幕高度
	ScreenW              int    `json:"screenW"`              //屏幕宽度
	ScreenPixel          string `json:"screenPixel"`
}

func (acc *Account) getUserAgent() string {
	return fmt.Sprintf("HXMobileBank/%s CFNetwork/902.2 Darwin/17.7.0", bundleVersion)
}


func (acc *Account) newHardwareInfo(platform string) {
	acc.Idfa, _ = utils.NewUUID(true)
	acc.Idfv, _ = utils.NewUUID(true)
	acc.ClientID, _ = utils.NewUUID(true)

	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.Carrier = utils.NewCarrierName()
	h.CellularIP = utils.NewLocalIPAddress()
	h.OSVersion = utils.GetIPhoneOSVersion()

	h.ScreenPixel = fmt.Sprintf("%d.000000*%d.000000", h.ScreenW*3, h.ScreenH*3)

	if platform == common.PlatformNameIOS {
		h.SystemVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()
		h.AvailableSystemSpace = fmt.Sprintf("%d", 21249343488+utils.RandInt(1000000, 9999999))
		h.TotalSystemSpace = "31989469184"
		h.TotalMemory = "2099249152"
		screenSize := acc.HardwareInfo.ScreenSize
		screenXY := strings.Split(screenSize, "*")

		h.ScreenW, _ = strconv.Atoi(screenXY[0])
		h.ScreenH, _ = strconv.Atoi(screenXY[1])

	} else if platform == common.PlatformNameAndroid {

	}
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[CBC]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)
			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(cbcAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(cbcAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			//运营商
			if acc.MobileOperators == "" {
				acc.MobileOperators = utils.NewCarrierName()
			}
			return acc, nil
		}

		logger.Errorf("[CBC]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	acc.newHardwareInfo(platform)
	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CBC]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}


func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[CBC]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(cbcAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[CBC]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}


func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(cbcAccountKey, field)
	if err != nil {
		logger.Errorf("[CBC]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[CBC]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	// ts := time.Now().Unix()
	if id == timerUpdate {
		// acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}


// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCBC, code, reason)
}