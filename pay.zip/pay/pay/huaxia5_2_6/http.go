package huaxia5_2_6

import (
	"compress/gzip"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/go-http-utils/headers"
	uuid "github.com/satori/go.uuid"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"pay/tools"
	"pay/tools/log2"
	"strconv"
	"strings"
)


func (acc *Account) postData(u string,path string, header *map[string]string, body interface{}) []byte{
	myUrl, err :=  url.Parse(u)

	if err != nil {
		log2.Errorf("post url.Parse url=%s error=%+v", u, err)
		return nil
	}


	addrs, err := net.LookupHost(myUrl.String())

	if err != nil {
		log2.Errorf("post net.LookupHost url=%s, error=%+v", myUrl.String(), err)
	} else {
		w.ServerIp = append(w.ServerIp, addrs[0])
	}

	var postBody []byte
	switch body.(type) {
	case []byte:
		postBody = body.([]byte)
	case string:
		postBody = []byte(body.(string))
		//fmt.Println(string(postBody))
	}

	postStr := string(postBody)
	req, err := http.NewRequest("POST", myUrl.String() + path, strings.NewReader(postStr))
	if err != nil {
		log2.Errorf("post http.NewRequest url=%s, error=%+v", myUrl.String(), err)
		return nil
	}


	// 添加公共header
	req.Header.Set(headers.UserAgent, w.getUserAgent())
	req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-Hans-KH;q=1, en-KH;q=0.9")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set("DeviceType", "D")
	req.Header.Set("PBClient", "cmbpb-iphone")
	req.Header.Set("ClientVersion", w.Acc.ClientVersion)
	req.Header.Set("SystemVersion", w.Acc.SysVersion)
	req.Header.Set("AID", w.Aid)
	req.Header.Set("SID", w.Sid)

	resp, err := w.Do(req) //发送Http包
	if err != nil {
		log2.Errorf("post w.Do url=%s, error=%+v", myUrl.String(), err)
		return nil
	}


	var reader io.Reader
	reader = resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		if reader, err = gzip.NewReader(resp.Body); err != nil {
			log2.Errorf("post gzip.NewReader url=%s, error=%+v", myUrl.String(), err)
			return nil
		}
	}

	// 全部读出来
	respBody, err := ioutil.ReadAll(reader)
	if err != nil {
		log2.Errorf("post ioutil.ReadAll url=%s, error=%+v", myUrl.String(), err)
		return nil
	}
	renewCert(req)
	_ = resp.Body.Close()


	return []byte(respBody)
}

func (acc *Account) getDynamicMenu(tokon string) string{
	var body []interface{}
	sonBody := &DynamicMenuReq{}
	nowtimesdate, nowtimestampcryp := getNowTimedateAndTimestampcryp()
	hNonce := strings.ToUpper(uuid.NewV4().String()) + nowtimesdate
	sonBody.RequestBody.Head.HCHNLID = "1001"
	sonBody.RequestBody.Head.HTIMEOFFSET = "0"
	sonBody.RequestBody.Head.HTIME = nowtimesdate
	sonBody.RequestBody.Head.HNONCE = hNonce
	sonBody.RequestBody.Body.UNICODE = w.Acc.UTDID
	sonBody.RequestBody.Body.VERSIONNO = AppVersion
	sonBody.RequestBody.Body.APPVERSION = AppVersion
	sonBody.RequestBody.Body.CustMobileToken = tokon //返回登陆的Token，用于二次登陆
	sonBody.RequestBody.Body.OSTYPE = "2"
	sonBody.RequestBody.Body.BUSICODE = "PD061000"
	sonBody.RequestBody.Body.MENUVERSION = ""


	body = append(body,sonBody)
	bitBody, _ := json.Marshal(body)

	strbody := string(bitBody)

	fmt.Println("getDynamicMenu req明文 -> \r\n" + strbody)

	reqBase64 := base64.StdEncoding.EncodeToString(bitBody)
	//获取sign
	sign := getSign("dynamicMenu", reqBase64, nowtimestampcryp)


	//自定义header
	var header map[string]string
	header = make(map[string]string)
	header["Operation-Type"] = "dynamicMenu"
	header["Did"] = w.Acc.UTDID
	header["Ts"] = nowtimestampcryp
	header["Sign"] = sign
	header["UniformGateway"] = "https://mobile.hxb.com.cn:446/mgw.htm"

	resp := w.post(mainUrl, &map[string]string{}, &header, bitBody, true)
	strresp := string(resp)
	fmt.Println("getDynamicMenu resp明文 -> \r\n" + strresp)

	return strresp
}

func getNowTimedateAndTimestampcryp()(string, string){

	nowtimestamp := tools.TimestampEx()                                 //1576939608057
	nowtimestampcryp := C10TO64(nowtimestamp)
	return strconv.FormatInt(nowtimestamp,10), nowtimestampcryp
}


//获取sign计算
func getSign(transCode string, reqBase64 string, ts string)(string){
	Sign := "1d9ddd24cbbd4fa5bd52e7065134f1ac&Operation-Type=" +
		transCode + "&Request-Data=" + reqBase64 + "&Ts=" + ts

	fmt.Println(Sign)
	return MD5([]byte(Sign))
}


