package huaxia5_2_6

import (
	"bytes"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"fmt"
)

//// c10to64  getCrypTimeStamp
func C10TO64(indata int64) string {
	var data []byte = []byte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/")
	indataTemp := indata
	i := 0
	for {
		indata >>= 6;
		i++
		if indata <=0 {
			break
		}
	}
	ret := make([]byte, i)

	for i--; i>=0; i-- {
		ret[i] = data[indataTemp & 0x3f]
		indataTemp >>= 6;
	}
	//fmt.Println("cto10:" + string(ret))
	return string(ret)
}

//整形转换成字节
func IntToBytes(n int) []byte {
	x := int32(n)
	bytesBuffer := bytes.NewBuffer([]byte{})
	binary.Write(bytesBuffer, binary.BigEndian, x)
	return bytesBuffer.Bytes()
}
//字节转换成整形
func BytesToInt(b []byte) int {
	bytesBuffer := bytes.NewBuffer(b)
	var x int32
	binary.Read(bytesBuffer, binary.BigEndian, &x)
	return int(x)
}


func MD5(b []byte) string {
	ctx := md5.New()
	_, err := ctx.Write(b)
	if err != nil {
		return ""
	}

	return fmt.Sprintf("%x", ctx.Sum(nil))
}


// HMACBase64Value 计算hmac值
func hmacBase64Value(in []byte, key string) string {
	h := hmac.New(sha1.New, []byte(key))
	h.Write(in)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}


// HashCode 计算字符串的hashcode
func hashCode(str string) uint32 {
	if str == "" {
		return 0
	}

	b := []byte(str)
	var r uint32
	for i := 0; i < len(b); i++ {
		r = uint32(b[i]) + 31*r
	}
	return r
}


func PKCS5UnPadding(src []byte) []byte {
	length := len(src)
	unpadding := int(src[length-1])
	return src[:(length - unpadding)]
}

func PKCS5Padding(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padtext...)
}