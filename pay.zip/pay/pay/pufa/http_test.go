package pufa

import (
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"pay/data/redis"
	"pay/utils/config"
	"pay/utils/logger"
	"testing"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "aa123456",
	}

	logger.SetDebug()

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	acc, err := NewAccount("13406730934", "848586", "848586", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	r := acc.Login(20000)
	if r == nil {
		t.Fatal("尚未实现登录接口.")
	}

	if r.Code != 0 {
		t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	}
}

func TestDec(t *testing.T) {
	str, err := decResponse(`ffc8458758943ea13k5YYV2zVY/hdaprz2ZUhyeovS5IHD2VwmVdQs18Ec9d19JI06GH7+fK1M1Jc24Jy74BqQj1cySX
rBDNJkMZJfZflDQjt4any2Ne2KoqymKuQkR0qwtE1n8Z11fSyl9aw1X9ddDxQWpAYJQJ/I4Xq7LL
rcEIQFtWkzBIPfwb6JQM53fDA7QbZiMyotBSB/7k8MzDqqTBr6r3l0LSkz31QDGeBFRxywIZAidX
yGGeQqpqKA8rsaf291OFq2zCj4U0F1fQX2Qaau1jqvfP/RvIdreoptlKxR9V09uoKsMl6J5TKVO4
CCLWwLKJhRPWOgBWsxM/8zrZRAoGq6FQ6Apn+5ldOJ1DdSpJ6Wq7gYwTdRFEaaXjQXcj+Rq1261P
u7CpH0rK0p8zSd5UY37UWh31HTu/LIheaosHPaPSbvBcr3Acsp4/Ip8xLdK8OAHbgYcLc1FMjb6H
7aXOHMqhtUfHUtSDdHSJjdBM8EhdoWnCSM71PVDps6B9UHWbIEn/O/cQ`)

	if err != nil {
		t.Fatalf("解密失败: %+v.\n", err)
	}
	t.Log(hex.EncodeToString([]byte(str)))
	t.Log(str)
}

func TestBase64(t *testing.T) {
	arr, err := base64.StdEncoding.DecodeString("hkrGKZFIayy3rfMs1Wg0aDc3Njc1NTcxOTI5MzY5ODk2")
	if err != nil {
		t.Fatal(err)
	}

	fmt.Printf("%x\n%s", arr, string(arr))
}
