package pufa

import (
	"crypto/rc4"
	"crypto/rsa"
	"encoding/base64"
	"errors"
	"fmt"
	"math/big"
	"math/rand"
	"pay/utils"
	"time"
)

func encPassword(pass string, pub *rsa.PublicKey) string {
	k := pub.Size()

	// 随机填充数据
	em := make([]byte, k)
	for i := 0; i < len(em); i++ {
		em[i] = byte(utils.RandIntn(255))
	}

	arr := []byte(pass)
	l := []byte(fmt.Sprintf("%.2d", len(arr)))
	em[0] = l[0]
	em[1] = l[1]

	for i := 0; i < len(arr); i++ {
		em[2+i] = arr[i]
	}

	m := new(big.Int).SetBytes(em)
	c := new(big.Int)
	e := big.NewInt((int64(pub.E)))

	c.Exp(m, e, pub.N)

	return fmt.Sprintf("%x", c.Bytes())
}

func encRequest(data []byte) (string, error) {
	pub, err := utils.PublicKeyFromString(rsaPublicKey, 65537, 16)
	if err != nil {
		return "", err
	}

	arr, err := utils.RSAEncryptPKCS1v15(data, pub)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(arr), nil
}

func encRC4(buf, key []byte) error {
	c, err := rc4.NewCipher(key)
	if err != nil {
		return err
	}

	// 先加密一些字节
	arr := []byte{}
	for i := 0; i < 0x271; i++ {
		arr = append(arr, byte(i))
	}

	c.XORKeyStream(arr, arr)

	// 加密内容
	c.XORKeyStream(buf, buf)

	return nil
}

func decResponse(data string) (string, error) {
	if len(data) < 16 {
		return "", errors.New("错误的解密数据长度")
	}

	key := data[:8]
	iv := data[8:16]
	str := data[16:]

	arr, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		return "", err
	}

	// fmt.Printf("len = %d, %x\n\n", len(arr), arr)
	// for i := 0; i < len(arr); i++ {
	// 	fmt.Printf("0x%x,", arr[i])
	// 	if (i+1)%16 == 0 {
	// 		fmt.Printf("\n")
	// 	}
	// }

	arr, err = utils.DESCBCDecrypt(arr, []byte(key), []byte(iv))
	if err != nil {
		return "", err
	}

	return string(arr), nil
}

func getRandInt(cnt int) string {
	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	s := ""
	for i := 0; i < cnt; i++ {
		s += fmt.Sprintf("%d", rnd.Intn(10))
	}

	return s
}
