package pufa

type geekRollList struct {
	GeekTryurl string `json:"GeekTryurl"`
	Geekurl    string `json:"GeekUrl"`
	GeekType   string `json:"GeekType"`
	GeekLable  string `json:"GeekLable"`
	GeekTitle  string `json:"GeekTitle"`
	GeekID     string `json:"GeekId"`
}

type geekRollListRes struct {
	JSESSIONID   string         `json:"JSESSIONID"`
	ResponseCode string         `json:"ResponseCode"`
	STATUS       string         `json:"STATUS"`
	List         []geekRollList `json:"List"`
	TransSeqNo   string         `json:"TransSeqNo"`
	ResponseMsg  string         `json:"ResponseMsg"`
	TransName    string         `json:"TransName"`
}

type queryRsaInfoRes struct {
	TimeStamp         string `json:"TimeStamp"`
	JSESSIONID        string `json:"JSESSIONID"`
	CoreKeyModulus    string `json:"CoreKeyModulus"`
	NetBankKeyModulus string `json:"NetBankKeyModulus"`
	ResponseCode      string `json:"ResponseCode"`
	STATUS            string `json:"STATUS"`
	TransSeqNo        string `json:"TransSeqNo"`
	ResponseMsg       string `json:"ResponseMsg"`
	TransName         string `json:"TransName"`
}

type commonCardInfo struct {
	AcctKind            string `josn:"AcctKind"`
	DeptID              string `json:"DeptId"`
	NickName            string `json:"NickName"`
	CardClass           string `json:"CardClass"`
	AcctNo              string `json:"AcctNo"`
	WisdomCardStatus    string `json:"WisdomCardStatus"`
	OverdraftStatus     string `json:"OverdraftStatus"`
	AcctType            string `josn:"AcctType"`
	CurrencyType        string `josn:"CurrencyType"`
	BranchID            string `json:"BranchId"`
	SpecialModuleStatus string `josn:"SpecialModuleStatus"`
	SpecialModule       string `json:"SpecialModule"`
	CheckStatus         string `json:"CheckStatus"`
	AcctName            string `json:"AcctName"`
	OtherSysFlag        string `json:"OtherSysFlag"`
	CardType            string `json:"CardType"`
	CanUseBalance       string `json:"CanUseBalance"`
	Currency            string `josn:"Currency"`
	Balance             string `json:"Balance"`
}

type clientLoginRes struct {
	JSessionID              string           `json:"JSESSIONID"`
	Msg                     string           `json:"MSG"`
	ResponseCode            string           `json:"ResponseCode"`
	ResponseMsg             string           `json:"ResponseMsg"`
	Status                  string           `json:"STATUS"`
	TransSeqNo              string           `json:"TransSeqNo"`
	TransName               string           `json:"TransName"`
	WXTAcctNo               string           `json:"WXTAcctNo"`
	UseIdentificationClient bool             `json:"USE_IDENTIFICATION_CLIENT"`
	PersonName              string           `json:"PersonName"`
	UserLevel               string           `json:"UserLevel"`
	IsResident              string           `json:"IsResident"`
	IDDueDate               string           `json:"IdDueDate"`
	SDeptID                 string           `json:"SDeptId"`
	IsEVoucherFlag          string           `json:"IsEVoucherFlag"`
	Birthday                string           `json:"Birthday"`
	Primes                  int              `json:"Primes"`
	DefaultAcctName         string           `json:"DefaultAcctName"`
	IsVip                   string           `json:"IsVip"`
	Sex                     string           `json:"Vip"`
	UserType                string           `json:"UserType"`
	FaceLoginOpenFlag       string           `json:"FaceLoginOpenFlag"`
	PassPort                string           `json:"PassPort"`
	UkeyID                  string           `json:"UkeyId"`
	CommonCardList          []commonCardInfo `json:"COMMONCARDLIST"`
	VoiceTextBtFlag         string           `json:"VoiceTextBtFlag"`
	UkeyFlag                string           `json:"UkeyFlag"`
	MasterID                string           `json:"MasterId"`
	OpenWXFlag              string           `json:"OpenWXFlag"`
	VoiceLoginOpenFlag      string           `json:"VoiceLoginOpenFlag"`
	WXTList                 []interface{}    `json:"WXTLIST"`
	IsSendPwdIn10Mins       string           `json:"IsSendPwdIn10Mins"`
	Email                   string           `json:"Email"`
	IDNo                    string           `json:"IdNo"`
	WXTAcctStatus           string           `json:"WXTAcctStatus"`
	GestureLoginOpenFlag    string           `json:"GestureLoginOpenFlag"`
	GestureFirstOpen        string           `json:"GestureFirstOpen"`
	IsFQUser                string           `json:"IsFQUser"`
	DefaultAcctNo           string           `json:"DefaultAcctNo"`
	ThreeLoginFlag          string           `json:"threeLoginFlag"`
	BaseNum                 int              `json:"BaseNum"`
	LoginWelcome            string           `json:"LoginWelcome"`
	EngName                 string           `json:"EngName"`
	AcctList                []commonCardInfo `json:"AcctList"`
	CreditFlag              string           `json:"CreditFlag"`
	LoginMobileNo           string           `json:"LoginMobileNo"`
	IDType                  string           `json:"IdType"`
	PlatformFlag            string           `json:"PlatformFlag"`
	FaxNo                   string           `json:"FaxNo"`
	IsWxtFlag               string           `json:"IsWxtFlag"`
	ZipCode                 string           `json:"ZipCode"`
	TelephoneNo             string           `json:"TelephoneNo"`
	IsBangDanWhiteList      string           `json:"isBangDanWhiteList"`
	DeviceBindStatus        string           `json:"DeviceBindStatus"`
	AuthenticateType        string           `json:"AuthenticateType"`
	Address                 string           `json:"Address"`
	WXTAcctBalance          string           `json:"WXTAcctBalance"`
	ModifyFlag              string           `json:"ModifyFlag"`
	FingerLoginOpenFlag     string           `json:"FingerLoginOpenFlag"`
}

type sendVoiceCodeRes struct {
	JSessionID    string `json:"JSESSIONID"`
	Msg           string `json:"MSG"`
	ResponseCode  string `json:"ResponseCode"`
	ResponseMsg   string `json:"ResponseMsg"`
	Status        string `json:"STATUS"`
	TransName     string `json:"TransName"`
	TransSeqNo    string `json:"TransSeqNo"`
	IsSuccess     string `json:"IsSuccess"`
	DynamicCodeNo string `json:"DynamicCodeNo"`
}

type voiceCodeLoginRes struct {
	JSessionID   string `json:"JSESSIONID"`
	Msg          string `json:"MSG"`
	ResponseCode string `json:"ResponseCode"`
	ResponseMsg  string `json:"ResponseMsg"`
	Status       string `json:"STATUS"`
	TransName    string `json:"TransName"`
	TransSeqNo   string `json:"TransSeqNo"`
}

type balanceInfo struct {
	Status        string `json:"STATUS"`
	CurrencyNo    string `json:"CurrencyNo"`
	SavingType    string `json:"SavingType"`
	CanUseBalance string `json:"CanUseBalance"`
	Balance       string `json:"Balance"`
	CurrencyType  string `json:"CurrencyType"`
}

type queryBalanceRes struct {
	JSessionID   string        `json:"JSESSIONID"`
	ResponseCode string        `json:"ResponseCode"`
	ResponseMsg  string        `json:"ResponseMsg"`
	Status       string        `json:"STATUS"`
	AcctNo       string        `json:"AcctNo"`
	AcctType     string        `json:"AcctType"`
	TransSeqNo   string        `json:"TransSeqNo"`
	TransName    string        `json:"TransName"`
	List         []balanceInfo `json:"List"`
}

type billInfo struct {
	AuthNo          string `json:"AuthNo"`
	AcctBal         string `json:"AcctBal"`
	TranCnterNm     string `json:"TranCnterNm"`
	DebitFlag       string `json:"DebitFlag"`
	TranCnterAcctNo string `json:"TranCnterAcctNo"`
	TranAmt         string `json:"TranAmt"`
	TranCd          string `json:"TranCd"`
	BusinessID      string `json:"BusinessId"`
	TranDate        string `json:"TranDate1"`
	TranTime        string `json:"TranTime2"`
	Sign            string `json:"Sign"`
	AbstractCode    string `json:"AbstractCode"`
	CnterBankName   string `json:"CnterBankName"`
	RemitFlag       string `json:"RemitFlag"`
	PostScript      string `json:"Postscript"`
}

type queryBillRes struct {
	JSessionID   string     `json:"JSESSIONID"`
	ResponseCode string     `json:"ResponseCode"`
	ResponseMsg  string     `json:"ResponseMsg"`
	Status       string     `json:"STATUS"`
	TransSeqNo   string     `json:"TransSeqNo"`
	TransName    string     `json:"TransName"`
	List         []billInfo `json:"List"`
}

type queryBankByAcctNoRes struct {
	JSessionID       string `json:"JSESSIONID"`
	ResponseCode     string `json:"ResponseCode"`
	ResponseMsg      string `json:"ResponseMsg"`
	Status           string `json:"STATUS"`
	TransSeqNo       string `json:"TransSeqNo"`
	TransName        string `json:"TransName"`
	IsSuperPayeeBank string `json:"IsSuperPayeeBank"`
	BankPaymentLevel string `json:"BankPaymentLevel"`
	BankNo           string `json:"BankNo"`
	BankName         string `json:"BankName"`
	AcctType         string `json:"AcctType"`
}

type querySIMSignStatusRes struct {
	JSessionID   string `json:"JSESSIONID"`
	ResponseCode string `json:"ResponseCode"`
	ResponseMsg  string `json:"ResponseMsg"`
	Status       string `json:"STATUS"`
	TransSeqNo   string `json:"TransSeqNo"`
	TransName    string `json:"TransName"`
	SIMStatus    string `json:"SIMStatus"`
}

type queryUserIsProtonRes struct {
	JSessionID    string `json:"JSESSIONID"`
	ResponseCode  string `json:"ResponseCode"`
	ResponseMsg   string `json:"ResponseMsg"`
	Status        string `json:"STATUS"`
	TransSeqNo    string `json:"TransSeqNo"`
	TransName     string `json:"TransName"`
	UkeyLmtPerDay string `json:"UkeyLmtPerDay"`
	LimitFlag     string `json:"LimtFlag"`
	LDLmtFlag     string `json:"LDLmtFlag"`
	LmtPerDay     string `json:"LmtPerDay"`
}

type queryChargeRes struct {
	JSessionID   string `json:"JSESSIONID"`
	ResponseCode string `json:"ResponseCode"`
	ResponseMsg  string `json:"ResponseMsg"`
	Status       string `json:"STATUS"`
	TransSeqNo   string `json:"TransSeqNo"`
	TransName    string `json:"TransName"`
	Charge       string `json:"Charge"`
}

type sendMobilePasswordRes struct {
	JSessionID   string `json:"JSESSIONID"`
	ResponseCode string `json:"ResponseCode"`
	ResponseMsg  string `json:"ResponseMsg"`
	Status       string `json:"STATUS"`
	TransSeqNo   string `json:"TransSeqNo"`
	TransName    string `json:"TransName"`
}

type transferOutToBankRes struct {
	JSessionID         string `json:"JSESSIONID"`
	ResponseCode       string `json:"ResponseCode"`
	ResponseMsg        string `json:"ResponseMsg"`
	Status             string `json:"STATUS"`
	TransSeqNo         string `json:"TransSeqNo"`
	TransName          string `json:"TransName"`
	BusinessID         string `json:"BusinessId"`
	NetAutoRequestFlag string `json:"NetAutoRequestFlag"`
	PayeeAcctNo        string `json:"PayeeAcctNo"`
	PayeeName          string `json:"PayeeName"`
	Amount             string `json:"Amount"`
}

type queryNetTransferRes struct {
	JSessionID        string `json:"JSESSIONID"`
	ResponseCode      string `json:"ResponseCode"`
	ResponseMsg       string `json:"ResponseMsg"`
	Status            string `json:"STATUS"`
	TransSeqNo        string `json:"TransSeqNo"`
	TransName         string `json:"TransName"`
	TransDate         string `json:"TransDate"`
	TransKind         string `json:"TransKind"`
	PayeeAcct         string `json:"PayeeAcct"`
	PayeeAcctType     string `json:"PayeeAcctType"`
	PayeeBankName     string `json:"PayeeBankName"`
	PayeeBankNo       string `json:"PayeeBankNo"`
	PayeeName         string `json:"PayeeName"`
	AcctNo            string `json:"AcctNo"`
	AcctNoType        string `json:"AcctNoType"`
	PayerAcctNoType   string `json:"PayerAcctNoType"`
	PayerBankName     string `json:"PayerBankName"`
	PayerBankNo       string `json:"PayerBankNo"`
	PayerName         string `json:"PayerName"`
	NetFeeAcct        string `json:"NetFeeAcct"`
	Currency          string `json:"Currency"`
	PayPurpose        string `json:"PayPurpose"`
	Amount            string `json:"Amount"`
	Charge            string `json:"Charge"`
	PostScript        string `json:"PostScript"`
	SignAgreeNo       string `json:"SignAgreeNo"`
	BusinessID        string `json:"BusinessId"`
	BusinessKind      string `json:"BusinessKind"`
	BusinessType      string `json:"BussinessType"`
	NetBusinessStatus string `json:"NetBusinessStatus"`
	ResultMsg         string `json:"ResultMsg"`
}
