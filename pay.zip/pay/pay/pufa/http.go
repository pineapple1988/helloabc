package pufa

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"strings"

	"github.com/go-http-utils/headers"
	jsoniter "github.com/json-iterator/go"
)

func fillHeader(req *http.Request) {
	req.Header.Set(headers.UserAgent, "PNCBank/10.1.8 CFNetwork/978.0.7 Darwin/18.7.0")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set(headers.Accept, "*/*")
	if req.Method == http.MethodPost {
		req.Header.Set(headers.ContentType, "application/json;charset=UTF-8")
	}
}

func (acc *Account) getNetWorkAndDeviceInfo() string {
	str := "'NetWorkType':'" + acc.NetWorkType +
		"','NetWorkName':'" + acc.NetWorkName +
		"','DeviceInfo':'" + acc.DeviceInfo +
		"','DeviceDigest':'" + acc.DeviceDigest + "'"
	return str
}

// func (acc *Account) geekRollList() error {
// 	reqData := `{ "TransId" : "GeekRollList"}||` + acc.getNetWorkAndDeviceInfo()
// 	// fmt.Println(reqData)

// 	url := fmt.Sprintf("%s?registerTransId=GeekRollList&OsType=%s&APP_VERSION=%s",
// 		urlTransservlet, osType, appVersion)

// 	// fmt.Println(url)

// 	req, err := http.NewRequest("POST", url, strings.NewReader(reqData))
// 	if err != nil {
// 		logger.Errorf("[PUFA]geekRollList创建http请求错误: %+v.", err)
// 		return err
// 	}

// 	fillHeader(req)

// 	body, err := utils.DoHTTP(acc.http, req)
// 	if err != nil {
// 		logger.Errorf("[PUFA]geekRollList http操作错误: %+v.", err)
// 		return err
// 	}

// 	res := geekRollListRes{}
// 	if err := json.Unmarshal([]byte(body), &res); err != nil {
// 		logger.Errorf("[PUFA]geekRollList反序列化返回数据错误: %+v.", err)
// 		return err
// 	}

// 	if res.STATUS != "1" {
// 		logger.Errorf("[PUFA]geekRollList返回错误, 代码: %+v, 信息: %+v.", res.ResponseCode, res.ResponseMsg)
// 		return fmt.Errorf("错误代码: %+v, 信息: %+v", res.ResponseCode, res.ResponseMsg)
// 	}

// 	acc.JSESSIONID = res.JSESSIONID

// 	// fmt.Println(body)

// 	return nil
// }

func (acc *Account) encryptPassword(password string) (string, error) {
	// rsa加密密码
	pub, err := utils.PublicKeyFromString(acc.coreKeyModulus, 65537, 16)
	if err != nil {
		return "", err
	}

	pass := encPassword(password, pub)

	// rc4加密密码
	rc4Key := []byte(utils.NewRandString(16, false))
	rc4Buf := []byte(fmt.Sprintf("%s:%s", acc.ts, strings.ToUpper(pass)))
	if err := encRC4(rc4Buf, rc4Key); err != nil {
		return "", err
	}

	// rsa加密rc4 key
	pub, err = utils.PublicKeyFromString(acc.netBankKeyModulus, 65537, 16)
	if err != nil {
		return "", err
	}

	encKey, err := utils.RSAEncryptPKCS1v15(rc4Key, pub)
	if err != nil {
		return "", err
	}
	// 反转
	utils.ReverseSlice(encKey)

	ba := bytes.Buffer{}
	// rc4key 长度
	ba.Write([]byte(fmt.Sprintf("%.8d", len(encKey)+0x0C)))
	// 随机串
	ba.Write([]byte(utils.NewRandString(0x0C, false)))
	// rc4key内容
	ba.Write(encKey)
	// rc4数据长度
	ba.Write([]byte(fmt.Sprintf("%.8d", len(rc4Buf))))
	// rc4数据内容
	ba.Write(rc4Buf)

	return base64.StdEncoding.EncodeToString(ba.Bytes()), nil
}

func (acc *Account) postHTTPData(u string, req, res interface{}, param, deviceinfo bool) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[PUFA][%+v]postHTTPData序列化请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	body := string(arr)
	if deviceinfo {
		body += "||" + acc.getNetWorkAndDeviceInfo()
	}

	body, err = encRequest([]byte(body))
	if err != nil {
		logger.Errorf("[PUFA][%+v]postHTTPData加密请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrEncRequestData
	}

	body += "||" + acc.getNetWorkAndDeviceInfo()
	if param {
		values := url.Values{}
		values.Set("refresh", "0."+getRandInt(16))
		values.Set("OsType", "iphone")
		values.Set("APP_VERSION", appVersion)
		values.Set("timeStamp", fmt.Sprintf("%d", utils.GetTimeStampEx()))
		u += "?" + values.Encode()
	}

	r, err := http.NewRequest("POST", u, strings.NewReader(body))
	if err != nil {
		logger.Errorf("[PUFA][%+v]postHTTPData创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	fillHeader(r)

	body, err = utils.DoHTTP(acc.http, r)
	if err != nil {
		logger.Errorf("[PUFA][%+v]postHTTPData http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}
		return "", pay.ErrOperationError
	}

	// 不是json数据要解密
	if !strings.HasPrefix(body, `{"`) {
		body, err = decResponse(body)
		if err != nil {
			logger.Errorf("[PUFA][%+v]postHTTPData解密响应数据错误: %+v, 数据: %s.", acc.Account, err, body)
			return "", pay.ErrDecRequestData
		}
	}

	logger.Debugf("[PUFA][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, u, string(arr), body)

	sessionTimeout := strings.TrimSpace(body) == "" ||
		strings.Contains(body, `"STATUS":"005"`) ||
		strings.Contains(body, `"STATUS": "005"`) ||
		strings.Contains(body, `"MSG":"SessionTimeout!"`) ||
		strings.Contains(body, `mbk.role.invalid_user`)
	if sessionTimeout {
		logger.Warnf("[PUFA][%+v]登录会话超时.", acc.Account)
		return "", pay.ErrSessionTimeout
	}

	if strings.Contains(body, `"STATUS":"003"`) {
		logger.Warnf("[PUFA][%+v]银行执行交易失败.", acc.Account)
		return "", pay.ErrBankTradeFail
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), res); err != nil {
			logger.Errorf("[PUFA][%+v]postHTTPData反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (acc *Account) queryRSAInfo() (*queryRsaInfoRes, error) {
	req := map[string]interface{}{
		"TransId":      "QueryRSAInfo",
		"QueryRSAName": "",
	}

	res := queryRsaInfoRes{}
	if _, err := acc.postHTTPData(urlloginservlet, &req, &res, false, true); err != nil {
		return nil, err
	}

	if res.STATUS == "1" {
		acc.coreKeyModulus = res.CoreKeyModulus
		acc.netBankKeyModulus = res.NetBankKeyModulus
		acc.ts = res.TimeStamp
	}

	return &res, nil
}

func (acc *Account) clientLogin() (*clientLoginRes, error) {
	pass, err := acc.encryptPassword(acc.getPassword())
	if err != nil {
		logger.Errorf("[PUFA][%+v]clientLogin加密用户密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	req := map[string]interface{}{
		"TransId":        "ClientLogin",
		"MobileNo":       acc.Account,
		"LoginWay":       "1",
		"Password":       pass,
		"ImageCoder":     "",
		"DeviceInfo":     acc.DeviceInfo,
		"DeviceDigest":   acc.DeviceDigest,
		"Platform":       "iPhone",
		"DeviceType":     "0",
		"OS_Version":     acc.SysVersion,
		"APP_Version":    appVersion,
		"IdNo":           "",
		"NewActiveXFlag": "2",
		"SimplePwdFlag":  "0",
		"IdType":         "",
		"NewVersionFlag": "0",
		"Longtitude":     "0.000000",
		"Latitude":       "0.000000",
	}

	res := clientLoginRes{}
	if _, err := acc.postHTTPData(urlloginservlet, &req, &res, false, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) sendVoiceCode() (*sendVoiceCodeRes, error) {
	req := map[string]interface{}{
		"TransId":       "SendVoiceCode",
		"DynamicCodeNo": "",
		"ConveyTerm":    "01",
		"MobileNo":      acc.Account,
		"Channel":       "01",
		"Flag":          "1",
	}

	res := sendVoiceCodeRes{}
	if _, err := acc.postHTTPData(urlloginservlet, &req, &res, false, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) voiceCodeLogin(code string) (*clientLoginRes, error) {
	req := map[string]interface{}{
		"TransId":          "CheckMobilePwd",
		"Platform":         "iPhone",
		"DeviceDigest":     acc.DeviceDigest,
		"AuthenticateType": "1",
		"DeviceType":       "0",
		"MobilePasswd":     code,
		"DeviceInfo":       acc.DeviceInfo,
	}

	res := clientLoginRes{}
	if _, err := acc.postHTTPData(urlloginservlet, &req, &res, false, true); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryBalance() (*queryBalanceRes, error) {
	req := map[string]interface{}{
		"TransId":     "QueryBalance",
		"AcctNo":      acc.acctNo,
		"AcctType":    "1",
		"BeginNumber": "0",
		"QueryNumber": "100",
	}

	res := queryBalanceRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryBillList(startDate, endDate, page string) (*queryBillRes, error) {
	req := map[string]interface{}{
		"TransId":       "PdIdvDmdDepHstryDtlQry",
		"AcctNo":        acc.acctNo,
		"Acctype":       "1",
		"AcctKind":      "0001",
		"CurrencyNo":    "01",
		"CurrencyType":  "0",
		"SpecialType":   "0",
		"QueryNumber":   "10",
		"BeginNumber":   page,
		"BeginDate":     startDate,
		"EndDate":       endDate,
		"CrDtIndicator": "",
		"FundSortOrder": "1",
	}

	res := queryBillRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryBankByAcctNo(acctNo string) (*queryBankByAcctNoRes, error) {
	req := map[string]interface{}{
		"TransId": "QueryBankByAcctNo",
		"AcctNo":  acctNo,
	}

	res := queryBankByAcctNoRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) querySIMSignStatus() (*querySIMSignStatusRes, error) {
	req := map[string]interface{}{
		"TransId":     "QuerySIMSignStatus",
		"QueryFlag":   "1",
		"IsFormTrans": "1",
	}

	res := querySIMSignStatusRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryUserIsProton(amount string) (*queryUserIsProtonRes, error) {
	req := map[string]interface{}{
		"TransId":          "QueryUserIsProton",
		"UserId":           acc.masterID,
		"Amount":           amount,
		"AuthenticateType": "2",
	}

	res := queryUserIsProtonRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryCharge(amount string) (*queryChargeRes, error) {
	req := map[string]interface{}{
		"TransId":   "NetQueryCharge",
		"AcctNo":    acc.acctNo,
		"Amount":    amount,
		"TransType": "EG01",
	}

	res := queryChargeRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) sendMobilePassword(account, name, amount string, sameBank bool) (*sendMobilePasswordRes, error) {
	req := map[string]interface{}{
		"TransId": "SendMobilePwdTransfer",
		//"RemitType":   "04",
		"RemitAcctNo": acc.acctNo,
		"Remitter":    acc.acctName,
		"RemitAmount": amount,
		"PayeeAcctNo": account,
		"PayeeName":   name,
	}

	if sameBank {
		req["RemitType"] = "01"
	} else {
		req["RemitType"] = "04"
	}

	res := sendMobilePasswordRes{}
	if _, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) transferOutToBank(code, canUseBalance string) (*transferOutToBankRes, string, error) {
	pass, err := acc.encryptPassword(acc.getPayPassword())
	if err != nil {

	}

	req := map[string]interface{}{
		//"TransId":      "NetTransferOutToBank",
		"AcctNo":   acc.acctNo,
		"Password": pass,
		//"AcctType":     "1",
		"SimTransNo":   "",
		"CheckSimFlag": "",
		"CmccSignFlag": "N",
		"UkeySigndata": "",
		"PayeeAcctNo":  acc.transferTargetAccount,
		"PayeeName":    acc.transferTargetName,
		//"PayeeBankNo":  acc.transferBankNo,
		"Amount":       acc.transferAmount,
		"MobilePasswd": code,
		"PostScript":   acc.transferComment,
	}

	if acc.transferBankNo == "310290000013" {
		// 行内转帐
		req["TransId"] = "TransferInBank"
		req["PayeeAcctType"] = "1"
		req["CanUseBalance"] = canUseBalance
	} else {
		req["TransId"] = "NetTransferOutToBank"
		req["AcctType"] = "1"
		req["PayeeBankNo"] = acc.transferBankNo
	}

	res := transferOutToBankRes{}
	body, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false)
	if err != nil {
		return nil, "", err
	}

	return &res, body, nil
}

func (acc *Account) queryNetTransfer(businessID string) (*queryNetTransferRes, string, error) {
	req := map[string]interface{}{
		"TransId":    "QueryNetTransferRes",
		"BusinessId": businessID + "type=sshk",
	}

	res := queryNetTransferRes{}
	body, err := acc.postHTTPData(urlTransservlet, &req, &res, true, false)
	if err != nil {
		return nil, "", err
	}

	return &res, body, nil
}
