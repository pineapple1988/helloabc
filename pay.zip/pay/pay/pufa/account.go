package pufa

import (
	"crypto/sha1"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

//Account 浦发银行帐号
type Account struct {
	Account               string          `json:"account"`
	Password              string          `json:"password"`
	PayPassword           string          `json:"payPassword"`
	Platform              string          `json:"platform"`
	CardNo                string          `json:"cardNo"`
	NetWorkType           string          `json:"netWorkType"`
	NetWorkName           string          `json:"netWorkName"`
	DeviceInfo            string          `json:"deviceInfo"`
	DeviceDigest          string          `json:"deviceDigest"`
	SysVersion            string          `json:"sysVersion"`
	Proxy                 utils.ProxyInfo `json:"proxy"`
	http                  *http.Client
	jar                   *cookiejar.Jar
	coreKeyModulus        string
	netBankKeyModulus     string
	ts                    string
	JSESSIONID            string
	acctNo                string
	acctName              string
	masterID              string
	loginStatus           int32
	loginPadding          int32
	lastPing              int64
	transferBankNo        string
	transferAmount        string
	transferOrderNo       string
	transferTargetAccount string
	transferTargetName    string
	transferComment       string
	loginFailCount        int
	smscodeFailCount      int
	payPasswordFailCount  int
}

// NewAccount 浦发银行帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[PUFA]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(paAccountKey, field)

	//没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			//写入成功认为有缓存数据
			if err := redis.HSet(paAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}
		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			return acc, nil
		}

		logger.Errorf("[PUFA]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	udid, _ := utils.NewUUID(true)
	udid = strings.ReplaceAll(udid, "-", "")
	sysVersion := utils.GetIPhoneOSVersion()

	deviceInfo := fmt.Sprintf("%s|iPhone|iPhoneiOS%s", udid, sysVersion)

	str := fmt.Sprintf("iOS%s%s", sysVersion, udid)

	hash := sha1.New()
	hash.Write([]byte(str))
	deviceDigest := fmt.Sprintf("%x", hash.Sum(nil))

	acc := &Account{
		Account:      account,
		Password:     utils.PasswordEncrypt(password),
		PayPassword:  utils.PasswordEncrypt(payPassword),
		Platform:     platform,
		NetWorkType:  "1",
		NetWorkName:  "4g",
		DeviceInfo:   deviceInfo,
		DeviceDigest: deviceDigest,
		SysVersion:   sysVersion,
		Proxy:        utils.ProxyInfo{},
	}

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[PUFA]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(paAccountKey, field)
	if err != nil {
		logger.Errorf("[PUFA]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[PUFA]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[PUFA]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(paAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[PUFA]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypePUFA)
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypePUFA)
	acc.save()
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypePUFA, code, reason)
}

func (acc *Account) checkOnline(ts int64) {
	if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 300 {
		// 检测代理服务器
		if config.IsUseProxy() {
			pi, _ := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
			if pi != nil {
				if acc.setProxy(pi.URI, pi.User, pi.Pass) {
					acc.http = pay.CreateHTTPClient(pi, acc.jar)
				}
			}
		}

		// res, err := acc.queryBalance()
		// if err != nil {
		// 	if err == pay.ErrSessionTimeout {
		// 		acc.doRelogin()
		// 	}
		// 	acc.lastPing = ts
		// 	return
		// }

		// if res.Status == "005" || res.Status == "mbk.null" {
		// 	acc.doRelogin()
		// }

		acc.lastPing = ts
	}
}

func (acc *Account) doRelogin() error {
	if len(acc.getPassword()) != 6 || !isNumber(acc.getPassword()) {
		logger.Errorf("[PUFA][%+v]重登录密码格式不正确, 密码: %s.", acc.Account, acc.getPassword())
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
		return errors.New("登录密码必须为6位数字, 请检查后再试")
	}

	res1, err := acc.queryRSAInfo()
	if err != nil {
		logger.Errorf("[PUFA][%+v]重登录获取RSA信息错误: %+v.", acc.Account, err)
		return err
	}

	if res1.STATUS != "1" {
		logger.Errorf("[PUFA][%+v]重登录获取RSA信息失败, 信息: %+v.", acc.Account, res1.ResponseMsg)
		return errors.New(res1.ResponseMsg)
	}

	res2, err := acc.clientLogin()
	if err != nil {
		logger.Errorf("[PUFA][%+v]重登录错误: %+v.", acc.Account, err)
		return err
	}

	if res2.Status != "1" {
		logger.Errorf("[PUFA][%+v]重登录失败, 信息: %+v.", acc.Account, res2.ResponseMsg)

		// 密码错误
		if res2.Status == "mbk.EGG0042" {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
			acc.loginFailCount++
			if acc.loginFailCount >= 3 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[PUFA][%+v]帐号连续三次登录错误, 临时冻结帐号.", acc.Account)
			}
		}

		if res2.Status == "mbk.7866" {
			acc.loginStatus = pay.LoginStatusNone
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
			logger.Errorf("[PUFA][%+v]登录失败, 密码格式不正确.", acc.Account)

			return errors.New("登录密码必须为6位数字, 请检查后再试")
		}

		if res2.Status == "mbk.validation.login_failed_check" {
			acc.loginStatus = pay.LoginStatusNone
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
			logger.Errorf("[PUFA][%+v]登录失败, 该号码未开通手机银行")

			return errors.New("该号码未开通手机银行")
		}

		if res2.Status == "mbk.validation.resource_access_retry_too_fast" {
			logger.Errorf("[PUFA][%+v]登录失败, 操作过于频繁", acc.Account)
			return errors.New("登录操作过于频繁, 请稍候再试")
		}

		return errors.New(res2.ResponseMsg)
	}

	if res2.DeviceBindStatus == "1" {
		// 帐号被踢
		acc.loginStatus = pay.LoginStatusNone
		pay.AccountKickout(acc.Account, acc.Platform, common.AccountTypePUFA)

		logger.Errorf("[PUFA][%+v]重登录失败, 帐号在其它地方登录.", acc.Account)
		return pay.ErrNeedBindDevice
	}

	acc.loginFailCount = 0

	return nil
}

func (acc *Account) selectCard(res *clientLoginRes) error {
	if res == nil || len(res.CommonCardList) <= 0 {
		return pay.ErrNoHaveCardList
	}

	if acc.CardNo == "" {
		// 没有指定卡号, 默认选择1类卡
		for _, v := range res.CommonCardList {
			if v.AcctType == "1" {
				// 1类优先使用
				acc.acctNo = v.AcctNo
				logger.Infof("[PUFA][%+v]优先使用I类帐号: %+v.", acc.Account, v.AcctNo)
				return nil
			} else if v.AcctType == "U" {
				// 跳过信用卡
				logger.Infof("[PUFA][%+v]跳过信用卡卡号: %+v.", acc.Account, v.AcctNo)
				continue
			} else {
				// 普通卡
				acc.acctNo = v.AcctNo
				logger.Infof("[PUFA][%+v]帐号类型: %+v, 卡号: %+v.", acc.Account, v.AcctType, v.AcctNo)
			}
		}

		// 没有找到可以使用的卡号
		if acc.acctNo == "" {
			logger.Errorf("[PUFA][%+v]该帐号没有找到可用的储蓄卡号.", acc.Account)
			return errors.New("没有找到可用的储蓄卡号, 请检查帐号信息")
		}

		return nil
	}

	for _, v := range res.CommonCardList {
		if v.AcctNo == acc.CardNo {
			acc.acctNo = v.AcctNo
			logger.Infof("[PUFA][%+v]选定指定银行卡号, 卡号: %+v.", acc.Account, acc.acctNo)
			return nil
		}
	}

	logger.Errorf("[PUFA][%+v]没有找到指定的银行卡号: %s.", acc.Account, acc.CardNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.CardNo)
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

func isNumber(str string) bool {
	if _, err := strconv.Atoi(str); err != nil {
		return false
	}

	return true
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	case pay.LoginStatusSuccess:
		logger.Infof("[PUFA][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[PUFA][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[PUFA][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	if len(acc.getPassword()) != 6 || !isNumber(acc.getPassword()) {
		logger.Errorf("[PUFA][%+v]登录密码格式不正确, 密码: %s.", acc.Account, acc.getPassword())
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
		return pay.Error(pay.ErrCodeInvalidIDPWD, "登录密码必须为6位数字, 请检查后再试.", nil)
	}

	res1, err := acc.queryRSAInfo()
	if err != nil {
		logger.Errorf("[PUFA][%+v]获取RSA公钥错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	// 取rsakey出错
	if res1.STATUS != "1" {
		logger.Errorf("[PUFA][%+v]获取RSA公钥返回失败, 代码: %+v, 信息: %+v.", acc.Account, res1.ResponseCode, res1.ResponseMsg)
		return pay.Error(pay.ErrCodeLoginError, res1.ResponseMsg, nil)
	}

	logger.Infof("[PUFA][%+v]获取RSA公钥成功.", acc.Account)

	res2, err := acc.clientLogin()
	if err != nil {
		logger.Errorf("[PUFA][%+v]登录错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	// 登录过程出错
	if res2.Status != "1" {
		pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypePUFA)

		if res2.Status == "mbk.EGG0042" {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)

			logger.Errorf("[PUFA][%+v]登录失败, 帐号或密码错误.", acc.Account)
			return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
		}

		if res2.Status == "mbk.7866" {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
			logger.Errorf("[PUFA][%+v]登录失败, 密码格式不正确.", acc.Account)

			return pay.Error(pay.ErrCodeInvalidIDPWD, "登录密码必须为6位数字, 请检查后再试.", nil)
		}

		if res2.Status == "mbk.validation.login_failed_check" {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypePUFA)
			logger.Errorf("[PUFA][%+v]登录失败, 该号码未开通手机银行")

			return pay.Error(pay.ErrCodeInvalidIDPWD, "该号码未开通手机银行", nil)
		}

		if res2.Status == "mbk.validation.resource_access_retry_too_fast" {
			logger.Errorf("[PUFA][%+v]登录失败, 操作过于频繁", acc.Account)
			return pay.Error(pay.ErrCodeLoginError, "登录操作过于频繁, 请稍候再试", nil)
		}

		logger.Errorf("[PUFA][%+v]登录返回失败, 代码: %+v, 信息: %+v.", acc.Account, res2.ResponseCode, res2.ResponseMsg)
		return pay.Error(pay.ErrCodeLoginError, res2.ResponseMsg, nil)
	}

	if res2.MasterID != "" {
		acc.masterID = res2.MasterID
	}

	// 需要验证码
	if res2.DeviceBindStatus == "1" {
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypePUFA)

		logger.Infof("[PUFA][%+v]需要进行语音验证.", acc.Account)

		return pay.Error(pay.ErrCodeNeedSMSCode, "需要语音验证, 请准备好电话, 然后点击获取验证码", nil)
	}

	if err := acc.selectCard(res2); err != nil {
		logger.Errorf("[PUFA][%+v]选择银行卡错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	// 登录成功
	acc.acctName = res2.PersonName
	acc.onLoginSuccess()
	logger.Infof("[PUFA][%+v]登录成功.", acc.Account)

	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypePUFA)

	logger.Infof("[PUFA][%+v]退出成功.", acc.Account)
	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[PUFA][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[PUFA][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {
		res, err := acc.sendVoiceCode()
		if err != nil {
			logger.Errorf("[PUFA][%+v]发送登录语音验证码错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout {
				acc.loginStatus = pay.LoginStatusNone
				api.ReportAccStateNone(acc.Account, acc.Platform, common.AccountTypePUFA)
			}

			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		// 未登录
		// if res.Status == "005" {
		// 	logger.Errorf("[PUFA][%+v]发送登录语音验证码失败, 登录已过期.", acc.Account)
		// 	return pay.Error(pay.ErrCodeSendCodeError, "登录状态已失效, 请重新登录后获取.", nil)
		// }

		if res.Status != "1" {
			logger.Errorf("[PUFA][%+v]发送登录语音验证码失败, 信息: %+v.", acc.Account, res.ResponseMsg)
			return pay.Error(pay.ErrCodeSendCodeError, res.ResponseMsg, nil)
		}

	} else if acc.loginStatus == pay.LoginStatusSuccess {
		if acc.transferBankNo != "" {
			sameBank := acc.transferBankNo == "310290000013"
			res, err := acc.sendMobilePassword(acc.transferTargetAccount, acc.transferTargetName, acc.transferAmount, sameBank)
			if err != nil {
				logger.Errorf("[PUFA][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeSendCodeError, pay.ErrMsgSendCodeError, nil)
			}

			if res.Status != "1" {
				logger.Errorf("[PUFA][%+v]发送转帐验证码失败, 信息: %+v.", acc.Account, res.ResponseMsg)
				return pay.Error(pay.ErrCodeSendCodeError, res.ResponseMsg, nil)
			}

			logger.Infof("[PUFA][%+v]发送转帐验证码成功.", acc.acctName)
		} else {
			return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
		}
	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus == pay.LoginStatusWaitCode {
		res, err := acc.voiceCodeLogin(code)
		if err != nil {
			logger.Errorf("[PUFA][%+v]验证码登录错误: %+v.", acc.Account, err)
			// 会话失败必须重来
			if err == pay.ErrSessionTimeout {
				acc.loginStatus = pay.LoginStatusNone
				api.ReportAccStateNone(acc.Account, acc.Platform, common.AccountTypePUFA)
				// return pay.Error(pay.ErrCodeSendCodeError, "会话已超时, 请重新执行登录操作", nil)
			}

			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if res.Status != "1" {
			logger.Errorf("[PUFA][%+v]验证码登录失败, 信息: %+v.", acc.Account, res.ResponseMsg)

			if res.Status == "mbk.validation.mobilepwd.error" {
				acc.smscodeFailCount++
				if acc.smscodeFailCount >= 3 {
					acc.smscodeFailCount = 0
					acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
					logger.Errorf("[PUFA][%+v]登录连续验证码错误, 临时冻结帐号.", acc.Account)
				}
			}

			return pay.Error(pay.ErrCodeSMSCodeError, res.ResponseMsg, nil)
		}

		// 登录成功
		acc.smscodeFailCount = 0
		acc.acctName = res.PersonName
		if res.MasterID != "" {
			acc.masterID = res.MasterID
		}

		if err := acc.selectCard(res); err != nil {
			logger.Errorf("[PUFA][%+v]选择银行卡错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()
		logger.Infof("[PUFA][%+v]验证码登录成功.", acc.Account)

	} else if acc.loginStatus == pay.LoginStatusSuccess {

	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PUFA][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.queryBalance()
	if err != nil {
		logger.Errorf("[PUFA][%+v]查询余额错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[PUFA][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.Status != "1" {
		logger.Errorf("[PUFA][%+v]查询余额失败, 信息: %+v.", acc.Account, balance.ResponseMsg)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.ResponseMsg, nil)
	}

	res := model.AccountBalanceRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data.Amount = balance.List[0].Balance
	res.Data.AmountAvailable = balance.List[0].CanUseBalance

	logger.Infof("[PUFA][%+v]查询余额成功, 余额: %+v, 可用余额: %+v", acc.Account, res.Data.Amount, res.Data.AmountAvailable)

	return pay.Success(&res)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Errorf("[PUFA][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// datetimeConver 把yyyyMMddhhmmss转换成yyyy-MM-dd hh:mm:ss
func datetimeConver(dt string) string {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return dt
	}

	return time.Unix(tmp.Unix(), 0).Format("2006-01-02 15:04:05")
}

// dateTimeToUnix时间字符串转成unix时间戳
func dateTimeToUnix(dt string) int {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return 0
	}

	return int(tmp.Unix())
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[PUFA][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 0

	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}

	for {
		billList, err := acc.queryBillList(startDate, endDate, fmt.Sprintf("%d", page*10))
		if err != nil {
			logger.Errorf("[PUFA][%+v]查询帐单错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PUFA][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
				}

				return acc.doBillList(req, false)
			}

			return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
		}

		// 状态不对
		if billList.Status != "1" {
			if page == 0 {
				logger.Errorf("[PUFA][%+v]查询帐单失败, 信息: %+v.", acc.Account, billList.ResponseMsg)
				if billList.ResponseCode == "EGG0056" || strings.Contains(billList.ResponseMsg, "存在[0]条记录") {
					// 记录为空, 认为成功, 返回空列表
					return pay.Success(&res)
				}

				return pay.Error(pay.ErrCodeGetBillListError, billList.ResponseMsg, nil)
			}

			break
		}

		exit := false
		for _, item := range billList.List {
			// 时间查询判断条件
			if req.TimeType == common.TimeTypeByTime {
				ts := dateTimeToUnix(fmt.Sprintf("%s%s", item.TranDate, item.TranTime))
				if ts == 0 || ts > req.EndTime {
					continue
				}

				if ts < req.StartTime {
					exit = true
					break
				}
			}

			info := model.AccountBillListInfo{
				TradeNo:        item.BusinessID,
				TradeTime:      datetimeConver(fmt.Sprintf("%s%s", item.TranDate, item.TranTime)),
				Amount:         item.TranAmt,
				AmountRemain:   item.AcctBal,
				TargetAccount:  item.TranCnterAcctNo,
				TargetName:     item.TranCnterNm,
				TargetBankName: item.CnterBankName,
				Comment:        item.PostScript,
			}

			if item.Sign == "-" {
				info.TradeType = "0"
			} else if item.Sign == "+" {
				info.TradeType = "1"
			} else {
				logger.Errorf("[PUFA][%+v]查询帐单出现未知的记帐方式: %+v.", acc.Account, item.Sign)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.Sign == "+" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.Sign == "-" {
					res.Data = append(res.Data, info)
				}
			}
		}

		if exit {
			break
		}

		// 不够一页了
		if len(billList.List) < 10 {
			break
		}

		page++

		if page > 20 {
			break
		}
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PUFA][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBillList(req, true)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if req.SMSCode == "" {
		bankInfo, err := acc.queryBankByAcctNo(req.TargetAccount)
		if err != nil {
			logger.Errorf("[PUFA][%+v]查询目标帐号银行信息错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[PUFA][%+v]转帐重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if bankInfo.Status != "1" {
			logger.Errorf("[PUFA][%+v]查询目标银行信息失败, 信息: %+v.", acc.Account, bankInfo.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, bankInfo.ResponseMsg, nil)
		}

		bankCode := ""
		bankNo := ""
		bankName := ""
		if bankInfo.BankNo != "" {
			bankCode = bankInfo.BankPaymentLevel
			bankNo = bankInfo.BankNo
			bankName = bankInfo.BankName
		} else if req.BankName != "" {
			res, err := api.NodeQueryBankInfo(req.BankName)
			if err != nil {
				bankName = req.BankName
			} else {
				bankCode = res.BankCode
				bankNo = res.BankNo
				bankName = res.BankName
			}
		}

		// 还是没有查出目标银行则认为不能转帐
		if bankCode == "" || bankNo == "" {
			logger.Warnf("[PUFA][%+v]查询到暂不支持的银行, 卡号: %+v, 银行名字: %+v, BankCode: %+v, BankNo: %+v.",
				acc.Account, req.TargetAccount, bankName, bankCode, bankNo)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		signStatus, err := acc.querySIMSignStatus()
		if err != nil {
			logger.Errorf("[PUFA][%+v]查询SIMSign状态错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if signStatus.Status != "1" {
			logger.Errorf("[PUFA][%+v]查询SIMSign状态失败, 信息: %+v.", acc.Account, signStatus.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, signStatus.ResponseMsg, nil)
		}

		protonInfo, err := acc.queryUserIsProton(req.Amount)
		if err != nil {
			logger.Errorf("[PUFA][%+v]查询用户限额信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if protonInfo.Status != "1" {
			logger.Errorf("[PUFA][%+v]查询用户限额信息失败, 信息: %+v.", acc.Account, protonInfo.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, protonInfo.ResponseMsg, nil)
		}

		chargeInfo, err := acc.queryCharge(req.Amount)
		if err != nil {
			logger.Errorf("[PUFA][%+v]查询转帐费率信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if chargeInfo.Status != "1" {
			logger.Errorf("[PUFA][%+v]查询转帐费率信息失败, 信息: %+v.", acc.Account, chargeInfo.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, chargeInfo.ResponseMsg, nil)
		}

		sameBank := bankNo == "310290000013"
		sendCode, err := acc.sendMobilePassword(req.TargetAccount, req.TargetName, req.Amount, sameBank)
		if err != nil {
			logger.Errorf("[PUFA][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if sendCode.Status != "1" {
			logger.Errorf("[PUFA][%+v]发送转帐验证码失败, 信息: %+v.", acc.Account, sendCode.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, sendCode.ResponseMsg, nil)
		}

		acc.transferBankNo = bankNo
		acc.transferAmount = req.Amount
		acc.transferOrderNo = req.OrderNo
		acc.transferTargetAccount = req.TargetAccount
		acc.transferTargetName = req.TargetName
		acc.transferComment = req.Comment

		logger.Infof("[PUFA][%+v]发送转帐验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	if acc.transferBankNo == "" || acc.transferTargetAccount == "" {
		logger.Warnf("[PUFA][%+v]尚未生成支付订单.", acc.Account)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrNotCreateOrderNo.Error(), nil)
	}

	transferBankNo := acc.transferBankNo

	rsaInfo, err := acc.queryRSAInfo()
	if err != nil {
		logger.Errorf("[PUFA][%+v]获取加密密钥错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if rsaInfo.STATUS != "1" {
		logger.Errorf("[PUFA][%+v]获取加密密钥失败, 信息: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, rsaInfo.ResponseMsg, nil)
	}

	canUseBalance := ""
	if transferBankNo == "310290000013" {
		balance, err := acc.queryBalance()
		if err != nil {
			logger.Errorf("[PUFA][%+v]行内转帐查询余额错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if balance.Status != "1" {
			logger.Errorf("[PUFA][%+v]行内转帐查询余额失败: %+v.", acc.Account, balance.ResponseMsg)
			return pay.Error(pay.ErrCodeTransferError, balance.ResponseMsg, nil)
		}

		canUseBalance = balance.List[0].CanUseBalance
	}

	transfer, body, err := acc.transferOutToBank(req.SMSCode, canUseBalance)
	if err != nil {
		logger.Errorf("[PUFA][%+v]确认转帐操作错误: %+v.", acc.Account, err)
		if err == pay.ErrOperationTimeout {
			return pay.Error(pay.ErrCodeTransferStatusUnknow, pay.ErrMsgTransferStatusUnknow, nil)
		}

		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if transfer.Status != "1" {
		logger.Errorf("[PUFA][%+v]确认转帐失败, 信息: %+v.", acc.Account, transfer.ResponseMsg)

		// 验证码错误
		if transfer.Status == "mbk.validation.mobilepwd.error" {
			acc.smscodeFailCount++
			if acc.smscodeFailCount >= 3 {
				acc.smscodeFailCount = 0
				acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
				logger.Errorf("[PUFA][%+v]转帐连续验证码错误, 临时冻结帐号.", acc.Account)
			}
		}

		// 支付密码错误
		if strings.Contains(transfer.Status, "EGG0391") {
			acc.payPasswordFailCount++
			if acc.payPasswordFailCount >= 3 {
				acc.payPasswordFailCount = 0
				acc.freeze(pay.FreezeCodePayPasswordError, pay.FreezeMsgPayPasswordError)
				logger.Errorf("[PUFA][%+v]转帐连续支付密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		// 风控 ??
		// EGG0014 => 主帐户状态不正常（EGG0014）
		// EGG0998 => 无法进行交易,详情请洽柜面或95528
		if strings.Contains(transfer.Status, "EGG0014") || strings.Contains(transfer.Status, "EGG0998") {
			acc.freeze(pay.FreezeCodeCardError, transfer.ResponseMsg)
			return pay.Error(pay.ErrCodeCardBlock, transfer.ResponseMsg, nil)
		}

		return pay.Error(pay.ErrCodeTransferError, transfer.ResponseMsg, nil)
	}

	acc.smscodeFailCount = 0
	acc.payPasswordFailCount = 0
	acc.transferBankNo = ""
	acc.transferTargetAccount = ""
	logger.Infof("[PUFA][%+v]确认转帐返回, SeqNo: %+v, 业务Id: %+v.", acc.Account, transfer.TransSeqNo, transfer.BusinessID)

	var queryTransfer *queryNetTransferRes

	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData

	res.Data.TradeType = "0"
	res.Data.AmountRemain = "未知"

	status := common.TransferStatusProcessing
	if transferBankNo == "310290000013" {
		// 行内转帐到这一步就直接成功
		res.Status = common.TransferStatusSuccess
		res.Data.TradeNo = transfer.TransSeqNo
		res.Data.Amount = transfer.Amount
		res.Data.TargetAccount = transfer.PayeeAcctNo
		res.Data.TargetName = transfer.PayeeName
		res.Data.TargetBankName = "上海浦东发展银行"
		res.Data.Comment = req.Comment
	} else {
		for i := 0; i < 5; i++ {
			time.Sleep(time.Second * 2)
			queryTransfer, body, err = acc.queryNetTransfer(transfer.BusinessID)
			if err != nil {
				logger.Errorf("[PUFA][%+v]查询转帐状态错误, 流水号: %+v, 错误: %+v.", acc.Account, transfer.BusinessID, err)
				continue
			}

			if queryTransfer.Status != "1" {
				logger.Errorf("[PUFA][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.", acc.Account, transfer.BusinessID, queryTransfer.ResponseMsg)
				return pay.Error(pay.ErrCodeTransferError, queryTransfer.ResponseMsg, nil)
			}

			if queryTransfer.NetBusinessStatus == "0" {
				status = common.TransferStatusFail
				logger.Infof("[PUFA][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.", acc.Account, transfer.BusinessID, queryTransfer.ResultMsg)
				return pay.Error(pay.ErrCodeTransferError, queryTransfer.ResultMsg, nil)
			}

			if queryTransfer.NetBusinessStatus == "1" {
				status = common.TransferStatusSuccess
				logger.Infof("[PUFA][%+v]查询转帐状态成功, 流水号: %+v, 信息: %+v.", acc.Account, transfer.BusinessID, queryTransfer.ResultMsg)
				break
			}

			if queryTransfer.NetBusinessStatus == "3" {
				logger.Infof("[PUFA][%+v]查询转帐状态尚未确认, 流水号: %+v.", acc.Account, transfer.BusinessID)
				continue
			}

			logger.Warnf("[PUFA][%+v]未知转帐状态, 流水号: %+v, 代码: %+v, 状态: %+v, 信息: %+v.", acc.Account, transfer.BusinessID, queryTransfer.NetBusinessStatus, queryTransfer.ResultMsg)
		}

		res.Status = status
		res.Data.TradeNo = transfer.BusinessID
		res.Data.Amount = queryTransfer.Amount
		res.Data.TargetAccount = queryTransfer.PayeeAcct
		res.Data.TargetName = queryTransfer.PayeeName
		res.Data.TargetBankName = queryTransfer.PayeeBankName
		res.Data.Comment = queryTransfer.PostScript

		if status == common.TransferStatusProcessing {
			res.Code = pay.ErrCodeTransferStatusUnknow
			res.Msg = pay.ErrMsgTransferStatusUnknow
		}
	}

	// 查询余额
	balance, err := acc.queryBalance()
	if err == nil && balance.Status == "1" && len(balance.List) > 0 {
		res.Data.AmountRemain = balance.List[0].Balance
	}

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypePUFA,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		res.Status)

	logger.LogTransfer("[PUFA][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		res.Data.TargetName,
		res.Data.TargetAccount,
		res.Data.Amount,
		res.Status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PUFA][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[PUFA][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	return acc.doTransfer(req, true)
}

func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	result, _, err := acc.queryNetTransfer(req.TradeNo)
	if err != nil {
		logger.Errorf("[PUFA][%+v]查询转帐状态错误, 流水号: %+v, 错误: %+v.", acc.Account, req.TradeNo, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[PUFA][%+v]查询转帐状态重新登录帐号错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
			}

			return acc.doTransferStatus(req, false)
		}

		return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
	}

	if result.Status != "1" {
		logger.Errorf("[PUFA][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.", acc.Account, req.TradeNo, result.ResponseMsg)
		return pay.Error(pay.ErrCodeTransferStatusError, result.ResponseMsg, nil)
	}

	status := common.TransferStatusNone
	if result.NetBusinessStatus == "0" {
		status = common.TransferStatusFail
	} else if result.NetBusinessStatus == "1" {
		status = common.TransferStatusSuccess
	} else if result.NetBusinessStatus == "3" {
		status = common.TransferStatusProcessing
	} else {
		logger.Errorf("[PUFA][%+v]查询转帐状态未知状态: %+v.", acc.Account, result.NetBusinessStatus)
		return pay.Error(pay.ErrCodeTransferStatusError, fmt.Sprintf("未知的转帐状态: %+v.", result.NetBusinessStatus), nil)
	}

	res := model.AccountTransferStatusRes{}
	res.Status = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Status = status

	if status != common.TransferStatusProcessing {
		api.NodeTransferStatus(req.TradeNo, status)
		logger.LogTransfer("[PUFA][%+v]转帐流水号[%+v]状态更新为: %+v.", req.TradeNo, status)
	}

	return pay.Success(&res)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[PUFA][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[PUFA][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
