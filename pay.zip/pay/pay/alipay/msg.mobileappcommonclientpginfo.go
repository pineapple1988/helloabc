package alipay

import (
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMobileAppCommonClientPGInfo() error {
	req := func() *alipaymsg.MobileAppCommonClientPGInfoReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			key := []string{"NOTIFICATION", "LBS", "LBSSERVICE", "CAMERA", "PHOTO", "ADDRESSBOOK", "MICROPHONE"}
			val := []string{"0", "0", "0", "2", "2", "0", "2"}
			extraData := []*alipaymsg.KeyValuePairs{}
			for i := range key {
				extraData = append(extraData, &alipaymsg.KeyValuePairs{
					Key:   proto.String(key[i]),
					Value: proto.String(val[i]),
				})
			}

			return &alipaymsg.MobileAppCommonClientPGInfoReq{
				ProductId:      proto.String(productIDIOS),
				ProductVersion: proto.String(productVersionIOS),
				ClientId:       proto.String(fmt.Sprintf("%s|%s", acc.IOSHardwareInfo.IMSI, acc.IOSHardwareInfo.IMEI)),
				MobileModel:    proto.String(acc.IOSHardwareInfo.Model),
				Manufacturer:   proto.String("apple"),
				MobileBrand:    proto.String("apple"),
				NetType:        proto.String("WIFI"),
				Utdid:          proto.String(acc.IOSHardwareInfo.UTDID),
				Platform:       proto.String("ios"),
				OvVersion:      proto.String(acc.IOSHardwareInfo.SysVer),
				ExtraData:      extraData,
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.MobileAppCommonClientPGInfoReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MobileAppCommonClientPGInfoReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_MOBILEAPPCOMMONPGPGPGINFO, c.onMobileAppCommonClientPGInfo, &mmtp, data, true)
}

func (c *AliConn) onMobileAppCommonClientPGInfo(op string, data []byte, param interface{}) {
	logger.Debug("onMobileAppCommonClientPGInfo")
}
