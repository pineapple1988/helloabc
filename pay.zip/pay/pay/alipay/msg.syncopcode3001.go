package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendProtoSyncOpCode3001() error {
	biz := []int32{
		2, 5, 18, 20, 28, 38, 39, 40, 41, 45, 54, 65, 73, 75, 76, 77, 81, 87, 96, 101, 108,
		114, 115, 121, 122, 129, 133, 136, 142, 152, 164, 172, 173, 174, 178, 181, 183, 196,
		199, 203, 204, 208, 214, 217, 219, 220, 222, 223, 226, 229, 232, 236, 238, 239}

	bucket := []int32{30, 32, 137, 138}

	bizInfo := []*alipaymsg.ProtoBizSyncInfo{}
	for _, v := range biz {
		bizInfo = append(bizInfo, &alipaymsg.ProtoBizSyncInfo{
			BizType: proto.Int32(v),
			SyncKey: proto.Int64(0),
		})
	}

	bucketInfo := []*alipaymsg.ProtoBucketSyncInfo{}
	for _, v := range bucket {
		bucketInfo = append(bucketInfo, &alipaymsg.ProtoBucketSyncInfo{
			BucketType: proto.Int32(v),
			SyncKey:    proto.Int64(0),
		})
	}

	req := &alipaymsg.ProtoSyncOpCode3001{
		UserId:         proto.String(c.acc.UserID),
		BizSyncInfo:    bizInfo,
		BucketSyncInfo: bucketInfo,
	}

	pd, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]ProtoSyncOpCode3001序列化错误: %+v.", err)
		return err
	}

	mmtp := &alipaymsg.MmtpHead{
		ZipType:          proto.Uint32(1),
		DataFrameChannel: proto.Uint32(2),
	}

	//data := []byte{0x06, 0x0A, 0xBA}
	//data = append(data, pd...)

	c.sendMessage(mmtp, nil, pd)

	return nil
}
