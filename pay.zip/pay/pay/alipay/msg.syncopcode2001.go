package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils/alihpack"
	"pay/utils/logger"
	"strings"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) onSyncOpCode2001(hf *[]alihpack.HeaderField, data []byte) error {
	res := alipaymsg.ProtoSyncOpCode2001{}
	if err := proto.Unmarshal(data, &res); err != nil {
		return err
	}

	bizSyncData := res.GetBizSyncData()
	bucketSyncInfo := res.GetBucketSyncInfo()

	c.syncMgr.UpdateSyncData(bizSyncData, bucketSyncInfo)

	if len(bizSyncData) > 0 {
		// 同步数据
		c.sendSyncOpCode2002(hf, &res)

		notifyed := false
		for _, item := range bizSyncData {
			if item.GetBizType() == 4 && item.GetBizName() == "devicelock" {
				oplogs := item.GetOplog()
				if oplogs == nil {
					continue
				}

				for _, oplog := range oplogs {
					str := oplog.GetPayload()
					if str == "" {
						continue
					}

					logger.Debugf("[AliConn]oplog==>payload: %+v.", str)

					if strings.Contains(str, "账号在其他设备登录") {
						if !notifyed {
							c.acc.notifyLogin(loginCodeOtherDevice, loginMsgOtherDevice)
							notifyed = true
						}

						logger.Warnf("[AliConn]onSyncOpCode2001, 帐号在其他设备登录, 帐号: %+v, 平台: %+v.",
							c.acc.Account, c.acc.Platform)

					}
				}
			}
		}
	}

	return nil
}
