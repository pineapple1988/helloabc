package alipay

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/alipayutils"
	"pay/utils/logger"
	"strconv"
	"strings"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMspV3GenTid() error {
	req := func() *alipaymsg.MspV3Req {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.MspV3Req{
				ApiNsp:      proto.String("0"),
				ApiNm:       proto.String("0"),
				Action:      proto.String("/cashier/gentid"),
				PbHasAlipay: proto.Int32(1),
				Subua1:      proto.String(acc.IOSHardwareInfo.ClientKey),
				Subua2:      proto.String(fmt.Sprintf("%s;%s", acc.IOSHardwareInfo.VIMEI, acc.IOSHardwareInfo.VIMSI)),
				Subua3:      proto.String(fmt.Sprintf("%s)(2)(zh_CN;;;;;%s;%s", acc.IOSHardwareInfo.IPhoneName, acc.IOSHardwareInfo.WIFIName, acc.IOSHardwareInfo.MacAddr)),
				Extinfo:     proto.String(`{"msp_switch_ver":"invalid"}`),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.MspV3Req{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MspV3GenTidReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage("/cashier/gentid", c.onMspV3GenTid, &mmtp, data, true)
}

func (c *AliConn) onMspV3GenTid(op string, data []byte, param interface{}) {
	logger.Debug("onMspV3GenTid")
	res := alipaymsg.MspV3Res{}
	if err := proto.Unmarshal(data, &res); err != nil {
		logger.Errorf("[AliConn]MspV3Res反序列化错误: %+v, 数据: %+v.", err, data)
		return
	}

	c.acc.TID = res.GetTid()
}

func (c *AliConn) sendMspV3Pay(ts, session, verifyID, dataToken string) error {
	p := make(map[string]string)
	pwd, err := alipayutils.PayPasswordEncrypt(c.acc.GetPayPassword(), ts, rsaPayPassword)
	if err != nil {
		logger.Errorf("[AliConn]MspV3Pay支付密码加密错误: %+v.", err)
		return err
	}

	p["encryptPwd"] = pwd
	pwdJSON, err := json.Marshal(&p)
	if err != nil {
		logger.Errorf("[AliConn]MspV3Pay支付密码序列化错误: %+v.", err)
		return err
	}

	vd := make(map[string]string)
	vd["version"] = "3.1.20.100"
	vd["data"] = string(pwdJSON)
	vd["verifiId"] = verifyID
	vd["module"] = "NATIVE_PAYMENT_PASSWORD"
	vd["token"] = dataToken
	vd["action"] = "VERIFY_PPW"

	vdJSON, err := json.Marshal(&vd)
	if err != nil {
		logger.Errorf("[AliConn]sendMspV3Payvd结构序列化错误: %+v.", err)
		return err
	}

	vi := make(map[string]string)
	vi["VIData"] = string(vdJSON)

	viJSON, err := json.Marshal(&vi)
	if err != nil {
		logger.Errorf("[AliConn]MspV3Payvi结构序列化错误:%+v.", err)
		return err
	}

	req := &alipaymsg.MspV3Req{
		ApiNsp:  proto.String("0"),
		ApiNm:   proto.String("0"),
		Action:  proto.String("/cashier/pay"),
		Session: proto.String(session),
		Extinfo: proto.String(string(viJSON)),
	}

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MspV3PayReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage("/cashier/pay", c.onMspV3Pay, &mmtp, data, true)
}

func (c *AliConn) onMspV3Pay(op string, data []byte, param interface{}) {
	logger.Debug("onMspV3Pay")
}

func (c *AliConn) sendMspV3Main(tradeNo string) error {
	synch := fmt.Sprintf(`trade_no="%s"&app_name="alipay"&biz_type="biz_account_transfer"&display_pay_result="false"&source_id="formtransfer"%s`,
		tradeNo, utils.GetTimeStrEx())
	extinfo := fmt.Sprintf(`trade_no="%s"&app_name="alipay"&biz_type="biz_account_transfer"&display_pay_result="false"&source_id="formtransfer"`,
		tradeNo)
	trid := "A" + utils.MD5String(strconv.FormatInt(utils.GetTimeStampEx(), 10))

	req := func() *alipaymsg.MspV3Req {
		acc := c.acc
		if acc.Platform == platformIOS {
			sec := make(map[string]string)
			sec["rt"] = "0"
			sec["ap"] = ""
			sec["pn"] = bundleIDIOS
			sec["bi"] = "1#1#2#0#2#1#0#6#0#1#0;"
			sec["dv"] = "16"
			sec["ai"] = "2#2#0#2#1#0#6;"
			sec["pm"] = strings.ReplaceAll(acc.IOSHardwareInfo.Model, ",", "#")
			sec["di"] = "FFFFFFFF" + strings.ReplaceAll(acc.IOSHardwareInfo.AWID, "-", "")

			vi := make(map[string]interface{})
			vi["dm"] = acc.IOSHardwareInfo.Model
			vi["secData"] = sec
			vi["sfp"] = "true"
			vi["viv"] = "3.1.20.100"
			vi["bmi"] = "3.0.1:495,7"

			ext := make(map[string]interface{})
			ext["lang"] = "zh-Hans"
			ext["VIData"] = vi
			ext["msp_switch_ver"] = "invalid"

			extJSON, err := json.Marshal(&ext)
			if err != nil {
				logger.Errorf("[AliConn]MspV3Main ext结构序列化错误: %+v, 数据: %+v.", err, ext)
				return nil
			}

			return &alipaymsg.MspV3Req{
				ApiNsp:       proto.String("0"),
				ApiNm:        proto.String("0"),
				Action:       proto.String("/cashier/main"),
				Synch:        proto.String(strconv.FormatUint(alipayutils.CFStringHash(synch), 10)),
				Decay:        proto.String(base64.StdEncoding.EncodeToString([]byte{0x08, 0x03, 0x50, 0x0A, 0x58, 0xC5, 0x04, 0x68, 0x7C})),
				ExternalInfo: proto.String(extinfo),
				Trid:         proto.String(trid),
				Trdfrom:      proto.Int32(1),
				PbHasAlipay:  proto.Int32(1),
				Subua1:       proto.String(acc.IOSHardwareInfo.ClientKey),
				Subua2:       proto.String(fmt.Sprintf("%s;%s", acc.IOSHardwareInfo.VIMEI, acc.IOSHardwareInfo.VIMSI)),
				Subua3:       proto.String(acc.IOSHardwareInfo.IPhoneName),
				Extinfo:      proto.String(string(extJSON)),
			}

		} else if acc.Platform == platformAndroid {
			return &alipaymsg.MspV3Req{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	return nil
}

func (c *AliConn) onMspV3Main(op string, data []byte, param interface{}) {
	logger.Debug("onMspV3Main")
}
