package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendStageInfo() error {
	req := func() *alipaymsg.StateInfoReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.StateInfoReq{
				BaseReq: &alipaymsg.BaseReq{
					Platform: proto.String("IOS"),
					Pre:      proto.Bool(false),
					Width:    proto.Int32(int32(acc.GetScreenWidth())),
				},
				Scene: proto.Int32(2),
				StageCodes: []*alipaymsg.StageCode{
					&alipaymsg.StageCode{ParentState: proto.String("WealthHome")},
					&alipaymsg.StageCode{ParentState: proto.String("fastStage1")},
					&alipaymsg.StageCode{ParentState: proto.String("marketStage")},
					&alipaymsg.StageCode{ParentState: proto.String("socialContact")},
					&alipaymsg.StageCode{ParentState: proto.String("publicStage")},
					&alipaymsg.StageCode{ParentState: proto.String("h5Stage")},
				},
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.StateInfoReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]StageInfoReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_QUERYSTAGEINFO, c.onStageInfo, &mmtp, data, true)
}

func (c *AliConn) onStageInfo(op string, data []byte, param interface{}) {
	logger.Debug("onStageInfo")
}
