package alipay

import (
	"encoding/json"
	"fmt"
	"pay/utils/logger"
	"reflect"
)

func (c *AliConn) sendGetRSAKey(str string) error {
	return c.sendStringMessage(HTTP_GETRSAKEY, c.onString, str, nil)
}

func (c *AliConn) sendGetMsgRecord(str string) error {
	return c.sendStringMessage(HTTP_GETMSGRECORD, c.onString, str, nil)
}

func (c *AliConn) sendUserHistoryReport() error {
	str := ""
	if c.acc.Platform == platformIOS {
		str = `{"reqType":"1","clientRecentUsedList":[],"platform":"IOS"}`
	}

	return c.sendStringMessage(HTTP_USERHISTORYREPORT, c.onString, str, nil)
}

func (c *AliConn) sendMyFollowedList(str string) error {
	return c.sendStringMessage(HTTP_MYFOLLOWEDLIST, c.onString, str, nil)
}

func (c *AliConn) sendQueryAllJoinedGroup(str string) error {
	return c.sendStringMessage(HTTP_QUERYALLJOINEDGROUP, c.onString, str, nil)
}

func (c *AliConn) sendInitialSpaceInfo(str string) error {
	return c.sendStringMessage(HTTP_INITIALSPACEINFO4PB, c.onString, str, nil)
}

func (c *AliConn) sendQueryBankcardList(str string) (<-chan []byte, error) {
	ch := make(chan []byte)
	return ch, c.sendStringMessage(HTTP_BANKCARD_LIST_QUERYV920, c.onQueryResultWait, str, ch)
}

func (c *AliConn) sendQueryBalance(str string) (<-chan []byte, error) {
	ch := make(chan []byte)
	return ch, c.sendStringMessage(HTTP_WEALTHACCOUNTHOME, c.onQueryResultWait, str, ch)
}

func (c *AliConn) sendCollectSingleMoneyCreateSession(str string) (<-chan []byte, error) {
	ch := make(chan []byte)
	return ch, c.sendStringMessage(HTTP_COLLECTSINGLEMONEYCREATESESSION, c.onQueryResultWait, str, ch)
}

func (c *AliConn) sendCollectSingleMoneyConsultSetAmount(sessionID, amount, desc string) (<-chan []byte, error) {
	ch := make(chan []byte)
	str := fmt.Sprintf(`[{"sessionId":"%s","desc":"%s","amount":"%s"}]`,
		sessionID, desc, amount)

	return ch, c.sendStringMessage(HTTP_COLLECTSINGLEMONEYCONSULTSETAMOUNT, c.onQueryResultWait, str, ch)
}

func (c *AliConn) sendMobileCodecRoute(url string) (<-chan []byte, error) {
	ch := make(chan []byte)

	req := func() *map[string]interface{} {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &map[string]interface{}{
				"paiType": "qrCode",
				"decodeData": map[string]string{
					"code": url,
				},
				"channelId": "20000001#topIcon",
				"productContext": map[string]string{
					"clientId":        fmt.Sprintf("%s|%s", acc.IOSHardwareInfo.IMSI, acc.IOSHardwareInfo.IMEI),
					"productVersion":  productVersionIOS,
					"productId":       productIDIOS,
					"birdnestVersion": `{"tplVersion":"5.3.0","platform":"iphone"}`,
					"productChannel":  "apple-iphone",
				},
				"extData": map[string]string{
					"appId":        "10000007",
					"imageChannel": "camera",
					"lbsInfo":      "",
					"scanResult":   url,
				},
			}
		} else if acc.Platform == platformAndroid {
			return &map[string]interface{}{}
		}

		return &map[string]interface{}{}
	}()

	str, err := json.Marshal(req)
	logger.Debug(string(str))
	if err != nil {
		logger.Errorf("[AliConn]扫描二维码序列化数据错误: %+v.", err)
		return nil, err
	}

	return ch, c.sendStringMessage(HTTP_ALIPAY_MOBILECODEC_ROUTE, c.onQueryResultWait, fmt.Sprintf("[%s]", string(str)), ch)
}

func (c *AliConn) onString(op string, data []byte, param interface{}) {
	logger.Debugf("onString, op: %+v.", op)
}

func (c *AliConn) onQueryResultWait(op string, data []byte, param interface{}) {
	t := reflect.TypeOf(param)
	if t.Kind() == reflect.Chan {
		ch, ok := param.(chan []byte)
		if ok {
			ch <- data
		}
	}
}
