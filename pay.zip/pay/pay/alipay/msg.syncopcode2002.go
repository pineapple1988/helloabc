package alipay

import (
	"bytes"
	"encoding/binary"
	"pay/proto/alipaymsg"
	"pay/utils/alihpack"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendSyncOpCode2002(hf *[]alihpack.HeaderField, data *alipaymsg.ProtoSyncOpCode2001) error {

	bizSyncInfoList := []*alipaymsg.ProtoBizSyncInfo{}
	for _, item := range data.GetBizSyncData() {
		bizSyncInfoList = append(bizSyncInfoList, &alipaymsg.ProtoBizSyncInfo{
			BizType:        proto.Int32(item.GetBizType()),
			SyncKey:        proto.Int64(item.GetSyncKey()),
			Pf:             proto.Int32(item.GetPf()),
			DispatchStatus: proto.Int32(1001),
		})
	}

	var bucketSyncInfo *alipaymsg.ProtoBucketSyncInfo
	bsi := data.GetBucketSyncInfo()
	if bsi != nil {
		bucketSyncInfo = &alipaymsg.ProtoBucketSyncInfo{
			BucketType: proto.Int32(bsi.GetBucketType()),
			SyncKey:    proto.Int64(bsi.GetSyncKey()),
		}
	}

	req := alipaymsg.ProtoSyncOpCode2002{
		BizSyncInfo:     bizSyncInfoList,
		BucketSyncInfo:  bucketSyncInfo,
		HasMoreData:     proto.Bool(data.GetHasMoreData()),
		PrincipalId:     proto.String(data.GetPrincipalId()),
		PrincipalIdType: proto.Int32(data.GetPrincipalIdType()),
	}

	pd, err := proto.Marshal(&req)
	if err != nil {
		logger.Errorf("[AliConn]ProtoSyncOpCode2002序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	// ip转换
	ip := func(ip uint32) uint32 {
		arr := make([]byte, 4)
		binary.BigEndian.PutUint32(arr, ip)
		var r uint32
		binary.Read(bytes.NewReader(arr), binary.LittleEndian, &r)
		return r
	}(data.GetServerIp())

	// hpack data
	var hpData []byte
	if hf != nil {
		c.hpackLock.Lock()
		defer c.hpackLock.Unlock()
		c.encodeBuffer.Reset()
		for _, k := range *hf {
			c.hpackEncoder.WriteField(k)
		}

		hpData = c.encodeBuffer.Bytes()
	}

	mmtp := alipaymsg.MmtpHead{
		DataFrameChannel: proto.Uint32(2),
		ForwardIp:        proto.Uint32(ip),
	}

	buffer := []byte{0x06, 0x07, 0xD2}
	buffer = append(buffer, pd...)

	return c.sendMessage(&mmtp, hpData, buffer)
}
