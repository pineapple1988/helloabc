package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMobileRelationGetAllFriend() error {
	req := &alipaymsg.MobileRelationGetAllFriendReq{
		Version:          proto.Int64(0),
		ExtVersion:       proto.Int64(0),
		LastGetDatasTime: proto.Int64(-1),
		DeleteVersion:    proto.Int64(-1),
	}

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MobileRelationGetAllFriendReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_FINDALLFRIENDSV2, c.onMobileRelationGetAllFriend, &mmtp, data, true)
}

func (c *AliConn) onMobileRelationGetAllFriend(op string, data []byte, param interface{}) {
	logger.Debug("onMobileRelationGetAllFriend")
}
