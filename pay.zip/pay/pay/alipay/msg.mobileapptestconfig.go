package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMobileAppTestConfig() error {
	req := func() *alipaymsg.MobileAppABTestConfigReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.MobileAppABTestConfigReq{
				ParamList: func() []*alipaymsg.KeyValuePairs {
					result := []*alipaymsg.KeyValuePairs{}
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("productVersion"), Value: proto.String(productVersionIOS)})
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("os"), Value: proto.String("iphone")})
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("phoneBrand"), Value: proto.String(phoneBrandIOS)})
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("phoneModel"), Value: proto.String("iPhone")})
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("osVersion"), Value: proto.String(acc.IOSHardwareInfo.SysVer)})
					result = append(result, &alipaymsg.KeyValuePairs{Key: proto.String("clientAutoLoginStatus"), Value: proto.String("false")})
					return result
				}(),
				ProductName:        proto.String("alipay"),
				IdentificationCode: proto.String(""),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.MobileAppABTestConfigReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MobileAppTestConfigReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := &alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_ABTESTCONFIGLITE, c.onMobileAppTestConfig, mmtp, data, true)
}

func (c *AliConn) onMobileAppTestConfig(op string, data []byte, param interface{}) {
	logger.Debug("onMobileAppTestConfig")
}
