package alipay

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"pay/api"
	"pay/data/redis"
	"pay/pay"
	"pay/utils"
	"pay/utils/alipayutils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

const (
	alipayAccountKey = "AlipayAccount"
)

var (
	errWrongPlatform   = errors.New("错误的平台")
	errLoadAccountInfo = errors.New("加载帐号信息错误")
	errSaveAccountInfo = errors.New("保存帐号信息错误")
)

// LoginResult 登录返回结构体
type LoginResult struct {
	Code int
	Msg  string
}

// SMSResult 验证码返回结构体
type SMSResult struct {
	Code int
	Msg  string
}

// Account 支付宝登录帐号结构体
type Account struct {
	Account             string              `json:"account"`
	Password            string              `json:"password"`
	PayPassword         string              `json:"payPassword"`
	Platform            string              `json:"platform"`
	Proxy               utils.ProxyInfo     `json:"proxy"`
	IOSHardwareInfo     IOSHardwareInfo     `json:"iosHardwareInfo"`
	AndroidHardwareInfo AndroidHardwareInfo `json:"androidHardwareInfo"`
	Miniwua             string              `json:"miniwua"`
	UMID                string              `json:"umid"`
	UUID                string              `json:"uuid"`
	MmtpDid             string              `json:"mntpdid"`
	ApdidToken          string              `json:"apdidToken"`
	SessionID           string              `json:"sessionId"`
	TID                 string              `json:"tid"`
	UserID              string              `json:"userId"`
	DynamicKey          string              `json:"dynamicKey"`
	loginState          int32
	smsLastCodeTime     uint
	smsCodeH5Url        string
	smsSecurityID       string
	smsToken            string
	smsVerifyID         string
	smsRefererURL       string
	smsSendURL          string
	loginResultCH       chan *LoginResult
	httpClient          *http.Client
	conn                *AliConn
	jar                 *cookiejar.Jar
	loginPadding        int32
	autoReconnect       bool
	disconnectTime      int64
}

// IOSHardwareInfo ios设备硬件信息
type IOSHardwareInfo struct {
	UDID       string `json:"udid"`
	IMEI       string `json:"imei"`
	IMSI       string `json:"imsi"`
	VUDID      string `json:"vudid"`
	VIMEI      string `json:"vimei"`
	VIMSI      string `json:"vimsi"`
	ClientKey  string `json:"clientKey"`
	UTDID      string `json:"utdid"`
	APDID      string `json:"apdid"`
	AWID       string `json:"awid"`
	IDFA       string `json:"idfa"`
	VendorID   string `json:"vendorID"`
	SysVer     string `json:"sysVer"`
	Model      string `json:"model"`
	MacAddr    string `json:"macAddr"`
	WIFIName   string `json:"wifiName"`
	WIFIMac    string `json:"wifiMac"`
	IPhoneName string `json:"iphoneName"`
	ScreenSize string `json:"screenSize"`
}

// AndroidHardwareInfo android设备硬件信息
type AndroidHardwareInfo struct {
	ScreenSize string `json:"screenSize"`
}

// NewAccount 创建一个登录帐号
func NewAccount(
	account string,
	password string,
	payPassword string,
	platform string,
) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		logger.Errorf("[AliPay]错误的登录平台, 帐号: %+v, 平台: %+v.",
			account, platform)

		return nil, errWrongPlatform
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(alipayAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(alipayAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:       account,
			Platform:      platform,
			loginResultCH: make(chan *LoginResult),
		}

		// 加载成功返回, 否则创建帐号
		if err := acc.load(account); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			acc.conn = NewAliConn(acc)

			return acc, nil
		}

		logger.Errorf("[AliPay]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:             account,
		Password:            utils.PasswordEncrypt(password),
		PayPassword:         utils.PasswordEncrypt(payPassword),
		Platform:            platform,
		Proxy:               utils.ProxyInfo{},
		IOSHardwareInfo:     IOSHardwareInfo{},
		AndroidHardwareInfo: AndroidHardwareInfo{},
		loginResultCH:       make(chan *LoginResult),
	}

	if platform == platformIOS {
		acc.newIOSHardwareInfo()
	} else if platform == platformAndroid {
		acc.newAndroidHardwareInfo()
	}

	if err := acc.save(); err != nil {
		return nil, errLoadAccountInfo
	}

	logger.Infof("[AliPay]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	acc.conn = NewAliConn(acc)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.GetPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.GetPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

// GetPassword 返回帐户的明文密码
func (acc *Account) GetPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

// GetPayPassword 返回帐户的明文支付密码
func (acc *Account) GetPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

// GetScreenWidth 返回屏幕宽度
func (acc *Account) GetScreenWidth() int64 {
	size := ""
	if acc.Platform == platformIOS {
		size = acc.IOSHardwareInfo.ScreenSize
	} else {
		size = acc.AndroidHardwareInfo.ScreenSize
	}

	arr := strings.Split(size, "*")
	if len(arr) < 2 {
		return 0
	}

	n, err := strconv.Atoi(arr[0])
	if err != nil {
		return 0
	}

	return int64(n)
}

// GetScreenHeight 返回屏幕高度
func (acc *Account) GetScreenHeight() int64 {
	size := ""
	if acc.Platform == platformIOS {
		size = acc.IOSHardwareInfo.ScreenSize
	} else {
		size = acc.AndroidHardwareInfo.ScreenSize
	}

	arr := strings.Split(size, "*")
	if len(arr) < 2 {
		return 0
	}

	n, err := strconv.Atoi(arr[1])
	if err != nil {
		return 0
	}

	return int64(n)
}

// SetApdid 设置apdid
func (acc *Account) SetApdid(apdid string) {
	if acc.Platform == platformIOS {
		acc.IOSHardwareInfo.APDID = apdid
	} else if acc.Platform == platformAndroid {

	}
}

// SetApdidToken 设置apdidToken
func (acc *Account) SetApdidToken(apdidToken string) {
	acc.ApdidToken = apdidToken
}

// SetDynamicKey 设置dynamicKey
func (acc *Account) SetDynamicKey(dynamicKey string) {
	acc.DynamicKey = dynamicKey
}

func (acc *Account) newIOSHardwareInfo() {
	info := &acc.IOSHardwareInfo
	info.UDID = utils.NewRandString(30, false)
	info.IMEI = info.UDID[:15]
	info.IMSI = "46000" + info.UDID[20:]

	info.VUDID = utils.NewRandString(30, false)
	info.VIMEI = info.VUDID[:15]
	info.VIMSI = info.VUDID[15:]

	info.ClientKey = utils.NewRandString(10, false)
	info.UTDID, _ = alipayutils.NewUTDID(hmacKeyIOS)
	info.APDID, _ = utils.NewUUID(true)
	info.AWID, _ = utils.NewUUID(true)
	info.IDFA, _ = utils.NewUUID(true)
	info.VendorID, _ = utils.NewUUID(true)

	info.SysVer = utils.GetIPhoneOSVersion()

	model, name, screenSize := utils.GetIPhoneModel()
	info.Model = model
	info.IPhoneName = name
	info.ScreenSize = screenSize

	info.MacAddr = utils.NewMacAddress()
	info.WIFIName = utils.NewWifiName()
	info.WIFIMac = utils.NewMacAddress()
}

func (acc *Account) newAndroidHardwareInfo() {

}

func (acc *Account) load(account string) error {
	field := fmt.Sprintf("%s_%s", account, acc.Platform)
	value, err := redis.HGet(alipayAccountKey, field)
	if err != nil {
		logger.Errorf("[AliPay]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[AliPay]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[AliPay]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(alipayAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[AliPay]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

// SetProxy 设置代理服务器信息
func (acc *Account) setProxy(uri, user, pass string) bool {
	if uri != acc.Proxy.URI || user != acc.Proxy.User || pass != acc.Proxy.Pass {
		acc.Proxy.URI = uri
		acc.Proxy.User = user
		acc.Proxy.Pass = pass
		acc.save()
		return true
	}

	return false
}

func (acc *Account) setLoginState(state int) {
	atomic.SwapInt32(&acc.loginState, int32(state))
}

func (acc *Account) notifyLogin(code int, msg string) {
	if acc.loginPadding != 0 {
		// 登录等待时才操作
		acc.loginResultCH <- &LoginResult{
			Code: code,
			Msg:  msg,
		}
	}

	switch code {
	case loginCodeSuccess:
		{
			pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeAlipay)
			acc.setLoginState(pay.LoginStatusSuccess)
			api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeAlipay)
			acc.autoReconnect = true
			// 保存一次sessionkey
			acc.save()
		}
	case loginCodeNeedSMSCode:
		{
			acc.setLoginState(pay.LoginStatusWaitCode)
			api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypeAlipay)
			// 请求验证码
			go acc.SendCode()
		}
	default:
		{
			acc.setLoginState(pay.LoginStatusNone)
		}
	}

	// 帐号密码错误
	if code == loginCodeInvalidAccount || code == loginCodeInvalidPassword {
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeAlipay)
	}

	// 被挤下线
	if code == loginCodeOtherDevice {
		// 登录成功说明被人挤了, 下线
		if acc.loginState == pay.LoginStatusSuccess {
			go acc.conn.Stop()
			acc.loginState = pay.LoginStatusNone
			pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeAlipay)
			api.ReportAccStateKickout(acc.Account, acc.Platform, common.AccountTypeAlipay)
		}
	}

	// 输入帐号密码重新登录时重走一次正常流程
	if code == loginCodeReloginWithPwd {
		go func() {
			logger.Infof("[AliPay]需要重新输入帐号密码登录, 5秒后进行重新登录, 帐号: %+v, 平台: %+v.",
				acc.Account, acc.Platform)
			acc.conn.Stop()
			time.Sleep(time.Millisecond * 5000)
			acc.UserID = ""
			acc.TID = ""
			acc.ApdidToken = ""
			acc.Login(20000)
		}()
	}
}

// IsLoginSuccess 返回帐号是否已经登录成功
func (acc *Account) IsLoginSuccess() bool {
	return acc.loginState == pay.LoginStatusSuccess
}

// IsLoginNeedSMSCode 返回是否需要登录验证码
func (acc *Account) IsLoginNeedSMSCode() bool {
	return acc.loginState == pay.LoginStatusWaitCode
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 执行登录过程, 超时时间为毫秒.
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	switch acc.loginState {
	case pay.LoginStatusWaitCode:
		{
			return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
		}
	case pay.LoginStatusSuccess:
		{
			return pay.Success(nil)
		}
	}

	if acc.loginPadding != 0 {
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[AliPay]Login分配代理服务器错误: %+v.", err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.httpClient = pay.CreateHTTPClient(&acc.Proxy, nil)
	} else {
		acc.httpClient = pay.CreateHTTPClient(nil, nil)
	}

	if err := acc.PostSaveWB(); err != nil {
		defer acc.setLoginState(pay.LoginStatusNone)
		return pay.Error(pay.ErrCodeLoginError, loginMsgGetMiniwuaError, nil)
	}

	acc.conn.Start()

	select {
	case r := <-acc.loginResultCH:
		{
			logger.Infof("[AliPay]登录返回, 帐号: %+v, 平台: %+v, 代码: %+v, 信息: %+v.",
				acc.Account, acc.Platform, r.Code, r.Msg)
			return pay.Error(r.Code, r.Msg, nil)
		}
	case <-time.After(time.Millisecond * time.Duration(timeout)):
		{
			logger.Infof("[AliPay]登录超时, 帐号: %+v, 平台: %+v.",
				acc.Account, acc.Platform)

			acc.conn.Stop()

			return pay.Error(pay.ErrCodeLoginError, loginMsgTimeout, nil)
		}
	}
}

// Logout 退出登录
func (acc *Account) Logout() *pay.ResultInfo {
	acc.autoReconnect = false
	acc.setLoginState(pay.LoginStatusNone)
	go acc.conn.Stop()
	pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeAlipay)
	api.ReportAccStateLogout(acc.Account, acc.Platform, common.AccountTypeAlipay)

	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	if err := acc.setPassword(password, payPassword); err != nil {
		return pay.Error(pay.ErrCodeResetPassError, pay.ErrMsgResetPassError, nil)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	// 不在状态不要验证码
	if !acc.IsLoginNeedSMSCode() {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	// 操作过快
	if (utils.GetTimeStamp() - acc.smsLastCodeTime) < 30 {
		return pay.Error(pay.ErrCodeSendCodeError, smsMsgTooBusy, nil)
	}

	r := acc.requestSMSCode()

	// 要刷脸
	if r.Code == smsCodeNeedFaceScan {
		api.ReportAccStateNeedFaceScan(acc.Account, acc.Platform, common.AccountTypeAlipay)
	}

	// 设置为等待验证码, 记录时间
	if r.Code == smsCodeSendSuccess {
		acc.smsLastCodeTime = utils.GetTimeStamp()
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	// 不在状态
	if !acc.IsLoginNeedSMSCode() {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	r := acc.verifySMSCode(code)

	// 验证成功时再次请求登录
	if r.Code == smsCodeVerifySuccess {
		go acc.conn.sendUnifyLogin(acc.smsToken, acc.smsSecurityID)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	ch, err := acc.conn.sendQueryBankcardList("[{}]")
	if err != nil {
		logger.Errorf("[AliPay]CardList发送银行卡列表查询错误: %+v.", err)
		return pay.Error(pay.ErrCodeCardListError, queryMsgSendQueryFail, nil)
	}

	select {
	case r := <-ch:
		{
			if r == nil || len(r) <= 0 {
				go acc.conn.Stop()

				return pay.Error(pay.ErrCodeCardListError, queryMsgDisconnect, nil)
			}
		}
	case <-time.After(time.Millisecond * 5000):
		{
			return pay.Error(pay.ErrCodeCardListError, queryMsgQueryTimeout, nil)
		}
	}

	return pay.Success(nil)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	ch, err := acc.conn.sendQueryBalance("[{}]")

	if err != nil {
		logger.Errorf("[AliPay]Balance发送查询余额请求错误: %+v.", err)
		return pay.Error(pay.ErrCodeGetBalanceError, queryMsgSendQueryFail, nil)
	}

	select {
	case r := <-ch:
		{
			if r == nil || len(r) <= 0 {
				go acc.conn.Stop()

				return pay.Error(pay.ErrCodeGetBalanceError, queryMsgDisconnect, nil)
			}

			res := BalanceInfo{}
			if err := json.Unmarshal(r, &res); err != nil {
				logger.Warnf("[AliPay]Balance反序列化响应数据错误: %+v, 数据: %+v.", err, string(r))

				return pay.Error(pay.ErrCodeGetBalanceError, queryMsgUnmarshalFail, nil)
			}

			if !res.Success {
				return pay.Error(pay.ErrCodeGetBalanceError, queryMsgUnSuccess, nil)
			}

			resData := model.AccountBalanceRes{}
			resData.Code = common.ErrCodeSuccess
			resData.Msg = common.ErrMsgSuccess
			resData.Data.Amount = res.RemainAmount
			resData.Data.AmountAvailable = res.AvailableAmount

			return pay.Success(&resData)
		}
	case <-time.After(time.Millisecond * 5000):
		{
			return pay.Error(pay.ErrCodeGetBalanceError, queryMsgQueryTimeout, nil)
		}
	}
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	return nil
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	// 支付宝不实现该接口
	return nil
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	return nil
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {

}

// QRScan 二维码扫描
func (acc *Account) QRScan(qrURL string) error {
	ch, err := acc.conn.sendMobileCodecRoute(qrURL)
	if err != nil {
		logger.Errorf("[AliPay]QRScan发送扫码请求失败: %+v.", err)
		return errors.New("发送扫码请求失败")
	}

	ri := []RouteInfo{}

	select {
	case r := <-ch:
		{

			// 可能断线了, 强制断线重连
			if r == nil || len(r) <= 0 {
				go acc.conn.Stop()
				return errors.New("帐号断线, 请稍候再试")
			}

			logger.Debugf("[AliPay]QRScan扫码返回: %+v.", string(r))

			res := MobileCodecRouteRes{}
			if err := json.Unmarshal(r, &res); err != nil {
				logger.Errorf("[AliPay]QRScan反序列化扫码返回数据错误: %+v.", err)
				return errors.New("反序列化响应数据失败-1")
			}

			if !res.Success {
				return errors.New("扫码返回结果错误")
			}

			if res.RouteInfos == "" {
				return errors.New("扫码返回结果为空")
			}

			if err := json.Unmarshal([]byte(res.RouteInfos), &ri); err != nil {
				logger.Errorf("[AliPay]QRScan反序列化扫码返回结果错误: %+v.", err)
				return errors.New("反序列化响应数据失败-2")
			}

			if len(ri) <= 0 {
				return errors.New("扫码返回结果为空")
			}
		}
	case <-time.After(time.Millisecond * 5000):
		{
			return errors.New("扫描二维码超时")
		}
	}

	// 提取下一步操作url
	u, err := url.Parse(ri[0].URI)
	if err != nil {
		logger.Warnf("[AliPay]QRScan解释url错误: %+v.", err)
		return errors.New("解释扫码URL失败-1")
	}

	nextURL := u.Query().Get("url")
	if nextURL == "" {
		logger.Warn("[AliPay]QRScan无法找到扫码确定地址.")
		return errors.New("解释扫码URL失败-2")
	}

	// 下一步操作
	logger.Debugf("[AliPay]QRScan NextURL: %s.", nextURL)
	if err := acc.qrScanNext(nextURL); err != nil {
		return err
	}

	return nil
}

// GetQRCode 生成收款二维码
func (acc *Account) GetQRCode(amount, desc string, setAmount bool) (string, string, error) {
	// 第一步先生成无金额的二维码
	ch, err := acc.conn.sendCollectSingleMoneyCreateSession("[{}]")
	if err != nil {
		logger.Errorf("[AliPay]GetQRCode发送生成二维码请求错误: %+v.", err)
		return "", "", errors.New("发送生成二维码请求失败")
	}

	qrCodeURL := ""
	printQRCodeURL := ""
	sessionID := ""

	select {
	case r := <-ch:
		{
			//
			if r == nil || len(r) <= 0 {
				go acc.conn.Stop()
				return "", "", errors.New("帐号断线, 请稍候再试")
			}

			logger.Debugf("[AliPay]GetQRCode生成二维码返回: %+v.", string(r))

			qr := NotAmountQRCode{}
			if err := json.Unmarshal(r, &qr); err != nil {
				logger.Errorf("[AliPay]GetQRCode第一步反序列化失败, 帐号: %+v, 数据: %+v, 错误: %+v.",
					acc.Account, string(r), err)
				return "", "", errors.New("反序列化响应数据失败-1")
			}

			if !qr.Success {
				logger.Errorf("[AliPay]GetQRCode第一步返回不成功, 帐号: %+v, 数据: %+v.",
					acc.Account, string(r))
				return "", "", errors.New("生成收款二维码错误-1")
			}

			qrCodeURL = qr.QRCodeURL
			printQRCodeURL = qr.PrintQRCodeURL
			sessionID = qr.SessionID
		}
	case <-time.After(time.Millisecond * 5000):
		{
			return "", "", errors.New("生成收款二维码超时1")
		}
	}

	if setAmount {
		ch, err := acc.conn.sendCollectSingleMoneyConsultSetAmount(sessionID, amount, desc)
		if err != nil {
			logger.Errorf("[AliPay]GetQRCode发送生成带金额二维码请求错误: %+v.", err)
			return "", "", errors.New("发送生成带金额二维码请求失败")
		}
		select {
		case r := <-ch:
			{
				//logger.Debug(string(r))
				qr := AmountQRCode{}
				if err := json.Unmarshal(r, &qr); err != nil {
					logger.Errorf("[AliPay]GetQRCode第二步反序列化失败, 帐号: %+v, 数据: %+v, 错误: %+v.",
						acc.Account, string(r), err)
					return "", "", errors.New("反序列化响应数据失败-2")
				}

				if !qr.Success {
					logger.Errorf("[AliPay]GetQRCode第二步返回不成功, 帐号: %+v, 数据: %+v.",
						acc.Account, string(r))
					return "", "", errors.New("生成收款二维码错误-2")
				}

				qrCodeURL = qr.QRCodeURL
				printQRCodeURL = qr.PrintQRCodeURL
			}
		case <-time.After(time.Millisecond * 5000):
			{
				return "", "", errors.New("生成收款二维码超时2")
			}
		}
	}

	return qrCodeURL, printQRCodeURL, nil
}
