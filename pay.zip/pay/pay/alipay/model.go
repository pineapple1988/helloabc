package alipay

// NotAmountQRCode 不设置金额的二维码信息
type NotAmountQRCode struct {
	PrintQRCodeURL string `json:"printQrCodeUrl"`
	QRCodeURL      string `json:"qrCodeUrl"`
	ResultStatus   int    `json:"resultStatus"`
	SessionID      string `json:"sessionId"`
	Success        bool   `json:"success"`
}

// AmountQRCode 设置金额的二维码信息
type AmountQRCode struct {
	CodeID         string `json:"codeId"`
	QRCodeURL      string `json:"qrCodeUrl"`
	PrintQRCodeURL string `json:"printQrCodeUrl"`
	ResultStatus   int    `json:"resultStatus"`
	SessionID      string `json:"sessionId"`
	Success        bool   `json:"success"`
}

// MobileCodecRouteRes 扫码返回
type MobileCodecRouteRes struct {
	ExtInfo       string `json:"extInfo"`
	FuseReplayTag bool   `json:"fuseReplayTag"`
	ResultCode    int    `json:"resultCode"`
	RouteInfos    string `json:"routeInfos"`
	Sampling      bool   `json:"sampling"`
	Success       bool   `json:"success"`
}

// RouteInfo 扫码RouteInfo
type RouteInfo struct {
	Method     string `json:"method"`
	URI        string `josn:"uri"`
	WalletOnly bool   `json:"walletOnly"`
}

//BalanceInfo 余额信息
type BalanceInfo struct {
	AvailableAmount   string `json:"availableAmount"`
	RemainAmount      string `json:"remainAmount"`
	BalancePayClose   bool   `json:"balancePayClose"`
	DepositAvailable  bool   `json:"depositAvailble"`
	ExpirationDays    int    `json:"expirationDays"`
	ResultCode        string `json:"resultCode"`
	ResultDesc        string `json:"resultDesc"`
	Success           bool   `json:"success"`
	WithdrawAvailable bool   `json:"withdrawAvailble"`
}
