package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendEdge() error {
	req := func() *alipaymsg.EdgeReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.EdgeReq{
				AppName:           proto.String(bundleIDIOS),
				AppVersion:        proto.String(productVersionIOS),
				SdkVersion:        proto.String(sdkVersionIOS),
				OsType:            proto.Int32(1),
				OsVersion:         proto.String(acc.IOSHardwareInfo.SysVer),
				Model:             proto.String(acc.IOSHardwareInfo.Model),
				EdgeStatus:        proto.Int32(1),
				Apdid:             proto.String(acc.IOSHardwareInfo.APDID),
				ApdidToken:        proto.String(""),
				CredibleTimestamp: proto.Int32(-1),
				PolicyPackVersion: proto.String("39"),
				SecureData:        []byte{0x45, 0x2b, 0xa2, 0x53, 0x35, 0x9d, 0x60, 0x97, 0xc6, 0x6e, 0xdc, 0xa4, 0x08, 0xad, 0xa3, 0x43},
				ExtData:           proto.String(`{"exAppListVer":"3"}`),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.EdgeReq{}
		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]EdgeReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_EDGEDATAUPDATE, c.onEdge, &mmtp, data, true)
}

func (c *AliConn) onEdge(op string, data []byte, param interface{}) {
	logger.Debug("onEdge")
}
