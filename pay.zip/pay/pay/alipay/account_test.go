package alipay

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"pay/data/redis"
	"pay/mgr/syncmgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"testing"
)

func TestNewIOSHardwareInfo(t *testing.T) {
	acc := &Account{}
	acc.newIOSHardwareInfo()
	json, err := json.Marshal(&acc)
	if err != nil {
		t.Fatalf("序列化IOS硬件信息错误:%+v.", err)
	}

	fmt.Println(string(json))
}

func TestNewAndroidHardwareInfo(t *testing.T) {

}

func TestPostSaveWB(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "aa123456",
	}

	if err := redis.InitRedis(cfg); err != nil {
		t.Fatalf("连接redis数据库失败, 错误: %+v.", err)
	}

	if err := syncmgr.LoadSyncInfo("../../data/syncinfo.plist"); err != nil {
		t.Fatalf("加载syncinfo.plist错误: %+v.", err)
	}

	id := utils.NewRandString(8, false)
	pwd := utils.NewRandString(8, false)
	//acc, err := NewAccount("3368528649@qq.com", "lxz640128", "lxz640128", "ios")
	//acc, err := NewAccount("yinkeng49255@163.com", "w1983102510", "w1983102510", "ios")
	acc, err := NewAccount(id, pwd, pwd, "ios")
	if err != nil {
		t.Fatalf("创建帐号失败, 错误: %+v", err)
	}

	acc.httpClient = pay.CreateHTTPClient(nil, nil)

	if err := acc.PostSaveWB(); err != nil {
		t.Fatalf("PostSaveWB失败, 错误: %+v.", err)
	}

	acc.conn.Start()

	bufio.NewReader(os.Stdin).ReadRune()
}
