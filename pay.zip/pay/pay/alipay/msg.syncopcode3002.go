package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendProtoSyncOpCode3002() error {
	req := &alipaymsg.ProtoSyncOpCode3002{}

	pd, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]ProtoSyncOpCode3002序列化错误: %+v.", err)
		return err
	}

	mmtp := &alipaymsg.MmtpHead{
		DataFrameChannel: proto.Uint32(2),
	}

	data := []byte{0x06, 0x0B, 0xBA}
	data = append(data, pd...)

	c.sendMessage(mmtp, nil, data)

	return nil
}
