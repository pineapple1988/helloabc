package alipay

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendReport() error {
	req := func() *alipaymsg.ReportReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			bizData := &alipaymsg.ReportBizData{
				Apdid:      proto.String(acc.IOSHardwareInfo.APDID),
				ApdidToken: proto.String(acc.ApdidToken),
				LastTime:   proto.String(""),
				DynamicKey: proto.String(acc.DynamicKey),
				UmidToken:  proto.String(acc.UMID),
			}

			startupTime := uint(utils.RandInt(7200, 200000))
			deviceData := &alipaymsg.ReportDeviceData{
				IE2:  proto.Int32(11),
				IE3:  proto.Bool(false),
				IE4:  proto.String(acc.IOSHardwareInfo.Model),
				IE5:  proto.String(acc.IOSHardwareInfo.SysVer),
				IE6:  proto.String(acc.IOSHardwareInfo.IPhoneName),
				IE7:  proto.String(acc.IOSHardwareInfo.Model),
				IE8:  proto.String("CHINA MOBILE"),
				IE9:  proto.String(""),
				IE11: proto.Float64(float64(utils.GetTimeStamp() - startupTime)),
				IE13: proto.Float64(float64(utils.GetTimeStamp())),
				IE12: proto.Float64(float64(startupTime)),
				IE14: proto.Int32(1),

				IL3:  proto.String(acc.IOSHardwareInfo.WIFIMac),
				ID1:  proto.String(acc.IOSHardwareInfo.VIMEI),
				ID2:  proto.String(acc.IOSHardwareInfo.VIMSI),
				ID3:  proto.String(acc.IOSHardwareInfo.IDFA),
				ID5:  proto.String("a6c9cfc2d1a19d7f9eec8b3a44b8d61528fc507c"),
				ID8:  proto.Int32(int32(acc.GetScreenWidth())),
				ID9:  proto.Int32(int32(acc.GetScreenHeight())),
				ID10: proto.Int32(2),
				ID11: proto.Int32(0),
				// 内存大小
				ID12: proto.Int64(1035988992),
				// 磁盘空间
				ID13: proto.Int64(12856651776),
				ID15: proto.String(""),
				ID16: proto.String(""),
				ID17: proto.String(acc.IOSHardwareInfo.VendorID),
				ID18: proto.String("Asia/Shanghai (GMT+8) offset 28800"),
				ID19: proto.String("zh-Hans"),
				ID20: proto.String(""),
				ID21: proto.String(""),
				ID22: proto.String(""),
				ID23: proto.String("0"),
				// 空闲磁盘空间
				ID24: proto.Int64(10911305728),
				// 电量
				ID25: proto.Float32(0.99),
				ID26: proto.Int32(2),

				IA1:  proto.String(bundleIDIOS),
				IA2:  proto.String(productVersionIOS),
				IA4:  proto.String("P1.3.8.20180316"),
				IA5:  proto.String(fmt.Sprintf(`{"%s_%s":"%d"}`, bundleIDIOS, productVersionIOS, utils.GetTimeStamp())),
				IA6:  proto.String(""),
				IC1:  proto.String(""),
				IC4:  proto.String(acc.IOSHardwareInfo.APDID),
				IC5:  proto.String(""),
				IC6:  proto.String(""),
				IC9:  proto.String(""),
				IC10: proto.String(""),
			}

			ID37Str := fmt.Sprintf("%d-ios-1521554639", int(deviceData.GetIE13()))
			ID37, _ := utils.AESCBCEncrypt([]byte(ID37Str), aesReportKey, aesReportIV)
			extDeviceData := map[string]string{
				"ID23": "0",
				"ID33": "",
				"ID30": "",
				"ID36": "",
				"IE15": acc.IOSHardwareInfo.IPhoneName,
				"ID34": "Darwin Kernel Version 14.0.0: Sun Mar 29 19:42:54 PDT 2015; root:xnu-2784.20.34~2/RELEASE_ARM64_T7000",
				"ID31": fmt.Sprintf(`{"wua":"%s","version":"3.0"}`, acc.Miniwua),
				"ID37": base64.StdEncoding.EncodeToString(ID37),
				// TODO: ?????????????
				"IE16": "android",
				"ID35": "0",
				"ID32": acc.IOSHardwareInfo.MacAddr,
			}

			extDeviceDataJSON, err := json.Marshal(&extDeviceData)
			if err != nil {
				logger.Errorf("[AliConn]ReportReq 序列化extDeviceData错误: %+v, 数据: %+v.", err, extDeviceData)
				return nil
			}

			return &alipaymsg.ReportReq{
				BizData:       bizData,
				DeviceData:    deviceData,
				ExtDeviceData: proto.String(string(extDeviceDataJSON)),
			}

		} else if acc.Platform == platformAndroid {
			return &alipaymsg.ReportReq{}
		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]ReportReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_DEVICEDATAREPORT, c.onReport, &mmtp, data, true)
}

func (c *AliConn) onReport(op string, data []byte, param interface{}) {
	logger.Debug("onReport")
	res := alipaymsg.ReportRes{}
	if err := proto.Unmarshal(data, &res); err != nil {
		c.notifyReportResult(false)
		logger.Errorf("[AliConn]ReportRes反序列化错误: %+v, 数据: %+v.", err, data)
		return
	}

	rd := res.GetResultData()
	acc := c.acc

	acc.SetApdid(rd.GetApdid())
	acc.SetApdidToken(rd.GetApdidToken())
	acc.SetDynamicKey(rd.GetDynamicKey())

	if err := acc.save(); err != nil {
		logger.Errorf("[AliConn]Report返回数据时缓存失败.")
	}

	logger.Infof("[AliConn]Report返回, apdid: %+v, apdidToken: %+v, dynamicKey: %+v.",
		rd.GetApdid(), rd.GetApdidToken(), rd.GetDynamicKey())

	c.notifyReportResult(true)
}
