package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendPushCoreBindUser() error {
	req := func() *alipaymsg.PushCoreBindUserReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.PushCoreBindUserReq{
				MspTid:      proto.String(acc.TID),
				UserId:      proto.String(acc.UserID),
				PushVersion: proto.String("1.1.0"),
				OsType:      proto.String("IOS"),
				ClientId:    proto.String(acc.IOSHardwareInfo.UTDID),
				DeviceId:    proto.String(""),
				AppVersion:  proto.String(productVersionIOS),
				IsPush:      proto.String("0"),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.PushCoreBindUserReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]PushCoreBindUserReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_DEVICEIOSBIND, c.onPushCoreBindUser, &mmtp, data, true)
}

func (c *AliConn) onPushCoreBindUser(op string, data []byte, param interface{}) {
	logger.Debug("onPushCoreBindUser")
}
