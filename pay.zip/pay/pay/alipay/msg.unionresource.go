package alipay

import (
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendUnionResource() error {
	biz := []int32{8, 2, 1, 6}
	resourceParam := []*alipaymsg.UnionResourceParam{}
	for _, v := range biz {
		resourceParam = append(resourceParam, &alipaymsg.UnionResourceParam{BizType: proto.Int32(v)})
	}

	req := func() *alipaymsg.UnionResourceReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.UnionResourceReq{
				Platform:           proto.Int32(1),
				ProductId:          proto.String(productIDIOS),
				ProductVersion:     proto.String(productVersionIOS),
				ReleaseVersion:     proto.String(productVersionIOS),
				Utdid:              proto.String(acc.IOSHardwareInfo.UTDID),
				ClientId:           proto.String(fmt.Sprintf("%s|%s", acc.IOSHardwareInfo.IMSI, acc.IOSHardwareInfo.IMEI)),
				PhoneBrand:         proto.String(phoneBrandIOS),
				PhoneModel:         proto.String(acc.IOSHardwareInfo.Model),
				OsVersion:          proto.String(acc.IOSHardwareInfo.SysVer),
				NetType:            proto.String("WIFI"),
				ResourceParam:      resourceParam,
				Uid:                proto.String(""),
				CupInstructionList: []string{"arm64"},
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.UnionResourceReq{}
		}
		return nil
	}()

	if req == nil {

		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]UnionResourceReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_GETUNIONRESOURCE, c.onUnionResource, &mmtp, data, true)
}

func (c *AliConn) onUnionResource(op string, data []byte, param interface{}) {
	logger.Debug("onUnionResource")
}
