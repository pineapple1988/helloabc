package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMobileCodecShareCodeConfig() error {
	req := &alipaymsg.MobileCodecShareCodeConfigReq{
		CurrentVersion: proto.Int32(-1),
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MobileCodecShareCodeConfigReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_MOBILECODECSHARECODE, c.onMobileCodecShareCodeConfig, &mmtp, data, true)
}

func (c *AliConn) onMobileCodecShareCodeConfig(op string, data []byte, param interface{}) {
	logger.Debug("onMobileCodecShareCodeConfig")
}
