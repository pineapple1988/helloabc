package alipay

import (
	"bytes"
	"compress/gzip"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io/ioutil"
	"net/http"
	"net/url"
	"pay/mgr/cookiemgr"
	"pay/utils"
	"pay/utils/alipayutils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"

	"github.com/go-http-utils/headers"
)

const (
	urlMGWHTM               = "https://mobilegw.alipay.com/mgw.htm"
	urlSaveWB               = "https://ynuf.alipay.com/saveWb.json"
	urlSMSH5Callback        = "https://www.alipay.com/webviewbridge?action=continueLogin"
	urlSMSCheckMobileVerify = "https://mobileic.alipay.com/mic/checkMobileVerify.htm?token=%s&verifyId=%s&code=1002"
	urlSMSView              = "https://mobileic.alipay.com/mic/view.htm?verifyId=%s&token=%s"
	urlSMSViewProduct       = "https://mobileic.alipay.com/mic/viewProduct.json?token=%s&product=ACCOUNT_BINDING_SMS&verifyId=%s&action=RESEND_SMS"
	urlSMSVerify            = "https://mobileic.alipay.com/mic/verify.json"
)

const (
	httpTimeout   = 10000
	smsSendedText = `发送短信$1到你的手机`
)

var (
	tripleDESKey = utils.NewRandString(24, false)
)

var (
	errSaveWBDataError           = errors.New("savewb error save wb data")
	errSaveWBPayloadDataNotFound = errors.New("savewb payload data not found")
	errSaveWBPayloadData         = errors.New("savewb payload data error")
)

type saveWBResponse struct {
	App       string `json:"app"`
	Payload   string `json:"payload"`
	Service   string `json:"service"`
	Signature string `json:"signature"`
	Timestamp int    `json:"timestamp"`
}

type saveWBPayloadData struct {
	EE          string `json:"ee"`
	TraceIPAddr string `json:"trace_ip_addr"`
	RMData      string `json:"rmdata"`
	AppList     string `json:"appList"`
	ExactID     string `json:"exactid"`
	STID        string `json:"stid"`
	UUID        string `json:"uuid"`
	AppListVer  string `json:"appListVer"`
}

type saveWBPayload struct {
	Code     int               `json:"code"`
	Data     saveWBPayloadData `json:"data"`
	Message  string            `json:"message"`
	SecEvent int               `json:"secevent"`
}

type accountBindingSMS struct {
	Msg            string `json:"msg"`
	Code           string `json:"code"`
	IsClosed       bool   `json:"isClosed"`
	ErrorTimesLeft int    `json:"errorTimesLeft"`
	ErrorCode      string `json:"errorCode"`
	ProdSuccess    bool   `json:"prodSuccess"`
}

type smsVerifyResult struct {
	HasOtherFlows           bool              `json:"hasOtherFlows"`
	Service                 bool              `json:"service"`
	CallbackType            string            `json:"call_back_type"`
	CallbackURL             string            `json:"call_back_url"`
	CallbackScript          bool              `json:"call_back_script"`
	Success                 bool              `json:"success"`
	Finish                  bool              `json:"finish"`
	AccountBindingSMS       accountBindingSMS `json:"ACCOUNT_BINDING_SMS"`
	AccountBindingSMSSimple accountBindingSMS `json:"ACCOUNT_BINDING_SMS_SIMPLE"`
}

func (acc *Account) getUserAgent() string {
	if acc.Platform == platformIOS {
		return fmt.Sprintf("Mozilla/5.0 (iPhone; CPU iPhone OS %s like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/16B92 NebulaSDK/1.8.100112 Nebula PSDType(1) AlipayDefined(nt:WIFI,ws:375|603|2.0) AliApp(AP/%s) AlipayClient/%s Language/zh-Hans",
			strings.ReplaceAll(acc.IOSHardwareInfo.SysVer, ".", "_"),
			productVersionIOS,
			productVersionIOS)
	} else if acc.Platform == platformAndroid {
		return ""
	}

	return ""
}

func (acc *Account) getSaveWBArray1() []byte {
	ba := utils.NewByteArray([]byte{})

	if acc.Platform == platformIOS {
		ba.WriteString("1000")
		ba.WriteString("iOS")
		//tmpBA.WriteBytes(Encoding.UTF8.GetBytes(actInfo.uuid));
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString(acc.IOSHardwareInfo.IDFA)
		ba.WriteString(strings.ToUpper(acc.IOSHardwareInfo.MacAddr))
		ba.WriteString("6.4.36")
		ba.WriteString(bundleIDIOS)
		ba.WriteString("10.1.20")
		ba.WriteString("23086819")
		ba.WriteString("4")
	} else if acc.Platform == platformAndroid {
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
		ba.WriteString("")
	} else {
		return nil
	}

	ts := utils.GetTimeStampEx()
	ba.WriteString(strconv.Itoa(int(ts)))

	arr := []byte{
		0x64, 0x02, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x64, 0x02, 0x00, 0x00, 0x46, 0x10, 0x00, 0x00,
		0xB3, 0x9D, 0xCF, 0xB2, 0x65, 0x01, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,
		0xF0, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	}

	tsBuf := make([]byte, 8)
	binary.LittleEndian.PutUint64(tsBuf, uint64(ts))
	copy(arr[16:], tsBuf)

	ba.WriteString(base64.StdEncoding.EncodeToString(arr))
	ba.WriteString("1")
	ba.WriteString("")

	ret := utils.NewByteArray([]byte{})
	ret.WriteBytes([]byte{0xBE, 0xBC})
	ret.WriteInt32(int32(ba.Length() + 6))
	ret.WriteBytes(ba.Bytes())

	return ret.Bytes()
}

func (acc *Account) getSaveWBMobileInfo() []byte {
	ba := utils.NewByteArray([]byte{})
	if acc.Platform == platformIOS {
		// 32
		ba.WriteBytes([]byte(`{"32":{"2":{"22":"1.0.0","1":"1.0.0","23":"0xFFFFFFFF"},"0":{}},`))

		// 24
		ba.WriteBytes([]byte(`"24":{"2":{"2":"` + strconv.Itoa(int(utils.GetTimeStamp())) + `"000000},"0":{}},`))

		// 25
		ba.WriteBytes([]byte(`"25":{"2":{"2":"`))
		ba.WriteBytes(alipayutils.NotString(acc.IOSHardwareInfo.MacAddr))
		ba.WriteBytes([]byte(`"},"0":{}},`))

		// 8
		ba.WriteBytes([]byte(`"8":{"2":{"2":"`))
		ba.WriteBytes(alipayutils.NotString(acc.IOSHardwareInfo.WIFIMac))
		ba.WriteBytes([]byte(`"},"0":{}},`))

		// 27
		ba.WriteBytes([]byte(`"27":{"2":{"`))
		ba.WriteBytes(alipayutils.NotString("en0"))
		ba.WriteBytes([]byte(`":"`))

		ba.WriteBytes(alipayutils.NotString("fe80::40d:d79:1835:5aff"))
		ba.WriteBytes([]byte(`","`))
		ba.WriteBytes(alipayutils.NotString("en0"))
		ba.WriteBytes([]byte(`":"`))

		ba.WriteBytes(alipayutils.NotString("172.20.10.5"))
		ba.WriteBytes([]byte(`","`))
		ba.WriteBytes(alipayutils.NotString("awdl0"))
		ba.WriteBytes([]byte(`":"`))

		ba.WriteBytes(alipayutils.NotString("fe80::f039:e0ff:fed9:3c72"))
		ba.WriteBytes([]byte(`"},"0":{}},`))

		// 30
		ba.WriteBytes([]byte(`"30":{"2":{"30":"`))
		ba.WriteBytes([]byte(acc.IOSHardwareInfo.MacAddr))
		ba.WriteBytes([]byte(`"},"0":{}},`))

		// 62
		ba.WriteBytes([]byte(`"62":{"2":{"57":3000,"58":"14.0.0","59":"` + acc.IOSHardwareInfo.IPhoneName + `","60":"` + acc.Account + `","61":3000},"0":{}},`))

		// 80
		ba.WriteBytes([]byte(`"80":{"2":{"75":"`))
		ba.WriteBytes([]byte(alipayutils.NotString("(null)")))
		ba.WriteBytes([]byte(`","76":"`))
		ba.WriteBytes([]byte(alipayutils.NotString("/var/mobile/Containers/Data/Application/E50D1E2C-BC3E-4186-B35D-7A48BFCE23E9")))
		ba.WriteBytes([]byte(`","77":"`))
		ba.WriteBytes([]byte(alipayutils.NotString("/private/var/mobile/Containers/Bundle/Application/A623EC6B-9EBC-4781-A553-9D345AB32241/Alipay.app/Info.plist")))
		ba.WriteBytes([]byte(`","78":"`))
		ba.WriteBytes([]byte(alipayutils.NotString("E1664DC3-53B7-4E07-8F25-8DB58ED98AC3")))
		ba.WriteBytes([]byte(`","79":"`))
		ba.WriteBytes([]byte(alipayutils.NotString("3135D32E-374F-4593-9365-1F5DE9267182")))
		ba.WriteBytes([]byte(`"},"0":{}}}`))

	} else if acc.Platform == platformAndroid {

	} else {
		return nil
	}

	zlibArr, err := utils.ZLibCompress(ba.Bytes())
	if err != nil {
		return nil
	}

	zlibStr := base64.StdEncoding.EncodeToString(zlibArr)

	base64Arr := []byte{0x00, 0x00, 0x00}
	base64Arr = append(base64Arr, zlibStr...)

	ret := utils.NewByteArray([]byte{})
	ret.WriteBytes([]byte{0xBE, 0xBC})
	ret.WriteInt32(int32(len(base64Arr) + 7))
	ret.WriteBytes(base64Arr)
	ret.WriteByte(0)

	return ret.Bytes()
}

func (acc *Account) getSaveWBFileInfo() []byte {
	ba := utils.NewByteArray([]byte{})

	if acc.Platform == platformIOS {
		arr := []byte{
			0x7B, 0x0A, 0x09, 0x22, 0x32, 0x22, 0x3A, 0x09, 0x7B, 0x0A, 0x09, 0x09, 0x22, 0x31, 0x22, 0x3A,
			0x09, 0x22, 0x69, 0x30, 0x30, 0x34, 0x22, 0x2C, 0x0A, 0x09, 0x09, 0x22, 0x32, 0x22, 0x3A, 0x09,
			0x22, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x36,
			0x33, 0x39, 0x36, 0x38, 0x38, 0x32, 0x31, 0x42, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x32, 0x34, 0x34, 0x34, 0x34, 0x34, 0x36, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x45, 0x30, 0x41, 0x33, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x32, 0x35, 0x46, 0x38,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x30, 0x43, 0x46, 0x35, 0x39, 0x33, 0x42,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x39, 0x38, 0x37,
			0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x36,
			0x33, 0x39, 0x36, 0x38, 0x38, 0x31, 0x44, 0x43, 0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x32, 0x34, 0x34, 0x34, 0x34, 0x34, 0x36, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x45, 0x30, 0x37, 0x36, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x33, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x32, 0x35, 0x46, 0x38,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x32, 0x35, 0x46, 0x38,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x39, 0x38, 0x34,
			0x42, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x34, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x38, 0x31, 0x42, 0x38, 0x31, 0x30, 0x39, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x38, 0x31, 0x42, 0x38, 0x31, 0x30, 0x39, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x30, 0x30, 0x30, 0x30, 0x31, 0x35, 0x41, 0x44, 0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x35, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x30, 0x32, 0x31, 0x35,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x42, 0x46, 0x31, 0x35, 0x46, 0x32, 0x42, 0x32,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x33, 0x36, 0x45,
			0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x36, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x38, 0x31, 0x42, 0x31, 0x31, 0x33, 0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x31, 0x32, 0x36, 0x33, 0x38, 0x46, 0x41, 0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x35, 0x41, 0x33, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x31, 0x37, 0x35, 0x32,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x42, 0x46, 0x31, 0x36, 0x31, 0x30, 0x42, 0x41,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x37, 0x34, 0x36,
			0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x38, 0x31, 0x42, 0x34, 0x33, 0x38, 0x33, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34,
			0x43, 0x34, 0x34, 0x39, 0x32, 0x39, 0x33, 0x39, 0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x44, 0x34, 0x30, 0x36, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
			0x39, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x43, 0x38, 0x31, 0x42, 0x32, 0x32, 0x43, 0x43,
			0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x34, 0x42, 0x46, 0x31, 0x44, 0x33, 0x34, 0x31, 0x45,
			0x38, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x39, 0x31, 0x44,
			0x44, 0x22, 0x0A, 0x09, 0x7D, 0x2C, 0x0A, 0x09, 0x22, 0x30, 0x22, 0x3A, 0x09, 0x7B, 0x0A, 0x7D,
			0x0A, 0x7D,
		}

		base64str := base64.StdEncoding.EncodeToString(arr)
		ba.WriteBytes([]byte{0x00, 0x69, 0x30, 0x30, 0x34, 0x3A})
		ba.WriteBytes([]byte(base64str))
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x30, 0x00, 0x00})
		ba.WriteString(strings.ToUpper(acc.IOSHardwareInfo.MacAddr))
	} else if acc.Platform == platformAndroid {

	} else {
		return nil
	}

	ret := utils.NewByteArray([]byte{})
	ret.WriteBytes([]byte{0xBE, 0xBC})
	ret.WriteInt32(int32(ba.Length()) + 6)
	ret.WriteBytes(ba.Bytes())

	return ret.Bytes()
}

func (acc *Account) getSaveWBRootInfo() []byte {
	ba := utils.NewByteArray([]byte{})

	if acc.Platform == platformIOS {
		ba.WriteBytes([]byte{0x39, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x31, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00})
		ba.WriteString("Darwin")
		ba.WriteString("Darwin Kernel Version 14.0.0: Sun Mar 29 19:42:54 PDT 2015; root:xnu-2784.20.34~2/RELEASE_ARM64_T7000")
		ba.WriteString("sg_unknown")
		ba.WriteString("iPhone")
		ba.WriteString(acc.IOSHardwareInfo.Model)
		ba.WriteString("zh-Hans")
		ba.WriteString("zh_CN")
		ba.WriteString("Apple")
		ba.WriteString("N61AP")
		ba.WriteString("iPhone")
		ba.WriteString(acc.IOSHardwareInfo.SysVer)
		ba.WriteString("14.0.0")
		ba.WriteBytes([]byte{0x52, 0x0B, 0x03, 0x00, 0x00})
		ba.WriteString("iPhone OS")
		ba.WriteString("0")
		ba.WriteString("16777228")
		ba.WriteString("1")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00})
		ba.WriteString("0")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
		ba.WriteBytes([]byte{0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x31, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00})
		ba.WriteString("-1")
		ba.WriteString("-1")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00})
		ba.WriteString("2")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})

		arr := strings.Split(acc.IOSHardwareInfo.ScreenSize, "*")
		if len(arr) >= 2 {
			ba.WriteString(fmt.Sprintf("%s.000000*%s.000000", arr[0], arr[1]))
		} else {
			ba.WriteString("750.000000*1334.000000")
		}

		ba.WriteString(acc.Account)
		ba.WriteBytes([]byte{0x00, 0x00, 0x00})
		ba.WriteString("中国移动")
		ba.WriteString("2g")
		ba.WriteString(`{"longitude": 0.000000,"altitude": 0.000000,"latitude": 0.000000}`)
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
		ba.WriteString("100")
		ba.WriteBytes([]byte{0x00, 0x00})
		ba.WriteString("123922")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00})
		ba.WriteString("支付宝")
		ba.WriteString("16000")
		ba.WriteBytes([]byte{0x00, 0x00})
		ba.WriteString("1")
		ba.WriteString("")
		ba.WriteString("F03D957A-85F3-4B65-ACB2-FE66C4E94F24")
		ba.WriteString(acc.IOSHardwareInfo.UTDID)
		ba.WriteString("14")
		ba.WriteString("1035988992")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00})
		ba.WriteString(acc.IOSHardwareInfo.WIFIName)
		ba.WriteString(acc.IOSHardwareInfo.WIFIMac)
		ba.WriteBytes([]byte{0x00, 0x00, 0x00})
		ba.WriteString("SensorsAccelerometerGyroMagnetometer")
		ba.WriteString("")
		ba.WriteString("Asia/Shanghai GMT+8")
		ba.WriteBytes([]byte{0x00, 0x00, 0x00, 0x00})
		ba.WriteString("1")
		ba.WriteString("1")
		ba.WriteString("")
	} else if acc.Platform == platformAndroid {

	} else {
		return nil
	}

	ret := utils.NewByteArray([]byte{})
	ret.WriteBytes([]byte{0xBE, 0xBC})
	ret.WriteInt32(int32(ba.Length() + 6))
	ret.WriteBytes(ba.Bytes())

	return ret.Bytes()
}

func (acc *Account) getSaveWBPostData() (string, error) {
	arr1 := acc.getSaveWBArray1()
	if arr1 == nil {
		return "", errSaveWBDataError
	}

	arr2 := acc.getSaveWBMobileInfo()
	if arr2 == nil {
		return "", errSaveWBDataError
	}

	arr3 := acc.getSaveWBRootInfo()
	if arr3 == nil {
		return "", errSaveWBDataError
	}

	arr4 := acc.getSaveWBFileInfo()
	if arr4 == nil {
		return "", errSaveWBDataError
	}

	ba := utils.NewByteArray([]byte{})
	ba.WriteBytes(arr1)
	ba.WriteBytes(arr2)
	ba.WriteBytes(arr3)
	ba.WriteBytes(arr4)

	body := utils.NewByteArray([]byte{})
	body.WriteBytes([]byte{0xBE, 0xBC, 0x00, 0x28})
	body.WriteInt32(int32(ba.Length() + 8))
	body.WriteBytes(ba.Bytes())

	zlibArr, err := utils.ZLibCompress(body.Bytes())
	if err != nil {
		return "", err
	}

	aesArr, err := utils.AESCBCEncrypt(zlibArr,
		[]byte(saveWBAESKey),
		[]byte(saveWBAESIV))

	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(aesArr), nil
}

// PostSaveWB 获取miniwua参数
func (acc *Account) PostSaveWB() error {
	body, err := acc.getSaveWBPostData()
	if err != nil {
		logger.Errorf("[AliPay]SaveWB 获取提交数据失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	req, err := http.NewRequest("POST", urlSaveWB, strings.NewReader(body))
	if err != nil {
		logger.Errorf("[AliPay]SaveWB 生成http请求对象失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	req.Header.Set(headers.ContentType, "text/plain")
	req.Header.Set("keyindex", "wb_sc_int_res_k1")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")

	if acc.Platform == platformIOS {
		req.Header.Set(headers.UserAgent,
			fmt.Sprintf("%s/%s CFNetwork/711.3.18 Darwin/14.0.0",
				utils.URLEncode("支付宝"),
				productVersionIOS))
	} else {
		// 修正其它平台User-Agent
		req.Header.Set(headers.UserAgent,
			fmt.Sprintf("%s/%s CFNetwork/711.3.18 Darwin/14.0.0",
				utils.URLEncode("支付宝"),
				productVersionIOS))
	}

	resp, err := acc.httpClient.Do(req)
	if err != nil {
		logger.Errorf("[AliPay]SaveWB http请求失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	defer resp.Body.Close()
	/*
		data, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			return err
		}

		res := &saveWBResponse{}
		if err := json.Unmarshal(data, &res); err != nil {
			return err
		}
	*/

	res := saveWBResponse{}
	if err := json.NewDecoder(resp.Body).Decode(&res); err != nil {
		logger.Errorf("[AliPay]SaveWB 解码http响应数据失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			err)
		return err
	}

	if res.Payload == "" {
		logger.Errorf("[AliPay]SaveWB payload字段为空, 帐号: %+v, 平台: %+v, res: %+v.",
			acc.Account,
			acc.Platform,
			res)
		return errSaveWBPayloadDataNotFound
	}

	arr, err := base64.StdEncoding.DecodeString(res.Payload)
	if err != nil {
		logger.Errorf("[AliPay]SaveWB payload数据base64解码失败, 帐号: %+v, 平台: %+v, payload: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			res.Payload,
			err)
		return err
	}

	arr, err = utils.AESCBCDecrypt(arr, []byte(saveWBAESKey), []byte(saveWBAESIV))
	if err != nil {
		logger.Errorf("[AliPay]SaveWB 解密payload数据失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			err)
		return err
	}

	payload := saveWBPayload{}
	if err := json.Unmarshal(arr, &payload); err != nil {
		logger.Errorf("[AliPay]SaveWB 反序列化payload数据失败, 帐号: %+v, 平台: %+v, 数据: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			string(arr),
			err)
		return err
	}

	if payload.Code != 200 {
		logger.Errorf("[AliPay]SaveWB payload数据错误, 帐号: %+v, 平台: %+v, 数据: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			string(arr),
			err)
		return errSaveWBPayloadData
	}

	miniwua, err := alipayutils.MiniwuaEncrypt(
		payload.Data.EE,
		[]byte(miniwuaAESKey),
		[]byte(miniwuaAESIV))
	if err != nil {
		logger.Errorf("[AliPay]SaveWB Miniwua加密失败, 帐号: %+v, 平台: %+v, miniwua: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			payload.Data.EE,
			err)
		return err
	}

	acc.Miniwua = miniwua
	acc.UMID = payload.Data.STID
	acc.UUID = payload.Data.UUID

	if err := acc.save(); err != nil {
		logger.Warnf("[AliPay]SaveWB 保存用户数据失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account,
			acc.Platform,
			err)
	}

	logger.Infof("[AliPay]SaveWB返回成功, 帐号: %+v, 平台: %+v, miniwua: %+v, UMID: %+v, UUID: %+v.",
		acc.Account,
		acc.Platform,
		acc.Miniwua,
		acc.UMID,
		acc.UUID)

	return nil
}

func (acc *Account) getPostMGWData() []byte {
	ba := utils.NewByteArray([]byte{})
	if acc.Platform == platformIOS {
		//
		dict := make(map[string]interface{})
		dict["data"] = map[string]string{
			"namespace":   "com.alipay.mobilecashier",
			"api_name":    "com.alipay.quickpay",
			"api_version": "5.7.1",
		}

		j, err := json.Marshal(&dict)
		if err != nil {
			logger.Errorf("[AliPay]PostMGW数据序列化错误: %+v, 帐号: %+v, 平台: %+v, 数据: %+v.",
				err, acc.Account, acc.Platform, dict)
			return nil
		}

		l := fmt.Sprintf("%.5d", len(j))
		ba.WriteBytes([]byte(l))
		ba.WriteBytes(j)

		//
		buf, _ := utils.RSAEncrypt([]byte(tripleDESKey), rsaTripleDESKey)
		l = fmt.Sprintf("%.5d", len(buf))
		ba.WriteBytes([]byte(l))
		ba.WriteBytes(buf)

		//
		action := map[string]interface{}{
			"action": map[string]string{
				"type":   "cashier",
				"method": "updateTidInfo",
			},
			"pa":            fmt.Sprintf("%s;%s", bundleIDIOS, productVersionIOS),
			"external_info": `bizcontext={"requestScene":"INIT"}`,
			"ua": fmt.Sprintf("10.8.12(i %s;1;%s;;;%s;%s;wifi;02:00:00:00:00:00;1;;%s)(1)(%s)",
				acc.IOSHardwareInfo.SysVer,
				acc.IOSHardwareInfo.ClientKey,
				acc.IOSHardwareInfo.VIMEI,
				acc.IOSHardwareInfo.VIMSI,
				acc.IOSHardwareInfo.IPhoneName,
				acc.ApdidToken),
			"bp":             "(i530)",
			"tid":            acc.TID,
			"lang":           "zh-Hans",
			"new_client_key": utils.NewRandString(10, false),
			"trdfrom":        "1",
			"has_alipay":     true,
			"utdid":          acc.IOSHardwareInfo.APDID,
		}

		j, err = json.Marshal(&action)
		if err != nil {
			logger.Errorf("[AliPay]PostMGW数据序列化错误: %+v, 帐号: %+v, 平台: %+v, 数据: %+v.",
				err, acc.Account, acc.Platform, action)
			return nil
		}

		key := []byte(tripleDESKey)
		buf, err = utils.TripleDESECBEncrypt(j, key)
		if err != nil {
			logger.Errorf("[AliPay]PostMGW数据加密错误: %+v, 帐号: %+v, 平台: %+v, 数据: %+v.",
				err, acc.Account, acc.Platform, buf)
			return nil
		}

		l = fmt.Sprintf("%.5d", len(buf))
		ba.WriteBytes([]byte(l))
		ba.WriteBytes(buf)

	} else if acc.Platform == platformAndroid {

	}

	return ba.Bytes()
}

func (acc *Account) postMGW() {
	body := acc.getPostMGWData()
	if body == nil {
		return
	}

	req, err := http.NewRequest("POST", urlMGWHTM, bytes.NewReader(body))
	if err != nil {
		logger.Errorf("[AliPay]postMGW 生成http请求对象失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return
	}

	req.Header.Set(headers.ContentType, "application/octet-stream")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set("Msp-Gzip", "true")
	req.Header.Set("Operation-Type", "alipay.msp.cashier.dispatch.bytes")

	// User-Agent
	if acc.Platform == platformIOS {
		req.Header.Set(headers.UserAgent,
			fmt.Sprintf("%s/%s CFNetwork/711.3.18 Darwin/14.0.0",
				utils.URLEncode("支付宝"),
				productVersionIOS))
	} else {

	}

	// Cookie
	req.AddCookie(&http.Cookie{
		Name:  "devKeySet",
		Value: fmt.Sprintf(`{"apdidToken":"%s"}`, acc.ApdidToken),
	})

	cookie := cookiemgr.GetUserCookie(alipayCookiePrefix, acc.Account, acc.Platform)
	zone := cookie.GetCookie("zone")
	if zone != "" {
		req.AddCookie(&http.Cookie{
			Name:  "zone",
			Value: zone,
		})
	}

	resp, err := acc.httpClient.Do(req)
	if err != nil {
		logger.Errorf("[AliPay]postMGW http 请求失败, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return
	}

	defer resp.Body.Close()

	logger.Infof("[AliPay]postMGW成功, 帐号: %+v, 平台: %+v.", acc.Account, acc.Platform)

	for _, v := range resp.Cookies() {
		cookie.SetCookie(v.Name, v.Value, false)
	}

	cookie.Save()
}

func httpGetBody(resp *http.Response) (string, error) {
	// gzip解压
	body := resp.Body
	if resp.Header.Get("Content-Encoding") == "gzip" {
		var err error
		if body, err = gzip.NewReader(body); err != nil {
			return "", err
		}
	}

	data, err := ioutil.ReadAll(body)
	if err != nil {
		return "", err
	}

	// 如果有gbk编码转成utf8
	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "GBK") || strings.Contains(ct, "gbk") {
		var err error
		if data, err = utils.GBK2UTF8(data); err != nil {
			return "", err
		}
	}

	return string(data), nil
}

func (acc *Account) httpGet(c http.Client, url, referer string) (string, error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", err
	}

	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-CN,en-US;q=0.8")
	req.Header.Set("ts", utils.GetTimeStrEx())
	req.Header.Set(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	req.Header.Set(headers.UserAgent, acc.getUserAgent())
	req.Header.Set("X-Alipay-Client-Session", "check")
	if referer != "" {
		req.Header.Set(headers.Referer, referer)
	}

	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()

	return httpGetBody(resp)
}

func (acc *Account) httpPost(c http.Client, url, referer, body string, postForm bool) (string, error) {
	req, err := http.NewRequest("POST", url, strings.NewReader(body))
	if err != nil {
		return "", err
	}

	req.Header.Set(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-CN,en-US;q=0.8")
	req.Header.Set("ts", utils.GetTimeStrEx())
	req.Header.Set(headers.Accept, "application/json, text/javascript")
	req.Header.Set("X-Requested-With", "XMLHttpRequest")
	req.Header.Set(headers.UserAgent, acc.getUserAgent())

	if postForm {
		req.Header.Set(headers.ContentType, "application/x-www-form-urlencoded;charset=UTF-8")
	}

	if referer != "" {
		req.Header.Set(headers.Referer, referer)
	}

	req.Header.Set("X-Alipay-Client-Session", "check")

	resp, err := c.Do(req)
	if err != nil {
		return "", err
	}

	defer resp.Body.Close()

	return httpGetBody(resp)
}

func extractSecurityID(u string) string {
	u, _ = url.PathUnescape(u)
	start := strings.Index(u, "SecurityId=")
	if start > -1 {
		end := strings.Index(u[start:], "&")
		if end > -1 {
			return u[start+11 : start+end]
		}
	}
	return ""
}

func extractToken(s string) string {
	prefix := "token: '"
	start := strings.Index(s, prefix)
	if start == -1 {
		prefix = "token : '"
		start = strings.Index(s, prefix)
	}

	if start > -1 {
		end := strings.Index(s[start:], "',")
		if end > -1 {
			return s[start+len(prefix) : start+end]
		}
	}

	return ""
}

func extractVerifyID(s string) string {
	start := strings.Index(s, "verifyID: '")
	if start > -1 {
		end := strings.Index(s[start:], "',")
		if end > -1 {
			return s[start+11 : start+end]
		}
	}
	return ""
}

func extractSmsToken(s string) string {
	s = html.UnescapeString(s)
	offset := len(`"text":"短信验证码","token":"`)
	start := strings.Index(s, `"text":"短信验证码"`)
	if start > -1 {
		end := strings.Index(s[start:], `"}`)
		if end > -1 {
			return s[start+offset : start+end]
		}
	}
	return ""
}

func isNeedFaceScan(s string) bool {
	if strings.Contains(s, "需刷脸以确保是") &&
		strings.Contains(s, "由于您在不常用的设备上登录") &&
		strings.Contains(s, "hasOtherFlows: 'false'") {
		return true
	}
	return false
}

func (acc *Account) requestSMSCode() *SMSResult {
	c := http.Client{
		Transport: acc.httpClient.Transport,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) > 10 {
				return http.ErrUseLastResponse
			}

			//提取securityID
			securityID := extractSecurityID(req.URL.String())
			if securityID != "" {
				acc.smsSecurityID = securityID
			}

			return nil
		},
		Jar:     acc.jar,
		Timeout: time.Millisecond * httpTimeout,
	}

	if acc.smsSendURL != "" && acc.smsRefererURL != "" {
		body, err := acc.httpGet(c, acc.smsSendURL, acc.smsRefererURL)
		if err != nil {
			logger.Errorf("[AliPay]requestSMSCode重发验证码操作失败, 帐号: %+v, 错误: %+v.",
				acc.Account, err)

			return &SMSResult{
				Code: smsCodeResendSMSFail,
				Msg:  smsMsgResendSMSFail,
			}
		}

		logger.Infof("[AliPay]requestSMSCode重发验证码, 帐号: %+v, 结果: %+v.",
			acc.Account, strings.Contains(body, smsSendedText))
	}

	url := acc.smsCodeH5Url + "&callbackUrl=" + url.PathEscape(urlSMSH5Callback)
	body, err := acc.httpGet(c, url, "")

	logger.Debugf("[AliPay]requestSMSCode发送验证码返回: %+v.", body)

	if err != nil {
		logger.Errorf("[AliPay]requestSMSCode打开短信验证码发送页面失败, 帐号: %+v, 错误: %+v.",
			acc.Account, err)

		return &SMSResult{
			Code: smsCodeOpenH5Fail,
			Msg:  smsMsgOpenH5Fail,
		}

	}

	acc.smsToken = extractToken(body)
	acc.smsVerifyID = extractVerifyID(body)

	logger.Infof("[AliPay]requestSMSCode step1, 帐号: %+v, SecurityID: %+v, Token: %+v, VerifyID: %+v.",
		acc.Account, acc.smsSecurityID, acc.smsToken, acc.smsVerifyID)

	// 要刷脸登录...
	if isNeedFaceScan(body) {
		logger.Infof("[AliPay]requestSMSCode需要刷脸登录, 帐号: %+v.", acc.Account)
		return &SMSResult{
			Code: smsCodeNeedFaceScan,
			Msg:  smsMsgNeedFaceScan,
		}
	}

	// 第一步没有成功要尝试后续步骤
	if !strings.Contains(body, smsSendedText) {
		// 第二步切换页面操作
		if !strings.Contains(body, "接收短信验证码") {
			url := fmt.Sprintf(urlSMSCheckMobileVerify, acc.smsToken, acc.smsVerifyID)

			body, err := acc.httpGet(c, url, "")
			if err != nil {
				logger.Errorf("[AliPay]requestSMSCode切换到短信验证码失败, 帐号: %+v, 错误: %+v.",
					acc.Account, err)

				return &SMSResult{
					Code: smsCodeChangeVerifyTypeFail,
					Msg:  smsMsgChangeVerifyTypeFail,
				}
			}

			logger.Debugf("[AliPay]requestSMSCode 切换到短信验证码页面: %+v.", body)

			acc.smsToken = extractSmsToken(body)
			if acc.smsToken == "" {
				logger.Infof("[AliPay]requestSMSCode获取短信验证码Token失败, 帐号: %+v.", acc.Account)

				return &SMSResult{
					Code: smsCodeGetTokenFail,
					Msg:  smsMsgGetTokenFail,
				}
			}

			logger.Infof("[AliPay]requestSMSCode切换短信验证页面, 帐号: %+v, Token: %+v.",
				acc.Account, acc.smsToken)
		}

		// 第三步发送操作
		url := fmt.Sprintf(urlSMSView, acc.smsVerifyID, acc.smsToken)
		body, err := acc.httpGet(c, url, "")
		if err != nil {
			logger.Errorf("[AliPay]requestSMSCode发送短信验证码操作失败, 帐号: %+v, 错误: %+v.",
				acc.Account, err)

			return &SMSResult{
				Code: smsCodeSendSMSFail,
				Msg:  smsMsgSendSMSFail,
			}
		}

		logger.Debugf("[AliPay]requestSMSCode发送短信验证码操作结果: %+v.", err)

		logger.Infof("[AliPay]requestSMSCode step3 帐号: %+v, 短信发送结果: %+v.",
			acc.Account, strings.Contains(body, smsSendedText))
	}

	acc.smsRefererURL = fmt.Sprintf(urlSMSView, acc.smsVerifyID, acc.smsToken)
	acc.smsSendURL = fmt.Sprintf(urlSMSViewProduct, acc.smsToken, acc.smsVerifyID)

	logger.Infof("[AliPay]requestSMSCode发送短信验证码成功, 帐号: %+v.", acc.Account)
	return &SMSResult{
		Code: smsCodeSendSuccess,
		Msg:  smsMsgSendSuccess,
	}
}

func (acc *Account) verifySMSCode(code string) *SMSResult {
	c := http.Client{
		Transport: acc.httpClient.Transport,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
		Jar: acc.jar,
	}

	body := ""
	smsSimple := false
	// 长度为4的为简单验证码
	if len(code) == 4 {
		body = fmt.Sprintf("verifyId=%s&group=h5&token=%s&product=ACCOUNT_BINDING_SMS_SIMPLE&ACCOUNT_BINDING_SMS_SIMPLE=%s",
			utils.URLEncode(acc.smsVerifyID),
			utils.URLEncode(acc.smsToken),
			utils.URLEncode(fmt.Sprintf(`{"ackCode":"%s"}`, code)))
		smsSimple = true
		logger.Infof("[AliPay]verifySMSCode使用简单验证码: %s.", code)
	} else {
		body = fmt.Sprintf("verifyId=%s&group=h5&token=%s&product=ACCOUNT_BINDING_SMS&ACCOUNT_BINDING_SMS=%s",
			utils.URLEncode(acc.smsVerifyID),
			utils.URLEncode(acc.smsToken),
			utils.URLEncode(fmt.Sprintf(`{"ackCode":"%s"}`, code)))
		smsSimple = false
	}

	body, err := acc.httpPost(c, urlSMSVerify, acc.smsRefererURL, body, true)
	if err != nil {
		logger.Errorf("[AliPay]verifySMSCode验证码校验请求错误, 帐号: %+v, 错误: %+v.",
			acc.Account, err)

		return &SMSResult{
			Code: smsCodeVerifyError,
			Msg:  smsMsgVerifyError,
		}
	}

	logger.Debugf("[AliPay]verifySMSCode返回: %+v.", string(body))

	result := smsVerifyResult{}
	//logger.Infof("[AliPay]verifySMSCode返回, 帐号: %+v, 结果: %+v.", acc.Account, result)

	if err := json.Unmarshal([]byte(body), &result); err != nil {
		logger.Errorf("[AliPay]verifySMSCode验证码校验结果反序列化失败, 帐号: %+v, 错误: %+v.",
			acc.Account, err)

		return &SMSResult{
			Code: smsCodeVerifyResultDecodeFail,
			Msg:  smsMsgVerifyResultDecodeFail,
		}
	}

	if smsSimple {
		if !result.AccountBindingSMSSimple.ProdSuccess {
			logger.Infof("[AliPay]verifySMSCode验证码校验失败1, 帐号: %+v, 信息: %+v.",
				acc.Account, result.AccountBindingSMS.Msg)
			return &SMSResult{
				Code: smsCodeVerifyFail,
				Msg:  result.AccountBindingSMS.Msg,
			}
		}
	} else {
		if !result.AccountBindingSMS.ProdSuccess {
			logger.Infof("[AliPay]verifySMSCode验证码校验失败2, 帐号: %+v, 信息: %+v.",
				acc.Account, result.AccountBindingSMS.Msg)
			return &SMSResult{
				Code: smsCodeVerifyFail,
				Msg:  result.AccountBindingSMS.Msg,
			}
		}
	}

	logger.Infof("[AliPay]verifySMSCode验证码校验成功, 帐号: %+v.", acc.Account)

	return &SMSResult{
		Code: smsCodeVerifySuccess,
		Msg:  smsMsgVerifySuccess,
	}

}

func (acc *Account) getQRScanToken(s string) (string, string, error) {
	doc, err := goquery.NewDocumentFromReader(strings.NewReader(s))
	if err != nil {
		return "", "", err
	}

	token := ""
	securityID := ""

	if el := doc.Find("input[name='_form_token']"); el != nil {
		token, _ = el.Attr("value")
	}

	if el := doc.Find("input[name='securityId']"); el != nil {
		securityID, _ = el.Attr("value")
	}

	if token == "" || securityID == "" {
		return "", "", errors.New("获取token失败")
	}

	return token, securityID, nil
}

func (acc *Account) qrScanNext(url string) error {
	c := &http.Client{
		Transport: acc.httpClient.Transport,
		Jar:       acc.jar,
	}

	ts := utils.GetTimeStrEx()
	sign := utils.MD5String(fmt.Sprintf("wallet&%s&ts=%s", url, ts))

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logger.Errorf("[AliPay]qrScanNext创建http请求错误: %+v.", err)
		return errors.New("创建http请求失败")
	}

	req.Header.Add(headers.Accept, "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	req.Header.Add(headers.UserAgent, acc.getUserAgent())
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-CN,en-US;q=0.8")
	req.Header.Add("ts", ts)
	req.Header.Add("X-Alipay-Client-Session", "check")
	req.Header.Add("sign", sign)
	req.Header.Add(headers.Cookie, acc.conn.getCookie())

	body, err := utils.DoHTTP(c, req)
	if err != nil {
		logger.Errorf("[AliPay]qrScanNext HTTP操作错误: %+v.", err)
		return errors.New("打开确认页面错误")
	}

	if !strings.Contains(body, "enterFlow") {
		token, securityID, err := acc.getQRScanToken(body)
		if err != nil {
			if strings.Contains(body, "二维码已失效") || strings.Contains(body, "获取新的二维码") {
				logger.Warn("[AliPay]qrScanNext二维码已过期.")
				return errors.New("二维码已过期")
			}

			logger.Warnf("[AliPay]qrScanNext无法获取token或securityID, body: %+v", body)
			return errors.New("无法获取确认登录Token")
		}

		return acc.postScanResult(url, token, securityID)
	}

	return nil
}

func (acc *Account) postScanResult(referer, token, securityID string) error {
	val := url.Values{}
	val.Add("_form_token", token)
	val.Add("securityId", securityID)

	c := http.Client{
		Transport: acc.httpClient.Transport,
		Jar:       acc.jar,
	}

	body, err := acc.httpPost(c, "https://mobile.alipay.com/scanResult.htm", referer, val.Encode(), true)
	if err != nil {
		logger.Errorf("[AliPay]postScanResult HTTP操作错误: %+v.", err)
		return errors.New("点击确认登录操作失败")
	}

	logger.Debugf("[AliPay]postScanResult返回: %+v.", body)

	return nil
}
