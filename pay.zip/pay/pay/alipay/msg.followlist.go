package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendFollowList() error {
	req := func() *alipaymsg.FollowListReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.FollowListReq{
				Terminal:      proto.String("iPhone"),
				ClientVersion: proto.String(productVersionIOS),
				ChanelPackage: proto.String("apple-iphone"),
				PageNum:       proto.Int32(1),
				PageSize:      proto.Int32(50),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.FollowListReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]FollowListReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_QUERYUSERFOLLOWER, c.onFollowList, &mmtp, data, true)
}

func (c *AliConn) onFollowList(op string, data []byte, param interface{}) {
	logger.Debug("onFollowList")
}
