package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendProtoSyncOpCode4011(value string) error {
	req := &alipaymsg.ProtoSyncOpCode4011{
		BizType:         proto.String("CONFIGSDK-NOTIFY"),
		Key:             proto.String("ConfigArrivalCount" + value),
		Version:         proto.String(""),
		ClinetLocalTime: proto.Int64(utils.GetTimeStampEx()),
	}

	pd, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]ProtoSyncOpCode4011序列化错误: %+v.", err)
		return err
	}

	mmtp := &alipaymsg.MmtpHead{
		DataFrameChannel: proto.Uint32(2),
	}

	data := []byte{0x06, 0x0F, 0xAB}
	data = append(data, pd...)

	c.sendMessage(mmtp, nil, data)

	return nil
}
