package alipay

import (
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/alipayutils"
	"pay/utils/logger"
	"strconv"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) getRdsRequestMessage() *alipaymsg.RdsRequestMessage {
	result := func() *alipaymsg.RdsRequestMessage {
		acc := c.acc
		getTimeStampExStr := func() string {
			return fmt.Sprintf("%d", utils.GetTimeStampEx())
		}
		if acc.Platform == platformIOS {
			// RdsRequestMessageSdkDevSensorSensorData
			sensorData := &alipaymsg.RdsRequestMessageSdkDevSensorSensorData{
				Accelerometer: []string{
					"0.022034,-0.438721,-0.857651",
					"0.102615,-0.510162,-0.843765",
					"0.075546,-0.424118,-0.868301",
					"0.185043,-0.509689,-0.787964",
				},
				Gravity: []string{
					"0.024317,-0.455565,-0.889870",
					"0.066415,-0.470221,-0.880046",
					"0.108100,-0.490622,-0.864641",
					"0.147916,-0.528270,-0.836093",
				},
				Gyroscope: []string{
					"-0.013306,0.194209,-0.213023",
					"0.035594,0.241977,-0.507900",
					"0.481758,0.195506,-0.506234",
					"0.368564,0.181365,-0.239597",
				},
				Magnetometer: []string{
					"-25.583588,167.203949,-482.183350",
					"-25.929306,166.163254,-483.835754",
					"-28.695099,166.510162,-486.149200",
					"-32.498062,164.775681,-487.471130",
				},
			}

			// RdsRequestMessageSdkDevSensor
			devSensor := &alipaymsg.RdsRequestMessageSdkDevSensor{
				SensorData: sensorData,
				T:          proto.Int64(utils.GetTimeStampEx()),
			}

			// RdsRequestMessageSdkUsrAD
			usrAd1 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				Pr: proto.String("-"),
				T:  proto.String(getTimeStampExStr()),
			}

			// RdsRequestMessageSdkUsrAction
			usrAction1 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd1},
				Cn:   proto.String("-"),
				Et:   proto.String("pe"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("0"),
				Type: proto.String("1"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd2 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
				F: proto.Bool(true),
			}

			usrAction2 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd2},
				Cn:   proto.String("UsernameET"),
				Et:   proto.String("fc"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("1"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd3 := []*alipaymsg.RdsRequestMessageSdkUsrAD{}
			for i := 0; i < len(acc.Account); i++ {
				sub := (len(acc.Account) - i) * utils.RandInt(800, 1300)
				usrAd3 = append(usrAd3, &alipaymsg.RdsRequestMessageSdkUsrAD{
					T:   proto.String(strconv.Itoa(int(utils.GetTimeStampEx()) - sub - 5000)),
					Key: proto.String(acc.Account[:i+1]),
				})
			}

			usrAction3 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   usrAd3,
				Cn:   proto.String("UsernameET"),
				Et:   proto.String("ei"),
				Num:  proto.String(fmt.Sprintf("%d", len(usrAd3))),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("2"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd4 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
				F: proto.Bool(false),
			}

			usrAction4 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd4},
				Cn:   proto.String("UsernameET"),
				Et:   proto.String("fc"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("3"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd5 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
				F: proto.Bool(true),
			}

			usrAction5 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd5},
				Cn:   proto.String("PwdET"),
				Et:   proto.String("fc"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("4"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd6 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
				X: proto.String("265"),
				Y: proto.String("20"),
			}

			usrAction6 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd6},
				Cn:   proto.String("LoginBtn"),
				Et:   proto.String("st"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("5"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd7 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
				F: proto.Bool(false),
			}

			usrAction7 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd7},
				Cn:   proto.String("PwdET"),
				Et:   proto.String("fc"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("6"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrAd8 := &alipaymsg.RdsRequestMessageSdkUsrAD{
				T: proto.String(getTimeStampExStr()),
			}

			usrAction8 := &alipaymsg.RdsRequestMessageSdkUsrAction{
				Ad:   []*alipaymsg.RdsRequestMessageSdkUsrAD{usrAd8},
				Cn:   proto.String("LoginBtn"),
				Et:   proto.String("cc"),
				Num:  proto.String("1"),
				Pn:   proto.String("LoginPage"),
				Seq:  proto.String("7"),
				Type: proto.String("0"),
				T:    proto.String(getTimeStampExStr()),
			}

			usrUa := &alipaymsg.RdsRequestMessageSdkUsrUa{
				Action: []*alipaymsg.RdsRequestMessageSdkUsrAction{
					usrAction1,
					usrAction2,
					usrAction3,
					usrAction4,
					usrAction5,
					usrAction6,
					usrAction7,
					usrAction8,
				},
				Num: proto.String("8"),
				T:   proto.String(getTimeStampExStr()),
			}

			nativeEnv := &alipaymsg.RdsRequestMessageNativeEnv{
				Em:         proto.Bool(false),
				Rep:        proto.Bool(true),
				Root:       proto.Bool(true),
				Binaryhash: proto.String("e4c5c586d1330aff41235b5166b43c23"),
				Repiehash:  proto.String("2403ba087627f2740e00ab86cf7dc8fe"),
				Safe:       proto.String("22"),
				Sign:       proto.String("CC YUN"),
				Signhash:   proto.String("b685ef290ee614a2f95d90c47b3b350e"),
				Repie: []string{
					"AlipayWallet",
					"MobileSubstrate.dylib",
					"RevealServer",
					"SubstrateLoader.dylib",
					"libcycript.dylib",
					"libsubstrate.dylib",
				},
			}

			sdkDev := &alipaymsg.RdsRequestMessageSdkDev{
				Apdid:  proto.String(acc.IOSHardwareInfo.APDID),
				Gss:    proto.String(""),
				Gss2:   proto.String(""),
				H:      proto.String(fmt.Sprintf("%d", acc.GetScreenHeight())),
				Idfa:   proto.String(acc.IOSHardwareInfo.IDFA),
				Imei:   proto.String(""),
				Imsi:   proto.String(""),
				Mac:    proto.String(""),
				Px:     proto.String(acc.IOSHardwareInfo.ScreenSize),
				Sensor: devSensor,
				Tid:    proto.String(acc.TID),
				Umid:   proto.String(acc.UMID),
				Usb:    proto.String(""),
				Utdid:  proto.String(acc.IOSHardwareInfo.UTDID),
				W:      proto.String(fmt.Sprintf("%d", acc.GetScreenWidth())),
				Wi:     proto.String(""),
			}

			sdkEnv := &alipaymsg.RdsRequestMessageSdkEnv{
				Asdk:         proto.String(""),
				Board:        proto.String(""),
				Brand:        proto.String(""),
				Displayid:    proto.String(""),
				Em:           proto.Bool(false),
				Incremental:  proto.String(""),
				Kerver:       proto.String(""),
				Manufacturer: proto.String(""),
				Model:        proto.String(acc.IOSHardwareInfo.Model),
				Name:         proto.String(acc.IOSHardwareInfo.IPhoneName),
				Os:           proto.String("iOS"),
				Pf:           proto.String("0"),
				Pm:           proto.String(""),
				Pn:           proto.String("2"),
				Processor:    proto.String(""),
				Qemu:         proto.String(""),
				OsRelease:    proto.String(acc.IOSHardwareInfo.SysVer),
				Root:         proto.Bool(true),
				Tags:         proto.String(""),
				Device:       proto.String(""),
			}

			sdkLoc := &alipaymsg.RdsRequestMessageSdkLoc{
				Acc:     proto.String(""),
				Active:  proto.Bool(true),
				Bssid:   proto.String(acc.IOSHardwareInfo.MacAddr),
				Carrier: proto.String("CHINA MOBILE"),
				Cid:     proto.String(""),
				La:      proto.String(""),
				Lac:     proto.String(""),
				Lo:      proto.String(""),
				Mcc:     proto.String("460"),
				Mnc:     proto.String("00"),
				Nettype: proto.String("WIFI"),
				Ssid:    proto.String(acc.IOSHardwareInfo.WIFIName),
				T:       proto.Int64(0),
			}

			sdkUsr := &alipaymsg.RdsRequestMessageSdkUsr{
				AppKey:  proto.String(appKeyIOS),
				AppName: proto.String("AlipayWallet"),
				AppVer:  proto.String(productVersionIOS),
				PubKey:  proto.String(""),
				SdkName: proto.String("aliusersdk"),
				SdkVer:  proto.String("2.0.0.6"),
				Ua:      usrUa,
			}

			native := &alipaymsg.RdsRequestMessageNative{
				Env: nativeEnv,
			}

			sdk := &alipaymsg.RdsRequestMessageSdk{
				Dev: sdkDev,
				Env: sdkEnv,
				Loc: sdkLoc,
				Usr: sdkUsr,
			}

			taobao := &alipaymsg.RdsRequestMessageTaobao{
				Version: proto.String("3.0"),
				Wua:     proto.String(acc.Miniwua),
			}

			extInfo := map[string]interface{}{
				"appInfo": map[string]interface{}{
					"resign":      0,
					"debug":       3,
					"appEncrypt":  false,
					"personSing":  true,
					"Injuctplugs": false,
					"hook":        0,
					"restict":     false,
					"pie":         true,
					"memoryplug":  "MobileSubstrate.dylib,SubstrateLoader.dylib",
					"rebuild":     0,
				},
				"deviceInfo": map[string]interface{}{
					"process":     "PPHelperLaunchd,vmd,seld,discoveryd,fairplayd.H2,nanoregistryd,discoveryd_helpe,biometrickitd,nanoregistrylaun,nfcd,",
					"logintm":     utils.GetTimeStamp(),
					"vpn":         false,
					"Jalibreaktm": 1527240741,
					"uname":       "Darwin Kernel Version 14.0.0: Sun Mar 29 19:42:54 PDT 2015; root:xnu-2784.20.34~2\\/RELEASE_ARM64_T7000",
					"emulator":    false,
				},
				"scanInfo": []string{},
			}

			extInfoJSON, _ := json.Marshal(&extInfo)

			return &alipaymsg.RdsRequestMessage{
				Native: native,
				Sdk:    sdk,
				Taobao: taobao,
				Extra2: proto.String(string(extInfoJSON)),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.RdsRequestMessage{}
		}
		return nil
	}()

	return result
}

func (c *AliConn) sendUnifyLogin(token, securityID string) error {
	acc := c.acc
	loginPwd := ""
	alipayEnvJSON := ""
	validateType := 8

	if securityID == "" {
		pwd, err := alipayutils.PasswordEncrypt(acc.GetPassword(), rsaPassword)
		if err != nil {
			logger.Errorf("[AliConn]UnifyLogin 登录密码加密错误: %+v, 帐号: %+v, 平台: %+v.",
				err, acc.Account, acc.Platform)
		}
		loginPwd = pwd
		validateType = 7
		alipayEnvJSON = func() string {
			if token == "" && securityID == "" {
				rds := c.getRdsRequestMessage()
				rdsBuffer, err := proto.Marshal(rds)
				if err == nil {
					rdsBuffer, _ = utils.GZipCompress(rdsBuffer)
					dic := map[string]string{
						"version": "4",
						"data":    alipayutils.EncryptAndSign(rdsBuffer, rdsRequestMessageKey),
					}
					json, err := json.Marshal(&dic)
					if err == nil {
						return string(json)
					}
				} else {
					logger.Errorf("[AliConn]序列化RdsRequestMessage错误: %+v, 数据: %+v.", err, rds)
				}
			}

			return ""
		}()
	}

	apdidJSON := fmt.Sprintf(`{"apdidToken":"%s"}`, acc.ApdidToken)

	ep := func() string {
		if acc.Platform == platformIOS {
			dic := map[string]string{
				"apdid":        acc.IOSHardwareInfo.APDID,
				"netType":      "WIFI",
				"terminalName": acc.IOSHardwareInfo.IPhoneName,
				"devKeySet":    apdidJSON,
			}

			epJSON, err := json.Marshal(&dic)
			if err != nil {
				return ""
			}

			return string(epJSON)
		} else if acc.Platform == platformAndroid {
			return ""
		}
		return ""
	}()

	appData := func() []*alipaymsg.KeyValuePairs {
		if acc.Platform == platformIOS {
			return []*alipaymsg.KeyValuePairs{
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("productId"),
					Value: proto.String(productIDIOS),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("mspTid"),
					Value: proto.String(acc.TID),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("userAgent"),
					Value: proto.String(acc.IOSHardwareInfo.Model),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("walletClientKey"),
					Value: proto.String(acc.IOSHardwareInfo.ClientKey),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("mspImei"),
					Value: proto.String(acc.IOSHardwareInfo.IMEI),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("mac"),
					Value: proto.String(acc.IOSHardwareInfo.MacAddr),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("walletTid"),
					Value: proto.String(acc.TID),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("mspImsi"),
					Value: proto.String(acc.IOSHardwareInfo.IMSI),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("mspClientKey"),
					Value: proto.String(acc.IOSHardwareInfo.ClientKey),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("vimsi"),
					Value: proto.String(acc.IOSHardwareInfo.VIMSI),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("externParams"),
					Value: proto.String(ep),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("channels"),
					Value: proto.String("apple-iphone"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("clientId"),
					Value: proto.String(fmt.Sprintf("%s|%s", acc.IOSHardwareInfo.IMSI, acc.IOSHardwareInfo.IMEI)),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("osVersion"),
					Value: proto.String(acc.IOSHardwareInfo.SysVer),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("terminalName"),
					Value: proto.String(acc.IOSHardwareInfo.IPhoneName),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("productVersion"),
					Value: proto.String(productVersionIOS),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("vimei"),
					Value: proto.String(acc.IOSHardwareInfo.VIMEI),
				},
			}
		} else if acc.Platform == platformAndroid {
			return []*alipaymsg.KeyValuePairs{}
		}
		return nil
	}()

	//edge
	ba := utils.NewByteArray([]byte{})
	ba.SetEndian(binary.LittleEndian)
	ba.WriteBytes([]byte{0x28, 0x00})
	ba.WriteUInt32(uint32(utils.GetTimeStamp()))
	ba.WriteBytes([]byte{0x01, 0x00, 0x00, 0x00, 0x01})
	ba.WriteUInt32(uint32(utils.GetTimeStamp() - 11))
	ba.WriteBytes([]byte{0x00, 0x00, 0x00})

	edgeData := ""
	if arr, err := utils.AESCBCEncrypt(ba.Bytes(), aesEdgeDataKey, aesEdgeDataIV); err == nil {
		edgeData = base64.StdEncoding.EncodeToString(arr)
	} else {
		logger.Errorf("[AliConn]UnfiyLoginReq 加密edge数据错误: %+v.", err)
	}

	externParams := func() []*alipaymsg.KeyValuePairs {
		if acc.Platform == platformIOS {
			r := []*alipaymsg.KeyValuePairs{
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("netType"),
					Value: proto.String("WIFI"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("afterLoginSyncConfig"),
					Value: proto.String(`{"faceStatus":"N"}`),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("apdidDowngrade"),
					Value: proto.String("N"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("edgeData"),
					Value: proto.String(edgeData),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("devKeySet"),
					Value: proto.String(apdidJSON),
				},
			}
			return r
		} else if acc.Platform == platformAndroid {
			return []*alipaymsg.KeyValuePairs{}
		}
		return nil
	}()

	if securityID != "" && externParams != nil {
		if len(externParams) > 3 {
			s := externParams[:3]
			e := externParams[3:]
			i := &alipaymsg.KeyValuePairs{
				Key:   proto.String("securityId"),
				Value: proto.String(securityID),
			}

			externParams = append(s, i)
			externParams = append(externParams, e...)
		}
	}

	req := func() *alipaymsg.UnifyLoginReq {
		if acc.Platform == platformIOS {
			return &alipaymsg.UnifyLoginReq{
				LoginId:        proto.String(acc.Account),
				AppId:          proto.String(appIDIOS),
				AppKey:         proto.String(appKeyIOS),
				LoginType:      proto.Int32(1),
				ValidateType:   proto.Int32(int32(validateType)),
				Scene:          proto.String(""),
				LoginPwd:       proto.String(loginPwd),
				SsoToken:       proto.String(""),
				SignData:       proto.String(""),
				CheckCodeId:    proto.String(""),
				CheckCode:      proto.String(""),
				Apdid:          proto.String(acc.IOSHardwareInfo.APDID),
				Utdid:          proto.String(acc.IOSHardwareInfo.UTDID),
				Tid:            proto.String(acc.TID),
				Ttid:           proto.String(""),
				ProductId:      proto.String(productIDIOS),
				ProductVersion: proto.String(productVersionIOS),
				UmidToken:      proto.String(acc.UMID),
				Imsi:           proto.String(acc.IOSHardwareInfo.IMSI),
				Imei:           proto.String(acc.IOSHardwareInfo.IMEI),
				Channel:        proto.String(""),
				ClientType:     proto.String(""),
				UserAgent:      proto.String(""),
				ScreenWidth:    proto.Int32(int32(acc.GetScreenWidth())),
				ScreenHeight:   proto.Int32(int32(acc.GetScreenHeight())),
				MobileBrand:    proto.String("Apple"),
				MobileModel:    proto.String("CHINA MOBILE"),
				AccessPoint:    proto.String(""),
				ClientPosition: proto.String(""),
				SystemType:     proto.String("IOS"),
				SystemVersion:  proto.String(acc.IOSHardwareInfo.SysVer),
				WifiMac:        proto.String(acc.IOSHardwareInfo.WIFIMac),
				WifiNodeName:   proto.String(acc.IOSHardwareInfo.WIFIName),
				LacId:          proto.String(""),
				CellId:         proto.String(""),
				IsPrisonBreak:  proto.String("0"),
				AlipayEnvJson:  proto.String(alipayEnvJSON),
				TaobaoEnvJson:  proto.String(""),
				Token:          proto.String(""),
				DeviceId:       proto.String("unknown"),
				AppData:        appData,
				ExternParams:   externParams,
				SdkVersion:     proto.String("2.0.0.6"),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.UnifyLoginReq{}
		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]UnifyLoginReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_UNIFYLOGIN, c.onUnifyLogin, &mmtp, data, true)
}

func (c *AliConn) onUnifyLogin(op string, data []byte, param interface{}) {
	logger.Debug("onUnifyLogin")
	acc := c.acc
	res := alipaymsg.UnifyLoginRes{}
	if err := proto.Unmarshal(data, &res); err != nil {
		acc.notifyLogin(loginCodeDataError, loginMsgDataError)
		logger.Errorf("[AliConn]UnifyLoginRes反序列化错误: %+v, 数据: %+v.", err, data)
		return
	}

	// 登录成功
	if res.GetSuccess() && res.GetCode() == "1000" {
		acc.UserID = res.GetUserId()
		acc.SessionID = res.GetSessionId()
		acc.notifyLogin(loginCodeSuccess, loginMsgSuccess)

		// 发登录成功后的包
		go c.afterLoginRoutine(true)

		logger.Infof("[AliConn]UnifyLoginRes用户登录成功, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	// 验证码登录
	if res.GetCode() == "6207" {
		acc.smsCodeH5Url = res.GetH5URL()
		acc.smsLastCodeTime = 0
		acc.smsSendURL = ""
		acc.smsRefererURL = ""
		acc.notifyLogin(loginCodeNeedSMSCode, loginMsgNeedSMSCode)

		logger.Infof("[AliConn]UnifyLoginRes用户登录需要验证码, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	// 密码不正确
	if res.GetCode() == "6307" {
		acc.notifyLogin(loginCodeInvalidPassword, loginMsgInvalidPassword)
		logger.Infof("[AliConn]UnifyLoginRes登录密码不正确, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	// 帐号不存在
	if res.GetCode() == "5039" {
		acc.notifyLogin(loginCodeInvalidAccount, loginMsgInvalidAccount)

		logger.Infof("[AliConn]UnifyLoginRes登录帐号不存在, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	logger.Infof("[AliConn]UnifyLoginRes其它登录代码: %+v, msg: %+v, 帐号: %+v, 平台: %+v.\n",
		res.GetCode(), res.GetMsg(), acc.Account, acc.Platform)

	code, err := strconv.Atoi(res.GetCode())
	if err == nil {
		acc.notifyLogin(code, res.GetMsg())
	} else {
		acc.notifyLogin(loginCodeUnknowState, res.GetMsg())
	}
}
