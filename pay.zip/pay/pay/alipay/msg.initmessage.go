package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) getInitMessageReqWithToken() *alipaymsg.InitMessageReq {
	acc := c.acc
	if acc.Platform == platformIOS {
		req := &alipaymsg.InitMessageReq{
			Apdid:                 proto.String(acc.IOSHardwareInfo.APDID),
			CacheSessionId:        proto.String(acc.SessionID),
			Utdid:                 proto.String(acc.IOSHardwareInfo.UTDID),
			SystemVersion:         proto.String(acc.IOSHardwareInfo.SysVer),
			PublishChannel:        proto.String("apple-iphone"),
			ProductId:             proto.String(productIDIOS),
			ProductVersion:        proto.String(productVersionIOS),
			Brand:                 proto.String(phoneBrandIOS),
			Model:                 proto.String(acc.IOSHardwareInfo.Model),
			ClientType:            proto.String("phone"),
			AppType:               proto.String("client"),
			Imei:                  proto.String(acc.IOSHardwareInfo.IMEI),
			Imsi:                  proto.String(acc.IOSHardwareInfo.IMSI),
			SettingVersion:        proto.Int64(24),
			HpackVersion:          proto.Int32(2),
			UserId:                proto.String(acc.UserID),
			AppStatus:             proto.Int32(1),
			LinkAction:            proto.Int32(1),
			Language:              proto.String("zh-Hans"),
			IncrementMode:         proto.Bool(false),
			NetworkEnum:           proto.Int32(6),
			MobileSystemEnum:      proto.Int32(1),
			ClientSeq:             proto.Int64(utils.GetTimeStampEx()),
			ConnectId:             proto.Int64(utils.GetTimeStampEx()),
			MmtpDid:               proto.String(acc.MmtpDid),
			OwnedZstdDictionaryId: proto.String(""),
			AppName:               proto.String(appNameIOS),
			OnlyToLink:            proto.Bool(true),
		}

		if acc.IsLoginSuccess() {
			req.LinkAction = proto.Int32(2)
		}

		return req
	} else if acc.Platform == platformAndroid {
		req := &alipaymsg.InitMessageReq{}
		return req
	}

	return nil
}

func (c *AliConn) getInitMessageReqNoneToken() *alipaymsg.InitMessageReq {
	acc := c.acc
	if acc.Platform == platformIOS {
		req := &alipaymsg.InitMessageReq{
			Apdid:            proto.String(acc.IOSHardwareInfo.APDID),
			Utdid:            proto.String(acc.IOSHardwareInfo.UTDID),
			SystemVersion:    proto.String(acc.IOSHardwareInfo.SysVer),
			PublishChannel:   proto.String("apple-iphone"),
			ProductId:        proto.String(productIDIOS),
			ProductVersion:   proto.String(productVersionIOS),
			Brand:            proto.String(phoneBrandIOS),
			Model:            proto.String(acc.IOSHardwareInfo.Model),
			ClientType:       proto.String("phone"),
			AppType:          proto.String("client"),
			Imei:             proto.String(acc.IOSHardwareInfo.IMEI),
			Imsi:             proto.String(acc.IOSHardwareInfo.IMSI),
			SettingVersion:   proto.Int64(0),
			Language:         proto.String("zh-Hans"),
			NetworkEnum:      proto.Int32(6),
			MobileSystemEnum: proto.Int32(1),
			AppName:          proto.String(appNameIOS),
		}

		if len(acc.IOSHardwareInfo.APDID) > 40 {
			req.HpackVersion = proto.Int32(2)
			req.AppStatus = proto.Int32(1)
			req.LinkAction = proto.Int32(1)
			req.ResetUpseq = proto.Bool(true)
			req.IncrementMode = proto.Bool(false)
			req.ConnectId = proto.Int64(1)
		}

		return req
	} else if acc.Platform == platformAndroid {
		req := &alipaymsg.InitMessageReq{}
		return req
	}

	return nil
}

func (c *AliConn) sendInitMessage() error {
	var req *alipaymsg.InitMessageReq
	cep := &alipaymsg.ChannelExtParam{
		ChannelId: proto.Int32(2),
	}

	if c.acc.ApdidToken != "" {
		req = c.getInitMessageReqWithToken()
		cep.ExtParams = c.syncMgr.GetSyncKeyInfo(true)
	} else {
		req = c.getInitMessageReqNoneToken()
		cep.ExtParams = c.syncMgr.GetSyncKeyInfo(false)
	}

	if req == nil {
		return errRequestObjectNotFound
	}

	req.ExtParams = []*alipaymsg.ChannelExtParam{
		cep,
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]InitMessageReq序列化错误: %+v.", err)
		return err
	}

	mmtp := &alipaymsg.MmtpHead{
		Type:             proto.Uint32(3),
		ZipType:          proto.Uint32(1),
		DataFrameChannel: proto.Uint32(0),
	}

	c.sendMessage(mmtp, nil, data)

	return nil
}

func (c *AliConn) onInitMessage(data []byte) {
	logger.Debug("onInitMessageRes")
	res := &alipaymsg.InitMessgeRes{}
	if err := proto.Unmarshal(data, res); err != nil {
		logger.Errorf("[AliConn]InitMessageRes反序列化错误: %+v, 数据: %+v.", err, data)
	}

	mmtpdid := res.GetMmtpDid()
	logger.Infof("[AliConn]InitMessageRes, 帐号: %+v, mmtpid: %+v.", c.acc.Account, mmtpdid)

	c.acc.MmtpDid = mmtpdid

	go c.loginRoutine()
}
