package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendSTMessage1() error {
	action := alipaymsg.Actions_USERLOGOUT
	req := alipaymsg.STMessage{
		Action: &action,
	}

	data, err := proto.Marshal(&req)
	if err != nil {
		logger.Errorf("[AliConn]STMessageReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		Type:             proto.Uint32(4),
		DataFrameChannel: proto.Uint32(0),
	}

	return c.sendMessage(&mmtp, nil, data)
}

func (c *AliConn) sendSTMessage2() error {
	acc := c.acc
	action := alipaymsg.Actions_USERLOGIN
	req := &alipaymsg.STMessage{
		Action:         &action,
		UserId:         proto.String(acc.UserID),
		CacheSessionId: proto.String(acc.SessionID),
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]STMessageReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		Type:             proto.Uint32(4),
		DataFrameChannel: proto.Uint32(0),
	}

	return c.sendMessage(&mmtp, nil, data)
}

func (c *AliConn) onSTMessage(data []byte) {
	logger.Debug("onSTMessage")
	res := &alipaymsg.STMessage{}
	if err := proto.Unmarshal(data, res); err != nil {
		logger.Errorf("[AliConn]STMessage反序列化错误: %+v, 数据: %+v.", err, data)
	}

	if c.acc.IsLoginSuccess() {
		if res.GetAction() == alipaymsg.Actions_SESSION_NEED_REACTIVE {
			logger.Infof("[AliConn]断线重连需要重新登录, 帐号: %+v.", c.acc.Account)
			return
		}

		if res.GetAction() == alipaymsg.Actions_SEQ_SHAKE {
			logger.Infof("[AliConn]断线重连不需要登录, 帐号: %+v.", c.acc.Account)
			return
		}

		logger.Warnf("[AliConn]断线重连未处理的Action: %+v.", res.Action)

		return
	}

	logger.Infof("[AliConn]普通登录, 帐号: %+v.", c.acc.Account)
}
