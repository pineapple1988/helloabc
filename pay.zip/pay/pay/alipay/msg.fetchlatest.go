package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendFetchLatest() error {
	info := &alipaymsg.CFLocationInfo{
		Lat:        proto.Float64(0),
		Lon:        proto.Float64(0),
		AdCode:     proto.String(""),
		LocTime:    proto.String(""),
		Accuracy:   proto.String("0"),
		CityAdCode: proto.String(""),
	}

	req := func() *alipaymsg.FetchLatestReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			if acc.UserID != "" {
				return &alipaymsg.FetchLatestReq{
					LastQueryTime: proto.Int64(utils.GetTimeStampEx()),
					RefreshMode:   proto.String("init"),
					Version:       proto.Int64(1),
					OsType:        proto.String("ios"),
				}
			}

			return &alipaymsg.FetchLatestReq{
				LastQueryTime: proto.Int64(0),
				LocationInfo:  info,
				RefreshMode:   proto.String("first"),
				Version:       proto.Int64(1),
				OsType:        proto.String("ios"),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.FetchLatestReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]FetchLatestReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_FETCHINDEXLATEST, c.onFetchLatest, &mmtp, data, true)
}

func (c *AliConn) onFetchLatest(op string, data []byte, param interface{}) {
	logger.Debug("onFetchLatest")
}
