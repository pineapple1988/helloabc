package alipay

import (
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendUserLoginGW() error {
	req := func() *alipaymsg.UserLoginGWReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			externParams := []*alipaymsg.KeyValuePairs{
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("umidToken"),
					Value: proto.String(acc.UMID),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("netType"),
					Value: proto.String("WIFI"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("appState"),
					Value: proto.String("foreground"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("gestureType"),
					Value: proto.String("0"),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("terminalName"),
					Value: proto.String(acc.IOSHardwareInfo.IPhoneName),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("apdid"),
					Value: proto.String(acc.IOSHardwareInfo.APDID),
				},
				&alipaymsg.KeyValuePairs{
					Key:   proto.String("devKeySet"),
					Value: proto.String(fmt.Sprintf(`{"apdidToken":"%s"}`, acc.ApdidToken)),
				},
			}

			return &alipaymsg.UserLoginGWReq{
				LoginId:         proto.String(acc.Account),
				LoginType:       proto.Int32(1),
				LoginWithPwd:    proto.Int32(2),
				LoginPassword:   proto.String(""),
				LoginCheckCode:  proto.String(""),
				TbCheckCodeId:   proto.String(""),
				TbCheckCode:     proto.String(""),
				ProductId:       proto.String(productIDIOS),
				ProductVersion:  proto.String(productVersionIOS),
				OsVersion:       proto.String(acc.IOSHardwareInfo.SysVer),
				UserAgent:       proto.String(acc.IOSHardwareInfo.Model),
				Channels:        proto.String("apple-iphone"),
				ClientDigest:    proto.String(""),
				DeviceToken:     proto.String(""),
				ScreenWidth:     proto.Int32(int32(acc.GetScreenWidth())),
				ScreenHeight:    proto.Int32(int32(acc.GetScreenHeight())),
				ClientId:        proto.String(fmt.Sprintf("%s|%s", acc.IOSHardwareInfo.IMSI, acc.IOSHardwareInfo.IMEI)),
				WalletTid:       proto.String(acc.TID),
				WalletClientKey: proto.String(acc.IOSHardwareInfo.ClientKey),
				MspTid:          proto.String(acc.TID),
				MspImsi:         proto.String(acc.IOSHardwareInfo.IMSI),
				MspImei:         proto.String(acc.IOSHardwareInfo.IMEI),
				MspClientKey:    proto.String(acc.IOSHardwareInfo.ClientKey),
				SourceId:        proto.String(""),
				Mac:             proto.String(acc.IOSHardwareInfo.MacAddr),
				CellId:          proto.String(""),
				Location:        proto.String(""),
				Vimsi:           proto.String(acc.IOSHardwareInfo.VIMSI),
				Vimei:           proto.String(acc.IOSHardwareInfo.VIMEI),
				ExternParams:    externParams,
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.UserLoginGWReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]UserLoginGWReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_USERLOGINPB, c.onUserLoginGW, &mmtp, data, true)
}

func (c *AliConn) onUserLoginGW(op string, data []byte, param interface{}) {
	logger.Debug("onUserLoginGW")
	acc := c.acc
	res := alipaymsg.UserLoginGWRes{}
	if err := proto.Unmarshal(data, &res); err != nil {
		acc.notifyLogin(loginCodeDataError, loginMsgDataError)
		logger.Errorf("[AliConn]UserLoginGWRes反序列化错误: %+v, 数据: %+v.", err, data)

		return
	}

	// 登录成功
	if res.GetResultStatus() == 1000 {
		acc.notifyLogin(loginCodeSuccess, loginMsgSuccess)
		go c.afterLoginRoutine(false)

		logger.Infof("[AliConn]UserLoginGW用户登录成功, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	// 重新用帐号密码登录
	if res.GetResultStatus() == 1014 {
		acc.notifyLogin(loginCodeReloginWithPwd, loginMsgReloginWithPwd)
		logger.Warnf("[AliConn]UserLoginGw需要重新输入帐号密码登录, 帐号: %+v, 平台: %+v.",
			acc.Account, acc.Platform)

		return
	}

	acc.notifyLogin(int(res.GetResultStatus()), res.GetMemo())
	logger.Warnf("[AliConn]UserLoginGw其它登录代码: %+v, 信息: %+v.", res.GetResultStatus(), res.GetMemo())
}
