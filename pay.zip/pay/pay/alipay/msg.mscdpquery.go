package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMSCdpQuery() error {
	req := func() *alipaymsg.MSCdpQueryReq {
		acc := c.acc
		entries := []*alipaymsg.KeyValuePairs{
			&alipaymsg.KeyValuePairs{Key: proto.String("netType"), Value: proto.String("wifi")},
			&alipaymsg.KeyValuePairs{Key: proto.String("userAgent"), Value: proto.String("")},
		}
		if acc.Platform == platformIOS {
			return &alipaymsg.MSCdpQueryReq{
				SceneCodes:     []string{"APP_LOGIN_RECOMMEND", "APP_LOGIN_BACKGROUND"},
				MobileBrand:    proto.String(phoneBrandIOS),
				MobileModel:    proto.String(acc.IOSHardwareInfo.Model),
				SystemType:     proto.String("IOS"),
				SystemVersion:  proto.String(acc.IOSHardwareInfo.SysVer),
				IsPrisonBreak:  proto.String("0"),
				ProductId:      proto.String(productIDIOS),
				ProductVersion: proto.String(productVersionIOS),
				Apdid:          proto.String(acc.IOSHardwareInfo.APDID),
				Utdid:          proto.String(acc.IOSHardwareInfo.UTDID),
				Imei:           proto.String(acc.IOSHardwareInfo.IMEI),
				Imsi:           proto.String(acc.IOSHardwareInfo.IMSI),
				Channel:        proto.String(""),
				Ip:             proto.String(utils.GetLocalIPAddress()),
				WifiMac:        proto.String(acc.IOSHardwareInfo.WIFIMac),
				Cellid:         proto.String(""),
				WifiName:       proto.String(acc.IOSHardwareInfo.WIFIName),
				ExternParam:    &alipaymsg.MapStringString{Entries: entries},
				UmidToken:      proto.String(acc.UMID),
				Source:         proto.String(""),
			}
		} else if acc.Platform == platformAndroid {

		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MSCdqQuery序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_SECURITYCDPQUERY, c.onMSCdpQuery, &mmtp, data, true)
}

func (c *AliConn) onMSCdpQuery(op string, data []byte , param interface{}) {
	logger.Debug("onMSCdpQuery")
}
