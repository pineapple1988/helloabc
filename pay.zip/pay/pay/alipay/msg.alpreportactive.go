package alipay

import (
	"fmt"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendALPReportActive(hpid string) error {
	acc := c.acc
	key := []string{"cellId", "isPrisonBreak", "longitude", "latitude", "devKeySet", "apdid", "umidToken", "wifiMac", "wifiNodeName", "isPushEnable", "lacId", "hpid"}
	value := []string{}
	req := func() *alipaymsg.ALPReportActiveReq {
		if acc.Platform == platformIOS {
			value = []string{
				"",
				"F",
				"",
				"",
				fmt.Sprintf(`{"apdidToken":"%s"}`, acc.ApdidToken),
				acc.IOSHardwareInfo.APDID,
				acc.UMID,
				acc.IOSHardwareInfo.MacAddr,
				acc.IOSHardwareInfo.WIFIName,
				"F",
				"",
				hpid,
			}
			return &alipaymsg.ALPReportActiveReq{
				Channels:       proto.String("apple-iphone"),
				ProductID:      proto.String(productIDIOS),
				ProductVersion: proto.String(productVersionIOS),
				UserAgent:      proto.String("ALIPAY_FOR_IOS"),
				MobileBrand:    proto.String(phoneBrandIOS),
				MobileModel:    proto.String("iPhone"),
				AccessPoint:    proto.String("wifi"),
				ClientPosition: proto.String(""),
				SystemVersion:  proto.String(acc.IOSHardwareInfo.SysVer),
				Awid:           proto.String(acc.IOSHardwareInfo.AWID),
				DeviceToken:    proto.String(""),
				SourceId:       proto.String(""),
				Imei:           proto.String(acc.IOSHardwareInfo.IMEI),
				Imsi:           proto.String(acc.IOSHardwareInfo.IMSI),
				ScreenSize:     proto.String(""),
				Carrier:        proto.String("CHINA MOBILE"),
				//ExtInfos:       &alipaymsg.MapStringString{Entries: extInfo},
				ScreenWidth:  proto.Int64(acc.GetScreenWidth()),
				ScreenHeight: proto.Int64(acc.GetScreenHeight()),
				SystemType:   proto.Int32(0),
				MobileModel2: proto.String(acc.IOSHardwareInfo.Model),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.ALPReportActiveReq{}
		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	if len(value) != len(key) {
		return errRequestObjectNotFound
	}

	extInfo := []*alipaymsg.KeyValuePairs{}
	for k := range key {
		extInfo = append(extInfo, &alipaymsg.KeyValuePairs{
			Key:   proto.String(key[k]),
			Value: proto.String(value[k]),
		})
	}

	req.ExtInfos = &alipaymsg.MapStringString{
		Entries: extInfo,
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]ALPReportActive序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_REPORTACTIVE, c.onALPReportActive, &mmtp, data, true)
}

func (c *AliConn) onALPReportActive(op string, data []byte, param interface{}) {
	logger.Debug("onALPReportActive")
}
