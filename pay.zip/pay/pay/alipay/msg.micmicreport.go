package alipay

import (
	"encoding/json"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"
	"strings"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendMICMICReport() error {
	req := func() *alipaymsg.MICMICReportReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			secData := map[string]string{
				"rt": "1",
				"ap": "",
				"pn": bundleIDIOS,
				"bi": "1#1#2#0#2#1#0#6#0#1#0;",
				"di": "FFFFFFFF" + strings.ReplaceAll(acc.IOSHardwareInfo.AWID, "-", ""),
				"ai": "2#2#0#2#1#0#6;",
				"pm": strings.ReplaceAll(acc.IOSHardwareInfo.Model, ",", "#"),
				"dv": "16",
			}

			secDataJSON, _ := json.Marshal(&secData)

			envData := []string{
				string(secDataJSON),
				acc.IOSHardwareInfo.APDID,
				"",
				bundleIDIOS,
				"10.1.20",
				"3.1.20.100",
				"iOS " + acc.IOSHardwareInfo.SysVer,
				"ios",
				"Apple",
				acc.IOSHardwareInfo.Model,
				"3.0.1:495,6",
				"i530",
				"true",
				"",
			}

			envDataJSON, _ := json.Marshal(&envData)

			return &alipaymsg.MICMICReportReq{
				ReportData: &alipaymsg.MapStringString{
					Entries: []*alipaymsg.KeyValuePairs{
						&alipaymsg.KeyValuePairs{Key: proto.String("envData"), Value: proto.String(string(envDataJSON))},
						&alipaymsg.KeyValuePairs{Key: proto.String("reportOccasion"), Value: proto.String("appStart")},
					},
				},
			}

		} else if acc.Platform == platformAndroid {
			return &alipaymsg.MICMICReportReq{}
		}
		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]MICMICReportReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		ZipType:        proto.Uint32(1),
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_MOBILEICREPORT, c.onMICMICReport, &mmtp, data, true)
}

func (c *AliConn) onMICMICReport(op string, data []byte, param interface{}) {
	logger.Debug("onMICMICReport")
}
