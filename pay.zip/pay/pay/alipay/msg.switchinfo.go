package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"
	"strconv"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendSwitchInfo() error {
	req := func() *alipaymsg.SwitchInfoReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.SwitchInfoReq{
				ClientVersion:    proto.String(productVersionIOS),
				Utdid:            proto.String(acc.IOSHardwareInfo.UTDID),
				UserId:           proto.String(acc.UserID),
				Imei:             proto.String(acc.IOSHardwareInfo.IMEI),
				LastResponseTime: proto.String(strconv.FormatInt(c.lastResponseTime, 10)),
				SystemType:       proto.String("ios"),
				ProductId:        proto.String(productIDIOS),
				MobileBrand:      proto.String(phoneBrandIOS),
				MobileModel:      proto.String(acc.IOSHardwareInfo.Model),
				OsVersion:        proto.String(acc.IOSHardwareInfo.SysVer),
				Manufacturer:     proto.String("apple"),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.SwitchInfoReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]SwitchInfoReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_SWITCHINFOREQPB, c.onSwitchInfo, &mmtp, data, true)
}

func (c *AliConn) onSwitchInfo(op string, data []byte, param interface{}) {
	logger.Debug("onSwitchInfo")
}
