package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendCmdListMessage() error {
	req := &alipaymsg.CmdListMessageReq{
		Seq: proto.Int32(0),
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]CmdListMessageReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		Type:             proto.Uint32(9),
		DataFrameChannel: proto.Uint32(0),
	}

	return c.sendMessage(&mmtp, nil, data)
}

func (c *AliConn) onCmdListMessage(data []byte) {
	res := alipaymsg.CmdListMessageRes{}
	if err := proto.Unmarshal(data, &res); err != nil {
		logger.Errorf("[AliConn]CmdListMessageRes反序列化错误: %+v, 数据: %+v.", err, data)
		return
	}

	for _, v := range res.CmdList {
		logger.Debugf("[AliConn]CmdListMessageRes Cmd: %+v.", v.GetCmdType())
	}
}
