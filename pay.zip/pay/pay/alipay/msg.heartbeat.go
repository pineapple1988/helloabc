package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

var (
	started    = false
	lastTime   = int64(0)
	heartValue = int16(0)
)

func (c *AliConn) startHeart() {
	if !started {
		started = true
		heartValue = 1
		lastTime = utils.GetTimeStampEx()
	}
}

func (c *AliConn) stopHeart() {
	started = false
}

func (c *AliConn) checkHeart() {
	if !started {
		return
	}

	time := utils.GetTimeStampEx()
	if time-lastTime < 180000 {
		return
	}

	c.sendHeartbeat(heartValue)
	heartValue += 2

	lastTime = time
}

func (c *AliConn) sendHeartbeat(value int16) {
	ba := utils.NewByteArray([]byte{})
	ba.WriteInt16(value)

	mmtp := alipaymsg.MmtpHead{
		Type:             proto.Uint32(2),
		DataFrameChannel: proto.Uint32(0),
	}

	c.sendMessage(&mmtp, nil, ba.Bytes())
}

func (c *AliConn) onHeartbeat(data []byte) {
	logger.Debug("[AliConn]onHeartbeat.")
}
