package alipay

import (
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/logger"

	"github.com/golang/protobuf/proto"
)

func (c *AliConn) sendDeviceLocation() error {
	req := func() *alipaymsg.DeviceLocationReq {
		acc := c.acc
		if acc.Platform == platformIOS {
			return &alipaymsg.DeviceLocationReq{
				Apdid:                 proto.String(acc.IOSHardwareInfo.APDID),
				Os:                    proto.String("iOS"),
				VoiceOver:             proto.String("false"),
				Altitude:              proto.Float64(0),
				Speed:                 proto.Float64(0),
				Direction:             proto.Float64(0),
				Longitude:             proto.Float64(0),
				Latitude:              proto.Float64(0),
				Accuracy:              proto.Float64(0),
				WifiConn:              proto.Bool(true),
				LbsOpen:               proto.Bool(false),
				CurrentMobileOperator: proto.String("CHINA MOBILE"),
				AccessWirelessNetType: proto.String("WiFi"),
				BluetoothOpen:         proto.Bool(false),
				Source:                proto.String("21314794"),
				QueryLbs:              proto.Bool(false),
				OsVersion:             proto.String(acc.IOSHardwareInfo.SysVer),
			}
		} else if acc.Platform == platformAndroid {
			return &alipaymsg.DeviceLocationReq{}
		}

		return nil
	}()

	if req == nil {
		return errRequestObjectNotFound
	}

	data, err := proto.Marshal(req)
	if err != nil {
		logger.Errorf("[AliConn]DeviceLocationReq序列化错误: %+v, 数据: %+v.", err, req)
		return err
	}

	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	return c.sendHTTPMessage(HTTP_REPORTDEVICELOCATION, c.onDeviceLocation, &mmtp, data, true)
}

func (c *AliConn) onDeviceLocation(op string, data []byte, param interface{}) {
	logger.Debug("onDeviceLocation")
}
