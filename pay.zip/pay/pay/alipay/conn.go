package alipay

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"pay/conn"
	"pay/mgr/cookiemgr"
	"pay/mgr/syncmgr"
	"pay/mgr/timermgr"
	"pay/proto/alipaymsg"
	"pay/utils"
	"pay/utils/alihpack"
	"pay/utils/alipayutils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/golang/protobuf/proto"
)

const (
	alipayCookiePrefix  = "AlipayCookie"
	timerUpdate         = 1000
	timerUpdateInterval = 1000
	alipayHost          = "mygw.alipay.com"
	alipayPort          = "443"
)

var (
	errRequestObjectNotFound = errors.New("request object not found")
)

// MsgCallback 消息回调函数
type MsgCallback func(op string, body []byte, param interface{})

// CallbackInfo 回调信息结构
type CallbackInfo struct {
	op    string
	cb    MsgCallback
	param interface{}
}

// AliConn 支付宝网络连接
type AliConn struct {
	acc              *Account
	conn             *conn.Connection
	buffer           []byte
	recvCh           chan *PacketData
	lastResponseTime int64
	lastHearbeatTime int64
	rpcID            uint64
	heartValue       int16
	hpackEncoder     *alihpack.Encoder
	hpackDecoder     *alihpack.Decoder
	encodeBuffer     *bytes.Buffer
	syncMgr          *syncmgr.SyncMgr
	cbInfo           map[string]*CallbackInfo
	reportCH         chan bool
	hpackLock        sync.Mutex
}

// PacketData 封包数据
type PacketData struct {
	Header []byte
	Body   []byte
}

// NewAliConn 新建支付宝网络连接
func NewAliConn(acc *Account) *AliConn {
	c := &AliConn{
		acc:          acc,
		buffer:       []byte{},
		encodeBuffer: &bytes.Buffer{},
	}

	addr := net.JoinHostPort(alipayHost, alipayPort)
	c.conn = conn.NewConnection(addr, true, c)
	c.syncMgr = syncmgr.NewSyncMgr(acc.Account, acc.Platform)
	c.syncMgr.Load()

	return c
}

// Start 开始网络连接
func (c *AliConn) Start() {
	acc := c.acc
	if acc.Proxy.URI != "" {
		c.conn.SetProxy(&acc.Proxy)
	}
	c.conn.Start()
}

// Stop 停止网络连接
func (c *AliConn) Stop() {
	c.conn.Stop()
}

// OnConnecting 正在连接
func (c *AliConn) OnConnecting() {
	logger.Info("[AliConn]正在尝试连接到服务器...")
}

// OnConnected 连接结果
func (c *AliConn) OnConnected(ok bool, err error) {
	if ok {
		logger.Info("[AliConn]连接服务器成功.")
		c.recvCh = make(chan *PacketData, 20)
		c.lastHearbeatTime = utils.GetTimeStampEx()
		c.rpcID = 0
		c.heartValue = 1
		c.hpackEncoder = alihpack.NewEncoder(c.encodeBuffer)
		c.hpackDecoder = alihpack.NewDecoder(2048, nil)
		c.cbInfo = make(map[string]*CallbackInfo)
		c.startHeart()
		go c.packetRoutine()

		c.sendInitMessage()
	} else {
		logger.Errorf("[AliConn]连接服务器失败, 错误: %+v.", err)
		c.acc.notifyLogin(loginCodeConnectError, loginMsgConnectError)
	}
}

// OnReceived 收到网络数据
func (c *AliConn) OnReceived(data []byte) {
	if data == nil || len(data) <= 0 {
		return
	}

	if len(c.buffer) > 0 {
		// 缓冲区还有数据时第一个字节必须是0x90, 否则丢弃
		if c.buffer[0] != 0x90 {
			logger.Errorf("[AliConn]缓冲区数据第一位不是0x90, 丢弃缓冲区数据: %+v.", c.buffer)
			c.buffer = []byte{}
		}
	}

	// 添加到缓冲区
	c.buffer = append(c.buffer, data...)
	if c.buffer[0] != 0x90 {
		logger.Errorf("[AliConn]接收数据第一位不是0x90, 丢弃数据: %+v.", c.buffer)
		c.buffer = []byte{}
		return
	}

	// 拆包处理
	for {
		pos := 1

		// 头部长度
		headerLen, n := alipayutils.DeserializeLen(c.buffer, pos)
		if n == 0 {
			break
		}

		pos += n
		// 消息体长度
		bodyLen, n := alipayutils.DeserializeLen(c.buffer, pos)
		if n == 0 {
			break
		}

		pos += n

		packetLen := pos + int(headerLen+bodyLen)
		// 不够一个包长度
		if len(c.buffer) < packetLen {
			break
		}

		bodyPos := pos + int(headerLen)
		bodyEnd := pos + int(headerLen+bodyLen)

		// 处理一个包
		packetData := &PacketData{
			Header: c.buffer[pos:bodyPos],
			Body:   c.buffer[bodyPos:bodyEnd],
		}

		c.recvCh <- packetData

		// 清理处理的
		c.buffer = c.buffer[bodyEnd:]
	}
}

// OnError 网络连接错误
func (c *AliConn) OnError(err error) {
	c.recvCh <- nil

	c.stopHeart()
	if err != io.EOF {
		c.acc.notifyLogin(loginCodeNetError, err.Error())
	}

	c.acc.disconnectTime = utils.GetTimeStampEx()
	if c.acc.autoReconnect {
		logger.Info("[AliConn]网络连接断开, 10秒重将重新连接.")
	}
}

// OnTimer 定时器事件
func (c *AliConn) OnTimer(id int, param interface{}) {
	if id == timerUpdate {
		c.checkHeart()

		ts := utils.GetTimeStampEx()
		if !c.conn.IsConnected() && c.acc.autoReconnect {
			if ts-c.acc.disconnectTime > 10000 {
				c.Start()
			}
		}
	}
}

func (c *AliConn) packetRoutine() {
	timermgr.SetTimer(c, timerUpdate, timerUpdateInterval, true, nil)

	for data := range c.recvCh {
		if data == nil {
			break
		}

		// 头
		mh := &alipaymsg.MmtpHead{}
		if len(data.Header) > 0 {
			if err := proto.Unmarshal(data.Header, mh); err != nil {
				logger.Errorf("[AliConn]数据头反序列化失败, 错误: %+v, 数据: %+v.", err, data.Header)
				continue
			}
		}

		// 解压
		if mh.GetZipType() == 1 {
			body, err := utils.GZipUncompress(data.Body)
			if err != nil {
				logger.Errorf("[AliConn]数据GZip解压失败, 错误: %+v, 数据: %+v.", err, data.Body)
				continue
			}

			data.Body = body
		}

		//fmt.Println(data.Body)

		headLen := mh.GetDataFrameHeadLength()
		var hf []alihpack.HeaderField
		if headLen > 0 {
			//d := alihpack.NewDecoder(2048, nil)
			var err error
			hf, err = c.hpackDecoder.DecodeFull(data.Body[:headLen])
			if err != nil {
				logger.Errorf("[AliConn]HPACK解码失败, 错误: %+v, 数据: %+v.", err, data.Body[:headLen])
				continue
			}
		}

		c.processPacket(mh, hf, data.Body[headLen:])
	}

	timermgr.KillTimer(c, timerUpdate)
}

func (c *AliConn) processPacket(mh *alipaymsg.MmtpHead, hf []alihpack.HeaderField, data []byte) {
	// cookie处理
	for _, f := range hf {
		if f.Name == "Set-Cookie" && f.Value != "" {
			cookie := cookiemgr.GetUserCookie(alipayCookiePrefix, c.acc.Account, c.acc.Platform)
			cookie.UpdateCookie(f.Value)
		}
	}

	switch mh.GetType() {
	case 1:
		c.onDataFrameChannel(mh, hf, data)
	case 2:
		c.onHeartbeat(data)
	case 3:
		c.onInitMessage(data)
	case 4:
		c.onSTMessage(data)
	case 5:
		c.onSettingMessage()
	case 6:
	case 7:
	case 9:
		c.onCmdListMessage(data)
	case 10:
	case 13:
	default:
		logger.Warnf("[AliConn]未处理的MMTPHead类型: %+v.", mh.GetType())
	}

	c.lastResponseTime = utils.GetTimeStampEx()
}

func (c *AliConn) onDataFrameChannel(mh *alipaymsg.MmtpHead, hf []alihpack.HeaderField, data []byte) {
	switch mh.GetDataFrameChannel() {
	case 1:
		{
			if mh.GetDirect() == 1 {
				rpcID := func() string {
					for _, field := range hf {
						if field.Name == "RpcId" {
							return field.Value
						}
					}

					return ""
				}()

				if rpcID == "" {
					logger.Error("[AliConn]onDataFrameChannel无法从找到rpcID.")
					return
				}

				callback, ok := c.cbInfo[rpcID]
				if !ok {
					logger.Errorf("[AliConn]onDataFrameChannel无法找到rpcID对应的回调信息, rpcID: %+v.", rpcID)
					return
				}

				logger.Debugf("[AliConn]onDateFrameChannel RpcId: %+v, op: %+v.", rpcID, callback.op)

				callback.cb(callback.op, data, callback.param)
				delete(c.cbInfo, rpcID)
			}
		}
	case 2:
		{
			c.onSyncOpCode(&hf, data)
		}
	}
}

func (c *AliConn) onSettingMessage() {
	logger.Debug("onSettingMessage")
}

func (c *AliConn) onSyncOpCode(hf *[]alihpack.HeaderField, data []byte) {
	var opCode int16

	// 去掉一字节
	r := bytes.NewReader(data[1:])
	if err := binary.Read(r, binary.BigEndian, &opCode); err != nil {
		return
	}
	switch opCode {
	case 2001:
		c.onSyncOpCode2001(hf, data[3:])
	}
}

func (c *AliConn) sendMessage(mmtp *alipaymsg.MmtpHead, hpack []byte, data []byte) error {
	ba := utils.NewByteArray([]byte{})

	if hpack != nil && len(hpack) > 0 {
		ba.WriteBytes(hpack)
		mmtp.DataFrameHeadLength = proto.Uint32(uint32(ba.Length()))
	}

	ba.WriteBytes(data)

	body := ba.Bytes()
	if mmtp.GetZipType() == 1 {
		var err error
		body, err = utils.GZipCompress(body)
		if err != nil {
			logger.Errorf("[AliConn]压缩包体数据错误: %+v.", err)
			return err
		}
	}

	mmtpData, err := proto.Marshal(mmtp)
	if err != nil {
		logger.Errorf("[AliConn]MmtpHead序列化错误: %+v, 数据: %+v.", err, mmtp)
		return err
	}

	mmtpLen := int32(len(mmtpData))
	bodyLen := int32(len(body))

	ba.Reset()
	ba.WriteByte(0x90)
	ba.WriteBytes(alipayutils.SerializeLen(mmtpLen))
	ba.WriteBytes(alipayutils.SerializeLen(bodyLen))
	ba.WriteBytes(mmtpData)
	ba.WriteBytes(body)

	c.conn.Send(ba.Bytes())

	return nil
}

func (c *AliConn) sendHTTPMessage(op string, cb MsgCallback, mmtp *alipaymsg.MmtpHead, data []byte, proto bool) error {
	ts := alipayutils.C10To64(utils.GetTimeStampEx())
	sign := c.getSign(op, data, ts)
	rpcID := c.getRPCID()
	header := c.getHeader(op, rpcID, sign, ts, proto)

	c.setCallback(rpcID, op, cb, nil)
	return c.sendMessage(mmtp, header, data)
}

func (c *AliConn) sendStringMessage(op string, cb MsgCallback, str string, param interface{}) error {
	data := []byte(str)
	ts := alipayutils.C10To64(utils.GetTimeStampEx())
	sign := c.getSign(op, data, ts)
	rpcID := c.getRPCID()
	header := c.getHeader(op, rpcID, sign, ts, false)
	mmtp := alipaymsg.MmtpHead{
		MmtpUpSequence: proto.Uint64(uint64(utils.GetTimeStampEx())),
	}

	c.setCallback(rpcID, op, cb, param)
	return c.sendMessage(&mmtp, header, data)
}

func (c *AliConn) setCallback(rpcID, op string, cb MsgCallback, param interface{}) {
	c.cbInfo[rpcID] = &CallbackInfo{
		op:    op,
		cb:    cb,
		param: param,
	}
}

func (c *AliConn) getRPCID() string {
	rpc := atomic.AddUint64(&c.rpcID, 1)
	return strconv.FormatUint(rpc, 10)
}

func (c *AliConn) getSign(op string, data []byte, ts string) string {
	reqData := ""
	if data != nil && len(data) > 0 {
		reqData = base64.StdEncoding.EncodeToString(data)
	}

	// 特殊处理
	if op == "/cashier/gentid" || op == "/cashier/pay" {
		op = HTTP_DISPATCH_PB_V3
	}

	param := fmt.Sprintf("%+v&Operation-Type=%+v&Request-Data=%+v&Ts=%+v",
		requestSignIOS, op, reqData, ts)

	return utils.MD5String(param)
}

func (c *AliConn) getCookie() string {
	cookies := []string{}
	cookie := cookiemgr.GetUserCookie(alipayCookiePrefix, c.acc.Account, c.acc.Platform)

	// spanner
	if ck := cookie.GetCookie("spanner"); ck != "" {
		cookies = append(cookies, fmt.Sprintf("spanner=%s", ck))
	}

	// ssl_upgrade
	if ck := cookie.GetCookie("ssl_upgrade"); ck != "" {
		cookies = append(cookies, fmt.Sprintf("ssl_upgrade=%s", ck))
	}

	// ALIPAYJSESSIONID
	if c.acc.SessionID != "" {
		cookies = append(cookies, fmt.Sprintf("ALIPAYJSESSIONID=%s", c.acc.SessionID))
	}

	// devKeySet
	if c.acc.ApdidToken != "" {
		cookies = append(cookies, fmt.Sprintf(`devKeySet={"apdidToken":"%s"}`, c.acc.ApdidToken))
	}

	// zone
	if ck := cookie.GetCookie("zone"); ck != "" {
		cookies = append(cookies, fmt.Sprintf("zone=%s", ck))
	}

	return strings.Join(cookies, "; ")
}

func (c *AliConn) getHeader(op, rpcID, sign, ts string, proto bool) []byte {
	writeField := func(name, value string) {
		f := alihpack.HeaderField{Name: name, Value: value}
		if err := c.hpackEncoder.WriteField(f); err != nil {
			logger.Errorf("[AliConn]HPACK编码错误, 错误: %+v, key: %+v, value: %+v.", err, name, value)
		}
	}

	c.hpackLock.Lock()
	defer c.hpackLock.Unlock()

	c.encodeBuffer.Reset()
	writeField("Accept-Language", "zh-Hans")
	writeField("AppId", productIDIOS)
	if proto {
		writeField("Content-Type", "application/protobuf")
	} else {
		writeField("Content-Type", "application/json")
	}

	if cookie := c.getCookie(); cookie != "" {
		writeField("Cookie", cookie)
	}
	writeField("Did", c.acc.IOSHardwareInfo.UTDID)

	// 特殊处理
	if op == "/cashier/gentid" || op == "/cashier/pay" {
		writeField("Operation-Type", HTTP_DISPATCH_PB_V3)
	} else {
		writeField("Operation-Type", op)
	}

	writeField("RpcId", rpcID)
	writeField("Sign", sign)
	writeField("Ts", ts)
	writeField("Version", "2")
	writeField("clientVersion", productVersionIOS)

	miniwua := ""
	if c.acc.Miniwua != "" {
		m := make(map[string]string)
		m["w"] = c.acc.Miniwua

		json, err := json.Marshal(&m)
		if err != nil {
			logger.Errorf("[AliConn]Miniwua序列化错误: %+v, 数据: %+v.", err, m)
		} else {
			miniwua = string(json)
		}
	}
	writeField("miniwua", miniwua)

	// 特殊处理
	if op == "/cashier/gentid" {
		acc := c.acc
		if acc.Platform == platformIOS {
			writeField("mqp-apiver", mqpAPIVerIOS)
			apdidToken := acc.ApdidToken
			if apdidToken == "" {
				writeField("mqp-ua", fmt.Sprintf("10.8.12(i %s;1;(a);;;(b);wifi;02:00:00:00:00:00;0;;(c))", acc.IOSHardwareInfo.SysVer))
			} else {
				writeField("mqp-ua", fmt.Sprintf("10.8.12(i %s;1;(a);;;(b);wifi;02:00:00:00:00:00;1;;(c))(1)(%s)", acc.IOSHardwareInfo.SysVer, apdidToken))
			}
		} else if acc.Platform == platformAndroid {
			// TODO: 安卓版本不要忘记添加
		}
	}

	if op == "/cashier/pay" {
		acc := c.acc
		if acc.Platform == platformIOS {
			writeField("mqp-apiver", mqpAPIVerIOS)
			writeField("mqp-bp", "(i530)")
			writeField("mqp-tid", acc.TID)
			uac := fmt.Sprintf("zh_CN;;;;;%s;%s", acc.IOSHardwareInfo.WIFIName, acc.IOSHardwareInfo.WIFIMac)
			writeField("mqp-uac", base64.StdEncoding.EncodeToString([]byte(uac)))
		} else if acc.Platform == platformAndroid {
			// TODO: 安卓版本不要忘记添加
		}
	}

	writeField("scene", "active")
	writeField("retryable", "1")
	writeField("visibleflag", "1")

	return c.encodeBuffer.Bytes()
}

func (c *AliConn) notifyReportResult(b bool) {
	c.reportCH <- b
	close(c.reportCH)
}

func (c *AliConn) loginRoutine() {
	acc := c.acc
	if acc.UserID == "" || acc.TID == "" || acc.ApdidToken == "" {
		c.firstLogin()
	} else {
		c.secondLogin()
	}
}

func (c *AliConn) firstLogin() {
	acc := c.acc

	//首次登录清理
	acc.UserID = ""
	acc.TID = ""
	acc.ApdidToken = ""

	c.sendProtoSyncOpCode4011("0")
	c.sendSwitchInfo()
	c.sendGetRSAKey("[]")
	c.sendMobileAppCommonClientPGInfo()
	c.sendMspV3GenTid()
	acc.postMGW()
	c.sendALPReportActive("")
	c.sendMSCdpQuery()
	c.sendGetRSAKey("[null]")
	c.sendUnionResource()
	c.sendEdge()
	c.sendGetMsgRecord("[]")

	c.reportCH = make(chan bool, 2)
	c.sendReport()

	select {
	case <-c.reportCH:
		{

		}
	case <-time.After(time.Second * 5):
		{
			logger.Errorf("[AliConn]等待Report返回超时, 帐号: %+v, 平台: %+v.", acc.Account, acc.Platform)

			return
		}
	}

	c.sendMICMICReport()
	c.sendMobileCodecShareCodeConfig()
	c.sendUnifyLogin("", "")
}

func (c *AliConn) secondLogin() {
	acc := c.acc
	c.sendProtoSyncOpCode4011("0")
	c.sendSwitchInfo()
	c.sendGetRSAKey("[]")
	acc.postMGW()
	c.sendALPReportActive("7079")
	c.sendDeviceLocation()
	c.sendUserLoginGW()
}

func (c *AliConn) afterLoginRoutine(first bool) {
	if first {
		c.sendProtoSyncOpCode3002()
		c.sendSTMessage2()
		c.sendMobileAppCommonClientPGInfo()
		c.sendUserHistoryReport()
		c.sendStageInfo()
		c.sendMobileRelationGetAllFriend()
		c.sendMyFollowedList("[{}]")
		c.sendQueryAllJoinedGroup("[0]")
		c.sendPushCoreBindUser()
		c.sendSwitchInfo()
		c.sendProtoSyncOpCode3001()
		c.sendInitialSpaceInfo("")
		c.sendFetchLatest()
		// 不发这个包就不会踢掉原先的帐号
		c.sendFollowList()
	} else {
		c.sendFetchLatest()
		c.sendCmdListMessage()
	}
}
