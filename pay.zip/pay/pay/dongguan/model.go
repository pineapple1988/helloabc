package ceb

type header struct {
	Code      string `json:"IBSReturnCode"`
	Msg       string `json:"IBSReturnMsg"`
	TransCode string `json:"TransCode"`
}


type getBasicMsgRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg  string `json:"IBSReturnMsg"`
		TransCode     string `json:"TransCode"`
	} `json:"head"`
	MessageNum string `json:"MessageNum"`
	Flag       string `json:"Flag"`
}

type messEncryptDataRes struct {

	MessEncryptData string `json:"MessEncryptData"`

}


type whiteCifGrayscaleRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg  string `json:"IBSReturnMsg"`
		TransCode     string `json:"TransCode"`
	} `json:"head"`
	TestFlag string `json:"TestFlag"`
}



type HomePageFloorPictureQryRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg  string `json:"IBSReturnMsg"`
		TransCode     string `json:"TransCode"`
	} `json:"head"`
	List []struct {
		HomeNumber   string `json:"homeNumber"`
		ActionName   string `json:"actionName"`
		PhotoAddress string `json:"photoAddress"`
		LinkAddress  string `json:"linkAddress"`
		ActPlace     string `json:"actPlace"`
		ParentCode   string `json:"parentCode"`
		ParentName   string `json:"parentName"`
		IsBind       string `json:"isBind"`
		IsLogin      string `json:"isLogin"`
		IsVersion    string `json:"isVersion"`
		SortNo       string `json:"sortNo"`
	} `json:"List"`
}
type ExcellentFinancingRes struct {
	MainPictureInfo  []interface{} `json:"MainPictureInfo"`
	SaleActivityList []struct {
		ActivityAim        string `json:"ActivityAim"`
		ActivityForm       string `json:"ActivityForm"`
		ActivityOperation  string `json:"ActivityOperation"`
		AssociatedActivity string `json:"AssociatedActivity"`
		AssociatedPlatform string `json:"AssociatedPlatform"`
		EndDate            string `json:"EndDate"`
		OrderNumber        string `json:"OrderNumber"`
		PicSkipURL         string `json:"PicSkipUrl"`
		PicURL             string `json:"PicUrl"`
		RankEndDate        string `json:"RankEndDate"`
		RankStartDate      string `json:"RankStartDate"`
		SaleCode           string `json:"SaleCode"`
		SaleID             string `json:"SaleId"`
		SaleName           string `json:"SaleName"`
		SaleOrgan          string `json:"SaleOrgan"`
		StartDate          string `json:"StartDate"`
	} `json:"SaleActivityList"`
	Data []struct {
		Gotransacde            string `json:"gotransacde"`
		MarketingLabelText     string `json:"marketingLabelText"`
		MarketingPromotionText string `json:"marketingPromotionText"`
		Pid                    string `json:"pid"`
		Proceeds               string `json:"proceeds"`
		ProductName            string `json:"productName"`
		ProductRate            string `json:"productRate"`
		Ptype                  string `json:"ptype"`
		ViewOrder              string `json:"viewOrder"`
	} `json:"data"`
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg  string `json:"IBSReturnMsg"`
		TransCode     string `json:"TransCode"`
	} `json:"head"`
	IsBind string `json:"isBind"`
}


type fetchPublicKeyRes struct {
	Head               header `json:"head"`
	AdvID              string `json:"AdbId"`
	PicURL             string `json:"picurl"`
	DetailURL          string `json:"detailurl"`
	AdvFlag            string `json:"AdvFlg"`
	SM2Key             string `json:"SM2Key"`
	SM4Key             string `json:"SM4Key"`
	Timestamp          string `json:"timestamp"`
	CSIITimeStamp      string `json:"_CSII_TIMESTAMP"`
	FidoLoginOpenFlag  string `json:"FidoLoginOpenFlag"`
	FidoPayOpenFlag    string `json:"FidoPayOpenFlag"`
	FaceLoginOpenFlag  string `json:"FaceLoginOpenFlag"`
	VoiceLoginOpenFlag string `json:"voiceLoginOpenFlag"`
	GDMapSwitch        string `json:"GDMapSwitch"`
	ClientVersion      string `json:"clientVersion"`
	ChannelIDVision    string `json:"channelIdVision"`
	VersionType        string `json:"VersionType"`
	VersionValue       string `json:"VersionValue"`
	HighestVersion     string `json:"HighestVersion"`
	UploadURL          string `json:"UploadUrl"`
	AgreementHighestVersionNo string `json:"AgreementHighestVersionNo"` //7.10新字段
	APPUpdate          string `json:"APPUpdate"`//7.10新字段
}

type getTokenRes struct {
	Head struct {
		Status int    `json:"status"`
		Msg    string `json:"msg"`
	} `json:"rsp_header"`
	Body  string `json:"rsp_body"`
	Token string `json:"token_id"`
}

type clientNoticeListRes struct {
	Head header `json:"head"`
}

type getMobileToLoginRes struct {
	Head            header `json:"head"`
	MobileNo        string `json:"MobileNo"`
	NewDeviceFlag   string `json:"NewDeviceFlag"`
	DynamicSM4Key   string `json:"DynamicSM4Key"`
	DynamicArrayKey string `json:"DynamicArrayKey"`
	FaceOpenFlag    string `json:"FaceOpenFlag"`
	VoiceOpenFlag   string `json:"VoiceOpenFlag"`
	LoginFlag       string `json:"loginFlag"`
	UserID          string `json:"UserId"`
}

type toSendSMSPwdRes struct {
	Head                header `json:"head"`
	SignatureSendSmsMD5 string `json:"SignatureSendSmsMD5"`
	NewDeviceDataMap    string `json:"NewDeviceDataMap"`
}

type ecifGrantDeviceRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg string `json:"IBSReturnMsg"`
		TransCode string `json:"TransCode"`
	} `json:"head"`
}


type smsCodeDatas struct {
	TransferSmsCode string `json:"transferSmsCode"`
}

type toLoginRes struct {
	Head header `json:"head"`
	RemindHeaderList []interface{} `json:"remindHeaderList"`
	ShowLottryFlag string `json:"ShowLottryFlag"`
	ShowCouponFlag string `json:"ShowCouponFlag"`
	ImgFlay string `json:"ImgFlay"`
	MbankImg string `json:"MbankImg"`
	LoginLotteryFlag string `json:"LoginLotteryFlag"`
	Sessionid string `json:"sessionid"`
	BLACKLISTFLAG string `json:"BLACKLISTFLAG"`
	OpenMBankFlag string `json:"OpenMBankFlag"`
	UserID string `json:"UserId"`
	IDNo string `json:"IdNo"`
	IDType string `json:"IdType"`
	UserName string `json:"UserName"`
	CifNo string `json:"CifNo"`
	IsTranfer string `json:"IsTranfer"`
	IsToken string `json:"IsToken"`
	DefaultAcNo string `json:"DefaultAcNo"`
	NeedSetDefaultAcNo string `json:"NeedSetDefaultAcNo"`
	CebKey string `json:"CebKey"`
	TipNote string `json:"TipNote"`
	SecureCookie string `json:"SecureCookie"`
	CertExpireFlag string `json:"CertExpireFlag"`
	CertDueDate string `json:"CertDueDate"`
	UserLastLoginTime string `json:"UserLastLoginTime"`
	WelcomeMessage string `json:"WelcomeMessage"`
	MobilePhone string `json:"MobilePhone"`
	TokenCiflag string `json:"TokenCiflag"`
	Code string `json:"code"`
	TimeOutFlag string `json:"timeOutFlag"`
	AcNoD string `json:"acNoD"`
	VisitorFlag string `json:"VisitorFlag"`
	IsPhoneSetFace string `json:"isPhoneSetFace"`
}


type dailyFirstLoginRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg string `json:"IBSReturnMsg"`
		TransCode string `json:"TransCode"`
	} `json:"head"`
	IsConditionSatisfied string `json:"isConditionSatisfied"`
	EncryptCifNo string `json:"encryptCifNo"`
	LotteryURL string `json:"lotteryUrl"`
}

type BranchActivityVisibleRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg string `json:"IBSReturnMsg"`
		TransCode string `json:"TransCode"`
	} `json:"head"`
	ShowTable string `json:"showTable"`
	Branch string `json:"branch"`
	BranchName string `json:"branchName"`
	BranchCityCode string `json:"branchCityCode"`
	IndexActivityList []interface{} `json:"indexActivityList"`
}
type fiDoLoginAndPayQueryRes struct {
	Head header `json:"head"`
}

type registGeTuiRes struct {
	Head header `json:"head"`
}

type actQryPreRes struct {
	Head                        header `json:"head"`
	ShowQueryPageRemindWordFlag string `json:"ShowQueryPageRemindWordFlag"`
	ContentValue                string `json:"ContentValue"`
	Logo                        string `json:"Logo"`
	ReturnURL                   string `json:"ReturnUrl"`
	DetailURL                   string `json:"DetailUrl"`
	ButtonName                  string `json:"ButtonName"`
	TitleBar                    string `json:"titleBar"`
	ShowLottryFlag              string `json:"ShowLottryFlag"`
	ShowCouponFlag              string `json:"ShowCouponFlag"`
	ImgFlay                     string `json:"ImgFlay"`
	MbankImg                    string `json:"MbankImg"`
	LoginLotteryFlag            string `json:"LoginLotteryFlag"`
	SessionID                   string `json:"sessionid"`
	DefaultAcNo                 string `json:"DefaultAcNo"`
	HideAcNo                    string `json:"HideAcNo"`
	AcID                        string `json:"AcId"`
	List                        []struct {
		AcNo         string `json:"AcNo"`
		HideAcNo     string `json:"HideAcNo"`
		AcID         string `json:"AcId"`
		BankAcType   string `json:"BankAcType"`
		BankAcTypeBH string `json:"bankAcTypeBH"`
		BankAcTypeBS string `json:"bankAcTypeBS"`
		AliasName    string `json:"AliasName"`
		SCurrency    string `json:"sCurrency"`
		AvailBal     string `json:"AvailBal"`
	} `json:"List"`
}

type queryDAIFARes struct {
	Head header `json:"head"`
}

type billInfo struct {
	TransDate string `json:"TransDate"`
	TransTime string `json:"TransTime"`
	Spending  string `json:"Spending"`
	Income    string `json:"Income"`
	Balance   string `json:"Balance"`
	DUIFZH    string `json:"DUIFZH"`
	DUIFMC    string `json:"DUIFMC"`
	Remark    string `json:"Remark"`
	DANWMC    string `json:"DANWMC"`
}

type actTrsQryRes struct {
	Head         header `json:"head"`
	EncryptValue string `json:"encryptValue"`
	Step         string `json:"step"`
	AcList       []struct {
		AcNo       string `json:"AcNo"`
		HideAcNo   string `json:"HideAcNo"`
		AcID       string `json:"AcId"`
		BankAcType string `json:"BankAcType"`
		AliasName  string `json:"AliasName"`
		AvailBal   string `json:"AvailBal"`
	} `json:"AcList"`
	FriendList []struct{} `json:"FriendList"`
	PnsList    []struct {
		AcNo       string `json:"AcNo"`
		HideAcNo   string `json:"HideAcNo"`
		AcID       string `json:"AcId"`
		BankAcType string `json:"BankAcType"`
		AliasName  string `json:"AliasName"`
		Currency   string `json:"Currency"`
		CRFlag     string `json:"CRFlag"`
	} `json:"PsnList"`
	EntList      []struct{} `json:"entList"`
	FromPage     string     `json:"FromPage"`
	AliasName    string     `json:"AliasName"`
	RecordNumber string     `json:"recordNumber"`
	PageSize     string     `json:"pageSize"`
	CurrentIndex string     `json:"currentIndex"`
	AcNo         string     `json:"AcNo"`
	HideAcNo     string     `json:"HideAcNo"`
	AcID         string     `json:"AcId"`
	BankAcType   string     `json:"BankAcType"`
	BeginDate    string     `json:"BeginDate"`
	EndDate      string     `json:"EndDate"`
	TotalCost    string     `json:"TotalCost"`
	TotalIncome  string     `json:"TotalIncome"`
	TotalCostS   string     `json:"TotalCostS"`
	TotalIncomeS string     `json:"TotalIncomeS"`
	TotalFlag    string     `json:"TotalFlag"`
	HXTotalNum   string     `json:"HXTotalNum"`
	List         []billInfo `json:"List"`
}

type bankTransferPreRes struct {
	Head            header `json:"head"`
	PayerBankAcType string `json:"PayerBankAcType"`
	PayerAcNo       string `json:"PayerAcNo"`
	HidePayerAcNo   string `json:"HidePayerAcNo"`
	AcID            string `json:"AcId"`
	AliasName       string `json:"AliasName"`
	AvailBal        string `json:"AvailBal"`
	AvailBalValue   string `json:"AvailBalValue"`
	Balance         string `json:"Balance"`
	BalanceValue    string `json:"BalanceBalue"`
	AcNoFlag        string `json:"AcNoFlag"`
	CommonHouse     string `json:"CommonHouse"`
	NextDayHouse    string `json:"NextDayhouse"`
	PayeeAcNo       string `json:"PayeeAcNo"`
	PayeeBankAcType string `json:"PayeeBankAcType"`
	PayeeAcName     string `json:"PayeeAcName"`
	PayeeBankID     string `json:"PayeeBankId"`
	UnionDeptID     string `json:"UnionDeptId"`
	SuperDeptID     string `json:"SuperDeptId"`
	BankName        string `json:"BankName"`
	CDFlag          string `json:"CDFLAG"`
	SiteName        string `json:"siteName"`
	PayeeAcAlias    string `json:"PayeeAcAlias"`
	List            []struct {
		PayerAcNo       string `json:"PayerAcNo"`
		HidePayerAcNo   string `json:"HidePayerAcNo"`
		AcID            string `json:"AcId"`
		PayerBankAcType string `json:"PayerBankAcType"`
		AliasName       string `json:"aliasName"`
	} `json:"list"`
}

type transBankInfo struct {
	PayeeBankID   string `json:"PayeeBankId"`
	UnionDeptID   string `json:"UnionDeptId"`
	PayeeAddr     string `json:"PayeeAddr"`
	SuperDeptID   string `json:"SuperDeptId"`
	SuperDeptName string `json:"SuperDeptName"`
	ParentCount   string `json:"parentCount"`
	BankName      string `json:"BankName"`
}

type transferBankQryRes struct {
	Head       header          `json:"head"`
	PayeePhone string          `json:"payeePhone"`
	CDFlag     string          `json:"CDFLAG"`
	List       []transBankInfo `json:"list"`
}

type bankTransferConfirmRes struct {
	Head            header `json:"head"`
	DataMap         string `json:"_dataMap"`
	LargeAmountFlag string `json:"largeAmountFlag"`
	LargeAmount     string `json:"largeAmount"`
	JNLNo           string `json:"JNL_NO"`
	PayerMobile     string `json:"PAYERMOBILE"`
	PayeePhone      string `json:"PayeePhone"`
	TimeFlag        string `json:"timeFlag"`
	IsSelf          string `json:"IsSelf"`
	PayerAcNo       string `json:"PayerAcNo"`
	SuperDeptName   string `json:"SuperDeptName"`
	CDCFlag         string `json:"CDCFlag"`
	HidePayerAcNo   string `json:"HidePayerAcNo"`
	AcID            string `json:"AcId"`
	PayerBankAcType string `json:"PayerBankAcType"`
	PayeeAddr       string `json:"PayeeAddr"`
	PayeeAcNo       string `json:"PayeeAcNo"`
	PayeeAcName     string `json:"PayeeAcName"`
	PayeeBankID     string `json:"PayeeBankId"`
	UnionDeptID     string `json:"UnionDeptId"`
	SuperDeptID     string `json:"SuperDeptId"`
	BankName        string `json:"BankName"`
	QSDeptID        string `json:"QSDeptId"`
	QSBankName      string `json:"QSBankName"`
	FallFlag        string `json:"FALLFLAG"`
	Remark          string `json:"Remark"`
	Fee             string `json:"Fee"`
	RealFee         string `json:"RealFee"`
	DeAmount        string `json:"deAmount"`
	SmsData         string `json:"SmsData"`
	SmsSignFlag     string `json:"SMSSignFlag"`
	Amount          string `json:"Amount"`
	AmountValue     string `json:"AmountValue"`
	AvailBal        string `json:"AvailBal"`
	PayerPhone      string `json:"PayerPhone"`
	TokenName       string `json:"_tokenName"`
	ShowOptOrSms    string `json:"showOtpOrSms"`
	FiDoPayFlag     string `json:"FiDoPayFlag"`
	SiteName        string `json:"siteName"`
	FaceOpenFlag    string `json:"FaceOpenFlag"`
}


type getMerchantParamsRes struct {
	Head struct {
		IBSReturnCode string `json:"IBSReturnCode"`
		IBSReturnMsg string `json:"IBSReturnMsg"`
		TransCode string `json:"TransCode"`
	} `json:"head"`
	Data string `json:"data"`
	Data2 string `json:"data2"`
	Flags string `json:"flags"`
	MerchantName string `json:"merchantName"`
	Purpose string `json:"purpose"`
	PopupWindow string `json:"popupWindow"`
}


type sendSMSPwdRes struct {
	Head header `json:"head"`
}

type bankTransferRes struct {
	Head                      header        `json:"head"`
	ShowLottryFlag            string        `json:"ShowLottryFlag"`
	ShowCouponFlag            string        `json:"ShowCouponFlag"`
	ImgFlay                   string        `json:"ImgFlay"`
	MbankImg                  string        `json:"MbankImg"`
	LoginLotteryFlag          string        `json:"LoginLotteryFlag"`
	SessionID                 string        `json:"sessionid"`
	ShowRemindWordFlag        string        `json:"ShowRemindWordFlag"`
	ContentValue              string        `json:"ContentValue"`
	ReturnURL                 string        `json:"ReturnUrl"`
	ShowWhichHead             string        `json:"ShowWhichHead"`
	DetailURL                 string        `json:"DetailUrl"`
	ButtonName                string        `json:"ButtonName"`
	ShowTitleBar              string        `json:"showTitleBar"`
	ShowPictureFlag           string        `json:"ShowPictureFlag"`
	PictureURL                string        `json:"PictureUrl"`
	RemindHeaderList          []interface{} `json:"remindHeaderList"`
	PayerAcNo                 string        `json:"PayerAcNo"`
	PayerBankAcType           string        `json:"PayerBankAcType"`
	HidePayerAcNo             string        `json:"HidePayerAcNo"`
	AcID                      string        `json:"AcId"`
	OrganName                 string        `json:"organName"`
	PayerAcName               string        `json:"PayerAcName"`
	TransDate                 string        `json:"trsDate"`
	PayeeAddr                 string        `json:"PayeeAddr"`
	PayeeAcNo                 string        `json:"PayeeAcNo"`
	PayeeAcName               string        `json:"PayeeAcName"`
	PayeeBankID               string        `json:"PayeeBankId"`
	UnionDeptID               string        `json:"UnionDeptId"`
	SuperDeptID               string        `json:"SuperDeptId"`
	BankName                  string        `json:"BankName"`
	QSDeptID                  string        `json:"QSDeptId"`
	QSBankName                string        `json:"QSBankName"`
	Remark                    string        `json:"Remark"`
	Fee                       string        `json:"Fee"`
	RealFee                   string        `json:"RealFee"`
	Amount                    string        `json:"Amount"`
	AmountValue               string        `json:"AmountValue"`
	DeAmount                  string        `json:"deAmount"`
	AmountBig                 string        `json:"AmountBig"`
	FallFlag                  string        `json:"fallfalg"`
	TimeFlag                  string        `json:"timeFlag"`
	PayeePhone                string        `json:"payeePhone"`
	Currency                  string        `json:"Currency"`
	TransferDetailConfirmFlag string        `json:"TransferDetailConfirmFlag"`
	JnlNoMsg                  string        `json:"JnlNoMSG"`
	TransactionSQLDateMsg     string        `json:"TransactionSqlDateMSG"`
}

type appInfo struct {
	Sdkversion string `json:"sdkversion"`
	Appid      string `json:"appid"`
	Channel    string `json:"channel"`
	Appkey     string `json:"appkey"`
	Sdktype    string `json:"sdktype"`
	Appversion string `json:"appversion"`
}

type deviceInfo struct {
	Devicemodel string `json:"devicemodel"`
	Osversion   string `json:"osversion"`
	Resolution  string `json:"resolution"`
	Mac         string `json:"mac"`
	IsRoot      string `json:"isRoot"`
	Accesstype  string `json:"accesstype"`
	Ostype      string `json:"ostype"`
	Imei        string `json:"imei"`
	Language    string `json:"language"`
	Wifiname    string `json:"wifiname"`
	Timezone    string `json:"timezone"`
	Country     string `json:"country"`
	Carrier     string `json:"carrier"`
	Devicebrand string `json:"devicebrand"`
}

type btnEvent struct {
	Eventid      string `json:"eventid"`
	Sessionid    string `json:"sessionid"`
	Time         string `json:"time"`
	Count        string `json:"count"`
	Date         string `json:"date"`
	PageName     string `json:"pageName"`
	Label        string `json:"label"`
	LoginAcctNum string `json:"loginAcctNum"`
}

type launch struct {
	Duration   string     `json:"duration"`
	Sessionid  string     `json:"sessionid"`
	Activities [][]string `json:"activities"`
	Time       string     `json:"time"`
	Date       string     `json:"date"`
}

type sessionInfo struct {
	Event  []btnEvent `json:"event"`
	Launch []launch   `json:"launch"`
}

type reqCollet struct {
	AppInfo     appInfo     `json:"appinfo"`
	Deviceinfo  deviceInfo  `json:"deviceinfo"`
	SessionInfo sessionInfo `json:"sessioninfo"`
}

type initMobile struct {
	Did string        `json:"did"`
	Dev []interface{} `json:"dev"`
	App []string      `json:"app"`
}
