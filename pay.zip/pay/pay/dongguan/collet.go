package ceb

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"pay/utils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"time"

	"github.com/go-http-utils/headers"
)

func (acc *Account) getColletAppInfo() appInfo {
	var ret appInfo
	ret.Sdkversion = colletSdkVersion
	ret.Appid = colletappID
	ret.Channel = ""
	ret.Appkey = colletappID
	ret.Sdktype = "iOS"
	ret.Appversion = colletAppVersion
	return ret
}

func (acc *Account) getColletDeviceInfo() deviceInfo {
	var ret deviceInfo
	ret.Devicemodel = acc.HardwareInfo.Model
	ret.Osversion = acc.HardwareInfo.OSVersion
	ret.Resolution = acc.HardwareInfo.Resolution
	ret.Mac = "02:00:00:00:00:00" //可以固定
	ret.IsRoot = "N"              //可以固定
	ret.Accesstype = "Wi-Fi"
	ret.Ostype = "iOS"
	ret.Imei = acc.HardwareInfo.Imei
	ret.Language = "zh-Hans-CN"
	ret.Wifiname = acc.HardwareInfo.WIFIName
	ret.Timezone = "GMT+8"
	ret.Country = "cn"
	ret.Carrier = acc.MobileOperators
	ret.Devicebrand = "iPhone"
	return ret
}

func (acc *Account) addColletEvent(collet *reqCollet, eventid, sessionid, pagename, label string) btnEvent {

	var ret btnEvent
	ret.Eventid = eventid
	ret.Sessionid = sessionid
	ret.Time = utils.GetTimeTimeStrEx()
	ret.Count = "1"
	ret.Date = utils.GetTimeDateStrEx()
	ret.PageName = pagename
	ret.Label = label
	ret.LoginAcctNum = acc.loginAcctNum

	collet.SessionInfo.Event = append(collet.SessionInfo.Event, ret)

	return ret
}

func (acc *Account) addColletLaunch(collet *reqCollet, sessionid string) {
	var ret launch
	ret.Duration = ""
	ret.Sessionid = sessionid
	ret.Time = acc.tokenTimeTimeStr
	ret.Date = acc.tokenTimeDateStr

	collet.SessionInfo.Launch = append(collet.SessionInfo.Launch, ret)
}

func (acc *Account) addActivities(collet *reqCollet, index int, pageName string, rTime int) {

	arrLen := len(collet.SessionInfo.Launch[index].Activities)
	var activitiesTime int64
	if arrLen == 0 {
		//事件1时间
		activitiesTime = utils.GetTimeStampEx()
	} else {
		//事件1时间
		tmpTime, _ := strconv.ParseInt(collet.SessionInfo.Launch[index].Activities[arrLen-1][2], 10, 64)
		activitiesTime = tmpTime + int64(rTime)
	}

	str := []string{
		pageName,
		fmt.Sprintf("%d", rTime),
		fmt.Sprintf("%d", activitiesTime),
		acc.loginAcctNum,
	}

	totalTime, _ := strconv.Atoi(collet.SessionInfo.Launch[index].Duration)

	totalTime += rTime

	collet.SessionInfo.Launch[index].Duration = fmt.Sprintf("%d", totalTime)

	collet.SessionInfo.Launch[index].Activities = append(collet.SessionInfo.Launch[index].Activities, str)
}

func colletSleep(start int, end int) {
	sleep := utils.RandInt(start, end)
	time.Sleep(time.Millisecond * time.Duration(sleep))
}

func colletSleep1(start int) {
	time.Sleep(time.Millisecond * time.Duration(start))
}

func (acc *Account) postCollet(collet reqCollet) error {
	// sstr := "xGT7QAjRt1AHv5ZWIlWHAtoGuvIeps4gaGumMlFKZXbjy4OSvLdPjctL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHDCmSKvT/rBYoKa9UWOsvvSiCjFRf/I+Mmpo6zFcaX4tj5m9ZbgpYdr15pPbOYfWAXY6TGyhx2QYhhMWFSI3XBIPhb8T1GQWaLmRb9N3zWAYJJ2wLUX90J5bF60M46pW2jbVum6TlzJIuq6SptH4eoGOwwXgwlLXqFCzS0+suJwx9x+Mfa7vw494RR8lZg4x3RMf5eJruXwhMTX1I1VplM/WTT9MmXBR0SkaJ3mpQgEF7P6oZtRLLnYWYNt3GNtdB1maJzo/mDY3UfB6rptsVhfSjVLSqRLDgQeaa4IizboN5dy6BVzdeEZF+xuPfPcV5CPxDC80LVjxBorg1FH1WEYSj4goQQ/9AV48FwIf6upQzUEm2UCT+8CkGwhY299aN7MHBiAxBGCn+zo6Ii2nN81FC1m+yBUXsXobwWEBofwod2m7W86KkmERDfPaS8wsPvv68JE3KAlaz7cMi6ndiFd/qDDyKr3Kbwajyx0KLWF83cj2fuFspWYcI38Try7dmXvZYrdiDGU2KY8EsbZXiLlyLkgo4K2whOoUd9I+ZGzJJYSyZabMjrDBVAWLEbQS9Oa8iLLbnOdc/P/Y83XYs/VnWYhPG27PM9NJmUZR8UgOFlnTBFvlWxUq9NliF02uyRNabfyWjw1mB/k5tduajUMtL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHWLFcylcb+LepkETj3e3FxVNtZ1Gvw3ZqDNEpTux7uTs4cvywv59BfnXXQLDqJARTLpXfa1nhGvs/6yDOFdglapOqzswAC66ScK7E1JNWtOo6S1x3vBugsMNoCG1aSf4KwQvv6OiqeihvwBXHf7vRR/1M+cYK4ga+4awBAN8vnHbXTerR7FBgm/XypMN+PHMxtOeI6Cc92Wsu+qZ+65ds0LvMMa6cD9cK816H4TcdVhIlDU1q4RtjMZ7eR5J8pPEGv9PWtrsWc6b3gM5nQUzVYbiithtuPkPIzuFTYXmTTUf2B0fp++kfMU5toilu4zi4vhks6BnF5s/aOYed2lGnrQyMD9lQ90QQ9rqP9CfIGdC0+/Z+BdME/DC+JAVXEkTpj/GLKCazBp7asPgxwe0oJh0Bxlu5j0cQErHhz1mD7tHrJGexnfQogYj215R7Uo9Ra85Kueuc3G8sRygpVXnWRtdQGurQunqZP+YvRm5yzW9jqK28HS6Vs2HFuYgh0dXB0LqxoLGpovDkxwhH1lYI2DlhUBc/PHD0DTI2lSXFRW5rzkq565zcbwsemHeyT/YAReOg5Ie4ToJZvam4KdDe+cpLxNJoFtkDHAzuKU8ziiHIfczq90l6wX/JDq1SOtQTy5W3mHGF6qI="
	// out, _ := base64.StdEncoding.DecodeString(sstr)

	// outbuff, _ := DESECBDecrypt([]byte(out), []byte("ISSMOB01"))

	// fmt.Println(string(outbuff))

	buff, err := json.Marshal(collet)
	if err != nil {
		logger.Errorf("[CEB]postCollet数据序列化错误: %+v.", err)
		return err
		// return fmt.Sprintf("[CEB]%s请求, 原始数据: %+v.", funcName, req)
	}

	logger.Infof("[CEB][%+v] Collet %+v.", acc.Account, string(buff))

	buff, _ = DESECBEncrypt([]byte(buff), []byte("ISSMOB01"))
	body := base64.StdEncoding.EncodeToString(buff)

	req, err := http.NewRequest("POST", urlCollet, strings.NewReader(body))
	if err != nil {
		logger.Errorf("[CEB]getCollet创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Set(headers.ContentType, "application/json")
	req.Header.Set(headers.Accept, "*/*")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s CFNetwork/902.2 Darwin/17.7.0", appVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-cn")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")

	body, err = utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB]getCollet http操作错误: %+v.", err)
		return err
	}
	return nil
}

//发关登录的第一个检测数据
func (acc *Account) getfetchPublicKeyCollet() error {
	//得到Token这里重置一下时间
	acc.tokenIDTime = utils.GetTimeStamp()
	acc.tokenTimeDateStr = utils.GetTimeDateStrEx()
	acc.tokenTimeTimeStr = utils.GetTimeTimeStrEx()

	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	colletSleep(400, 700)

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletLaunch(&reqcollet, sessionid)

	//当前页面sy 切换到tab_sy
	acc.addColletEvent(&reqcollet, "tab_sy", sessionid, "sy", "tab_sy")
	acc.addActivities(&reqcollet, 0, "SYTabBarViewController", utils.RandInt(500, 1000))
	acc.addActivities(&reqcollet, 0, "HomeViewController", utils.RandInt(30, 80))
	acc.addActivities(&reqcollet, 0, "sy", utils.RandInt(5, 20))

	sleep := utils.RandInt(3000, 5000)
	colletSleep1(sleep)

	acc.addColletEvent(&reqcollet, "launch", sessionid, "launchPager", "launch")

	acc.addActivities(&reqcollet, 0, "HomeViewController", sleep)

	acc.postCollet(reqcollet)
	return nil
}

//从右下角我的登录
func (acc *Account) getMobileToLoginCollet() error {

	acc.pageName = "HomeViewController"

	sleep := utils.RandInt(3000, 5000)
	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletEvent(&reqcollet, "wd-dl", sessionid, acc.pageName, "wd-dl")
	acc.addColletLaunch(&reqcollet, sessionid)
	colletSleep1(sleep)
	acc.pageName = "LastLoginViewController" //这里应该是这样才对
	acc.addActivities(&reqcollet, 0, acc.pageName, sleep)
	colletSleep(800, 1000)
	acc.postCollet(reqcollet)
	return nil
}

func (acc *Account) getMobileToLoginCollet1() error {

	acc.pageName = "LastLoginViewController"

	sleep := utils.RandInt(3000, 5000)
	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletEvent(&reqcollet, "wd-dl", sessionid, acc.pageName, "wd-dl")
	acc.addColletLaunch(&reqcollet, sessionid)
	colletSleep1(sleep)
	acc.addActivities(&reqcollet, 0, acc.pageName, sleep)

	acc.postCollet(reqcollet)
	return nil
}

func (acc *Account) getColletToSendSMSPwd() error {

	acc.pageName = "LastLoginViewController"
	sleep := utils.RandInt(3000, 5000)

	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletEvent(&reqcollet, "dly-dlhqyzm", sessionid, acc.pageName, "dly-dlhqyzm")
	acc.addColletLaunch(&reqcollet, sessionid)
	colletSleep(10, 30)
	acc.addActivities(&reqcollet, 0, acc.pageName, sleep)

	acc.postCollet(reqcollet)
	return nil
}

func (acc *Account) getToLoginCollet() error {

	acc.pageName = "LastLoginViewController"
	sleep := utils.RandInt(3000, 5000)

	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletEvent(&reqcollet, "dl-dlsj", sessionid, acc.pageName, "dl-dlsj")
	acc.addColletLaunch(&reqcollet, sessionid)
	colletSleep1(sleep)
	acc.addActivities(&reqcollet, 0, acc.pageName, 1)

	acc.postCollet(reqcollet)

	colletSleep(2000, 4000)
	//切换到首页
	acc.getTosyCollet()
	return nil
}

//登录成功之后不管怎么样先切换到首页
func (acc *Account) getTosyCollet() error {
	acc.pageName = "LastLoginViewController"
	sleep := utils.RandInt(1000, 5000)

	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

	acc.addColletEvent(&reqcollet, "tab_sy", sessionid, acc.pageName, "tab_sy")
	acc.addColletLaunch(&reqcollet, sessionid)
	colletSleep1(sleep)
	acc.pageName = "sy"
	acc.addActivities(&reqcollet, 0, acc.pageName, 1)

	acc.postCollet(reqcollet)
	return nil
}

//查询余额
func (acc *Account) actQryPreCollet() error {

	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

	var reqcollet reqCollet
	reqcollet.AppInfo = acc.getColletAppInfo()
	reqcollet.Deviceinfo = acc.getColletDeviceInfo()
	acc.addColletLaunch(&reqcollet, sessionid)

	acc.addColletEvent(&reqcollet, "zhcx", sessionid, acc.pageName, "zhcx")
	sleep := utils.RandInt(1000, 1500)
	colletSleep1(sleep)
	acc.addActivities(&reqcollet, 0, "VXWebViewController", utils.RandInt(500, 1000))
	acc.addActivities(&reqcollet, 0, "https://mobile.cebbank.com/WDZH/index.html", utils.RandInt(200, 800))
	colletSleep(1000, 1500)
	acc.pageName = "https://mobile.cebbank.com/WDZH/index.html"
	acc.postCollet(reqcollet)
	return nil
}

// //-------------------
// func (acc *Account) getColletBankTransferPre() error {

// 	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

// 	var reqcollet reqCollet
// 	reqcollet.AppInfo = acc.getColletAppInfo()
// 	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

// 	acc.addColletEvent(&reqcollet, "Ys_XZZM", sessionid, "https://mobile.cebbank.com/WDZH/index.html", "Ys_XZZM")
// 	acc.addColletLaunch(&reqcollet, sessionid)
// 	rtime := utils.RandInt(2000, 8000)
// 	acc.addActivities(&reqcollet, 0, "TransferMainViewController", utils.RandInt(2000, 8000))

// 	reqcollet.SessionInfo.Launch[0].Duration = fmt.Sprintf("%d", rtime+utils.RandInt(2000, 8000))

// 	acc.postCollet(reqcollet)
// 	return nil
// }

// func (acc *Account) getColletBankTransfer() error {

// 	sessionid := colletappID + fmt.Sprintf("%d", acc.tokenIDTime) + acc.HardwareInfo.Imei

// 	var reqcollet reqCollet
// 	reqcollet.AppInfo = acc.getColletAppInfo()
// 	reqcollet.Deviceinfo = acc.getColletDeviceInfo()

// 	acc.addColletEvent(&reqcollet, "Ys_XZZM", sessionid, "TransferResultViewController", "Ys_XZZM")
// 	acc.addColletLaunch(&reqcollet, sessionid)

// 	rtime := utils.RandInt(2000, 8000)

// 	acc.addActivities(&reqcollet, 0, "TransferMainViewController", utils.RandInt(2000, 8000))

// 	reqcollet.SessionInfo.Launch[0].Duration = fmt.Sprintf("%d", rtime+utils.RandInt(2000, 8000))

// 	acc.postCollet(reqcollet)
// 	return nil
// }
