package ceb

import (
	"bytes"
	"crypto/aes"
	"crypto/des"
	"crypto/rc4"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"pay/tools"
	"pay/utils"
	"reflect"
	"strconv"
	"strings"

	"github.com/tjfoc/gmsm/sm2"

	"github.com/tjfoc/gmsm/sm4"
)

var (
	errWrongDataSize = errors.New("错误的数据大小")
	errWrongIVSize   = errors.New("错误的向量大小")
	errWrongNumber   = errors.New("错误的数值")
	errPKCS7Trimming = errors.New("PKCS7去除填充失败")
)

//通过发包时生成的时间错计算出一个起点值，用于取MessageNumString中的32位hex字符串用于计算sm4key，解密返回包,
func getCalculateRandomNumberForString(time string) int{

	//取的传入时间戳的前9位
	strPart1 := time[:len(time) - 4]
	strPart2 := time[len(time) - 4:len(time)]

	sumPart1 := 0
	sumPart2 := 0
	for i := 0; i < len(strPart1); i++ {
		ch := strPart1[i]
		intV, _ := strconv.Atoi(string(ch))

		sumPart1 = sumPart1 + intV

	}

	for j := 0; j < len(strPart2); j++ {
		ch := strPart2[j]
		intV, _ := strconv.Atoi(string(ch))

		sumPart2 = sumPart2 + intV

	}

	result := (sumPart1 + 1)*(sumPart2+1) % 224 +1

	return result

}
//解密GetBasicMsg返回的MessageNum，得到MessageNumString用于计算返回包的sm4key,这个数在重启APP后改变
func calculationRandomNumber(MessageNum string)(string,error){
	nMessageNum , err:= base64.StdEncoding.DecodeString(MessageNum)

	if err != nil {
		return "", err
	}

	sMessageNum := hex.EncodeToString(nMessageNum)


	//取基数
	comma := strings.Index(sMessageNum, "0")

	if comma == 0{
		sMessageNum = string([]rune(sMessageNum)[1:])
	}


	//转化为大数
	bigRadixMessageNum,_ := new(big.Int).SetString(sMessageNum,10)

	//右移7位
	bigRadixMessageNum.Rsh(bigRadixMessageNum,7)

	//得到字符串
	messageNumString := hex.EncodeToString(bigRadixMessageNum.Bytes())
	fmt.Println(hex.Dump(bigRadixMessageNum.Bytes()))
	return messageNumString,nil

}

//计算sm4key
func calculateSm4key(messageNumString,timeString string)(string,error){
	//求的起始位置
	nRange := getCalculateRandomNumberForString(timeString)

	sm4Key := messageNumString[nRange:(nRange + 32)]

	return sm4Key,nil
}


//按16位补齐待加密数据,补齐数据为剩余长度值
//0x16f04a2b0: 7b 22 42 61 6e 6b 49 64 22 3a 22 39 39 39 39 22  {"BankId":"9999"
//0x16f04a2c0: 2c 22 63 6c 69 65 6e 74 56 65 72 73 69 6f 6e 22  ,"clientVersion"
//0x16f04a2d0: 3a 22 37 2e 31 2e 30 22 2c 22 63 68 65 63 6b 46  :"7.1.0","checkF
//0x16f04a2e0: 6c 61 67 22 3a 22 74 65 73 74 22 2c 22 4e 65 77  lag":"test","New
//0x16f04a2f0: 56 65 72 73 69 6f 6e 35 32 38 46 6c 61 67 22 3a  Version528Flag":
//0x16f04a300: 22 59 22 2c 22 53 69 67 6e 61 74 75 72 65 22 3a  "Y","Signature":
//0x16f04a310: 22 32 61 33 30 30 37 38 34 32 62 39 32 37 35 65  "2a3007842b9275e
//0x16f04a320: 30 34 61 38 32 31 61 32 62 64 30 31 64 36 63 30  04a821a2bd01d6c0
//0x16f04a330: 66 22 2c 22 4d 65 73 73 54 69 6d 65 53 74 61 6d  f","MessTimeStam
//0x16f04a340: 70 22 3a 22 31 36 30 33 37 39 32 33 38 37 35 39  p":"160379238759
//0x16f04a350: 32 22 7d 0d 0d 0d 0d 0d 0d 0d 0d 0d 0d 0d 0d 0d  2"}.............
func dealInData(inData []byte)([]byte,error){
	if len(inData) == 0{
		return nil,nil
	}

	n := 16 - len(inData) % 16

	//strN := strconv.FormatInt(int64(n), 16)

	for i := 0; i < n; i++{
		inData = append(inData ,byte(n))
	}

	return inData,nil
}


//enPostBody sm4加密 PostData
func enPostBody(inData []byte,messageNumString ,messTimeStamp string)(string,error){

	sm4key,_:= calculateSm4key(messageNumString,messTimeStamp)
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	enData,err :=tools.SM4ECBEncrypt(inData,bSm4key)

	if err != nil{
		return "",err
	}

	fmt.Println(messTimeStamp)
	fmt.Println(sm4key)

	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//处理输入数据
	//newReqData,_:= dealInData(inData)
	//
	//fmt.Println(hex.Dump(newReqData))
	////计算sm4key
	//sm4key,_:= calculateSm4key(messageNumString,messTimeStamp)
	//bSm4key, _ := hex.DecodeString(sm4key)
	////body Sm4加密
	////enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	////enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData1,_ := psbc.SM4ECBEncrypt(newReqData,bSm4key)
	//strEncodeBody := base64.StdEncoding.EncodeToString(enData1)

	return strEncodeBody,nil
}

//enPostBody sm4加密 PostData
func deRespBody(inData []byte,messageNumString ,messTimeStamp string)(string,error){

	sm4key,_:= calculateSm4key(messageNumString,messTimeStamp)
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	enData,err :=tools.SM4ECBDecrypt(inData,bSm4key)

	if err != nil{
		return "",err
	}


	return string(enData),nil
}
//处理返回包
func dealRespData(inData []byte)([]byte,error){
	if len(inData) == 0{
		return nil,nil
	}

	//取最后一个自己
	lastByte := inData[len(inData) - 1]



	newData := inData[:len(inData) - int(lastByte)]
		
		//末尾全部抹零
	for i:= 0;i <= int(lastByte) ;i++  {
		DeleteSliceE(newData, len(newData) - 1)

	}


	return newData,nil
}


// DeleteSliceE deletes the specified subscript element from the slice
// Note that original slice will not be modified
func DeleteSliceE(slice interface{}, index int) (interface{}, error) {
	// check params
	v := reflect.ValueOf(slice)
	if v.Kind() != reflect.Slice {
		return nil, errors.New("target isn't a slice")
	}
	if v.Len() == 0 || index < 0 || index > v.Len()-1 {
		return nil, errors.New("param is invalid")
	}

	dst := reflect.MakeSlice(reflect.TypeOf(slice), 0, 0)
	dst = reflect.AppendSlice(dst, v.Slice(0, index))
	dst = reflect.AppendSlice(dst, v.Slice(index+1, v.Len()))
	return dst.Interface(), nil
}


func sign(data, ts string) string {
	return utils.MD5String(data + headerSalt + ts)
}

func encAesKey(key []byte) (string, error) {
	pub := utils.PublicKeyFromBytes(aesKey, 65537)
	arr, err := utils.RSAEncryptPKCS1v15(key, pub)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(arr), nil
}

func encRC4(buf, key []byte) error {
	c, err := rc4.NewCipher(key)
	if err != nil {
		return err
	}

	// 先加密一些字节
	arr := []byte{}
	for i := 0; i < 0x200; i++ {
		arr = append(arr, byte(i))
	}

	c.XORKeyStream(arr, arr)

	// 加密内容
	c.XORKeyStream(buf, buf)

	return nil
}

func encPassword(pass, ts string) ([]byte, error) {
	arr := []byte(fmt.Sprintf("S%s:%s", ts, pass))
	//key := []byte("1as6jm341lim8pn3")
	key := []byte(utils.NewRandString(16, false))
	pub := utils.PublicKeyFromBytes(rcKey, 65537)

	if err := encRC4(arr, key); err != nil {
		return nil, err
	}

	//fmt.Println("rc4=>", hex.EncodeToString(arr))

	keyBuf, err := utils.RSAEncryptPKCS1v15(key, pub)
	if err != nil {
		return nil, err
	}

	//fmt.Println("rsa=>", hex.EncodeToString(keyBuf))

	utils.ReverseSlice(keyBuf)

	bw := bytes.NewBuffer([]byte{})
	binary.Write(bw, binary.LittleEndian, int32(114353504256513&0x0FFFFFFFF))
	binary.Write(bw, binary.LittleEndian, int32(114353504256513>>32))
	binary.Write(bw, binary.LittleEndian, int32(41984))

	ret := bytes.NewBuffer([]byte{})
	ret.Write([]byte(fmt.Sprintf("%08d", len(keyBuf)+len(bw.Bytes()))))
	ret.Write(bw.Bytes())
	ret.Write(keyBuf)
	ret.Write([]byte(fmt.Sprintf("%08d", len(arr))))
	ret.Write(arr)

	//fmt.Println(hex.EncodeToString(ret.Bytes()))

	return ret.Bytes(), nil
}

func encSM2(data []byte, x, y string) (string, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	data, err := pub.Encrypt(data)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", data[1:]), nil
}



func encSM4ECB(buf, key []byte) (string, error) {
	c, err := sm4.NewCipher(key)
	if err != nil {
		return "", err
	}

	buf = utils.PKCS7Padding(buf, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(buf); i += c.BlockSize() {
		src := buf[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return base64.StdEncoding.EncodeToString(out), nil
}

//时间戳加密
func encTimestamp(time string)(string,error){
	arr := []byte(time)

	//if err != nil {
	//	return "", err
	//}

	sm2Data, err := encSM2(arr, timesm2_x, timesm2_y)

	if err != nil {
		return "", err
	}

	return sm2Data,err
}



func encPayPassword(pass, ts, sm2Key string) ([]byte, error) {
	arr, err := hex.DecodeString(fmt.Sprintf("%02d%sFFFFFFFF", len(pass), pass))
	if err != nil {
		return nil, err
	}

	key, err := base64.StdEncoding.DecodeString(sm2Key)
	if err != nil {
		return nil, err
	}

	n := len(key) / 2
	x := fmt.Sprintf("%x", key[:n])
	y := fmt.Sprintf("%x", key[n:])
	//sm2Data, err := encSM2(arr, x, y)
	sm2Data, err := tools.SM2Encrypt(arr, x, y)
	if err != nil {
		return nil, err
	}

	return encPassword(sm2Data, ts)
}

// DESECBEncrypt 3DESECB加密, 使用PKCS7填充
func DESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = utils.PKCS7Padding(in, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

// DESECBDecrypt ESECB解密, 并去除PKCS7填充
func DESECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errors.New("错误的数据大小")
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	out, err = utils.PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}

// AesECBEncrypt AESECB加密, 使用PKCS7填充
func AesECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = utils.PKCS7Padding(in, c.BlockSize())
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

// AesECBDecrypt AESECB解密, 并去除PKCS7填充
func AesECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(in)%c.BlockSize() != 0 {
		return nil, errWrongDataSize
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	out, err = utils.PKCS7Trimming(out)
	if err != nil {
		return nil, err
	}

	return out, nil
}


func encryp3Des(data, desKey1, desKey2, desKey3 string) string {


	in := []byte(data)
	key1 := []byte(desKey1)
	key2 := []byte(desKey2)
	key3 := []byte(desKey3)

	out, _ := tools.DESECBEncrypt(in, key1)
	fmt.Println(hex.Dump(out))

	//padding := []byte {
	//	0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04,
	//}
	//out = append(out, padding...)
	out, _ = tools.DESECBEncrypt(out, key2)
	fmt.Println(hex.Dump(out))

	//out = append(out, padding...)
	out, _ = tools.DESECBEncrypt(out, key3)
	fmt.Println(hex.Dump(out))

	outData := base64.StdEncoding.EncodeToString(out)


	return utils.URLEncode(utils.URLEncode(outData))
}