package ccb

type requestReq struct {
	ID            string      `json:"id"`
	Preassociated string      `json:"preassociated"`
	Params        interface{} `json:"params"`
	TxCode        string      `json:"txCode"`
	Version       string      `json:"version"`
}

type headerReq struct {
	Device       string `json:"device"`
	ClientAllVer string `json:"clientAllVer"`
	Ext          string `json:"ext"`
	Local        string `json:"local"`
	Platform     string `json:"platform"`
	Language     string `json:"language"`
	Version      string `json:"version"`
	Agent        string `json:"agent"`
}

type bodyJSON struct {
	Request []*requestReq `json:"request"`
	Header  interface{}   `json:"header"`
}

type bodyReq struct {
	MBSKEY   string `json:"MBSKEY"`
	USERID   string `json:"USERID"`
	SKEY     string `json:"SKEY"`
	BRANCHID string `json:"BRANCHID"`
	JSON     string `json:"JSON"`
}

// type LoginParams struct {
// 	MBSKEY          string `json:"MBSKEY"`
// 	USERID          string `json:"USERID"`
// 	TechniquVersion string `json:"techniquVersion"`
// 	DN              string `json:"DN"`
// 	SKEY            string `json:"SKEY"`
// 	BRANCHID        string `json:"BRANCHID"`
// 	SECCODE         string `json:"SECCODE"`
// 	PASSWORD        string `json:"PASSWORD"`
// }

type firstLoginRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode       string `json:"errCode"`
			ErrMessage    string `json:"errMessage"`
			ParamSecurity struct {
				UserToken     string `json:"UserToken"`
				PubKey        string `json:"PubKey"`
				SECCONTROL    string `json:"SECCONTROL"`
				SECMSG        string `json:"SECMSG"`
				LoginNum      string `json:"LoginNum"`
				LastLoginTime string `json:"lastLoginTime"`
			} `json:"param_security"`
			MbcAccount []struct {
				AccNo       string `json:"ACC_NO"`
				AccName     string `json:"ACC_NAME"`
				AccType     string `json:"ACC_TYPE"`
				Status      string `json:"STATUS"`
				BranchCode  string `json:"BRANCH_CODE"`
				BBranchCode string `json:"BBRANCH_CODE"`
			} `json:"MBC_ACCOUNT"`
			SetvarParams struct {
				UserID         string `json:"USERID"`
				Branchid       string `json:"BRANCHID"`
				Skey           string `json:"SKEY"`
				MbsKey         string `json:"MBSKEY"`
				MobileNo       string `json:"MOBILENO"`
				ECIFCustNo     string `json:"ECIFCust_No"`
				ChannelAddress struct {
					RecordNum int    `json:"RCRD_NUM"`
					TimeStamp string `json:"20200102164829"`
					AddrList  []struct {
						DataCenter    string `json:"DATACENTER"`
						Rule          string `json:"RULE"`
						AddressPrefix string `json:"ADDRESS_PREFIX"`
						ClientType    string `json:"CLIENT_TYPE"`
						MultiChannel  string `json:"MULTI_CHANNEL"`
					} `json:"addrList"`
				} `json:"CHANNELADDRESS"`
			} `json:"setvar_params"`
		} `json:"result"`
	} `json:"response"`
}

type bindTokenLoginRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		ErrCode    string `json:"errCode"`
		ErrMessage string `json:"errMessage"`
		TxCode     string `json:"txCode"`
		ID         string `json:"id"`
		Status     string `json:"status"`
		Result     struct {
			ErrCode       string `json:"errCode"`
			ErrMessage    string `json:"errMessage"`
			AlertTips     string `json:"alert_tips"`
			ParamSecurity struct {
				LoginNum      string `json:"LoginNum"`
				LastLoginTime string `json:"lastLoginTime"`
			} `json:"param_security"`
			MbcAccount []struct {
				AccNo       string `json:"ACC_NO"`
				AccName     string `json:"ACC_NAME"`
				AccType     string `json:"ACC_TYPE"`
				Status      string `json:"STATUS"`
				BranchCode  string `json:"BRANCH_CODE"`
				BBranchCode string `json:"BBRANCH_CODE"`
			} `json:"MBC_ACCOUNT"`
			SetvarParams struct {
				UserID         string `json:"USERID"`
				Branchid       string `json:"BRANCHID"`
				Skey           string `json:"SKEY"`
				MbsKey         string `json:"MBSKEY"`
				MobileNo       string `json:"MOBILENO"`
				ECIFCustNo     string `json:"ECIFCust_No"`
				ChannelAddress struct {
					RecordNum int    `json:"RCRD_NUM"`
					TimeStamp string `json:"20200102164829"`
					AddrList  []struct {
						DataCenter    string `json:"DATACENTER"`
						Rule          string `json:"RULE"`
						AddressPrefix string `json:"ADDRESS_PREFIX"`
						ClientType    string `json:"CLIENT_TYPE"`
						MultiChannel  string `json:"MULTI_CHANNEL"`
					} `json:"addrList"`
				} `json:"CHANNELADDRESS"`
			} `json:"setvar_params"`
		} `json:"result"`
	} `json:"response"`
}

type searchBankRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode        string `json:"errCode"`
			ErrMessage     string `json:"errMessage"`
			RegionFlag     string `json:"regionFlag"`
			InAccType      string `json:"inAccType"`
			BankName       string `json:"bankName"`
			BankCode       string `json:"bankCode"`
			InMobileStatus string `json:"inMobileStatus"`
			InBranchCode   string `json:"inBranchCode"`
			CCBInsID       string `json:"CCBIns_ID"`
		} `json:"result"`
	} `json:"response"`
}

type transferSmsCodeRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode          string `json:"errCode"`
			ErrMessage       string `json:"errMessage"`
			Fee              string `json:"fee"`
			FType            string `json:"fType"`
			InAccBbranchCode string `json:"inAccBbranchCode"`
			ReserveSign      string `json:"reserveSign"`
			AccCash          string `json:"accCash"`
			CurFlag          string `json:"curFlag"`
			CardNum          string `json:"cardNum"`
			SecFlow          string `json:"secFlow"`
			SecFlag          string `json:"secFlag"`
			SmsTitle         string `json:"smsTitle"`
			MsgIndex         string `json:"msgIndex"`
			MaxTime          string `json:"maxTime"`
			ResentCount      string `json:"resetcount"`
			SafeContent      string `json:"safeContent"`
			AcmDrwAmt        string `json:"acmDrwAmt"`
		} `json:"result"`
	} `json:"response"`
}

type transferRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode            string `json:"errCode"`
			ErrMessage         string `json:"errMessage"`
			CreditNo           string `json:"creditNo"`
			InAccName          string `json:"inAccName"`
			Amount             string `json:"amount"`
			InAccNo            string `json:"inAccNo"`
			AccNo              string `json:"accNo"`
			AccName            string `json:"accName"`
			BankName           string `json:"bankName"`
			OutAccAfterBalance string `json:"outAccAfterBalance"`
			OriTransactionSN   string `json:"ori_transaction_sn"`
			EvtTraceIDEc       string `json:"EVT_TRACE_ID_EC"`
			RmtStCd            string `json:"Rmt_StCd"`
			BsnRctCD           string `json:"BsnRct_CD"`
			BsnRctInf          string `json:"BsnRct_Inf"`
			SmsNotifyFlag      string `json:"smsNotifyFlag"`
			Safe               struct {
				TxCode   string `json:"txCode"`
				SafeCode string `json:"safeCode"`
				SafeData struct {
					ShowPassword      string `json:"showPassword"`
					ErrCode           string `json:"errCode"`
					ErrMsg            string `json:"errMsg"`
					VoicePrint        string `json:"voicePrint"`
					FaceFeature       string `json:"faceFeature"`
					VerifyOrder       string `json:"verifyOrder"`
					NeedImageValidate string `json:"needImageValidate"`
					Title             string `json:"title"`
				} `json:"safeData"`
			} `json:"safe"`
		} `json:"result"`
	} `json:"response"`
}

type balanceRes struct {
	Success   string `json:"SUCCESS"`
	ErrorCode string `json:"ERRORCODE"`
	ErrorMsg  string `json:"ERRORMSG"`
	AcBa      string `json:"AcBa"`
	AvlBal    string `json:"Avl_Bal"`
}

type detailsInfo struct {
	CreditID   string `json:"Crdeit_Id"`
	Amount     string `json:"Amount"`
	TaxAmount  string `json:"Tax_Amount"`
	TransPlace string `json:"Transplace"`
	DeRemark1  string `json:"De_Remark1"`
	DeRemark2  string `json:"De_Remark2"`
	PayName    string `json:"PayName"`
	OccurDate  string `json:"Occur_Date"`
	KeepAmt    string `json:"KeepAmt"`
	CurCode    string `json:"CurCode"`
	RecAccount string `json:"Rec_Account"`
	TransDate  string `json:"Transdate"`
	TransTime  string `json:"Transtime"`
	Remark     string `json:"Remark"`
	TransSign  string `json:"TransSign"`
}

type detailsRes struct {
	Success      string        `json:"SUCCESS"`
	ErrorCode    string        `json:"ERRORCODE"`
	ErrorMsg     string        `json:"ERRORMSG"`
	DebitAmount  string        `json:"Debit_Amount"`
	CreditAmount string        `json:"Credit_Amount"`
	CurrentPage  string        `json:"Current_Page"`
	TotalPage    string        `json:"TPage"`
	List         []detailsInfo `json:"LIST"`
}

type encryptReq struct {
	MBSKEY   string `json:"MBSKEY"`
	JSON     string `json:"JSON"`
	USERID   string `json:"USERID"`
	SKEY     string `json:"SKEY"`
	BRANCHID string `json:"BRANCHID"`
	DataDic  string `json:"DataDic"`
}

// TransferResultInfo 转帐返回信息, 用于查询
type TransferResultInfo struct {
	CreditNO         string `json:"creditNo"`
	OriTransactionSN string `json:"oriTransactionSN"`
	EvtTraceIDEC     string `json:"evtTraceIdEc"`
	RcvPymtPsAccNO   string `json:"rcvPymtPsAccNo"` // 收款卡号
	ChnlCustNO       string `json:"chnlCustNo"`     // 身份证号
	PyPsnAccNO       string `json:"pyPsnAccNo"`     // 卡号
	RmtAmt           string `json:"rmtAmt"`
	DataDic          string `json:"dataDic"`
	TradeNo          string `json:"tradeNo"`
}

type queryTransferRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ChnlCustNO      string `json:"CHNL_CUST_NO"`     // "370323199803203027",
			EvtTraceIDEC    string `json:"EVT_TRACE_ID_EC"`  // "1010055241577138259018394",
			PyClrgBsnTPCD   string `json:"Py_Clrg_Bsn_TpCd"` //"",
			RmtCcyCD        string `json:"Rmt_CcyCd"`        // 156",
			RmtAmt          string `json:"Rmt_Amt"`          // "0.01",
			AREfDt          string `json:"AR_EfDt"`          // "20191224",
			PyPsnNm         string `json:"Py_Psn_Nm"`        // "宋树雨",
			PyPsnAccNO      string `json:"Py_Psn_AccNo"`     // "6217002340037369941",
			PyPsDpBkNm      string `json:"PyPsDpBk_Nm"`      // "中国建设银行济南长清支行大学科技园分理处",
			PyPsDpBkBrNO    string `json:"PyPsDpBk_BrNo"`    // "105451001409",
			RPPDBnkBrNO     string `json:"RPPDBnk_BrNo"`     // "103100000026",
			RcvPymtPsFullNm string `json:"RcvPymtPs_FullNm"` // "尤康",
			RcvPymtPsAccNO  string `json:"RcvPymtPs_AccNo"`  // "6230520460026137277",
			RPPDBnkNm       string `json:"RPPDBnk_Nm"`       // "中国农业银行资金清算中心",
			RcvbHdCg        string `json:"Rcvb_HdCg"`        // "0",
			FeeAccNO        string `json:"Fee_AccNo"`        // "",
			Rmrk            string `json:"Rmrk"`             // "跨行转出",
			TRNSTCD         string `json:"TRN_ST_CD"`        // "00",
			RmtStCD         string `json:"Rmt_StCd"`         // "ZF05",
			BsnRctInf       string `json:"BsnRct_Inf"`       // "账号、户名不符",
			BsnRctCD        string `json:"BsnRct_CD"`        // "PR09"
		} `json:"result"`
	} `json:"response"`
}

type channelAddressRes struct {
	Header struct {
		Server string `json:"server"`
		Status string `json:"status"`
		Local  string `json:"local"`
		Ext    string `json:"ext"`
	} `json:"header"`
	Response []struct {
		TxCode  string `json:"txCode"`
		ID      string `json:"id"`
		Version string `json:"version"`
		Status  string `json:"status"`
		Result  struct {
			ErrCode        string `json:"errCode"`
			ErrMessage     string `json:"errMessage"`
			ChannelAddress struct {
				RecordNum int    `json:"RCRD_NUM"`
				TimeStamp string `json:"20200102164829"`
				AddrList  []struct {
					DataCenter    string `json:"DATACENTER"`
					Rule          string `json:"RULE"`
					AddressPrefix string `json:"ADDRESS_PREFIX"`
					ClientType    string `json:"CLIENT_TYPE"`
					MultiChannel  string `json:"MULTI_CHANNEL"`
				} `json:"addrList"`
			} `json:"CHANNELADDRESS"`
		} `json:"result"`
	} `json:"response"`
}

type reqURLRes struct {
	Success       string `json:"SUCCESS"`
	MTTC          string `json:"MTTC"`
	TxCode        string `json:"TXCODE"`
	SysEvtTraceID string `json:"SYS_EVT_TRACE_ID"`
	ReqURL        string `json:"REQ_URL"`
}
