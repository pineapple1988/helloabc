package ccb

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// Account 建设银行付帐号
type Account struct {
	Account             string              `json:"account"`
	Password            string              `json:"password"`
	PayPassword         string              `json:"payPassword"`
	Platform            string              `json:"platform"`
	AccNo               string              `json:"accNo"`
	AccName             string              `json:"accName"`
	AccType             string              `json:"accType"`
	BranchCode          string              `json:"barnchCode"`
	BBranchCode         string              `json:"bbarnchCode"`
	UserID              string              `json:"userID"`
	UserToken           string              `json:"userToken"`
	MbsKey              string              `json:"mbsKey"`
	SKey                string              `json:"sKey"`
	SkeyB2c             string              `json:"sKeyB2c"`
	CustNo              string              `json:"custNo"`
	CardNo              string              `json:"cardNo"`
	MultiChannel        string              `json:"multiChannel"`
	ReqURL              string              `json:"reqUrl"`
	Proxy               utils.ProxyInfo     `json:"proxy"`
	IOSHardwareInfo     IOSHardwareInfo     `json:"iosHardwareInfo"`
	AndroidHardwareInfo AndroidHardwareInfo `json:"androidHardwareInfo"`
	http                *http.Client
	jar                 *cookiejar.Jar
	//转账用到的
	targetCard       string
	targetName       string
	amount           string
	note             string
	regionFlag       string
	bankName         string
	bankCode         string
	curFlag          string
	cardNum          string
	secFlow          string
	secFlag          string
	safeContent      string
	fee              string
	inAccBbranchCode string
	reserveSign      string
	fType            string
	// 登录绑定
	secControl string
	secMsg     string
	//
	loginStatus          int32
	loginPadding         int32
	lastPing             int64
	smscodeFailCount     int
	passwordFailCount    int
	payPasswordFailCount int
}

// IOSHardwareInfo ios硬件信息
type IOSHardwareInfo struct {
	Did           string `json:"did"`
	Model         string `json:"model"`
	SysVer        string `json:"sysVer"`
	IPhoneName    string `json:"iphoneName"`
	WifiName      string `json:"wifiName"`
	CarrierName   string `json:"carrierName"`
	UUID          string `json:"uuid"`
	InjectAttr    string `json:"injectAttr"`
	CurrentScreen string `json:"currentScreen"`
	IDFV          string `json:"idfv"`
	IPAddress     string `json:"ipAddress"`
}

// AndroidHardwareInfo 安卓硬件信息
type AndroidHardwareInfo struct {
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[CCB][%+v]错误的登录平台, 平台: %+v.",
				account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(ccbAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(ccbAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			return acc, nil
		}

		logger.Errorf("[CCB][%+v]从缓存加载帐号信息失败, 将重新生成帐号信息, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:             account,
		Password:            utils.PasswordEncrypt(password),
		PayPassword:         utils.PasswordEncrypt(payPassword),
		Platform:            platform,
		Proxy:               utils.ProxyInfo{},
		IOSHardwareInfo:     IOSHardwareInfo{},
		AndroidHardwareInfo: AndroidHardwareInfo{},
	}

	if platform == platformIOS {
		acc.newIOSHardwareInfo()
	} else if platform == platformAndroid {
		acc.newAndroidHardwareInfo()
	}

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CCB][%+v]创建帐户信息成功, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) newIOSHardwareInfo() {
	h := &acc.IOSHardwareInfo
	model, name, screenSize := utils.GetIPhoneModel()
	h.Model = model
	h.IPhoneName = name
	h.CurrentScreen = screenSize
	h.SysVer = utils.GetIPhoneOSVersion()
	h.WifiName = utils.NewWifiName()
	h.CarrierName = utils.NewCarrierName()
	h.UUID, _ = utils.NewUUID(true)
	h.IDFV, _ = utils.NewUUID(true)
	h.InjectAttr = fmt.Sprintf("%s%d", utils.NewRandString(32, false), utils.GetTimeStampEx())
	h.IPAddress = utils.NewLocalIPAddress()
}

func (acc *Account) newAndroidHardwareInfo() {

}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(ccbAccountKey, field)
	if err != nil {
		logger.Errorf("[CCB][%+v]读取缓存帐号信息错误, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[CCB][%+v]缓存帐号信息反序列化错误, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[CCB][%+v]无法将帐号信息序列化为json, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(ccbAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[CCB][%+v]无法将帐号信息缓存到redis, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCCB)
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCCB)
	acc.save()
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCCB, code, reason)
}

func (acc *Account) checkOnline(ts int64) {
	if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 300 {
		// res, err := acc.getBalance()
		// if err != nil {
		// 	logger.Errorf("[CCB][%+v]检查在线状态错误: %+v.", acc.Account, err)
		// 	return
		// }

		// // 还能查, 在线
		// if res.Success == "true" {
		// 	acc.lastPing = ts
		// 	logger.Infof("[CCB][%+v]检查在线状态成功.", acc.Account)
		// 	return
		// }

		// // 重登录
		// if _, err := acc.bindTokenLogin(); err != nil {
		// 	logger.Errorf("[CCB][%+v]重登录错误: %+v.", acc.Account, err)
		// 	acc.lastPing += 20
		// 	return
		// }

		acc.lastPing = ts
		// logger.Infof("[CCB][%+v]重登录成功.", acc.Account)
	}
}

func (acc *Account) doRelogin() error {
	acc.jar, _ = cookiejar.New(nil)
	if config.IsUseProxy() {
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	res, err := acc.bindTokenLogin()
	if err != nil {
		return err
	}

	if res.Header.Status != resCodeSuccess {
		msg := res.Response[0].Result.ErrMessage
		if strings.Contains(msg, "输入信息不正确") {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCCB)
			acc.passwordFailCount++
			if acc.passwordFailCount >= 3 {
				acc.passwordFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[CCB][%+v]重登录连续登录密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		logger.Errorf("[CCB][%+v]重登录登录错误: %+v.", acc.Account, msg)
		return errors.New(msg)
	}

	tips := res.Response[0].Result.AlertTips
	if strings.Contains(tips, "重新进行设备绑定") {
		acc.loginStatus = pay.LoginStatusNone
		pay.AccountKickout(acc.Account, acc.Platform, common.AccountTypeCCB)
		return pay.ErrNeedBindDevice
	}

	acc.UserID = res.Response[0].Result.SetvarParams.UserID
	acc.SKey = res.Response[0].Result.SetvarParams.Skey
	acc.MbsKey = res.Response[0].Result.SetvarParams.MbsKey
	acc.CustNo = res.Response[0].Result.SetvarParams.ECIFCustNo

	if err := acc.getSkey(); err != nil {
		return err
	}

	return nil
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	// case pay.LoginStatusWaitCode:
	// 	logger.Infof("[CCB][%+v]待待验证码登录.", acc.Account)
	// 	return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	case pay.LoginStatusSuccess:
		logger.Infof("[CCB][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[CCB][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[CCB][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	// 拿地址
	if acc.MultiChannel == "" {
		channelAddress, err := acc.queryChannelAddress()
		if err != nil {
			logger.Errorf("[CCB][%+v]获取服务器请求路径操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if channelAddress.Header.Status != resCodeSuccess {
			logger.Errorf("[CCB][%+v]获取服务器请求路径失败, 代码:  %+v, 信息: %+v.",
				acc.Account, channelAddress.Response[0].Result.ErrCode, channelAddress.Response[0].Result.ErrMessage)
			return pay.Error(pay.ErrCodeLoginError, channelAddress.Response[0].Result.ErrMessage, nil)
		}

		for _, v := range channelAddress.Response[0].Result.ChannelAddress.AddrList {
			if v.ClientType == "01" || strings.Contains(v.Rule, "/cmccb/servlet/") {
				acc.MultiChannel = v.MultiChannel
				acc.save()
				logger.Infof("[CCB][%+v]获取MultiChannel成功: %s.", acc.Account, v.MultiChannel)
				break
			}
		}

		// 还是空
		if acc.MultiChannel == "" {
			logger.Errorf("[CCB][%+v]获取MultiChannel为空.", acc.Account)
			return pay.Error(pay.ErrCodeLoginError, "无法获取服务器请求路径, 请重试", nil)
		}
	}

	// 首次登录, 返回请求验证码
	if acc.UserID == "" || acc.UserToken == "" {
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypeCCB)

		logger.Infof("[CCB][%+v]用户首次登录.", acc.Account)
		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	// 正常登录
	res, err := acc.bindTokenLogin()
	if err != nil {
		logger.Errorf("[CCB][%+v]登录操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if res.Header.Status != resCodeSuccess {
		msg := res.Response[0].Result.ErrMessage
		if strings.Contains(msg, "输入信息不正确") {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCCB)
			acc.passwordFailCount++
			if acc.passwordFailCount >= 3 {
				acc.passwordFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[CCB][%+v]连续登录密码错误, 临时冻结帐号.", acc.Account)
			}

			return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
		}

		logger.Errorf("[CCB][%+v]普通登录错误: %+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeLoginError, msg, nil)
	}

	tips := res.Response[0].Result.AlertTips
	if strings.Contains(tips, "重新进行设备绑定") {
		pay.AccountKickout(acc.Account, acc.Platform, common.AccountTypeCCB)
		return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
	}

	acc.UserID = res.Response[0].Result.SetvarParams.UserID
	acc.SKey = res.Response[0].Result.SetvarParams.Skey
	acc.MbsKey = res.Response[0].Result.SetvarParams.MbsKey
	// acc.BranchID = res.Response[0].Result.SetvarParams.Branchid
	acc.CustNo = res.Response[0].Result.SetvarParams.ECIFCustNo

	if len(res.Response[0].Result.MbcAccount) <= 0 {
		logger.Errorf("[CCB][%+v]该帐号银行卡列表为空.", acc.Account)
		return pay.Error(pay.ErrCodeLoginError, pay.ErrNoHaveCardList.Error(), nil)
	}

	if len(res.Response[0].Result.SetvarParams.ChannelAddress.AddrList) != 0 {
		for _, v := range res.Response[0].Result.SetvarParams.ChannelAddress.AddrList {
			if v.ClientType == "01" || strings.Contains(v.Rule, "/cmccb/servlet/") {
				acc.MultiChannel = v.MultiChannel
				logger.Infof("[CCB][%+v]修正MultiChannel为: %s.", acc.Account, v.MultiChannel)
				break
			}
		}
	}

	if acc.CardNo == "" {
		acc.AccNo = res.Response[0].Result.MbcAccount[0].AccNo
		acc.AccName = res.Response[0].Result.MbcAccount[0].AccName
		acc.AccType = res.Response[0].Result.MbcAccount[0].AccType
		acc.BranchCode = res.Response[0].Result.MbcAccount[0].BranchCode
		acc.BBranchCode = res.Response[0].Result.MbcAccount[0].BBranchCode
		logger.Infof("[CCB][%+v]没有指定卡号, 选择默认卡号[%s].", acc.Account, acc.AccNo)
	} else {
		// 找出指定卡号
		exists := false
		for _, v := range res.Response[0].Result.MbcAccount {
			if v.AccNo == acc.CardNo {
				acc.AccNo = v.AccNo
				acc.AccName = v.AccName
				acc.AccType = v.AccType
				acc.BranchCode = v.BranchCode
				acc.BBranchCode = v.BBranchCode
				exists = true
				break
			}
		}

		if !exists {
			return pay.Error(pay.ErrCodeLoginError, fmt.Sprintf("没有找到指定的银行卡号: %s", acc.CardNo), nil)
		}
	}

	// 如果路径为空
	if acc.ReqURL == "" {
		reqURL, err := acc.getReqURL()
		if err != nil {
			logger.Errorf("[CCB][%+v]获取reqUrl操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if reqURL.Success != "true" {
			logger.Errorf("[CCB][%+v]获取reqUrl失败.", acc.Account)
			return pay.Error(pay.ErrCodeLoginError, "无法获取服务器请求路径, 请重试", nil)
		}

		acc.ReqURL = reqURL.ReqURL
		acc.save()
		logger.Infof("[CCB][%+v]获取reqUrl成功: %s.", acc.Account, acc.ReqURL)
	}

	if err := acc.getSkey(); err != nil {
		logger.Errorf("[CCB][%+v]普通登录获取SKey错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	acc.onLoginSuccess()

	logger.Infof("[CCB][%+v]普通登录成功.", acc.Account)

	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypeCCB)

	logger.Infof("[CCB][%+v]退出成功.", acc.Account)
	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[CCB][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[CCB][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)
	// 不在登录状态
	// if acc.loginStatus != pay.LoginStatusSuccess {
	// 	logger.Warnf("[CCB][%+v]发送验证码失败, 帐号尚未登录.", acc.Account)
	// 	return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	// }

	// // 发送操作
	// if err := acc.transferSmsCode(); err != nil {
	// 	logger.Errorf("[CCB][%+v]发送验证码错误: %+v.", acc.Account, err)
	// 	return pay.Error(pay.ErrCodeSendCodeError, pay.ErrMsgSendCodeError, nil)
	// }

	// logger.Infof("[CCB][%+v]发送验证码成功.", acc.Account)
	// return pay.Success(nil)

	// 不用发送验证码
	return nil
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus != pay.LoginStatusSuccess {
		// 非登录成功认为是登录验证码
		logger.Infof("[CCB][%+v]首次验证码登录, 验证码: %+v.", acc.Account, code)
		res, err := acc.firstLogin(code)
		if err != nil {
			logger.Errorf("[CCB][%+v]校验登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if res.Header.Status != resCodeSuccess {
			msg := res.Response[0].Result.ErrMessage
			logger.Errorf("[CCB][%+v]校验登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, res.Response[0].Result.ErrCode, msg)

			if strings.Contains(msg, "手机号码或授权码不正确") {
				acc.smscodeFailCount++
				if acc.smscodeFailCount >= 3 {
					acc.smscodeFailCount = 0
					acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
					logger.Errorf("[CCB][%+v]登录连续验证码错误, 临时冻结帐号.", acc.Account)
				}

				return pay.Error(pay.ErrCodeSMSCodeError, pay.ErrMsgSMSCodeError, nil)
			}

			if strings.Contains(msg, "输入信息不正确") {
				api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCCB)
				acc.passwordFailCount++
				if acc.passwordFailCount >= 3 {
					acc.passwordFailCount = 0
					acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
					logger.Errorf("[CCB][%+v]连续登录密码错误, 临时冻结帐号.", acc.Account)
				}

				return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
			}

			return pay.Error(pay.ErrCodeSMSCodeError, msg, nil)
		}

		acc.passwordFailCount = 0
		acc.smscodeFailCount = 0

		acc.UserID = res.Response[0].Result.SetvarParams.UserID
		acc.UserToken = res.Response[0].Result.ParamSecurity.UserToken
		acc.secControl = res.Response[0].Result.ParamSecurity.SECCONTROL
		acc.secMsg = res.Response[0].Result.ParamSecurity.SECMSG
		acc.SKey = res.Response[0].Result.SetvarParams.Skey
		acc.MbsKey = res.Response[0].Result.SetvarParams.MbsKey
		// acc.BranchID = res.Response[0].Result.SetvarParams.Branchid
		acc.CustNo = res.Response[0].Result.SetvarParams.ECIFCustNo

		// 哪里请求路径不对
		if len(res.Response[0].Result.SetvarParams.ChannelAddress.AddrList) != 0 {
			for _, v := range res.Response[0].Result.SetvarParams.ChannelAddress.AddrList {
				if v.ClientType == "01" || strings.Contains(v.Rule, "/cmccb/servlet/") {
					acc.MultiChannel = v.MultiChannel
					logger.Infof("[CCB][%+v]修正MultiChannel为: %s.", acc.Account, v.MultiChannel)
					break
				}
			}
		}

		acc.save()

		if len(res.Response[0].Result.MbcAccount) <= 0 {
			logger.Errorf("[CCB][%+v]该帐号银行卡列表为空.", acc.Account)
			return pay.Error(pay.ErrCodeLoginError, pay.ErrNoHaveCardList.Error(), nil)
		}

		if acc.CardNo == "" {
			acc.AccNo = res.Response[0].Result.MbcAccount[0].AccNo
			acc.AccName = res.Response[0].Result.MbcAccount[0].AccName
			acc.AccType = res.Response[0].Result.MbcAccount[0].AccType
			acc.BranchCode = res.Response[0].Result.MbcAccount[0].BranchCode
			acc.BBranchCode = res.Response[0].Result.MbcAccount[0].BBranchCode
			logger.Infof("[CCB][%+v]没有指定卡号, 选择默认卡号[%s].", acc.Account, acc.AccNo)
		} else {
			// 找出指定卡号
			exists := false
			for _, v := range res.Response[0].Result.MbcAccount {
				if v.AccNo == acc.CardNo {
					acc.AccNo = v.AccNo
					acc.AccName = v.AccName
					acc.AccType = v.AccType
					acc.BranchCode = v.BranchCode
					acc.BBranchCode = v.BBranchCode
					exists = true
					break
				}
			}

			if !exists {
				return pay.Error(pay.ErrCodeLoginError, fmt.Sprintf("没有找到指定的银行卡号: %s", acc.CardNo), nil)
			}
		}

		// 没有获取到UserToken
		if acc.UserToken == "" {
			// 绑定
			if strings.Contains(acc.secMsg, "系统监测到您已绑定其它设备") {
				res, err := acc.verifyPayPassword(code)
				if err != nil {
					logger.Errorf("[CCB][%+v]重新绑定设备登录错误: %+v.", acc.Account, err)
					return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
				}

				if res.Header.Status != resCodeSuccess {
					msg := res.Response[0].Result.ErrMessage
					logger.Errorf("[CCB][%+v]重新绑定设备登录失败, 代码: %+v, 信息: %+v.", acc.Account, res.Response[0].Result.ErrCode, msg)

					if strings.Contains(msg, "手机号码或授权码不正确") {
						acc.smscodeFailCount++
						if acc.smscodeFailCount >= 3 {
							acc.smscodeFailCount = 0
							acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
							logger.Errorf("[CCB][%+v]重新绑定设备连续验证码错误, 临时冻结帐号.", acc.Account)
						}

						return pay.Error(pay.ErrCodeSMSCodeError, pay.ErrMsgSMSCodeError, nil)
					}

					if strings.Contains(msg, "输入信息不正确") {
						api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCCB)
						acc.passwordFailCount++
						if acc.passwordFailCount >= 3 {
							acc.passwordFailCount = 0
							acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
							logger.Errorf("[CCB][%+v]重新绑定设备登录密码错误, 临时冻结帐号.", acc.Account)
						}

						return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
					}

					return pay.Error(pay.ErrCodeLoginError, msg, nil)
				}

				acc.UserID = res.Response[0].Result.SetvarParams.UserID
				acc.UserToken = res.Response[0].Result.ParamSecurity.UserToken
				acc.SKey = res.Response[0].Result.SetvarParams.Skey
				acc.MbsKey = res.Response[0].Result.SetvarParams.MbsKey
				acc.BranchCode = res.Response[0].Result.SetvarParams.Branchid
				acc.CustNo = res.Response[0].Result.SetvarParams.ECIFCustNo

				acc.passwordFailCount = 0
				acc.smscodeFailCount = 0

			} else {
				logger.Warnf("[CCB][%+v]校验验证码登录无法获取UserToken, 代码: %+v, 信息: %+v.", acc.secControl, acc.secMsg)
				return pay.Error(pay.ErrCodeLoginError, acc.secMsg, nil)
			}
		}

		// 如果路径为空
		if acc.ReqURL == "" {
			reqURL, err := acc.getReqURL()
			if err != nil {
				logger.Errorf("[CCB][%+v]获取reqUrl操作错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
			}

			if reqURL.Success != "true" {
				logger.Errorf("[CCB][%+v]获取reqUrl失败.", acc.Account)
				return pay.Error(pay.ErrCodeLoginError, "无法获取服务器请求路径, 请重试", nil)
			}

			acc.ReqURL = reqURL.ReqURL
			acc.save()
			logger.Infof("[CCB][%+v]获取reqUrl成功: %s.", acc.Account, acc.ReqURL)
		}

		if err := acc.getSkey(); err != nil {
			logger.Errorf("[CCB][%+v]验证码登录获取Skey错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()

		logger.Infof("[CCB][%+v]验证码登录成功, UserID: %+v, UserToken: %s.", acc.Account, acc.UserID, acc.UserToken)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CCB][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.getBalance()
	if err != nil {
		logger.Errorf("[CCB][%+v]查询余额错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CCB][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeReloginError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}
		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.Success != "true" {
		logger.Errorf("[CCB][%+v]查询余额返回失败, 代码: %+v, 信息: %+v.", acc.Account, balance.ErrorCode, balance.ErrorMsg)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.ErrorMsg, nil)
	}

	res := model.AccountBalanceRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data.Amount = balance.AcBa
	res.Data.AmountAvailable = balance.AvlBal

	logger.Infof("[CCB][%+v]查询余额成功, 余额: %+v, 可用余额: %+v.", acc.Account, balance.AcBa, balance.AvlBal)

	return pay.Success(&res)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CCB][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// datetimeConver 把yyyyMMddhhmmss转换成yyyy-MM-dd hh:mm:ss
func datetimeConver(dt string) string {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return dt
	}

	return time.Unix(tmp.Unix(), 0).Format("2006-01-02 15:04:05")
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)

	logger.Infof("[CCB][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 1
	success := false

	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess

	for {
		details, err := acc.getDetails(startDate, endDate, page)
		if err != nil {
			logger.Errorf("[CCB][%+v]查询帐单操作错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[CCB][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeReloginError, err.Error(), nil)
				}

				return acc.doBillList(req, false)
			}

			if !success {
				// 没有查询成功过
				return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
			}

			break
		}

		if details.Success != "true" {
			logger.Errorf("[CCB][%+v]查询帐单返回错误, 代码: %+v, 信息: %+v.", acc.Account, details.ErrorCode, details.ErrorMsg)
			if !success {
				// 没有查询成功过
				return pay.Error(pay.ErrCodeGetBillListError, details.ErrorMsg, nil)
			}

			break
		}

		success = true

		for _, item := range details.List {
			if item.Amount == "" {
				continue
			}

			info := model.AccountBillListInfo{
				TradeNo:       item.CreditID,
				TradeType:     item.TransSign,
				TradeTime:     datetimeConver(fmt.Sprintf("%s%s", item.TransDate, item.TransTime)),
				Amount:        item.Amount,
				AmountRemain:  item.KeepAmt,
				TargetAccount: item.RecAccount,
				TargetName:    item.PayName,
				Comment:       fmt.Sprintf("%s-%s", item.Remark, item.TransPlace),
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.TransSign == "1" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.TransSign == "0" {
					res.Data = append(res.Data, info)
				}
			}
		}

		currPage, err := strconv.Atoi(details.CurrentPage)
		if err != nil {
			logger.Warnf("[CCB][%+v]查询帐单转换当前页码错误: %+v.", acc.Account, err)
			break
		}

		totalPage, err := strconv.Atoi(details.TotalPage)
		if err != nil {
			logger.Warnf("[CCB][%+v]查询帐单转换总页码错误: %+v.", acc.Account, err)
			break
		}

		if currPage >= totalPage {
			break
		}

		page++
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CCB][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBillList(req, true)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if req.SMSCode == "" {
		logger.Infof("[CBC][%+v]第一次转帐请求, 查询目标银行.", acc.Account)
		// 查询目标银行
		bank, err := acc.searchBank(req.TargetAccount)
		if err != nil {
			logger.Errorf("[CBC][%+v]查询转帐目标银行卡信息错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[CCB][%+v]转帐重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeReloginError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if bank.Header.Status != resCodeSuccess {
			logger.Errorf("[CBC][%+v]转帐操作失败: %+v.", acc.Account, bank.Response[0].Result.ErrMessage)
			return pay.Error(pay.ErrCodeTransferError, bank.Response[0].Result.ErrMessage, nil)
		}

		acc.regionFlag = bank.Response[0].Result.RegionFlag
		acc.bankName = bank.Response[0].Result.BankName
		acc.bankCode = bank.Response[0].Result.BankCode

		logger.Infof("[CCB][%+v]查询成功, 目标银行: %+v,银行代码: %+v, 地区: %+v.",
			acc.Account, acc.bankName, acc.bankCode, acc.regionFlag)

		if acc.regionFlag != "1" && acc.bankCode == "" {
			logger.Warnf("[CBC][%+v]查询到暂不支持的银行, 卡号: %+v.", acc.Account, req.TargetAccount)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		// 保存转帐参数
		acc.targetName = req.TargetName
		acc.targetCard = req.TargetAccount
		acc.amount = req.Amount
		acc.note = req.Comment

		// 发送短信验证码
		code, err := acc.transferSmsCode(acc.regionFlag == "1")
		if err != nil {
			logger.Errorf("[CBC][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		acc.curFlag = code.Response[0].Result.CurFlag
		cardNum := code.Response[0].Result.CardNum
		if cardNum != "" {
			acc.cardNum = cardNum
		}

		acc.secFlow = code.Response[0].Result.SecFlow
		acc.secFlag = code.Response[0].Result.SecFlag
		acc.safeContent = code.Response[0].Result.SafeContent
		acc.fee = code.Response[0].Result.Fee
		acc.inAccBbranchCode = code.Response[0].Result.InAccBbranchCode
		acc.reserveSign = code.Response[0].Result.ReserveSign
		acc.fType = code.Response[0].Result.FType

		logger.Infof("[CBC][%+v]发送转帐验证码成功.", acc.Account)
		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	logger.Infof("[CBC][%+v]第二次转帐请求, 确认交易.", acc.Account)
	transfer, body, err := acc.transfer(req.SMSCode, acc.regionFlag == "1", false)
	if err != nil {
		logger.Errorf("[CBC][%+v]转帐操作错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout {
			return pay.Error(pay.ErrCodeTransferStatusUnknow, pay.ErrMsgTransferStatusUnknow, nil)
		}

		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if transfer.Header.Status != resCodeSuccess {
		msg := transfer.Response[0].Result.ErrMessage
		logger.Errorf("[CBC][%+v]转帐操作失败, 代码: %+v, 信息: %+v.", acc.Account, transfer.Response[0].Result.ErrCode, msg)
		return pay.Error(pay.ErrCodeTransferError, msg, nil)
	}

	if transfer.Response[0].Result.Safe.SafeCode != "" {
		// 需要验证密码
		if transfer.Response[0].Result.Safe.SafeData.ShowPassword == "1" {
			transfer, body, err = acc.transfer(req.SMSCode, acc.regionFlag == "1", true)
			if err != nil {
				logger.Errorf("[CBC][%+v]转帐操作验证密码操作错误: %+v.", acc.Account, err)
				if err == pay.ErrSessionTimeout {
					return pay.Error(pay.ErrCodeTransferStatusUnknow, pay.ErrMsgTransferStatusUnknow, nil)
				}

				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if transfer.Header.Status != resCodeSuccess {
				msg := transfer.Response[0].Result.ErrMessage
				logger.Errorf("[CBC][%+v]转帐操作失败, 代码: %+v, 信息: %+v.", acc.Account, transfer.Response[0].Result.ErrCode, msg)
				return pay.Error(pay.ErrCodeTransferError, msg, nil)
			}

		} else {
			return pay.Error(pay.ErrCodeTransferError, transfer.Response[0].Result.Safe.SafeData.Title, nil)
		}
	}

	// 查询是否成功
	if acc.regionFlag == "1" {
		res := model.AccountTransferRes{}
		res.Code = pay.ErrCodeSuccess
		res.Msg = pay.ErrMsgSuccess
		res.ExtData = req.ExtData
		res.Status = common.TransferStatusSuccess

		res.Data.TradeNo = transfer.Response[0].Result.CreditNo
		res.Data.TradeType = "0"
		//res.Data.TradeTime = r.Response[0].Result.
		res.Data.Amount = transfer.Response[0].Result.Amount
		res.Data.AmountRemain = transfer.Response[0].Result.OutAccAfterBalance
		res.Data.TargetAccount = transfer.Response[0].Result.InAccName
		res.Data.TargetName = transfer.Response[0].Result.InAccNo
		res.Data.Comment = req.Comment

		return pay.Success(&res)
	}

	info := TransferResultInfo{
		CreditNO:         transfer.Response[0].Result.CreditNo,
		OriTransactionSN: transfer.Response[0].Result.OriTransactionSN,
		EvtTraceIDEC:     transfer.Response[0].Result.EvtTraceIDEc,
		RcvPymtPsAccNO:   acc.targetCard,
		ChnlCustNO:       acc.UserID,
		PyPsnAccNO:       acc.AccNo,
		RmtAmt:           transfer.Response[0].Result.Amount,
		DataDic:          "1",
		TradeNo:          req.OrderNo,
	}

	status := common.TransferStatusProcessing
	for i := 0; i < 5; i++ {
		time.Sleep(time.Second * 2)
		result, err := acc.queryTransfer(&info)
		if err != nil {
			continue
		}

		if result.Header.Status != resCodeSuccess {
			logger.Errorf("[CCB][%+v]查询转帐状态失败, 流水号: %+v, code: %+v.",
				acc.Account, info.CreditNO, result.Header.Status)
			continue
		}

		// 确认成功的
		if result.Response[0].Result.BsnRctInf == "success" {
			status = common.TransferStatusSuccess
			logger.Infof("[CCB][%+v]查询转帐状态成功, 流水号: %+v.", acc.Account, info.CreditNO)
			break
		}

		// 确认失败的
		status = common.TransferStatusFail
		logger.Infof("[CCB][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.",
			acc.Account, info.CreditNO, result.Response[0].Result.BsnRctInf)
		return pay.Error(pay.ErrCodeTransferError, result.Response[0].Result.BsnRctInf, nil)
	}

	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData
	res.Status = status

	if status == common.TransferStatusProcessing {
		res.Code = pay.ErrCodeTransferStatusUnknow
		res.Msg = pay.ErrMsgTransferStatusUnknow
	}

	if status != common.TransferStatusSuccess {
		key := fmt.Sprintf("%s_%s", ccbTransferInfoKey, info.CreditNO)
		if err := redis.HSetObject(key, info.CreditNO, &info); err != nil {
			logger.Warnf("[CCB][%+v]缓存转帐查询信息错误: %+v.", acc.Account, err)
		}

		if err := redis.PExpire(key, ccbTransferInfoExprieTime); err != nil {
			logger.Warnf("[CCB][%+v]设置转帐查询信息过期时间错误: %+v.", acc.Account, err)
		}
	}

	res.Data.TradeNo = transfer.Response[0].Result.CreditNo
	res.Data.TradeType = "0"
	//res.Data.TradeTime = r.Response[0].Result.
	res.Data.Amount = transfer.Response[0].Result.Amount
	res.Data.AmountRemain = transfer.Response[0].Result.OutAccAfterBalance
	res.Data.TargetAccount = transfer.Response[0].Result.InAccName
	res.Data.TargetName = transfer.Response[0].Result.InAccNo
	res.Data.Comment = req.Comment

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypeCCB,
		req.OrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		status)

	logger.LogTransfer("[CCB][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		req.TargetName,
		req.TargetAccount,
		res.Data.Amount,
		status,
		req.OrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求转帐, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CCB][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[CCB][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	return acc.doTransfer(req, true)
}

func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	key := fmt.Sprintf("%s_%s", ccbTransferInfoKey, req.TradeNo)
	info := TransferResultInfo{}
	if err := redis.GetObject(key, &info); err != nil {
		return pay.Error(pay.ErrCodeTransferStatusError, "无法获取订单信息, 请人工查询", nil)
	}

	result, err := acc.queryTransfer(&info)
	if err != nil {
		logger.Errorf("[CCB][%+v]查询转帐状态错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
	}

	if result.Header.Status != resCodeSuccess {
		logger.Errorf("[CCB][%+v]查询转帐状态失败, 代码: %+v.", acc.Account, result.Header.Status)
		return pay.Error(pay.ErrCodeTransferStatusError, pay.ErrMsgTransferStatusError, nil)
	}

	status := common.TransferStatusProcessing
	if result.Response[0].Result.BsnRctInf == "success" {
		status = common.TransferStatusSuccess
		redis.Del(key)
	} else {
		status = common.TransferStatusFail
	}

	res := model.AccountTransferStatusRes{}
	res.Status = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Status = status

	if status != common.TransferStatusProcessing {
		if info.TradeNo != "" {
			api.NodeTransferStatus(info.TradeNo, status)
		}

		logger.LogTransfer("[CCB][%+v]转帐流水号[%+v]状态更新为: %+v.", acc.Account, info.CreditNO, status)
	}

	return pay.Success(&res)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[CCB][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CCB][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
