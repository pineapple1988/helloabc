package ccb

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/des"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"pay/utils"
)

// AESCBCEncrypt AESCBC加密, 使用PKCS7填充
func AESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	left := len(in) % c.BlockSize()
	if left != 0 {
		padding := c.BlockSize() - left
		for i := 0; i < padding; i++ {
			in = append(in, 0)
		}
	}
	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

// AESECBEncrypt AESECB加密, 填充零
func AESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	left := len(in) % c.BlockSize()
	if left != 0 {
		padding := c.BlockSize() - left
		for i := 0; i < padding; i++ {
			in = append(in, 0)
		}
	}
	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

func desEncrypt(in []byte, key []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	left := len(in) % c.BlockSize()
	if left != 0 {
		padding := c.BlockSize() - left
		for i := 0; i < padding; i++ {
			in = append(in, 0)
		}
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)
		out = append(out, dst...)
	}

	return out, nil
}

func desCbcEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	if len(iv) != c.BlockSize() {
		return nil, errors.New("块错误")
	}

	//in = PKCS7Padding(in, c.BlockSize())

	left := len(in) % c.BlockSize()
	if left != 0 {
		padding := c.BlockSize() - left
		for i := 0; i < padding; i++ {
			in = append(in, 0)
		}
	}

	out := make([]byte, len(in))

	encrypter := cipher.NewCBCEncrypter(c, iv)
	encrypter.CryptBlocks(out, in)

	return out, nil
}

func checkBuff(buff []byte, len int) int {

	i := 0
	result := 0
	for {
		v5 := buff[i]
		v6 := 8
		for {
			v7 := 2*result&0xFFFFFFFE | int(v5>>7)&1
			v5 *= 2
			if (result & 0x8000) > 0 {
				result = v7 ^ 0x1021
			} else {
				result = v7
			}
			v6--
			if v6 <= 0 {
				break
			}
		}

		result = result & 0xffff
		i++
		if i == len {
			break
		}
	}
	return result
}

// func CustonCreateTable(key []byte) []int {
// 	result := make([]int, 258)
// 	for i := 0; i < 258; i++ {
// 		for j := 0; j < 258; j++ {
// 			if i == 0 || i == 1 || i == 2 {
// 				j = 0
// 				continue
// 			} else {
// 				result[i] = j
// 			}
// 		}
// 	}
// 	result1 := result[2:258]
// 	var x8 uint = 0
// 	var w12 int = 0
// 	var w9 uint = 0
// 	var w11 uint = 0
// 	for {
// 		w12 = result1[x8]
// 		w11 = uint(w12+int(w11)+int(key[w9])) & 0xff
// 	}
// }

func md5Encrypt(pass string) string {
	data := []byte(pass)
	has := md5.Sum(data)
	databuf := has[0:16]
	str := base64.StdEncoding.EncodeToString(databuf)
	return str
}

func jsonEncrypt(str string) (string, error) {
	buff, err := utils.TripleDESCBCEncrypt([]byte(str), []byte(postJSONAesKey), []byte(postJSONAesIV))
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(buff), nil
}

func passMd5(pass string) string {
	str := fmt.Sprintf("%s%s", "20160506070809111", pass)

	str = passEncrypt(str)
	randStr := "927576075498146"
	str = fmt.Sprintf("%s|%s||%s", "1.0.0.1", str, randStr)

	buff, err := utils.TripleDESCBCEncrypt([]byte(str), []byte(passAesKey), []byte(passAesIV))
	if err != nil {
		fmt.Println("错误")
	}

	str = base64.StdEncoding.EncodeToString(buff)

	// str = hex.EncodeToString(buff)
	// fmt.Println(str)

	// str := md5Encrypt(md5Encrypt(pass))

	// //后面参数是随机数
	// str = fmt.Sprintf("%s|%s", str, "1496")

	// fmt.Println(str)

	// key := []byte("chenml1024!wuxs")
	// key = append(key, 0x0)

	// buff, err := AESECBEncrypt([]byte(str), key)
	// if err != nil {
	// 	fmt.Println("出错。")
	// }

	// str = hex.EncodeToString(buff)
	// fmt.Println(str)
	// str = string(buff)

	// str = fmt.Sprintf("%s|%s", "1.0.0.1", str)

	return str
}

func passEncrypt(pass string) string {
	algID := 1
	key := []byte("0000000000000000")

	passLen := len(pass)
	if algID == 0 {
		buff, err := desCbcEncrypt([]byte(pass), key, key)
		if err != nil {
			fmt.Println("出错。")
		}

		passBuff := []byte{}

		if passLen <= len(key) {
			for i := 0; i < 8; i++ {
				passBuff = append(passBuff, key[i])
				passBuff = append(passBuff, buff[i])
			}
		} else {
			passBuff = append(passBuff, 0x0)
			passBuff = append(passBuff, 0x8)
			for i := 0; i < 8; i++ {
				passBuff = append(passBuff, key[i])
				passBuff = append(passBuff, buff[i])
			}
			for i := 8; i < len(buff); i++ {
				passBuff = append(passBuff, buff[i])
			}
		}

		check := checkBuff(passBuff[2:len(passBuff)], len(passBuff)-2)
		check1 := check & 0xff
		check2 := check >> 8

		passBuff = append(passBuff, byte(check1))
		passBuff = append(passBuff, byte(check2))

		fmt.Printf("%x", check)

		str := hex.EncodeToString(buff)
		str1 := hex.EncodeToString(passBuff)

		str2 := base64.StdEncoding.EncodeToString(passBuff)
		fmt.Println(str)
		fmt.Println(str1)
		return str2
	} else if algID == 1 {
		buff, err := AESECBEncrypt([]byte(pass), key)
		if err != nil {
			fmt.Println("出错。")
		}

		passBuff := []byte{}

		if passLen <= len(key) {
			for i := 0; i < 8; i++ {
				passBuff = append(passBuff, key[i])
				passBuff = append(passBuff, buff[i])
			}
		} else {
			passBuff = append(passBuff, 0x1)
			passBuff = append(passBuff, 0x10)
			for i := 0; i < 16; i++ {
				passBuff = append(passBuff, key[i])
				passBuff = append(passBuff, buff[i])
			}
			for i := 16; i < len(buff); i++ {
				passBuff = append(passBuff, buff[i])
			}
		}

		check := checkBuff(passBuff[2:len(passBuff)], len(passBuff)-2)
		check1 := check & 0xff
		check2 := check >> 8

		passBuff = append(passBuff, byte(check1))
		passBuff = append(passBuff, byte(check2))

		// fmt.Printf("%x", check)

		// str := hex.EncodeToString(buff)
		// str1 := hex.EncodeToString(passBuff)

		str2 := base64.StdEncoding.EncodeToString(passBuff)
		// fmt.Println(str)
		// fmt.Println(str1)
		return str2

	}

	return ""
}

func desDecrypt(msg string, key []byte) ([]byte, error) {
	in, err := hex.DecodeString(msg)
	if err != nil {
		return nil, err
	}

	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	len := len(in)
	if (len % 8) != 0 {
		len = len - (len % 8)
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len; i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}
