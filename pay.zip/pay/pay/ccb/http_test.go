package ccb

import (
	"encoding/base64"
	"fmt"
	"net/url"
	"pay/data/redis"
	"pay/utils"
	"pay/utils/config"
	"testing"
)

func TestDesEncrypt(t *testing.T) {
	str := passEncrypt("20160506070809111aa121244")
	fmt.Println(str)

	str = passMd5("aa121244")
	fmt.Println(str)
	// key := "01234567"
	// // str := ""

	// aaaa := []byte{0x1, 0x1, 1, 1, 1, 1, 1, 1}

	// data, _ := desEncrypt(aaaa, []byte(key))

	// // str = EncryptDES_ECB(str, key)
	// // fmt.Println(str)
	// str1 := hex.EncodeToString(data)

	// fmt.Println(str1)
	fmt.Println("111111111111111")
}

func TestDecryptJSON(t *testing.T) {
	fmt.Println(utils.GetTimeStrEx())

	str := "MaGjqh48Qj7KpfK5GXcApoF%2BY1PO%2B6hMLbSCGk8L8%2B%2FX8qf3C8%2FMmoNwWOP7Pf3lowxmQFb2r30z6Q%2F1P22tdARwIdb2IVuzh9ObHK7PIR%2FONB96riSjDjjDvhw0EaLOs6puhJoNy19IbJp7Ck78ZiwDDYctaZVU78DMbCW8GiJGLIrKIPHKJDAB7ijjH9RkjDbKm2dnsedIkpFGjrtPJ48SCVKTeY%2BN83NWBF2HiScjQxlr72wEJkpeczIdcOWrMFOhDakcdaKpdhN4egbwNy8CEyPNAqwdjTCrxBNaUfFoffaE9VFm4nQ6iNncO%2BJ3u47lx06PiNGoD%2FO2hHEfuM3Il6PFcn2RuGmjUYNz07G3IsJWsO2CDx1DXYn83J39c1WkL1tDdSxfmlLWqe6JDC5XAYuat1LCiFXAINuShuqNwi8evrg5q4dA%2BkauCbpKyiVVYvlyTkeDxU9QrNUbuymi8OzSjfmDt4cINOFe9qoSEcvLoLrsZ8yBe8lYnw7phrIK%2BxGOLgcKq87mULYDt77KeUxgIWtMqPzz4y3ta6PyBq1sowDNriIyBOmjJhnFYSZlBz1DlmU1%2FHPn%2Fkc7kP1thLiDqjqu6Km0eP87IATTGejDzOJvJLRyReVe7sIaO3zf0xilDX3DPNdWv38LNkS65Dml1bWWhYlPNvZ4pyR78NVMQPzEAWmVdgttTHAhiLLc6Z4jnuPhH5S%2BbxxIMacvjQ40oIcq1rAHE26S9BpDiIbHPXUXtr0VmphgFVYJKiJuKZYYGwfU%2Fec%2FJMEO8zkDRY%2FdFxzu7V85KJYNbx%2Fm36hluNBK2ECoxfU3C8Zx1Az9RXFWpDVSeJUNhmNQa2xJ7bqIg6Lnx8sXHGYjhJH%2BHbZq%2BVjAqiI%2BCmIQ4qrKzOOW7f7Zi84KmmXstZYEeBLo5xiDe7C5%2BeKvhNSv54hRxaRGe8Fr7a3oUfqW5cslQLZqM3xwaZhCDFHAanCxX1%2FyG%2F%2FVmmQa5qIuQQFvMIK9kdsZvQH5uC62cv14dffD%2FTaybdELZqdP20p%2FJv5KAp9r3BRJbyJj1gItcQO6%2BEteextEFHUg1vAEFJF1pOBthdhCD6p5XhTjOeFZTq8PyOaVD0%2FXjA6GAwqCquA2Iq7I75bip4S90MBWfP2aF2WyQ%2B4ljx%2FxDtFVB8ywAuCBaBTuoxDvALAP1fr%2FtUOvWtpj9qdAwFQfwtCXQDUq344bmvZPfItZm9kIhmI9XfODwJFzKqr1Tu3zmbthS4ezKryUvugrdupHpLkA8FJj7By2DaGIzSfSxe4UgONE15o6pGl5GgQQd3dbyqzQO1FrX3uNASLnC%2FHNQS9odFdPa6wdhCQWqr5%2BAOOapWodI3S%2BiMVzRfujY4WzUvm1KoIF4ytJ3J2ZIZZQr3FReHZniTPaGaj9UGQFurgzn67LHl6i921zh%2FyMHBAX"
	str, _ = url.QueryUnescape(str)
	strKey := "spR8lQXnSbegEO45hgg6Ixg9"
	strIv := "lz8SLdwo"

	ddd, _ := base64.StdEncoding.DecodeString(str)

	buff, err := utils.TripleDESCBCDecrypt(ddd, []byte(strKey), []byte(strIv))
	if err != nil {
		fmt.Println("错误")
	}

	str = string(buff)

	fmt.Println(str)

	values := url.Values{}
	values.Add("Cfm_St_Ind", "1")
	values.Add("BRANCHID", "370000000")
	values.Add("TX_TIME", "20190418050543313")
	values.Add("TXCODE", "SJ1001")
	values.Add("MOBIL_NO", "13864183729")
	values.Add("DeviceInfo", "1#10.3.3#iPhone 7 Plus")
	values.Add("MobileClientVersion", "4.1.5.002.VC20190412#201904120000")
	values.Add("PT_STYLE", "3")
	values.Add("ECTIP_SKEY", "gKpdh6")
	values.Add("USERID", "370323199803203027")
	values.Add("PT_LANGUAGE", "CN")
	values.Add("TXN_TERM_INF", "758AB501-86F6-4FAF-B371-D83341545B6F#104.924002#11.563137")
	values.Add("CCB_IBSVersion", "V6")

	fmt.Println(values.Encode())

}

func TestPost(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "aa123456",
	}

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	//16638055194    密码 xql514034 支付密码 514034
	acc, err := NewAccount("13864183729", "xql514034", "369369", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	//str := "MaGjqh48Qj5ugb7Lr4RtHKRn5PNv1NGx7YNrejZ9zzc7HOmP5q5PngIpE8qIJ7lJiSrvRLipLGMrb5Ew55aKUzPGattM+9Mt8iH3IvVpqum+inlKjheQvUlwJz3Sbgt1uPIJ32kTlBpgurSzWQDbImF30Jui3RwTCSGnEriaI0hqTr2rTUbSbxNv5h7T5U1lfh3sLYnejxI/nxRGvriI1VRrJ3VgzLdbT0U7YjxucdyYskAsDpOkFUkFfqzNOZGSnbnM7pjBszSbUMQ1vVURsKfv2eOi7Ru3uynNyF92cuxwbVlWe4OZvhvDufWbJLG24d8t1plyu8lmEx7pkOiEtaWM9HKojru5+pzKh0j/cuRiHpwkyAHG5QO62AzCIodUVrnNvgs48jDPVVEcWfGvWszFMhZcglNW3lCZb0/RLx5EVegfTwPj+YPwIeFADGR2lWZShFgBTVDIh3hyW/j4Sv14WPPhZBbazt7jyezmY6zYW9Ozoo6hNLJj72eM0F55FgLA0AHoRNhoJUqAgAOQYUMHx5SF9Es6WR0wkq+DqaLdmK1wEWQqCEOcj9/piD/OAuhski41WFgfCzbG4qBixwe3KnUmwn3xW6qfZR0h1xqNLI2jrW/JE63m34gALtrCL8HkUqIWYAA69NIxxt6MkcDL3+NMdODH/3Kovr8ivpBxxBZTpWj0SmgVEwXu3CaP+rrRvMEAU3Ac4rK8zZFhuFT2mEikWoP35auyBGu3k8ow2RcVGPs4x2W8iwbkjyToShnZizr2VH72AKRzLIQkZhH1soMV+QmavJ8+I40blRs2q84k1PmkkXddgOT87q9Ig409dDySFxewcIE+VZEn6zTYIoTSFujWaqam6szOY+4lHdZCYiUy3Azw4xSt6Q9ItK3sugx1VHQ3n9pLTTswmowitDh1h0lLfjFA7Mrm+UE="
	str := "MaGjqh48Qj5ugb7Lr4RtHPCCknTjrTtLau5ThFSvY6rbrIQoEYS6pMBqBeKCJr6Po1cvABPW9MBU0yxz0BB+VBvcngeiEYF7zuK93cufJwirocak4kfi093tQbzs/srkxgD58R5lkzHs8Ln5/iRu1u//ACgBQNNdTM1KDud4wMr5k4p98tJALnK6qji6e98+/yZavVG8NqlPb42RGv52Qsltz7X5qO2tl85YImUklqJILVHXcwU0Hs4GeuXN6i1Y9usmSccGsltN1jNktA1wI5iFgbohaX5mLLPLrXaC4uqeyJFYXsWdIL2BosVsLqp4AEvbjxpeEcSlfNXKv10BTZsB5KzR/0pINVoy2bvyVPeVOhnChsqymXl5W8Q5SmcdjaZP2CUGBNu9qrwTD32KPzIXDlOQOTQJn6sS3Ezppfo5DchIySLuHL6wvgH7KjXelIVSk85jkGunx4Jbiwimnw/Une93/jNw0Fd2SuXffcxpzuKgzrIB4npeN2Qh6jioOm0v8/Laz6nQKaFPjV2XVI0iHAwVWeR07KB1Psh+gKspN2o7Ac+2FPPpFRTvPXTvhwUBNC5CkmU3vZ2aYwRkrQsFFiBgoARrs1sfH+fm9o994UtzrSetz677JnQvXoKLkT3s3DZxTw2dAoI5ptQCK8ZPDV/HMJ8rMrm5I8M9erQI3FVLrJj4Xb7dOxOEIH0DZqYhvTRf2ondYtOCXX2Ky0rSsQRW9L5ZzLBwNyzS6H9eiMN4XsJ+GMMOGmurtLWDWNmp1mlCUPJZfmXSAcobUesF7XT/EfpjR19rcOIPaPHMuP+Qtr5ENeaZPyGfBrRZo7pZd7kceixVCq1Yf380RQMRPfln3ur7Mx808SmKqAYnMUOzE0Iv1mTP7MUer5j4ZIJfoyiG/IspAC8kSS5PJjs4G2qxXAiX7zuSsnfDUmhuQ18tDjxlKAHajW1UOYEdEjj2M8eAQNrordkX86J+cWbcyR0tn6I1tLwZmm8VdurOJXmYbzsqyDIYNLwKhZ5QwwT3mLEZn3Ch4Xx26JMkPARdGBDNw4zGWzkQsvYdELzMiR9hp2irbwYO9Lk0kXfpBJwj5s0+Dfz/GY4Lyu9/oTc4shxK3NzdatmLTrlnhl+9IyKUVUzMccGq33kfxur+05DaICz1jcYrwP0lKwzkv3K3H59MGHsy7cVKysHbjLjwj9u6ED+pMaeSTBiuc1WlvieZjyuktGL9K4aDCnxv4R+wigCWSpBKdV1U4Rz+1fE4XSbren0ceMOR0BuO8VwU4YAyA9b++Tbgkda4i32/mOCQiBKdJ4jBz9dz/cU/c6SAiiDpipJrAauU8Oold9rCKkYyc+bAH1NZAa5djrIpX/888aqNVtY1TW1IrCC5IBziq9dIODolvSdjd64iFau2"

	strKey := "spR8lQXnSbegEO45hgg6Ixg9"
	strIv := "lz8SLdwo"

	ddd, _ := base64.StdEncoding.DecodeString(str)

	buff, err := utils.TripleDESCBCDecrypt(ddd, []byte(strKey), []byte(strIv))
	if err != nil {
		fmt.Println("错误")
	}

	str = string(buff)

	fmt.Println(str)

	str = "MaGjqh48Qj5ugb7Lr4RtHKRn5PNv1NGx7YNrejZ9zzc7HOmP5q5PngIpE8qIJ7lJiSrvRLipLGMrb5Ew55aKUzPGattM+9Mt8iH3IvVpqum+inlKjheQvUlwJz3Sbgt1uPIJ32kTlBpgurSzWQDbImF30Jui3RwTCSGnEriaI0hqTr2rTUbSbxNv5h7T5U1lfh3sLYnejxI/nxRGvriI1VRrJ3VgzLdbT0U7YjxucdyYskAsDpOkFUkFfqzNOZGSnbnM7pjBszSbUMQ1vVURsKfv2eOi7Ru3uynNyF92cuxwbVlWe4OZvhvDufWbJLG24d8t1plyu8lmEx7pkOiEtaWM9HKojru5+pzKh0j/cuRiHpwkyAHG5QO62AzCIodUVrnNvgs48jDPVVEcWfGvWszFMhZcglNW3lCZb0/RLx5EVegfTwPj+YPwIeFADGR2lWZShFgBTVDIh3hyW/j4Sv14WPPhZBbazt7jyezmY6zYW9Ozoo6hNLJj72eM0F55FgLA0AHoRNhoJUqAgAOQYUMHx5SF9Es6WR0wkq+DqaLdmK1wEWQqCEOcj9/piD/OAuhski41WFgfCzbG4qBixwe3KnUmwn3xW6qfZR0h1xqNLI2jrW/JE63m34gALtrCL8HkUqIWYAA69NIxxt6MkcDL3+NMdODH/3Kovr8ivpBxxBZTpWj0SmgVEwXu3CaP+rrRvMEAU3Ac4rK8zZFhuFT2mEikWoP35auyBGu3k8ow2RcVGPs4x2W8iwbkjyToShnZizr2VH72AKRzLIQkZhH1soMV+QmavJ8+I40blRs2q84k1PmkkXddgOT87q9Ig409dDySFxewcIE+VZEn6zTYIoTSFujWaqam6szOY+4lHdZCYiUy3Azw4xSt6Q9ItK3sugx1VHQ3n9pLTTswmowitDh1h0lLfjFA7Mrm+UE="
	ddd, _ = base64.StdEncoding.DecodeString(str)

	buff, err = utils.TripleDESCBCDecrypt(ddd, []byte(strKey), []byte(strIv))
	if err != nil {
		fmt.Println("错误")
	}

	str = string(buff)
	fmt.Println("=========================")
	fmt.Println(str)

	acc.Login(20000)

}

func decrypt(str string) ([]byte, error) {
	// var key []byte = []byte{0x4E, 0x54, 0x45, 0x6E, 0x63, 0x72, 0x79, 0x70, 0x74, 0x5F, 0x6B, 0x65, 0x79, 0x21, 0x40, 0x2A, 0x26, 0x25, 0x26, 0x25, 0x5E, 0x23, 0x24, 0x00}
	// var iv []byte = []byte{0x69, 0x6E, 0x69, 0x74, 0x20, 0x56, 0x65, 0x63}
	// strKey := "spR8lQXnSbegEO45hgg6Ixg9"
	// strIv := "lz8SLdwo"

	strKey := "bbzPApD6DkpRIfRNRLAQPAZz"
	strIv := "3HYZJ84E"
	//str, _ = url.QueryUnescape(str)
	buf, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		return nil, err
	}
	// return utils.TripleDESCBCDecrypt(buf, key, iv)
	return utils.TripleDESCBCDecrypt(buf, []byte(strKey), []byte(strIv))
}

func TestTransferCodeDecrypt(t *testing.T) {
	str := `ufDDoO3JqEoD7iJnYP6E9Ub+msQoJKowb3dctKYtAL4dffVIJE7ZijpGZ3Se9/A2P/xcy6UPt/I7sO73rW2GQGAfYVbkh1k2WSEjKn99yQsqwqvmUF7oPrdPIqJS9eTEdvalJkxYQVpTdiCer/itDlAszjeRr2xNa3tNQr2wifEJ5tlwkol5l90B8dPepDU2dKwwRd3O++oLSHjwlemaXvaI/tScT2PEUNIKkJqDWuksVi1SOUOeHxKdgOknAyqV2xaNhJLSY3ug8ZNqRCXCe/AfLM/zQXF3ufau1nCY4XJm0lH/C1nZ35JHhO8pgoS4/7iRRPkgoL5O325KwHGP8tzvRAhlJ2X9d95bsX4o0jIcrPAC6UoFxw7a1AuAWgc2EjjWBE7pt070Z0kbyxKpw2OJhsX2GjCFhVqnj5lkhwLpJpxmcbnB1w==`
	buf, err := decrypt(str)
	if err != nil {
		t.Fatalf("解密失败: %+v.\n", err)
	}

	fmt.Println(string(buf))
	t.Logf("解密结果: %+v.\n", string(buf))
}

func TestTransferDecrypt(t *testing.T) {
	str := `gsu4i8qdbo6fUolv+uHiUcDtrfJMJVpzgiZk/pfMQhOBkyM+MqI9NeyeqnRkrUbmfPotejap4IBPHV+qhZDXaa/VygbmVxiW1AbXDC1REJZFgUmF/WbMqIH6GmR3pDPWepyfOEDzsLoqfX7gkE5b3ZNFHsTzkZqLCxAmYsBdS78/72WVZJ/cjG9vv7tK/jhvWgbitrprtFcVKFhyH2TggCOWlk84LkBxod9Q0Hvhn/LMyZjVzG5MX2PDVUv8CVeQm72d/Nmrz/r73UIRAgr0hlb1ay1k4aBXvssVXPNMIJ9zG5KNWjZ2846sAtGdM+CA4AhX7QAf6fJbKR9lY/eWskrlF0P0hGDBb6NlNhiJlQkvAU+4n9NTTb8cu3mQZASqsqjFGSOyCHak+n2fxqVMn3Y+FwhtGHK+XLVs1KPNgruvaKVXA1s7hrXtMxg+wjKGoV1O3w3tAIE7r/zagUfFnZRdb/oFjE1Ot6vP04bZ3EW/JtOjtiY2IOXjOXKAuD1dI2w1rV36QWJ/mvLu4QRTciamPYl/JMkfuvfOFzVq2COgqvBkWGfDTLOaRMAsEWtHfSD4JuNG1Jt5EYc9DJhi8ltjKMEWhRwS4LWtG3KE6igUFvVEoY83xaGL30pHTyk3D3HRwXS6BEoEYb0sR7OuQdHKTJ7mUE96FD5aFIKi7+6OU2mDN5g9Tzn3pZ0zEnfXhYpcBhJbWwXzT9ejLwR7+DTlQxeOihEyWne/+SR/v3+ixMifCibCoREZvEvkFaKupCEv+YhQwIYcvPyzrF1kxT3XYbQ9MmAMDi2BwycWtcGWKUNUl6aOh2xNRHwzcUEKhtoatmJXnZfLX55PYbXLpzEX29lyc7pKlPteLQGiwPeN0BtOzZvGTiox7gZQru9QLBWn5VzuC8KdZw2IX4Ri+KmbN6AcWFZS1fXcdiz65Yc=`
	buf, err := decrypt(str)
	if err != nil {
		t.Fatalf("解密失败: %+v.\n", err)
	}
	t.Logf("11111111111111111111111Start.\n")
	fmt.Println(string(buf))
	t.Logf("解密结果: %+v.\n", string(buf))

	t.Logf("11111111111111111111111End.\n")
}

func TestDecryptPass(t *testing.T) {
	pass := "88888888"
	pass = fmt.Sprintf("%s%s", "20160506070809111", pass)

	pass = passEncrypt(pass)
	fmt.Println(pass)

	enstr := `1.0.0.1|AAhERhuPsWbmXZRZn3wTAHpybUouoZtDLINB5RYP/oJgGeBJhVwnKlpBEz8=||467867481133937`
	buff, err := utils.TripleDESCBCEncrypt([]byte(enstr), []byte(passAesKey), []byte(passAesIV))
	if err != nil {
		fmt.Println("错误")
	}

	enstr = base64.StdEncoding.EncodeToString(buff)
	fmt.Println(string(enstr))

	str := `EUFX+2wQQ2vDEaBzzhfoxV438tDf4ohKJLVQ3AkInJcH6M0doixHDT1WJ61fokfsomQRN4an67l7dcTl43usyvxy3l+TYhveasIXKc7dVm97UAyN6tWjKzvRpVqfomclXj/GHl/+HXk=`
	// str := `EUFX+2wQQ2skqaLvgm94cMkpeutQTIhnhWv91hHAUtIT6pmowrI3TiVXQE+AePUKiMx6KhuvUyPkb89O0uRj7g7M2TZi4SYdTYRAT58/epTlSNTlVDBojw==`
	buf, _ := base64.StdEncoding.DecodeString(str)
	str111, _ := utils.TripleDESCBCDecrypt(buf, []byte(passAesKey), []byte(passAesIV))
	fmt.Println(string(str111))

}

func TestImage(t *testing.T) {

}