package ccb

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"strconv"
	"strings"

	"github.com/go-http-utils/headers"
)

const (
	userAgent = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.2.2) Gecko/20100316 Firefox/3.6.2"
)

func (acc *Account) getMbcInfo(userToken string) (string, string, string) {
	screenSize := acc.IOSHardwareInfo.CurrentScreen
	screenXY := strings.Split(screenSize, "*")
	x, _ := strconv.Atoi(screenXY[0])
	x = x * 3
	y, _ := strconv.Atoi(screenXY[1])
	y = y * 3
	screenSize = string(x) + "*" + string(y)

	//MBCCB/*//*/00000000000000/*/iPhone Work/*/iOS/*/12.4/*/iPhone/*/1125*2304/*/909F5730-81D1-43F6-AF9D-B7487612DF47/*//*//*/0.000000/*/0.000000/*/0
	mbcUserInfo := fmt.Sprintf(`MBCCB/*/%s/*/00000000000000/*/%s/*/%s/*/%s/*/%s/*/%s/*/%s/*//*//*/0.000000/*/0.000000/*/0`,
		userToken,
		acc.IOSHardwareInfo.IPhoneName,
		"iOS",
		acc.IOSHardwareInfo.SysVer,
		"iPhone",
		screenSize, //iphoneScreenSizeArray 这个分辨率*3
		acc.IOSHardwareInfo.UUID,
	)

	mbcUserInfo = base64.StdEncoding.EncodeToString([]byte(mbcUserInfo))
	//            %E5%BB%BA%E8%A1%8C%E6%89%8B%E6%9C%BA%E9%93%B6%E8%A1%8C/20190412 CFNetwork/978.0.7 Darwin/18.7.0
	userAgent := "%E5%BB%BA%E8%A1%8C%E6%89%8B%E6%9C%BA%E9%93%B6%E8%A1%8C/" + versionDate + " CFNetwork/978.0.7 Darwin/18.7.0"

	//MBCCCB/iPhone/iOS12.4/4.23/1.01/909F5730-81D1-43F6-AF9D-B7487612DF47/chinamworld/1125*2304
	mbcUserAgent := fmt.Sprintf(`MBCCCB/%s/iOS%s/%s/%s/%s/%s/%s`,
		"iPhone", acc.IOSHardwareInfo.SysVer, appVersion, "1.01", acc.IOSHardwareInfo.IDFV, "chinamworld", screenSize)

	return userAgent, mbcUserAgent, mbcUserInfo
}

func (acc *Account) getCookie(name string) string {
	u, err := url.Parse(fmt.Sprintf("https://mobile.ccb.com/%s/cmccb/servlet/ccbNewClient", acc.MultiChannel))
	if err != nil {
		return ""
	}

	cookies := acc.jar.Cookies(u)
	for _, cookie := range cookies {
		if cookie.Name == name {
			v, err := url.QueryUnescape(cookie.Value)
			if err != nil {
				return ""
			}

			return v
		}
	}

	return ""
}

func (acc *Account) updateMBSKey() {
	key := acc.getCookie("CCBIBS1")
	if key != "" {
		acc.MbsKey = key
		logger.Debugf("[CCB]UpdateMSBKey: %+v.", key)
	}
}

func (acc *Account) postHTTPData(data string, res interface{}) (string, error) {
	url := fmt.Sprintf("https://mobile.ccb.com/%s/cmccb/servlet/ccbNewClient", acc.MultiChannel)
	return acc.postHTTPDataEx(url, data, res)
}

func (acc *Account) postHTTPDataEx(url, data string, res interface{}) (string, error) {
	req, err := http.NewRequest("POST", url, strings.NewReader(data))
	if err != nil {
		logger.Errorf("[CCB][%+v]创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	userAgent, mbcUserAgent, mbcUserInfo := acc.getMbcInfo(acc.UserToken)

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.UserAgent, userAgent)
	req.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")

	// Add, Set会修正
	req.Header["clientAllVer"] = []string{clientAllVer}
	req.Header["MBC-User-Agent"] = []string{mbcUserAgent}
	req.Header["MBC-User-Info"] = []string{mbcUserInfo}
	req.Header["UA"] = []string{"IPHONE"}
	req.Header["UserToken"] = []string{acc.UserToken}

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[CCB][%+v]http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		if strings.Contains(err.Error(), "701") {
			return "", pay.ErrSessionTimeout
		}

		return "", pay.ErrOperationError
	}

	acc.updateMBSKey()

	if strings.Contains(body, "Error 404--Not Found") {
		logger.Errorf("[CCB][%+v]http请求响应404: %s.", acc.Account, body)
		return "", pay.ErrOperationError
	}

	if res != nil {
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			logger.Errorf("[CCB][%+v]反序列化响应数据错误, body: %s, err: %+v.", acc.Account, body, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return utils.ReplaceWhiteSpace(body), nil
}

func (acc *Account) getHTTPData(u, data string, res interface{}) (string, error) {
	if u == "" {
		return "", errors.New("url参数错误, 请重新登录")
	}

	reqData, err := jsonEncrypt(data)
	if err != nil {
		logger.Errorf("[CCB][%+v]加密请求数据错误, data: %s, err: %+v.", acc.Account, data, err)
		return "", pay.ErrEncRequestData
	}

	query := url.Values{}
	query.Set("SYS_CODE", "0760")
	query.Set("MP_CODE", "02")
	query.Set("SEC_VERSION", secVersion)
	query.Set("APP_NAME", "com.ccb.ccbDemo")
	query.Set("SKEY", acc.SkeyB2c)
	query.Set("GLOBAL_SKEY", acc.SKey)
	query.Set("ccbParam", reqData)

	url := fmt.Sprintf("%s?%s", u, query.Encode())

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logger.Errorf("[CCB][%+v]创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	_, mbcUserAgent, _ := acc.getMbcInfo("")
	req.Header.Add(headers.ContentType, "application/x-www-form-urlencoded")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add(headers.UserAgent, userAgent)

	req.Header["MBC-User-Agent"] = []string{mbcUserAgent}
	req.Header["UA"] = []string{userAgent}

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[CCB][%+v]http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	body = utils.ReplaceWhiteSpace(body)
	logger.Debugf("[CCB][%+v]httpGet操作成功, data: %s, body: %s.", acc.Account, data, body)

	if strings.Contains(body, "重新登录") {
		return "", pay.ErrSessionTimeout
	}

	if res != nil {
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			logger.Errorf("[CCB][%+v]反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

//第一次登录绑定设备,需要先查询有没有绑定设备，没有绑定设备需要，使用当前的手机号码发送
func (acc *Account) firstLogin(smsCode string) (*firstLoginRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"MBSKEY":          "",
		"USERID":          "",
		"techniquVersion": techniquVersion,
		"DN":              acc.Account,
		"SKEY":            "",
		"BRANCHID":        "",
		"SECCODE":         smsCode,
		"PASSWORD":        fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(acc.getPassword())),
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "Q70021",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   "",
		USERID:   "",
		SKEY:     "",
		BRANCHID: "010231000",
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]firstLogin JSON加密错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "Q70021")

	res := firstLoginRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]fistLogin请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, nil
}

func (acc *Account) verifyPayPassword(smsCode string) (*firstLoginRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"techniquVersion": techniquVersion,
		"DN":              acc.Account,
		"ACCOUNT":         acc.AccNo,
		"ACCPASSWORD":     fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(acc.getPayPassword())),
		"SECCODE":         smsCode,
		"PASSWORD":        fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(acc.getPassword())),
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "Q70021",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   acc.MbsKey,
		USERID:   acc.UserID,
		SKEY:     "",
		BRANCHID: acc.BranchCode,
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]verifyPayPassword JSON加密错误： %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "Q70021")

	res := firstLoginRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]verifyPayPassword请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, nil
}

//已绑定设备登录，需要userID, userToken
func (acc *Account) bindTokenLogin() (*bindTokenLoginRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"UserToken":       acc.UserToken,
		"BRANCHID":        "",
		"MBSKEY":          "",
		"voiceStr":        "",
		"valCode":         "",
		"SKEY":            "",
		"techniquVersion": techniquVersion,
		"MOBILE":          acc.Account,
		"USERID":          acc.UserID,
		"flowNo":          "",
		"PWD":             fmt.Sprintf("%s%s", "!![C#C%B*KeyB$oa11r22d]!!::", passMd5(acc.getPassword())),
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "QU7020",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := bodyReq{
		MBSKEY:   "",
		USERID:   acc.UserID,
		SKEY:     "",
		BRANCHID: "010231000",
		JSON:     string(jsonStr),
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]bindTokenLogin JSON加密错误： %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "QU7020")

	res := bindTokenLoginRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]bindTokenLogin 请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, nil
}

//网银登录成功后发送第一个数据包，获取sKey
func (acc *Account) getSkey() error {
	values := url.Values{}

	values.Add("Cfm_St_Ind", "1")
	values.Add("BRANCHID", acc.BranchCode)
	values.Add("MTTC", "")
	values.Add("TX_TIME", utils.GetTimeStrEx1())
	values.Add("TXCODE", "SJ1001")
	values.Add("MOBIL_NO", acc.Account)
	values.Add("DeviceInfo", "1#"+acc.IOSHardwareInfo.SysVer+"#"+acc.IOSHardwareInfo.IPhoneName)
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("PT_STYLE", "3")
	values.Add("ECTIP_SKEY", acc.SKey)
	values.Add("USERID", acc.UserID)
	values.Add("PT_LANGUAGE", "CN")
	values.Add("TXN_TERM_INF", acc.IOSHardwareInfo.IDFV+"##")
	values.Add("CCB_IBSVersion", "V6")

	res := map[string]string{}
	if _, err := acc.getHTTPData(acc.ReqURL, values.Encode(), &res); err != nil {
		return err
	}

	if res["SUCCESS"] != "true" {
		logger.Errorf("[CCB][%+v]getSkey返回完成状态为假，code: %+v, msg: %+v.",
			acc.Account, res["ERRORCODE"], res["ERRORMSG"])

		return errors.New(res["ERRORMSG"])
	}

	acc.SkeyB2c = res["SKEY"]
	logger.Infof("[CCB][%+v]getSkey成功, SKEY: %+v.", acc.Account, acc.SkeyB2c)

	return nil
}

//查询账户余额
func (acc *Account) getBalance() (*balanceRes, error) {
	values := url.Values{}
	values.Add("TXN_INSID", acc.BranchCode)
	values.Add("BRANCHID", acc.BranchCode)
	values.Add("MTTC", "")
	values.Add("PT_STYLE", "3")
	values.Add("TXN_TERM_INF", acc.IOSHardwareInfo.IDFV+"##")
	values.Add("LNG_ID", "zh-cn")
	values.Add("TXCODE", "SJ5803")
	values.Add("CCB_IBSVersion", "V6")
	values.Add("TXN_ITT_CHNL_ID", "0006")
	values.Add("PT_LANGUAGE", "CN")
	values.Add("MULTI_TENANCY_ID", "CN000")
	values.Add("CshEx_Cd", "1")
	values.Add("TXN_TM", "204761") //050593
	values.Add("Cfm_St_Ind", "1")
	values.Add("TXN_ITT_CHNL_CGY", "10030006")
	values.Add("TXN_DT", utils.GetDateStr1())
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("CcyCd", "156")
	values.Add("USERID", acc.UserID)
	values.Add("DbCrd_CardNo", acc.AccNo)
	values.Add("TX_TIME", utils.GetTimeStrEx1())
	values.Add("DeviceInfo", "1#"+acc.IOSHardwareInfo.SysVer+"#"+acc.IOSHardwareInfo.IPhoneName)
	values.Add("TXN_STFF_ID", "0")

	res := balanceRes{}
	if _, err := acc.getHTTPData(acc.ReqURL, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}

//账单查询
func (acc *Account) getDetails(startDate, endDate string, page int) (*detailsRes, error) {
	if page < 1 {
		page = 1
	}

	values := url.Values{}
	values.Add("Id_Type", "01")
	values.Add("Curcode", "01")
	values.Add("Branch_Code", acc.BBranchCode)
	values.Add("BRANCHID", acc.BranchCode)
	values.Add("MTTC", "")
	values.Add("Account_No", acc.AccNo)
	values.Add("PT_STYLE", "3")
	values.Add("TXN_TERM_INF", acc.IOSHardwareInfo.IDFV+"##")
	values.Add("Acc_Sign", "0")
	values.Add("DiyFlag", "0")
	values.Add("TXCODE", "SJ3102")
	values.Add("CCB_IBSVersion", "V6")
	values.Add("PT_LANGUAGE", "CN")
	values.Add("Cust_No", acc.UserID)
	values.Add("Start_Date", startDate)
	values.Add("End_Date", endDate)
	values.Add("Id_Num", acc.UserID)
	values.Add("Depositno", "")
	values.Add("Cfm_St_Ind", "1")
	values.Add("USERID", acc.UserID)
	values.Add("OutCash", "0")
	values.Add("MobileClientVersion", mobileClientVersion)
	values.Add("Sequenceno", "0")
	values.Add("Cust_Name", utils.URLEncode(acc.AccName))
	values.Add("TX_TIME", utils.GetTimeStrEx1())
	values.Add("Acc_Type", acc.AccType)
	values.Add("Current_Page", fmt.Sprintf("%d", page))
	values.Add("DeviceInfo", "1#"+acc.IOSHardwareInfo.SysVer+"#"+acc.IOSHardwareInfo.IPhoneName)
	values.Add("Pdt_Code", "0101")

	res := detailsRes{}
	if _, err := acc.getHTTPData(acc.ReqURL, values.Encode(), &res); err != nil {
		return nil, err
	}
	return &res, nil
}

//转账记录
func (acc *Account) getTransferDetails() (map[string]interface{}, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"Rsrv_Bmp_ECD":    "0",
		"RcvPymtPs_Nm":    "",
		"Bmp_ECD":         "",
		"StDt":            "",
		"Cst_ID":          acc.CustNo,
		"REC_IN_PAGE":     "5",
		"RcvPymtPs_AccNo": "",
		"EdDt":            "",
		"PAGE_JUMP":       "1",
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "NZN006",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqData := url.Values{}
	reqData.Set("MBSKEY", acc.MbsKey)
	reqData.Set("BRANCHID", acc.BranchCode)
	reqData.Set("USERID", acc.UserID)
	reqData.Set("SKEY", acc.SKey)
	reqData.Set("DataDic", "1")
	reqData.Set("JSON", string(jsonStr))

	res := map[string]interface{}{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]getTransferDetails请求成功, data: %s, body: %s.", acc.Account, string(jsonStr), body)

	return res, nil
}

//查询目标银行名字，代码
func (acc *Account) searchBank(cardno string) (*searchBankRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"inAccNo": cardno,
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "NZN001",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqData := url.Values{}
	reqData.Set("MBSKEY", acc.MbsKey)
	reqData.Set("BRANCHID", acc.BranchCode)
	reqData.Set("USERID", acc.UserID)
	reqData.Set("SKEY", acc.SKey)
	reqData.Set("DataDic", "1")
	reqData.Set("JSON", string(jsonStr))

	res := searchBankRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]searchBank请求成功, data: %s, body: %s.", acc.Account, string(jsonStr), body)

	return &res, nil
}

//发送转账验证码
func (acc *Account) transferSmsCode(isSameBank bool) (*transferSmsCodeRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"accBranchCode":   acc.BranchCode,
		"regionFlag":      acc.regionFlag,
		"accNo":           acc.AccNo,
		"accType":         acc.AccType,
		"amount":          acc.amount,
		"inAccNo":         acc.targetCard,
		"inAccName":       acc.targetName,
		"inetBankWayFlag": "",
	}

	if isSameBank {
		reqParams["selSubAccMsg"] = "0101,01,0,0,人民币"
	} else {
		reqParams["bankCode"] = acc.bankCode
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "NZN002",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	jsonBuff, _ := json.Marshal(&map[string]string{
		"MBSKEY":   acc.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   acc.UserID,
		"SKEY":     acc.SKey,
		"BRANCHID": acc.BranchCode,
		"DataDic":  "1",
	})

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]transferSmsCode JSON加密错误： %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "NZN002")

	res := transferSmsCodeRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	acc.updateMBSKey()

	logger.Debugf("[CCB][%+v]transferSmsCode请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, nil
}

//转账
func (acc *Account) transfer(code string, isSameBank, needPassword bool) (*transferRes, string, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	accCode := "0101"
	if acc.cardNum != "" {
		accCode = acc.cardNum
	}

	curFlag := "01"
	if acc.curFlag != "" {
		curFlag = acc.curFlag
	}

	reqParams := map[string]string{
		"inAccName":       acc.targetName,
		"amount":          acc.amount,
		"curFlag":         curFlag,
		"accCode":         accCode,
		"inAccNo":         acc.targetCard,
		"rmtPstcrpt":      acc.note,
		"accName":         acc.AccName,
		"regionFlag":      acc.regionFlag,
		"inetBankWayFlag": "",
		"accBranchCode":   acc.BranchCode,
		"secFlow":         acc.secFlow,
		"safeContent":     acc.safeContent,
		"secFlag":         acc.secFlag,
		"fee":             acc.fee,
		"accType":         acc.AccType,
		"safeType":        "SMS",
		"accCash":         "0",
		"secCode":         code, //验证码
		"accNo":           acc.AccNo,
	}

	if isSameBank {
		reqParams["reserveSign"] = acc.reserveSign
		reqParams["fType"] = acc.fType
		reqParams["bBranchCode"] = acc.BBranchCode
		reqParams["accFlag"] = "0"
	} else {
		reqParams["bankCode"] = acc.bankCode
		reqParams["bankName"] = acc.bankName
	}

	if needPassword {
		reqParams["safeAccPsw"] = acc.getPayPassword()
		reqParams["operation"] = "verifyPassword"
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "NZN003",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := map[string]string{
		"MBSKEY":   acc.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   acc.UserID,
		"SKEY":     acc.SKey,
		"BRANCHID": acc.BranchCode,
		"DataDic":  "1",
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]transfer JSON加密错误: %+v.", acc.Account, err)
		return nil, "", pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "NZN003")

	res := transferRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, "", err
	}

	logger.Debugf("[CCB][%+v]transfer请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, body, nil
}

func (acc *Account) queryTransfer(info *TransferResultInfo) (*queryTransferRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{
		"ori_transaction_sn": info.OriTransactionSN,
		"EVT_TRACE_ID_EC":    info.EvtTraceIDEC,
		"RcvPymtPs_AccNo":    info.RcvPymtPsAccNO,
		"CHNL_CUST_NO":       info.ChnlCustNO,
		"Py_Psn_AccNo":       info.PyPsnAccNO,
		"Rmt_Amt":            info.RmtAmt,
		"DataDic":            info.DataDic,
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "PGJ004",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := map[string]string{
		"MBSKEY":   acc.MbsKey,
		"JSON":     string(jsonStr),
		"USERID":   acc.UserID,
		"SKEY":     acc.SKey,
		"BRANCHID": acc.BranchCode,
		"DataDic":  "1",
	}

	jsonBuff, _ := json.Marshal(&reqBody)

	reqJSON, err := jsonEncrypt(string(jsonBuff))
	if err != nil {
		logger.Errorf("[CCB][%+v]queryTransfer JSON加密错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	reqData := url.Values{}
	reqData.Set("SIGN", "0")
	reqData.Set("JSON", reqJSON)
	reqData.Set("TXCODES", "PGJ004")

	res := queryTransferRes{}
	body, err := acc.postHTTPData(reqData.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]queryTransfer请求成功, data: %s, body: %s.", acc.Account, string(jsonBuff), body)

	return &res, nil
}

func (acc *Account) queryChannelAddress() (*channelAddressRes, error) {
	reqHeader := headerReq{
		Device:       "iPhone",
		ClientAllVer: clientAllVer,
		Ext:          "",
		Local:        "ZH_cn",
		Platform:     "iOS",
		Language:     "CN",
		Version:      "1.05",
		Agent:        "mbp1.0",
	}

	reqParams := map[string]string{}
	if acc.UserToken != "" {
		reqParams["UserToken"] = acc.UserToken
	} else {
		reqParams["UserDN"] = acc.Account
	}

	request := requestReq{
		ID:            "id1",
		Preassociated: "",
		Params:        reqParams,
		TxCode:        "XA0001",
		Version:       "1.0.0",
	}

	jsonStr, _ := json.Marshal(&bodyJSON{
		Request: []*requestReq{&request},
		Header:  reqHeader,
	})

	reqBody := url.Values{}
	reqBody.Set("MBSKEY", "")
	reqBody.Set("JSON", string(jsonStr))
	reqBody.Set("USERID", "")
	reqBody.Set("SKEY", "")
	reqBody.Set("BRANCHID", "")

	res := channelAddressRes{}
	body, err := acc.postHTTPDataEx(urlccbNewClient, reqBody.Encode(), &res)
	if err != nil {
		return nil, err
	}

	logger.Debugf("[CCB][%+v]queryChannelAddress请求成功, data: %s, body: %s.", acc.Account, reqBody.Encode(), body)

	return &res, nil
}

func (acc *Account) getReqURL() (*reqURLRes, error) {
	values := url.Values{}
	values.Set("CRDT_NO", acc.UserID)
	values.Set("BRANCHID", acc.BranchCode)
	values.Set("MTTC", "")
	values.Set("TX_TIME", utils.GetTimeStrEx1())
	values.Set("Cfm_St_Ind", "1")
	values.Set("TXCODE", "SJ1100")
	values.Set("DeviceInfo", "1#"+acc.IOSHardwareInfo.SysVer+"#"+acc.IOSHardwareInfo.IPhoneName)
	values.Set("MobileClientVersion", mobileClientVersion)
	values.Set("PT_STYLE", "3")
	values.Set("PT_LANGUAGE", "CN")
	values.Set("USERID", acc.UserID)
	values.Set("TXN_TERM_INF", acc.IOSHardwareInfo.IDFV+"##")
	values.Set("CCB_IBSVersion", "V6")

	res := reqURLRes{}
	if _, err := acc.getHTTPData(urlB2CMainPlat00MB, values.Encode(), &res); err != nil {
		return nil, err
	}

	return &res, nil
}
