package ysf

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"payserver/common"
	"strings"

	"github.com/go-http-utils/headers"
)

func (acc *Account) getDefaultUserAgent() string {
	if acc.Platform == platformIOS {
		return "iPhone CHSP"
	} else if acc.Platform == platformAndroid {
		return ""
	}

	return ""
}

// initMobileApp 听云sdk初始化
func (acc *Account) initMobileApp() error {
	url := ""
	str := ""
	licenseKey := ""
	appSign := ""
	userAgent := ""
	if acc.Platform == platformIOS {
		url = fmt.Sprintf("%s?version=%s", urlInitMobileApp, tingyunAppVersionIOS)
		str = fmt.Sprintf(`{"did":"%s","dev":[1,"Apple","%s","iOS","%s","agent-ios","2.7.2",{"uid":"","size":"2"}],"app":["com.unionpay.chsp","wallet","6.16","9F9CC204-D6D2-32CF-B12F-1C9803665AF2","AppStore"]}`,
			"28333436", acc.IOSHardwareInfo.Model, acc.IOSHardwareInfo.SysVer)
		licenseKey = "5d88f0530dc747b0a71bb1c942f6f711"
		appSign = "com.unionpay.chsp"
		userAgent = fmt.Sprintf("NBS Newlens Agent/2.7.2(iOS %s)", acc.IOSHardwareInfo.SysVer)
	}

	body, _ := utils.GZipCompress([]byte(str))

	req, err := http.NewRequest("POST", url, bytes.NewReader(body))
	if err != nil {
		logger.Errorf("[YSF]InitMobileApp创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.ContentEncoding, "gzip")
	req.Header.Add(headers.Accept, "application/json")
	req.Header.Add(headers.AcceptLanguage, "zh-cn")
	req.Header.Add("X-License-Key", licenseKey)
	req.Header.Add("X-App-Sign", appSign)
	req.Header.Set(headers.UserAgent, userAgent)

	result, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]InitMobileApp http操作错误: %+v.", err)
		return err
	}

	logger.Infof("[YSF]InitMobileApp返回: %s.", result)

	res := initMobileAppRes{}
	if err := json.Unmarshal([]byte(result), &res); err != nil {
		logger.Errorf("[YSF]InitMobileApp反序列化响应数据错误: %+v.", err)
		return err
	}

	if res.Status != "success" {
		logger.Warnf("[YSF]InitMobileApp返回失败: %s.", res.Status)
		return errors.New(res.Status)
	}

	acc.TyToken = res.Result.Token
	acc.TyID = res.Result.TyID

	return nil
}

func (acc *Account) sysInit1() error {
	desKey := generateSessionKey(24)
	pub, err := utils.PublicKeyFromString(rsaInit1, 65537, 10)
	if err != nil {
		logger.Errorf("[YSF]SysInit1创建设置rsa分钥错误: %+v.", err)
		return err
	}

	vid, err := desEncrypt([]byte("0000"), desKey)
	if err != nil {
		logger.Errorf("[YSF]SysInit1 DES加密错误: %+v.", err)
		return err
	}

	tk, err := utils.RSAEncryptPKCS1v15(desKey, pub)
	if err != nil {
		logger.Errorf("[YSF]SysInit1 RSA加密错误: %+v.", err)
		return err
	}

	osName := ""
	version := ""
	if acc.Platform == platformIOS {
		osName = "ios"
		version = clientVersionIOS
	} else if acc.Platform == platformAndroid {
		//
	}

	values := url.Values{}
	values.Add("osName", osName)
	values.Add("clientVersion", version)
	values.Add("encryptedTk", fmt.Sprintf("%X", tk))
	values.Add("encryptedVid", fmt.Sprintf("%X", vid))
	values.Add("maxKeyNo", "3")

	url := fmt.Sprintf("%s?%s", urlSysInit, values.Encode())

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logger.Errorf("[YSF]SysInit1创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())

	// TODO: cityCd 邮编, 要按ip地址处理
	req.Header.Add("cityCd", "310000")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]SysInit1 http操作错误: %+v.", err)
		return err
	}

	logger.Infof("[YSF]SysInit1返回: %s.", body)

	return nil
}

func (acc *Account) sysInit2() error {
	desKey := generateSessionKey(24)
	pub, err := utils.PublicKeyFromString(rsaInit2, 65537, 10)
	if err != nil {
		logger.Errorf("[YSF]SysInit2创建设置rsa分钥错误: %+v.", err)
		return err
	}

	userVid := "0000"
	if acc.Vid != "" {
		userVid = acc.Vid
	}

	vid, err := desEncrypt([]byte(userVid), desKey)
	if err != nil {
		logger.Errorf("[YSF]SysInit2 DES加密错误: %+v.", err)
		return err
	}

	tk, err := utils.RSAEncryptPKCS1v15(desKey, pub)
	if err != nil {
		logger.Errorf("[YSF]SysInit2 RSA加密错误: %+v.", err)
		return err
	}

	osName := ""
	version := ""
	if acc.Platform == platformIOS {
		osName = "ios"
		version = clientVersionIOS
	} else if acc.Platform == platformAndroid {
		//
	}

	values := url.Values{}
	values.Add("currentKeyNo", "2")
	values.Add("osName", osName)
	values.Add("clientVersion", version)
	values.Add("encryptedTk", fmt.Sprintf("%X", tk))
	values.Add("encryptedVid", fmt.Sprintf("%X", vid))
	values.Add("maxKeyNo", "3")

	url := fmt.Sprintf("%s?%s", urlSysInit, values.Encode())

	req, err := http.NewRequest("GET", url, nil)
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())

	// TODO: cityCd 邮编, 要按ip地址处理
	req.Header.Add("cityCd", "310000")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]SysInit2创建http请求错误: %+v.", err)
		return err
	}

	logger.Infof("[YSF]SysInit2返回: %s.", body)

	res := sysInit2Res{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]SysInit2响应数据反序列化错误: %+v.", err)
		return err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]SysInit2返回失败, 代码: %s, 信息: %s.", res.Resp, res.Msg)
		return errors.New(res.Msg)
	}

	acc.SID = res.Params.Sid

	ck, err := desDecrypt(res.Params.EncryptedCk, desKey)
	if err != nil {
		logger.Errorf("[YSF]SysInit2解密DESKey错误: %+v.", err)
		return err
	}

	acc.DESKey, err = hex.DecodeString(string(ck))
	if err != nil {
		logger.Errorf("[YSF]SysInit2转换DESKey错误: %+v.", err)
		return err
	}

	vid, err = desDecrypt(res.Params.EncryptedVid, acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]SysInit2解密VID错误: %+v.", err)
		return err
	}

	acc.Vid = string(vid)

	return nil
}

func (acc *Account) infoCollect() error {
	deviceInfo := func() map[string]string {
		if acc.Platform == platformIOS {
			return map[string]string{
				"3022":       acc.IOSHardwareInfo.WifiName,
				"3011":       bundleShortVersionStringIOS,
				"3027":       "",
				"3016":       "zh_CN",
				"3005":       "iPhone",
				"3031":       "2.006048,-1.866607,1.174458",
				"3020":       "",
				"3025":       utils.GetTimeStrEx(),
				"3014":       "10719379456",
				"3003":       "1",
				"devType":    "D003",
				"3019":       acc.IOSHardwareInfo.CarrierName,
				"3008":       acc.IOSHardwareInfo.SysVer,
				"3023":       "0",
				"3012":       acc.IOSHardwareInfo.SysVer,
				"3001":       acc.IOSHardwareInfo.UUID,
				"3017":       "Local Time Zone (Asia/Shanghai (GMT+8) offset 28800)",
				"3006":       acc.IOSHardwareInfo.IPhoneName,
				"injectAttr": acc.IOSHardwareInfo.InjectAttr,
				"3021":       "",
				"3010":       bundleIDIOS,
				"3026":       appVersionIOS,
				"3015":       "0.990000",
				"3004":       acc.IOSHardwareInfo.CurrentScreen,
				"3030":       "0.009365,0.011921,0.044931",
				"3009":       "zh-Hans",
				"3024":       bundleIDIOS,
				"3013":       "2137262320",
				"3002":       acc.IOSHardwareInfo.IDFV,
				"3029":       "2.851520,64.5551155,-4.518950",
				"3018":       acc.IOSHardwareInfo.IPAddress,
				"3007":       "iPhone OS",
			}
		} else if acc.Platform == platformAndroid {
			return map[string]string{}
		}

		return map[string]string{}
	}()

	deviceInfoJSON, err := json.Marshal(&deviceInfo)
	if err != nil {
		logger.Errorf("[YSF]InfoCollect序列化请求数据错误: %+v.", err)
		return err
	}

	key := []byte(aesKey)
	data, err := utils.AESCBCEncrypt(deviceInfoJSON, key, key)
	if err != nil {
		logger.Errorf("[YSF]InfoCollect加密请求数据错误: %+v.", err)
		return err
	}

	body := func(data []byte) string {
		if acc.Platform == platformIOS {
			return fmt.Sprintf(`{"appK%sey":"%s","id":"%s","data":"%s","version":"%s"}`,
				utils.NewRandString(6, false),
				appKeyIOS,
				appIDIOS,
				base64.StdEncoding.EncodeToString(data),
				appVersionIOS)
		} else if acc.Platform == platformAndroid {
			return ""
		}

		return ""
	}(data)

	base64Str := base64.StdEncoding.EncodeToString([]byte(body))
	bodyArr, err := utils.GZipCompress([]byte(base64Str))
	if err != nil {
		logger.Errorf("[YSF]InfoCollect压缩请求数据错误: %+v.", err)
		return err
	}

	req, err := http.NewRequest("POST", urlInfoCollect, bytes.NewReader(bodyArr))
	if err != nil {
		logger.Errorf("[YSF]InfoCollect创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.ContentEncoding, "gzip")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.UserAgent, "wallet/523 CFNetwork/711.3.18 Darwin/14.0.0")

	body, err = utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]InfoCollect http操作错误: %+v.", err)
		return err
	}

	logger.Infof("[YSF]InfoCollect返回: %s.", body)

	res := infoCollectRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]InfoCollect反序列化响应数据错误: %+v.", err)
		return err
	}

	if res.RespCd != "0000" {
		logger.Warnf("[YSF]InfoCollect返回失败, 代码: %s, 错误: %s.", res.RespCd, res.Msg)
		return errors.New(res.Msg)
	}

	acc.DfpSessionID = res.Data.DFPSessionID

	return nil
}

func (acc *Account) verifyDevice() (bool, error) {
	req, err := http.NewRequest("GET", urlVerifyDevice, nil)
	if err != nil {
		return false, err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add("gray", "11111")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add("urid", acc.UserID)
	req.Header.Add("dfpSessionId", acc.DfpSessionID)
	req.Header.Add("sid", acc.SID)
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())
	req.Header.Add("cityCd", "310000")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		return false, err
	}

	arr, err := desDecrypt(body, acc.DESKey)
	if err != nil {
		return false, err
	}

	body = utils.Bytes2String(arr)

	logger.Infof("[YSF]VerifyDevice返回: %+v.", body)

	res := verifyDeviceRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]VerifyDevice反序列化响应数据错误: %+v.", err)
		return false, err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]VerifyDevice返回失败, 代码: %s, 信息: %s.", res.Resp, res.Msg)
		return false, nil
	}

	return true, nil
}

func (acc *Account) userLogin() (bool, error) {
	body := fmt.Sprintf(`{"cntryCode":"+86","loginName":"%s","password":"%s","imageId":"","imageCode":""}`,
		acc.Account, acc.getPassword())

	bodyArr, err := desEncrypt([]byte(body), acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]UserLogin加密请求数据错误: %+v.", err)
		return false, err
	}

	req, err := http.NewRequest("POST", urlUserLogin, strings.NewReader(hex.EncodeToString(bodyArr)))
	if err != nil {
		logger.Errorf("[YSF]UserLogin创建http请求错误: %+v.", err)
		return false, err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add("gray", "11111")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add("dfpSessionId", acc.DfpSessionID)
	req.Header.Add("sid", acc.SID)
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())
	req.Header.Add("cityCd", "310000")

	body, err = utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]UserLogin http操作错误: %+v.", err)
		return false, err
	}

	arr, err := desDecrypt(body, acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]UserLogin解密响应数据错误: %+v.", err)
		return false, err
	}

	body = utils.Bytes2String(arr)

	logger.Infof("[YSF]UserLogin返回: %+v.", body)

	res := userLoginRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]UserLogin反序列化响应数据错误: %+v.", err)
		return false, err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]UserLogin返回失败, 代码: %s, 信息: %s.", res.Resp, res.Msg)
		return false, errors.New(res.Msg)
	}

	if res.Params.NeedVerify == "1" {
		logger.Infof("[YSF]UserLogin需要验证码登录, 帐号: %s.", acc.Account)
		return true, nil
	}

	return false, nil
}

func (acc *Account) userGet() error {
	req, err := http.NewRequest("GET", urlUserGet, nil)
	if err != nil {
		logger.Errorf("[YSF]UserGet创建http请求错误: %+v.", err)
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add("gray", "11111")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add("dfpSessionId", acc.DfpSessionID)
	req.Header.Add("sid", acc.SID)
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())
	req.Header.Add("cityCd", "310000")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]UserGet http操作错误: %+v.", err)
		return err
	}

	arr, err := desDecrypt(body, acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]UserGet解密响应数据错误: %+v.", err)
		return err
	}

	body = utils.Bytes2String(arr)

	logger.Infof("[YSF]UserGet返回: %+v.", body)

	res := userGetRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]UserGet反序列化响应数据错误: %+v.", err)
		return err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]UserGet返回失败, 代码: %+v, 信息: %+v.", res.Resp, res.Msg)
		return errors.New(res.Msg)
	}

	// 登录成功
	acc.UserID = res.Params.URID
	acc.loginStatus = loginStatusSuccess
	acc.save()

	// 添加到登录成功
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeYSF)

	return nil
}

func (acc *Account) sendLoginCode() error {
	arr, err := desEncrypt([]byte("{}"), acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]SendloginCode加密请求数据错误: %+v.", err)
		return err
	}

	req, err := http.NewRequest("POST", urlSendLoginCode, strings.NewReader(hex.EncodeToString(arr)))
	if err != nil {
		logger.Errorf("[YSF]SendLoginCode创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add("gray", "11111")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add("X-Tingyun-Id", fmt.Sprintf("%s;c=2;r=%d", acc.TyID, utils.RandInt(10000000, 200000000)))
	req.Header.Add("dfpSessionId", acc.DfpSessionID)
	req.Header.Add("sid", acc.SID)
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())
	req.Header.Add("cityCd", "310000")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]SendLoginCode http操作错误: %+v.", err)
		return err
	}

	arr, err = desDecrypt(body, acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]SendLoginCode解密响应数据错误: %+v.", err)
		return err
	}

	body = utils.Bytes2String(arr)
	logger.Infof("[YSF]SendLoginCode返回: %+v.", body)

	res := sendLoginCodeRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]SendLoginCode反序列化响应数据错误: %+v.", err)
		return err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]SendLoginCode返回失败, 代码: %s, 信息: %s.", res.Resp, res.Msg)
		return errors.New(res.Msg)
	}

	return nil
}

func (acc *Account) verifyLoginCode(code string) error {
	body := fmt.Sprintf(`{"smsCode":"%s"}`, code)
	arr, err := desEncrypt([]byte(body), acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]VerifyLoginCode加密请求数据错误: %+v.", err)
		return err
	}

	req, err := http.NewRequest("POST", urlVerifyLoginCode, strings.NewReader(hex.EncodeToString(arr)))
	if err != nil {
		logger.Errorf("[YSF]VerifyLoginCode创建http请求错误: %+v.", err)
		return err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add("gray", "11111")
	req.Header.Add(headers.ContentType, "application/json")
	req.Header.Add(headers.AcceptLanguage, "zh-Hans;q=1")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add("X-Tingyun-Id", fmt.Sprintf("%s;c=2;r=%d", acc.TyID, utils.RandInt(10000000, 200000000)))
	req.Header.Add("dfpSessionId", acc.DfpSessionID)
	req.Header.Add("sid", acc.SID)
	req.Header.Add(headers.UserAgent, acc.getDefaultUserAgent())
	req.Header.Add("cityCd", "310000")

	body, err = utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[YSF]VerifyLoginCode http操作错误: %+v.", err)
		return err
	}

	arr, err = desDecrypt(body, acc.DESKey)
	if err != nil {
		logger.Errorf("[YSF]VerifyLoginCode解密响应数据错误: %+v.", err)
		return err
	}

	body = utils.Bytes2String(arr)
	logger.Infof("[YSF]VerifyLoginCode返回: %+v.", body)

	res := verifyLoginCodeRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[YSF]VerifyLoginCode反序列化响应数据错误: %+v.", err)
		return err
	}

	if res.Resp != "00" {
		logger.Warnf("[YSF]VerifyLoginCode返回失败, 代码: %s, 信息: %s.", res.Resp, res.Msg)
		return errors.New(res.Msg)
	}

	return nil
}
