package ysf

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"sync/atomic"
)

// Account 云闪付帐号
type Account struct {
	Account             string              `json:"account"`
	Password            string              `json:"password"`
	PayPassword         string              `json:"payPassword"`
	Platform            string              `json:"platform"`
	Vid                 string              `json:"vid"`
	UserID              string              `json:"userId"`
	DESKey              []byte              `json:"desKey"`
	SID                 string              `json:"sid"`
	DfpSessionID        string              `json:"dfpSessionId"`
	TyToken             string              `json:"tyToken"`
	TyID                string              `json:"tyId"`
	Proxy               utils.ProxyInfo     `json:"proxy"`
	IOSHardwareInfo     IOSHardwareInfo     `json:"iosHardwareInfo"`
	AndroidHardwareInfo AndroidHardwareInfo `json:"androidHardwareInfo"`
	http                *http.Client
	jar                 *cookiejar.Jar
	loginStatus         int32
	loginPadding        int32
}

// IOSHardwareInfo ios硬件信息
type IOSHardwareInfo struct {
	Did           string `json:"did"`
	Model         string `json:"model"`
	SysVer        string `json:"sysVer"`
	IPhoneName    string `json:"iphoneName"`
	WifiName      string `json:"wifiName"`
	CarrierName   string `json:"carrierName"`
	UUID          string `json:"uuid"`
	InjectAttr    string `json:"injectAttr"`
	CurrentScreen string `json:"currentScreen"`
	IDFV          string `json:"idfv"`
	IPAddress     string `json:"ipAddress"`
}

// AndroidHardwareInfo 安卓硬件信息
type AndroidHardwareInfo struct {
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[YSF]错误的登录平台, 帐号: %+v, 平台: %+v.",
				account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(ysfAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(ysfAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			return acc, nil
		}

		logger.Errorf("[YSF]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:             account,
		Password:            utils.PasswordEncrypt(password),
		PayPassword:         utils.PasswordEncrypt(payPassword),
		Platform:            platform,
		Proxy:               utils.ProxyInfo{},
		IOSHardwareInfo:     IOSHardwareInfo{},
		AndroidHardwareInfo: AndroidHardwareInfo{},
	}

	if platform == platformIOS {
		acc.newIOSHardwareInfo()
	} else if platform == platformAndroid {
		acc.newAndroidHardwareInfo()
	}

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[YSF]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)

	return acc, nil
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) newIOSHardwareInfo() {
	h := &acc.IOSHardwareInfo
	model, name, screenSize := utils.GetIPhoneModel()
	h.Model = model
	h.IPhoneName = name
	h.CurrentScreen = screenSize
	h.SysVer = utils.GetIPhoneOSVersion()
	h.WifiName = utils.NewWifiName()
	h.CarrierName = utils.NewCarrierName()
	h.UUID, _ = utils.NewUUID(true)
	h.IDFV, _ = utils.NewUUID(true)
	h.InjectAttr = fmt.Sprintf("%s%d", utils.NewRandString(32, false), utils.GetTimeStampEx())
	h.IPAddress = utils.NewLocalIPAddress()
}

func (acc *Account) newAndroidHardwareInfo() {

}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(ysfAccountKey, field)
	if err != nil {
		logger.Errorf("[YSF]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[YSF]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[YSF]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(ysfAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[YSF]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {

}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	// 各种登录状态
	switch acc.loginStatus {
	case loginStatusWaitCode:
		{
			return &pay.ResultInfo{
				Code: loginCodeWaitCode,
				Msg:  loginMsgWaitCode,
			}
		}
	case loginStatusSuccess:
		{
			return &pay.ResultInfo{
				Code: loginCodeSuccess,
				Msg:  loginMsgSuccess,
			}
		}
	}

	if acc.loginPadding != 0 {
		return &pay.ResultInfo{
			Code: loginCodePadding,
			Msg:  loginMsgPadding,
		}
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
	if err != nil {
		return &pay.ResultInfo{
			Code: loginCodeProxyError,
			Msg:  loginMsgProxyError,
		}
	}

	if pi != nil {
		acc.setProxy(pi.URI, pi.User, pi.Pass)
	}

	acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)

	// if err := acc.initMobileApp(); err != nil {
	// 	return &pay.ResultInfo{
	// 		Code: loginCodeInitMobileAppError,
	// 		Msg:  loginMsgInitMobileAppError,
	// 	}
	// }

	if err := acc.sysInit1(); err != nil {
		return &pay.ResultInfo{
			Code: loginCodeSysInit1Error,
			Msg:  loginMsgSysInit1Error,
		}
	}

	if err := acc.sysInit2(); err != nil {
		return &pay.ResultInfo{
			Code: loginCodeSysInit2Error,
			Msg:  loginMsgSysInit2Error,
		}
	}

	if err := acc.infoCollect(); err != nil {
		return &pay.ResultInfo{
			Code: loginCodeInfoCollectError,
			Msg:  loginMsgInfoCollectError,
		}
	}

	if acc.UserID == "" {
		needCode, err := acc.userLogin()
		if err != nil {
			return &pay.ResultInfo{
				Code: loginCodeLoginError,
				Msg:  err.Error(),
			}
		}

		if needCode {
			acc.loginStatus = loginStatusWaitCode
			return &pay.ResultInfo{
				Code: loginCodeNeedCode,
				Msg:  loginMsgNeedCode,
			}
		}
	} else {
		success, err := acc.verifyDevice()
		if err != nil {
			return &pay.ResultInfo{
				Code: loginCodeVerifyDeviceError,
				Msg:  loginMsgVerifyDeviceError,
			}
		}

		if !success {
			return &pay.ResultInfo{
				Code: loginCodeNeedRelogin,
				Msg:  loginMsgNeedRelogin,
			}
		}
	}

	if err := acc.userGet(); err != nil {
		return &pay.ResultInfo{
			Code: loginCodeUserGetError,
			Msg:  loginMsgUserGetError,
		}
	}

	return &pay.ResultInfo{
		Code: loginCodeSuccess,
		Msg:  loginMsgSuccess,
	}
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeYSF)
	api.ReportAccStateLogout(acc.Account, acc.Platform, common.AccountTypeYSF)
	return &pay.ResultInfo{
		Code: logoutCodeSuccess,
		Msg:  logoutMsgSuccess,
	}
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	if err := acc.setPassword(password, payPassword); err != nil {
		return &pay.ResultInfo{
			Code: resetPasswordCodeError,
			Msg:  resetPasswordMsgError,
		}
	}

	return &pay.ResultInfo{
		Code: resetPasswordCodeSuccess,
		Msg:  resetPasswordMsgSuccess,
	}
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	if acc.loginStatus != loginStatusWaitCode {
		return &pay.ResultInfo{
			Code: sendCodeCodeNotNeed,
			Msg:  sendCodeMsgNotNeed,
		}
	}

	if err := acc.sendLoginCode(); err != nil {
		return &pay.ResultInfo{
			Code: sendCodeCodeError,
			Msg:  err.Error(),
		}
	}

	return &pay.ResultInfo{
		Code: sendCodeCodeSuccess,
		Msg:  sendCodeMsgSuccess,
	}
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	if acc.loginStatus != loginStatusWaitCode {
		return &pay.ResultInfo{
			Code: verifyCodeCodeNotNeed,
			Msg:  verifyCodeMsgNotNeed,
		}
	}

	if err := acc.verifyLoginCode(code); err != nil {
		return &pay.ResultInfo{
			Code: verifyCodeCodeError,
			Msg:  err.Error(),
		}
	}

	go acc.userGet()

	return &pay.ResultInfo{
		Code: verifyCodeCodeSuccess,
		Msg:  verifyCodeMsgSuccess,
	}
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	return nil
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	return nil
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	return nil
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	return nil
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	return nil
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {

}
