package ysf

import (
	"crypto/des"
	"encoding/hex"
	"pay/utils"
)

func desEncrypt(in []byte, key []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	left := len(in) % c.BlockSize()
	if left != 0 {
		padding := c.BlockSize() - left
		for i := 0; i < padding; i++ {
			in = append(in, 0)
		}
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len(in); i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Encrypt(dst, src)
		out = append(out, dst...)
	}

	return out, nil
}

func desDecrypt(msg string, key []byte) ([]byte, error) {
	in, err := hex.DecodeString(msg)
	if err != nil {
		return nil, err
	}

	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	len := len(in)
	if (len % 8) != 0 {
		len = len - (len % 8)
	}

	out := []byte{}
	dst := make([]byte, c.BlockSize())
	for i := 0; i < len; i += c.BlockSize() {
		src := in[i : i+c.BlockSize()]
		c.Decrypt(dst, src)

		out = append(out, dst...)
	}

	return out, nil
}

func generateSessionKey(len int) []byte {
	r := make([]byte, len)
	for i := 0; i < len; i++ {
		r[i] = byte(utils.RandIntn(255))
	}

	return r
}
