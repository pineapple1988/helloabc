package ysf

import (
	"fmt"
	"pay/data/redis"
	"pay/utils/config"
	"testing"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1",
		DBPort: 6379,
		DBPass: "aa123456",
	}

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	//16638055194    密码 xql514034 支付密码 514034
	acc, err := NewAccount("16638055194", "xql514034", "514034", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	if err := acc.Login(20000); err != nil {
		t.Fatalf("登录错误: %+v.", err)
	}
}

func TestDES(t *testing.T) {
	key := []byte{
		0x91, 0x9b, 0x06, 0x3c, 0x59, 0xd4, 0x6e, 0x16, 0xea, 0x28, 0xf1, 0x49, 0x49, 0x03, 0x51, 0x53,
		0x91, 0x9b, 0x06, 0x3c, 0x59, 0xd4, 0x6e, 0x16,
	}

	in := []byte{
		0x30, 0x30, 0x30, 0x30,
	}

	out, err := desEncrypt(in, key)
	if err != nil {
		t.Fatalf("err: %+v.", err)
	}

	//5819EC6F09C3817A
	fmt.Printf("%x.\n", out)
}
