package ysf

type initMobileAppRes struct {
	Status string `json:"status"`
	Result struct {
		Token string `json:"token"`
		TyID  string `json:"tyId"`
	} `json:"result"`
}

type sysInit2Res struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
		EncryptedVid string `json:"encryptedVid"`
		EncryptedCk  string `json:"encryptedCk"`
		Sid          string `json:"sid"`
		Gray         string `json:"gray"`
		RespCode     string `json:"respCode"`
		RespMsg      string `json:"respMsg"`
	} `json:"params"`
}

type infoCollectRes struct {
	RespCd string `json:"respCd"`
	Msg    string `json:"msg"`
	Data   struct {
		DFPSessionID string `json:"dfpSessionId"`
	} `json:"data"`
}

type userLoginRes struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
		ImageID     string `json:"imageId"`
		ImageHexStr string `json:"imageHexStr"`
		NeedVerify  string `json:"needVerify"`
		MaskMobile  string `json:"maskMobile"`
		HceUserID   string `json:"hceUserId"`
		RespCode    string `json:"respCode"`
		RespMsg     string `json:"respMsg"`
	} `json:"params"`
}

type sendLoginCodeRes struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
		RespCode string `json:"respCode"`
		RespMsg  string `json:"respMsg"`
	} `json:"params"`
}

type verifyLoginCodeRes struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
		RespCode string `json:"respCode"`
		RespMsg  string `json:"respMsg"`
	} `json:"params"`
}

type verifyDeviceRes struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
	} `json:"params"`
}

type userGetRes struct {
	Resp   string `json:"resp"`
	Msg    string `json:"msg"`
	Params struct {
		URID string `json:"urid"`
	} `json:"params"`
}
