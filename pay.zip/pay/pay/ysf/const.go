package ysf

const (
	ysfAccountKey               = "YSFAccount"
	ysfCookiePrefix             = "YSFCookie"
	platformIOS                 = "ios"
	platformAndroid             = "android"
	timerUpdate                 = 1000
	timerUpdateInterval         = 1000
	tingyunAppVersionIOS        = "2.2.6"
	clientVersionIOS            = "68"
	bundleShortVersionStringIOS = "6.1.6"
	bundleIDIOS                 = "com.unionpay.chsp"
	appVersionIOS               = "01.00.07"
	appKeyIOS                   = "a7yg5tghw1r8gh5s"
	appIDIOS                    = "110005"
)

const (
	rsaInit1 = "18339517381827265589924728533530791541674643687500503344721874186609928362517014722973967303151827715043782042466947087865194401832757701016104883823897027828953449366207604025813090131703076984870991175766173974905587809645192009508901646318002302618083900727214673483516690000820211832760444973449926299789120899202804098591224226086247861612535531805572322268080615594684048283257614597787790957946872011823256136953139094716026094695746836047165485008327716161939923159581677221327606278261430875465662650876721559291872211463330899202377757406164311536265621835011235136282491700283466817468600502686393744683489"
	rsaInit2 = "17725065609758934834729017420118386428027746543358434184077093844306402456225535577593051440226834397540736411971355559307595423454494110943334235618761640203929837168020168897507300532023235296764839545808610798670509866938422728394398361563086895529660232081815882470156474269405866693854401917240484913372433878758000849711697198308390030555221239806732908397927333864239341554324691743482846372452598949129643577936834470926217153667283817051823655400414645970391333693129833602106200612637125328877837340231663175302959499472048212609517708058912693777636555425241414101814672797274408699025373958773698146916727"
	rsaPay1  = "27822011345320821507643159523573919783524858643451112141447942780406190423654619699060538477481825441820722866137371269409970983058096291461521269569373969358094927064599165847887449639047076525976490029485478933886618763748426217141802384915610655846001874287896609503948423927466164540052114952996715602919537718893879936178194891321291669858749642240664861610348877582260335889464060601540072483388836266411523416830861789376687883347756522133557815868938584223097495921865967804897373649207498208711523464212433665101493068338328285961014689698627023671693929606575355769019880064181481404101091211204004423263021"
	rsaPay2  = "24978456104506129337006693910043386263339247157427797858916653481450206272221169964053574507714139794157526797418180902502011999381460198984985428156411478890933288726651819651555274441433619530011528726187638952554603551937883221666783505105913516785138659309705691359227920777968258832509682208288961955082327953756586108868446216997514644479402376512229206981468336000990998641839878250504720735270566938625482649520037325969411075006777581678726841486455878331900290478257500269434585705653868941804768993468250945225139253727855093383169040666177172990240403354146081513597405133822937499462471230230179370385387"
	aesKey   = "1234567890asdfgh"
)

const (
	urlInitMobileApp       = "https://tysdk.95516.com/tingyunapp/initMobileApp"
	urlSysInit             = "https://wallet.95516.com/app/inApp/sys/init"
	urlInfoCollect         = "https://device.95516.com/dcs_svc/rest/outer/devinfo/infoCollect"
	urlUserLogin           = "https://wallet.95516.com/app/inApp/user/login"
	urlSendLoginCode       = "https://wallet.95516.com/app/inApp/user/sendLoginCode"
	urlVerifyLoginCode     = "https://wallet.95516.com/app/inApp/user/verifyLoginCode"
	urlVerifyDevice        = "https://wallet.95516.com/app/inApp/sys/verifyDevice"
	urlUserGet             = "https://wallet.95516.com/app/inApp/user/get"
	urlCardInfoList        = "https://wallet.95516.com/app/inApp/cardInfo/list"
	urlCardInfoDetail      = "https://wallet.95516.com/app/inApp/cardInfo/detail"
	urlCheckBalance        = "https://pay.95516.com/pay-web/restlet/other/accQuery/checkBalance"
	urlBigDataRecords      = "https://wallet.95516.com/acc/inApp/bigData/records"
	urlTransferHistory     = "https://wallet.95516.com/life/inApp/pub/transfer/history"
	urlTransferOutcardList = "https://wallet.95516.com/life/inApp/transfer/outcard/list"
	urlTransferQueryBin    = "https://wallet.95516.com/life/inApp/pub/transfer/queryBin"
	urlTransferFace        = "https://wallet.95516.com/life/inApp/pub/transfer/face"
	urlTransferPrepay      = "https://wallet.95516.com/life/inApp/pub/transfer/prepay"
	urlGetSecureKey        = "https://pay.95516.com/pay-web/restlet/other/payPwd/getSecureKey"
	urlVerifyPwd           = "https://pay.95516.com/pay-web/restlet/other/payPwd/verifyPwd"
	urlTransferResult      = "https://wallet.95516.com/life/inApp/pub/transfer/result"
)

const (
	loginStatusNone     = 0
	loginStatusWaitCode = 1
	loginStatusSuccess  = 2
)

const (
	loginCodeSuccess            = 0
	loginMsgSuccess             = "登录成功"
	loginCodeProxyError         = 1001
	loginMsgProxyError          = "请求代理服务器错误"
	loginCodeInitMobileAppError = 1002
	loginMsgInitMobileAppError  = "App初始化请求错误"
	loginCodeSysInit1Error      = 1003
	loginMsgSysInit1Error       = "SysInit-1请求错误"
	loginCodeSysInit2Error      = 1004
	loginMsgSysInit2Error       = "SysInit-2请求错误"
	loginCodeInfoCollectError   = 1005
	loginMsgInfoCollectError    = "设备信息请求错误"
	loginCodePadding            = 1006
	loginMsgPadding             = "正在登录中"
	loginCodeWaitCode           = 1007
	loginMsgWaitCode            = "正在等待验证码登录"
	loginCodeLoginError         = 1008
	loginMsgLoginError          = "登录错误"
	loginCodeNeedCode           = 1009
	loginMsgNeedCode            = "需要验证码登录"
	loginCodeVerifyDeviceError  = 1010
	loginMsgVerifyDeviceError   = "验证设备错误"
	loginCodeNeedRelogin        = 1011
	loginMsgNeedRelogin         = "需要重新登录"
	loginCodeUserGetError       = 1012
	loginMsgUserGetError        = "获取用户数据失败"

	logoutCodeSuccess = 0
	logoutMsgSuccess  = "退出成功"

	resetPasswordCodeSuccess = 0
	resetPasswordMsgSuccess  = "密码修改成功"
	resetPasswordCodeError   = 1001
	resetPasswordMsgError    = "密码修改失败"

	sendCodeCodeSuccess = 0
	sendCodeMsgSuccess  = "发送成功"
	sendCodeCodeNotNeed = 1001
	sendCodeMsgNotNeed  = "不需要验证码"
	sendCodeCodeError   = 1002
	sendCodeMsgError    = "发送验证码失败"

	verifyCodeCodeSuccess = 0
	verifyCodeMsgSuccess  = "验证成功"
	verifyCodeCodeNotNeed = 1001
	verifyCodeMsgNotNeed  = "发送验证码失败"
	verifyCodeCodeError   = 1002
	verifyCodeMsgError    = "校验验证码失败"
)
