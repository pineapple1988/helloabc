package cbc

import (
	"fmt"
	"pay/data/redis"
	"pay/pay"
	"pay/utils"

	"pay/utils/config"
	"pay/utils/logger"
	"testing"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	//1-3 中国	15394253785	中国银行	徐小敏	6216696200008201064	浙江	杭州	城北支行营业部	330822197503070618	aa369369	528528
	// 1-3 中国	15394253785	中国银行	徐小敏	6216696200008201064	浙江	杭州	城北支行营业部	330822197503070618	aa369369	528528
	acc, err := NewAccount("15251812984", "li950703", "950703", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	//acc.readTif()
	//代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[CBC][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			//return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}
		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	acc.Login(100)

	//读文件 拿到短信验证码
	smsCodeDatas := &smsCodeDatas{}
	if utils.Exist("./SmsCode.json") {
		utils.LoadJsonFromFile("./SmsCode.json", smsCodeDatas)
	} else {
		fmt.Println("./SmsCode.json 文件不存在, 请检查!!!")
	}
	acc.VerifyCode(smsCodeDatas.TransferSmsCode)
	//acc.readTif()

	acc.AesKey = []byte(utils.NewRandString(16, false))
	acc.loginIn()
	acc.getPsnLoginForPassword()
	acc.getToken()
	acc.psnxGetRandomLoginPre()
	 acc.getImageCode()
	 acc.getPsnUCSendSMS(acc.VerifyCode)
	 acc.getPsnUCloginOrRegForMsg()

	acc.getPsnUCSendSMS("1111")
	acc.getPsnUCloginOrRegForMsg()

	arr := acc.getWatcher()

	rsakey, _ := acc.getRsaKey()
	fmt.Println(rsakey)

	fmt.Println(string(arr))
	r := acc.Login(20000)
	if r == nil {
		t.Fatal("尚未实现登录接口.")
	}

	if r.Code != 0 {
		t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	}
}

func TestLogin1(t *testing.T) {
	//var cfg = &config.RedisConfig{
	//	DBHost: "127.0.0.1:6379",
	//	DBPass: "",
	//}

	logger.SetDebug()

	//if err := redis.InitRedis(cfg); err != nil {
	//	fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	//}

	//acc, err := NewAccount("13528520510", "qq121233", "891850", "ios")
	//if err != nil {
	//	t.Fatalf("创建帐号错误: %+v.", err)
	//}

	//acc.loginIn()
	//acc.getToken()
	// acc.getRandomLoginPre()
	// acc.getPsnLoginForPassword()
	// acc.getPsnCommonQuerySystemDateTime()
	// acc.getPsnCommonQueryAllChinaBankAccount()
	// acc.getPSNCreatConversation()
	// acc.getPsnAccountQueryTransferDetail()
	// acc.getPsnTransPayeeListqueryForDim()
	//转账第一步
	//PsnAccountQueryAccountDetail

}

func TestVerifyCode(t *testing.T) {
	//acc1.getPsnUCSendSMS("6534")
	//acc1.getPsnUCloginOrRegForMsg()

}

func TestTiff(t *testing.T) {
	// var data []byte
	// var err error
	// data, _ = ioutil.ReadFile("/Users/fish/Desktop/cbcimage.normal.exp0.tif")
	// // if err != nil {
	// // 	fmt.Println("错误: %+v", err)
	// // }
	// m, _, _ := tiff.DecodeAll(bytes.NewReader(data))

	// for i := 0; i < len(m); i++ {
	// 	for j := 0; j < len(m[i]); j++ {

	// 	}
	// }

}

// func TestLogin(t *testing.T) {

// 	cdata := map[string]interface{}{
// 		"deviceModel":              "iPhone10,6",
// 		"isJailBreak":              true,
// 		"batteryStatus":            3,
// 		"country":                  "KH",
// 		"cpuCoreNum":               6,
// 		"batteryLevel":             -1,
// 		"wifiMac":                  nil,
// 		"cellIPAddress":            "10.7.48.10",
// 		"systemUpTime":             272560,
// 		"timeZone":                 "Asia/Phnom_Penh",
// 		"appVersion":               "6.3.1(3.0.1)",
// 		"totalMemory":              2816,
// 		"carrierOperator":          "seatel",
// 		"freeDiskSpace":            42.129005432128906,
// 		"wiFiIPAddress":            nil,
// 		"diskSpace":                59.5460090637207,
// 		"carrierMobileNetworkCode": "11",
// 		"appId":                    "Production_env_zh",
// 		"cpuFrequency":             2,
// 		"carrierAllowVoip":         true,
// 		"screenH":                  812,
// 		"osVersion":                "12.4",
// 		"internetType":             "4G",
// 		"wifiName":                 nil,
// 		"carrierIsoCountryCode":    "kh",
// 		"screenBrightness":         0.2991935908794403,
// 		"deviceType":               "iPhone",
// 		"idfa":                     "EB707E26-9549-4118-9AAB-053E892E4D31",
// 	}

// 	arr, _ := json.Marshal(cdata)
// 	fmt.Println(string(arr))

// }

func TestIm(t *testing.T) {

}