package cbc

//func (acc *Account) readTif() {
//	data, err := ioutil.ReadFile("/Users/fish/Desktop/cbcimage.normal.exp0.tif")
//	if err != nil {
//		fmt.Printf("错误: %+v", err)
//	}
//	m, _, _ := tiff.DecodeAll(bytes.NewReader(data))
//
//	mlen := len(m)
//	fmt.Printf("%d", mlen)
//	fmt.Println("开始。")
//	for i := 0; i < len(m); i++ {
//		for j := 0; j < len(m[i]); j++ {
//			bounds := m[i][j].Bounds()
//			dx := bounds.Dx()
//			dy := bounds.Dy()
//			// newRgba := image.NewRGBA(bounds)
//
//			file1, _ := os.Create("/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/imgCode.png")
//			err = tiff.Encode(file1, m[i][j], nil)
//
//			fmt.Println("写入文件成功。")
//			// // gosseract.NewClient()
//			///usr/local/Cellar/tesseract/4.1.0/share/tessdata
//
//			client := gosseract.NewClient()
//			defer client.Close()
//			client.SetImage("/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/imgCode.png")
//			client.Languages = []string{"snum"}
//			client.SetWhitelist("0123456789")
//			client.SetPageSegMode(10)
//			text, _ := client.Text()
//			fmt.Printf("%s", text)
//			fmt.Printf("9 0 0 %d %d %d\n", dx, dy, i)
//		}
//	}
//	fmt.Println("完成。")
//}
//
//func (acc *Account) getImageCode() error {
//	req, err := http.NewRequest("GET", urlImageCode, nil)
//	if err != nil {
//		logger.Errorf("[CBC]getImageCode创建http请求错误: %+v.", err)
//		return err
//	}
//	req.Header.Add("Accept-Encoding", "br, gzip, deflate")
//	req.Header.Add("Accept", "*/*")
//	req.Header.Add("Accept-Language", "zh-cn")
//	req.Header.Add(headers.AcceptLanguage, "zh-cn")
//	req.Header.Set("User-Agent", "BOCMBCI/3.0.1 CFNetwork/978.0.7 Darwin/18.7.0")
//
//	for i := 0; i < 100; i++ {
//		body, err := utils.DoHTTP(acc.http, req)
//		if err != nil {
//			logger.Errorf("[CCB]getImageCode创建http请求错误: %+v.", err)
//			return err
//		}
//		bbb := bytes.NewBuffer([]byte(body))
//
//		img, _ := gif.Decode(bbb)
//		newrbga := clearImage(img)
//
//		// split(newrbga, i)
//
//		// file1, err := os.Create("/Users/fish/Desktop/image1/code" + strconv.Itoa(i) + ".jpg")
//		file1, err := os.Create("/Users/fish/Desktop/image1/code0.jpg")
//		err = jpeg.Encode(file1, newrbga, &jpeg.Options{100})
//
//		fmt.Println("写入文件成功。")
//		// // gosseract.NewClient()
//		///usr/local/Cellar/tesseract/4.1.0/share/tessdata
//
//		client := gosseract.NewClient()
//		defer client.Close()
//		client.SetImage("/Users/fish/Desktop/image1/code0.jpg")
//		client.Languages = []string{"snum"}
//		client.SetWhitelist("0123456789")
//		client.SetPageSegMode(7)
//
//		text, _ := client.Text()
//		text = strings.Trim(text, "")
//		text = strings.Trim(text, "\r")
//		text = strings.Trim(text, "\n")
//		if len(text) == 4 {
//			// acc.VerifyCode = text
//			break
//		}
//		fmt.Println(text)
//
//		// fmt.Println(text)
//	}
//
//	// // fmt.Printf("%x", []byte(body))
//
//	// ioutil.WriteFile("/Users/fish/Desktop/image/code"+strconv.Itoa(i)+".gif", []byte(body), 0666)
//
//	fmt.Println("写入文件成功。")
//
//	return nil
//}
//
//func (acc *Account) postVerifyCode() {
//
//}
