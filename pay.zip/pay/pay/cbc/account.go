package cbc

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// Account 中国银行帐号
type Account struct {
	Account         string          `json:"account"`
	Password        string          `json:"password"`
	PayPassword     string          `json:"payPassword"`
	Platform        string          `json:"platform"`
	CardNo          string          `json:"cardNo"`
	MobileOperators string          `json:"mobileOperators"`
	Idfa            string          `json:"idfa"`
	Idfv            string          `json:"idfv"`
	ClientID        string          `json:"clientID"`
	TokenID         string          `json:"tokenID"`
	UserID          int             `json:"UserID"`
	HardwareInfo    HardwareInfo    `json:"hardwareInfo"`
	Proxy           utils.ProxyInfo `json:"proxy"`
	http            *http.Client
	jar             *cookiejar.Jar
	AesKey          []byte
	ConversationID  string
	Rs              string
	RandKey         []byte
	PassSM4Key      []byte
	PassSM4IV       []byte
	DeviceSM4Key    []byte
	DeviceSM4IV     []byte
	//查询转账需要用到的
	userID    int
	accountID int

	loginStatus  int32
	loginPadding int32
	Token        string

	//转账
	transferPadding int32  //转帐等待
	targetAccount   string //对方银行号码
	targetName      string //对方名称
	bankCode        string //对方银行编码
	bankName        string //对方银行名称
	amount          string //转账金额
	comment         string //转账留言
	payeeBankNum    string //银行数字
	transactionID   int64  //交易订单号
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	WIFIName             string `json:"wifiName"`             // wifi名字
	WIFIMac              string `json:"wifiMac"`              // wifiMac地址
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // 设备的名字
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace string `json:"availableSystemSpace"` // 可用穷疯
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
	OSVersion            string `json:"osVersion"`            // 系统版本
	ScreenH              int    `json:"screenH"`              //屏幕高度
	ScreenW              int    `json:"screenW"`              //屏幕宽度
	ScreenPixel          string `json:"screenPixel"`
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case platformIOS, platformAndroid:
	default:
		{
			logger.Errorf("[CBC]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)
			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(cbcAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(cbcAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			//运营商
			if acc.MobileOperators == "" {
				acc.MobileOperators = utils.NewCarrierName()
			}
			return acc, nil
		}

		logger.Errorf("[CBC]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	acc.newHardwareInfo(platform)
	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CBC]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) newHardwareInfo(platform string) {
	acc.Idfa, _ = utils.NewUUID(true)
	acc.Idfv, _ = utils.NewUUID(true)
	acc.ClientID, _ = utils.NewUUID(true)

	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.Carrier = utils.NewCarrierName()
	h.CellularIP = utils.NewLocalIPAddress()
	h.OSVersion = utils.GetIPhoneOSVersion()

	h.ScreenPixel = fmt.Sprintf("%d.000000*%d.000000", h.ScreenW*3, h.ScreenH*3)

	if platform == common.PlatformNameIOS {
		h.SystemVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()
		h.AvailableSystemSpace = fmt.Sprintf("%d", 21249343488+utils.RandInt(1000000, 9999999))
		h.TotalSystemSpace = "31989469184"
		h.TotalMemory = "2099249152"
		screenSize := acc.HardwareInfo.ScreenSize
		screenXY := strings.Split(screenSize, "*")

		h.ScreenW, _ = strconv.Atoi(screenXY[0])
		h.ScreenH, _ = strconv.Atoi(screenXY[1])

	} else if platform == common.PlatformNameAndroid {

	}
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(cbcAccountKey, field)
	if err != nil {
		logger.Errorf("[CBC]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[CBC]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[CBC]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(cbcAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[CBC]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	// ts := time.Now().Unix()
	if id == timerUpdate {
		// acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCBC, code, reason)
}

func (acc *Account) selectCard() error {
	for i := 0; i < 3; i++ {
		res, err := acc.getPsnCommonQueryAllChinaBankAccount()
		if err != nil {
			continue
		}

		if res.ISException {
			return errors.New(res.Message)
		}

		if len(res.Result) <= 0 {
			return pay.ErrNoHaveCardList
		}

		// 未设置卡号
		if acc.CardNo == "" {
			for _, v := range res.Result {
				if v.AccountCatalog == "1" {
					acc.accountID = v.AccountID

					logger.Infof("[CBC][%+v]未指定卡号, 默认选择卡号: %s, 卡序号: %+v.",
						acc.Account, v.AccountNumber, v.AccountID)
					return nil
				}
			}

			logger.Errorf("[CBC][%+v]未指定卡号但无法找到可用卡号.", acc.Account)
			return pay.ErrNoHaveCardList
		}

		// 设置卡号选择
		for _, v := range res.Result {
			if v.AccountNumber == acc.CardNo {
				acc.accountID = v.AccountID

				logger.Infof("[CBC][%+v]选择指定银行卡号, 指定卡号: %s, 选择卡号: %s, 卡序号: %+v.",
					acc.Account, acc.CardNo, v.AccountNumber, v.AccountID)
				return nil
			}
		}
	}

	return errors.New("获取帐号银行卡列表失败")
}

func (acc *Account) doRelogin() error {
	logger.Infof("[CBC][%+v]session过期，重新登陆, 平台: %+v.", acc.Account, acc.Platform)
	acc.jar, _ = cookiejar.New(nil)
	if config.IsUseProxy() {
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	//PsnxGetRandomLoginPre
	loginpre, err := acc.psnxGetRandomLoginPre()

	if err != nil {
		return err
	}

	if loginpre.ISException {
		logger.Warnf("[CBC][%+v]psnxGetRandomLoginPre异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, loginpre.Type, loginpre.Code, loginpre.Message)
		return errors.New(loginpre.Message)
	}

	acc.ConversationID = loginpre.Result.ConversationID
	acc.Rs = loginpre.Result.Rs
	err = acc.setRandKey(acc.Rs)

	PsnLoginForPassword, err := acc.psnLoginForPassword()

	if err != nil {
		return err
	}
	if PsnLoginForPassword.ISException {
		logger.Warnf("[CBC][%+v]psnLoginForPassword异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, PsnLoginForPassword.Type, PsnLoginForPassword.Code, PsnLoginForPassword.Message)
		return errors.New(PsnLoginForPassword.Message)
	}

	if PsnLoginForPassword.Result.CurrentDeviceFlag == "0" {
		logger.Infof("[CBC][%+v]重登录需要重新绑定帐号.", acc.Account)
		return pay.ErrNeedBindDevice
	}

	acc.UserID = PsnLoginForPassword.Result.UserID

	PsnCommonQuerySystemDateTime, err := acc.getPsnCommonQuerySystemDateTime()
	if err != nil {
		logger.Errorf("[CBC][%+v]PsnCommonQuerySystemDateTime错误: %+v.", acc.Account, err)
		return err
	}

	if PsnCommonQuerySystemDateTime.ISException {
		logger.Errorf("[CBC][%+v]PsnCommonQuerySystemDateTime失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, PsnCommonQuerySystemDateTime.Type, PsnCommonQuerySystemDateTime.Code, PsnCommonQuerySystemDateTime.Message)
		return errors.New(PsnCommonQuerySystemDateTime.Message)
	}

	creatConversation, err := acc.pSNCreatConversation()
	if err != nil {
		logger.Errorf("[CBC][%+v]pSNCreatConversation错误: %+v.", acc.Account, err)
		return err
	}

	if creatConversation.ISException {
		logger.Errorf("[CBC][%+v]pSNCreatConversation失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, creatConversation.Type, creatConversation.Code, creatConversation.Message)
		return errors.New(creatConversation.Message)
	}

	acc.ConversationID = creatConversation.Result
	creatConversation1, err := acc.pSNCreatConversation()
	if err != nil {
		logger.Errorf("[CBC][%+v]pSNCreatConversation错误: %+v.", acc.Account, err)
		return err
	}

	if creatConversation1.ISException {
		logger.Errorf("[CBC][%+v]pSNCreatConversation失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, creatConversation1.Type, creatConversation1.Code, creatConversation1.Message)
		return errors.New(creatConversation1.Message)
	}

	acc.ConversationID = creatConversation1.Result

	// PSNGetTokenId
	getTokenID, err := acc.pSNGetTokenID()
	if err != nil {
		return err
	}
	if getTokenID.ISException {
		logger.Warnf("[CBC][%+v]pSNGetTokenID异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, getTokenID.Type, getTokenID.Code, getTokenID.Message)
		return errors.New(getTokenID.Message)
	}

	acc.Token = getTokenID.Result

	creatConversation2, err := acc.pSNCreatConversation()
	if err != nil {
		logger.Errorf("[CBC][%+v]pSNCreatConversation错误: %+v.", acc.Account, err)
		return err
	}

	if creatConversation2.ISException {
		logger.Errorf("[CBC][%+v]pSNCreatConversation失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, creatConversation2.Type, creatConversation2.Code, creatConversation2.Message)
		return errors.New(creatConversation2.Message)
	}

	acc.ConversationID = creatConversation2.Result

	return nil
}

func (acc *Account) onLoginSuccess() {
	acc.loginStatus = pay.LoginStatusSuccess
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCBC)
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCBC)
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)
	acc.jar, _ = cookiejar.New(nil)

	switch acc.loginStatus {
	case pay.LoginStatusSuccess:
		logger.Infof("[CBC][%+v]已在登录状态.", acc.Account)
		return pay.Success((nil))
	}

	if acc.loginPadding != 0 {
		logger.Infof("[CBC][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}
	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[CBC][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}
		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}
		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	// getToken
	token, err := acc.getToken()
	if err != nil {
		logger.Errorf("[CBC][%+v]获取Token错误: %+v", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	acc.TokenID = token.TokenID

	// PsnxGetRandomLoginPre
	loginpre, err := acc.psnxGetRandomLoginPre()

	if err != nil {
		logger.Errorf("[CBC][%+v]loginpre异常: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if loginpre.ISException {
		logger.Warnf("[CBC][%+v]psnxGetRandomLoginPre异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, loginpre.Type, loginpre.Code, loginpre.Message)
		return pay.Error(pay.ErrCodeLoginError, loginpre.Message, nil)
	}

	acc.ConversationID = loginpre.Result.ConversationID
	acc.Rs = loginpre.Result.Rs

	err = acc.setRandKey(acc.Rs)
	if err != nil {
		return pay.Error(pay.ErrCodeLoginError, "SM4KEY生成错误", nil)
	}

	if loginpre.ISException {
		logger.Warnf("[CBC][%+v]psnxGetRandomLoginPre异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, loginpre.Type, loginpre.Code, loginpre.Message)
		return pay.Error(pay.ErrCodeLoginError, loginpre.Message, nil)
	}

	acc.ConversationID = loginpre.Result.ConversationID
	acc.Rs = loginpre.Result.Rs

	err = acc.setRandKey(acc.Rs)
	if err != nil {
		logger.Errorf("[CBC][%+v]生成随机KEY错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, "SM4KEY生成错误", nil)
	}

	// psnLoginForPassword
	loginForPassWord, err := acc.psnLoginForPassword()
	if err != nil {
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}
	if loginForPassWord.ISException {
		logger.Warnf("[CBC][%+v]psnLoginForPassword异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, loginForPassWord.Type, loginForPassWord.Code, loginForPassWord.Message)
		return pay.Error(pay.ErrCodeLoginError, loginForPassWord.Message, nil)
	}

	acc.UserID = loginForPassWord.Result.UserID
	// 当前设备未绑定需要绑定设备
	if loginForPassWord.Result.CurrentDeviceFlag == "0" {
		logger.Infof("[CBC][%+v]需要进行设备ID绑定.", acc.Account)

		// psnQueryUserLocateAuth
		locateAuth, err := acc.psnQueryUserLocateAuth()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if locateAuth.ISException {
			logger.Warnf("[CBC][%+v]psnQueryUserLocateAuth异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, locateAuth.Type, locateAuth.Code, locateAuth.Message)
			return pay.Error(pay.ErrCodeLoginError, locateAuth.Message, nil)
		}

		isSign := locateAuth.Result.IsSign

		if isSign {
			fmt.Println("可能是第一次登录需要验证什么鬼")
		}

		// 重新请求会话ID
		// psnxGetRandom
		getRandom, err := acc.psnxGetRandom()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if getRandom.ISException {
			logger.Warnf("[CBC][%+v]psnxGetRandom异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, getRandom.Type, getRandom.Code, getRandom.Message)
			return pay.Error(pay.ErrCodeLoginError, getRandom.Message, nil)
		}

		acc.ConversationID = getRandom.Result.ConversationID
		acc.Rs = loginpre.Result.Rs

		err = acc.setRandKey(acc.Rs)
		if err != nil {
			logger.Errorf("[CBC][%+v]生成随机KEY错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, "SM4KEY生成错误", nil)
		}

		// psnGetSecurityFactor
		securityFactor, err := acc.psnGetSecurityFactor("PB107")
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if securityFactor.ISException {
			logger.Warnf("[CBC][%+v]psnQueryUserLocateAuth异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, securityFactor.Type, securityFactor.Code, securityFactor.Message)
			return pay.Error(pay.ErrCodeLoginError, securityFactor.Message, nil)
		}

		if securityFactor.Result.CombinList[0].ID == 32 {
			// ???
		}

		// pSNGetRandom
		psnRandom, err := acc.pSNGetRandom()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if psnRandom.ISException {
			logger.Warnf("[CBC][%+v]pSNGetRandom异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, psnRandom.Type, psnRandom.Code, psnRandom.Message)
			return pay.Error(pay.ErrCodeLoginError, psnRandom.Message, nil)
		}

		acc.Rs = psnRandom.Result
		acc.setRandKey(psnRandom.Result)

		// PsnSvrRegisterDevicePre
		registerDevicePre, err := acc.psnSvrRegisterDevicePre("32")
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if registerDevicePre.ISException {
			logger.Warnf("[CBC][%+v]registerDevicePre异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, registerDevicePre.Type, registerDevicePre.Code, registerDevicePre.Message)
			return pay.Error(pay.ErrCodeLoginError, registerDevicePre.Message, nil)
		}

		// PsnSendSMSCodeToMobile
		smsCode, err := acc.psnSendSMSCodeToMobile()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if smsCode.ISException {
			logger.Warnf("[CBC][%+v]psnSendSMSCodeToMobile异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, smsCode.Type, smsCode.Code, smsCode.Message)
			return pay.Error(pay.ErrCodeLoginError, smsCode.Message, nil)
		}

		// PSNGetTokenId
		getTokenID, err := acc.pSNGetTokenID()
		if err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}
		if getTokenID.ISException {
			logger.Warnf("[CBC][%+v]pSNGetTokenID异常 Type: %+v, Code: %+v, Msg: %+v.", acc.Account, getTokenID.Type, getTokenID.Code, getTokenID.Message)
			return pay.Error(pay.ErrCodeLoginError, getTokenID.Message, nil)
		}

		acc.Token = getTokenID.Result
		acc.save()

		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypeCBC)

		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	// 二次登陆
	// PsnQueryBankBranchInfo
	PsnCommonQuerySystemDateTime, err := acc.getPsnCommonQuerySystemDateTime()
	if err != nil {
		logger.Errorf("[CBC][%+v]PsnCommonQuerySystemDateTime错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
	}

	if PsnCommonQuerySystemDateTime.ISException {
		logger.Errorf("[CBC][%+v]PsnCommonQuerySystemDateTime失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, PsnCommonQuerySystemDateTime.Type, PsnCommonQuerySystemDateTime.Code, PsnCommonQuerySystemDateTime.Message)
		return pay.Error(pay.ErrCodeSMSCodeError, PsnCommonQuerySystemDateTime.Message, nil)
	}

	if err := acc.selectCard(); err != nil {
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	acc.onLoginSuccess()
	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypeCBC)

	if acc.Proxy.URI != "" {
		pay.ReleaseProxy(acc.Proxy.URI)
		acc.setProxy("", "", "")
	}

	logger.Infof("[CBC][%+v]退出成功.", acc.Account)

	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[CBC][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[CBC][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)
	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)
	if acc.loginStatus == pay.LoginStatusWaitCode {
		// psnSvrRegisterDeviceSubmit
		registerDeviceSubmit, err := acc.psnSvrRegisterDeviceSubmit(code)
		if err != nil {
			logger.Errorf("[CBC][%+v]校验验证码操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if registerDeviceSubmit.ISException {
			logger.Warnf("[CBC][%+v]]校验登登录验证码失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, registerDeviceSubmit.Type, registerDeviceSubmit.Code, registerDeviceSubmit.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, registerDeviceSubmit.Message, nil)
		}

		// PsnCommonQuerySystemDateTime
		querySystemDateTime, err := acc.getPsnCommonQuerySystemDateTime()

		if err != nil {
			logger.Errorf("[CBC][%+v]获取银行系统时间错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if querySystemDateTime.ISException {
			logger.Errorf("[CBC][%+v]获取银行系统时间失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, querySystemDateTime.Type, querySystemDateTime.Code, querySystemDateTime.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, querySystemDateTime.Message, nil)
		}

		// PsnQueryBankBranchInfo
		queryBankBranchInfo, err := acc.psnQueryBankBranchInfo()
		if err != nil {
			logger.Errorf("[CBC][%+v]psnQueryBankBranchInfo错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if queryBankBranchInfo.ISException {
			logger.Errorf("[CBC][%+v]psnQueryBankBranchInfo失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, queryBankBranchInfo.Type, queryBankBranchInfo.Code, queryBankBranchInfo.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, queryBankBranchInfo.Message, nil)
		}

		// PSNCreatConversation
		creatConversation, err := acc.pSNCreatConversation()
		if err != nil {
			logger.Errorf("[CBC][%+v]pSNCreatConversation错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if creatConversation.ISException {
			logger.Errorf("[CBC][%+v]pSNCreatConversation失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, creatConversation.Type, creatConversation.Code, creatConversation.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, creatConversation.Message, nil)
		}

		acc.ConversationID = creatConversation.Result

		// psnAllAccountsQuery
		allAccountsQuery, err := acc.psnAllAccountsQuery()
		if err != nil {
			logger.Errorf("[CBC][%+v]pSNCreatConversation错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if allAccountsQuery.ISException {
			logger.Errorf("[CBC][%+v]psnAllAccountsQuery失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, allAccountsQuery.Type, allAccountsQuery.Code, allAccountsQuery.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, allAccountsQuery.Message, nil)
		}

		// PSNCreatConversationLoginPre
		creatConversationLoginPre, err := acc.pSNCreatConversationLoginPre()
		if err != nil {
			logger.Errorf("[CBC][%+v]pSNCreatConversationLoginPre错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if creatConversationLoginPre.ISException {
			logger.Errorf("[CBC][%+v]pSNCreatConversationLoginPre失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, creatConversationLoginPre.Type, creatConversationLoginPre.Code, creatConversationLoginPre.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, creatConversationLoginPre.Message, nil)
		}

		acc.ConversationID = creatConversation.Result

		mobileIsSignedAgent, err := acc.psnMobileIsSignedAgent()
		if err != nil {
			logger.Errorf("[CBC][%+v]psnMobileIsSignedAgent错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if mobileIsSignedAgent.ISException {
			logger.Errorf("[CBC][%+v]psnMobileIsSignedAgent失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, mobileIsSignedAgent.Type, mobileIsSignedAgent.Code, mobileIsSignedAgent.Message)
			return pay.Error(pay.ErrCodeSMSCodeError, mobileIsSignedAgent.Message, nil)
		}

		if err := acc.selectCard(); err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CBC][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.getPsnAccountQueryAccountDetail()
	if err != nil {
		logger.Errorf("[CBC][%+v]查询余额错误: %+v.", acc.Account, err)
		// 第一次时尝试重新登录
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CBC][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.ISException {
		logger.Errorf("[CBC][%+v]查询余额返回失败, 信息: %+v.", acc.Account, balance.Message)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.Message, nil)
	}

	if len(balance.Result.AccountDetaiList) <= 0 {
		logger.Errorf("CBC][%+v]查询余额返回列表为空.", acc.Account)
		return pay.Error(pay.ErrCodeGetBalanceError, "余额数据不存在", nil)
	}

	amount := fmt.Sprintf("%.2f", balance.Result.AccountDetaiList[0].AvailableBalance)
	res := model.AccountBalanceRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data.Amount = amount
	res.Data.AmountAvailable = amount

	logger.Infof("[CBC][%+v]查询余额成功, 余额: %+v, 可用余额: %+v.", acc.Account, amount, amount)

	return pay.Success(&res)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CBC][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// datetimeConvert 把yyyyMMddhhmmss转换成yyyy-MM-dd hh:mm:ss
func datetimeConvert(dt string) string {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return dt
	}

	return time.Unix(tmp.Unix(), 0).Format("2006-01-02 15:04:05")
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	// 首先更新ConversationId
	logger.Infof("[CBC][%+v]请求账单，更新ConversationId, 平台: %+v.", acc.Account, acc.Platform)

	PSNCreatConversation, err := acc.pSNCreatConversation()

	if err != nil {
		logger.Errorf("[CBC][%+v]请求账单，更新ConversationId错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CBC][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
			}

			return acc.doBillList(req, false)
		}
		return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
	}

	if PSNCreatConversation.ISException {
		logger.Warnf("[CBC][%+v]]请求账单，更新ConversationId失败, Type: %+v, Code: %+v, Msg: %+v.", acc.Account, PSNCreatConversation.Type, PSNCreatConversation.Code, PSNCreatConversation.Message)
		return pay.Error(pay.ErrCodeGetBillListError, PSNCreatConversation.Message, nil)
	}

	acc.ConversationID = PSNCreatConversation.Result
	startDate, endDate := pay.GetBillListDate(req)

	logger.Infof("[CBC][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	currentIndex := 1
	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}

	for {
		PsnFinRecQuery, err := acc.getPsnFinRecQuery(startDate, endDate, strconv.Itoa(currentIndex))
		if err != nil {
			logger.Errorf("[CBC][%+v]查询帐单错误: %+v.", acc.Account, err)
		}

		if PsnFinRecQuery.IsException {
			if len(res.Data) > 0 {
				break
			}

			logger.Errorf("[CBC][%+v]查询帐单失败, 信息: %+v.", acc.Account, PsnFinRecQuery.Message)
			return pay.Error(pay.ErrCodeGetBillListError, PsnFinRecQuery.Message, nil)
		}

		for _, item := range PsnFinRecQuery.Result.List {
			amount, err := strconv.ParseFloat(item.TransAmount, 64)
			if err != nil {
				amount = 0.0
				logger.Warnf("[CBC][%+v]转换转帐金额为浮点数错误, 数值: %+v, 错误: %+v.", acc.Account, item.TransAmount, err)
			}

			info := model.AccountBillListInfo{
				TradeNo:   item.RecordID,
				TradeTime: datetimeConvert(item.Date + item.Time),
				Amount:    fmt.Sprintf("%.2f", amount),
				// AmountRemain: item.InterTransfer.BalanceAmt,
				// Comment:      item.InterTransfer.Remark,
			}

			if item.DebitCreditFlag == "D" {
				// 支出
				info.TradeType = "0"
				info.TargetAccount = item.AccountNum
				info.TargetName = item.OtherActName
				// info.TargetBankName = item.InterTransfer.PayBankName
			} else if item.DebitCreditFlag == "C" {
				// 收入
				info.TradeType = "1"
				info.TargetAccount = item.AccountNum
				info.TargetName = item.OtherActName
				// info.TargetBankName = item.InterTransfer.PayBankName
			} else {
				logger.Errorf("[CBC][%+v]查询帐单出现未知的记帐方式: %+v.", acc.Account, item.OtherActName)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.DebitCreditFlag == "C" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.DebitCreditFlag == "D" {
					res.Data = append(res.Data, info)
				}
			}
		}

		retItems, err := strconv.Atoi(PsnFinRecQuery.Result.RetItems)
		// 总共多少个
		totolItems, err := strconv.Atoi(PsnFinRecQuery.Result.TotalItems)

		currentIndex = currentIndex + retItems

		if currentIndex <= totolItems {
			currentIndex += retItems
		} else {
			break
		}
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CBC][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}
	return acc.doBillList(req, true)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {

	if acc.transferPadding != 0 {
		return pay.Error(pay.ErrCodeTransferError, "转帐正在操作中, 请稍候再试", nil)
	}

	acc.targetAccount = req.TargetAccount
	acc.targetName = req.TargetName
	acc.amount = req.Amount
	acc.comment = req.Comment

	if req.SMSCode == "" {
		// 查询对方的银行编码
		PsnQueryBankInfobyCardBin, err := acc.getPsnQueryBankInfobyCardBin(req.TargetAccount)
		if err != nil {
			logger.Errorf("[CBC][%+v]查询对方的银行编码错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[CBC][%+v]查询余额重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if PsnQueryBankInfobyCardBin.ISException {
			logger.Errorf("[CBC][%+v]查询对方的银行编码失败, 信息: %+v.", acc.Account, PsnQueryBankInfobyCardBin.Message)
			return pay.Error(pay.ErrCodeTransferError, PsnQueryBankInfobyCardBin.Message, nil)
		}

		acc.bankCode = PsnQueryBankInfobyCardBin.Result.CnapsCode
		acc.bankName = PsnQueryBankInfobyCardBin.Result.BankName

		if acc.bankName == "" || acc.bankCode == "" {
			if req.BankName != "" {
				res, err := api.NodeQueryBankInfo(req.BankName)
				if err != nil {
					acc.bankName = req.BankName
				} else {
					acc.bankName = res.BankName
					acc.bankCode = res.BankNo
				}
			}
		}

		if acc.bankName == "" || acc.bankCode == "" {
			logger.Warnf("[CBC][%+v]查询到斩不支持的银行, 卡号: %+v, 银行名字: %+v, 银行代码: %+v.",
				acc.Account, req.TargetAccount, acc.bankName, acc.bankCode)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		// 切换conversationId
		PSNCreatConversation, err := acc.pSNCreatConversation()
		if err != nil {
			logger.Errorf("[CBC][%+v]切换conversationId错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if PSNCreatConversation.ISException {
			logger.Errorf("[CBC][%+v]切换conversationId失败, 信息: %+v.", acc.Account, PSNCreatConversation.Message)
			return pay.Error(pay.ErrCodeTransferError, PSNCreatConversation.Message, nil)
		}

		acc.ConversationID = PSNCreatConversation.Result

		// 判断是否同行转账
		if acc.bankCode == "104100000004" {
			// 安全检查
			PsnGetSecurityFactor, err := acc.psnGetSecurityFactor("PB031")
			if err != nil {
				logger.Errorf("[CBC][%+v]PsnGetSecurityFactor错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnGetSecurityFactor.ISException {
				logger.Errorf("[CBC][%+v]PsnGetSecurityFactor失败, 信息: %+v.", acc.Account, PsnGetSecurityFactor.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnGetSecurityFactor.Message, nil)
			}

			// logger.Infof("[CBC][%+v]同行查询验证费用, 平台: %+v.", acc.Account, acc.Platform)
			PsnTransBocTransferVerify, err := acc.getPsnTransBocTransferVerify()
			if err != nil {
				logger.Errorf("[CBC][%+v]同行查询转账费用: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnTransBocTransferVerify.IsException {
				logger.Errorf("[CBC][%+v]同行查询转账费用, 信息: %+v.", acc.Account, PsnTransBocTransferVerify.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnTransBocTransferVerify.Message, nil)
			}

			acc.payeeBankNum = PsnTransBocTransferVerify.Result.PayeeBankNum

			// logger.Infof("[CBC][%+v]同行查询转账费用, 平台: %+v.", acc.Account, acc.Platform)
			PsnTransGetBocTransferCommissionCharge, err := acc.getPsnTransGetBocTransferCommissionCharge()
			if err != nil {
				logger.Errorf("[CBC][%+v]同行查询转账费用: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnTransGetBocTransferCommissionCharge.IsException {
				logger.Errorf("[CBC][%+v]同行查询转账费用, 信息: %+v.", acc.Account, PsnTransGetBocTransferCommissionCharge.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnTransGetBocTransferCommissionCharge.Message, nil)
			}

		} else {
			// 安全检查
			PsnGetSecurityFactor, err := acc.psnGetSecurityFactor("PB113")
			if err != nil {
				logger.Errorf("[CBC][%+v]PsnGetSecurityFactor错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnGetSecurityFactor.ISException {
				logger.Errorf("[CBC][%+v]PsnGetSecurityFactor失败, 信息: %+v.", acc.Account, PsnGetSecurityFactor.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnGetSecurityFactor.Message, nil)
			}

			// logger.Infof("[CBC][%+v]非查询验证费用, 平台: %+v.", acc.Account, acc.Platform)
			PsnEbpsRealTimePaymentConfirm, err := acc.getPsnEbpsRealTimePaymentConfirm()
			if err != nil {
				logger.Errorf("[CBC][%+v]实时转帐确认错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnEbpsRealTimePaymentConfirm.ISException {
				logger.Errorf("[CBC][%+v]实时转帐确认失败, 信息: %+v.", acc.Account, PsnEbpsRealTimePaymentConfirm.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnEbpsRealTimePaymentConfirm.Message, nil)
			}

			PsnTransGetNationalTransferCommissionCharge, err := acc.getPsnTransGetNationalTransferCommissionCharge()
			if err != nil {
				logger.Errorf("[CBC][%+v]非同行查询转账费用: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
			}

			if PsnTransGetNationalTransferCommissionCharge.ISException {
				logger.Errorf("[CBC][%+v]非同行查询转账费用, 信息: %+v.", acc.Account, PsnTransGetNationalTransferCommissionCharge.Message)
				return pay.Error(pay.ErrCodeTransferError, PsnTransGetNationalTransferCommissionCharge.Message, nil)
			}
		}

		PSNGetRandom, err := acc.pSNGetRandom()
		if err != nil {
			logger.Errorf("[CBC][%+v]获取随机key错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		acc.Rs = PSNGetRandom.Result
		acc.setRandKey(PSNGetRandom.Result)

		PsnSendSMSCodeToMobile, err := acc.getPsnSendSMSCodeToMobile()
		if err != nil {
			logger.Errorf("[CBC][%+v]发送交易短信验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if PsnSendSMSCodeToMobile.ISException {
			logger.Errorf("[CBC][%+v]确定交易短信验证码失败, 信息: %+v.", acc.Account, PsnSendSMSCodeToMobile.Message)
			return pay.Error(pay.ErrCodeTransferError, PsnSendSMSCodeToMobile.Message, nil)
		}

		PSNGetTokenID, err := acc.pSNGetTokenID()
		if err != nil {
			logger.Errorf("[CBC][%+v]获取TokenID错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if PSNGetTokenID.ISException {
			logger.Errorf("[CBC][%+v]获取TokenID失败, 信息: %+v.", acc.Account, PSNGetTokenID.Message)
			return pay.Error(pay.ErrCodeTransferError, PSNGetTokenID.Message, nil)
		}

		acc.Token = PSNGetTokenID.Result
		logger.Infof("[CBC][%+v]发送转帐验证码成功.", acc.Account)
		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	atomic.StoreInt32(&acc.transferPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.transferPadding, 0)
	}()

	transAmount := ""
	body := ""
	status := common.TransferStatusProcessing

	// 转账判断是否同行
	if acc.bankCode == "104100000004" {

		logger.Infof("[CBC][%+v]同行转账确认开始, 平台: %+v.", acc.Account, acc.Platform)
		var err error
		var transferSubmit *resPsnTransBocTransferSubmit
		transferSubmit, body, err = acc.psnTransBocTransferSubmit(req.SMSCode)
		if err != nil {
			logger.Errorf("[CBC][%+v]同行转账错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if transferSubmit.IsException {
			logger.Errorf("[CBC][%+v]同行转账失败, 信息: %+v.", acc.Account, transferSubmit.Message)
			return pay.Error(pay.ErrCodeTransferError, transferSubmit.Message, nil)
		}

		acc.transactionID = transferSubmit.Result.TransactionID
		transAmount = fmt.Sprintf("%.2f", transferSubmit.Result.Amount)
		status = common.TransferStatusSuccess
	} else {
		logger.Infof("[CBC][%+v]跨行转账确认开始, 平台: %+v.", acc.Account, acc.Platform)

		realtimeTransfer, err := acc.getPsnEbpsRealTimePaymentTransfer(req.SMSCode)
		if err != nil {
			logger.Errorf("[CBC][%+v]非同行转账错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if realtimeTransfer.ISException {
			logger.Errorf("[CBC][%+v]非同行转账失败, 信息: %+v.", acc.Account, realtimeTransfer.Message)
			return pay.Error(pay.ErrCodeTransferError, realtimeTransfer.Message, nil)
		}

		if realtimeTransfer.Result.TransactionID == 0 && realtimeTransfer.Result.TransMonStatus != "" {
			logger.Infof("[CBC][%+v]需要刷脸进行转帐, 状态: %+v.", acc.Account, realtimeTransfer.Result.TransMonStatus)
			return pay.Error(pay.ErrCodeTransferError, "需要刷脸才能进行转帐操作", nil)
		}

		acc.transactionID = realtimeTransfer.Result.TransactionID

		for i := 0; i < 4; i++ {
			time.Sleep(time.Second * 5)
			var transferRecord *resPsnSingleTransQueryTransferRecord
			transferRecord, body, err = acc.getPsnSingleTransQueryTransferRecord(strconv.FormatInt(acc.transactionID, 10))
			if err != nil {
				logger.Errorf("[CBC][%+v]非同行转账完成后错误: %+v.", acc.Account, err)
				continue
			}

			if transferRecord.IsException {
				logger.Errorf("[CBC][%+v]非同行转账失败, 信息: %+v.", acc.Account, transferRecord.Message)
				continue
			}

			transAmount = transferRecord.Result.Amount

			// 确认成功
			if transferRecord.Result.Status == "A" {
				status = common.TransferStatusSuccess
				logger.Infof("[CBC][%+v]转帐状态确认成功.", acc.Account)
				break
			}

			// 处理中
			if transferRecord.Result.Status == "L" {
				status = common.TransferStatusProcessing
				logger.Infof("[CBC][%+v]转帐状态处理中.", acc.Account)
				continue
			}

			// 确认失败
			if transferRecord.Result.Status == "B" {
				logger.Infof("[CBC][%+v]转帐状态确认失败, 消息: %+v.", acc.Account, transferRecord.Result.ReturnCode)
				return pay.Error(pay.ErrCodeTransferError, transferRecord.Result.ReturnCode, nil)
			}

			// 未处理的状态
			logger.Infof("[CBC][%+v]未知的转帐状态: %+v.", acc.Account, transferRecord.Result.Status)
		}
	}

	time.Sleep(time.Second * 2)

	tradeTime := ""
	for i := 0; i < 3; i++ {
		PsnQueryTransActivityStatus, err := acc.getPsnQueryTransActivityStatus(strconv.FormatInt(acc.transactionID, 10))
		if err != nil {
			logger.Errorf("[CBC][%+v]非同行转账完成后错误: %+v.", acc.Account, err)
			continue
		}

		if PsnQueryTransActivityStatus.ISException {
			logger.Errorf("[CBC][%+v]非同行转账失败, 信息: %+v.", acc.Account, PsnQueryTransActivityStatus.Message)
			continue
		}

		tradeTime = PsnQueryTransActivityStatus.Result.FirstSubmitDate
		break
	}

	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData
	res.Status = status

	if status == common.TransferStatusProcessing {
		res.Code = pay.ErrCodeTransferStatusUnknow
		res.Msg = pay.ErrMsgTransferStatusUnknow
	}

	res.Data.TradeNo = fmt.Sprintf("%d", acc.transactionID)
	res.Data.TradeTime = tradeTime
	res.Data.Amount = transAmount
	res.Data.AmountRemain = "未知"
	res.Data.TargetAccount = req.TargetAccount
	res.Data.TargetName = req.TargetName
	res.Data.Comment = req.Comment

	for i := 0; i < 3; i++ {
		balance, err := acc.getPsnAccountQueryAccountDetail()
		if err != nil {
			continue
		}

		if balance.ISException {
			continue
		}

		if len(balance.Result.AccountDetaiList) <= 0 {
			break
		}

		res.Data.AmountRemain = fmt.Sprintf("%.2f", balance.Result.AccountDetaiList[0].AvailableBalance)
		break
	}

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypeCBC,
		req.OrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		status)

	logger.LogTransfer("[CBC][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		req.TargetName,
		req.TargetAccount,
		res.Data.Amount,
		status,
		req.OrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CBC][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[CBC][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}
	return acc.doTransfer(req, true)
}

func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	result, _, err := acc.getPsnSingleTransQueryTransferRecord(req.TradeNo)
	if err != nil {
		logger.Errorf("[CBC][%+v]查询转帐状态错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CBC][%+v]查询转帐状态重新登录帐号错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
			}

			return acc.doTransferStatus(req, false)
		}

		return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
	}

	if result.IsException {
		logger.Errorf("[CBC][%+v]查询转帐状态失败, 信息: %+v.", acc.Account, result.Message)
		return pay.Error(pay.ErrCodeTransferStatusError, result.Message, nil)
	}

	status := common.TransferStatusNone
	if result.Result.Status == "A" {
		status = common.TransferStatusSuccess
	} else if result.Result.Status == "L" {
		status = common.TransferStatusProcessing
	} else if result.Result.Status == "B" {
		status = common.TransferStatusFail
	} else {
		logger.Errorf("[CBC][%+v]查询转帐状态未知状态: %+v.", acc.Account, result.Result.Status)
		return pay.Error(pay.ErrCodeTransferStatusError, fmt.Sprintf("未知的转帐状态: %+v", result.Result.Status), nil)
	}

	res := model.AccountTransferStatusRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Status = status

	if status != common.TransferStatusProcessing {
		api.NodeTransferStatus(req.TradeNo, status)
		logger.LogTransfer("[CBC][%+v]转帐流水号[%+v]状态更新为: %+v.", acc.Account, req.TradeNo, status)
	}

	return pay.Success(&res)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[CBC][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CBC][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
