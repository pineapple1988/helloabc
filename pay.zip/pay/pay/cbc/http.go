package cbc

import (
	"bytes"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"net"
	"pay/pay"
	"strconv"
	"time"

	"github.com/forgoer/openssl"

	"net/http"
	"pay/utils"
	"pay/utils/logger"
	"strings"

	jsoniter "github.com/json-iterator/go"
)

func (acc *Account) fillHeader(req *http.Request) {
	req.Header.Set("bfw-ctrl", "json")
	req.Header.Set("Accept-Language", "zh-cn")
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
	req.Header.Set("secfactor", "auk")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Encoding", "br, gzip, deflate")
	req.Header.Set("User-Agent", "BOCMBCI/3.0.1 CFNetwork/978.0.7 Darwin/18.7.0")
}

func (acc *Account) postHTTPData(req interface{}, res interface{}) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[CBC][%+v]postHTTPData序列化错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	str := "json=" + utils.URLEncode(string(arr))

	r, err := http.NewRequest("POST", urlRandomLoginPre, strings.NewReader(str))
	if err != nil {
		logger.Errorf("[CBC][%+v]postHTTPData创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	acc.fillHeader(r)

	body, err := utils.DoHTTP(acc.http, r)
	if err != nil {
		logger.Errorf("[CBC][%+v]postHTTPData http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	logger.Debugf("[CBC][%+v]http请求成功, data: %s, body: %s.", acc.Account, string(arr), body)

	if strings.Contains(body, "您的网银会话已经超时") || strings.Contains(body, "role.invalid_user") {
		return "", pay.ErrSessionTimeout
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), res); err != nil {
			logger.Errorf("[CBC][%+v]postHTTPData反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (acc *Account) getHeader() map[string]interface{} {
	return map[string]interface{}{
		"device":     "Apple,iPhone,iPhoneX",
		"cipherType": "0",
		"mac":        "02:00:00:00:00:00",
		"serial":     acc.Idfv,
		"platform":   "Apple,iOS," + acc.HardwareInfo.SystemVersion,
		"local":      "zh_CN",
		"ext":        "8",
		"version":    "6.5.4",
		"plugins":    "5",
		"page":       "6",
		"agent":      "X-IOS",
	}
}

func (acc *Account) setRandKey(key string) error {
	acc.RandKey = []byte(utils.NewRandString(16, false))

	rsAry, err := base64.StdEncoding.DecodeString(key)
	if err != nil {
		logger.Errorf("[CBC][%+v]setRandKey RSBase64解密错误: %+v.", acc.Account, err)
		return err
	}
	acc.DeviceSM4Key = []byte{}
	acc.DeviceSM4IV = []byte{}
	acc.DeviceSM4Key = append(acc.DeviceSM4Key, rsAry[0:8]...)
	acc.DeviceSM4Key = append(acc.DeviceSM4Key, acc.RandKey[0:8]...)

	acc.DeviceSM4IV = append(acc.DeviceSM4IV, rsAry[8:16]...)
	acc.DeviceSM4IV = append(acc.DeviceSM4IV, acc.RandKey[8:16]...)
	// fmt.Printf("%x\n", rsAry)

	rsAry, err = SM4Decrypt(rsAry, sm4Key)
	if err != nil {
		logger.Errorf("[CBC][%+v]setRandKey SM4解密错误: %+v.", acc.Account, err)
		return err
	}

	// fmt.Printf("%x\n", rsAry)
	acc.PassSM4Key = []byte{}
	acc.PassSM4IV = []byte{}

	acc.PassSM4Key = append(acc.PassSM4Key, rsAry[0:8]...)
	acc.PassSM4Key = append(acc.PassSM4Key, acc.RandKey[0:8]...)

	acc.PassSM4IV = append(acc.PassSM4IV, rsAry[8:16]...)
	acc.PassSM4IV = append(acc.PassSM4IV, acc.RandKey[8:16]...)

	return nil
}

func decodeJSON(str string, obj interface{}) error {
	if err := json.Unmarshal([]byte(str), obj); err != nil {
		return err
	}

	return nil
}

func (acc *Account) getRsaKey() (string, error) {
	block, _ := pem.Decode([]byte(devicePublicKey))
	publicKeyInterface, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		logger.Errorf("[CBC][%+v]getRsaKey解释公钥数据错误: %+v.", acc.Account, err)
		return "", err
	}
	// 类型断言
	publicKey := publicKeyInterface.(*rsa.PublicKey)
	// label := []byte("")
	// sha256hash := sha256.New()
	// cipherText, err := rsa.EncryptOAEP(sha256hash, rand.Reader, publicKey, acc.AesKey, label)

	cipherText, err := utils.RSAEncryptPKCS1v15(acc.AesKey, publicKey)
	if err != nil {
		logger.Errorf("[CBC][%+v]getRsaKey加密AesKey错误: %+v.", acc.Account, err)
		return "", err
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

func (acc *Account) getToken() (*resToken, error) {
	// data := map[string]interface{}{
	// 	"deviceModel":              "iPhone10,6",
	// 	"isJailBreak":              true,
	// 	"batteryStatus":            3,
	// 	"country":                  "CN",
	// 	"cpuCoreNum":               6,
	// 	"batteryLevel":             -1,
	// 	"wifiMac":                  nil,
	// 	"cellIPAddress":            "10.7.48.10",
	// 	"systemUpTime":             272560,
	// 	"timeZone":                 "Asia/Phnom_Penh",
	// 	"appVersion":               appVersion,
	// 	"totalMemory":              2816,
	// 	"carrierOperator":          "seatel",
	// 	"freeDiskSpace":            42.129005432128906,
	// 	"wiFiIPAddress":            nil,
	// 	"diskSpace":                59.5460090637207,
	// 	"carrierMobileNetworkCode": "11",
	// 	"appId":                    "Production_env_zh",
	// 	"cpuFrequency":             2,
	// 	"carrierAllowVoip":         true,
	// 	"screenH":                  812,
	// 	"osVersion":                "12.4",
	// 	"internetType":             "4G",
	// 	"wifiName":                 nil,
	// 	"carrierIsoCountryCode":    "kh",
	// 	"screenBrightness":         0.2991935908794403,
	// 	"deviceType":               "iPhone",
	// 	"idfa":                     "EB707E26-9549-4118-9AAB-053E892E4D31",
	// 	"idfv":                     "6C2C6BAC-6206-48C3-8C52-85D5DC580875",
	// 	"usedDiskSpace":            17.417003631591797,
	// 	"os":                       "iOS",
	// 	"connectedToCellNetwork":   true,
	// 	"carrierMobileCountryCode": "456",
	// 	"usedMemory":               73.046875,
	// 	"connectedToWiFi":          false,
	// 	"deviceName":               "iPhone Work",
	// 	"isEmulate":                false,
	// 	"screenW":                  375,
	// 	"sdkVersion":               "1.0.0",
	// 	"clientId":                 "44B2A483-461B-4A3D-A089-B9672534A8E8",
	// 	"isOpenGPS":                false,
	// 	"macAddress":               "02:00:00:00:00:00",
	// 	"language":                 "zh",
	// 	"tokenId":                  acc.TokenID,
	// 	"resolution":               "1125.000000*2436.000000",
	// 	"cpuType":                  "arm64 v8",
	// }

	//6.5.6包
	/*
		{
		  "deviceModel" : "iPhone7,2",
		  "isJailBreak" : true,
		  "batteryStatus" : 2,
		  "country" : "CN",
		  "cpuCoreNum" : 2,
		  "batteryLevel" : 1,
		  "wifiMac" : null,
		  "cellIPAddress" : "100.194.84.124",
		  "systemUpTime" : 94264,
		  "timeZone" : "Asia/Shanghai",
		  "appVersion" : "6.5.4(3.0.0)",
		  "totalMemory" : 1024,
		  "carrierOperator" : "中国电信",
		  "wiFiIPAddress" : null,
		  "diskSpace" : 14.891368865966797,
		  "carrierMobileNetworkCode" : "04",
		  "appId" : "Production_env_zh",
		  "isVPNOpened" : false,
		  "screenH" : 667,
		  "proxyInfo" : "",
		  "osVersion" : "11.4.1",
		  "internetType" : "3G",
		  "wifiName" : null,
		  "carrierIsoCountryCode" : "nl",
		  "screenBrightness" : 0.52175611257553101,
		  "deviceType" : "iPhone",
		  "idfa" : "22D04092-EC2D-4B75-9062-9F177F335288",
		  "idfv" : "64AC0589-5E8E-4D36-B7AD-F47E9432DB10",
		  "os" : "iOS",
		  "connectedToCellNetwork" : true,
		  "carrierMobileCountryCode" : "204",
		  "connectedToWiFi" : false,
		  "isEmulate" : false,
		  "deviceName" : "guapi444",
		  "screenW" : 375,
		  "sdkVersion" : "1.1.6",
		  "clientId" : "43C30E2E-EC52-4CF5-B128-5FC0FA23E4B9",
		  "macAddress" : "02:00:00:00:00:00",
		  "tokenId" : "Js1t2syrSEDTWDUnJXiHsFGgPLtnZ20ln8k4N+Mdz5UN0mmxPdu80iF\/G0\/2Z3ScFOaw\/rZMiiAy5nGJyQeT2U6+t4Iv5i34TJBrqoZecBKYNkALBF3AfHLNhWP4U3lW2\/F3Y4xuigMcr5RqpwZfRN1TStUgVYtge44zoE\/cKLiq4Hdsp634kNLZ3vM64zY7",
		  "language" : "zh-Hans-KH",
		  "resolution" : "750.000000*1334.000000",
		  "cpuType" : "arm64 v8"
		}

	*/

	data := map[string]interface{}{
		"deviceModel":              acc.HardwareInfo.Model,
		"isJailBreak":              false,
		"batteryStatus":            3,
		"country":                  "CN",
		"cpuCoreNum":               2,
		"batteryLevel":             -1,
		"wifiMac":                  nil,
		"cellIPAddress":            acc.HardwareInfo.CellularIP,
		"systemUpTime":             utils.RandInt(92000, 94264),
		"timeZone":                 "Asia/Shanghai",
		"appVersion":               appVersion,
		"totalMemory":              2816,
		"carrierOperator":          acc.MobileOperators,
		"wiFiIPAddress":            nil,
		"diskSpace":                59.5460090637207,
		"carrierMobileNetworkCode": "11", //运营商移动网络码中国联通 中国电信 中国移动不一样
		"appId":                    "Production_env_zh",
		"isVPNOpened":              false,
		"screenH":                  acc.HardwareInfo.ScreenH,
		"proxyInfo":                "",
		"osVersion":                acc.HardwareInfo.OSVersion,
		"internetType":             "4G",
		"wifiName":                 nil,
		"carrierIsoCountryCode":    "nl",
		"screenBrightness":         0.52175611257553101,
		"deviceType":               "iPhone",
		"idfa":                     acc.Idfa,
		"idfv":                     acc.Idfv,
		"os":                       "iOS",
		"connectedToCellNetwork":   true,
		"carrierMobileCountryCode": "204",
		"connectedToWiFi":          false,
		"isEmulate":                false,
		"deviceName":               "guapi444",
		"screenW":                  acc.HardwareInfo.ScreenW,
		"sdkVersion":               sdkVersion,
		"clientId":                 acc.ClientID,
		"macAddress":               "02:00:00:00:00:00",
		"tokenId":                  acc.TokenID,
		"language":                 "zh",
		"resolution":               acc.HardwareInfo.ScreenPixel,
		"cpuType":                  "arm64 v8",
	}

	arr, _ := json.Marshal(data)

	// fmt.Println(string(arr))

	acc.AesKey = []byte{0x44, 0x46, 0x36, 0x45, 0x42, 0x45, 0x34, 0x33, 0x30, 0x46, 0x43, 0x46, 0x30, 0x35, 0x31, 0x36}

	rsaKey, _ := acc.getRsaKey()

	buff, _ := AESCBCEncrypt(arr, acc.AesKey, acc.AesKey)

	req, err := http.NewRequest("POST", urlGetToken, bytes.NewReader(buff))
	if err != nil {
		logger.Errorf("[CBC][%+v]getToken创建http请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	req.Header.Set("sdk_platform", "2")
	req.Header.Set("User-Agent", "BOCMBCI/3.0.0 CFNetwork/978.0.7 Darwin/18.7.0")
	req.Header.Set("rsa_key", rsaKey)

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[CBC][%+v]getToken http操作错误: %+v.", acc.Account, err)
		return nil, err
	}

	res := resToken{}
	if err := decodeJSON(body, &res); err != nil {
		logger.Errorf("[CBC][%+v]getToken响应数据反序列化错误: %+v.", acc.Account, err)
		return nil, err
	}

	if res.RspHeader.Status != 0 {
		logger.Warnf("[CBC][%+v]getToken反回失败, 代码: %d, 信息: %s.", acc.Account, res.RspHeader.Status, res.RspHeader.Msg)
		return nil, errors.New("获取TokenID失败")
	}

	return &res, nil
}

func (acc *Account) psnxGetRandomLoginPre() (*resPsnxGetRandomLoginPre, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnxGetRandomLoginPre",
		"params": map[string]interface{}{
			"isNeedCreate": true,
		},
	}

	res := resPsnxGetRandomLoginPre{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnxGetRandomLoginPre请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 账号登录
func (acc *Account) psnLoginForPassword() (*resPsnLoginForPassword, error) {
	password, passwordRc, err := acc.encryptPassword(acc.getPassword())
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnLoginForPassword 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	data := map[string]interface{}{}
	device := fmt.Sprintf("%s%d", acc.Idfv, acc.UserID)

	deviceInfo, deviceInfoRc, err := acc.encryptDeviceid(device)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnLoginForPassword 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	data = map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnLoginForPassword",
		"params": map[string]interface{}{
			"deviceLocateInfo":   "||||||",
			"wp7LoginType":       "2",
			"loginName":          acc.Account,
			"password_RC":        passwordRc,
			"deviceInfo":         deviceInfo,
			"conversationId":     acc.ConversationID,
			"password":           password,
			"devicePrintTokenId": acc.TokenID,
			"deviceInfo_RC":      deviceInfoRc,
			"validationChar":     "",
			"segment":            "1",
			"state":              "41943040",
			"activ":              "403002008",
		},
	}

	res := resPsnLoginForPassword{}

	_, err = acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnLoginForPassword请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 查询所有中国银行帐户?
func (acc *Account) getPsnCommonQueryAllChinaBankAccount() (*resPsnCommonQueryAllChinaBankAccount, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnCommonQueryAllChinaBankAccount",
		"params": map[string]interface{}{},
	}

	res := resPsnCommonQueryAllChinaBankAccount{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnQueryUserLocateAuth请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 验证什么鬼
func (acc *Account) psnQueryUserLocateAuth() (*resPsnQueryUserLocateAuth, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnQueryUserLocateAuth",
		"params": map[string]interface{}{},
	}

	res := resPsnQueryUserLocateAuth{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnQueryUserLocateAuth请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) psnxGetRandom() (*resPsnxGetRandom, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnxGetRandom",
		"params": map[string]interface{}{
			"isNeedCreate": true,
		},
	}

	res := resPsnxGetRandom{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]PsnxGetRandom请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) pSNGetRandom() (*resPSNGetRandom, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PSNGetRandom",
		"params": map[string]interface{}{
			"conversationId": acc.ConversationID,
		},
	}

	res := resPSNGetRandom{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]PSNGetRandom请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) psnSvrRegisterDevicePre(combinid string) (*resPsnSvrRegisterDevicePre, error) {

	device := fmt.Sprintf("%s%d", acc.Idfv, acc.UserID)

	deviceInfo, deviceInfoRc, err := acc.encryptDeviceid(device)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnLoginForPassword 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnSvrRegisterDevicePre",
		"params": map[string]interface{}{
			"areaCode":       "",
			"conversationId": acc.ConversationID,
			"deviceInfo_RC":  deviceInfoRc,
			"deviceInfo":     deviceInfo,
			"_combinId":      "32",
			"state":          "41943040",
			"activ":          "303002003",
		},
	}

	res := resPsnSvrRegisterDevicePre{}

	_, err = acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDevicePre请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) pSNGetTokenID() (*resPSNGetTokenID, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PSNGetTokenId",
		"params": map[string]interface{}{
			"conversationId": acc.ConversationID,
		},
	}

	res := resPSNGetTokenID{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]pSNGetTokenID请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) psnSvrRegisterDeviceSubmit(smsCode string) (*resPsnSvrRegisterDeviceSubmit, error) {
	t := time.Now()
	grantTime := fmt.Sprintf("%.4d%.2d%.2d%.2d%.2d%.2d", t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second())

	grantNo := acc.Account + grantTime

	smc, smcRC, err := acc.encryptVerifyCode(smsCode)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	device := fmt.Sprintf("%s%d", acc.Idfv, acc.UserID)

	deviceInfo, deviceInfoRc, err := acc.encryptDeviceid(device)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnSvrRegisterDeviceSubmit",
		"params": map[string]interface{}{
			"state":              "41943040",
			"deviceLocateInfo":   "||||||",
			"deviceInfo":         deviceInfo,
			"Otp":                "",
			"conversationId":     acc.ConversationID,
			"Smc":                smc,
			"Smc_RC":             smcRC,
			"grantNo":            grantNo,
			"grantTime":          grantTime,
			"token":              acc.Token,
			"devicePrintTokenId": acc.TokenID,
			"deviceInfo_RC":      deviceInfoRc,
			"_signedData":        "",
			"areaCode":           "",
			"activ":              "303002003",
		},
	}

	res := resPsnSvrRegisterDeviceSubmit{}

	_, err = acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getPsnUCSendSMS(code string) error {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnUCSendSMS",
		"params": map[string]interface{}{
			"validationChar": code,
			"mobile":         acc.Account,
			"conversationId": acc.ConversationID,
		},
	}

	res := resPsnUCSendSMS{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnUCSendSMS请求错误: %+v.", acc.Account, err)
		return err
	}

	return nil
}

func (acc *Account) getPsnUCloginOrRegForMsg() error {

	arr, _ := SM2Encrypt(acc.RandKey, sm2KeyX, sm2KeyY)

	validateCodeRC := base64.StdEncoding.EncodeToString(arr)

	// fmt.Println(validateCodeRC)

	code := "666666"

	codeAry, err := SM4CBCEncrypt([]byte(code), acc.PassSM4Key, acc.PassSM4IV)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnUCloginOrRegForMsg SM4加密短信验证码错误: %+v.", acc.Account, err)
		return err
	}

	validateCode := base64.StdEncoding.EncodeToString(codeAry)

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnUCLoginOrRegForMsg",
		"params": map[string]interface{}{
			"validateCode_RC": validateCodeRC,
			"loginName":       "13528520510",
			"conversationId":  acc.ConversationID,
			"validateCode":    validateCode,
			"keep":            "1",
			"state":           "41943040",
			"activ":           "303002003",
		},
	}

	res := resPsnUCloginOrRegForMsg{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPSNGetRandomLoginPre请求错误: %+v.", acc.Account, err)
		return err
	}

	return nil
}

func (acc *Account) encryptPassword(str string) (string, string, error) {
	hash := sha1.New()
	hash.Write([]byte(str))

	base64Str := base64.StdEncoding.EncodeToString(hash.Sum(nil))

	arr, _ := SM2Encrypt(acc.RandKey, sm2KeyX, sm2KeyY)//加密自己生成的key

	enStrRc := base64.StdEncoding.EncodeToString(arr)

	// fmt.Println(enStrRc)

	enBuff, err := SM4CBCEncrypt([]byte(base64Str), acc.PassSM4Key, acc.PassSM4IV)
	if err != nil {
		logger.Errorf("[CBC][%+v]encryptSha1Rc SM4加密短信验证码错误: %+v.", acc.Account, err)
		return "", "", err
	}
	enStr := base64.StdEncoding.EncodeToString(enBuff)
	return enStr, enStrRc, nil
}

func (acc *Account) encryptVerifyCode(str string) (string, string, error) {
	arr, _ := SM2Encrypt(acc.RandKey, sm2KeyX, sm2KeyY)

	enStrRc := base64.StdEncoding.EncodeToString(arr)

	// fmt.Println(enStrRc)

	enBuff, err := SM4CBCEncrypt([]byte(str), acc.PassSM4Key, acc.PassSM4IV)
	if err != nil {
		logger.Errorf("[CBC][%+v]encryptSha1Rc SM4加密短信验证码错误: %+v.", acc.Account, err)
		return "", "", err
	}
	enStr := base64.StdEncoding.EncodeToString(enBuff)
	return enStr, enStrRc, nil
}

func (acc *Account) encryptDeviceid(str string) (string, string, error) {
	hash := sha1.New()
	hash.Write([]byte(str))

	base64Str := base64.StdEncoding.EncodeToString(hash.Sum(nil))

	arr, _ := SM2Encrypt(acc.RandKey, sm2KeyX1, sm2KeyY1)

	enStrRc := base64.StdEncoding.EncodeToString(arr)

	// fmt.Println(enStrRc)

	enBuff, err := SM4CBCEncrypt([]byte(base64Str), acc.DeviceSM4Key, acc.DeviceSM4IV)
	if err != nil {
		logger.Errorf("[CBC][%+v]encryptSha1Rc SM4加密短信验证码错误: %+v.", acc.Account, err)
		return "", "", err
	}
	enStr := base64.StdEncoding.EncodeToString(enBuff)
	return enStr, enStrRc, nil
}

//
func (acc *Account) getPsnCommonQuerySystemDateTime() (*resPsnCommonQuerySystemDateTime, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnCommonQuerySystemDateTime",
		"params": map[string]interface{}{},
	}

	res := resPsnCommonQuerySystemDateTime{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnCommonQuerySystemDateTime请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 普通查询所有中国银行帐户
func (acc *Account) psnCommonQueryAllChinaBankAccount() (*resPsnCommonQueryAllChinaBankAccount, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnCommonQueryAllChinaBankAccount",
		"params": map[string]interface{}{},
	}

	res := resPsnCommonQueryAllChinaBankAccount{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]PsnCommonQueryAllChinaBankAccount请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

//
func (acc *Account) psnMobileIsSignedAgent() (*resPsnMobileIsSignedAgent, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnMobileIsSignedAgent",
		"params": map[string]interface{}{},
	}

	res := resPsnMobileIsSignedAgent{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]PsnMobileIsSignedAgent请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) psnQueryBankBranchInfo() (*resPsnQueryBankBranchInfo, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnQueryBankBranchInfo",
		"params": map[string]interface{}{},
	}

	res := resPsnQueryBankBranchInfo{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]psnQueryBankBranchInfo请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 账户余额查询
func (acc *Account) getPsnAssetBalanceQuery() (*resPsnAssetBalanceQuery, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnAssetBalanceQuery",
		"params": map[string]interface{}{},
	}

	res := resPsnAssetBalanceQuery{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnAssetBalanceQuery请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 帐户查询帐户转账明细
func (acc *Account) getPsnAccountQueryTransferDetail() (*resPsnAccountQueryTransferDetail, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnAccountQueryTransferDetail",
		"params": map[string]interface{}{
			"sortFlag":       "",
			"conversationId": acc.ConversationID,
			"toAccNumber":    "",
			"endDate":        "2019/12/19",
			"currentIndex":   "0",
			"cashRemit":      "",
			"accountId":      strconv.Itoa(acc.accountID),
			"serType":        "",
			"amtLimit":       "",
			"_refresh":       "true",
			"amtUpper":       "",
			"startDate":      "2019/06/20",
			"toAccName":      "",
			"currency":       "001",
			"pageSize":       "50",
		},
	}

	res := resPsnAccountQueryTransferDetail{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnAccountQueryTransferDetail请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) psnAllAccountsQuery() (*resPsnAllAccountsQuery, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnAllAccountsQuery",
		"params": map[string]interface{}{
			"conversationId": acc.ConversationID,
		},
	}

	res := resPsnAllAccountsQuery{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnAllAccountsQuery请求错误: %+v.", acc.Account, err)
		return nil, err
	}
	return &res, nil
}

func (acc *Account) pSNCreatConversationLoginPre() (*resPSNCreatConversationLoginPre, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PSNCreatConversationLoginPre",
		"params": map[string]interface{}{},
	}

	res := resPSNCreatConversationLoginPre{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]pSNCreatConversationLoginPre请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getPsnSendSMSCodeToMobile() (*resPsnSendSMSCodeToMobile, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnSendSMSCodeToMobile",
		"params": map[string]interface{}{
			"conversationId": acc.ConversationID,
		},
	}

	res := resPsnSendSMSCodeToMobile{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnSendSMSCodeToMobile请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 以下为转账流程

// PsnTransPayeeListqueryForDim
// 常用收款人信息查询
func (acc *Account) getPsnTransPayeeListqueryForDim() (*resPsnTransPayeeListqueryForDim, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransPayeeListqueryForDim",
		"params": map[string]interface{}{
			"currentIndex": "0",
			"isAppointed":  "",
			"pageSize":     "500",
			"bocFlag": []string{
				"0",
				"1",
				"3",
			},
		},
	}

	res := resPsnTransPayeeListqueryForDim{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnTransPayeeListqueryForDim请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnTransPayeeRecommend
func (acc *Account) getPsnTransPayeeRecommend() (*resPsnTransPayeeRecommend, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransPayeeRecommend",
		"params": map[string]interface{}{
			"pageSize":     5,
			"currentIndex": 0,
			"bocFlag": []string{
				"",
			},
		},
	}

	res := resPsnTransPayeeRecommend{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnTransPayeeRecommend请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}


//PsnTransQueryOpenBank // 遍历小银行
func (acc *Account) getPsnTransQueryOpenBank() (*resPsnTransPayeeRecommend, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransQueryOpenBank",
		"params": map[string]interface{}{
			"bankCode":    "OTHER",
			"bankName":    "",
			"clscod": "",
			"currentIndex":"0",
			"drecco":"",
			"pageSize":"50",
		},
	}




}
// PsnTransQuerySMSCharge
func (acc *Account) getPsnTransQuerySMSCharge() (*resPsnTransQuerySMSCharge, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransQuerySMSCharge",
		"params": map[string]interface{}{},
	}

	res := resPsnTransQuerySMSCharge{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnTransQuerySMSCharge请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnQueryBankInfobyCardBin //查询对方的银行编码
// 通过银行帐户查询对方账户详细信息
func (acc *Account) getPsnQueryBankInfobyCardBin(cardNo string) (*resPsnQueryBankInfobyCardBin, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnQueryBankInfobyCardBin",
		"params": map[string]interface{}{
			"accountNumber": cardNo,
		},
	}

	res := resPsnQueryBankInfobyCardBin{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnQueryBankInfobyCardBin请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnQryBankInfoByCnaps 拿到对方银行编号继续查询银行细节
// 通过上面反回的CnapsCode去查询银行的具体信息
func (acc *Account) getPsnQryBankInfoByCnaps() (*resPsnQryBankInfoByCnaps, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnQryBankInfoByCnaps",
		"params": map[string]interface{}{
			"bankCode": acc.bankCode,
		},
	}

	res := resPsnQryBankInfoByCnaps{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnQryBankInfoByCnaps请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil

}

// PsnTransQuotaQuery 检查需要转账的交易金额
// 检查需要转账的交易金额
func (acc *Account) getPsnTransQuotaQuery() (*resPsnTransQuotaQuery, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransQuotaQuery",
		"params": map[string]interface{}{},
	}

	res := resPsnTransQuotaQuery{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnTransQuotaQuery请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil

	// 这个包发完发 getPSNCreatConversation 这个切换一下ID
}

// PSNCreatConversation 切换conversationId
// 查询账户详细信息的时候需要发这个包
func (acc *Account) pSNCreatConversation() (*resPSNCreatConversation, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PSNCreatConversation",
		"params": map[string]interface{}{},
	}

	res := resPSNCreatConversation{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]pSNCreatConversation请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	acc.ConversationID = res.Result

	return &res, nil
}

// PsnGetSecurityFactor 安全因数

// 不知道什么鬼
func (acc *Account) psnGetSecurityFactor(servicesID string) (*resPsnGetSecurityFactor, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnGetSecurityFactor",
		"params": map[string]interface{}{
			"serviceId":      servicesID,
			"conversationId": acc.ConversationID,
		},
	}

	res := resPsnGetSecurityFactor{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnGetSecurityFactor请求错误: %+v.", acc.Account, err)
		return nil, err
	}
	return &res, nil
}

// 同行转账验证PsnTransBocTransferVerify
func (acc *Account) getPsnTransBocTransferVerify() (*resPsnTransBocTransferVerify, error) {

	key := []byte{
		0x56, 0x7B, 0x58, 0xA4, 0x9A, 0xDC, 0xDF, 0x0E, 0xDB, 0x1A, 0x41, 0x03, 0x42, 0x6E, 0x23, 0x86,
		0x61, 0x1F, 0x23, 0x71, 0x75, 0x18, 0x3F, 0x4A}
	//iv := []byte{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}

	inAmount := []byte(acc.amount)
	inPayeeActno := []byte(acc.targetAccount)
	inpayeeName := []byte(acc.targetName)

	encAmount, err := openssl.Des3ECBEncrypt(inAmount, key, openssl.PKCS7_PADDING)
	//enc, err := utils.TripleDESCBCEncrypt(in, key, iv)

	encPayeeActno, err := openssl.Des3ECBEncrypt(inPayeeActno, key, openssl.PKCS7_PADDING)
	//encAmount, err := utils.TripleDESCBCEncrypt(inAmount, key, iv)

	encPayeeName, err := openssl.Des3ECBEncrypt(inpayeeName, key, openssl.PKCS7_PADDING)

	strAmount := base64.StdEncoding.EncodeToString(encAmount)
	strPayeeActno := base64.StdEncoding.EncodeToString(encPayeeActno)
	strPayeeName := base64.StdEncoding.EncodeToString(encPayeeName)
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransBocTransferVerify",
		"params": map[string]interface{}{
			"payeeMobile":    "",
			"executeType":    "0",
			"amount":         strAmount,
			"_combinId":      "96",
			"conversationId": acc.ConversationID,
			"payeeId":        "",
			"endDate":        "",
			"passFlag":       "1",
			"payeeActno":     strPayeeActno,
			"remark":         acc.comment,
			"startDate":      "",
			"fromAccountId":  strconv.Itoa(acc.accountID),
			"cycleSelect":    "",
			"currency":       "001",
			"payeeName":      strPayeeName,
		},
	}

	res := resPsnTransBocTransferVerify{}

	_, err1 := acc.postHTTPData(&data, &res)
	if err1 != nil {
		logger.Errorf("[CBC][%+v]PsnTransBocTransferVerify请求错误: %+v.", acc.Account, err)
		return nil, err
	}
	return &res, nil
}

// PsnTransGetBocTransferCommissionCharge同行转帐费用查询
func (acc *Account) getPsnTransGetBocTransferCommissionCharge() (*resPsnTransGetBocTransferCommissionCharge, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransGetBocTransferCommissionCharge",
		"params": map[string]interface{}{
			"payeeMobile":   "",
			"serviceId":     "PB031",
			"amount":        acc.amount,
			"toAccountId":   "",
			"cashRemit":     "",
			"payeeActno":    acc.targetAccount,
			"remark":        "",
			"notifyId":      "",
			"fromAccountId": strconv.Itoa(acc.accountID),
			"currency":      "001",
			"payeeName":     acc.targetName,
		},
	}

	res := resPsnTransGetBocTransferCommissionCharge{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]PsnTransGetBocTransferCommissionCharge请求错误: %+v.", acc.Account, err)
		return nil, err
	}
	return &res, nil
}

// PsnEbpsRealTimePaymentConfirm 确认订单

// 不知道什么鬼 这个函数下面几个值加密没看
func (acc *Account) getPsnEbpsRealTimePaymentConfirm() (*resPsnEbpsRealTimePaymentConfirm, error) {

	key := []byte{
		0x56, 0x7B, 0x58, 0xA4, 0x9A, 0xDC, 0xDF, 0x0E, 0xDB, 0x1A, 0x41, 0x03, 0x42, 0x6E, 0x23, 0x86,
		0x61, 0x1F, 0x23, 0x71, 0x75, 0x18, 0x3F, 0x4A}

	in := []byte(acc.targetName)

	inAmount := []byte(acc.amount)
	inPayeeActno := []byte(acc.targetAccount)

	enc, err := openssl.Des3ECBEncrypt(in, key, openssl.PKCS7_PADDING)
	//enc, err := utils.TripleDESCBCEncrypt(in, key, iv)

	encAmount, err := openssl.Des3ECBEncrypt(inAmount, key, openssl.PKCS7_PADDING)
	//encAmount, err := utils.TripleDESCBCEncrypt(inAmount, key, iv)

	encPayeeActno, err := openssl.Des3ECBEncrypt(inPayeeActno, key, openssl.PKCS7_PADDING)
	//encPayeeActno, err := utils.TripleDESCBCEncrypt(inPayeeActno, key, iv)
	if err != nil {
		logger.Errorf("加密错误: %+v", err)
	}

	strPayeeName := base64.StdEncoding.EncodeToString(enc)
	strAmount := base64.StdEncoding.EncodeToString(encAmount)
	strPayeeActno := base64.StdEncoding.EncodeToString(encPayeeActno)
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnEbpsRealTimePaymentConfirm",
		"params": map[string]interface{}{
			"payeeMobile":    "",
			"payeeActno2":    acc.targetAccount,
			"executeType":    "0",
			"amount":         strAmount, //3des
			"_combinId":      "96",
			"memo":           acc.comment,
			"payeeOrgName":   acc.bankName,
			"conversationId": acc.ConversationID,
			"payeeId":        "",
			"passFlag":       "1",
			"payeeActno":     strPayeeActno,
			"payeeBankName":  acc.bankName,
			"fromAccountId":  strconv.Itoa(acc.accountID),
			"payeeCnaps":     acc.bankCode,
			"currency":       "001",
			"payeeName":      strPayeeName, //3des加密
			"sendMsgFlag":    "0",
		},
	}

	res := resPsnEbpsRealTimePaymentConfirm{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnEbpsRealTimePaymentConfirm请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnTransGetNationalTransferCommissionCharge 获取转账费用
func (acc *Account) getPsnTransGetNationalTransferCommissionCharge() (*resPsnTransGetNationalTransferCommissionCharge, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransGetNationalTransferCommissionCharge",
		"params": map[string]interface{}{
			"payeeMobile":    "",
			"serviceId":      "PB113", //这里是死的
			"conversationId": "",
			"amount":         acc.amount,
			"toOrgName":      acc.bankName,
			"cnapsCode":      acc.bankCode,
			"cashRemit":      "",
			"payeeActno":     acc.targetAccount,
			"remark":         "",
			"fromAccountId":  strconv.Itoa(acc.accountID),
			"currency":       "001",
			"payeeName":      acc.targetName,
		},
	}

	res := resPsnTransGetNationalTransferCommissionCharge{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnTransGetNationalTransferCommissionCharge请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 同行转账
// PsnTransBocTransferSubmit
func (acc *Account) psnTransBocTransferSubmit(smsCode string) (*resPsnTransBocTransferSubmit, string, error) {

	key := []byte{
		0x56, 0x7B, 0x58, 0xA4, 0x9A, 0xDC, 0xDF, 0x0E, 0xDB, 0x1A, 0x41, 0x03, 0x42, 0x6E, 0x23, 0x86,
		0x61, 0x1F, 0x23, 0x71, 0x75, 0x18, 0x3F, 0x4A}
	//iv := []byte{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}
	in := []byte(acc.targetName)

	inAmount := []byte(acc.amount)
	inPayeeActno := []byte(acc.targetAccount)

	enc, err := openssl.Des3ECBEncrypt(in, key, openssl.PKCS7_PADDING)
	//enc, err := utils.TripleDESCBCEncrypt(in, key, iv)

	encAmount, err := openssl.Des3ECBEncrypt(inAmount, key, openssl.PKCS7_PADDING)
	//encAmount, err := utils.TripleDESCBCEncrypt(inAmount, key, iv)

	encPayeeActno, err := openssl.Des3ECBEncrypt(inPayeeActno, key, openssl.PKCS7_PADDING)
	//encPayeeActno, err := utils.TripleDESCBCEncrypt(inPayeeActno, key, iv)

	if err != nil {
		logger.Errorf("加密错误: %+v", err)
	}

	strPayeeName := base64.StdEncoding.EncodeToString(enc)
	strAmount := base64.StdEncoding.EncodeToString(encAmount)
	strPayeeActno := base64.StdEncoding.EncodeToString(encPayeeActno)

	smc, smcRC, err := acc.encryptVerifyCode(smsCode)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit 加密密码错误: %+v.", acc.Account, err)
		return nil, "", err
	}

	device := fmt.Sprintf("%s%d", acc.Idfv, acc.UserID)

	deviceInfo, deviceInfoRc, err := acc.encryptDeviceid(device)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit 加密密码错误: %+v.", acc.Account, err)
		return nil, "", err
	}

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnTransBocTransferSubmit",
		"params": map[string]interface{}{
			"Smc":                smc,
			"amount":             strAmount,
			"_signedData":        "",
			"deviceInfo":         deviceInfo,
			"fromAccountId":      strconv.Itoa(acc.accountID),
			"currency":           "001",
			"activ":              "403002008",
			"passFlag":           "1",
			"devicePrintTokenId": acc.TokenID,
			"executeType":        "0",
			"payeeId":            "",
			"deviceInfo_RC":      deviceInfoRc,
			"state":              "41943040",
			"deviceLocateInfo":   "||||||",
			"Otp":                "",
			"atmPassword":        "",
			"toAccountType":      "119",
			"token":              acc.Token,
			"passbookPassword":   "",
			"payeeName":          strPayeeName,
			"payeeActno":         strPayeeActno,
			"devicePrint":        "",
			"endDate":            "",
			"payeeMobile":        "",
			"startDate":          "",
			"Smc_RC":             smcRC,
			"payeeBankNum":       acc.payeeBankNum,
			"conversationId":     acc.ConversationID,
			"remark":             acc.comment,
			"cycleSelect":        "",
			"phoneBankPassword":  "",
		},
	}

	res := resPsnTransBocTransferSubmit{}

	body, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSvrRegisterDeviceSubmit请求错误: %+v.", acc.Account, err)
		return nil, "", err
	}

	return &res, body, nil
}

// PSNGetRandom //获取随机数
// PsnSendSMSCodeToMobile 获取交易短信
func (acc *Account) psnSendSMSCodeToMobile() (*resPsnSendSMSCodeToMobile, error) {
	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnSendSMSCodeToMobile",
		"params": map[string]interface{}{
			"conversationId": acc.ConversationID,
		},
	}

	res := resPsnSendSMSCodeToMobile{}

	_, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]psnSendSMSCodeToMobile请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PSNGetTokenId 获取token下一步使用
// PsnEbpsRealTimePaymentTransfer 确认交易
// 转账
func (acc *Account) getPsnEbpsRealTimePaymentTransfer(smsCode string) (*resPsnEbpsRealTimePaymentTransfer, error) {

	key := []byte{
		0x56, 0x7B, 0x58, 0xA4, 0x9A, 0xDC, 0xDF, 0x0E, 0xDB, 0x1A, 0x41, 0x03, 0x42, 0x6E, 0x23, 0x86,
		0x61, 0x1F, 0x23, 0x71, 0x75, 0x18, 0x3F, 0x4A}
	//iv := []byte{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}
	inPayeeName := []byte(acc.targetName)

	inAmount := []byte(acc.amount)
	inPayeeActno := []byte(acc.targetAccount)

	encPayeeActno, err := openssl.Des3ECBEncrypt(inPayeeActno, key, openssl.PKCS7_PADDING)
	//enc, err := utils.TripleDESCBCEncrypt(in, key, iv)

	encAmount, err := openssl.Des3ECBEncrypt(inAmount, key, openssl.PKCS7_PADDING)
	//encAmount, err := utils.TripleDESCBCEncrypt(inAmount, key, iv)

	encPayeeName, err := openssl.Des3ECBEncrypt(inPayeeName, key, openssl.PKCS7_PADDING)
	//encPayeeActno, err := utils.TripleDESCBCEncrypt(inPayeeActno, key, iv)

	if err != nil {
		logger.Errorf("加密错误: %+v", err)
	}

	strAmount := base64.StdEncoding.EncodeToString(encAmount)
	strPayeeActno := base64.StdEncoding.EncodeToString(encPayeeActno)
	strPayeeName := base64.StdEncoding.EncodeToString(encPayeeName)

	smc, smcRC, err := acc.encryptVerifyCode(smsCode)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnEbpsRealTimePaymentTransfer 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	device := fmt.Sprintf("%s%d", acc.Idfv, acc.UserID)

	deviceInfo, deviceInfoRc, err := acc.encryptDeviceid(device)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnEbpsRealTimePaymentTransfer 加密密码错误: %+v.", acc.Account, err)
		return nil, err
	}

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnEbpsRealTimePaymentTransfer",
		"params": map[string]interface{}{
			"Smc":                smc,
			"amount":             strAmount,
			"_signedData":        "",
			"deviceInfo":         deviceInfo,
			"fromAccountId":      strconv.Itoa(acc.accountID),
			"currency":           "001",
			"activ":              "403002008",
			"dueDate":            "",
			"passFlag":           "1",
			"devicePrintTokenId": acc.TokenID,
			"executeType":        "0",
			"payeeId":            "",
			"memo":               acc.comment,
			"deviceInfo_RC":      deviceInfoRc,
			"state":              "41943040",
			"deviceLocateInfo":   "||||||",
			"Otp":                "",
			"atmPassword":        "",
			"payeeBankName":      acc.bankName,
			"token":              acc.Token,
			"passbookPassword":   "",
			"payeeName":          strPayeeName,
			"payeeCnaps":         acc.bankCode,
			"payeeActno":         strPayeeActno,
			"devicePrint":        "",
			"payeeMobile":        "",
			"payeeOrgName":       acc.bankName,
			"Smc_RC":             smcRC,
			"sendMsgFlag":        "0",
			"conversationId":     acc.ConversationID,
			"phoneBankPassword":  "",
		},
	}

	res := resPsnEbpsRealTimePaymentTransfer{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnEbpsRealTimePaymentTransfer请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnSingleTransQueryTransferRecord不知道干嘛
func (acc *Account) getPsnSingleTransQueryTransferRecord(transID string) (*resPsnSingleTransQueryTransferRecord, string, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnSingleTransQueryTransferRecord",
		"params": map[string]interface{}{
			"transId": transID,
		},
	}

	res := resPsnSingleTransQueryTransferRecord{}

	body, err := acc.postHTTPData(&data, &res)
	if err != nil {
		logger.Errorf("[CBC][%+v]getPsnSingleTransQueryTransferRecord请求错误: %+v.", acc.Account, err)
		return nil, "", err
	}

	return &res, body, nil
}

// 帐户查询帐户详细信息
func (acc *Account) getPsnAccountQueryAccountDetail() (*resPsnAccountQueryAccountDetail, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnAccountQueryAccountDetail",
		"params": map[string]interface{}{
			"accountId": strconv.Itoa(acc.accountID),
		},
	}

	res := resPsnAccountQueryAccountDetail{}
	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnAccountQueryAccountDetail请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// PsnQueryTransActivityStatus不知道干嘛
func (acc *Account) getPsnQueryTransActivityStatus(transactionID string) (*resPsnQueryTransActivityStatus, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnQueryTransActivityStatus",
		"params": map[string]interface{}{
			"transactionId": transactionID,
			"tranType":      "",
		},
	}

	res := resPsnQueryTransActivityStatus{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]getPsnQueryTransActivityStatus请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}

// 查询账单
func (acc *Account) getPsnFinRecQuery(startDate string, endDate string, index string) (*resPsnFinRecQuery, error) {

	data := map[string]interface{}{
		"header": acc.getHeader(),
		"method": "PsnFinRecQuery",
		"params": map[string]interface{}{
			"maxTranAmount":   "",
			"debitCreditFlag": "",
			"sumFlag":         "",
			"conversationId":  acc.ConversationID,
			"endDate":         endDate,
			"currentIndex":    index,
			"maxCount":        "50",
			"keywords":        "",
			"transCat":        "",
			"classifyId":      "",
			"startDate":       startDate,
			"minTranAmount":   "",
		},
	}

	res := resPsnFinRecQuery{}

	if _, err := acc.postHTTPData(&data, &res); err != nil {
		logger.Errorf("[CBC][%+v]PsnFinRecQuery请求错误: %+v.", acc.Account, err)
		return nil, err
	}

	return &res, nil
}
