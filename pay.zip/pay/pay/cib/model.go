package cib

import "fmt"

type generatePostRes struct {
	IDFV string `json:"IDFV"`
	Exp  string `json:"exp"`
	Dfp  string `json:"dfp"`
}

type err struct {
	Code    string `json:"code"`
	TraceID string `json:"traceId"`
	Msg     string `json:"msg"`
	OldMsg  string `json:"oldMsg"`
}

type keyHandleRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		KeyType   string `json:"key_type"`
		KeyLength string `json:"key_length"`
		KeyStr    string `json:"key_str"`
		KeyID     string `json:"key_id"`
		HandleID  string `json:"handle_id"`
	} `json:"data"`
}

func (res *keyHandleRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type keepAliveRes struct {
	Status int `json:"status"`
	Data   struct {
		IsLogin bool `json:"isLogin"`
	} `json:"data"`
}

type queryUserByMistyRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		PromptMsg string `json:"promptMsg"`
		ListSize  int    `json:"listSize"`
		CustList  []struct {
			UniauthID         string `json:"uniauthId"`
			MaskUamName       string `json:"maskUamName"`
			UniauthStatus     string `json:"uniauthStatus"`
			UniauthStatusDesc string `json:"uniauthStatusDesc"`
			Authed            string `json:"authed"`
			AuthedDesc        string `json:"authedDesc"`
			AuthedType        string `json:"authedType"`
			AuthedTypeDesc    string `json:"authedTypeDesc"`
		} `json:"custList"`
	} `json:"data"`
}

func (res *queryUserByMistyRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryUserByUniauthIDRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		PromptMsg string `json:"promptMsg"`
		ListSize  int    `json:"listSize"`
		CustList  []struct {
			UniauthID         string `json:"uniauthId"`
			MaskUamName       string `json:"maskUamName"`
			UniauthStatus     string `json:"uniauthStatus"`
			UniauthStatusDesc string `json:"uniauthStatusDesc"`
			Authed            string `json:"authed"`
			AuthedDesc        string `json:"authedDesc"`
			AuthedType        string `json:"authedType"`
			AuthedTypeDesc    string `json:"authedTypeDesc"`
		} `json:"custList"`
	} `json:"data"`
}

func (res *queryUserByUniauthIDRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type getEncryptPKRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		RSAPublicKey  string `json:"rsaPublicKey"`
		SM2PublicKeyX string `json:"sm2PublicKeyX"`
		SM2PublicKeyY string `json:"sm2PublicKeyY"`
	} `json:"data"`
}

func (res *getEncryptPKRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type comitLoginInfoRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		FrmsCompages int `json:"frmsCompages"`
	} `json:"data"`
}

func (res *comitLoginInfoRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type getTokenRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Token string `json:"token"`
	} `json:"data"`
}

func (res *getTokenRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type custLoginRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		UniauthID          string `json:"uniauthId"`
		LoginMode          string `json:"loginMode"`
		LoginPhoneNo       string `json:"loginPhoneNo"`
		CustomerID         string `json:"customerId"`
		Name               string `json:"name"`
		IDNo               string `json:"idNo"`
		IDType             string `json:"idType"`
		CustPhoneNo        string `json:"custPhoneNo"`
		LastLoginTime      string `json:"lastLoginTime"`
		KeepMsg            string `json:"keepMsg"`
		UserLoginName      string `json:"userLoginName"`
		Authed             string `json:"authed"`
		CustomerLevelValue string `json:"customerLevelValue"`
		CustomerLevelName  string `json:"customerLevelName"`
		PwdErrorNum        int    `json:"pwdErrorNum"`
		RegisterName       string `json:"registerName"`
		InnerCode          string `json:"innerCode"`
	} `json:"data"`
}

func (res *custLoginRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type getAccountsByURLRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		LastVerifyPwdAccountIndex int `json:"lastVerifyPwdAccountIndex"`
		List                      []struct {
			AccountIndex       int    `json:"accountIndex"`
			AccountNoMask      string `json:"accountNoMask"`
			OwnerName          string `json:"ownerName"`
			AccountName        string `json:"accountName"`
			AccountType        int    `json:"accountType"`
			AccountTypeDesc    string `json:"accountTypeDesc"`
			BankCode           string `json:"bankCode"`
			HasPwd             bool   `json:"hasPwd"`
			HasQueryPwd        bool   `json:"hasQueryPwd"`
			BelongLevel        string `json:"belongLevel"`
			BelongLevelDesc    string `json:"belongLevelDesc"`
			AcctCategory       string `json:"acctCateGory"`
			AcctCategoryDesc   string `json:"acctCategoryDesc"`
			AcctStatus         string `json:"acctStatus"`
			AcctStatusDesc     string `json:"acctStatusDesc"`
			CreditProdNo       string `json:"creditProdNo"`
			CreditFace         string `json:"creditFace"`
			CardOriginalStatus string `json:"cardOriginalStatus"`
			CardType           string `json:"cardType"`
			CreditCardStatus   string `json:"creditCardStatus"`
			AcctNoTail         string `json:"acctNoTial"`
			OpenBranch         string `json:"openBranch"`
			OpenOrgan          string `json:"openOrgan"`
			IDNo               string `json:"idNo"`
		} `json:"list"`
		CusIDNo      string `json:"cusIdNo"`
		CusIDNoMask  string `json:"cusIdNoMask"`
		AcctCategory string `json:"acctCategory"`
	} `json:"data"`
}

func (res *getAccountsByURLRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryBalanceRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		List []struct {
			AccountIndex  int     `json:"accountIndex"`
			UsableBalance float64 `json:"usableBalance"`
			Balance       float64 `json:"balance"`
			CurrencyType  string  `json:"currencyType"`
			CurrencyName  string  `json:"currencyName"`
			BusinessName  string  `json:"businessName"`
		} `json:"list"`
	} `json:"data"`
}

func (res *queryBalanceRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryTransListByPageRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		ListSize    int    `json:"listSize"`
		ExceedLimit string `json:"exceedLimit"`
		IsEnd       bool   `json:"isEnd"`
		TransList   []struct {
			TradeDate      string  `json:"tradeDate"`
			PayWay         string  `json:"payWay"`
			OtherOwnerName string  `json:"otherOwnerName"`
			TransAmount    float64 `json:"transAmount"`
			SummaryCode    string  `json:"summaryCode"`
			SummaryName    string  `json:"summaryName"`
			Channel        string  `json:"channel"`
			ChannelDesc    string  `json:"channelDesc"`
			OtherAcctNo    string  `json:"otherAcctNo"`
			OtherBank      string  `json:"otherBank"`
			TradeTime      string  `json:"tradeTime"`
			BookDate       string  `json:"bookDate"`
			Usage          string  `json:"usage"`
			Balance        float64 `json:"balance"`
		} `json:"transList"`
	} `json:"data"`
}

func (res *queryTransListByPageRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type getFrmsNoRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		FrmsNo string `json:"frmsNo"`
	} `json:"data"`
}

func (res *getFrmsNoRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type selectCardRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		AccountIndex      int     `json:"accountIndex"`
		CurAmount         float64 `json:"curAmount"`
		XYHBBalance       float64 `json:"xyhbBalance"`
		XYHBUseBalance    float64 `json:"xyhbUseBalance"`
		DCZLBalance       float64 `json:"dczlBalance"`
		DCZLUseBalance    float64 `json:"dczlUseBalance"`
		IsOld             int     `json:"isOld"`
		TransferFlag      int     `json:"transferFlag"`
		BoundAccountIndex int     `json:"boundAccountIndex"`
		HasBoundAcctList  int     `json:"hasBoundAcctList"`
		BoundAcctList     []struct {
		} `json:"boundAcctList"`
	} `json:"data"`
}

func (res *selectCardRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type getBankByCardNoRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		BankName   string `json:"bankName"`
		BankCode   string `json:"bankCode"`
		ToRtBankNo string `json:"toRtBankNo"`
	}
}

func (res *getBankByCardNoRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type canSuperTransferRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Result       int    `json:"result"`
		ResultDesc   string `json:"resultDesc"`
		ToRtBankNo   string `json:"toRtBankNo"`
		ToRtBankName string `json:"toRtBankName"`
	} `json:"data"`
}

func (res *canSuperTransferRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type cussentAccountQueryRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		AccListSize int `json:"accListSize"`
		List        []struct {
			CussentID        int    `json:"cussentId"`
			AccNo            string `json:"accNo"`
			AccName          string `json:"accName"`
			AccAlias         string `json:"accAlias"`
			AccType          string `json:"accType"`
			BankName         string `json:"bankName"`
			BankCode         string `json:"bankCode"`
			Telephone        string `json:"telephone"`
			Phoneticize      string `json:"phoneticize"`
			AliasPhoneticize string `json:"aliasPhoneticize"`
			ToBranchCityCode string `json:"toBranchCityCode"`
			ToNativeBankNo   string `json:"toNativeBankNo"`
			ToNativeBankName string `json:"toNativeBankName"`
			ToRtBankNo       string `json:"toRtBankNo"`
			ToRtBankName     string `json:"toRtBankName"`
		} `json:"list"`
		Result string `json:"result"`
		Desc   string `json:"desc"`
	} `json:"data"`
}

func (res *cussentAccountQueryRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type transferNextStepRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		FrmsNo           string `json:"frmsNo"`
		Result           int    `json:"result"`
		ResultDesc       string `json:"resultDesc"`
		SameNameTransfer int    `json:"sameNameTransfer"`
	} `json:"data"`
}

func (res *transferNextStepRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryAcclmtRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		AccountIndex       int     `json:"accountIndex"`
		MoneyLimitYear     float64 `json:"moneyLimitYear"`
		MoneyLimitYearLeft float64 `json:"moneyLimitYearLeft"`
		MoneyLimitDay      float64 `json:"moneyLimitDay"`
		MoneyLimitDayLeft  float64 `json:"moneyLimitDayLeft"`
		PayLimitDay        int     `json:"payLimitDay"`
		PayLimitDayLeft    int     `json:"payLimitDayLeft"`
	} `json:"data"`
}

func (res *queryAcclmtRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryRemarksRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		List []string `json:"list"`
	} `json:"data"`
}

func (res *queryRemarksRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type todayToTaCountRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		TodayCount      int     `json:"todayCount"`
		TodayTransMoney float64 `json:"todayTransMoney"`
	} `json:"data"`
}

func (res *todayToTaCountRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type beforeTransferRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		FrmsNo            string  `json:"frmsNo"`
		Fee               float64 `json:"fee"`
		MoreThanThreehths int     `json:"moreThanThreeths"`
	} `json:"data"`
}

func (res *beforeTransferRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type queryFrmsSignRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Result string `json:"result"`
	} `json:"data"`
}

func (res *queryFrmsSignRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type confirmTransferRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		FrmsNo       string `json:"frmsNo"`
		FrmsCompages string `json:"frmsCompages"`
	} `json:"data"`
}

func (res *confirmTransferRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type sendSMSCodeRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Result        int    `json:"result"`
		ResultDesc    string `json:"resultDesc"`
		Seqence       string `json:"seqence"`
		MobileTailNum string `json:"mobileTailNum"`
	} `json:"data"`
}

func (res *sendSMSCodeRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type checkFaceRecognitionRes struct {
	Status int `json:"status"`
	Data   struct {
		Result     int    `json:"result"`
		ResultDesc string `json:"resultDesc"`
		Similarity string `json:"similarity"`
	}
}

type verifySMSCodeRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Result     int    `json:"result"`
		ResultDesc string `json:"ResultDesc"`
		ErrorNum   int    `json:"errorNum"`
	} `json:"data"`
}

func (res *verifySMSCodeRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type verifyPwdRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		Result     int    `json:"result"`
		ResultDesc string `json:"resultDesc"`
		ErrorNum   int    `json:"errorNum"`
	} `json:"data"`
}

func (res *verifyPwdRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type doTransferRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		TransferNo string  `json:"transferNo"`
		Amount     float64 `json:"amount"`
		ToAcctName string  `json:"toAcctName"`
		ToAcctNo   string  `json:"toAcctNo"`
		ToBankName string  `json:"toBankName"`
		TranTime   string  `json:"tranTime"`
		TodayCount int     `json:"todayCount"`
		//TodayTransMoney
		Fee float64 `json:"fee"`
		//Memo
		FromAcctNoIndex int    `json:"fromAcctNoIndex"`
		FrmAcctName     string `json:"fromAcctName"`
		CussentID       int    `json:"cussentId"`
		SaveOrUpdate    string `json:"saveOrUpdate"`
		TransUsage      string `json:"transUsage"`
	} `json:"data"`
}

func (res *doTransferRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}

type realtimeTransferResultRes struct {
	Status int `json:"status"`
	Error  err `json:"error"`
	Data   struct {
		DealStatus string `json:"dealStatus"`
		DealTime   string `json:"dealTime"`
		RejectInfo string `json:"rejectInfo"`
	} `json:"data"`
}

func (res *realtimeTransferResultRes) getErrMsg() string {
	if res.Status != 200 {
		if res.Status == 500 {
			return fmt.Sprintf("信息: %s", res.Error.Msg)
		}

		return fmt.Sprintf("代码: %d", res.Status)
	}

	return ""
}
