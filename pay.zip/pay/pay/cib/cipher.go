package cib

import (
	"crypto/rsa"
	"fmt"
	"io/ioutil"
	"math/big"
	"pay/utils"
	"strings"

	random "math/rand"

	"github.com/tjfoc/gmsm/sm2"

	"golang.org/x/text/encoding/charmap"
	"golang.org/x/text/transform"
)

// UTF8ToISO8859_1 utf8转iso8859
func UTF8ToISO8859_1(str string) string {
	reader := transform.NewReader(strings.NewReader(str), charmap.ISO8859_1.NewDecoder())
	b, _ := ioutil.ReadAll(reader)
	return string(b)
}

// ISO8859_1ToUTF8 iso8859转utf8
func ISO8859_1ToUTF8(str string) (string, error) {
	reader := transform.NewReader(strings.NewReader(str), charmap.ISO8859_1.NewEncoder())
	b, err := ioutil.ReadAll(reader)
	return string(b), err
}

func randBytesStr(len int) string {
	result := ""
	for i := 0; i < len; i++ {
		result += fmt.Sprintf("%x", random.Intn(15))
	}

	return result
}

func rsaNoPadding(in []byte, pub *rsa.PublicKey) string {
	m := new(big.Int).SetBytes(in)
	c := new(big.Int)
	e := big.NewInt((int64)(pub.E))

	c.Exp(m, e, pub.N)

	return fmt.Sprintf("%x", c.Bytes())
}

func encAESKey(in []byte) string {
	pub := utils.PublicKeyFromBytes(rsaModulus, 65537)
	return rsaNoPadding(in, pub)
}

func encSM2(data []byte, x, y string) (string, error) {
	pub := new(sm2.PublicKey)
	pub.Curve = sm2.P256Sm2()
	pub.X, _ = new(big.Int).SetString(x, 16)
	pub.Y, _ = new(big.Int).SetString(y, 16)

	data, err := pub.Encrypt(data)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", data[1:]), nil
}
