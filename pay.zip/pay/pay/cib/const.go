package cib

const (
	cibAccountKey       = "CIBAccount"
	cibCookieKey        = "CIBCookie"
	timerUpdate         = 1000
	timerUpdateInterval = 5000
)

const (
	urlGeneratePost           = "https://bd.cib.com.cn:10010/public/generate/post"
	urlKeyHandle              = "https://z.cib.com.cn/api/secure/security/key/handle"
	urlKeepAlive              = "https://z.cib.com.cn/api/common/security/index/keepAlive"
	urlQueryUserByMisty       = "https://z.cib.com.cn/api/crm/login/login/queryUserByMisty"
	urlQueryUserByUniauthID   = "https://z.cib.com.cn/api/crm/login/login/queryUserByUniauthId"
	urlGetEncryptPK           = "https://z.cib.com.cn/api/common/encrypt/encrypt/getEncryptPK"
	urlComitLoginInfo         = "https://z.cib.com.cn/api/crm/login/login/comitLoginInfo"
	urlGetToken               = "https://z.cib.com.cn/api/common/token/token/token"
	urlCustLogin              = "https://z.cib.com.cn/api/crm/login/login/custLogin"
	urlGetAccountsByURL       = "https://z.cib.com.cn/api/query/account/accountQuery/getAccountsByUrl"
	urlQueryBalance           = "https://z.cib.com.cn/api/query/account/accountQuery/queryBalance"
	urlQueryTransListByPage   = "https://z.cib.com.cn/api/query/account/accountAsset/queryTransListByPage"
	urlGetFrmsNo              = "https://z.cib.com.cn/api/common/frms/frms/getFrmsNo"
	urlSelectCard             = "https://z.cib.com.cn/api/payment/common/query/selectCard"
	urlGetBankByCardNo        = "https://z.cib.com.cn/api/payment/bank/transferBank/getBankByCardNo"
	urlCanSuperTransfer       = "https://z.cib.com.cn/api/payment/bank/transferBank/canSuperTransfer"
	urlCussentAccountQuery    = "https://z.cib.com.cn/api/payment/account/cussentAccount/query"
	urlTransferNextStep       = "https://z.cib.com.cn/api/payment/transfer/transfer/transferNextStep"
	urlQueryAcclmt            = "https://z.cib.com.cn/api/payment/common/query/acclmt"
	urlQueryRemarks           = "https://z.cib.com.cn/api/payment/common/query/remarks"
	urlTodayToTaCount         = "https://z.cib.com.cn/api/payment/common/query/todayToTaCount"
	urlBeforeTransfer         = "https://z.cib.com.cn/api/payment/transfer/transfer/beforeTransfer"
	urlQueryFrmsSign          = "https://z.cib.com.cn/api/common/frms/frms/queryFrmsSign"
	urlConfirmTransfer        = "https://z.cib.com.cn/api/payment/transfer/transfer/confirmTransfer"
	urlCheckFaceRecognition   = "https://z.cib.com.cn/api/common/frms/frms/checkFaceRecognition"
	urlSendSMSCode            = "https://z.cib.com.cn/api/common/frms/frms/sendSmsCode"
	urlVerifySMSCode          = "https://z.cib.com.cn/api/common/frms/frms/verifySmsCode"
	urlVerifyPwd              = "https://z.cib.com.cn/api/common/frms/frms/verifyPwd"
	urlDoTransfer             = "https://z.cib.com.cn/api/payment/transfer/transfer/doTransfer"
	urlRealtimeTransferResult = "https://z.cib.com.cn/api/payment/common/query/realtimeTransferResult"
)

const (
	cfBundleShortVersion = "5.0.4"
	cfBundleVersion      = "5.0.0.0"
	sdkVersion           = "4.1.1"
	resVersion           = "4.0"
	appName              = "cib"
	pkgName              = "com.cib.cibmb"
	devicePublicKey      = "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCka79VOg7uxOSUU98nN6I7LTO+\neWb7EU67R61Kdu8izf0Y2h1P9XeeUDRm2/jJjts3JGM56zvyx4HdSd1fFmxH3CTw\n06DxhTW6iLZKeodKivqoB7H0ddfMFLbmBSPYl9Pn6XFLnJz3G4nixkDnnxFveSZs\nb9U6bin+txVt8kZYWQIDAQAB\n-----END PUBLIC KEY-----\n"
	checkFaceKey         = "E256744EFC699C84"
)

var (
	rsaModulus = []byte{
		0xB9, 0xF7, 0x97, 0xBD, 0xD6, 0xAF, 0x8D, 0x26, 0x51, 0x7C, 0x20, 0xD1, 0x0F, 0x0D, 0x1E, 0xFF,
		0xC7, 0x0D, 0xAC, 0xE8, 0x4D, 0x82, 0x53, 0x13, 0x4A, 0xF5, 0xAD, 0x3A, 0x8D, 0xCC, 0xAF, 0x37,
		0x32, 0x3B, 0x90, 0x91, 0x08, 0xC0, 0xBC, 0x26, 0xD9, 0xED, 0x08, 0xAC, 0x6E, 0x02, 0x7A, 0xDE,
		0x1E, 0xF9, 0xCA, 0x73, 0x12, 0x53, 0x24, 0xF8, 0x86, 0x0A, 0x34, 0xC2, 0xE0, 0x44, 0x8C, 0x9D,
		0x8B, 0x8C, 0xCD, 0xB8, 0x52, 0x24, 0x1C, 0x0C, 0xBF, 0x73, 0x68, 0x48, 0x1E, 0x12, 0x2E, 0xE4,
		0xB7, 0x0C, 0x38, 0x02, 0x9C, 0x42, 0x41, 0xBA, 0xE9, 0xBF, 0x5F, 0x78, 0x69, 0xBD, 0xC4, 0x9E,
		0x7B, 0xBF, 0xE7, 0x10, 0x30, 0xBF, 0x02, 0xA9, 0x0F, 0x9C, 0xB5, 0xE6, 0xE4, 0xB7, 0xE9, 0x04,
		0xDE, 0xE3, 0xA6, 0x88, 0xA5, 0x8A, 0x61, 0x93, 0x2A, 0x30, 0x47, 0xFC, 0xDC, 0x5C, 0x52, 0xF7,
	}
)
