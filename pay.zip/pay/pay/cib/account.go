package cib

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/faceimagemgr"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/service/notify"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strings"
	"sync/atomic"
	"time"
)

// Account 兴业银行帐号
type Account struct {
	Account               string          `json:"account"`
	Password              string          `json:"password"`
	PayPassword           string          `json:"payPassword"`
	Platform              string          `json:"platform"`
	FirstLogin            bool            `json:"firstLogin"`
	UUID                  string          `json:"uuid"`
	HandleID              string          `json:"handleId"`
	DeviceID              string          `json:"deviceID"`
	IDFV                  string          `json:"idfv"`
	DFP                   string          `json:"dfp"`
	DFPExpire             string          `json:"dfpExp"`
	UniauthID             string          `json:"uniAuthId"`
	CardNo                string          `json:"cardNo"`
	Proxy                 utils.ProxyInfo `json:"proxy"`
	HardwareInfo          HardwareInfo    `json:"hardwareInfo"`
	http                  *http.Client
	jar                   *cookiejar.Jar
	aesKey                string
	rsaPublicKey          string
	sm2KeyX               string
	sm2KeyY               string
	token                 string
	accountIndex          int
	startTime             string
	loginStatus           int32
	loginPadding          int32
	lastPing              int64
	transferFrmsNo        string
	transferOrderNo       string
	transferTargetAccount string
	transferTargetName    string
	transferAmount        string
	transferComment       string
	loginFailCount        int
	payPasswordFailCount  int
	smscodeFailCount      int
	faceImages            []faceimagemgr.FaceImageInfo
}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	SystemVersion        string `json:"systemVersion"`        // 系统版本
	WIFIName             string `json:"wifiName"`             // wifi名字
	WIFIMac              string `json:"wifiMac"`              // wifiMac地址
	Model                string `json:"model"`                // 设备类型
	DeviceName           string `json:"deviceName"`           // 设备的名字
	ScreenSize           string `json:"screenSize"`           // 分辨率
	Carrier              string `json:"carrier"`              // 运营商
	AvailableSystemSpace string `json:"availableSystemSpace"` // 可用穷疯
	TotalSystemSpace     string `json:"totalSystemSpace"`     // 总空间
	TotalMemory          string `json:"totalMemory"`          // 内存
	CellularIP           string `json:"cellularIP"`           // ip地址
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case common.PlatformNameIOS, common.PlatformNameAndroid:
	default:
		{
			logger.Errorf("[CIB]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(cibAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(cibAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.loadFaceImages()
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			return acc, nil
		}

		logger.Errorf("[CIB]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	acc.UUID, _ = utils.NewUUID(true)
	acc.HandleID, _ = utils.NewUUID(true)
	acc.DeviceID, _ = acc.getDeviceID()
	acc.newHardwareInfo(platform)

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CIB]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.loadFaceImages()
	acc.jar, _ = cookiejar.New(nil)
	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

func (acc *Account) getDeviceID() (string, error) {
	block, _ := pem.Decode([]byte(devicePublicKey))
	publicKeyInterface, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		logger.Errorf("[CIB]getDeviceID解释公钥数据错误: %+v.", err)
		return "", err
	}
	//类型断言
	publicKey := publicKeyInterface.(*rsa.PublicKey)
	cipherText, err := rsa.EncryptPKCS1v15(rand.Reader, publicKey, []byte(acc.UUID))
	if err != nil {
		logger.Errorf("[CIB]getDeviceID加密uuid错误: %+v.", err)
		return "", err
	}
	return base64.StdEncoding.EncodeToString(cipherText), nil
}

func (acc *Account) getDeviceIDBase64() string {
	return base64.StdEncoding.EncodeToString([]byte(url.PathEscape(acc.DeviceID)))
}

func (acc *Account) getHandleID() string {
	if acc.startTime == "" {
		acc.startTime = fmt.Sprintf("%sSSS", time.Now().Format("20060102150405"))
	}

	return acc.HandleID + acc.startTime
}

func (acc *Account) newHardwareInfo(platform string) {
	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.Carrier = utils.NewCarrierName()
	h.CellularIP = utils.NewLocalIPAddress()

	if platform == common.PlatformNameIOS {
		h.SystemVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()
		h.AvailableSystemSpace = fmt.Sprintf("%d", 21249343488+utils.RandInt(1000000, 9999999))
		h.TotalSystemSpace = "31989469184"
		h.TotalMemory = "2099249152"

	} else if platform == common.PlatformNameAndroid {

	}
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(cibAccountKey, field)
	if err != nil {
		logger.Errorf("[CIB]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[CIB]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[CIB]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(cibAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[CIB]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) loadFaceImages() error {
	images, err := api.AccountGetFaceImages(acc.Account, acc.Platform, common.AccountTypeCIB, true)
	if err != nil {
		logger.Errorf("[CIB][%+v]获取刷脸数据错误: %+v.", acc.Account, err)
		return err
	}

	acc.faceImages = []faceimagemgr.FaceImageInfo{}
	for _, item := range images.List {
		if err := faceimagemgr.SaveFaceImage(acc.Account, item.Hash, item.Data); err == nil {
			acc.faceImages = append(acc.faceImages, faceimagemgr.FaceImageInfo{
				Hash: item.Hash,
				Type: item.Type,
			})

			logger.Infof("[CIB][%+v]加载刷脸图片成功, hash: %+v, 类型: %+v.", acc.Account, item.Hash, item.Type)
		} else {
			logger.Errorf("[CIB][%+v]保存刷脸图片数据错误, hash: %+v, 类型: %+v, 错误: %+v.",
				acc.Account, item.Hash, item.Type, err)
		}
	}

	return nil
}

func (acc *Account) deleteFaceImage(idx int) {
	images := []faceimagemgr.FaceImageInfo{}
	for i := 0; i < len(acc.faceImages); i++ {
		if i == idx {
			continue
		}

		images = append(images, acc.faceImages[i])
	}

	acc.faceImages = images
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCIB)
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCIB)
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCIB, code, reason)
}

func (acc *Account) checkOnline(ts int64) {
	if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 120 {
		res, err := acc.keepAlive()
		if err != nil {
			logger.Errorf("[CIB][%+v]keepAlive检测错误: %+v.", acc.Account, err)
			return
		}

		if res.Status != 200 {
			logger.Errorf("[CIB][%+v]keepAlive检测失败, 代码: %+v.", acc.Account, res.Status)
			return
		}

		if !res.Data.IsLogin {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CIB][%+v]重登录帐号失败: %+v.", acc.Account, err)
			}
		}

		acc.lastPing = ts
	}
}

func (acc *Account) selectCardNo() error {
	for i := 0; i < 3; i++ {
		res, err := acc.getAccountsByURL()
		if err != nil {
			continue
		}

		if len(res.Data.List) <= 0 {
			return pay.ErrNoHaveCardList
		}

		// 未设置卡号选择
		if acc.CardNo == "" {
			index := -1
			cardMask := ""
			cardTail := ""
			for _, v := range res.Data.List {
				// 非储蓄卡
				if v.AccountType != 1 {
					continue
				}

				// 主帐户
				if v.BelongLevel == "M" {
					index = v.AccountIndex
					cardMask = v.AccountNoMask
					cardTail = v.AcctNoTail
				}

				// I类卡
				if v.AcctCategory == "1" {
					index = v.AccountIndex
					cardMask = v.AccountNoMask
					cardTail = v.AcctNoTail
					break
				}
			}

			if index != -1 {
				acc.accountIndex = index
				logger.Infof("[CIB][%+v]未指定银行卡号, 默认选择卡号: %s(%s).", acc.Account, cardMask, cardTail)
				return nil
			}

			logger.Errorf("[CIB][%+v]未指定卡号但无法找到可用卡号.", acc.Account)
			return pay.ErrNoHaveCardList
		}

		// 设置卡号选择
		for _, v := range res.Data.List {
			if v.AccountType != 1 {
				continue
			}

			// 找到
			if strings.HasSuffix(strings.TrimSpace(acc.CardNo), v.AcctNoTail) {
				acc.accountIndex = v.AccountIndex
				logger.Infof("[CIB][%+v]选定指定银行卡号, 卡号: %s, 序号: %d.", acc.Account, acc.CardNo, v.AccountIndex)
				return nil
			}
		}

		logger.Errorf("[CIB][%+v]没有找到指定的银行卡号: %s.", acc.Account, acc.CardNo)
		return fmt.Errorf("没有找到指定的银行卡号: %s", acc.CardNo)
	}

	return errors.New("获取帐号银行卡列表失败")
}

func (acc *Account) doRelogin() error {
	acc.jar, _ = cookiejar.New(nil)
	acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)

	key, err := acc.keyHandle()
	if err != nil {
		return err
	}

	if key.Status != 200 {
		return errors.New(key.Error.Msg)
	}

	authID, err := acc.queryUserByUniauthID()
	if err != nil {
		return err
	}

	if authID.Status != 200 {
		return errors.New(authID.Error.Msg)
	}

	pk, err := acc.getEncryptPK()
	if err != nil {
		return err
	}

	if pk.Status != 200 {
		return errors.New(pk.Error.Msg)
	}

	acc.rsaPublicKey = pk.Data.RSAPublicKey
	acc.sm2KeyX = pk.Data.SM2PublicKeyX
	acc.sm2KeyY = pk.Data.SM2PublicKeyY

	comitLogin, err := acc.comitLoginInfo()
	if err != nil {
		return err
	}

	if comitLogin.Status != 200 {
		return errors.New(comitLogin.Error.Msg)
	}

	token, err := acc.getToken()
	if err != nil {
		return err
	}

	if token.Status != 200 {
		return errors.New(token.Error.Msg)
	}

	acc.token = token.Data.Token

	custLogin, err := acc.custLogin()
	if err != nil {
		return err
	}

	if custLogin.Status == 200 {
		acc.loginFailCount = 0

		return nil
	} else if custLogin.Status == 500 {
		logger.Errorf("[CIB][%+v]用户重登录失败, 信息: %+v.", acc.Account, custLogin.Error.Msg)
		// 密码错误
		if strings.Contains(custLogin.Error.Msg, "登录密码有误") {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCIB)

			acc.loginFailCount++
			if acc.loginFailCount >= 3 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[CIB][%+v]帐号连续连续三次登录错误, 临时冻结帐号.", acc.Account)
			}
		}

		// 风控
		if strings.Contains(custLogin.Error.Msg, "统一用户被锁定") {
			acc.freeze(pay.ErrCodeAccountRisk, "用户被锁定")
			logger.Errorf("[CIB][%+v]登录失败, 帐号被锁定.", acc.Account)
			return errors.New("帐号被锁定, 暂时无法进行登录")
		}

		return errors.New(custLogin.Error.Msg)
	} else {
		return fmt.Errorf("用户登录失败, 代码: %+v", custLogin.Status)
	}
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	// case pay.LoginStatusWaitCode:
	// 	logger.Infof("[CIB][%+v]等待验证码登录.", acc.Account)
	// 	return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	case pay.LoginStatusSuccess:
		logger.Infof("[CIB][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[CIB][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[CIB][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	_, err := acc.generatePost()
	if err != nil {
		logger.Errorf("[CIB][%+v]获取设备指纹信息错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	logger.Infof("[CIB][%+v]获取设备指纹信息成功.", acc.Account)

	key, err := acc.keyHandle()
	if err != nil {
		logger.Errorf("[CIB][%+v]交换加密密钥错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if key.Status != 200 {
		msg := fmt.Sprintf("交换加密密钥失败, %+v", key.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)

		return pay.Error(pay.ErrCodeLoginError, key.Error.Msg, nil)
	}

	logger.Infof("[CIB][%+v]交换加密密钥成功.", acc.Account)

	if acc.UniauthID == "" {
		res, err := acc.queryUserByMisty()
		if err != nil {
			logger.Errorf("[CIB][%+v]获取用户UniauthId错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if res.Status != 200 {
			msg := fmt.Sprintf("获取用户UniauthId失败, %+v", res.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)

			return pay.Error(pay.ErrCodeLoginError, res.Error.Msg, nil)
		}

		acc.UniauthID = res.Data.CustList[0].UniauthID
		acc.save()

		logger.Infof("[CIB][%+v]获取用户UniauthId成功, UniauthId: %+v.", acc.Account, acc.UniauthID)

	} else {
		res, err := acc.queryUserByUniauthID()
		if err != nil {
			logger.Errorf("[CIB][%+v]查询用户UniauthId错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), err)
		}

		if res.Status != 200 {
			msg := fmt.Sprintf("查询用户UniauthId失败, %+v", res.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)

			return pay.Error(pay.ErrCodeLoginError, res.Error.Msg, nil)
		}
	}

	pk, err := acc.getEncryptPK()
	if err != nil {
		logger.Errorf("[CIB][%+v]获取加密公钥错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if pk.Status != 200 {
		msg := fmt.Sprintf("获取加密公钥失败, %+v", pk.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)

		return pay.Error(pay.ErrCodeLoginError, pk.Error.Msg, nil)
	}

	acc.rsaPublicKey = pk.Data.RSAPublicKey
	acc.sm2KeyX = pk.Data.SM2PublicKeyX
	acc.sm2KeyY = pk.Data.SM2PublicKeyY

	logger.Infof("[CIB][%+v]获取加密公钥成功.", acc.Account)

	comitLogin, err := acc.comitLoginInfo()
	if err != nil {
		logger.Errorf("[CIB][%+v]提交登录信息错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if comitLogin.Status != 200 {
		msg := fmt.Sprintf("提交登录信息失败, %+v", comitLogin.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)

		return pay.Error(pay.ErrCodeLoginError, comitLogin.Error.Msg, nil)
	}

	token, err := acc.getToken()
	if err != nil {
		logger.Errorf("[CIB][%+v]获取token错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if token.Status != 200 {
		msg := fmt.Sprintf("获取token失败, %+v", token.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeLoginError, token.Error.Msg, nil)
	}

	acc.token = token.Data.Token

	custLogin, err := acc.custLogin()
	if err != nil {
		logger.Errorf("[CIB][%+v]用户登录错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if custLogin.Status == 200 {
		if err := acc.selectCardNo(); err != nil {
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.onLoginSuccess()

		logger.Infof("[CIB][%+v]登录成功.", acc.Account)
		return pay.Success(nil)
	} else if custLogin.Status == 500 {
		logger.Errorf("[CIB][%+v]用户登录失败, 信息: %+v.", acc.Account, custLogin.Error.Msg)
		pay.DelLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCIB)

		// 密码错误
		if strings.Contains(custLogin.Error.Msg, "登录密码有误") {
			api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCIB)

			logger.Errorf("[CIB][%+v]登录失败, 帐号或密码错误.", acc.Account)
			return pay.Error(pay.ErrCodeInvalidIDPWD, pay.ErrMsgInvalidIDPWD, nil)
		}

		// 风控
		if strings.Contains(custLogin.Error.Msg, "统一用户被锁定") {
			acc.freeze(pay.FreezeCodeAccountRisk, "用户被锁定")
			logger.Errorf("[CIB][%+v]登录失败, 帐号被锁定.", acc.Account)

			return pay.Error(pay.ErrCodeAccountRisk, "帐号被锁定, 暂时无法进行登录", nil)
		}

		return pay.Error(pay.ErrCodeLoginError, custLogin.Error.Msg, nil)
	} else {
		logger.Errorf("[CIB][%+v]未知登录错误, 代码: %+v.", acc.Account, custLogin.Status)
		return pay.Error(pay.ErrCodeLoginError, fmt.Sprintf("未知登录错误, 代码: %+v", custLogin.Status), nil)
	}
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypeCIB)

	logger.Infof("[CIB][%+v]退出成功.", acc.Account)
	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[CIB][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[CIB][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusSuccess && acc.transferFrmsNo != "" {
		// 转帐验证码
		res, err := acc.sendSMSCode(acc.transferFrmsNo)
		if err != nil {
			logger.Errorf("[CIB][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if res.Status != 200 {
			msg := fmt.Sprintf("发送转帐验证码失败, %+v", res.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeSendCodeError, res.Error.Msg, nil)
		}

		if res.Data.Result != 1 {
			logger.Errorf("[CIB][%+v]发送转帐验证码失败, 代码: %+v, 信息: %+v.", acc.Account, res.Data.Result, res.Data.ResultDesc)
			return pay.Error(pay.ErrCodeSendCodeError, res.Data.ResultDesc, nil)
		}

		logger.Infof("[CIB][%+v]发送转帐验证码成功.", acc.Account)

	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)

	return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CIB][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CIB][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	balance, err := acc.queryBalance()
	if err != nil {
		logger.Errorf("[CIB][%+v]查询余额错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.Status != 200 {
		logger.Errorf("[CIB][%+v]查询余额失败, 信息: %+v.", acc.Account, balance.Error.Msg)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.Error.Msg, nil)
	}

	res := model.AccountBalanceRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess

	if len(balance.Data.List) > 0 {
		res.Data.Amount = fmt.Sprintf("%.2f", balance.Data.List[0].Balance)
		res.Data.AmountAvailable = fmt.Sprintf("%.2f", balance.Data.List[0].UsableBalance)
	}

	return pay.Success(&res)
}

// datetimeConver 把yyyyMMddhhmmss转换成yyyy-MM-dd hh:mm:ss
func datetimeConver(dt string) string {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return dt
	}

	return time.Unix(tmp.Unix(), 0).Format("2006-01-02 15:04:05")
}

// dateTimeToUnix时间字符串转成unix时间戳
func dateTimeToUnix(dt string) int {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return 0
	}

	return int(tmp.Unix())
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CIB][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[CIB][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 0

	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}

	for {
		billList, err := acc.queryTransListByPage(startDate, endDate, page+1)
		if err != nil {
			logger.Errorf("[CIB][%+v]查询帐单错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
		}

		if billList.Status != 200 {
			if len(res.Data) == 0 {
				logger.Errorf("[CIB][%+v]查询帐单失败: %+v.", acc.Account, billList.Error.Msg)
				return pay.Error(pay.ErrCodeGetBillListError, billList.Error.Msg, nil)
			}

			break
		}

		if billList.Data.ListSize == 0 {
			break
		}

		exit := false
		for _, item := range billList.Data.TransList {
			// 时间查询判断条件
			if req.TimeType == common.TimeTypeByTime {
				ts := dateTimeToUnix(item.TradeTime)
				if ts == 0 || ts > req.EndTime {
					continue
				}

				if ts < req.StartTime {
					exit = true
					break
				}
			}

			info := model.AccountBillListInfo{
				TradeNo:        "",
				TradeTime:      datetimeConver(item.TradeTime),
				Amount:         fmt.Sprintf("%.2f", item.TransAmount),
				AmountRemain:   fmt.Sprintf("%.2f", item.Balance),
				TargetAccount:  item.OtherAcctNo,
				TargetName:     item.OtherOwnerName,
				TargetBankName: item.OtherBank,
				Comment:        item.Usage,
			}

			if item.PayWay == "0" {
				info.TradeType = "0"
			} else if item.PayWay == "1" {
				info.TradeType = "1"
			} else {
				logger.Errorf("[CIB][%+v]查询帐单出现未知的记帐方式: %+v.", acc.Account, item.PayWay)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if item.PayWay == "1" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if item.PayWay == "0" {
					res.Data = append(res.Data, info)
				}
			}
		}

		if exit {
			break
		}

		if billList.Data.IsEnd {
			break
		}

		page++

		if page > 20 {
			break
		}
	}

	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CIB][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[CIB][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	if req.SMSCode == "" {
		token, err := acc.getToken()
		if err != nil {
			logger.Errorf("[CIB][%+v]获取转帐token错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if token.Status != 200 {
			msg := fmt.Sprintf("获取转帐token失败, %+v", token.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, token.Error.Msg, nil)
		}

		acc.token = token.Data.Token

		frmsNo, err := acc.getFrmsNo()
		if err != nil {
			logger.Errorf("[CIB][%+v]生成转帐订单号错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if frmsNo.Status != 200 {
			msg := fmt.Sprintf("生成转帐订单号失败, %+v", frmsNo.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, frmsNo.Error.Msg, nil)
		}

		tradeNo := frmsNo.Data.FrmsNo

		selectCard, err := acc.selectCard(tradeNo)
		if err != nil {
			logger.Errorf("[CIB][%+v]选择支付卡号错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if selectCard.Status != 200 {
			logger.Errorf("[CIB][%+v]选择支付卡号失败: %+v.", acc.Account, selectCard.Error.Msg)
			if strings.Contains(selectCard.Error.Msg, "状态异常") {
				acc.freeze(pay.FreezeCodeCardError, selectCard.Error.Msg)
				return pay.Error(pay.ErrCodeCardBlock, selectCard.Error.Msg, nil)
			}

			return pay.Error(pay.ErrCodeTransferError, selectCard.Error.Msg, nil)
		}

		bankInfo, err := acc.getBankByCardNo(req.TargetAccount)
		if err != nil {
			logger.Errorf("[CIB][%+v]查询目标银行信息错误: %+v.", acc.Account)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if bankInfo.Status != 200 {
			msg := fmt.Sprintf("查询目标银行信息失败, %+v", bankInfo.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, bankInfo.Error.Msg, nil)
		}

		bankCode := bankInfo.Data.BankCode
		bankNo := bankInfo.Data.ToRtBankNo
		bankName := bankInfo.Data.BankName

		if bankCode != "309" {
			if bankCode == "" || bankNo == "" || bankName == "" {
				logger.Warnf("[CIB][%+v]查询到暂不支持的银行, 卡号: %+v, 银行名字: %+v, BankCode: %+v, BankNo: %+v.",
					acc.Account, req.TargetAccount, bankName, bankCode, bankNo)
				return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
			}
		}

		superTransfer, err := acc.canSuperTransfer(bankCode)
		if err != nil {
			logger.Errorf("[CIB][%+v]查询是否支持快速转帐错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if superTransfer.Status != 200 {
			msg := fmt.Sprintf("查询是否支持快速转帐失败, %+v", superTransfer.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, superTransfer.Error.Msg, nil)
		}

		nextStep, err := acc.transferNextStep(
			tradeNo,
			req.TargetAccount,
			req.TargetName,
			bankCode,
			bankNo,
			bankName)
		if err != nil {
			logger.Errorf("[CIB][%+v]转帐下一步操作错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if nextStep.Status != 200 {
			msg := fmt.Sprintf("转帐下一步操作失败, %+v", nextStep.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, nextStep.Error.Msg, nil)
		}

		if nextStep.Data.Result != 1 {
			msg := fmt.Sprintf("转帐一下操作返回异常, 信息: %+v", nextStep.Data.ResultDesc)
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, nextStep.Data.ResultDesc, nil)
		}

		accLimit, err := acc.queryAcclmt()
		if err != nil {
			logger.Errorf("[CIB][%+v]查询用户限额信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if accLimit.Status != 200 {
			msg := fmt.Sprintf("查询用户限额信息失败, %+v", accLimit.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, accLimit.Error.Msg, nil)
		}

		today, err := acc.todayToTaCount(req.TargetAccount)
		if err != nil {
			logger.Errorf("[CIB][%+v]查询当天转帐信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if today.Status != 200 {
			msg := fmt.Sprintf("查询当天转帐信息失败, %+v", today.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, today.Error.Msg, nil)
		}

		before, err := acc.beforeTransfer(tradeNo, req.Amount, bankNo, bankName, req.Comment)
		if err != nil {
			logger.Errorf("[CIB][%+v]提交转帐信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if before.Status != 200 {
			msg := fmt.Sprintf("提交转帐信息失败, %+v", before.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, before.Error.Msg, nil)
		}

		frmsSign, err := acc.queryFrmsSign()
		if err != nil {
			logger.Errorf("[CIB][%+v]查询订单签名错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if frmsSign.Status != 200 {
			msg := fmt.Sprintf("查询订单签名失败， %+v", frmsSign.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, frmsSign.Error.Msg, nil)
		}

		confirm, err := acc.confirmTransfer(tradeNo)
		if err != nil {
			logger.Errorf("[CIB][%+v]确认转帐信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if confirm.Status != 200 {
			msg := fmt.Sprintf("确认转帐信息失败, %+v", confirm.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, confirm.Error.Msg, nil)
		}

		compages := confirm.Data.FrmsCompages
		if compages == "2" || compages == "29" {
			// 正常短信模式
			logger.Infof("[CIB][%+v]普通短信验证模式.", acc.Account)
		} else if compages == "62" || compages == "629" {
			// 刷脸模式
			logger.Infof("[CIB][%+v]刷脸验证模式.", acc.Account)

			// 尝试三次
			faceImageSuccess := false
			for i := 0; i < 3; i++ {
				time.Sleep(time.Millisecond * 2000)
				cnt := len(acc.faceImages)
				if cnt <= 0 {
					logger.Infof("[CIB][%+v]没有找到刷脸图片数据.", acc.Account)
					return pay.Error(pay.ErrCodeTransferError, "没有找到刷脸图片数据", nil)
				}

				idx := utils.RandIntn(cnt)
				faceImageInfo := acc.faceImages[idx]
				faceData, err := faceimagemgr.LoadFaceImage(acc.Account, faceImageInfo.Hash)
				if err != nil {
					logger.Errorf("[CIB][%+v]加载刷脸图片数据错误, hash: %+v, 错误: %+v.",
						acc.Account, faceImageInfo.Hash, err)
					acc.deleteFaceImage(idx)
					continue
				}

				checkFace, err := acc.checkFaceRecognition(tradeNo, faceData)
				if err != nil {
					logger.Errorf("[CIB][%+v]刷脸操作错误, hash: %+v, 错误: %+v.",
						acc.Account, faceImageInfo.Hash, err)
					continue
				}

				if checkFace.Status != 200 {
					logger.Errorf("[CIB][%+v]刷脸操作返回失败, hash: %+v, 代码: %+v.",
						acc.Account, faceImageInfo.Hash, checkFace.Status)
					continue
				}

				if checkFace.Data.Result == 0 {
					logger.Errorf("[CIB][%+v]刷脸图片检测失败, hash: %+v, 相似度: %+v.",
						acc.Account, faceImageInfo.Hash, checkFace.Data.Similarity)
					acc.deleteFaceImage(idx)
					api.NodeFaceImageError(acc.Account, acc.Platform, common.AccountTypeCIB, faceImageInfo.Hash)
				} else if checkFace.Data.Result == 1 {
					logger.Infof("[CIB][%+v]刷脸图片检测成功, hash: %+v, 相似度: %+v.",
						acc.Account, faceImageInfo.Hash, checkFace.Data.Similarity)
					faceImageSuccess = true
					break
				} else {
					logger.Errorf("[CIB][%+v]刷脸图片检测未知状态, hash: %+v, 状态: %+v, 描述: %+v.",
						acc.Account, faceImageInfo.Hash, checkFace.Data.Result, checkFace.Data.ResultDesc)
				}
			}

			if !faceImageSuccess {
				logger.Errorf("[CIB][%+v]多次尝试刷脸操作失败.", acc.Account)
				return pay.Error(pay.ErrCodeTransferError, "多次尝试刷脸操作失败", nil)
			}
		} else {
			logger.Errorf("[CIB][%+v]出现未知的安全工具验证方式: %+v.", acc.Account, compages)
			// 其它未知的模式
			if strings.Contains(compages, "1") {
				return pay.Error(pay.ErrCodeTransferError, "需要动态令牌认证方式进行转帐", nil)
			} else if strings.Contains(compages, "5") {
				return pay.Error(pay.ErrCodeTransferError, "需要软令牌认证方式进行转帐", nil)
			}

			return pay.Error(pay.ErrCodeTransferError, fmt.Sprintf("未知的安全工具验证方式[%+v]", compages), nil)
		}

		code, err := acc.sendSMSCode(tradeNo)
		if err != nil {
			logger.Errorf("[CIB][%+v]发送支付验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if code.Status != 200 {
			msg := fmt.Sprintf("发送支付验证码失败, %+v", code.getErrMsg())
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, code.Error.Msg, nil)
		}

		if code.Data.Result != 1 {
			msg := fmt.Sprintf("发送支付验证码失败, 信息: %+v", code.Data.ResultDesc)
			logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
			return pay.Error(pay.ErrCodeTransferError, code.Data.ResultDesc, nil)
		}

		//
		acc.transferFrmsNo = tradeNo
		acc.transferOrderNo = req.OrderNo
		acc.transferAmount = req.Amount
		acc.transferTargetAccount = req.TargetAccount
		acc.transferTargetName = req.TargetName
		acc.transferComment = req.Comment

		logger.Infof("[CIB][%+v]发送转帐验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	if acc.transferFrmsNo == "" {
		logger.Warnf("[CIB][%+v]尚未生成支付订单.", acc.Account)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrNotCreateOrderNo.Error(), nil)
	}

	code, err := acc.verifySMSCode(acc.transferFrmsNo, req.SMSCode)
	if err != nil {
		logger.Errorf("[CIB][%+v]校验验证码错误: %+v.", err)
		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if code.Status != 200 {
		msg := fmt.Sprintf("校验验证码失败, %+v", code.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeTransferError, code.Error.Msg, nil)
	}

	if code.Data.Result != 1 {
		msg := fmt.Sprintf("校验验证码失败, 信息: %+v", code.Data.ResultDesc)
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		acc.smscodeFailCount++
		if acc.smscodeFailCount >= 3 {
			acc.smscodeFailCount = 0
			acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
			logger.Errorf("[CIB][%+v]转帐连续验证码错误, 临时冻结帐号.", acc.Account)
		}

		return pay.Error(pay.ErrCodeTransferError, code.Data.ResultDesc, nil)
	}

	acc.smscodeFailCount = 0

	pwd, err := acc.verifyPwd(acc.transferFrmsNo)
	if err != nil {
		logger.Errorf("[CIB][%+v]验证支付密码操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if pwd.Status != 200 {
		msg := fmt.Sprintf("验证支付密码失败, %+v", pwd.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeTransferError, msg, nil)
	}

	if pwd.Data.Result != 1 {
		msg := fmt.Sprintf("验证支付密码失败, 信息: %+v", pwd.Data.ResultDesc)
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		acc.payPasswordFailCount++
		if acc.payPasswordFailCount >= 3 {
			acc.payPasswordFailCount = 0
			acc.freeze(pay.FreezeCodePayPasswordError, pay.FreezeMsgPayPasswordError)
			logger.Errorf("[CIB][%+v]转帐连续支付密码错误, 冻结帐号.", acc.Account)
		}

		return pay.Error(pay.ErrCodeTransferError, msg, nil)
	}

	token, err := acc.getToken()
	if err != nil {
		logger.Errorf("[CIB][%+v]获取转帐确认token错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if token.Status != 200 {
		msg := fmt.Sprintf("获取转帐确认token失败, %+v", token.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeTransferError, token.Error.Msg, nil)
	}

	acc.token = token.Data.Token

	transfer, body, err := acc.doTransfer(acc.transferFrmsNo)
	if err != nil {
		logger.Errorf("[CIB][%+v]转帐确认错误: %+v.", acc.Account, err)

		// 网络超时不确定有没有完成转帐
		if err == pay.ErrOperationTimeout {
			return pay.Error(pay.ErrCodeTransferStatusUnknow, pay.ErrMsgTransferStatusUnknow, nil)
		}

		return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
	}

	if transfer.Status != 200 {
		msg := fmt.Sprintf("转帐确认失败, %+v", transfer.getErrMsg())
		logger.Errorf("[CIB][%+v]%+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeTransferError, msg, nil)
	}

	transferNo := transfer.Data.TransferNo
	status := common.TransferStatusProcessing
	if transfer.Data.ToBankName == "兴业银行" {
		status = common.TransferStatusSuccess
	} else {
		for i := 0; i < 5; i++ {
			time.Sleep(time.Second * 2)
			result, err := acc.realtimeTransferResult(transferNo)
			if err != nil {
				continue
			}

			if result.Status != 200 {
				logger.Errorf("[CIB][%+v]查询转帐状态失败, 流水号: %+v, %+v.", acc.Account, transferNo, result.getErrMsg())
				continue
			}

			// 未确定的
			if result.Data.DealStatus == "1" {
				logger.Infof("[CIB][%+v]查询转帐状态尚未确定, 流水号: %+v.", acc.Account, transferNo)
				continue
			}

			//确定成功
			if result.Data.DealStatus == "Y" {
				status = common.TransferStatusSuccess
				logger.Infof("[CIB][%+v]查询转帐状态成功, 流水号: %+v.", acc.Account, transferNo)
				break
			}

			// 确定失败
			if result.Data.DealStatus == "F" {
				status = common.TransferStatusFail
				logger.Infof("[CIB][%+v]查询转帐状态失败, 流水号: %+v, 信息: %+v.", acc.Account, transferNo, result.Data.RejectInfo)
				break
			}

			// 未知状态
			logger.Warnf("[CIB][%+v]未知的转帐状态, 流水号: %+v, 状态: %+v.", acc.Account, transferNo, result.Data.DealStatus)
		}
	}

	acc.transferFrmsNo = ""

	res := model.AccountTransferRes{}
	res.Code = pay.ErrCodeSuccess
	res.Msg = pay.ErrMsgSuccess
	res.ExtData = req.ExtData
	res.Status = status

	if status == common.TransferStatusProcessing {
		res.Code = pay.ErrCodeTransferStatusUnknow
		res.Msg = pay.ErrMsgTransferStatusUnknow
	}

	res.Data.TradeNo = transferNo
	res.Data.TradeType = "0"
	res.Data.Amount = fmt.Sprintf("%.2f", transfer.Data.Amount)

	balance, err := acc.queryBalance()
	if err == nil && balance.Status == 200 && len(balance.Data.List) > 0 {
		res.Data.AmountRemain = fmt.Sprintf("%.2f", balance.Data.List[0].Balance)
	} else {
		res.Data.AmountRemain = "未知"
	}

	res.Data.TargetAccount = acc.transferTargetAccount
	res.Data.TargetName = acc.transferTargetName
	res.Data.TargetBankName = transfer.Data.ToBankName
	res.Data.Comment = acc.transferComment

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypeCIB,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		status)

	logger.LogTransfer("[CIB][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		acc.transferTargetName,
		acc.transferTargetAccount,
		res.Data.Amount,
		status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[CIB][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CIB][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
	}

	result, err := acc.realtimeTransferResult(req.TradeNo)
	if err != nil {
		logger.Errorf("[CIB][%+v]查询转帐状态错误, 流水号: %+v, 错误: %+v.", acc.Account, req.TradeNo, err)
		return pay.Error(pay.ErrCodeTransferStatusError, err.Error(), nil)
	}

	if result.Status != 200 {
		msg := fmt.Sprintf("查询转帐状态失败, 流水号: %+v, %+v", req.TradeNo, result.getErrMsg())
		logger.Errorf("[CIB][%+v]查询转帐状态失败, %+v.", acc.Account, msg)
		return pay.Error(pay.ErrCodeTransferStatusError, result.Error.Msg, nil)
	}

	status := common.TransferStatusNone
	if result.Data.DealStatus == "Y" {
		status = common.TransferStatusSuccess
	} else if result.Data.DealStatus == "F" {
		status = common.TransferStatusFail
	} else if result.Data.DealStatus == "1" {
		status = common.TransferStatusProcessing
	} else {
		logger.Errorf("[CIB][%+v]查询转帐状态未知状态, 流水号: %+v, 状态: %+v, 信息: %+v.",
			acc.Account, req.TradeNo, result.Data.DealStatus, result.Data.RejectInfo)
		return pay.Error(pay.ErrCodeTransferStatusError, fmt.Sprintf("未知转帐状态: %+v", result.Data.DealStatus), nil)
	}

	res := model.AccountTransferStatusRes{}
	res.Status = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Status = status

	if status != common.TransferStatusNone {
		api.NodeTransferStatus(req.TradeNo, status)
		logger.LogTransfer("[CIB][%+v]转帐流水[%+v]状态更新为: %+v.", acc.Account, req.TradeNo, status)
	}

	return pay.Success(&res)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	if event == notify.EventTypeLoadFaceImages {
		if err := acc.loadFaceImages(); err != nil {
			return pay.Error(pay.ErrCodeEventError, "加载刷脸图片失败", nil)
		}
	}

	return pay.Success(nil)
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
