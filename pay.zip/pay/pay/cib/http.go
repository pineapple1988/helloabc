package cib

import (
	"bytes"
	"crypto/md5"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"pay/pay"
	"pay/utils"
	"pay/utils/logger"
	"sort"
	"strings"
	"time"

	jsoniter "github.com/json-iterator/go"

	"github.com/go-http-utils/headers"
)

// func (acc *Account) getCookie(name string) string {
// 	u, err := url.Parse(urlUserHello)
// 	if err != nil {
// 		return ""
// 	}

// 	cookies := acc.jar.Cookies(u)
// 	for _, cookie := range cookies {
// 		if cookie.Name == name {
// 			v, err := url.QueryUnescape(cookie.Value)
// 			if err != nil {
// 				return ""
// 			}

// 			return v
// 		}
// 	}

// 	return ""
// }

// func (acc *Account) getDefaultUserAgentString() string {
// 	return fmt.Sprintf("%s 4.0.3 rv:4.0.3.2 (iPhone; iPhone OS %s; zh_CN)", UTF8ToISO8859_1("兴业银行"), acc.HardwareInfo.SystemVersion)
// }

func (acc *Account) generateRequestBody() string {
	convertKey := make(map[string]string)
	convertKey["model"] = "k3LE"
	convertKey["networkType"] = "Swlw"
	convertKey["VQFA"] = "908759025"
	convertKey["totalMemory"] = "oUvy"
	// 总共硬盘空间
	convertKey["totalSystem"] = "bxIT"
	convertKey["cellularIP"] = "PneH"
	convertKey["resolution"] = "9_vV"
	convertKey["IDFA"] = "bA0Q"
	// 可用的硬盘空间
	convertKey["availableSystem"] = "H6Rg"
	convertKey["brightness"] = "qm7W"
	convertKey["IDFV"] = "sxWp"
	convertKey["startupTime"] = "oA3w"
	convertKey["wifiList"] = "wXg4"
	convertKey["version"] = "XKTz"
	convertKey["appVersion"] = "wfQn"
	convertKey["battery"] = "89Fw"
	convertKey["rooted"] = "UqMW"
	convertKey["activeTime"] = "R7of"
	convertKey["carrier"] = "WANY"
	convertKey["language"] = "pO8w"
	convertKey["sdkVersion"] = "Vkrm"
	bodyDict := make(map[string]string)
	bodyDict["brightness"] = "0.496323"
	bodyDict["version"] = acc.HardwareInfo.SystemVersion
	bodyDict["wifiList"] = fmt.Sprintf("[%s-%s]", acc.HardwareInfo.WIFIName, acc.HardwareInfo.WIFIMac)
	bodyDict["model"] = acc.HardwareInfo.DeviceName
	bodyDict["sdkVersion"] = sdkVersion
	bodyDict["packageName"] = pkgName
	bodyDict["appVersion"] = cfBundleShortVersion
	bodyDict["resolution"] = strings.ReplaceAll(acc.HardwareInfo.ScreenSize, "*", "-")
	bodyDict["carrier"] = acc.HardwareInfo.Carrier
	bodyDict["networkType"] = "WiFi"
	bodyDict["isProxy"] = "0"
	bodyDict["isVPN"] = "0"
	bodyDict["rooted"] = "0"
	bodyDict["availableSystem"] = acc.HardwareInfo.AvailableSystemSpace
	bodyDict["platform"] = "IOS"
	bodyDict["totalSystem"] = acc.HardwareInfo.TotalSystemSpace
	bodyDict["totalMemory"] = acc.HardwareInfo.TotalMemory
	bodyDict["custID"] = "123"
	bodyDict["startupTime"] = fmt.Sprint(time.Now().Unix() - int64(utils.RandInt(1000, 100000)))
	bodyDict["battery"] = "[charging-1.000000]"
	bodyDict["cellularIP"] = acc.HardwareInfo.CellularIP
	bodyDict["language"] = "[zh_CN-中文（中国）]"
	keys := make([]string, 0)
	for k := range bodyDict {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	str := fmt.Sprintf("IDFA%s", acc.UUID)
	if strings.TrimSpace(acc.IDFV) != "" {
		str += fmt.Sprintf("IDFV%s", acc.IDFV)
	}

	for _, v := range keys {
		str = fmt.Sprintf("%s%s%s", str, v, bodyDict[v])
	}

	sha1Ary := sha256.Sum256([]byte(str))
	md5Ary := md5.Sum(sha1Ary[:])
	bodyDict["hashCode"] = base64.RawURLEncoding.EncodeToString(md5Ary[:])
	bodyDict["IDFA"] = acc.UUID
	bodyDict["algID"] = "IOSAlg"
	reqDict := make(map[string]string)
	for k, v := range bodyDict {
		key := k
		if v1, ok := convertKey[key]; ok {
			key = v1
		}
		reqDict[key] = v
	}
	b, _ := json.Marshal(reqDict)
	return string(b)
}

func (acc *Account) generatePost() (*generatePostRes, error) {
	data := acc.generateRequestBody()
	req, err := http.NewRequest("POST", urlGeneratePost, strings.NewReader(data))
	if err != nil {
		logger.Errorf("[CIB][%+v]创建http请求错误, url: %s, data: %s, err: %+v.", acc.Account, urlGeneratePost, data, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json; charset=utf-8")
	req.Header.Set(headers.UserAgent, "CIBMobileBank-prod/3 CFNetwork/894 Darwin/17.4.0")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.AcceptEncoding, "gzip,deflate")
	req.Header.Set(headers.AcceptLanguage, "zh-cn")

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[CIB][%+v]http操作错误, url: %s, data: %s, err: %+v.", acc.Account, urlGeneratePost, data, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		if strings.Contains(err.Error(), "204") {
			return &generatePostRes{}, nil
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CIB][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, urlGeneratePost, data, body)

	res := generatePostRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[CIB][%+v]反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	acc.IDFV = res.IDFV
	acc.DFP = res.Dfp
	acc.DFPExpire = res.Exp

	return &res, nil
}

func (acc *Account) postHTTPData(u string, req, res interface{}) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[CIB][%+v]序列化请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	// if u != urlCheckFaceRecognition {
	// 	logger.Debugf("[CIB][%+v]postHTTPData, url: %s, req body: %s.", acc.Account, u, string(arr))
	// }

	r, err := http.NewRequest("POST", u, bytes.NewReader(arr))
	if err != nil {
		logger.Errorf("[CIB][%+v]创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	// header
	r.Header.Add(headers.UserAgent, fmt.Sprintf("CIBMobileBank-prod/%s (iPhone; iOS %s; Scale/2.00)", cfBundleShortVersion, acc.HardwareInfo.SystemVersion))
	r.Header.Add(headers.AcceptLanguage, "zh-Hans-CN;q=1")
	r.Header.Add(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Add(headers.Accept, "*/*")
	r.Header.Add(headers.ContentType, "application/json; charset=utf-8")
	r.Header.Add("viewfrom", "2")
	r.Header.Add("channel", "208")
	r.Header.Add("terminaltype", "01")
	r.Header.Add("ua", fmt.Sprintf("%s,iOS,%s", acc.HardwareInfo.DeviceName, cfBundleShortVersion))
	r.Header.Add("formdev", "IOS")

	// token
	if acc.token != "" {
		r.Header.Set("formtoken", acc.token)
	}

	// dfp
	if acc.DFP != "" {
		r.Header.Add("bsfit-deviceid", acc.DFP)
		r.AddCookie(&http.Cookie{
			Name:  "BSFIT_DEVICEID",
			Value: acc.DFP,
		})
	}

	// handleid
	r.Header.Add("handleid", acc.getHandleID())

	body, err := utils.DoHTTP(acc.http, r)
	if err != nil {
		logger.Errorf("[CIB][%+v]http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	if u != urlCheckFaceRecognition {
		logger.Debugf("[CIB][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, u, string(arr), body)
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), res); err != nil {
			logger.Errorf("[CIB][%+v]反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (acc *Account) postEncData(u string, req, res interface{}, decrypt bool) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[CIB][%+v]序列化请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	// if u != urlCheckFaceRecognition {
	// 	logger.Debugf("[CIB][%+v]postEncData, url: %s, req JSON: %s.", acc.Account, u, string(arr))
	// }

	reqBody := string(arr)

	// 加密数据
	key := []byte(acc.aesKey)
	arr, err = utils.AESCBCEncrypt(arr, key, key)
	if err != nil {
		logger.Errorf("[CIB][%+v]postEncData加密请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrEncRequestData
	}

	reqData := map[string]interface{}{
		"data": base64.StdEncoding.EncodeToString(arr),
	}

	body := ""

	if decrypt {
		var resData struct {
			Data string `json:"data"`
		}

		body, err = acc.postHTTPData(u, &reqData, &resData)
		if err != nil {
			return "", err
		}

		if !strings.Contains(body, `"status":`) {
			arr, err := base64.StdEncoding.DecodeString(resData.Data)
			if err != nil {
				logger.Errorf("[CIB][%+v]postEncData解码返回数据错误: %+v", acc.Account, err)
				return "", pay.ErrDecRequestData
			}

			arr, err = utils.AESCBCDecrypt(arr, key, key)
			if err != nil {
				logger.Errorf("[CIB][%+v]postEncData解密返回数据错误: %+v.", acc.Account, err)
				return "", pay.ErrDecRequestData
			}

			body = string(arr)
		}
	} else {
		body, err = acc.postHTTPData(u, &reqData, nil)
		if err != nil {
			return "", err
		}
	}

	if u != urlCheckFaceRecognition {
		logger.Debugf("[CIB][%+v]http请求响应, url: %s, data: %s, body: %s.", acc.Account, u, reqBody, body)
	}

	if res != nil {
		json := jsoniter.ConfigCompatibleWithStandardLibrary
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			logger.Errorf("[CIB][%+v]反序列化解密数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}

func (acc *Account) postData(u string, req, res interface{}) (string, error) {
	return acc.postEncData(u, req, res, true)
}

func (acc *Account) keyHandle() (*keyHandleRes, error) {
	acc.aesKey = randBytesStr(16)
	keyStr := encAESKey([]byte(fmt.Sprintf("16%s%s", acc.aesKey, randBytesStr(110))))

	req := map[string]interface{}{
		"key_str":    keyStr,
		"key_type":   "AES_KEY",
		"key_length": "128",
	}

	res := keyHandleRes{}
	if _, err := acc.postHTTPData(urlKeyHandle, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) keepAlive() (*keepAliveRes, error) {
	req := map[string]interface{}{}
	res := keepAliveRes{}
	if _, err := acc.postEncData(urlKeepAlive, &req, &res, false); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryUserByMisty() (*queryUserByMistyRes, error) {
	req := map[string]interface{}{
		"uamName": acc.Account,
	}

	res := queryUserByMistyRes{}
	if _, err := acc.postData(urlQueryUserByMisty, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryUserByUniauthID() (*queryUserByUniauthIDRes, error) {
	req := map[string]interface{}{
		"uniauthId": acc.UniauthID,
	}

	res := queryUserByUniauthIDRes{}
	if _, err := acc.postData(urlQueryUserByUniauthID, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getEncryptPK() (*getEncryptPKRes, error) {
	req := map[string]interface{}{}
	res := getEncryptPKRes{}
	if _, err := acc.postData(urlGetEncryptPK, &req, &res); err != nil {
		return nil, err
	}

	// 成功设置key
	if res.Status == 200 {
		acc.rsaPublicKey = res.Data.RSAPublicKey
		acc.sm2KeyX = res.Data.SM2PublicKeyX
		acc.sm2KeyY = res.Data.SM2PublicKeyY
	}

	return &res, nil
}

func (acc *Account) comitLoginInfo() (*comitLoginInfoRes, error) {
	factor := acc.UniauthID[2:10]
	ba := bytes.NewBuffer([]byte{})
	binary.Write(ba, binary.BigEndian, int16(len(acc.getPassword())+len(factor)+4))
	ba.Write([]byte(fmt.Sprintf("%.2d", len(acc.getPassword()))))
	ba.Write([]byte(acc.getPassword()))
	ba.Write([]byte(fmt.Sprintf("%.2d", len(factor))))
	ba.Write([]byte(factor))

	data := ba.Bytes()
	//fmt.Println(hex.EncodeToString(data))
	cnt := 0x40 - len(data)
	for i := 0; i < cnt; i++ {
		data = append(data, byte(utils.RandInt(1, 255)))
	}

	pwd, err := encSM2(data, acc.sm2KeyX, acc.sm2KeyY)
	if err != nil {
		logger.Errorf("[CIB][%+v]加密登录密码错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	req := map[string]interface{}{
		"mobileType":    acc.HardwareInfo.Model,
		"termialType":   "01",
		"longitude":     "",
		"clientVersion": cfBundleShortVersion,
		"latitude":      "",
		"loginPhoneNo":  "",
		"uamPwd":        pwd,
		"genDevId":      acc.UUID,
		"ipAddr":        "",
		"geoType":       "2",
		"faceId":        "",
		"agent":         "iOS" + acc.HardwareInfo.SystemVersion,
		"devSN":         acc.UUID,
		"macAddr":       "",
		"devPlat":       "iOS",
		"devName":       "iPhone",
		"uniauthId":     acc.UniauthID,
	}

	res := comitLoginInfoRes{}
	if _, err := acc.postData(urlComitLoginInfo, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getToken() (*getTokenRes, error) {
	req := map[string]interface{}{}
	res := getTokenRes{}
	if _, err := acc.postData(urlGetToken, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) custLogin() (*custLoginRes, error) {
	req := map[string]interface{}{}
	res := custLoginRes{}
	if _, err := acc.postData(urlCustLogin, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getAccountsByURL() (*getAccountsByURLRes, error) {
	req := map[string]interface{}{
		"url": "/card-manager/card-list",
	}
	res := getAccountsByURLRes{}
	if _, err := acc.postData(urlGetAccountsByURL, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryBalance() (*queryBalanceRes, error) {
	req := map[string]interface{}{
		"indexArr": []int{acc.accountIndex},
	}

	res := queryBalanceRes{}
	if _, err := acc.postData(urlQueryBalance, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryTransListByPage(startDate, endDate string, page int) (*queryTransListByPageRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
		"seqence":      "001",
		"payWay":       "2",
		"tradeType":    "2",
		"minAmount":    "",
		"maxAmount":    "",
		"beginDate":    startDate,
		"endDate":      endDate,
		"startIndex":   page,
		"pageSize":     10,
	}

	res := queryTransListByPageRes{}
	if _, err := acc.postData(urlQueryTransListByPage, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getFrmsNo() (*getFrmsNoRes, error) {
	req := map[string]interface{}{}
	res := getFrmsNoRes{}
	if _, err := acc.postData(urlGetFrmsNo, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) selectCard(frmsNo string) (*selectCardRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
		"frmsNo":       frmsNo,
	}

	res := selectCardRes{}
	if _, err := acc.postData(urlSelectCard, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) getBankByCardNo(account string) (*getBankByCardNoRes, error) {
	req := map[string]interface{}{
		"acctNo": account,
	}

	res := getBankByCardNoRes{}
	if _, err := acc.postData(urlGetBankByCardNo, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) canSuperTransfer(bankCode string) (*canSuperTransferRes, error) {
	req := map[string]interface{}{
		"bankCode": bankCode,
	}

	res := canSuperTransferRes{}
	if _, err := acc.postData(urlCanSuperTransfer, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) cussentAccountQuery() (*cussentAccountQueryRes, error) {
	req := map[string]interface{}{}
	res := cussentAccountQueryRes{}
	if _, err := acc.postData(urlCussentAccountQuery, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) transferNextStep(frmsNo, account, name, bankCode, bankNo, bankName string) (*transferNextStepRes, error) {
	req := map[string]interface{}{
		"frmsNo":           frmsNo,
		"toAccNo":          account,
		"toAccName":        name,
		"toBankCode":       bankCode,
		"toNativeBankNo":   "",
		"toNativeBankName": "",
		"toRtBankNo":       bankNo,
		"toRtBankName":     bankName,
		"toCityCode":       "",
	}

	res := transferNextStepRes{}
	if _, err := acc.postData(urlTransferNextStep, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryAcclmt() (*queryAcclmtRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
		"transferFlag": 0,
	}

	res := queryAcclmtRes{}
	if _, err := acc.postData(urlQueryAcclmt, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryRemarks() (*queryRemarksRes, error) {
	req := map[string]interface{}{}
	res := queryRemarksRes{}
	if _, err := acc.postData(urlQueryRemarks, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) todayToTaCount(account string) (*todayToTaCountRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
		"toAcctNo":     account,
	}
	res := todayToTaCountRes{}
	if _, err := acc.postData(urlTodayToTaCount, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) beforeTransfer(frmsNo, amount, bankNo, bankName, comment string) (*beforeTransferRes, error) {
	req := map[string]interface{}{
		"frmsNo":           frmsNo,
		"amount":           amount,
		"toNativeBankNo":   "",
		"toNativeBankName": "",
		"toRtBankNo":       bankNo,
		"toRtBankName":     bankName,
		"toCityCode":       "",
		"note":             comment,
		"xybFlag":          0,
	}

	res := beforeTransferRes{}
	if _, err := acc.postData(urlBeforeTransfer, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) queryFrmsSign() (*queryFrmsSignRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
	}

	res := queryFrmsSignRes{}
	if _, err := acc.postData(urlQueryFrmsSign, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) confirmTransfer(frmsNo string) (*confirmTransferRes, error) {
	req := map[string]interface{}{
		"frmsNo":       frmsNo,
		"transferMode": 1,
	}

	res := confirmTransferRes{}
	if _, err := acc.postData(urlConfirmTransfer, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) checkFaceRecognition(frmsNo, data string) (*checkFaceRecognitionRes, error) {
	str := fmt.Sprintf("%ddata:image/jpeg;base64,%s", utils.GetTimeStamp(), data)
	key := []byte(checkFaceKey)
	arr, err := utils.AESCBCEncrypt([]byte(str), key, key)
	if err != nil {
		logger.Errorf("[CIB][%+v]加密刷脸图片数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrFaceDataError
	}

	req := map[string]interface{}{
		"frmsNo":    frmsNo,
		"userId":    acc.UniauthID,
		"faceImage": base64.StdEncoding.EncodeToString(arr),
		"userType":  "1",
	}

	res := checkFaceRecognitionRes{}
	if _, err := acc.postData(urlCheckFaceRecognition, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) sendSMSCode(frmsNo string) (*sendSMSCodeRes, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
	}

	res := sendSMSCodeRes{}
	if _, err := acc.postData(urlSendSMSCode, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) verifySMSCode(frmsNo, code string) (*verifySMSCodeRes, error) {
	req := map[string]interface{}{
		"frmsNo":  frmsNo,
		"smsCode": code,
	}

	res := verifySMSCodeRes{}
	if _, err := acc.postData(urlVerifySMSCode, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) verifyPwd(frmsNo string) (*verifyPwdRes, error) {
	ba := bytes.NewBuffer([]byte{})
	ba.Write([]byte(fmt.Sprintf("%.2d", len(acc.getPayPassword()))))
	ba.Write([]byte(acc.getPayPassword()))

	data := ba.Bytes()
	cnt := 0x40 - len(data)
	for i := 0; i < cnt; i++ {
		data = append(data, byte(utils.RandInt(1, 255)))
	}

	pwd, err := encSM2(data, acc.sm2KeyX, acc.sm2KeyY)
	if err != nil {
		logger.Errorf("[CIB][%+v]加密支付密码错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	req := map[string]interface{}{
		"frmsNo": frmsNo,
		"pwd":    pwd,
	}

	res := verifyPwdRes{}
	if _, err := acc.postData(urlVerifyPwd, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}

func (acc *Account) doTransfer(frmsNo string) (*doTransferRes, string, error) {
	req := map[string]interface{}{
		"frmsNo": frmsNo,
	}

	res := doTransferRes{}
	body, err := acc.postData(urlDoTransfer, &req, &res)
	if err != nil {
		return nil, "", err
	}

	return &res, body, nil
}

func (acc *Account) realtimeTransferResult(frmsNo string) (*realtimeTransferResultRes, error) {
	req := map[string]interface{}{
		"accountIndex": acc.accountIndex,
		"netTraceNo":   frmsNo,
	}

	res := realtimeTransferResultRes{}
	if _, err := acc.postData(urlRealtimeTransferResult, &req, &res); err != nil {
		return nil, err
	}

	return &res, nil
}
