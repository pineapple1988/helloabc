package cib

import (
	"fmt"
	"pay/data/redis"
	"pay/utils/config"
	"pay/utils/logger"
	"testing"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	acc, err := NewAccount("18292611043", "aa121244", "121244", "ios")
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	r := acc.Login(20000)
	if r == nil {
		t.Fatal("尚未实现登录接口.")
	}

	if r.Code != 0 {
		t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	}
}
