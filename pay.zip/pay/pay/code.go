package pay

// 登录状态
const (
	LoginStatusNone     = 0
	LoginStatusWaitCode = 1
	LoginStatusSuccess  = 2
)

// 冻结代码
const (
	FreezeCodePasswordError    = 1
	FreezeMsgPasswordError     = "密码错误次数过多"
	FreezeCodeSMSCodeError     = 2
	FreezeMsgSMSCodeError      = "验证码错误次数过多"
	FreezeCodePayPasswordError = 3
	FreezeMsgPayPasswordError  = "支付密码错误次数过多"
	FreezeCodeAccountRisk      = 4
	FreezeMsgAccountRisk       = "帐号存在风险"
	FreezeCodeCardError        = 5
	FreezeMsgCardError         = "卡片状态异常"
)

// 错误代码
const (
	ErrCodeSuccess              = 0
	ErrMsgSuccess               = "操作成功"
	ErrCodeProxyError           = 1001
	ErrMsgProxyError            = "请求代理服务器错误"
	ErrCodeLoginPadding         = 1002
	ErrMsgLoginPadding          = "当前帐号正在进行登录操作, 请稍候再试"
	ErrCodeNeedSMSCode          = 1003
	ErrMsgNeedSMSCode           = "需要验证码登录"
	ErrCodeTimeout              = 1004
	ErrMsgTimeout               = "操作超时"
	ErrCodeLoginError           = 1005
	ErrMsgLoginError            = "登录错误"
	ErrCodeInvalidIDPWD         = 1006
	ErrMsgInvalidIDPWD          = "帐号或密码错误"
	ErrCodeSMSCodeError         = 1007
	ErrMsgSMSCodeError          = "短信验证码错误"
	ErrCodeNotLogined           = 1008
	ErrMsgNotLogined            = "帐号尚未登录, 请登录后再进行操作"
	ErrCodeSendCodeError        = 1009
	ErrMsgSendCodeError         = "发送验证码操作失败"
	ErrCodeTransferError        = 1010
	ErrMsgTransferError         = "转帐操作失败"
	ErrCodeGetBalanceError      = 1011
	ErrMsgGetBalanceError       = "查询余额错误, 请稍候再试"
	ErrCodeGetBillListError     = 1012
	ErrMsgGetBillListError      = "查询帐单错误, 请稍候再试"
	ErrCodeReloginError         = 1013
	ErrMsgReloginError          = "重新登录帐号失败"
	ErrCodeNotNeedSMSCode       = 1014
	ErrMsgNotNeedSMSCode        = "不需要验证码"
	ErrCodeNeedTransferCode     = 1015
	ErrMsgNeedTransferCode      = "需要验证码进行转帐"
	ErrCodeTransferStatusError  = 1016
	ErrMsgTransferStatusError   = "查询转帐状态错误"
	ErrCodeUnSupportBank        = 1017
	ErrMsgUnSupportBank         = "暂不支持向该银行转帐"
	ErrCodeCardBlock            = 1018
	ErrMsgCardBlock             = "该卡号已被冻结"
	ErrCodeCardListError        = 1019
	ErrMsgCardListError         = "获取银行卡列表错误"
	ErrCodeResetPassError       = 1020
	ErrMsgResetPassError        = "重置密码错误"
	ErrCodeEventError           = 1021
	ErrMsgEventError            = "事件处理错误"
	ErrCodeGetQRCodeError       = 1022
	ErrMsgGetQRCodeError        = "生成收款二维码错误"
	ErrCodeQRScanError          = 1023
	ErrMsgQRScanError           = "扫描二维码错误"
	ErrCodeOperationPadding     = 1024
	ErrMsgOperationPadding      = "操作正在进行中, 请稍候再试"
	ErrCodeOperationDelay       = 1025
	ErrMsgOperationDelay        = "操作过于频繁, 请稍候再试"
	ErrCodeAccountRisk          = 1026
	ErrMsgAccountRisk           = "帐号存在风险"
	ErrCodePayPasswordNotExists = 1027
	ErrMsgPayPasswordNotExists  = "支付密码为空, 无法进行转帐操作"
	ErrCodeLoginOtherDevice     = 1028
	ErrMsgLoginOtherDevice      = "该帐号已在其它设备登录, 需要重新登录进行设备绑定"
	ErrCodeTransferStatusUnknow = 1029
	ErrMsgTransferStatusUnknow  = "无法确认的转帐状态, 请人工核对转帐操作是否成功"
	ErrCodeCardReportLost       = 1030
	ErrMsgCardReportLost        = "卡号挂失状态"
)
