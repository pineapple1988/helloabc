package pay

import (
	"crypto/tls"
	"errors"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"pay/api"
	"pay/data/redis"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/go-http-utils/headers"

	"golang.org/x/net/proxy"
)

const (
	// LoginSuccessKey 登录成功帐号
	LoginSuccessKey = "AccountLoginSuccess"

	// ProxyUserCountKey 代理使用数量
	ProxyUserCountKey = "ProxyUserCount"
)

var (
	proxyUserMap = map[string]int{}
	proxyLock    = sync.Mutex{}
)

// ProxyInfo 代理信息
type ProxyInfo struct {
	URI  string `json:"uri"`
	User string `json:"user"`
	Pass string `json:"pass"`
}

// ResultInfo 操作结果信息
type ResultInfo struct {
	Code int
	Msg  string
	Data interface{}
}

// LoginSuccessInfo 登录成功帐号信息
type LoginSuccessInfo struct {
	Account  string `json:"account"`
	AccType  int    `json:"accType"`
	Platform int    `json:"platform"`
}

// Error 返回错误结果
func Error(code int, msg string, data interface{}) *ResultInfo {
	return &ResultInfo{
		Code: code,
		Msg:  msg,
		Data: data,
	}
}

// Success 返回成功结果
func Success(data interface{}) *ResultInfo {
	if data == nil {
		return Error(ErrCodeSuccess, ErrMsgSuccess, &model.ResBase{
			Code: ErrCodeSuccess,
			Msg:  ErrMsgSuccess,
		})
	}

	return Error(ErrCodeSuccess, ErrMsgSuccess, data)
}

// AddLoginSuccess 添加登录成功帐号, 用于自动上号
func AddLoginSuccess(account, platform string, acctype int) error {
	key := fmt.Sprintf("%s_%s", LoginSuccessKey, api.GetNodeGUID())
	pltCode := api.GetPlatformCode(platform)
	field := fmt.Sprintf("%s_%d_%d", account, acctype, pltCode)
	exists, err := redis.HExists(key, field)

	// 存在
	if err == nil && exists {
		return nil
	}

	info := LoginSuccessInfo{
		Account:  account,
		AccType:  acctype,
		Platform: pltCode,
	}

	if err := redis.HSetObject(key, field, &info); err != nil {
		return err
	}

	return nil
}

// DelLoginSuccess 删除登录成功帐号
func DelLoginSuccess(account, platform string, acctype int) {
	key := fmt.Sprintf("%s_%s", LoginSuccessKey, api.GetNodeGUID())
	pltCode := api.GetPlatformCode(platform)
	field := fmt.Sprintf("%s_%d_%d", account, acctype, pltCode)
	redis.HDel(key, &[]string{field})
}

// GetLoginSuccessList 取登录成功列表
func GetLoginSuccessList() (*map[string]string, error) {
	key := fmt.Sprintf("%s_%s", LoginSuccessKey, api.GetNodeGUID())
	return redis.HGetAll(key)
}

// DetectProxy 检测代理服务器
func DetectProxy(pi *utils.ProxyInfo) error {
	// 访问百度进行检测
	cli := CreateHTTPClient(pi, nil)
	ts, ok := cli.Transport.(*http.Transport)
	if ok {
		// 关掉keepalive
		ts.DisableKeepAlives = true
	}

	req, err := http.NewRequest("GET", "http://www.baidu.com/", nil)
	if err != nil {
		return err
	}

	req.Header.Add(headers.Accept, "*/*")
	req.Header.Add(headers.AcceptEncoding, "gzip, deflate")
	req.Header.Add(headers.AcceptLanguage, "zh-CN")
	req.Header.Add(headers.UserAgent, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134")

	// 尝试三次
	for i := 0; i < 3; i++ {
		_, err = utils.DoHTTP(cli, req)
		if err == nil {
			return nil
		}
	}

	return err
}

// AllocProxy 分配代理服务器
func AllocProxy(account string, platform string, pi *utils.ProxyInfo) (*utils.ProxyInfo, error) {
	pltCode := api.GetPlatformCode(platform)

	if config.IsUseLocalProxy() {
		return allocLocalProxy(account, platform, pi)
	}

	ac := true

	// 测试代理服务器
	if pi != nil && pi.URI != "" {
		if err := DetectProxy(pi); err != nil {
			// 检测错误, 释放代理
			logger.Warnf("[pay]代理服务器检测失败, 将释放, 错误: %+v.", err)
			if err := api.ProxyRelease(account, pltCode); err != nil {
				logger.Warn("[pay]释放代理服务器错误.")
				return nil, err
			}
		} else {
			ac = false
		}
	}

	if ac {
		// 通过接口获取代理服务器
		proxy, err := api.ProxyAlloc(account, pltCode)
		if err != nil {
			logger.Warnf("[pay]请求代理服务器错误: %+v.", err)
			return nil, err
		}

		logger.Infof("[pay]请求代理服务器成功, Uri: %+v", proxy.URI)
		return proxy, nil
	}

	return nil, nil
}

// ReleaseProxy 释放代理服务器
func ReleaseProxy(uri string) {
	if uri == "" {
		return
	}

	if config.IsUseLocalProxy() && config.GetLocalProxyMode() == 1 {
		decProxyUserCount(uri)
	}
}

func getProxyUserCount(uri string) int {
	proxyLock.Lock()
	defer proxyLock.Unlock()

	// 存在直接返回
	count, exists := proxyUserMap[uri]
	if exists {
		return count
	}

	// 看缓存是否存在
	str, err := redis.HGet(ProxyUserCountKey, uri)
	if err != nil {
		return 0
	}

	count, err = strconv.Atoi(str)
	if err != nil {
		return 0
	}

	proxyUserMap[uri] = count

	return count
}

func incProxyUserCount(uri string) {
	count := getProxyUserCount(uri)
	proxyLock.Lock()
	defer proxyLock.Unlock()

	count++
	proxyUserMap[uri] = count
	redis.HSet(ProxyUserCountKey, uri, strconv.Itoa(count))
}

func decProxyUserCount(uri string) {
	count := getProxyUserCount(uri)
	if count <= 0 {
		return
	}

	proxyLock.Lock()
	defer proxyLock.Unlock()

	count--
	if count < 0 {
		count = 0
	}

	proxyUserMap[uri] = count
	redis.HSet(ProxyUserCountKey, uri, strconv.Itoa(count))
}

// allocLocalProxy 分配本地代理服务器
func allocLocalProxy(account string, platform string, pi *utils.ProxyInfo) (*utils.ProxyInfo, error) {
	mode := config.GetLocalProxyMode()
	proxys := config.GetProxyConfig()
	lineType := config.GetProxyLineType()
	n := len(proxys)
	if n <= 0 {
		return nil, errors.New("无法找到可用代理服务器")
	}

	// 如果之前分配的还存在直接使用
	if pi != nil {
		for _, v := range proxys {
			uri := v.InternalURI
			if lineType != config.LineTypeInternal {
				uri = v.PublicURI
			}

			if pi.URI == uri {
				return pi, nil
			}
		}
	}

	if mode == 0 {
		// 随机分配模式
		proxy := proxys[rand.Intn(n)]
		uri := proxy.InternalURI
		if lineType != config.LineTypeInternal {
			uri = proxy.PublicURI
		}

		return &utils.ProxyInfo{
			URI:  uri,
			User: proxy.UserName,
			Pass: proxy.Password,
		}, nil

	} else if mode == 1 {
		// 先尝试随机分配
		count := config.GetLocalProxyUserCount()
		for i := 0; i < 3; i++ {
			proxy := proxys[rand.Intn(n)]
			uri := proxy.InternalURI
			if lineType != config.LineTypeInternal {
				uri = proxy.PublicURI
			}

			if getProxyUserCount(uri) < count {
				incProxyUserCount(uri)
				return &utils.ProxyInfo{
					URI:  uri,
					User: proxy.UserName,
					Pass: proxy.Password,
				}, nil
			}
		}

		// 无法分配时循环查找
		for _, v := range proxys {
			uri := v.InternalURI
			if lineType != config.LineTypeInternal {
				uri = v.PublicURI
			}

			if getProxyUserCount(uri) < count {
				incProxyUserCount(uri)
				return &utils.ProxyInfo{
					URI:  uri,
					User: v.UserName,
					Pass: v.Password,
				}, nil
			}
		}
	} else {
		return nil, errors.New("代理服务器配置不正确")
	}

	return nil, errors.New("无法找到可用代理服务器")
}

// CreateHTTPClient 创建http客户端
func CreateHTTPClient(pi *utils.ProxyInfo, jar *cookiejar.Jar) *http.Client {
	// transport
	ts := &http.Transport{
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			InsecureSkipVerify: true,
		},
		MaxIdleConns:        50,
		MaxIdleConnsPerHost: 10,
	}

	// proxy
	if pi != nil && pi.URI != "" {
		uri := strings.TrimPrefix(pi.URI, "socks5://")
		d, _ := proxy.SOCKS5("tcp", uri,
			&proxy.Auth{
				User:     pi.User,
				Password: pi.Pass,
			},
			&net.Dialer{
				Timeout:   time.Second * 3,
				KeepAlive: time.Second * 5,
			})

		ts.Dial = d.Dial
	}

	// cookie
	if jar == nil {
		jar, _ = cookiejar.New(nil)
	}

	u, _ := url.Parse("http://127.0.0.1:8888")
	return &http.Client{
		Transport: &http.Transport{
			Proxy:               http.ProxyURL(u),
			MaxIdleConns:        50,
			MaxIdleConnsPerHost: 10,
			//DisableKeepAlives:   true,
		},
		Jar:       jar,
		Timeout:   time.Second * 20,
	}
}

// GetBillListDate 计算帐单日期
func GetBillListDate(req *model.AccountBillListReq) (string, string) {
	startDate := ""
	endDate := ""
	t := time.Now()

	if req.TimeType == common.TimeTypeByDay {
		// 按天查询
		if req.Days < 0 {
			req.Days = 0
		}

		s := t.AddDate(0, 0, -req.Days)
		endDate = fmt.Sprintf("%.4d%.2d%.2d", t.Year(), t.Month(), t.Day())
		startDate = fmt.Sprintf("%.4d%.2d%.2d", s.Year(), s.Month(), s.Day())
	} else if req.TimeType == common.TimeTypeByTime {
		// 按时间查询
		s := time.Unix(int64(req.StartTime), 0)
		e := time.Unix(int64(req.EndTime), 0)
		endDate = fmt.Sprintf("%.4d%.2d%.2d", e.Year(), e.Month(), e.Day())
		startDate = fmt.Sprintf("%.4d%.2d%.2d", s.Year(), s.Month(), s.Day())
	} else {
		// 默认查询当天
		endDate = fmt.Sprintf("%.4d%.2d%.2d", t.Year(), t.Month(), t.Day())
		startDate = endDate
	}

	return startDate, endDate
}

// GetBillListDate 计算帐单日期
func GetBillListDate1(req *model.AccountBillListReq) (string, string) {
	startDate := ""
	endDate := ""
	t := time.Now()

	if req.TimeType == common.TimeTypeByDay {
		// 按天查询
		if req.Days < 0 {
			req.Days = 0
		}

		s := t.AddDate(0, 0, -req.Days)
		endDate = fmt.Sprintf("%.4d/%.2d/%.2d", t.Year(), t.Month(), t.Day())
		startDate = fmt.Sprintf("%.4d/%.2d/%.2d", s.Year(), s.Month(), s.Day())
	} else if req.TimeType == common.TimeTypeByTime {
		// 按时间查询
		s := time.Unix(int64(req.StartTime), 0)
		e := time.Unix(int64(req.EndTime), 0)
		endDate = fmt.Sprintf("%.4d/%.2d/%.2d", e.Year(), e.Month(), e.Day())
		startDate = fmt.Sprintf("%.4d/%.2d/%.2d", s.Year(), s.Month(), s.Day())
	} else {
		// 默认查询当天
		endDate = fmt.Sprintf("%.4d/%.2d/%.2d", t.Year(), t.Month(), t.Day())
		startDate = endDate
	}

	return startDate, endDate
}
// AccountFreeze 冻结帐号
func AccountFreeze(account, platform string, acctype, code int, reason string) {
	DelLoginSuccess(account, platform, acctype)
	api.ReportAccStateLogout(account, platform, acctype)
	api.NodeAccountFreeze(account, platform, acctype, code, reason)
}

// AccountLogout 退出帐号
func AccountLogout(account, platform string, acctype int) {
	DelLoginSuccess(account, platform, acctype)
	api.ReportAccStateLogout(account, platform, acctype)
}

// AccountKickout 踢出帐号
func AccountKickout(account, platform string, acctype int) {
	DelLoginSuccess(account, platform, acctype)
	api.ReportAccStateKickout(account, platform, acctype)
}
