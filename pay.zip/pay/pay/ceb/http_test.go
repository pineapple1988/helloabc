package ceb

import (
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/big"
	"pay/data/redis"
	"pay/pay"
	"pay/pay/psbc"
	"pay/tools"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"strconv"
	"strings"
	"testing"

	"github.com/tjfoc/gmsm/sm2"
)

func TestLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()
	logger.SetDir("/log")

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}

	acc, err := NewAccount("13755090355", "wei201498", "150590", "ios")

	acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	//第一次打开APP
	acc.getBasicMsg()

	//acc.testFetchPublicKey()
 	resfetchPublicKey,_ := acc.fetchPublicKey1()

	acc.sm2Key = resfetchPublicKey.SM2Key
	acc.sm4Key = resfetchPublicKey.SM4Key
	acc.publicKeyTimestamp = resfetchPublicKey.Timestamp

	//获取硬件token，只有第一次打开APP时候获取
	//res,_ := acc.getToken()
	//
	//
	//
	//acc.Token = res.Token

	acc.WhiteCifGrayscale()

	acc.HomePageFloorPictureQry()

	acc.ExcellentFinancing()

	acc.clientNoticeList()

	//跳到登陆页面

	resGetMobileToLogin,_ := acc.getMobileToLogin(1)

	acc.dynamicSM4Key = resGetMobileToLogin.DynamicSM4Key
	acc.dynamicArrayKey = resGetMobileToLogin.DynamicArrayKey
	acc.newDeviceFlag = resGetMobileToLogin.NewDeviceFlag
	acc.loginFlag = resGetMobileToLogin.LoginFlag


	//resSendSMSPwd,_ := acc.toSendSMSPwd("")

	//发短信
	resNewSendSMSPwd,_ := acc.getNewToSendSMSPwd()
	acc.signatureSendSmsMD5 = resNewSendSMSPwd.SignatureSendSmsMD5
	acc.newDeviceDataMap = resNewSendSMSPwd.NewDeviceDataMap

	smsCodeDatas := &smsCodeDatas{}
	if utils.Exist("./SmsCode.json") {
		utils.LoadJsonFromFile("./SmsCode.json", smsCodeDatas)
	} else {
		fmt.Println("./SmsCode.json 文件不存在, 请检查!!!")
	}
	acc.geIsPwdNull(smsCodeDatas.TransferSmsCode)

	resToLogin,_ := acc.toLogin(smsCodeDatas.TransferSmsCode)

	acc.UserID = resToLogin.UserID
	acc.loginFailCount = 0

	acc.getMineCreditQryPre()
	//查账
	resActQry,_ := acc.actQryPre()

	acc.acID = resActQry.AcID
	acc.actTrsQry("20201230","20210327",0)

	acc.UserID = resToLogin.UserID
	acc.loginFailCount = 0
	acc.save()

	acc.ExcellentFinancing()
	acc.DailyFirstLogin() //7.10新
	acc.clientNoticeList()

	//转帐
	resbankTransferPre,_ := acc.bankTransferPre()
	//confirm, err := acc.bankTransferConfirm(bankCode, bankNo, bankName, pre.AvailBal, pre.PayerBankAcType, req.TargetAccount, req.TargetName, req.Amount, req.Comment)
	acc.acID = resbankTransferPre.AcID
	resTransferBankQry,_ := acc.transferBankQry("6230582000069648114")
	//确认转账
	resConfirm ,_:= acc.bankTransferConfirmNew(resTransferBankQry.List[0].SuperDeptID,resTransferBankQry.List[0].PayeeBankID,
		resTransferBankQry.List[0].BankName,
		resbankTransferPre.AvailBal,resbankTransferPre.PayeeBankAcType,"6230582000069648114","涂聪","1.2","")


	//发验证码
	acc.sendSMSPwd(resConfirm.PayeeAcNo,resConfirm.PayeeAcNo,resConfirm.Amount,resConfirm.SmsData)


	if utils.Exist("./SmsCode.json") {
		utils.LoadJsonFromFile("./SmsCode.json", smsCodeDatas)
	} else {
		fmt.Println("./SmsCode.json 文件不存在, 请检查!!!")
	}

	acc.bankTransfer(resConfirm,smsCodeDatas.TransferSmsCode)
	acc.save()
	acc.getfetchPublicKeyCollet()
	// acc.getMobileToLoginCollet()
	// acc.getColletToSendSMSPwd()
	acc.getToLoginCollet()

	// r := acc.Login(20000)
	// if r == nil {
	// 	t.Fatal("尚未实现登录接口.")
	// }

	// if r.Code != 0 {
	// 	t.Fatalf("登录错误, code: %d, msg: %s.", r.Code, r.Msg)
	// }

	//二次登陆

}

//二次登陆
func TestSencondLogin(t *testing.T) {
	var cfg = &config.RedisConfig{
		DBHost: "127.0.0.1:6379",
		DBPass: "",
	}

	logger.SetDebug()
	logger.SetDir("/log")

	if err := redis.InitRedis(cfg); err != nil {
		fmt.Printf("连接redis数据库失败, 错误: %+v.\n", err)
	}


	acc, err := NewAccount("13755090355", "wei201498", "150590", "ios")

	acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	if err != nil {
		t.Fatalf("创建帐号错误: %+v.", err)
	}

	//第一次打开APP
	acc.getBasicMsg()

	resfetchPublicKey,_ := acc.fetchPublicKey1()

	acc.sm2Key = resfetchPublicKey.SM2Key
	acc.sm4Key = resfetchPublicKey.SM4Key
	acc.publicKeyTimestamp = resfetchPublicKey.Timestamp

	//乱七八糟的不重要的包
	acc.WhiteCifGrayscale()

	acc.HomePageFloorPictureQry()

	acc.ExcellentFinancing()

	acc.clientNoticeList()
	resGetMobileToLogin,_ := acc.getMobileToLogin(1)

	acc.dynamicSM4Key = resGetMobileToLogin.DynamicSM4Key
	acc.dynamicArrayKey = resGetMobileToLogin.DynamicArrayKey
	acc.newDeviceFlag = resGetMobileToLogin.NewDeviceFlag
	acc.loginFlag = resGetMobileToLogin.LoginFlag

	resToLogin,_ := acc.toLogin("")

	acc.getMineCreditQryPre()
	//查账
	resActQry,_ := acc.actQryPre()

	acc.acID = resActQry.AcID
	acc.actTrsQry("20201230","20210327",0)


	acc.getMineCreditQryPre()
	//查账
	resActQry1,_ := acc.actQryPre()

	acc.acID = resActQry1.AcID
	acc.actTrsQry("20201230","20210327",0)
	acc.UserID = resToLogin.UserID
	acc.loginFailCount = 0
	acc.save()

	acc.ExcellentFinancing()
	acc.DailyFirstLogin() //7.10新
	acc.clientNoticeList()

	//转帐
	resbankTransferPre,_ := acc.bankTransferPre()
	//confirm, err := acc.bankTransferConfirm(bankCode, bankNo, bankName, pre.AvailBal, pre.PayerBankAcType, req.TargetAccount, req.TargetName, req.Amount, req.Comment)
	acc.acID = resbankTransferPre.AcID
	resTransferBankQry,_ := acc.transferBankQry("6230582000069648114")
	resConfirm ,_:= acc.bankTransferConfirmNew(resTransferBankQry.List[0].SuperDeptID,resTransferBankQry.List[0].PayeeBankID,
		resTransferBankQry.List[0].BankName,
		resbankTransferPre.AvailBal,resbankTransferPre.PayeeBankAcType,"6230582000069648114","涂聪","1.2","")

	acc.sendSMSPwd(resConfirm.PayeeAcNo,resConfirm.PayeeAcNo,resConfirm.Amount,resConfirm.SmsData)

	smsCodeDatas := &smsCodeDatas{}
	if utils.Exist("./SmsCode.json") {
		utils.LoadJsonFromFile("./SmsCode.json", smsCodeDatas)
	} else {
		fmt.Println("./SmsCode.json 文件不存在, 请检查!!!")
	}

	acc.bankTransfer(resConfirm,smsCodeDatas.TransferSmsCode)






}

func TestSM2Key(t *testing.T) {
	arr, err := base64.StdEncoding.DecodeString("voGw0UtpxrDjpWNFnFeTDouwc3ms5NwGCBeMKYEcTeKzkzVjNPnTObw5njOi8rAMEleZWMThDdC2BagoQg8rCQ==")
	if err != nil {
		t.Fatalf("解码失败: %+v\n", err)
	}

	fmt.Printf("%x\n", arr[0:len(arr)/2])
	fmt.Printf("%x\n", arr[len(arr)/2:])
}

func TestPayPassword(t *testing.T) {
	encPayPassword("374930", "20191218212531", "voGw0UtpxrDjpWNFnFeTDouwc3ms5NwGCBeMKYEcTeKzkzVjNPnTObw5njOi8rAMEleZWMThDdC2BagoQg8rCQ==")
}

func TestCreateSM2Key(t *testing.T) {
	//pri, err := sm2.GenerateKey()
	//if err != nil {
	//	t.Fatal("生成密钥错误")
	//}
	//
	//t.Logf("d==>%s\n", pri.D.Text(16))
	//t.Logf("x==>%s\n", pri.PublicKey.X.Text(16))
	//t.Logf("y==>%s\n", pri.PublicKey.Y.Text(16))
	//
	strU := encryp3Des("32E15406-8F55-4E18-8951-A6BEADC37B14","hundsun1","hundsun1","hundsun1")
	//
	fmt.Println(strU)

	inData,_:= base64.StdEncoding.DecodeString("l5LmcRrh7tymG23l/Kz7AyULJE2lFPV2KSFlJPsoHBAUuvrsKlrcNFZ879qF/GRDpkDahrwrhv0=")
	fmt.Println(hex.Dump(inData))
	deStr1,_:= tools.DESECBDecrypt(inData,[]byte("hundsun1"))

	fmt.Println(hex.Dump(deStr1))

	deStr2,_:= tools.DESECBDecrypt(deStr1,[]byte("hundsun1"))
	fmt.Println(hex.Dump(deStr2))

	deStr3,_:= tools.DESECBDecrypt(deStr2,[]byte("hundsun1"))
	fmt.Println(hex.Dump(deStr3))

	rsaKey := "D0F92F4A372C854786109A91D2D69B280CB089D0D74A1EF82B46B76E7E481C39D33031D9CF62B979B87561FB05DB17BAC6DC4E920E650E9EE535B5B2D3F587781426418E637409E774EED8C39160DA16DF940C9EF7594BD0D31B99D40336D10C17BCB73661582850017DACACF2446BFC6F0108282E0756FA0CD31D80E5E27B02C891B4B49D4E23C05C0629FD43E84BA58E08C96FA0B00B7BA8F1FC4D090F46F8010E231254DC658FD8A7BEC41F2C3CB0F02831650827C737B0325A3F5D9BF5EA46AAD9D4CFACB667B1B36EEBEB28EA409BD5AADFFE986090A3C022278BE68A27FBF6854EF96712563194A2D85580F8BB2C1625D04791ED5F217476AE44EDBA95"
	strRs,_:= utils.PublicKeyFromString(rsaKey,0,16)
	fmt.Println(strRs)

}

func TestSM2Decrypt(t *testing.T) {
	pri := new(sm2.PrivateKey)
	pri.Curve = sm2.P256Sm2()
	pri.D, _ = new(big.Int).SetString("d19116ca88620dbd629f871a11dd15986d7732f43260f5b5947ebe25ee253690", 16)
	//pri.PublicKey = sm2.PublicKey{}
	//pri.PublicKey.Curve = sm2.P256Sm2()
	//pri.PublicKey.X, _ = new(big.Int).SetString("a4f70f49ea69a2653dd6626d5674be0bb4317dfdf9cb6a983d3c482434533954", 16)
	//pri.PublicKey.Y, _ = new(big.Int).SetString("3adf33d39351b1164e57e5949ee6859f58cf6aa53238501c7075cc1233fafe9b", 16)

	//arr, err := hex.DecodeString("04a66bdea02c050502cfad9313b5adfe4f2d6f33f566db2a301005980e6a11671ea9ac11833744d2fb94e96ddbf80c65a42e66f407d161e5f6b8546ca55ce74d85db38b3d6eddb1e36e82b5d9596c3afdab8ba06ca1c418c1e593fc3b8ed2d79abf8369be9fb4c7c2d")
	arr, err := hex.DecodeString("04c460d10fd0ef73756a988ff9a9a0f60b0614140b63b5741a3fb7152beec5a2a6d092461b58428215050565c16c0e81325dc4885361256a6ef671984ce899e1f736955cccafb17b83cf24e440d725c0019da13dd95937053e9bf32be6e8a70d9eed3d8901fd235615")
	if err != nil {
		t.Fatalf("解码加密数据错误: %+v.", err)
	}

	data, err := pri.Decrypt(arr)
	if err != nil {
		t.Fatalf("私钥解密错误: %+v.", err)
	}

	t.Logf("解密数据: %x.", data)
}

func TestSM2Enc(t *testing.T) {
	//pass := "198612"
	//arr, err := hex.DecodeString(fmt.Sprintf("%02d%sFFFFFFFF", len(pass), pass))
	//if err != nil {
	//	t.Fatalf("转换错误: %+v.", err)
	//}

	inData := "1603876610724"
	println(hex.Dump([]byte(inData)))
	enc, err := encSM2([]byte(inData), "7FB94C40A82EFF8020A560B58B29F762A14B750B433120E222DD8E2C50F354B4", "DB27632DF7A6CE55006CD395807CFFD97572731B2A56101EFEB3A4A7001364EE")

	if err != nil {
		t.Fatalf("加密错误: %+v.", err)
	}

	t.Log(enc)
}

func TestDesDecrypt(t *testing.T) {
	//str := "xGT7QAjRt1AHv5ZWIlWHAtoGuvIeps4gaGumMlFKZXbjy4OSvLdPjctL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHDCmSKvT/rBYoKa9UWOsvvSiCjFRf/I+Mmpo6zFcaX4tj5m9ZbgpYdr15pPbOYfWAXY6TGyhx2QYhhMWFSI3XBIPhb8T1GQWaLmRb9N3zWAYJJ2wLUX90J5bF60M46pW2jbVum6TlzJIuq6SptH4eoGOwwXgwlLXqFCzS0+suJwx9x+Mfa7vw494RR8lZg4x3RMf5eJruXwhMTX1I1VplM/WTT9MmXBR0SkaJ3mpQgEF7P6oZtRLLnYWYNt3GNtdB1maJzo/mDY3UfB6rptsVhfSjVLSqRLDgQeaa4IizboN5dy6BVzdeEZF+xuPfPcV5CPxDC80LVjxBorg1FH1WEYSj4goQQ/9AV48FwIf6upQzUEm2UCT+8CkGwhY299aN7MHBiAxBGCn+zo6Ii2nN81FC1m+yBUXsXobwWEBofwod2m7W86KkmERDfPaS8wsPvv68JE3KAlaz7cMi6ndiFd/qDDyKr3Kbwajyx0KLWF83cj2fuFspWYcI38Try7dmXvZYrdiDGU2KY8EsbZXiLlyLkgo4K2whOoUd9I+ZGzJJYSyZabMjrDBVAWLEbQS9Oa8iLLbnOdc/P/Y83XYs/VnWYhPG27PM9NJmUZR8UgOFlnTBFvlWxVdok1Yc+te68tsVnR+/uquB/k5tduajUMtL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHWLFcylcb+LepkETj3e3FxVNtZ1Gvw3ZqDNEpTux7uTs4cvywv59BfnXXQLDqJARTLpXfa1nhGvvs1uTpRzrQc63ZiYR9KF83cK7E1JNWtOo6S1x3vBugsMNoCG1aSf4KwQvv6OiqeihvwBXHf7vRR6jXECTXnufYCvYv5ayW3+160bLiSWPq5AlLA7GBs4xkT26VCnlBh/l785b4ZTHoOCQiOLo4R5aENUpJxU1IkDHoEYztXsBwl9zSMdQpvkkLmgpdyqc6fXQUry68zqlr0bZIFRcUpBKIcULF6THb0qLbPXZLQ7i+afAIgsri9L+KmyLChcZp+fggO3Rm5WCUjazRsB2GE3XzycFXP9hvgYm65D7KcYCVwyYOP1pWMDvAWf9TfQkIHCvdB9Go9FN8CI99iRRwUbqKkAZBJdHNxo8aJNeAiqKBRJoKTFqiBc7u/lyvUe7ruuQU5vwAryBQYcicyD+SFizo8VyDBeZK8SB0RovlkRSVozwnBgcnQ4tj"
	//str1 := "xGT7QAjRt1AHv5ZWIlWHAtoGuvIeps4gaGumMlFKZXbjy4OSvLdPjctL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHDCmSKvT/rBYoKa9UWOsvvSiCjFRf/I+Mmpo6zFcaX4tj5m9ZbgpYdr15pPbOYfWAXY6TGyhx2QYhhMWFSI3XBIPhb8T1GQWaLmRb9N3zWAYJJ2wLUX90J5bF60M46pW2jbVum6TlzJIuq6SptH4eoGOwwXgwlLXqFCzS0+suJwx9x+Mfa7vw494RR8lZg4x3RMf5eJruXwhMTX1I1VplM/WTT9MmXBR0SkaJ3mpQgEF7P6oZtRLLnYWYNt3GNtdB1maJzo/mDY3UfB6rptsVhfSjVLSqRLDgQeaa4IizboN5dy6BVzdeEZF+xuPfPcV5CPxDC80LVjxBorg1FH1WEYSj4goQQ/9AV48FwIf6upQzUEm2UCT+8CkGwhY299aN7MHBiAxBGCn+zo6Ii2nN81FC1m+yBUXsXobwWEBofwod2m7W86KkmERDfPaS8wsPvv68JE3KAlaz7cMi6ndiFd/qDDyKr3Kbwajyx0KLWF83cj2fuFspWYcI38Try7dmXvZYrdiDGU2KY8EsbZXiLlyLkgo4K2whOoUd9I+ZGzJJYSyZabMjrDBVAWLEbQS9Oa8iLLbnOdc/P/Y83XYs/VnWYhPG27PM9NJmUZR8UgOFlnTBFvlWxUq9NliF02uyRNabfyWjw1mB/k5tduajUMtL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHWLFcylcb+LepkETj3e3FxVNtZ1Gvw3ZqDNEpTux7uTs4cvywv59BfnXXQLDqJARTLpXfa1nhGvs/6yDOFdglapOqzswAC66ScK7E1JNWtOo6S1x3vBugsMNoCG1aSf4KwQvv6OiqeihvwBXHf7vRR/1M+cYK4ga+4awBAN8vnHbXTerR7FBgm/XypMN+PHMxtOeI6Cc92Wsu+qZ+65ds0LvMMa6cD9cK816H4TcdVhIlDU1q4RtjMZ7eR5J8pPEGv9PWtrsWc6b3gM5nQUzVYbiithtuPkPIzuFTYXmTTUf2B0fp++kfMU5toilu4zi4vhks6BnF5s/aOYed2lGnrQyMD9lQ90QQ9rqP9CfIGdC0+/Z+BdME/DC+JAVXEkTpj/GLKCazBp7asPgxwe0oJh0Bxlu5j0cQErHhz1mD7tHrJGexnfQogYj215R7Uo9Ra85Kueuc3G8sRygpVXnWRtdQGurQunqZP+YvRm5yzW9jqK28HS6Vs2HFuYgh0dXB0LqxoLGpovDkxwhH1lYI2DlhUBc/PHD0DTI2lSXFRW5rzkq565zcbwsemHeyT/YAReOg5Ie4ToJZvam4KdDe+cpLxNJoFtkDHAzuKU8ziiHIfczq90l6wX/JDq1SOtQTy5W3mHGF6qI="
	str2 := "xGT7QAjRt1AHv5ZWIlWHAtoGuvIeps4gaGumMlFKZXbjy4OSvLdPjctL7cZpp2zKhhnttLk4AJ4uNrJEQ2DtL1UBLGIoX+mHDCmSKvT/rBYoKa9UWOsvvSiCjFRf/I+Mmpo6zFcaX4tj5m9ZbgpYdr15pPbOYfWAXY6TGyhx2QYhhMWFSI3XBIPhb8T1GQWaLmRb9N3zWAYJJ2wLUX90J2TPtI+tabkJjbVum6TlzJIuq6SptH4eoGOwwXgwlLXqFCzS0+suJwxLgFbSLqZvyDcpmwNqmzAVDy5qfJ1Y32LEYW+n3I5L+Xl/k6Ob26rlxHVfAevdlLqgmJc3CRyMUYWYNt3GNtdB1maJzo/mDY3UfB6rptsVhfSjVLSqRLDgQeaa4IizboN5dy6BVzdeEZF+xuPfPcV5CPxDC80LVjxBorg1FH1WEYSj4goQQ/9ArJ0tdpgjsr8Hfka6fJwWtcUwAcYYUNw3VYtOPZm4J3RKue8CbcWmVFFC1m+yBUXsXobwWEBofwod2m7W86KkmERDfPaS8wsPEC0l7FpmDUt5RMB/q/6tpUGqIr16GRRRZChksgdfeq8mmZKs6/WNleewfmd3HMmxkh0BGFSE4reeE/IDrdCldSVAFHHNZJcokzZGaLN7yFqU/iiG4zP6w83yDnHIHT4dpjVEGwnL5t0/O0B+6c0BwPu9sfa/gAimpghQix4v5oMqN5pDG7jK9pqaOsxXGl+LY+ZvWW4KWHa9eaT2zmH1gF2OkxsocdkG64T+qUvnUrWWCEqG41Y4MCgivGHkp9kizisTT+x1CJ1grglavDTViTKBxX3/46bJ/lyvUe7ruuTyx+HJP38TPNL7J02U35FE/tcRPo78Ir/HeQSR8J/aWf4zKyiKDdrVKwxTbLGok1dH+yK9nNc5i3eTjVKU9MWbGubmlIcnv4CVgc706Vu2oW+gEZN8X0emRnlLgHIMPiSoEmXQLRoso3rRsuJJY+rks3qffdOziA219fyS5qBUziuPRNda9muJn8B0MHZQX8K5DmdHhBQOMe412Ad0qXmXt+ZflATALTUrRWJga7GvJFtP0Vf+ESHY7KqJHbRVKG0/P/Y83XYs/TrnogAjTsYSNHVF51N1oHfcUiMx+2VajFCTERRWFlLkp6sNObumRHbIfb0D5FaL1JXfuJDMRfAgXmjH9UWXsMazQDWVy01YlVWSJxENidT1chu8p6F5YwZRugv8GPKyM5vwcM4G6/d5KGD+dIhtCj7rJGexnfQogaKziJLIzOP7iIrCvs8+p1F99tUfMxySvMKG4Ch5w8gYHkUZwtV9gOTHJAGuFz3bpsRKDL6Np7MmZUVEraQQcGLXt1vZcDnoykSDlAU0IqR9TFd6i9VJIspXRL/7zBynpcRhFRq2PVMXv4EI+VsvaYEhGNQyYnh4PXYUF/Pvx1LxbXGbGXXQidPoQehwpWtYgLTmtOMcCVoZV8OeEFbDH0+rcOBgyf5n9JktJfbTpCDG/jMrKIoN2tWldrP1b9FH7DapPkDLzdpD"
	out, _ := base64.StdEncoding.DecodeString(str2)

	outbuff, _ := DESECBDecrypt([]byte(out), []byte("ISSMOB01"))

	fmt.Println(string(outbuff))
	fmt.Println("11111111111111111111111")
}

func TestAesEcbEncrypt(t *testing.T) {
	outBuff, _ := AesECBEncrypt([]byte("3370445660"), []byte("eca@ecb_20170101"))
	str := base64.StdEncoding.EncodeToString([]byte(outBuff))
	fmt.Println(str)
}

func TestTimeEnc(t *testing.T) {

	baseTime := utils.GetTimeStampEx()
	strBaseTime := strconv.FormatInt(baseTime,10)
	MesBasicTime , _:= encTimestamp(string(strBaseTime))

	fmt.Printf(MesBasicTime)


}


//
func TestSM4EcbDecrypt(t *testing.T) {
	//str :="AYkzKXWWSZOXOShYlIJZYhRCFVmFEyaJaYcyB1kIAJUzk5ZFlkMJlUeZSWMGhHQWVBRyUAMCZWUSmZYiABRDOXkJR1BWMJYSkQM3WWRzVZZZElIglGlzSDRgNBMAEFWGYiMyGFOYWXRAhpl3QjSVgpNUB3J4EkICcpc4V5BgAokjY4gjMxhCU2hQQAkTdSiJMBVEgFNUF3FyUnSI"
	//out, _ := base64.StdEncoding.DecodeString(str)
	//out2, err :=hex.DecodeString("6b2b3d2db1814bf4b4c9764a082e9472")
	//
	//if err != nil{
	//	fmt.Println(err)
	//}
	//fmt.Println(hex.Dump(out2))
	//outBuff, _ :=  psbc.SM4Decrypt(out,out2)
	//
	//fmt.Println(hex.Dump(outBuff))
	//fmt.Println("11111111111111111111111")
	//a1,_ := new(big.Int).SetString("20037657662302395838317181478475305075102838570714963951685613892252070796921201869804112496724742460066121646340946903742589534604361701371914735530734348284996805558704432905867120399172504489393472383476761679502839408738696989156897645465334307045174784572047434193722590909634135561688942265900148611398016",10)
	//a1.Rsh(a1,7)
	//a, _ := new(big.Int).SetString("156544200486737467486852980300588320899240926333710655872543858533219303100946889607844628880662050469266575362038647685488980739096575791968083871333862095976537543427378382077086878118535191323386502995912200621115932880771070227788262855197924273790428004469120579638457741481516684075694861452344911026547", 10)
	//b, _ := new(big.Int).SetString("deed24b33ff3fdaa0bf675e0f705b856a9313a107ce379ea847dd68583c7807ea44f1542ad9a8cac3e809d534d3597eaecca272df7b5a72a180daf6c0c995e224fce7697eb60c5827a4be1e786d44341ce7415d8bda9042e50700131968d3c2a791c8619bafb50ee715a1d923a66d54e9554525a9e1bab598ab273a9ff515973", 16)

	//fmt.Println(hex.Dump(a1.Bytes()))
	//fmt.Println(hex.Dump(a.Bytes()))
	//fmt.Println(hex.Dump(b.Bytes()))


	aaa := 1+6+0+3+5+6+1+9+9
	bbb := 4+6+5+1
	fmt.Println((aaa+1)*(bbb+1) %  224 +1)

	//214085508dceab354ea8d2df23d0f9ece84d51da280eeab772d1a261dcee9f046cba77a83805e0cb0b7f22b7252e5d1f70f573d5d60acebffbea47cae3ccfcaa63ff975533bdb2c3c9f01e33b8fc4aa533dfaefaa64985a48f35b05d20818f6baa9584b6ec3cbc33f8a886e12d2623fbded5dbe9f2651c3aff76f8e815912375

	messstr,_:= calculationRandomNumber("AVZVE2Y5FSgxGAh1BDSTFUV5cYVEEXmYIFCCMYBVEnOVASFSI0eXhzlHKQYmF5hJVzgxUzRURIWEUldjFRJTRpkxIGCAlnIGd0FHkkN4cVQxlEJUgzlGWHeFYVITkpJSUVU0OGAxQAWZNpAmVYESSFNwBQBjUhmHOGQGE0YANUKUCIBSQRJXOZiQWBYFNoglSTRjSYZkNgdjg3BW")

	fmt.Println(messstr)

	//res := getCalculateRandomNumberForString("1603444428599")
	//
	//fmt.Println(res)


	str1 := "yIkbFXX1vrBpQMHEe4ATzc3aWHlHPnJrwmwCrVgL/rrvZc3478zvzjqqddL0GQxX82vy2Tdpz7mPXkTyr0uhHvTzDO0/qzEO1Xmy7gBtpOMPZOaxDQJzfhbO1yvQlcyKpkak2GkDz8efkXjvyP+tkqad05eDNvTC/9NE4ODWx8EnaseM6Ib/ZVGOY6vVb42s"

	out1, _ := base64.StdEncoding.DecodeString(str1)
	deCode,_ := deRespBody(out1,messstr,"1612252183768")

	deCode = strings.Replace(deCode, "\r\n", "", -1)
	deCode = strings.Replace(deCode, "\n", "", -1)
	deCode = strings.Replace(deCode, " ", "", -1)

	fmt.Println(deCode)


}

func TestSm4En(t *testing.T) {
	reqData, _ := json.Marshal(map[string]interface{}{"BankId":"9999","UserId":"","clientVersion":"7.1.0","NewVersion528Flag":"Y","MessTimeStamp":"1604050188897"})

	//newData,_:= dealInData(reqData)

	//fmt.Println(hex.Dump(newData))
	//out1,_ := dealInData(reqData)
	out2, _ :=hex.DecodeString("876e6232b103183d04100690a93283ac")
	fmt.Println(hex.Dump(reqData))
	fmt.Println(hex.Dump(out2))
	outBuff,_ := psbc.SM4ECBEncrypt(reqData,out2)

	fmt.Println(base64.StdEncoding.EncodeToString(outBuff))


}

func TestSM4Key(t *testing.T) {
	mNum := "047afc25b40c4a4fec8f964586d1a52b7c3c7ef21b7908d1d5e664aa086bd5caca29468eaac96163e803c2c6d336fcc6c8915830bee1740dc88f1e9bdb07590b09c8f4b1fb97dad5ddf59cb402f6cb437e932d2c3f39df2e216893d9dec2a7713dd16bfa19209195f4c372c9ac4de01d6a8a701456d6bf936f4a6d4719d24968"
	str,_:= calculateSm4key(mNum,"1604132504264")
	fmt.Println(str)
}
