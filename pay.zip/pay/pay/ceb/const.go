package ceb

const (
	cebAccountKey       = "CEBAccount"
	cebCookieKey        = "CEBCookie"
	timerUpdate         = 1000
	timerUpdateInterval = 5000
	resCodeSuccess      = "000000"
)

const (
	appID         = "bopAP625"
	appVersion    = "8.0.62"
	clientVersion = "8.0.6"
	signature     = "2a3007842b9275e04a821a2bd01d6c0f" //版本变化需要修改
	headerSalt    = "ZJC2RE3BV6N4J2I5A4NG35O56VM6BM80X23QPX"
	bankID        = "9999"
	cityID        = "110102"

	colletSdkVersion = "2.1"
	colletappID      = "6a8e2839a170a96c6bb4a94f6bd31835"
	colletSdktype    = "iOS"
	colletAppVersion = "7.1.5"
	timesm2_x        = "7FB94C40A82EFF8020A560B58B29F762A14B750B433120E222DD8E2C50F354B4"
	timesm2_y        = "DB27632DF7A6CE55006CD395807CFFD97572731B2A56101EFEB3A4A7001364EE"
)

const (
	urlGetBasicMsg           = "https://mobile.cebbank.com/cebclient/GetBasicMsg.do"
	urlFetchPublicKey        = "https://mobile.cebbank.com/cebclient/FetchPublicKey.do"
	urlGetToken              = "https://mobile.cebbank.com/cebclient/F2.do" //7.10版本改变链接
	urlClientNoticeList      = "https://mobile.cebbank.com/cebclient/ClientNoticeList.do" //添加行为检测
	urlQueryDAIFA            = "https://mobile.cebbank.com/cebclient/QueryDAIFA.do"
	urlGetMobilToLogin       = "https://mobile.cebbank.com/cebclient/GetMobilToLogin.do"      //添加行为检测
	urlFiDoLoginAndPayQuery  = "https://mobile.cebbank.com/cebclient/FiDoLoginAndPayQuery.do" //添加行为检测
	urlRegistGeTui           = "https://mobile.cebbank.com/cebclient/RegistGeTui.do"
	urlActQryPre             = "https://mobile.cebbank.com/cebclient/ActQryPre.do"
	urlQryAddressForCardLogo = "https://mobile.cebbank.com/cebclient/QryAddressForCardLogo.do"
	urlActTrsQry             = "https://mobile.cebbank.com/cebclient/ActTrsQry.do"
	urlToLogin               = "https://mobile.cebbank.com/cebclient/Tologin.do"
	urlLogin                 = "https://mobile.cebbank.com/cebclient/login.do"
	urlToSendSMSPwd          = "https://mobile.cebbank.com/cebclient/ToSendSMSPwd.do" //添加行为检测
	urlNewDeviceSendSMS      = "https://mobile.cebbank.com/cebclient/NewDeviceSendSMS.do"
	urlSendSMSPwd            = "https://mobile.cebbank.com/cebclient/SendSMSPwd.do"
	urlTransferBankQry       = "https://mobile.cebbank.com/cebclient/TransferBankQry.do"
	urlBankTransferPre       = "https://mobile.cebbank.com/cebclient/BankTransferPre.do" //添加行为检测
	urlBankTransfer          = "https://mobile.cebbank.com/cebclient/BankTransfer.do"
	urlBankTransferConfirmNew   = "https://mobile.cebbank.com/cebclient/BankTransferConfirmNew.do"
	urlWhiteCifGrayscale     = "https://mobile.cebbank.com/cebclient/WhiteCifGrayscale.do"
	urlExcellentFinancing    = "https://mobile.cebbank.com/cebclient/ExcellentFinancing.do"
	urlHomePageFloorPictureQry    = "https://mobile.cebbank.com/cebclient/HomePageFloorPictureQry.do"

	urlEcifGrantDevice = "https://mobile.cebbank.com/cebclient/EcifGrantDevice.do" //7.10新
	urlQueryMarqueeData = "https://mobile.cebbank.com/cebclient/queryMarqueeData.do"
	//5.1.23更新
	urlNewBankTransferPayeeList = "https://mobile.cebbank.com/cebclient/NewBankTransferPayeeList.do"
	urlCollet                   = "https://ecad2.cebbank.com/mobile/collect.do"
	urlInitMobileApp            = "https://ebpm.cebbank.com:8443/initMobileApp?version=2.2.6"
	urlGetMerchantParams        = "https://mobile.cebbank.com/cebclient/getMerchantParams.do"
	urlActTrsQryPre             = "https://mobile.cebbank.com/cebclient/ActTrsQryPre.do"
	urlIsPwdNull                = "https://mobile.cebbank.com/cebclient/IsPwdNull.do"
	urlMineCreditQryPre         = "https://mobile.cebbank.com/cebclient/MineCreditQryPre.do"

)

var (
	aesKey = []byte{
		0xF3, 0x7C, 0x3F, 0x16, 0x8D, 0xE9, 0x31, 0x7F, 0xB4, 0xA3, 0x39, 0xC6, 0x71, 0x0E, 0xBA, 0x63,
		0x80, 0xF4, 0x25, 0xD1, 0x42, 0xDF, 0xEE, 0x54, 0xF7, 0x13, 0x80, 0x1B, 0xCC, 0xA2, 0x4D, 0xB2,
		0xF8, 0x3A, 0x68, 0x1F, 0x72, 0xB1, 0x51, 0xB0, 0x87, 0xF6, 0xFB, 0xB3, 0x8E, 0x32, 0xD5, 0xAA,
		0xF9, 0x02, 0xEC, 0x57, 0x4B, 0x8B, 0x01, 0x52, 0x3B, 0xB3, 0x57, 0x61, 0xD1, 0x8C, 0xEA, 0xC7,
		0x1A, 0x30, 0x00, 0xF0, 0xC8, 0xBE, 0x8F, 0x5E, 0x5E, 0x9E, 0xA2, 0x86, 0x96, 0xF9, 0x3E, 0x41,
		0x03, 0xBD, 0x7F, 0x2B, 0x4F, 0x19, 0x39, 0xE9, 0x1D, 0xDE, 0xEA, 0x01, 0x46, 0xA3, 0x3C, 0x34,
		0x64, 0x47, 0x6F, 0xBD, 0x40, 0xFC, 0x0C, 0x55, 0x3A, 0x05, 0xF9, 0xF1, 0xCC, 0x2B, 0x71, 0x75,
		0xA5, 0x3B, 0xD8, 0x5D, 0xB9, 0xDE, 0x7D, 0x30, 0x01, 0xB9, 0x93, 0x97, 0xC0, 0x7A, 0xB8, 0x55,
	}

	rcKey = []byte{
		0x8F, 0x69, 0xBE, 0xDA, 0xB4, 0x9C, 0x41, 0x88, 0xAD, 0x87, 0xE1, 0x4A, 0x57, 0xAC, 0x9D, 0x74,
		0xEE, 0x0F, 0xE3, 0x3E, 0x0D, 0x42, 0x2A, 0x2C, 0x83, 0xD5, 0xEF, 0x7C, 0x2C, 0x1D, 0xCF, 0x96,
		0x26, 0x58, 0x9F, 0xE0, 0x45, 0xB2, 0xFB, 0xEA, 0xEE, 0x20, 0x19, 0xAB, 0x99, 0x83, 0x75, 0x37,
		0xDF, 0xF7, 0x6A, 0xD3, 0x0E, 0x09, 0x38, 0x22, 0x12, 0x53, 0x1F, 0x30, 0x2F, 0x5C, 0x07, 0x7E,
		0xBC, 0xA4, 0x16, 0x7B, 0x4C, 0xE3, 0x51, 0x64, 0x6C, 0xB5, 0x0D, 0x02, 0x8C, 0x87, 0xDC, 0xAD,
		0xB6, 0x96, 0x09, 0xC0, 0xA8, 0x5A, 0x16, 0xDD, 0xA4, 0x42, 0x79, 0x27, 0x5E, 0xBF, 0x4E, 0x21,
		0x8E, 0xFB, 0x48, 0x0C, 0xE4, 0x5E, 0x6A, 0x4C, 0xEB, 0x53, 0x7F, 0xE1, 0x07, 0xC6, 0x6D, 0xBF,
		0xC1, 0xB3, 0x8D, 0x33, 0x85, 0x40, 0xDC, 0x28, 0x38, 0x37, 0x3A, 0x29, 0xE3, 0x25, 0x61, 0x2D,
	}
)
