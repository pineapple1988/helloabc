package ceb

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"pay/pay"
	"pay/pay/psbc"
	"pay/tools"
	"pay/utils"
	"pay/utils/logger"
	"strconv"
	"strings"
	"time"

	"github.com/go-http-utils/headers"
)

/***
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","_app_clientVersion":"8.0.6","MesBasicTime":"0406e51fec8447b8300b0e58a714ad94cd6f829bf5d028eec4a9fbb9abf8c7048792b077adbda090134e31d7d5339a732b26f0894634a92120bd1af0039c3861d706dd16b76717cff051c2b13ad619a456ac4cb5b8326ddc339c82cdeeb19f43e473e1ff5dec780dd204229955ae"}


*/

/***
回包：

{
    "head":{
        "IBSReturnCode":"000000"
        ,"IBSReturnMsg":""
        ,"TransCode":"GetBasicMsg"
    }
   ,"MessageNum":"AgZIhgdmcpIZIVU4QTAUhiBlSHFDaIIBiSgIOVgSUzlCBkghUFGBcCRWSXVRSZczJ4dZZWMFBSJE
chgDMQZgBVdydDVDCZcVIRM3h0UpdVdFhJRIAYlRKReVZyOACCExYUNoVjFZdGhZR5OEkiCXYpMF
dDIllVVFaGFGEjMDAggEBwWXRzaIk5dGI1FGkpJFdpWIUoVmmQVCEpZk"
   ,"Flag":"Y"
}


*/

func (acc *Account) getBasicMsg() (*getBasicMsgRes,error){


	baseTime := utils.GetTimeStampEx()
	MesBasicTime , err:= encTimestamp(strconv.FormatInt(baseTime,10))
	fmt.Println(MesBasicTime)
	if err != nil {
		return nil,err
	}
	reqData,err := json.Marshal(map[string]interface{}{
		"BankId":          bankID,
		"clientVersion":   clientVersion,
		"NewVersion528Flag": "Y",
		"MesBasicTime":       "04" + MesBasicTime,
		"_app_clientVersion":clientVersion,//8.0.6新增
	})

	req, err := http.NewRequest("POST", urlGetBasicMsg, bytes.NewReader(reqData))
	if err != nil {
		logger.Errorf("[CEB][%+v]getBasicMsg创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")

	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), ""))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]getBasicMsg http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]getBasicMsg http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	res := getBasicMsgRes{}

	//去除换行回车符号
	body = strings.Replace(body, "\r\n", "", -1)
	body = strings.Replace(body, "\n", "", -1)
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[CEB][%+v]getBasicMsg反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	messageNum := res.MessageNum

	acc.messageNumString,_= calculationRandomNumber(messageNum)


	//acc.getfetchPublicKeyCollet()

	return &res, nil
}


/**
发包：
{"BankId":"9999","clientVersion":"8.0.6","_app_clientVersion":"8.0.6","checkFlag":"test","MessTimeStamp":"1616746068168","Signature":"53d1b119645b1e45daf5963283f193d1","NewVersion528Flag":"Y"}


回包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"FetchPublicKey"},"AdvId":"","picurl":"","detailurl":"","AdvFlag":"","SM2Key":"WwCtLHPX4c40en+Dk/hMq1HOnaVIc9EgYfalVYEEgt2naQ+fgQr/ZleljkMUghMUsIF4X1yni226kjiIg4oXwQ==","SM4Key":"a509bc46f3cd288ea90bc510d35dffc2","Timestamp":"20210326160746","_CSII_TIMESTAMP":"1616746066985","FidoLoginOpenFlag":"1","FidoPayOpenFlag":"1","FaceLoginOpenFlag":"1","voiceLoginOpenFlag":"1","GDMapSwitch":"on","clientVersion":"8.0.6","channelIdVision":"HTTP.IPHONE","VersionType":"2","VersionValue":"5a6J5b+D6L+H5bm05rip5pqW5LiN57y65bit77yM57q/5LiK6YeR6J6N5pyN5Yqh5pu05pqW5b+D77yM5b+r5p2l5pu05paw5omL5py66ZO26KGM","HighestVersion":"8.0.6","UploadUrl":"http://itunes.apple.com/cn/app/id447733826?mt=8","AgreementHighestVersionNo":"1.1","APPUpdate":""}
 */

func (acc *Account) testFetchPublicKey() (*fetchPublicKeyRes, error) {

	baseTime := "1604050187475"
	reqData, err := json.Marshal(map[string]interface{}{
		"clientVersion":   clientVersion,
		"checkFlag":       "test",
		"Signature":       signature,
		"BankId":          bankID,
		"NewVersion528Flag":"Y", // 7.10版本新字段
		"MessTimeStamp":baseTime, // 7.10版本新字段
	})

	//reqDataRes:= map[string]interface{}{
	//	"clientVersion":   clientVersion,
	//	"UserId":       	"",
	//	"BankId":          bankID,
	//	"NewVersion528Flag":"Y",
	//	"MessTimeStamp":"",
	//}

	//处理输入数据
	newReqData,_:= dealInData(reqData)

	fmt.Println(hex.Dump(newReqData))
	//计算sm4key
	sm4key,_:= calculateSm4key("b7ae2a413d9637b18e2afa120f5f67f4f502b289a40c4b20a9ef0da5a7b8140fa500a66decf241912d8d9e2f57d12d1764d9c48d49069b5380a6b105470d97d0e45a3010ebcc7b05ae72dfdc646b5605fc25c5185bf5976911ee2150da6876e6232b103183d04100690a93283ac2344da9220f04e4435206d02e5c2848099fd5",baseTime)
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData1,_ := psbc.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData1)

	if err != nil {
		logger.Errorf("[CEB][%+v]fetchPublicKey1序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlFetchPublicKey,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]fetchPublicKey1创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", baseTime)
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), ""))

	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]fetchPublicKey1 http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]fetchPublicKey1 http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := psbc.SM4ECBDecrypt(bReponData,bSm4key)

	newData,_:= dealRespData(deCode)
	println(hex.Dump(newData))
	fmt.Println(string(newData))
	//calculateSm4key()

	strNewDecode := string(newData)

	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)

	resResp  := fetchPublicKeyRes{}
	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]fetchPublicKey1反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPublicKeyCollet()
	return &resResp, nil
}

func (acc *Account) fetchPublicKey() (*fetchPublicKeyRes, error) {

	//获取时间撮

	signTime := utils.GetTimeStampEx()



	baseTime := utils.GetTimeStampEx()
	reqData, _ := json.Marshal(map[string]interface{}{
		"clientVersion":   clientVersion,
		"checkFlag":       "test",
		"Signature":       signature,
		"BankId":          bankID,
		"NewVersion528Flag":"Y", // 7.10版本新字段
		"MessTimeStamp":strconv.FormatInt(baseTime,10), // 7.10版本新字段
	})

	resResp  := fetchPublicKeyRes{}


	if _, err :=  acc.NewPostHTTPData(urlFetchPublicKey,strconv.FormatInt(signTime,10),strconv.FormatInt(baseTime,10),reqData,&resResp); err != nil {
		// logger.Errorf("[CEB]clientNoticeList请求错误: %+v.", err)
		return nil, err
	}

	acc.sm4Key = resResp.SM4Key
	acc.sm2Key = resResp.SM2Key
	//acc.getfetchPublicKeyCollet()
	return &resResp, nil
}

func (acc *Account) fetchPublicKey1()  (*fetchPublicKeyRes, error) {
	//获取时间撮
	baseTime := utils.GetTimeStampEx()

	reqData:= map[string]interface{}{
		"clientVersion":   clientVersion,
		"checkFlag":       "test",
		"Signature":       signature,
		"BankId":          bankID,
		"NewVersion528Flag":"Y", // 7.10版本新字段
		"MessTimeStamp":strconv.FormatInt(baseTime,10), // 7.10版本新字段
		"_app_clientVersion":clientVersion,//8.0.6新增
	}
	//reqDataRes:= map[string]interface{}{
	//	"clientVersion":   clientVersion,
	//	"UserId":       	"",
	//	"BankId":          bankID,
	//	"NewVersion528Flag":"Y",
	//	"MessTimeStamp":"",
	//}
	resResp  := fetchPublicKeyRes{}
	respstr,_:= acc.NewPostHTTPData(urlFetchPublicKey,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}





	return &resResp, nil

}


//func (acc *Account) fetchPublicKey1()  (*fetchPublicKeyRes, error) {
//	//获取时间撮
//	baseTime := utils.GetTimeStampEx()
//	reqData, err := json.Marshal(map[string]interface{}{
//		"clientVersion":   clientVersion,
//		"checkFlag":       "test",
//		"Signature":       signature,
//		"BankId":          bankID,
//		"NewVersion528Flag":"Y", // 7.10版本新字段
//		"MessTimeStamp":strconv.FormatInt(baseTime,10), // 7.10版本新字段
//	})
//
//	reqData1:= map[string]interface{}{
//		"clientVersion":   clientVersion,
//		"checkFlag":       "test",
//		"Signature":       signature,
//		"BankId":          bankID,
//		"NewVersion528Flag":"Y", // 7.10版本新字段
//		"MessTimeStamp":strconv.FormatInt(baseTime,10), // 7.10版本新字段
//	}
//	//reqDataRes:= map[string]interface{}{
//	//	"clientVersion":   clientVersion,
//	//	"UserId":       	"",
//	//	"BankId":          bankID,
//	//	"NewVersion528Flag":"Y",
//	//	"MessTimeStamp":"",
//	//}
//	resResp  := fetchPublicKeyRes{}
//	respstr,_:= acc.NewPostHTTPData(urlFetchPublicKey,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData1,&resResp)
//	fmt.Println(respstr)
//	resMessEncryptData1 := messEncryptDataRes{}
//	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
//		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
//		return nil, pay.ErrUnmarshalResponseData
//	}
//
//
//
//
//	//处理输入数据
//	newReqData,_:= dealInData(reqData)
//
//	fmt.Println(hex.Dump(newReqData))
//	//计算sm4key
//	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
//	bSm4key, _ := hex.DecodeString(sm4key)
//	//body Sm4加密
//	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
//	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
//	enData1,_ := psbc.SM4ECBEncrypt(newReqData,bSm4key)
//	strEncodeBody := base64.StdEncoding.EncodeToString(enData1)
//
//	if err != nil {
//		logger.Errorf("[CEB][%+v]fetchPublicKey1序列化请求数据错误: %+v.", acc.Account, err)
//		return nil, pay.ErrMarshalRequestData
//	}
//
//	req, err := http.NewRequest("POST", urlFetchPublicKey,  strings.NewReader(strEncodeBody))
//	if err != nil {
//		logger.Errorf("[CEB][%+v]fetchPublicKey1创建http请求错误: %+v.", acc.Account, err)
//		return nil, pay.ErrCreateHTTPRequest
//	}
//
//	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
//	req.Header.Set(headers.Accept, "application/json")
//	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
//	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
//	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
//	req.Header.Set("USESSL", "0")
//	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
//	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), ""))
//
//	body, err := utils.DoHTTP(acc.http, req)
//
//	if err != nil {
//		logger.Errorf("[CEB][%+v]fetchPublicKey1 http操作错误: %+v.", acc.Account, err)
//		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
//			return nil, pay.ErrOperationTimeout
//		}
//
//		return nil, pay.ErrOperationError
//	}
//
//	logger.Debugf("[CEB][%+v]fetchPublicKey1 http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))
//
//	resMessEncryptData := messEncryptDataRes{}
//	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
//		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
//		return nil, pay.ErrUnmarshalResponseData
//	}
//
//	//解密返回值
//	MessEncryptData := resMessEncryptData.MessEncryptData
//
//	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
//	deCode,_ := deRespBody(bReponData,acc.messageNumString,strconv.FormatInt(baseTime,10))
//
//
//
//	fmt.Println(deCode)
//	//calculateSm4key()
//
//
//
//	deCode = strings.Replace(deCode, "\r\n", "", -1)
//	deCode = strings.Replace(deCode, "\n", "", -1)
//	deCode = strings.Replace(deCode, " ", "", -1)
//	fmt.Println(deCode)
//
//
//	fmt.Println(deCode)
//	if err := json.Unmarshal([]byte(deCode), &resResp); err != nil {
//		logger.Errorf("[CEB][%+v]fetchPublicKey1反序列化返回数据错误: %+v.", acc.Account, err)
//		return nil, pay.ErrUnmarshalResponseData
//	}
//
//	fmt.Println(resResp)
//	acc.getfetchPublicKeyCollet()
//	return &resResp, nil
//
//}


/**
发包：
{"BankId":"9999","UserId":"","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746068597","_app_clientVersion":"8.0.6"}

回包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"WhiteCifGrayscale"},"TestFlag":"false"}
*/

func (acc *Account) WhiteCifGrayscale()  (*whiteCifGrayscaleRes, error) {
	//获取时间撮
	baseTime := utils.GetTimeStampEx()

	reqData1 := map[string]interface{}{
		"clientVersion":   clientVersion,
		"UserId":       	acc.UserID,
		"BankId":          bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}
	resResp  := whiteCifGrayscaleRes{}
	respstr,_:= acc.NewPostHTTPData(urlWhiteCifGrayscale,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData1,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil

}

func (acc *Account) HomePageFloorPictureQry()(*HomePageFloorPictureQryRes, error){
	//获取时间撮
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"clientVersion":   clientVersion,
		"UserId":       	acc.UserID,
		"BankId":          bankID,
		"NewVersion528Flag":"Y",
		"sortNo": "1",
		"firstCustomerSign":"Y",
		"cityCode":"",
		"cellType":"MineQuickQuery",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}


	resResp  := HomePageFloorPictureQryRes{}
	respstr,_:= acc.NewPostHTTPData(urlHomePageFloorPictureQry,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]HomePageFloorPictureQry反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil

}


/**
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746068883","_app_clientVersion":"8.0.6","version":"8.0.6"}

回包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"WhiteCifGrayscale"},"TestFlag":"false"}
*/

func (acc *Account) ExcellentFinancing()  (*ExcellentFinancingRes, error) {
	//获取时间撮
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"clientVersion":   clientVersion,
		"UserId":       	acc.UserID,
		"BankId":          bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"firstCustomerSign":"Y",
		"version":clientVersion,
		"_app_clientVersion":clientVersion,//8.0.6新增
	}



	resResp  := ExcellentFinancingRes{}
	respstr,_:= acc.NewPostHTTPData(urlExcellentFinancing,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]ExcellentFinancing反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil

}


//7.10数据
/*
{
  "deviceModel" : "iPhone7,2",
  "isJailBreak" : true,
  "batteryStatus" : 3,
  "country" : "KH",
  "cpuCoreNum" : 2,
  "batteryLevel" : -1,
  "wifiMac" : "b0:be:76:fe:bf:72",
  "cellIPAddress" : null,
  "systemUpTime" : 724520,
  "timeZone" : "Asia\/Shanghai",
  "appVersion" : "7.1.00(7.1.00)",
  "totalMemory" : 1024,
  "carrierOperator" : "中国移动",
  "freeDiskSpace" : 5.2927932739257812,
  "wiFiIPAddress" : "192.168.0.105",
  "diskSpace" : 14.891368865966797,
  "carrierMobileNetworkCode" : null,
  "appId" : "bopAP625",
  "cpuFrequency" : 1,
  "carrierAllowVoip" : true,
  "screenH" : 667,
  "osVersion" : "11.4.1",
  "internetType" : "notreach",
  "wifiName" : "wifi3312",
  "carrierIsoCountryCode" : null,
  "screenBrightness" : 0.48659676313400269,
  "deviceType" : "iPhone",
  "idfa" : "22D04092-EC2D-4B75-9062-9F177F335288",
  "idfv" : "BAD4DC10-13BA-45EF-9F4B-6DD7CD9E445F",
  "usedDiskSpace" : 9.5985755920410156,
  "os" : "iOS",
  "connectedToCellNetwork" : false,
  "carrierMobileCountryCode" : null,
  "usedMemory" : 79.00390625,
  "connectedToWiFi" : true,
  "deviceName" : "guapi444",
  "isEmulate" : false,
  "screenW" : 375,
  "sdkVersion" : "1.0.0",
  "clientId" : "AC1F0EB7-D0C1-45AF-ACAB-A6DF59FA4454",
  "isOpenGPS" : false,
  "macAddress" : "02:00:00:00:00:00",
  "language" : "zh",
  "tokenId" : null,
  "resolution" : "750.000000*1334.000000",
  "cpuType" : "arm64 v8"
}
*/


func (acc *Account) getToken() (*getTokenRes, error) {

	rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
	diskSpace := float32(29.792522430419922)
	usedDiskSpace := float32(rnd.Float32()) + float32(utils.RandInt(3, 10))
	reqData, err := json.Marshal(map[string]interface{}{
		"deviceModel":              acc.HardwareInfo.Model,
		"IsJailBreak":              false,
		"batteryStatus":            2,
		"country":                  "cn",
		"cpuCoreNum":               6,
		"batteryLevel":             -1,
		"wifiMac":                  acc.HardwareInfo.WIFIMac,
		"cellIPAddress":            nil, //5.1.23更新有数据 公网地址
		"systemUpTime":             utils.RandInt(1201, 256841),
		"timeZone":                 "Asia/Shanghai",
		"appVersion":               appVersion,
		"totalMemory":              3840,
		"carrierOperator":          acc.HardwareInfo.Carrier,
		"freeDiskSpace":            diskSpace - usedDiskSpace,
		"wiFiIPAddress":            acc.HardwareInfo.WIFIIPAddress, //5.1.23更新新加
		"diskSpace":                59.546009063720703 + rnd.Float32(),
		"carrierMobileNetworkCode": "02",
		"appId":                    appID,
		"cpuFrequency":             1,
		"carrierAllowVoip":         true,
		"screenH":                  acc.GetScreenHeight(),
		"osVersion":                acc.HardwareInfo.OSVersion,
		"internetType":             "notreach",
		"wifiName":                 acc.HardwareInfo.WIFIName,
		"carrierIsoCountryCode":    "cn",
		"screenBrightness":         rnd.Float32(),
		"deviceType":               "iPhone",
		"idfa":                     acc.IDFA,
		"idfv":                     acc.IDFV,
		"usedDiskSpace":            usedDiskSpace,
		"os":                       "iOS",
		"connectedToCellNetwork":   false,
		"carrierMobileCountryCode": "460",
		"usedMemory":               float32(utils.RandInt(50, 80)) + rnd.Float32(),
		"connectedToWiFi":          true,
		"deviceName":               acc.HardwareInfo.DeviceName,
		"isEmulate":                false,
		"screenW":                  acc.GetScreenWidth(),
		"sdkVersion":               "1.0.0",
		"clientId":                 acc.ClientID,
		"isOpenGPS":                false,
		"macAddress":               "02:00:00:00:00:00",
		"language":                 "zh",
		"tokenId":                  nil,
		"resolution":               fmt.Sprintf("%.6f*%.6f", float32(acc.GetScreenWidth()*2), float32(acc.GetScreenHeight()*2)),
		"cpuType":                  "ARM64E",
	})

	if err != nil {
		logger.Errorf("[CEB][%+v]getToken序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	key := []byte(utils.MD5String(utils.NewRandString(10, false)))
	key = key[:16]

	reqBody := string(reqData)
	reqData, err = utils.AESCBCEncrypt(reqData, key, key)
	if err != nil {
		logger.Errorf("[CEB][%+v]getToken加密请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	encKey, err := encAesKey(key)
	if err != nil {
		logger.Errorf("[CEB][%+v]getToken加密aeskey错误: %+v.", acc.Account, err)
		return nil, pay.ErrEncRequestData
	}

	req, err := http.NewRequest("POST", urlGetToken, bytes.NewReader(reqData))
	if err != nil {
		logger.Errorf("[CEB][%+v]getToken创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set("rsa_key", encKey)
	req.Header.Set("sdk_platform", "2")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))

	body, err := utils.DoHTTP(acc.http, req)
	if err != nil {
		logger.Errorf("[CEB][%+v]getToken http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]getToken http请求成功, data: %s, body: %s.", acc.Account, reqBody, utils.ReplaceWhiteSpace(body))

	res := getTokenRes{}
	if err := json.Unmarshal([]byte(body), &res); err != nil {
		logger.Errorf("[CEB][%+v]getToken反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	return &res, nil
}

func (acc *Account) NewPostHTTPData(url ,time,messTimeStamp string, req, res interface{}) (string, error) {

	fmt.Println(req)
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[CEB][%+v]序列化请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	//logger.Debugf("[CEB]postHTTPData, url: %s, req body: %s.", url, string(arr))
	strEncodeBody,err :=  enPostBody(arr,acc.messageNumString,messTimeStamp)
	r, err := http.NewRequest("POST", url, strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}


	//r.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	r.Header.Set(headers.UserAgent, fmt.Sprintf("guang da yin xing/%s (iPhone; iOS %s; Scale/3.00)",appVersion, acc.HardwareInfo.OSVersion)) //8.0.0更新
	r.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	r.Header.Set(headers.Accept, "application/jsonIphone")
	r.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	r.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Set("USESSL", "0")
	if strings.Contains(url,"FetchPublicKey.do"){
		r.Header.Set("_CSII_JSON_SIGNATURE", sign(string(arr), ""))
	}else{
		r.Header.Set("_CSII_JSON_SIGNATURE", sign(string(arr), time))
		r.Header.Set("_CSII_TIMESTAMP", time)
	}

	r.Header.Set("MessTimeStamp", messTimeStamp)

	body, err := utils.DoHTTP(acc.http, r)
	if err != nil {
		logger.Errorf("[CEB[%+v]http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, url, string(arr), utils.ReplaceWhiteSpace(body))

	if strings.Contains(body, "会话已超时") {
		return "", pay.ErrSessionTimeout
	}

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]WhiteCifGrayscale反序列化返回数据错误: %+v.", acc.Account, err)
		return "", pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := deRespBody(bReponData,acc.messageNumString,messTimeStamp)

	deCode = strings.Replace(deCode, "\r\n", "", -1)
	deCode = strings.Replace(deCode, "\n", "", -1)
	deCode = strings.Replace(deCode, " ", "", -1)

	fmt.Println(deCode)
	if res != nil {
		if err := json.Unmarshal([]byte(deCode), &res); err != nil {
			logger.Errorf("[CEB][%+v]反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}



	return deCode, nil
}

func (acc *Account) postHTTPData(url string, req, res interface{}) (string, error) {
	arr, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[CEB][%+v]序列化请求数据错误: %+v.", acc.Account, err)
		return "", pay.ErrMarshalRequestData
	}

	//logger.Debugf("[CEB]postHTTPData, url: %s, req body: %s.", url, string(arr))
	r, err := http.NewRequest("POST", url, bytes.NewReader(arr))
	if err != nil {
		logger.Errorf("[CEB][%+v]创建http请求错误: %+v.", acc.Account, err)
		return "", pay.ErrCreateHTTPRequest
	}

	ts := fmt.Sprintf("%d", utils.GetTimeStampEx())
	r.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	r.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	r.Header.Set(headers.Accept, "application/jsonIphone")
	r.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	r.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	r.Header.Set("USESSL", "0")
	r.Header.Set("_CSII_JSON_SIGNATURE", sign(string(arr), ts))
	r.Header.Set("_CSII_TIMESTAMP", ts)

	body, err := utils.DoHTTP(acc.http, r)
	if err != nil {
		logger.Errorf("[CEB[%+v]http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return "", pay.ErrOperationTimeout
		}

		return "", pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]http请求成功, url: %s, data: %s, body: %s.", acc.Account, url, string(arr), utils.ReplaceWhiteSpace(body))

	if strings.Contains(body, "会话已超时") {
		return "", pay.ErrSessionTimeout
	}

	if res != nil {
		if err := json.Unmarshal([]byte(body), &res); err != nil {
			logger.Errorf("[CEB][%+v]反序列化响应数据错误: %+v.", acc.Account, err)
			return "", pay.ErrUnmarshalResponseData
		}
	}

	return body, nil
}


/**
发包：
{"BankId":"9999","clientVersion":"8.0.6","firstCustomerSign":"Y","isNewFlag":"1","_app_clientVersion":"8.0.6","MessTimeStamp":"1616746068409","NewVersion528Flag":"Y"}

回包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"WhiteCifGrayscale"},"TestFlag":"false"}
*/
func (acc *Account) clientNoticeList() (*clientNoticeListRes, error) {

	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"clientVersion":   clientVersion,
		"BankId":          bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"isNewFlag":"1",
		"firstCustomerSign":"Y",
		"_app_clientVersion":clientVersion,//8.0.6新增
	}


	resResp  := clientNoticeListRes{}
	respstr,_:= acc.NewPostHTTPData(urlClientNoticeList,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]clientNoticeList反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil
}

/**
queryMarqueeData
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746068879","_app_clientVersion":"8.0.6"}

收包：
{"head":{"IBSReturnCode":"validation.transcode.OrGroup.suspend","IBSReturnMsg":"功能维护中"}	}
 */


func (acc *Account) queryMarqueeData() (*queryMarqueeDataRes, error) {

	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"BankId": bankID,
		"clientVersion": clientVersion,
		"NewVersion528Flag": "Y",
		"MessTimeStamp": strconv.FormatInt(baseTime,10),
		"_app_clientVersion": clientVersion,
	}


	resResp  := queryMarqueeDataRes{}
	respstr,_:= acc.NewPostHTTPData(urlQueryMarqueeData,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]clientNoticeList反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil
}

/**
NewToSendSMSPwd
发包：
{"BankId":"9999","cityId":"110102","clientVersion":"8.0.6","_app_clientVersion":"8.0.6","TransName":"67","MessTimeStamp":"1616823765098","MobilePhone":"13390762271","MobileType":"iPhone9,2","NewVersion528Flag":"Y"}
收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"NewDeviceSendSMS"},"SignatureSendSmsMD5":"B7BEF4C10917AEF006860F3DA15F8DBE","NewDeviceDataMap":"NEOBTJGwPkOMVWBoSD81PVGkCTXAAAAEBcwASX0R5bmFtaWNQd2RPdXR0aW1lAUwNMTYxNjgyMzk0MTI2Mw=="}*/
func (acc *Account) getNewToSendSMSPwd() (*getNewToSendSMSPwdRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}


	reqData := map[string]interface{}{
		"BankId": bankID,
		"cityId": "110102",
		"clientVersion": clientVersion,
		"_app_clientVersion": clientVersion,
		"TransName": "67",
		"MessTimeStamp": strconv.FormatInt(baseTime,10),
		"MobilePhone": acc.Account,
		"MobileType":acc.HardwareInfo.Model,
		"NewVersion528Flag": "Y",
	}

	resResp := getNewToSendSMSPwdRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}


	respstr,_:= acc.NewPostHTTPData(urlNewDeviceSendSMS,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]getMobileToLogin反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	acc.newDeviceDataMap = resResp.NewDeviceDataMap
	acc.signatureSendSmsMD5 = resResp.SignatureSendSmsMD5
	return &resResp, nil
}

/**
IsPwdNull
发包：
{"NewDeviceDataMap":"NEMeLt3RLY3DggDd5JCAsul8CTXAAAAEBcwASX0R5bmFtaWNQd2RPdXR0aW1lAUwNMTYxNjc0NjQwOTIzMA==","_app_clientVersion":"8.0.6","clientVersion":"8.0.6","BankId":"9999","TokenPassword":"890392","NewDeviceFlag":"2","SignatureSendSmsMD5":"60E9AFC1C413BE37E18DC6CB1EC26B77","MobilePhone":"13390762271","MessTimeStamp":"1616746268893","NewVersion528Flag":"Y"}

收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"IsPwdNull"},"isPwdNull":"N"}
*/
func (acc *Account) geIsPwdNull(vcode string) (*geIsPwdNullRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}


	reqData := map[string]interface{}{
		"NewDeviceDataMap": acc.newDeviceDataMap,
		"_app_clientVersion": clientVersion,
		"clientVersion": clientVersion,
		"BankId": bankID,
		"TokenPassword": vcode,
		"NewDeviceFlag": "2",
		"SignatureSendSmsMD5":acc.signatureSendSmsMD5,
		"MobilePhone": acc.Account,
		"MessTimeStamp": strconv.FormatInt(baseTime,10),
		"NewVersion528Flag": "Y",
	}

	resResp := geIsPwdNullRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}


	respstr,_:= acc.NewPostHTTPData(urlIsPwdNull,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]getMobileToLogin反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

/**
QryCreditCardPoint
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746286873","_app_clientVersion":"8.0.6"}
收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"IsPwdNull"},"isPwdNull":"N"}

 */



/**
MineCreditQryPre
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746286887","_app_clientVersion":"8.0.6"}
收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"MineCreditQryPre"},"noCreditcard":"Y","ShowQueryPageRemindWordFlag":"","ContentValue":"","Logo":"","ReturnUrl":"","DetailUrl":"","ButtonName":"","titleBar":""			,"DefaultAcNo":"6226632001331839"			,"HideAcNo":"622663******1839"		,"AcId":"AAAb2SACHAAHcxVABs","cardList":[	]			,"RMBZQFLag":""												,"USAZQFLag":""									,"cardInfo":{				"CardNo":""				,"HideAcNo":""				,"AcId":""				,"Currency1":""				,"Currency2":""						,"CHNMemoBalance":"--"									,"CHNTotalAmountDue":"--"							,"CHNUnpaidAmount":"--"								,"CHNPaymentDueDate":"--"							,"BillingDate":"--"													,"IsCDC":""													,"hasForeCur":""																		}}
 */
func (acc *Account) getMineCreditQryPre() (*getMineCreditQryPreRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}


	reqData := map[string]interface{}{
		"BankId": bankID,
		"clientVersion": clientVersion,
		"NewVersion528Flag": "Y",
		"MessTimeStamp": strconv.FormatInt(baseTime,10),
		"_app_clientVersion": clientVersion,
	}

	resResp := getMineCreditQryPreRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}


	respstr,_:= acc.NewPostHTTPData(urlMineCreditQryPre,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]getMobileToLogin反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

/**
MineCreditQryPre
发包：
{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746286887","_app_clientVersion":"8.0.6"}
收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"MineCreditQryPre"},"noCreditcard":"Y","ShowQueryPageRemindWordFlag":"","ContentValue":"","Logo":"","ReturnUrl":"","DetailUrl":"","ButtonName":"","titleBar":""			,"DefaultAcNo":"6226632001331839"			,"HideAcNo":"622663******1839"		,"AcId":"AAAb2SACHAAHcxVABs","cardList":[	]			,"RMBZQFLag":""												,"USAZQFLag":""									,"cardInfo":{				"CardNo":""				,"HideAcNo":""				,"AcId":""				,"Currency1":""				,"Currency2":""						,"CHNMemoBalance":"--"									,"CHNTotalAmountDue":"--"							,"CHNUnpaidAmount":"--"								,"CHNPaymentDueDate":"--"							,"BillingDate":"--"													,"IsCDC":""													,"hasForeCur":""																		}}
*/

/**
发包：
{"_app_clientVersion":"8.0.6","DeviceCode":"019D6FC7-5630-4727-B5F6-AE4D8D69D7F5","UserId":"","clientVersion":"8.0.6","NewVersion528Flag":"Y","token":"4eXdJmCT8dNe4wQucQxcFXhvk\/fBWBbSaABEyZqfaZPgiK7GyPBNTA2zxYQfKTFXcLoci1aysscbVTjJA7TIshuyhIVN0zykwicF5rUdf4Qm+L9gjjM\/2+8otHtaftu+4qP1URgRbssomk76\/VUZBTAAy44UumjzUpMgcFIu0PAh9Ezm+NZ4CCvQbsLGw7PR","BankId":"9999","MessTimeStamp":"1616746066156","_locale":"Zh_CN","LoginType":"W","DeviceType":"iPhone9,2","City":"北京","checkFlag":"test"}


回包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"GetMobilToLogin"},"MobileNo":"","NewDeviceFlag":"2","DynamicSM4Key":"715f7b50e2edafab14bce895bef5deda","DynamicArrayKey":"","FaceOpenFlag":"","VoiceOpenFlag":"","loginFlag":"","UserId":"","SwitchFlag":"Y","IsPwdNullFlag":"Y"}
 */


func (acc *Account) getMobileToLogin(index int) (*getMobileToLoginRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}


	reqData := map[string]interface{}{
		"clientVersion":clientVersion,
		"UserId":acc.UserID,
		"DeviceCode":acc.UDID,
		"NewVersion528Flag":"Y",//7.10新
		"token":"",//acc.Token,//7.10新
		"BankId":bankID,
		"MessTimeStamp":strconv.FormatInt(baseTime,10),//7.10新
		"_locale":"Zh_CN",
		"LoginType":"W",
		"DeviceType":acc.HardwareInfo.Model,//7.10新
		"checkFlag":"test",
		"City":"定位失败",
		"_app_clientVersion":clientVersion,//8.0.6新增
	}
	resResp := getMobileToLoginRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}
	if index == 1 {
		acc.getMobileToLoginCollet()
	} else {
		acc.getMobileToLoginCollet1()
	}

	respstr,_:= acc.NewPostHTTPData(urlGetMobilToLogin,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]getMobileToLogin反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}


	return &resResp, nil
}

func (acc *Account) toSendSMSPwd(newDeviceDataMap string) (*toSendSMSPwdRes, error) {
	colletSleep(1000, 4000)
	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"cityId":        cityID,
	//	"clientVersion": clientVersion,
	//	"MobileType":    acc.HardwareInfo.Model,
	//	"MobilePhone":   acc.Account,
	//}

	reqData,err:= json.Marshal(map[string]interface{}{
		"BankId":bankID,
		"cityId":cityID,
		"clientVersion":clientVersion,
		"NewDeviceDataMap":newDeviceDataMap,
		"MessTimeStamp":strconv.FormatInt(baseTime,10),//7.10新,
		"MobilePhone":acc.Account,
		"NewVersion528Flag":"Y",//7.10新,
		"MobileType": acc.HardwareInfo.Model})
	resResp := toSendSMSPwdRes{}

	//处理输入数据
	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData,_ := tools.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//enPostBody(reqData,acc.messageNumString,strconv.FormatInt(baseTime,10))
	if err != nil {
		logger.Errorf("[CEB][%+v]toSendSMSPwd序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlToSendSMSPwd,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]getMobileToLogin创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
	req.Header.Set("_CSII_TIMESTAMP", strconv.FormatInt(baseTime - 100,10))
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), strconv.FormatInt(baseTime - 100,10)))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]toSendSMSPwd http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]toSendSMSPwd http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]toSendSMSPwd反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := tools.SM4ECBDecrypt(bReponData,bSm4key)
	//newData,_:= dealRespData(deCode)
	//println(hex.Dump(newData))
	fmt.Println(string(deCode))
	//calculateSm4key()

	strNewDecode := string(deCode)
	println(hex.Dump(deCode))
	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)


	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]toSendSMSPwd反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPub    licKeyCollet()

	return &resResp, nil
}

/**
发包：
{
  "clientVersion": "8.0.6",
  "TokenPassword": "652372",
  "_locale": "Zh_CN",
  "Password": "iS4ybGuUo+4pv7cVLHNfVmfAXJezX+nLiuwXoxddAt9lyxbL4haMZcriB+y2bh94HwdvCwaXgYnGyvUVRUp/CJ5Rgw28YgT40dtfHfE08yCocHrGFppIjt2gatI1r2X75hmUA4YKMntRDkajD2DQns1uiTC0P30xdgCVPSGdFFuMa5nhPMBWgoF2Dq4rBv3KjeQxv19wP+w8yzAk0I/RxL9K0JkB/UcMB5DsQ294Wxy4fFinvs/G/HFlyrpjbNCJ4SPTBROqCAZm1taixYUQbKL4xszi5qIqw6kniqGrokeDWiP93CTFQYINtknDZ0K/bukCfgHSbTL70d+DJbzyJQ==",
  "City": "定位失败",
  "_app_clientVersion": "8.0.6",
  "FiDoUpdateFlag": "Y",
  "NewVersion528Flag": "Y",
  "NewTipNoteBase64Flag": "Y",
  "BankId": "9999",
  "NewDeviceDataMap": "NEOBTJGwPkOMVWBoSD81PVGkCTXAAAAEBcwASX0R5bmFtaWNQd2RPdXR0aW1lAUwNMTYxNjgyMzk0MTI2Mw==",
  "DeviceDimension": "0.000000",
  "CityCode": "110102",
  "FidoSupportFlag": "N",
  "voiceData": "",
  "LoginStyle": "iIPzxLCROIG9ta10EPh64w==",
  "NewVersionSM2": "1",
  "DeviceLongitude": "0.000000",
  "MessTimeStamp": "1616823827279",
  "NewVersion": "Y",
  "NewDeviceFlag": "2",
  "SignatureSendSmsMD5": "B7BEF4C10917AEF006860F3DA15F8DBE",
  "LoginData": "~|~DeviceName=iPhone~|~City=定位失败~|~CityCode=110102~|~DeviceDimension=0.000000~|~DeviceLongitude=0.000000~|~DeviceCode=8E081EA8-63A0-4EAE-9A0F-695FEDE4B8FF~|~DeviceType=iPhone9,2~|~",
  "DeviceType": "iPhone9,2",
  "ClientIP": "192.168.8.116",
  "token": "",
  "MobilePhone": "13390762271",
  "faceData": "",
  "VersionFlag": "1",
  "sessionId": "",
  "DeviceName": "iPhone",
  "LoginType": "W",
  "DeviceCode": "8E081EA8-63A0-4EAE-9A0F-695FEDE4B8FF",
  "SecureCookie": "",
  "VersionNo": "iOS8.0.6"
}

收包：
{
  "head": {
    "IBSReturnCode": "000000",
    "IBSReturnMsg": "",
    "TransCode": "login"
  },
  "remindHeaderList": [],
  "ShowLottryFlag": "",
  "ShowCouponFlag": "",
  "ImgFlay": "",
  "MbankImg": "",
  "LoginLotteryFlag": "",
  "sessionid": "",
  "BLACKLISTFLAG": "",
  "OpenMBankFlag": "1",
  "UserId": "8138034422",
  "IdNo": "320112199101251658",
  "IdType": "1",
  "UserName": "谢超",
  "CifNo": "1883910107",
  "IsTranfer": "1",
  "IsToken": "0",
  "DefaultAcNo": "6226632001331839",
  "NeedSetDefaultAcNo": "",
  "CebKey": "3081890281810095275c6c211380ec6ae15d13093ee550d93553d9a3fb00fc010368d43b281cc47be70d90d79f7abd5e49368be06bc29cf03ed7da4c1e5424bc86caa2af7004cdfa16e7d1a9634772c47a8bcb05e29df5488d67697a981beefabda8aa8c878680f9dcd42c2d3595b7a808503e748d02a988a20766523f98b25ca7dd2c0d0251b70203010001",
  "TipNote": "MTIz",
  "SecureCookie": "",
  "CertExpireFlag": "",
  "CertDueDate": "20410113",
  "UserLastLoginTime": "2021-03-27",
  "WelcomeMessage": "**超先生,下午好!",
  "MobilePhone": "13390762271",
  "TokenCiflag": "",
  "code": "",
  "timeOutFlag": "",
  "acNoD": "",
  "VisitorFlag": "1",
  "isPhoneSetFace": "",
  "wordsInfo": ""
}

 */

func (acc *Account) toLogin(code string) (*toLoginRes, error) {
	baseTime := utils.GetTimeStampEx()
	key, err := hex.DecodeString(acc.dynamicSM4Key)
	if err != nil {
		logger.Errorf("[CEB]toLogin解码SM4密钥错误: %+v.", err)
		return nil, err
	}

	//加密logintype
	str, err := encSM4ECB([]byte("0"), key)
	if err != nil {
		logger.Errorf("[CEB]toLogin SM4 加密空字符串错误: %+v.", err)
		return nil, pay.ErrEncRequestData
	}

	//密码先来个RSA
	arr, err := encPassword(acc.getPassword(), acc.publicKeyTimestamp)
	if err != nil {
		logger.Errorf("[CEB]toLogin加密用户密码错误: %+v.", err)
		return nil, pay.ErrEncRequestData
	}

	//再来个SM4
	pass, err := encSM4ECB([]byte(base64.StdEncoding.EncodeToString(arr)), key)
	if err != nil {
		logger.Errorf("[CEB]toLogin SM4 加密用户密码错误: %+v.", err)
		return nil, pay.ErrEncRequestData
	}

	//5.1.23
	//req := map[string]interface{}{
	//	"DeviceCode":           acc.UDID,
	//	"NewVersion":           "Y",
	//	"VersionNo":            fmt.Sprintf("iOS%s", acc.HardwareInfo.OSVersion),
	//	"clientVersion":        acc.HardwareInfo.OSVersion,
	//	"DeviceDimension":      "0.000000",
	//	"FidoSupportFlag":      "N",
	//	"isRoot":               "0",
	//	"CityCode":             cityID,
	//	"LoginType":            "W",
	//	"Password":             pass,
	//	"City":                 "定位失败",
	//	"_locale":              "Zh_CN",
	//	"sessionId":            "",
	//	"FiDoUpdateFlag":       "Y",
	//	"NewTipNoteBase64Flag": "Y",
	//	"NewVersionSM2":        "1",
	//	"voiceData":            "",
	//	"BankId":               bankID,
	//	"SecureCookie":         "",
	//	"LoginStyle":           str,
	//	"DeviceLongitude":      "0.000000",
	//	"ClientIP":             acc.HardwareInfo.WIFIIPAddress,
	//	"VersionFlag":          "1",
	//	"faceData":             "",
	//	"DeviceType":           acc.HardwareInfo.Model,
	//	"DeviceName":           base64.StdEncoding.EncodeToString([]byte(acc.HardwareInfo.DeviceName)),
	//	"NewDeviceFlag":        acc.newDeviceFlag,
	//	"token":                acc.token,
	//}

	//7.10
	LoginData := fmt.Sprintf("~|~DeviceName=%s~|~City=定位失败~|~CityCode=110102~|~DeviceDimension=0.000000~|~DeviceLongitude=0." +
		"000000~|~DeviceCode=%s~|~DeviceType=%s~|~",acc.HardwareInfo.DeviceName,acc.UDID,acc.HardwareInfo.Model)
	reqData:= map[string]interface{}{
		"clientVersion":clientVersion,
		"TokenPassword":code,
		"_locale":"Zh_CN",
		"isRoot":"0",//8.0.6去除
		"City":"定位失败",
		"Password":pass,
		"FiDoUpdateFlag":"Y",
		"NewVersion528Flag":"Y",
		"NewTipNoteBase64Flag":"Y",
		"BankId":bankID,
		"DeviceDimension":"0.000000",
		"CityCode":cityID,
		"FidoSupportFlag":"N",
		"voiceData":"",
		"LoginStyle":str,
		"NewVersionSM2":"1",
		"DeviceLongitude":"0.000000",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),//7.10新,
		"NewVersion":"Y",
		"NewDeviceFlag":"2",
		"LoginData":LoginData,
		"DeviceType":acc.HardwareInfo.Model,
		"ClientIP":acc.HardwareInfo.WIFIIPAddress,
		"token":acc.Token,
		"MobilePhone":acc.Account,
		"faceData":"",
		"VersionFlag":"1",
		"sessionId":"",
		"DeviceName":acc.HardwareInfo.DeviceName,
		"LoginType":"W",
		"DeviceCode":acc.UDID,
		"SecureCookie":"",
		"VersionNo":"iOS" + clientVersion,
		"_app_clientVersion":clientVersion,//8.0.6新增
	}


	if code == "" {
		reqData["MobilePhone"] = ""
		reqData["UserId"] = acc.UserID
		reqData["NewDeviceFlag"] = acc.newDeviceFlag
	} else {
		//是否那么已绑定
		if acc.newDeviceFlag == "1" {
			reqData["MobilePhone"] = ""
			reqData["UserId"] = acc.UserID
		} else {
			reqData["MobilePhone"] = acc.Account
		}
		reqData["TokenPassword"] = code
		reqData["NewDeviceDataMap"] = acc.newDeviceDataMap       //前面返回
		reqData["SignatureSendSmsMD5"] = acc.signatureSendSmsMD5 //前面返回
		reqData["NewDeviceFlag"] = acc.newDeviceFlag
	}

	resResp := toLoginRes{}//结构题有变化
	fmt.Println(reqData)
	url := urlToLogin
	if code == "" || acc.newDeviceFlag == "1" {
		url = urlLogin
	}

	////if _, err := acc.postHTTPData(url, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]toLogin请求错误: %+v.", err)
	//	return nil, err
	//}


	respstr,_:= acc.NewPostHTTPData(url,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]toLogin反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}



	if resResp.CifNo != "" {
		buff, _ := AesECBEncrypt([]byte(resResp.CifNo), []byte("eca@ecb_20170101"))
		acc.loginAcctNum = base64.StdEncoding.EncodeToString([]byte(buff))
	}

	acc.getToLoginCollet()

	return &resResp, nil
}

/**
EcifGrantDevice
发包：
{"City":"定位失败","_app_clientVersion":"8.0.6","clientVersion":"8.0.6","UserId":"8138034422","CityCode":"","NewVersion528Flag":"Y","token":"4eXdJmCT8dNe4wQucQxcFXhvk\/fBWBbSaABEyZqfaZPgiK7GyPBNTA2zxYQfKTFXcLoci1aysscbVTjJA7TIshuyhIVN0zykwicF5rUdf4Qm+L9gjjM\/2+8otHtaftu+4qP1URgRbssomk76\/VUZBTAAy44UumjzUpMgcFIu0PAh9Ezm+NZ4CCvQbsLGw7PR","ClientVersionNo":"iOS8.0.6","BankId":"9999","AgreementHighestVersionNo":"1.1","DeviceDimension":"","DeviceType":"iPhone9,2","MessTimeStamp":"1616746286360","DeviceName":"iPhone","DeviceLongitude":""}
收包：
{"head":	{		"IBSReturnCode":"000000"			,"IBSReturnMsg":""			,"TransCode":"EcifGrantDevice"		}}
*/

func (acc *Account) EcifGrantDevice() (*ecifGrantDeviceRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}


	reqData,err:= json.Marshal(map[string]interface{}{
		"City":"定位失败",
		"clientVersion":clientVersion,
		"UserId":acc.UserID,
		"CityCode":"",
		"NewVersion528Flag":"Y",
		"token":acc.Token,
		"ClientVersionNo":"iOS" + clientVersion,
		"BankId":bankID,
		"AgreementHighestVersionNo":"1.1",
		"DeviceDimension":"",
		"DeviceType":acc.HardwareInfo.Model,
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"DeviceName":acc.HardwareInfo.DeviceName,
		"DeviceLongitude":"",
	})
	resResp := ecifGrantDeviceRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}
	//if index == 1 {
	//	acc.getMobileToLoginCollet()
	//} else {
	//	acc.getMobileToLoginCollet1()
	//}


	//处理输入数据
	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData,_ := tools.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//enPostBody(reqData,acc.messageNumString,strconv.FormatInt(baseTime,10))
	if err != nil {
		logger.Errorf("[CEB][%+v]EcifGrantDevice序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlEcifGrantDevice,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]EcifGrantDevice创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
	req.Header.Set("_CSII_TIMESTAMP", strconv.FormatInt(baseTime - 100,10))
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), strconv.FormatInt(baseTime - 100,10)))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]EcifGrantDevice http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]EcifGrantDevice http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]EcifGrantDevice反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := tools.SM4ECBDecrypt(bReponData,bSm4key)
	//newData,_:= dealRespData(deCode)
	//println(hex.Dump(newData))
	fmt.Println(string(deCode))
	//calculateSm4key()

	strNewDecode := string(deCode)
	println(hex.Dump(deCode))
	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)


	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]EcifGrantDevice反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPub    licKeyCollet()

	return &resResp, nil
}

//DailyFirstLogin //7.10新新

/**
DailyFirstLogin
发包：

{"BankId":"9999","clientVersion":"8.0.6","NewVersion528Flag":"Y","MessTimeStamp":"1616746286424","_app_clientVersion":"8.0.6"}
收包：
{"head":{"IBSReturnCode":"000000","IBSReturnMsg":"","TransCode":"DailyFirstLogin"}	,"isConditionSatisfied":"0"		,"encryptCifNo":""	,"lotteryUrl":""}
*/

func (acc *Account) DailyFirstLogin() (*dailyFirstLoginRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}




	reqData,err:= json.Marshal(map[string]interface{}{"BankId":bankID,"clientVersion":clientVersion,"NewVersion528Flag":"Y","MessTimeStamp":strconv.FormatInt(baseTime,10)})
	resResp := dailyFirstLoginRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}
	//if index == 1 {
	//	acc.getMobileToLoginCollet()
	//} else {
	//	acc.getMobileToLoginCollet1()
	//}


	//处理输入数据
	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData,_ := tools.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//enPostBody(reqData,acc.messageNumString,strconv.FormatInt(baseTime,10))
	if err != nil {
		logger.Errorf("[CEB][%+v]DailyFirstLogin序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlEcifGrantDevice,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]DailyFirstLogin创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
	req.Header.Set("_CSII_TIMESTAMP", strconv.FormatInt(baseTime - 100,10))
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), strconv.FormatInt(baseTime - 100,10)))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]DailyFirstLogin http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]DailyFirstLogin http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]DailyFirstLogin反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := tools.SM4ECBDecrypt(bReponData,bSm4key)
	//newData,_:= dealRespData(deCode)
	//println(hex.Dump(newData))
	fmt.Println(string(deCode))
	//calculateSm4key()

	strNewDecode := string(deCode)
	println(hex.Dump(deCode))
	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)


	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]DailyFirstLogin反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPub    licKeyCollet()

	return &resResp, nil
}

//BranchActivityVisible //7.10新新
func (acc *Account) BranchActivityVisible() (*BranchActivityVisibleRes, error) {

	baseTime := utils.GetTimeStampEx()
	//req := map[string]interface{}{
	//	"BankId":        bankID,
	//	"UserId":        acc.UserID,
	//	"_locale":       "Zh_CN",
	//	"LoginType":     "W",
	//	"DeviceCode":    acc.UDID,
	//	"checkFlag":     "test",
	//	"clientVersion": clientVersion,
	//	"NewVersion528Flag":"Y", //7.10新
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}




	reqData,err:= json.Marshal(map[string]interface{}{"BankId":bankID,"clientVersion":clientVersion,"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),"UserId":acc.UserID,"cityCode":""})
	resResp := BranchActivityVisibleRes{}

	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}
	//if index == 1 {
	//	acc.getMobileToLoginCollet()
	//} else {
	//	acc.getMobileToLoginCollet1()
	//}


	//处理输入数据
	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData,_ := tools.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//enPostBody(reqData,acc.messageNumString,strconv.FormatInt(baseTime,10))
	if err != nil {
		logger.Errorf("[CEB][%+v]BranchActivityVisible序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlEcifGrantDevice,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]BranchActivityVisible创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
	req.Header.Set("_CSII_TIMESTAMP", strconv.FormatInt(baseTime - 100,10))
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), strconv.FormatInt(baseTime - 100,10)))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]BranchActivityVisible http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]BranchActivityVisible http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]BranchActivityVisible反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := tools.SM4ECBDecrypt(bReponData,bSm4key)
	//newData,_:= dealRespData(deCode)
	//println(hex.Dump(newData))
	fmt.Println(string(deCode))
	//calculateSm4key()

	strNewDecode := string(deCode)
	println(hex.Dump(deCode))
	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)


	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]BranchActivityVisible反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPub    licKeyCollet()

	return &resResp, nil
}


func (acc *Account) fiDoLoginAndPayQuery() (*fiDoLoginAndPayQueryRes, error) {
	req := map[string]interface{}{
		"BankId":        bankID,
		"UserId":        acc.UserID,
		"OperFlag":      "1",
		"DeviceCode":    acc.UDID,
		"clientVersion": clientVersion,
	}
	res := fiDoLoginAndPayQueryRes{}

	if _, err := acc.postHTTPData(urlFiDoLoginAndPayQuery, &req, &res); err != nil {
		// logger.Errorf("[CEB]fiDoLoginAndPayQuery请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) registGeTui() (*registGeTuiRes, error) {
	baseTime := utils.GetTimeStampEx()

	resResp := registGeTuiRes{}

	reqData,err:= json.Marshal(map[string]interface{}{
		"BankId":        bankID,
		"UserId":        acc.UserID,
		"clientVersion": clientVersion,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10)})


	//if _, err := acc.postHTTPData(urlGetMobilToLogin, &req, &res); err != nil {
	//	// logger.Errorf("[CEB]getMobileToLogin请求错误: %+v.", err)
	//	return nil, err
	//}
	//if index == 1 {
	//	acc.getMobileToLoginCollet()
	//} else {
	//	acc.getMobileToLoginCollet1()
	//}


	//处理输入数据
	sm4key,_:= calculateSm4key(acc.messageNumString,strconv.FormatInt(baseTime,10))
	bSm4key, _ := hex.DecodeString(sm4key)
	//body Sm4加密
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	//enData,_ :=tools.SM4ECBEncrypt(reqData,bSm4key)
	enData,_ := tools.SM4ECBEncrypt(reqData,bSm4key)
	strEncodeBody := base64.StdEncoding.EncodeToString(enData)

	//enPostBody(reqData,acc.messageNumString,strconv.FormatInt(baseTime,10))
	if err != nil {
		logger.Errorf("[CEB][%+v]registGeTui序列化请求数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrMarshalRequestData
	}

	req, err := http.NewRequest("POST", urlEcifGrantDevice,  strings.NewReader(strEncodeBody))
	if err != nil {
		logger.Errorf("[CEB][%+v]registGeTui创建http请求错误: %+v.", acc.Account, err)
		return nil, pay.ErrCreateHTTPRequest
	}

	req.Header.Set(headers.ContentType, "application/json;charset=utf-8")
	req.Header.Set(headers.Accept, "application/json")
	req.Header.Set(headers.UserAgent, fmt.Sprintf("CEBMobileBank/%s (iPhone; iOS %s; Scale/2.00)", appVersion, acc.HardwareInfo.OSVersion))
	req.Header.Set(headers.AcceptLanguage, "zh-CN,zh;q=0.8")
	req.Header.Set(headers.AcceptEncoding, "br, gzip, deflate")
	req.Header.Set("USESSL", "0")
	req.Header.Set("MessTimeStamp", strconv.FormatInt(baseTime,10))
	req.Header.Set("_CSII_TIMESTAMP", strconv.FormatInt(baseTime - 100,10))
	req.Header.Set("_CSII_JSON_SIGNATURE", sign(string(reqData), strconv.FormatInt(baseTime - 100,10)))


	body, err := utils.DoHTTP(acc.http, req)

	if err != nil {
		logger.Errorf("[CEB][%+v]registGeTui http操作错误: %+v.", acc.Account, err)
		if nerr, ok := err.(net.Error); ok && nerr.Timeout() {
			return nil, pay.ErrOperationTimeout
		}

		return nil, pay.ErrOperationError
	}

	logger.Debugf("[CEB][%+v]registGeTui http请求成功, data: %s, body: %s.", acc.Account, string(reqData), utils.ReplaceWhiteSpace(body))

	resMessEncryptData := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(body), &resMessEncryptData); err != nil {
		logger.Errorf("[CEB][%+v]registGeTui 反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	//解密返回值
	MessEncryptData := resMessEncryptData.MessEncryptData

	bReponData,_  := base64.StdEncoding.DecodeString(MessEncryptData)
	deCode,_ := tools.SM4ECBDecrypt(bReponData,bSm4key)
	//newData,_:= dealRespData(deCode)
	//println(hex.Dump(newData))
	fmt.Println(string(deCode))
	//calculateSm4key()

	strNewDecode := string(deCode)
	println(hex.Dump(deCode))
	strNewDecode = strings.Replace(strNewDecode, "\r\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, "\n", "", -1)
	strNewDecode = strings.Replace(strNewDecode, " ", "", -1)
	fmt.Println(strNewDecode)


	fmt.Println(strNewDecode)
	if err := json.Unmarshal([]byte(strNewDecode), &resResp); err != nil {
		logger.Errorf("[CEB][%+v]registGeTui反序列化返回数据错误: %+v.", acc.Account, err)
		return nil, pay.ErrUnmarshalResponseData
	}

	fmt.Println(resResp)
	//acc.getfetchPub    licKeyCollet()

	return &resResp, nil
}




func (acc *Account) actQryPre() (*actQryPreRes, error) {

	acc.actQryPreCollet()
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"_locale":       "zh_CN",
		"FuncFlag":      1,
		"clientVersion": clientVersion,
		"MachineCode":   acc.UDID,
		"BankId":        bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
	}
	resResp := actQryPreRes{}

	respstr,_:= acc.NewPostHTTPData(urlActQryPre,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]ActQryPre反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) actTrsQry(startDate, endDate string, page int) (*actTrsQryRes, error) {
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"AliasName":     "",
		"BeginDate":     startDate,
		"MachineCode":   acc.UDID,
		"clientVersion": clientVersion,
		"AcCur":         "01",
		"currentIndex":  fmt.Sprintf("%d", page*10),
		"HXTotalNum":    "",
		"TotalFlag":     "true",
		"AcNo":          acc.acID,
		"CRFlag":        "0",
		"Currency":      "01",
		"moreFlag":      1,
		"BankAcType":    "1",
		"EndDate":       endDate,
		"_locale":       "zh_CN",
		"BankId":        bankID,
		"pageSize":      "10",
		"FriendFlag":    "", //7.10新
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}

	if page != 0 {
		reqData["TransCode"] = "ActTrsQry.do"
	}

	resResp := actTrsQryRes{}
	respstr,_:= acc.NewPostHTTPData(urlActTrsQry,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]ActTrsQry反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) queryDAIFA() (*queryDAIFARes, error) {
	req := map[string]interface{}{
		"clientVersion": clientVersion,
		"BankId":        bankID,
		"UserId":        acc.UserID,
	}
	res := queryDAIFARes{}

	if _, err := acc.postHTTPData(urlQueryDAIFA, &req, &res); err != nil {
		// logger.Errorf("[CEB]queryDAIFA请求错误: %+v.", err)
		return nil, err
	}

	return &res, nil
}

func (acc *Account) bankTransferPre() (*bankTransferPreRes, error) {
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"clientVersion": clientVersion,
		"BankId":        bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}

	resResp  := bankTransferPreRes{}
	respstr,_:= acc.NewPostHTTPData(urlBankTransferPre,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)
	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]clientNoticeList反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) transferBankQry(targetAccount string) (*transferBankQryRes, error) {
	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"PayeeCode":     targetAccount,
		"clientVersion": clientVersion,
		"BankId":        bankID,
		"NewVersion528Flag":"Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}
	resResp  := transferBankQryRes{}
	respstr,_:= acc.NewPostHTTPData(urlTransferBankQry,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]transferBankQry反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) bankTransferConfirmNew(
	bankCode string,
	bankNo string,
	bankName string,
	availBal string,
	payerBankAcType string,
	targetAccount string,
	targetName string,
	amount string,
	comment string,
) (*bankTransferConfirmRes, error) {

	//8.0.0更新
	//{
	//	"UnionDeptId": "",
	//	"AvailBal": "502.64",
	//	"FiDoPaySwitch": "N",
	//	"SuperDeptId": "103100000026",
	//	"BankName": "农业银行",
	//	"PayeeBankId": "103",
	//	"NewVersion528Flag": "Y",
	//	"PayeeAcNo": "6228481548821475578",
	//	"timeFlag": "0",
	//	"isToken": "0",
	//	"SuperDeptName": "农业银行",
	//	"MessTimeStamp": "1612252577687",
	//	"BankId": "9999",
	//	"CDCFlag": "",
	//	"videoFlag": "1",         //8.0.0新
	//	"clientVersion": "8.0.0",
	//	"payeePhone": "",
	//	"Remark": "",
	//	"aliasName": "",
	//	"PayeeAcName": "汤荣焱",
	//	"PayeeAddr": "",
	//	"PayerBankAcType": "1",
	//	"faceSupport": "0",
	//	"Amount": "0.1",
	//	"PayerAcNo": "AAAb2SACJAAD7XYABk"
	//}
	baseTime := utils.GetTimeStampEx()
	//reqData := map[string]interface{}{
	//	"UnionDeptId":     "",
	//	"AvailBal":        availBal,
	//	"FiDoPaySwitch":   "N",
	//	"SuperDeptId":     bankNo,
	//	"BankName":        bankName,
	//	"PayeeBankId":     bankCode,
	//	"PayeeAcNo":       targetAccount,
	//	"timeFlag":        "0",
	//	"isToken":         "0",
	//	"SuperDeptName":   bankName,
	//	"BankId":          bankID,
	//	"CDCFlag":         "",
	//	"clientVersion":   clientVersion,
	//	"payeePhone":      "",
	//	"Remark":          comment,
	//	"aliasName":       "",
	//	"PayeeAcName":     targetName,
	//	"PayeeAddr":       "",
	//	"PayerBankAcType": payerBankAcType,
	//	"Amount":          amount,
	//	"PayerAcNo":       acc.acID,
	//	"faceSupport":     "0",   //7.10新加
	//	"NewVersion528Flag":"Y",
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}

	reqData1 := map[string]interface{}{
		"UnionDeptId":"",
		"AvailBal":availBal,
		"FiDoPaySwitch":"N",
		"SuperDeptId":bankCode,
		"BankName":bankName,
		"PayeeBankId":bankNo,
		"NewVersion528Flag":"Y",
		"PayeeAcNo":targetAccount,
		"timeFlag":"0",
		"isToken":"0",
		"SuperDeptName":bankName,
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"BankId":bankID,
		"CDCFlag":"",
		"clientVersion":clientVersion,
		"payeePhone":"",
		"Remark":"",
		"aliasName":"",
		"PayeeAcName":targetName,
		"PayeeAddr":"",
		"PayerBankAcType":"1",
		"faceSupport":"0",
		"Amount":amount,
		"PayerAcNo":acc.acID,
		"videoFlag": "1",    //8.0新加
		"_app_clientVersion":clientVersion,//8.0.6新增
	}

	resResp := bankTransferConfirmRes{}

	respstr,_:= acc.NewPostHTTPData(urlBankTransferConfirmNew,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData1,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]bankTransferConfirm反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) sendSMSPwd(targetAccount, targetName, amount, smsData string) (*sendSMSPwdRes, error) {

	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"AcctNo":        targetAccount,
		"clientVersion": clientVersion,
		"BankId":        bankID,
		"TransAmt":      amount,
		"TransName":     "09",
		"SmsSndSeqNo":   "1",
		"SmsData":       smsData,
		"PayeeName":     targetName,
		"NewVersion528Flag":   "Y",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"_app_clientVersion":clientVersion,//8.0.6新增
	}
	resResp := sendSMSPwdRes{}

	respstr,_:= acc.NewPostHTTPData(urlSendSMSPwd,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]sendSMSPwd反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}

func (acc *Account) bankTransfer(confirmInfo *bankTransferConfirmRes, code string) (*bankTransferRes, string, error) {
	baseTime := utils.GetTimeStampEx()
	pass, err := encPayPassword(acc.getPayPassword(), acc.publicKeyTimestamp, acc.sm2Key)
	if err != nil {
		logger.Errorf("[CEB][%+v]bankTransfer加密支付密码错误, 密码: %s, ts: %s, key: %s, err: %+v.",
			acc.Account, acc.getPayPassword(), acc.publicKeyTimestamp, acc.sm2Key, err)
		return nil, "", pay.ErrEncRequestData
	}

	//reqData := map[string]interface{}{
	//	"timeFlag":        "0",
	//	"clientVersion":   clientVersion,
	//	"TrsPassword":     base64.StdEncoding.EncodeToString(pass),
	//	"PayeeBankId":     confirmInfo.PayeeBankID,
	//	"UnionDeptId":     confirmInfo.UnionDeptID,
	//	"SMSSignFlag":     confirmInfo.SmsSignFlag,
	//	"largeAmount":     confirmInfo.LargeAmount,
	//	"SmsData":         confirmInfo.SmsData,
	//	"BankId":          bankID,
	//	"OTPPassType":     "SMS",
	//	"PayerAcNo":       confirmInfo.PayerAcNo,
	//	"largeAmountFlag": confirmInfo.LargeAmountFlag,
	//	"aliasName":       "",
	//	"CDCFlag":         confirmInfo.CDCFlag,
	//	"MessageNotify":   "",
	//	"SuperDeptName":   confirmInfo.SuperDeptName,
	//	"QSDeptId":        confirmInfo.QSDeptID,
	//	"_dataMap":        confirmInfo.DataMap,
	//	"AmountValue":     confirmInfo.AmountValue,
	//	"Mobile":          "",
	//	"BankName":        confirmInfo.BankName,
	//	"_tokenName":      confirmInfo.TokenName,
	//	"fallflag":        confirmInfo.FallFlag,
	//	"Fee":             confirmInfo.Fee,
	//	"jnlno":           confirmInfo.JNLNo,
	//	"OTPPassword":     code,
	//	"SuperDeptId":     confirmInfo.SuperDeptID,
	//	"deAmount":        confirmInfo.DeAmount,
	//	"PayeeAcNo":       confirmInfo.PayeeAcNo,
	//	"PAYERMOBILE":     confirmInfo.PayerMobile,
	//	"IsSelf":          confirmInfo.IsSelf,
	//	"AvailBal":        confirmInfo.AvailBal,
	//	"RealFee":         confirmInfo.RealFee,
	//	"PayerBankAcType": confirmInfo.PayerBankAcType,
	//	"FiDoPaySwitch":   confirmInfo.FiDoPayFlag,
	//	"PayeeAddr":       confirmInfo.PayeeAddr,
	//	"Amount":          confirmInfo.Amount,
	//	"payeePhone":      confirmInfo.PayeePhone,
	//	"QSBankName":      confirmInfo.QSBankName,
	//	"PayeeAcName":     confirmInfo.PayeeAcName,
	//	"Remark":          confirmInfo.Remark,
	//	"NewVersion528Flag":   "Y",
	//	"MessTimeStamp":strconv.FormatInt(baseTime,10),
	//}

	reqData1 := map[string]interface{}{
		"timeFlag":"0",
		"clientVersion":clientVersion,
		"TrsPassword":base64.StdEncoding.EncodeToString(pass),
		"PayeeBankId":confirmInfo.PayeeBankID,
		"UnionDeptId":confirmInfo.UnionDeptID,
		"SMSSignFlag":confirmInfo.SmsSignFlag,
		"NewVersion528Flag":"Y",
		"largeAmount":confirmInfo.LargeAmount,
		"SmsData":confirmInfo.SmsData,
		"BankId":bankID,
		"OTPPassType":"SMS",
		"PayerAcNo":confirmInfo.PayerAcNo,
		"largeAmountFlag":confirmInfo.LargeAmountFlag,
		"CDCFlag":confirmInfo.CDCFlag,
		"aliasName":"",
		"MessageNotify":"",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"SuperDeptName":confirmInfo.SuperDeptName,
		"QSDeptId":"",
		"_dataMap":confirmInfo.DataMap,
		"AmountValue":confirmInfo.AmountValue,
		"Mobile":"",
		"BankName":confirmInfo.BankName,
		"_tokenName":confirmInfo.TokenName,
		"fallflag":confirmInfo.FallFlag,
		"Fee":confirmInfo.Fee,
		"jnlno":confirmInfo.JNLNo,
		"OTPPassword":code,
		"SuperDeptId":confirmInfo.SuperDeptID,
		"deAmount":confirmInfo.DeAmount,
		"PayeeAcNo":confirmInfo.PayeeAcNo,
		"PAYERMOBILE":confirmInfo.PayerMobile,
		"AvailBal":confirmInfo.AvailBal,
		"IsSelf":confirmInfo.IsSelf,
		"RealFee":confirmInfo.RealFee,
		"FiDoPaySwitch":confirmInfo.FiDoPayFlag,
		"PayerBankAcType":confirmInfo.PayerBankAcType,
		"PayeeAddr":"",
		"Amount":confirmInfo.Amount,
		"payeePhone":confirmInfo.PayeePhone,
		"QSBankName":confirmInfo.QSBankName,
		"PayeeAcName":confirmInfo.PayeeAcName,
		"Remark":confirmInfo.Remark,
		"_app_clientVersion":clientVersion,//8.0.6新增
	}

	resResp := bankTransferRes{}

	respstr,_:= acc.NewPostHTTPData(urlBankTransfer,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData1,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]BankTransfer反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp,respstr, nil
}


func (acc *Account) getMerchantParams() (*sendSMSPwdRes, error) {

	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"deviceCode":acc.UDID,
		"longLaTitude":"0.000000,0.000000",
		"userId":acc.UserID,
		"clientVersion":clientVersion,
		"BankId":bankID,
		"cId":"",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"merId":"53",
		"version":clientVersion,
		"token":"",
		"NewVersion528Flag":"Y"}
	resResp := sendSMSPwdRes{}

	respstr,_:= acc.NewPostHTTPData(urlGetMerchantParams,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]getMerchantParams反序列化返回数据错误: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}


func (acc *Account) ActTrsQryPre() (*sendSMSPwdRes, error) {

	baseTime := utils.GetTimeStampEx()
	reqData := map[string]interface{}{
		"BankId":bankID,
		"clientVersion":clientVersion,
		"_locale":"zh_CN",
		"timeFlag":"1month",
		"MessTimeStamp":strconv.FormatInt(baseTime,10),
		"version":0,
		"step":1,
		"MachineCode":acc.UDID,
		"versionEX":"N1",
		"NewVersion528Flag":"Y"}
	resResp := sendSMSPwdRes{}

	respstr,_:= acc.NewPostHTTPData(urlActTrsQryPre,strconv.FormatInt(baseTime-100,10),strconv.FormatInt(baseTime,10),reqData,&resResp)
	fmt.Println(respstr)


	resMessEncryptData1 := messEncryptDataRes{}
	if err := json.Unmarshal([]byte(respstr), &resMessEncryptData1); err != nil {
		logger.Errorf("[CEB][%+v]ActTrsQryPre: %+v.", acc.Account, err)
		//return nil, pay.ErrUnmarshalResponseData
	}

	return &resResp, nil
}
