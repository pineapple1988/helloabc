package ceb

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"pay/api"
	"pay/data/redis"
	"pay/mgr/timermgr"
	"pay/pay"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// Account 光大银行帐号
type Account struct {
	Account               string          `json:"account"`
	Password              string          `json:"password"`
	PayPassword           string          `json:"payPassword"`
	Platform              string          `json:"platform"`
	CardNo                string          `json:"cardNo"`
	UDID                  string          `json:"udid"`
	IDFA                  string          `json:"idfa"`
	IDFV                  string          `json:"idfv"`
	ClientID              string          `json:"clientId"`
	UserID                string          `json:"userId"`
	MobileOperators       string          `json:"obileOperators"`
	Proxy                 utils.ProxyInfo `json:"proxy"`
	HardwareInfo          HardwareInfo    `json:"hardwareInfo"`
	Token                 string          `json:"token"`
	http                  *http.Client
	jar                   *cookiejar.Jar
	sm2Key                string
	sm4Key                string
	publicKeyTimestamp    string
	dynamicSM4Key         string
	dynamicArrayKey       string
	newDeviceFlag         string
	newDeviceDataMap      string
	signatureSendSmsMD5   string
	acID                  string
	lastPing              int64
	loginFlag             string
	loginStatus           int32
	loginPadding          int32
	transferPadding       int32
	loginFailCount        int
	smscodeFailCount      int
	payPasswordFailCount  int
	transferTargetAccount string
	transferTargetName    string
	transferAmount        string
	transferComment       string
	transferOrderNo       string
	transferConfirmInfo   *bankTransferConfirmRes
	tokenIDTime           uint
	tokenTimeDateStr      string
	tokenTimeTimeStr      string
	loginAcctNum          string
	pageName              string
	messageNumString	  string //用于计算sm4 key的随机书值，由第一个包返回

}

// HardwareInfo 硬件信息
type HardwareInfo struct {
	Model         string `json:"model"`
	DeviceName    string `json:"deviceName"`
	ScreenSize    string `json:"screenSize"`
	OSVersion     string `json:"osVersion"`
	WIFIName      string `json:"wifiName"`
	WIFIMac       string `json:"wifiMac"`
	WIFIIPAddress string `json:"wifiIPAddress"`
	Carrier       string `json:"carrier"`
	Imei          string `json:"imei"`
	Resolution    string `json:"resolution"`
}

// NewAccount 创建一个登录帐号
func NewAccount(account, password, payPassword, platform string) (*Account, error) {
	switch platform {
	case common.PlatformNameIOS, common.PlatformNameAndroid:
	default:
		{
			logger.Errorf("[CEB]错误的登录平台, 帐号: %+v, 平台: %+v.", account, platform)

			return nil, errors.New("错误的登录平台")
		}
	}

	field := fmt.Sprintf("%s_%s", account, platform)
	exists, err := redis.HExists(cebAccountKey, field)

	// 没有尝试从设备服务获取
	if err != nil || !exists {
		data, err := api.AccountGetInfo(account, api.GetPlatformCode(platform))
		if err == nil && data != "" {
			// 写入成功认为有缓存数据
			if err := redis.HSet(cebAccountKey, field, data); err != nil {
				exists = true
			}
		}
	}

	if exists {
		acc := &Account{
			Account:  account,
			Platform: platform,
		}

		if err = acc.load(); err == nil {
			acc.setPassword(password, payPassword)
			acc.jar, _ = cookiejar.New(nil)
			timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

			if acc.HardwareInfo.Model == "" {
				acc.newHardwareInfo(platform)
			}

			if acc.MobileOperators == "" {
				acc.MobileOperators = utils.NewCarrierName()
			}

			return acc, nil
		}

		logger.Errorf("[CEB]从缓存加载帐号信息失败, 将重新生成帐号信息, 帐号: %+v, 平台: %+v, 错误: %+v.",
			account, platform, err)
	}

	acc := &Account{
		Account:     account,
		Password:    utils.PasswordEncrypt(password),
		PayPassword: utils.PasswordEncrypt(payPassword),
		Platform:    platform,
		Proxy:       utils.ProxyInfo{},
	}

	acc.UDID, _ = utils.NewUUID(true)
	acc.IDFA, _ = utils.NewUUID(true)
	acc.IDFV, _ = utils.NewUUID(true)
	acc.ClientID, _ = utils.NewUUID(true)
	acc.MobileOperators = utils.NewCarrierName()
	acc.newHardwareInfo(platform)

	if err := acc.save(); err != nil {
		return nil, err
	}

	logger.Infof("[CEB]创建帐户信息成功, 帐号: %+v, 平台: %+v.",
		account, platform)

	acc.jar, _ = cookiejar.New(nil)

	timermgr.SetTimer(acc, timerUpdate, timerUpdateInterval, true, nil)

	return acc, nil
}

// GetScreenWidth 返回屏幕宽度
func (acc *Account) GetScreenWidth() int64 {
	arr := strings.Split(acc.HardwareInfo.ScreenSize, "*")
	if len(arr) < 2 {
		return 0
	}

	n, err := strconv.Atoi(arr[0])
	if err != nil {
		return 0
	}

	return int64(n)
}

// GetScreenHeight 返回屏幕高度
func (acc *Account) GetScreenHeight() int64 {
	arr := strings.Split(acc.HardwareInfo.ScreenSize, "*")
	if len(arr) < 2 {
		return 0
	}

	n, err := strconv.Atoi(arr[1])
	if err != nil {
		return 0
	}

	return int64(n)
}

func (acc *Account) newHardwareInfo(platform string) {
	h := &acc.HardwareInfo
	h.WIFIName = utils.NewWifiName()
	h.WIFIMac = utils.NewMacAddress()
	h.WIFIIPAddress = utils.NewLocalIPAddress()
	h.Carrier = utils.NewCarrierName()
	h.Imei, _ = utils.NewUUID(true)

	if platform == common.PlatformNameIOS {
		h.OSVersion = utils.GetIPhoneOSVersion()
		h.Model, h.DeviceName, h.ScreenSize = utils.GetIPhoneModel()

		h.Resolution = fmt.Sprintf("%dX%d", acc.GetScreenWidth()*2, acc.GetScreenHeight()*2)

	} else if platform == common.PlatformNameAndroid {

	}
}

func (acc *Account) setPassword(password, payPassword string) error {
	changed := false
	if password != "" && password != acc.getPassword() {
		acc.Password = utils.PasswordEncrypt(password)
		changed = true
	}

	if payPassword != "" && payPassword != acc.getPayPassword() {
		acc.PayPassword = utils.PasswordEncrypt(payPassword)
		changed = true
	}

	if changed {
		return acc.save()
	}

	return nil
}

func (acc *Account) load() error {
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	value, err := redis.HGet(cebAccountKey, field)
	if err != nil {
		logger.Errorf("[CEB]读取缓存帐号信息错误, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err

	}

	if err = json.Unmarshal([]byte(value), acc); err != nil {
		logger.Errorf("[CEB]缓存帐号信息反序列化错误, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, value, err)
		return err
	}

	return nil
}

func (acc *Account) save() error {
	json, err := json.Marshal(acc)
	if err != nil {
		logger.Errorf("[CEB]无法将帐号信息序列化为json, 帐号: %+v, 平台: %+v, 错误: %+v.",
			acc.Account, acc.Platform, err)
		return err
	}

	jsonStr := string(json)

	// 上传到服务器
	api.AccountUploadInfo(acc.Account, api.GetPlatformCode(acc.Platform), jsonStr)

	// 本地缓存
	field := fmt.Sprintf("%s_%s", acc.Account, acc.Platform)
	if err = redis.HSet(cebAccountKey, field, jsonStr); err != nil {
		logger.Errorf("[CEB]无法将帐号信息缓存到redis, 帐号: %+v, 平台: %+v, 帐号信息: %+v, 错误: %+v.",
			acc.Account, acc.Platform, jsonStr, err)
		return err
	}

	return nil
}

func (acc *Account) getPassword() string {
	return utils.PasswordDecrypt(acc.Password)
}

func (acc *Account) getPayPassword() string {
	return utils.PasswordDecrypt(acc.PayPassword)
}

func (acc *Account) setProxy(url, user, password string) bool {
	if url != acc.Proxy.URI || user != acc.Proxy.User || password != acc.Proxy.Pass {
		acc.Proxy.URI = url
		acc.Proxy.User = user
		acc.Proxy.Pass = password
		acc.save()
		return true
	}

	return false
}

func (acc *Account) onLoginSuccess() {
	acc.lastPing = time.Now().Unix()
	acc.loginStatus = pay.LoginStatusSuccess
	api.ReportAccStateLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCEB)
	pay.AddLoginSuccess(acc.Account, acc.Platform, common.AccountTypeCEB)
}

// freeze 冻结用户
func (acc *Account) freeze(code int, reason string) {
	acc.loginStatus = pay.LoginStatusNone
	pay.AccountFreeze(acc.Account, acc.Platform, common.AccountTypeCEB, code, reason)
}

func (acc *Account) checkOnline(ts int64) {
	if acc.loginStatus == pay.LoginStatusSuccess && ts-acc.lastPing > 300 {
		// 检测代理服务器
		if config.IsUseProxy() {
			pi, _ := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
			if pi != nil {
				if acc.setProxy(pi.URI, pi.User, pi.Pass) {
					acc.http = pay.CreateHTTPClient(pi, acc.jar)
				}
			}
		}

		// res, err := acc.actQryPre()
		// if err != nil {
		// 	return
		// }

		// if res.Head.Msg == "会话已超时" {
		// 	acc.doRelogin()
		// }

		acc.lastPing = ts
	}
}

func (acc *Account) selectCard(balance *actQryPreRes) error {
	if balance == nil || len(balance.List) <= 0 {
		return pay.ErrNoHaveCardList
	}

	if acc.CardNo == "" {
		// 选择默认第一张卡号
		acc.acID = balance.List[0].AcID
		logger.Infof("[CEB][%+v]未指定银行卡号, 默认选择第一张, 卡号: %s, Id: %s.", acc.Account, balance.List[0].AcNo, balance.List[0].AcID)
		return nil
	}

	for _, v := range balance.List {
		if v.AcNo == acc.CardNo {
			acc.acID = v.AcID
			logger.Infof("[CEB][%+v]选定指定银行卡号, 卡号: %s, Id: %s.", acc.Account, v.AcNo, v.AcID)
			return nil
		}
	}

	logger.Errorf("[CEB][%+v]没有找到指定银行卡号: %s.", acc.Account, acc.CardNo)
	return fmt.Errorf("没有找到指定的银行卡号: %s", acc.CardNo)
}

func (acc *Account) doRelogin() error {
	key, err := acc.fetchPublicKey()
	if err != nil {
		logger.Errorf("[CEB][%+v]重登录获取加密公钥错误: %+v.", acc.Account, err)
		return err
	}

	if key.VersionType == "1" {
		acc.loginStatus = pay.LoginStatusNone
		api.ReportAccStateLogout(acc.Account, acc.Platform, common.AccountTypeCEB)
		logger.Errorf("[CEB][%+v]检测到银行进行强制版本更新.", acc.Account)
		return pay.ErrUpgradeRequired
	}

	if key.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]重登录获取加密公钥失败, 代码: %+v, 信息: %+v.", acc.Account, key.Head.Code, key.Head.Msg)
		return errors.New(key.Head.Msg)
	}

	acc.sm2Key = key.SM2Key
	acc.sm4Key = key.SM4Key
	acc.publicKeyTimestamp = key.Timestamp

	token, err := acc.getToken()
	if err != nil {
		logger.Errorf("[CEB][%+v]重登录获取token错误: %+v.", acc.Account, err)
		return err
	}

	if token.Head.Status != 0 {
		logger.Errorf("[CEB][%+v]重登录获取token失败, 代码: %+v, 信息: %+v.", acc.Account, token.Head.Status, token.Head.Msg)
		return errors.New(token.Head.Msg)
	}

	acc.Token = token.Token

	//acc.clientNoticeList()
	mobileToLogin, err := acc.getMobileToLogin(2)
	if err != nil {
		logger.Errorf("[CEB][%+v]重登录MobileToLogin错误: %+v.", acc.Account, err)
		return err
	}

	if mobileToLogin.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]重登录MobileToLogin失败, 代码: %+v, 信息: %+v.", acc.Account, mobileToLogin.Head.Code, mobileToLogin.Head.Msg)
		return errors.New(mobileToLogin.Head.Msg)
	}

	acc.dynamicSM4Key = mobileToLogin.DynamicSM4Key
	acc.dynamicArrayKey = mobileToLogin.DynamicArrayKey
	acc.newDeviceFlag = mobileToLogin.NewDeviceFlag
	acc.loginFlag = mobileToLogin.LoginFlag

	if mobileToLogin.NewDeviceFlag != "0" {
		acc.loginStatus = pay.LoginStatusNone
		pay.AccountKickout(acc.Account, acc.Platform, common.AccountTypeCEB)

		logger.Errorf("[CEB][%+v]需要重新绑定设备进行登录.", acc.Account)
		return pay.ErrNeedBindDevice
	}

	res, err := acc.toLogin("")
	if err != nil {
		logger.Errorf("[CEB][%+v]重登录操作错误: %+v.", acc.Account, err)
		return err
	}

	if res.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]重登录失败, 代码: %+v, 信息: %+v.", acc.Account, res.Head.Code, res.Head.Msg)
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCEB)

		// 风控
		if strings.Contains(res.Head.Msg, "您的账户存在可疑交易") {
			acc.freeze(pay.FreezeCodeCardError, res.Head.Msg)
		}

		if strings.Contains(res.Head.Msg, "用户名或登录密码错误") {
			acc.loginFailCount++
			if acc.loginFailCount >= 3 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[CEB][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return errors.New(res.Head.Msg)
	}

	acc.UserID = res.UserID
	acc.loginFailCount = 0

	logger.Infof("[CEB][%+v]用户重登录成功.", acc.Account)

	return nil
}

// OnTimer 定时器事件
func (acc *Account) OnTimer(id int, param interface{}) {
	ts := time.Now().Unix()
	if id == timerUpdate {
		acc.checkOnline(ts)
	}
}

// GetAccount 取帐号
func (acc *Account) GetAccount() string {
	return acc.Account
}

// Login 登录操作
func (acc *Account) Login(timeout int) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求登录, 平台: %+v.", acc.Account, acc.Platform)

	// 各种登录状态
	switch acc.loginStatus {
	// case pay.LoginStatusWaitCode:
	// 	logger.Infof("[CEB][%+v]等待验证码登录.", acc.Account)
	// 	return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	case pay.LoginStatusSuccess:
		logger.Infof("[CEB][%+v]已在登录状态.", acc.Account)
		return pay.Success(nil)
	}

	if acc.loginPadding != 0 {
		logger.Infof("[CEB][%+v]正在登录中.", acc.Account)
		return pay.Error(pay.ErrCodeLoginPadding, pay.ErrMsgLoginPadding, nil)
	}

	atomic.StoreInt32(&acc.loginPadding, 1)
	defer func() {
		atomic.StoreInt32(&acc.loginPadding, 0)
	}()

	// 代理服务器
	if config.IsUseProxy() {
		pi, err := pay.AllocProxy(acc.Account, acc.Platform, &acc.Proxy)
		if err != nil {
			logger.Errorf("[CEB][%+v]分配代理服务器错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeProxyError, pay.ErrMsgProxyError, nil)
		}

		if pi != nil {
			acc.setProxy(pi.URI, pi.User, pi.Pass)
		}

		acc.http = pay.CreateHTTPClient(&acc.Proxy, acc.jar)
	} else {
		acc.http = pay.CreateHTTPClient(nil, acc.jar)
	}

	key, err := acc.fetchPublicKey()
	if err != nil {
		logger.Errorf("[CEB][%+v]获取加密公钥错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if key.VersionType == "1" {
		return pay.Error(pay.ErrCodeLoginError, pay.ErrUpgradeRequired.Error(), nil)
	}

	if key.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]获取加密公钥失败, 代码: %+v, 信息: %+v.", acc.Account, key.Head.Code, key.Head.Msg)
		return pay.Error(pay.ErrCodeLoginError, key.Head.Msg, nil)
	}

	acc.sm2Key = key.SM2Key
	acc.sm4Key = key.SM4Key
	acc.publicKeyTimestamp = key.Timestamp

	//8.0.6不用了
	token, err := acc.getToken()
	if err != nil {
		logger.Errorf("[CEB][%+v]获取token错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if token.Head.Status != 0 {
		logger.Errorf("[CEB][%+v]获取token失败, 代码: %+v, 信息: %+v.", acc.Account, token.Head.Status, token.Head.Msg)
		return pay.Error(pay.ErrCodeLoginError, token.Head.Msg, nil)
	}

	acc.Token = token.Token

	//acc.clientNoticeList()
	mobileToLogin, err := acc.getMobileToLogin(1)
	if err != nil {
		logger.Errorf("[CEB][%+v]MobileToLogin错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if mobileToLogin.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]MobileToLogin失败, 代码: %+v, 信息: %+v.", acc.Account, mobileToLogin.Head.Code, mobileToLogin.Head.Msg)
		return pay.Error(pay.ErrCodeLoginError, mobileToLogin.Head.Msg, nil)
	}

	acc.dynamicSM4Key = mobileToLogin.DynamicSM4Key
	acc.dynamicArrayKey = mobileToLogin.DynamicArrayKey
	acc.newDeviceFlag = mobileToLogin.NewDeviceFlag
	acc.loginFlag = mobileToLogin.LoginFlag

	if acc.newDeviceFlag != "0" {
		// 绑定验证码登录
		acc.loginStatus = pay.LoginStatusWaitCode
		api.ReportAccStateLoginWaitSMSCode(acc.Account, acc.Platform, common.AccountTypeCEB)

		logger.Infof("[CEB][%+v]需要验证码进行登录.", acc.Account)

		code, err := acc.toSendSMSPwd(acc.newDeviceDataMap)
		if err != nil {
			logger.Errorf("[CEB][%+v]发送登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if code.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]发送登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, code.Head.Code, code.Head.Msg)
			return pay.Error(pay.ErrCodeLoginError, code.Head.Msg, nil)
		}

		acc.signatureSendSmsMD5 = code.SignatureSendSmsMD5
		acc.newDeviceDataMap = code.NewDeviceDataMap

		logger.Infof("[CEB][%+v]发送登录验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedSMSCode, pay.ErrMsgNeedSMSCode, nil)
	}

	res, err := acc.toLogin("")
	if err != nil {
		logger.Errorf("[CEB][%+v]登录操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	// 风控
	if strings.Contains(res.Head.Msg, "您的账户存在可疑交易") || strings.Contains(res.Head.Msg, "为保证您的资金安全") {
		acc.freeze(pay.FreezeCodeCardError, res.Head.Msg)
		return pay.Error(pay.ErrCodeAccountRisk, res.Head.Msg, nil)
	}

	if res.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]登录失败, 代码: %+v, 信息: %+v.", acc.Account, res.Head.Code, res.Head.Msg)
		api.ReportAccStateInvalidPassword(acc.Account, acc.Platform, common.AccountTypeCEB)
		if strings.Contains(res.Head.Msg, "用户名或登录密码错误") {
			acc.loginFailCount++
			if acc.loginFailCount >= 3 {
				acc.loginFailCount = 0
				acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
				logger.Errorf("[CEB][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return pay.Error(pay.ErrCodeLoginError, res.Head.Msg, nil)
	}

	acc.UserID = res.UserID
	acc.loginFailCount = 0

	acc.fiDoLoginAndPayQuery()
	//5.1.23 更新这个包不发了
	acc.queryDAIFA()

	balance, err := acc.actQryPre()
	if err != nil {
		logger.Errorf("[CEB][%+v]登录查询余额数据错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	if err := acc.selectCard(balance); err != nil {
		logger.Errorf("[CEB][%+v]选择银行卡错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
	}

	logger.Infof("[CEB][%+v]用户登录成功.", acc.Account)
	acc.save()
	acc.onLoginSuccess()

	return pay.Success(nil)
}

// Logout 退出操作
func (acc *Account) Logout() *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求退出, 平台: %+v.", acc.Account, acc.Platform)

	acc.loginStatus = pay.LoginStatusNone
	pay.AccountLogout(acc.Account, acc.Platform, common.AccountTypeCEB)

	if acc.Proxy.URI != "" {
		pay.ReleaseProxy(acc.Proxy.URI)
		acc.setProxy("", "", "")
	}

	logger.Infof("[CEB][%+v]退出成功.", acc.Account)

	return pay.Success(nil)
}

// ResetPassword 修改密码
func (acc *Account) ResetPassword(password, payPassword string) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求修改密码, 平台: %+v.", acc.Account, acc.Platform)
	if err := acc.setPassword(password, payPassword); err != nil {
		logger.Warnf("[CEB][%+v]修改密码错误: %+v.", acc.Account, err)
	} else {
		logger.Infof("[CEB][%+v]修改密码成功.", acc.Account)
	}

	return pay.Success(nil)
}

// SendCode 获取短信验证码
func (acc *Account) SendCode() *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求发送验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {
		key, err := acc.fetchPublicKey()
		if err != nil {
			logger.Errorf("[CEB][%+v]获取加密公钥错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		//5.1.23更新
		if key.VersionType == "1" {
			logger.Errorf("[CEB][%+v]检则到版本需要强制更新, VersionType: %+v.", acc.Account, key.VersionType)
			return pay.Error(pay.ErrCodeSendCodeError, pay.ErrUpgradeRequired.Error(), nil)
		}

		if key.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]获取加密公钥失败, 代码: %+v, 信息: %+v.", acc.Account, key.Head.Code, key.Head.Msg)
			return pay.Error(pay.ErrCodeSendCodeError, key.Head.Msg, nil)
		}

		acc.sm2Key = key.SM2Key
		acc.sm4Key = key.SM4Key
		acc.publicKeyTimestamp = key.Timestamp

		token, err := acc.getToken()
		if err != nil {
			logger.Errorf("[CEB][%+v]获取token错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if token.Head.Status != 0 {
			logger.Errorf("[CEB][%+v]获取token失败, 代码: %+v, 信息: %+v.", acc.Account, token.Head.Status, token.Head.Msg)
			return pay.Error(pay.ErrCodeSendCodeError, token.Head.Msg, nil)
		}

		acc.Token = token.Token

		mobileToLogin, err := acc.getMobileToLogin(2)
		if err != nil {
			logger.Errorf("[CEB][%+v]MobileToLogin错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if mobileToLogin.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]MobileToLogin失败, 代码: %+v, 信息: %+v.", acc.Account, mobileToLogin.Head.Code, mobileToLogin.Head.Msg)
			return pay.Error(pay.ErrCodeSendCodeError, mobileToLogin.Head.Msg, nil)
		}

		acc.dynamicSM4Key = mobileToLogin.DynamicSM4Key
		acc.dynamicArrayKey = mobileToLogin.DynamicArrayKey
		acc.newDeviceFlag = mobileToLogin.NewDeviceFlag
		acc.loginFlag = mobileToLogin.LoginFlag

		// 等待验证码
		res, err := acc.toSendSMSPwd(acc.newDeviceDataMap)
		if err != nil {
			logger.Errorf("[CEB][%+v]发送登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
		}

		if res.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]发送登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, res.Head.Code, res.Head.Msg)
			return pay.Error(pay.ErrCodeSendCodeError, res.Head.Msg, nil)
		}

		acc.signatureSendSmsMD5 = res.SignatureSendSmsMD5
		acc.newDeviceDataMap = res.NewDeviceDataMap

		logger.Infof("[CEB][%+v]发送登录验证码成功.", acc.Account)
	} else if acc.loginStatus == pay.LoginStatusSuccess {
		if acc.transferConfirmInfo != nil {
			sms, err := acc.sendSMSPwd(acc.transferTargetAccount, acc.transferTargetName, acc.transferAmount, acc.transferConfirmInfo.SmsData)
			if err != nil {
				logger.Errorf("[CEB][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
				return pay.Error(pay.ErrCodeSendCodeError, err.Error(), nil)
			}

			if sms.Head.Code != resCodeSuccess {
				logger.Errorf("[CEB][%+v]发送转帐验证码失败, 代码: %+v, 信息: %+v.", acc.Account, sms.Head.Code, sms.Head.Msg)
				return pay.Error(pay.ErrCodeSendCodeError, sms.Head.Msg, nil)
			}

			logger.Infof("[CEB][%+v]发送转帐验证码成功.", acc.Account)
		} else {
			pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
		}
	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// VerifyCode 校验短信验证码
func (acc *Account) VerifyCode(code string) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求校验验证码, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus == pay.LoginStatusWaitCode {
		res, err := acc.toLogin(code)
		if err != nil {
			logger.Errorf("[CEB][%+v]校验登录验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeSMSCodeError, err.Error(), nil)
		}

		if res.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]校验登录验证码失败, 代码: %+v, 信息: %+v.", acc.Account, res.Head.Code, res.Head.Msg)

			// 重置密码
			if strings.Contains(res.Head.Msg, "为保证您的资金安全") {
				acc.freeze(pay.FreezeCodeAccountRisk, res.Head.Msg)
				logger.Errorf("[CEB][%+v]需要重置密码, 临时冻结帐号.", acc.Account)
			}

			// 验证码错误
			if strings.Contains(res.Head.Msg, "无效的动态口令") {
				acc.smscodeFailCount++
				if acc.smscodeFailCount >= 3 {
					acc.smscodeFailCount = 0
					acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
					logger.Errorf("[CEB][%+v]登录连续验证码错误, 临时冻结帐号.", acc.Account)
				}
			}

			// 密码错误
			if strings.Contains(res.Head.Msg, "用户名或登录密码错误") {
				acc.loginFailCount++
				if acc.loginFailCount >= 3 {
					acc.loginFailCount = 0
					acc.freeze(pay.FreezeCodePasswordError, pay.FreezeMsgPasswordError)
					logger.Errorf("[CEB][%+v]登录连续密码错误, 临时冻结帐号.", acc.Account)
				}
			}

			return pay.Error(pay.ErrCodeSMSCodeError, res.Head.Msg, nil)
		}

		acc.UserID = res.UserID
		acc.smscodeFailCount = 0
		acc.loginFailCount = 0

		acc.fiDoLoginAndPayQuery()
		acc.registGeTui()

		balance, err := acc.actQryPre()
		if err != nil {
			logger.Errorf("[CEB][%+v]登录查询余额数据错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		if err := acc.selectCard(balance); err != nil {
			logger.Errorf("[CEB][%+v]选择银行卡错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeLoginError, err.Error(), nil)
		}

		acc.save()
		acc.onLoginSuccess()

		logger.Infof("[CEB][%+v]校验登录验证码成功.", acc.Account)

	} else if acc.loginStatus == pay.LoginStatusSuccess {

	} else {
		return pay.Error(pay.ErrCodeNotNeedSMSCode, pay.ErrMsgNotNeedSMSCode, nil)
	}

	return pay.Success(nil)
}

// CardList 银行卡列表
func (acc *Account) CardList() *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求银行卡列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CEB][%+v]查询银行卡列表错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return nil
}

func (acc *Account) doBalance(first bool) *pay.ResultInfo {
	balance, err := acc.actQryPre()
	if err != nil {
		logger.Errorf("[CEB][%+v]查询余额错误: %+v.", acc.Account, err)
		if err == pay.ErrSessionTimeout && first {
			if err := acc.doRelogin(); err != nil {
				logger.Errorf("[CEB][%+v]查询余额重新登录帐与错误: %+v.", acc.Account, err)
				if err == pay.ErrNeedBindDevice {
					return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
				}

				return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
			}

			return acc.doBalance(false)
		}

		return pay.Error(pay.ErrCodeGetBalanceError, err.Error(), nil)
	}

	if balance.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]查询余额失败, 代码: %+v, 信息: %+v.", acc.Account, balance.Head.Code, balance.Head.Msg)
		return pay.Error(pay.ErrCodeGetBalanceError, balance.Head.Msg, nil)
	}

	for _, v := range balance.List {
		if v.AcID == acc.acID {
			res := model.AccountBalanceRes{}
			res.Code = common.ErrCodeSuccess
			res.Msg = common.ErrMsgSuccess
			res.Data.Amount = v.AvailBal
			res.Data.AmountAvailable = v.AvailBal
			return pay.Success(&res)
		}
	}

	logger.Errorf("[CEB][%+v]没有找到余额信息, 卡号: %s, Id: %s.", acc.Account, acc.CardNo, acc.acID)
	return pay.Error(pay.ErrCodeGetBalanceError, fmt.Sprintf("没有找到银行卡号[%s]的余额信息", acc.CardNo), nil)
}

// Balance 查余额
func (acc *Account) Balance() *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求查询余额, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CEB][%+v]查询余额错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBalance(true)
}

// datetimeConvert 把yyyyMMddhhmmss转换成yyyy-MM-dd hh:mm:ss
func datetimeConvert(dt string) string {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return dt
	}

	return time.Unix(tmp.Unix(), 0).Format("2006-01-02 15:04:05")
}

// dateTimeToUnix时间字符串转成unix时间戳
func dateTimeToUnix(dt string) int {
	loc, _ := time.LoadLocation("Local")
	tmp, err := time.ParseInLocation("20060102150405", dt, loc)
	if err != nil {
		return 0
	}

	return int(tmp.Unix())
}

func (acc *Account) doBillList(req *model.AccountBillListReq, first bool) *pay.ResultInfo {
	startDate, endDate := pay.GetBillListDate(req)
	logger.Infof("[CEB][%+v]查询帐单时间: %+v~%+v.", acc.Account, startDate, endDate)

	page := 0
	res := model.AccountBillListRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.Data = []model.AccountBillListInfo{}
	acc.actQryPre()
	for {

		transList, err := acc.actTrsQry(startDate, endDate, page)
		if err != nil {
			logger.Errorf("[CEB][%+v]查询帐单错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[CEB][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
				}

				return acc.doBillList(req, false)
			}

			return pay.Error(pay.ErrCodeGetBillListError, err.Error(), nil)
		}

		if transList.Head.Code != resCodeSuccess {
			if page == 0 {
				logger.Errorf("[CEB][%+v]查询帐单列表失败, 代码: %+v, 信息: %+v.", acc.Account, transList.Head.Code, transList.Head.Msg)
				return pay.Error(pay.ErrCodeGetBillListError, transList.Head.Msg, nil)
			}

			break
		}

		exit := false
		for _, item := range transList.List {
			// 时间查询判断条件
			if req.TimeType == common.TimeTypeByTime {
				ts := dateTimeToUnix(fmt.Sprintf("%s%06s", item.TransDate, item.TransTime))
				if ts == 0 || ts > req.EndTime {
					continue
				}

				if ts < req.StartTime {
					exit = true
					break
				}
			}

			info := model.AccountBillListInfo{
				TradeNo:        "",
				TradeTime:      datetimeConvert(fmt.Sprintf("%s%06s", item.TransDate, item.TransTime)),
				AmountRemain:   item.Balance,
				TargetAccount:  item.DUIFZH,
				TargetName:     item.DUIFMC,
				TargetBankName: item.DANWMC,
				Comment:        item.Remark,
			}

			if item.Spending != "--" && item.Income == "--" {
				info.TradeType = "0"
				info.Amount = item.Spending
			} else if item.Spending == "--" && item.Income != "--" {
				info.TradeType = "1"
				info.Amount = item.Income
			} else {
				logger.Errorf("[CEB][%+v]查询帐单出现未知的记帐方式, Spending: %+v, Income: %+v.",
					acc.Account, item.Spending, item.Income)
				continue
			}

			if req.QueryType == common.QueryTypeAll {
				res.Data = append(res.Data, info)
			} else if req.QueryType == common.QueryTypeIncome {
				if info.TradeType == "1" {
					res.Data = append(res.Data, info)
				}
			} else if req.QueryType == common.QueryTypePayout {
				if info.TradeType == "0" {
					res.Data = append(res.Data, info)
				}
			}
		}

		if exit {
			break
		}

		if len(transList.List) < 10 {
			break
		}

		page++

		if page > 20 {
			break
		}
	}

	return pay.Success(&res)
}

// BillList 查帐单
func (acc *Account) BillList(req *model.AccountBillListReq) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求查询帐单列表, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CEB][%+v]查询帐单错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doBillList(req, true)
}

func (acc *Account) doTransfer(req *model.AccountTransferReq, first bool) *pay.ResultInfo {
	if acc.transferPadding != 0 {
		return pay.Error(pay.ErrCodeTransferError, "转帐正在操作中, 请稍候再试", nil)
	}

	if req.SMSCode == "" {
		acc.actQryPre()
		pre, err := acc.bankTransferPre()
		if err != nil {
			logger.Errorf("[CEB][%+v]查询支付帐号信息错误: %+v.", acc.Account, err)
			if err == pay.ErrSessionTimeout && first {
				if err := acc.doRelogin(); err != nil {
					logger.Errorf("[CEB][%+v]查询帐单重新登录帐号错误: %+v.", acc.Account, err)
					if err == pay.ErrNeedBindDevice {
						return pay.Error(pay.ErrCodeLoginOtherDevice, pay.ErrMsgLoginOtherDevice, nil)
					}

					return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
				}

				return acc.doTransfer(req, false)
			}

			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if pre.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]查询支付帐号信息失败, 代码: %+v, 信息: %+v.", acc.Account, pre.Head.Code, pre.Head.Msg)
			return pay.Error(pay.ErrCodeTransferError, pre.Head.Msg, nil)
		}

		bankInfo, err := acc.transferBankQry(req.TargetAccount)
		if err != nil {
			logger.Errorf("[CEB][%+v]查询目标银行信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if bankInfo.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]查询目标银行信息失败, 代码: %+v, 信息: %+v.", acc.Account, bankInfo.Head.Code, bankInfo.Head.Msg)
			return pay.Error(pay.ErrCodeTransferError, bankInfo.Head.Msg, nil)
		}

		bankCode := ""
		bankNo := ""
		bankName := ""

		if len(bankInfo.List) > 0 {
			bankCode = bankInfo.List[0].PayeeBankID
			bankNo = bankInfo.List[0].SuperDeptID
			bankName = bankInfo.List[0].BankName
		} else if req.BankName != "" {
			// 尝试查找
			res, err := api.NodeQueryBankInfo(req.BankName)
			if err != nil {
				bankName = req.BankName
			} else {
				bankCode = res.BankCode
				bankNo = res.BankNo
				bankName = res.BankName
			}
		}

		if bankCode == "" || bankNo == "" {
			logger.Warnf("[CEB][%+v]查询到暂不支持的银行, 卡号: %+v, 银行名字: %+v, 银行代码: %+v, 银行编号: %+v.",
				acc.Account, req.TargetAccount, bankName, bankCode, bankNo)
			return pay.Error(pay.ErrCodeTransferError, pay.ErrMsgUnSupportBank, nil)
		}

		confirm, err := acc.bankTransferConfirmNew(bankCode, bankNo, bankName, pre.AvailBal, pre.PayerBankAcType, req.TargetAccount, req.TargetName,
			req.Amount, req.Comment)
		if err != nil {
			logger.Errorf("[CEB][%+v]确认转帐信息错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if confirm.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]确认转帐信息失败, 代码: %+v, 信息: %+v.", acc.Account, confirm.Head.Code, confirm.Head.Msg)
			return pay.Error(pay.ErrCodeTransferError, confirm.Head.Msg, nil)
		}

		if confirm.FallFlag != "0" {
			logger.Errorf("[CEB][%+v]确认转帐信息失败, FallFlag: %+v.", acc.Account, confirm.FallFlag)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		sms, err := acc.sendSMSPwd(req.TargetAccount, req.TargetName, req.Amount, confirm.SmsData)
		if err != nil {
			logger.Errorf("[CEB][%+v]发送转帐验证码错误: %+v.", acc.Account, err)
			return pay.Error(pay.ErrCodeTransferError, err.Error(), nil)
		}

		if sms.Head.Code != resCodeSuccess {
			logger.Errorf("[CEB][%+v]发送转帐验证码失败, 代码: %+v, 信息: %+v.", acc.Account, sms.Head.Code, sms.Head.Msg)
			return pay.Error(pay.ErrCodeTransferError, sms.Head.Msg, nil)
		}

		acc.transferTargetAccount = req.TargetAccount
		acc.transferTargetName = req.TargetName
		acc.transferAmount = req.Amount
		acc.transferComment = req.Comment
		acc.transferOrderNo = req.OrderNo
		acc.transferConfirmInfo = confirm

		logger.Infof("[CEB][%+v]发送转帐验证码成功.", acc.Account)

		return pay.Error(pay.ErrCodeNeedTransferCode, pay.ErrMsgNeedTransferCode, nil)
	}

	if acc.transferConfirmInfo == nil {
		logger.Warnf("[CEB][%+v]尚未生成支付订单.", acc.Account)
		return pay.Error(pay.ErrCodeTransferError, pay.ErrNotCreateOrderNo.Error(), nil)
	}

	atomic.StoreInt32(&acc.transferPadding, 1)

	defer func() {
		atomic.StoreInt32(&acc.transferPadding, 0)
	}()

	transfer, body, err := acc.bankTransfer(acc.transferConfirmInfo, req.SMSCode)
	if err != nil {
		// timeout时要人工确认订单状态, 暂时返回处理中
		if err == pay.ErrOperationTimeout {
			logger.Warnf("[CEB][%+v]转帐操作超时, 需工人检查是否转帐成功, 转出卡号: %+v, 名字: %+v, 金额: %+v.",
				acc.Account, acc.transferConfirmInfo.PayeeAcNo, acc.transferConfirmInfo.PayeeAcName, acc.transferConfirmInfo.Amount)

			res := model.AccountTransferRes{}
			res.Code = common.ErrCodeSuccess
			res.Msg = common.ErrMsgSuccess
			res.ExtData = req.ExtData
			res.Status = common.TransferStatusProcessing
			res.Data.TradeNo = acc.transferConfirmInfo.JNLNo
			res.Data.TradeType = "0"
			res.Data.Amount = acc.transferConfirmInfo.Amount
			res.Data.AmountRemain = acc.transferConfirmInfo.AvailBal
			res.Data.TargetAccount = acc.transferConfirmInfo.PayeeAcNo
			res.Data.TargetName = acc.transferConfirmInfo.PayeeAcName
			res.Data.TargetBankName = acc.transferConfirmInfo.BankName
			res.Data.Comment = acc.transferConfirmInfo.Remark

			api.NodeLogTransfer(
				acc.Account,
				acc.Platform,
				common.AccountTypeCEB,
				acc.transferOrderNo,
				res.Data.TradeNo,
				res.Data.TargetAccount,
				res.Data.TargetName,
				res.Data.Amount,
				res.Data.AmountRemain,
				res.Status)

			logger.LogTransfer("[CEB][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
				acc.Account,
				res.Data.TargetName,
				res.Data.TargetAccount,
				res.Data.Amount,
				res.Status,
				acc.transferOrderNo,
				res.Data.TradeNo,
				"转帐操作超时, 需要人工核对转帐是否完成.")

			return pay.Success(&res)
		}

		logger.Errorf("[CEB][%+v]转帐操作错误: %+v.", acc.Account, err)
		return pay.Error(pay.ErrCodeTransferError, "转帐操作错误", nil)
	}

	if transfer.Head.Code != resCodeSuccess {
		logger.Errorf("[CEB][%+v]转帐操作失败, 代码: %+v, 信息: %+v.",
			acc.Account, transfer.Head.Code, transfer.Head.Msg)

		msg := transfer.Head.Msg
		if strings.Contains(msg, "已挂失") {
			acc.loginStatus = pay.LoginStatusNone
			api.ReportAccStateLogout(acc.Account, acc.Platform, common.AccountTypeCEB)
			return pay.Error(pay.ErrCodeCardReportLost, pay.ErrMsgCardReportLost, nil)
		}

		if strings.Contains(msg, "只收不付") {
			acc.loginStatus = pay.LoginStatusNone
			return pay.Error(pay.ErrCodeCardBlock, msg, nil)
		}

		if strings.Contains(msg, "数据库表正忙") || strings.Contains(msg, "中间业务平台处理失败") || strings.Contains(msg, "外部系统运行缓慢") {
			return pay.Error(pay.ErrCodeTransferError, "银行系统正忙, 请稍候再试", nil)
		}

		if strings.Contains(msg, "验密失败") {
			acc.smscodeFailCount++
			if acc.smscodeFailCount >= 3 {
				acc.smscodeFailCount = 0
				acc.freeze(pay.FreezeCodeSMSCodeError, pay.FreezeMsgSMSCodeError)
				logger.Errorf("[CEB][%+v]连续转帐验证码错误, 临时冻结帐号.", acc.Account)
			}
		}

		if strings.Contains(msg, "交易密码错误") {
			acc.payPasswordFailCount++
			if acc.payPasswordFailCount >= 3 {
				acc.payPasswordFailCount = 0
				acc.freeze(pay.FreezeCodePayPasswordError, pay.FreezeMsgPayPasswordError)
				logger.Errorf("[CEB][%+v]连续支付密码错误, 临时冻结帐号.", acc.Account)
			}
		}

		return pay.Error(pay.ErrCodeTransferError, transfer.Head.Msg, nil)
	}

	acc.transferConfirmInfo = nil
	acc.smscodeFailCount = 0
	acc.payPasswordFailCount = 0

	res := model.AccountTransferRes{}
	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess
	res.ExtData = req.ExtData

	res.Status = common.TransferStatusSuccess
	res.Data.TradeNo = transfer.JnlNoMsg
	res.Data.TradeType = "0"
	res.Data.Amount = transfer.Amount
	res.Data.AmountRemain = "未知"
	res.Data.TargetAccount = transfer.PayeeAcNo
	res.Data.TargetName = transfer.PayeeAcName
	res.Data.TargetBankName = transfer.BankName
	res.Data.Comment = transfer.Remark

	balance, err := acc.actQryPre()
	if err == nil && len(balance.List) > 0 {
		for _, v := range balance.List {
			if v.AcID == acc.acID {
				res.Data.AmountRemain = v.AvailBal
			}
		}
	}

	api.NodeLogTransfer(
		acc.Account,
		acc.Platform,
		common.AccountTypeCEB,
		acc.transferOrderNo,
		res.Data.TradeNo,
		res.Data.TargetAccount,
		res.Data.TargetName,
		res.Data.Amount,
		res.Data.AmountRemain,
		res.Status)

	logger.LogTransfer("[CEB][%+v]向[%s]卡号[%s]转帐[%s]成功, 状态: %d, 订单号: %s, 流水号: %s, 银行返回数据: %s.",
		acc.Account,
		res.Data.TargetName,
		res.Data.TargetAccount,
		res.Data.Amount,
		res.Status,
		acc.transferOrderNo,
		res.Data.TradeNo,
		body)

	return pay.Success(&res)
}

// Transfer 转帐
func (acc *Account) Transfer(req *model.AccountTransferReq) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求帐转, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CEB][%+v]转帐错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	pass := acc.getPayPassword()
	if strings.TrimSpace(pass) == "" || len(pass) <= 0 {
		logger.Errorf("[CEB][%+v]支付密码为空.", acc.Account)
		return pay.Error(pay.ErrCodePayPasswordNotExists, pay.ErrMsgPayPasswordNotExists, nil)
	}

	return acc.doTransfer(req, true)
}

func (acc *Account) doTransferStatus(req *model.AccountTransferStatusReq, first bool) *pay.ResultInfo {
	return pay.Error(pay.ErrCodeTransferStatusError, "该银行不支持查询转帐状态, 请登录网上银行自行查询", nil)
}

// TransferStatus 查询转帐状态
func (acc *Account) TransferStatus(req *model.AccountTransferStatusReq) *pay.ResultInfo {
	logger.Infof("[CEB][%+v]请求查询转帐状态, 平台: %+v.", acc.Account, acc.Platform)

	if acc.loginStatus != pay.LoginStatusSuccess {
		logger.Warnf("[CEB][%+v]查询转帐状态错误, 帐号尚未登录.", acc.Account)
		return pay.Error(pay.ErrCodeNotLogined, pay.ErrMsgNotLogined, nil)
	}

	return acc.doTransferStatus(req, true)
}

// Event 事件处理
func (acc *Account) Event(event int, data string) *pay.ResultInfo {
	return nil
}

// SetCardNo 设置主卡号
func (acc *Account) SetCardNo(cardNo string) {
	acc.CardNo = cardNo
}
