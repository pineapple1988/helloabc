package api

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"pay/utils"
	"pay/utils/config"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"
	"time"
)

const (
	pathAuthInit             = "/api/v1/auth/init"
	pathAuthGetToken         = "/api/v1/auth/gettoken"
	pathAccountGetInfo       = "/api/v1/account/getaccinfo"
	pathAccountUploadInfo    = "/api/v1/account/upaccinfo"
	pathAccountGetCookie     = "/api/v1/account/getcookie"
	pathAccountUploadCookie  = "/api/v1/account/upcookie"
	pathAccountGetExtInfo    = "/api/v1/account/getextinfo"
	pathAccountUploadExtInfo = "/api/v1/account/upextinfo"
	pathAccountGetFaceImages = "/api/v1/account/getfaceimages"
	pathNodeInit             = "/api/v1/node/init"
	pathNodeAccState         = "/api/v1/node/accstate"
	pathNodePing             = "/api/v1/node/ping"
	pathNodeLogTransfer      = "/api/v1/node/logtransfer"
	pathNodeTransferStatus   = "/api/v1/node/transferstatus"
	pathNodeAccountFreeze    = "/api/v1/node/freeze"
	pathNodeFaceImageError   = "/api/v1/node/faceimageerror"
	pathNodeQueryBankInfo    = "/api/v1/node/querybankinfo"
	pathProxyAlloc           = "/api/v1/proxy/alloc"
	pathProxyRelease         = "/api/v1/proxy/release"
)

var (
	httpClient  *http.Client
	urlBase     string
	appID       string
	appKey      string
	secKey      string
	nodeGUID    string
	nodeName    string
	nodeAccType int
	nodeMaxUser int
	nodeURL     string
	token       string
	initialized bool
)

func init() {
	httpClient = &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				MinVersion:         tls.VersionTLS12,
				InsecureSkipVerify: true,
			},
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 20,
		},
		Timeout: time.Millisecond * 10000,
	}

	initialized = false
}

func getParam(appid, ts, sign string) string {
	values := url.Values{}
	values.Add("appid", appid)
	values.Add("ts", ts)
	values.Add("sign", sign)

	return values.Encode()
}

func apiCallSuccess(code int) bool {
	return code == common.ErrCodeSuccess
}

func postJSON(path string, req, res interface{}, signData bool) error {
	// 序列化请求数据
	data, err := json.Marshal(req)
	if err != nil {
		return err
	}

	url := urlBase + path

	// 需要签名数据
	if signData {
		// 签名时必须有token数据
		if token == "" {
			return errors.New("没有token数据进行签名")
		}
		ts := common.GetTS()
		sign := common.Sign(appID, ts, string(data), token)
		url = url + "?" + getParam(appID, ts, sign)
	}

	// 提交数据
	resp, err := httpClient.Post(url, "application/json", bytes.NewReader(data))
	if err != nil {
		return err
	}

	defer resp.Body.Close()

	// 读取返回数据
	arr, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	// 反序列化返回数据
	err = json.Unmarshal(arr, res)

	return err
}

func postJSONSigned(path string, req, res interface{}) error {
	return postJSON(path, req, res, true)
}

// apiMonitor api监控, 发消息到后端
func apiMonitor() {
	failures := 0
	sendNotify := false
	for {
		time.Sleep(time.Millisecond * 30000)
		if err := NodePing(); err != nil {
			failures++
		} else {
			if sendNotify {
				// 发送过, 提醒服务恢复, 并关闭
				sendNotify = false
			}
			failures = 0
		}

		if failures > 5 {
			// 发送警报
			failures = 0
			sendNotify = true
		}
	}
}

// GetPlatformCode 取平台代码
func GetPlatformCode(name string) int {
	return common.GetPlatformCode(name)
}

// GetNodeGUID 取节点guid
func GetNodeGUID() string {
	return nodeGUID
}

// GetNodeAccType 取节点帐号类型
func GetNodeAccType() int {
	return nodeAccType
}

// SetConfig 设置配置
func SetConfig(cfg *config.Config) {
	urlBase = cfg.DeviceService
	appID = cfg.App.AppID
	appKey = cfg.App.AppKey
	secKey = cfg.App.SecKey

	nodeGUID = cfg.Node.GUID
	nodeName = cfg.Node.Name
	nodeAccType = cfg.Node.AccType
	nodeMaxUser = cfg.Node.MaxUser
	nodeURL = cfg.Node.URL
}

// Init 初始化
func Init() error {
	if initialized {
		return nil
	}

	initReq := model.AuthInitReq{
		AppID:  appID,
		AppKey: appKey,
	}
	initRes := model.AuthInitRes{}

	if err := postJSON(pathAuthInit, &initReq, &initRes, false); err != nil {
		logger.Errorf("[api]初始化错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(initRes.Code) {
		msg := fmt.Sprintf("[api]初始化失败, 代码: %d, 信息: %s", initRes.Code, initRes.Msg)
		logger.Warnf(msg)
		return errors.New(msg)
	}

	getTokenReq := model.AuthGetTokenReq{
		AppID:    appID,
		AuthData: common.GetAuthData(initRes.Data.AuthData, secKey),
	}
	getTokenRes := model.AuthGetTokenRes{}

	if err := postJSON(pathAuthGetToken, &getTokenReq, &getTokenRes, false); err != nil {
		logger.Errorf("[api]获取Token错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(getTokenRes.Code) {
		msg := fmt.Sprintf("[api]获取token失败, 代码: %d, 信息: %s", getTokenRes.Code, getTokenRes.Msg)
		logger.Warnf(msg)
		return errors.New(msg)
	}

	token = getTokenRes.Data.Token

	if err := nodeInit(); err != nil {
		return err
	}

	initialized = true

	// api 监控
	go apiMonitor()

	return nil
}

// AccountGetInfo 获取帐号信息
func AccountGetInfo(account string, platform int) (string, error) {
	if err := Init(); err != nil {
		return "", err
	}

	req := model.AccountGetAccInfoReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account

	res := model.AccountGetAccInfoRes{}

	if err := postJSONSigned(pathAccountGetInfo, &req, &res); err != nil {
		logger.Errorf("[api]AccountGetInfo操作错误: %+v.", err)
		return "", err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountGetInfo返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return "", fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return res.Data, nil
}

// AccountUploadInfo 上传帐号信息
func AccountUploadInfo(account string, platform int, data string) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.AccountUpAccInfoReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account
	req.Data = data

	res := model.AccountGetAccInfoRes{}

	if err := postJSONSigned(pathAccountUploadInfo, &req, &res); err != nil {
		logger.Errorf("[api]AccountUploadInfo操作错误: %+v.", err)
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountUploadInfo返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// AccountGetCookie 取帐号Cookie
func AccountGetCookie(account string, platform int) (string, error) {
	if err := Init(); err != nil {
		return "", err
	}

	req := model.AccountGetCookieReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account

	res := model.AccountGetCookieRes{}

	if err := postJSONSigned(pathAccountGetCookie, &req, &res); err != nil {
		logger.Errorf("[api]AccountGetCookie操作错误: %+v.", err)
		return "", err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountGetCookie返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return "", fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return res.Data, nil
}

// AccountUploadCookie 上传帐号Cookie
func AccountUploadCookie(account string, platform int, data string) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.AccountUpCookieReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account
	req.Data = data

	res := model.AccountUpCookieRes{}

	if err := postJSONSigned(pathAccountUploadCookie, &req, &res); err != nil {
		logger.Errorf("[api]AccountUploadCookie操作错误: %+v.", err)
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountUploadCookie返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// AccountGetExtInfo 取帐号扩展信息
func AccountGetExtInfo(account string, platform int) (string, error) {
	if err := Init(); err != nil {
		return "", err
	}

	req := model.AccountGetExtInfoReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account

	res := model.AccountGetExtInfoRes{}

	if err := postJSONSigned(pathAccountGetExtInfo, &req, &res); err != nil {
		logger.Errorf("[api]AccountGetExtInfo操作错误: %+v.", err)
		return "", err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountGetExtInfo返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return "", fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return res.Data, nil
}

// AccountUploadExtInfo 上传账号扩展信息
func AccountUploadExtInfo(account string, platform int, data string) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.AccountUpExtInfoReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account
	req.Data = data

	res := model.AccountUpExtInfoRes{}

	if err := postJSONSigned(pathAccountUploadExtInfo, &req, &res); err != nil {
		logger.Errorf("[api]AccountUploadExtInfo操作错误: %+v.", err)
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountUploadExtInfo返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

//AccountGetFaceImages 取刷脸图片
func AccountGetFaceImages(account, platform string, acctype int, onlyAvailable bool) (*model.AccountGetFaceImagesRes, error) {
	if err := Init(); err != nil {
		return nil, err
	}

	req := model.AccountGetFaceImagesReq{}
	req.AccType = acctype
	req.Platform = GetPlatformCode(platform)
	req.Account = account
	req.OnlyAvailable = onlyAvailable

	res := model.AccountGetFaceImagesRes{}

	if err := postJSONSigned(pathAccountGetFaceImages, &req, &res); err != nil {
		logger.Errorf("[api]AccountGetFaceImages操作错误: %+v.", err)
		return nil, err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]AccountGetFaceImages返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return nil, fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return &res, nil
}

// nodeInit 节点初始化
func nodeInit() error {
	req := model.NodeInitReq{
		GUID:    nodeGUID,
		Name:    nodeName,
		AccType: nodeAccType,
		URL:     nodeURL,
		MaxUser: nodeMaxUser,
	}

	res := model.NodeInitRes{}

	if err := postJSONSigned(pathNodeInit, &req, &res); err != nil {
		logger.Errorf("[api]NodeInit操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeInit返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeAccState 节点帐号状态
func NodeAccState(account, platform string, acctype, state int) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodeAccStateReq{
		GUID:    nodeGUID,
		AccType: acctype,
	}

	req.Data = append(req.Data, model.AccStateInfo{
		Platform: GetPlatformCode(platform),
		Account:  account,
		State:    state,
	})

	res := model.NodeAccStateRes{}

	if err := postJSONSigned(pathNodeAccState, &req, &res); err != nil {
		logger.Errorf("[api]NodeAccState操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeAccState返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// ReportAccStateNone 无状态
func ReportAccStateNone(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateNone)
}

// ReportAccStateLogout 退出状态
func ReportAccStateLogout(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateLogout)
}

// ReportAccStateKickout 被挤状态
func ReportAccStateKickout(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateKickout)
}

// ReportAccStateInvalidPassword 帐号或密码错误
func ReportAccStateInvalidPassword(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateInvalidPassword)
}

// ReportAccStateNeedFaceScan 要刷脸登录
func ReportAccStateNeedFaceScan(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateNeedFaceScan)
}

// ReportAccStateLoginPadding 登录进行中
func ReportAccStateLoginPadding(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateLoginPadding)
}

// ReportAccStateLoginWaitSMSCode 要验证码登录
func ReportAccStateLoginWaitSMSCode(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateLoginWaitSMSCode)
}

// ReportAccStateLoginSuccess 登录成功
func ReportAccStateLoginSuccess(account, platform string, acctype int) error {
	return NodeAccState(account, platform, acctype, common.AccountStateLoginSuccess)
}

// NodePing 节点ping
func NodePing() error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodePingReq{
		GUID: nodeGUID,
		TS:   utils.GetTimeStampEx(),
	}

	res := model.NodePingRes{}

	if err := postJSONSigned(pathNodePing, &req, &res); err != nil {
		logger.Errorf("[api]NodePing操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodePing返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeLogTransfer 记录日志
func NodeLogTransfer(account, platform string, acctype int, orderNo, tradeNo, targetAccount, targetName, amount, amountRemain string, status int) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodeLogTransferReq{}
	req.Account = account
	req.AccType = acctype
	req.Platform = common.GetPlatformCode(platform)
	req.OrderNo = orderNo
	req.TradeNo = tradeNo
	req.TargetAccount = targetAccount
	req.TargetName = targetName
	req.Amount = amount
	req.AmountRemain = amountRemain
	req.Status = status

	res := model.NodeLogTransferRes{}

	if err := postJSONSigned(pathNodeLogTransfer, &req, &res); err != nil {
		logger.Errorf("[api]NodeLogTransfer操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeLogTransfer返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeTransferStatus 转帐状态
func NodeTransferStatus(tradeNo string, status int) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodeTransferStatusReq{}
	req.TradeNo = tradeNo
	req.Status = status

	res := model.NodeTransferStatusRes{}

	if err := postJSONSigned(pathNodeTransferStatus, &req, &res); err != nil {
		logger.Errorf("[api]NodeTransferStatus操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeTransferStatus返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeAccountFreeze 临时冻结帐号
func NodeAccountFreeze(account, platform string, acctype, code int, reason string) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodeFreezeReq{}
	req.Account = account
	req.AccType = acctype
	req.Platform = common.GetPlatformCode(platform)
	req.Code = code
	req.Reason = reason

	res := model.NodeFreezeRes{}

	if err := postJSONSigned(pathNodeAccountFreeze, &req, &res); err != nil {
		logger.Errorf("[api]NodeFreeze操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeFreeze返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeFaceImageError 刷脸图片错误
func NodeFaceImageError(account, platform string, acctype int, hash string) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.NodeFaceImageErrorReq{}
	req.Account = account
	req.AccType = acctype
	req.Platform = common.GetPlatformCode(platform)
	req.Hash = hash

	res := model.NodeFaceImageErrorRes{}

	if err := postJSONSigned(pathNodeFaceImageError, &req, &res); err != nil {
		logger.Errorf("[api]NodeFaceImageError错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeFaceImageError返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}

// NodeQueryBankInfo 查询银行信息
func NodeQueryBankInfo(bankName string) (*model.NodeQueryBankInfoRes, error) {
	if err := Init(); err != nil {
		return nil, err
	}

	req := model.NodeQueryBankInfoReq{
		BankName: bankName,
	}

	res := model.NodeQueryBankInfoRes{}

	if err := postJSONSigned(pathNodeQueryBankInfo, &req, &res); err != nil {
		logger.Errorf("[api]NodeQueryBankInfo错误: %+v.", err)
		return nil, err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]NodeQueryBankInfo返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return nil, fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return &res, nil
}

// ProxyAlloc 申请分配代理
func ProxyAlloc(account string, platform int) (*utils.ProxyInfo, error) {
	if err := Init(); err != nil {
		return nil, err
	}

	req := model.ProxyAllocReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account
	req.ProxyType = "s5"

	res := model.ProxyAllocRes{}

	if err := postJSONSigned(pathProxyAlloc, &req, &res); err != nil {
		logger.Errorf("[api]ProxyAlloc操作错误: %+v.", err)
		return nil, err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]ProxyAlloc返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return nil, fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return &utils.ProxyInfo{
		URI:  res.Data.URI,
		User: res.Data.User,
		Pass: res.Data.Pass,
	}, nil
}

// ProxyRelease 释放代理
func ProxyRelease(account string, platform int) error {
	if err := Init(); err != nil {
		return err
	}

	req := model.ProxyReleaseReq{}
	req.AccType = nodeAccType
	req.Platform = platform
	req.Account = account
	req.ProxyType = "s5"

	res := model.ProxyAllocRes{}

	if err := postJSONSigned(pathProxyRelease, &req, &res); err != nil {
		logger.Errorf("[api]ProxyRelease操作错误: %+v.", err)
		return err
	}

	if !apiCallSuccess(res.Code) {
		logger.Warnf("[api]ProxyRelease返回失败, 代码: %d, 信息: %s.", res.Code, res.Msg)
		return fmt.Errorf("错误代码: %d, 信息: %s", res.Code, res.Msg)
	}

	return nil
}
