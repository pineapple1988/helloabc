package alipaymsg

import (
	fmt "fmt"
	"testing"

	"github.com/golang/protobuf/proto"
)

func TestMMTPHead(t *testing.T) {
	buf := []byte{16, 3, 32, 1, 56, 1}
	req := &MmtpHead{}
	if err := proto.Unmarshal(buf, req); err != nil {
		t.Fatalf("反序列化错误: %+v.", err)
	}

	fmt.Println(req)

	req = &MmtpHead{
		Type:             proto.Uint32(3),
		ZipType:          proto.Uint32(1),
		DataFrameChannel: proto.Uint32(0),
	}

	data, err := proto.Marshal(req)
	if err != nil {
		t.Fatalf("序列化错误: %+v.", err)
	}

	fmt.Println(data)
}
