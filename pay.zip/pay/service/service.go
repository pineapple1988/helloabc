package service

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"pay/service/ap"
	"pay/service/bank"
	"pay/utils/config"
	"pay/utils/logger"
	"time"

	"github.com/gin-gonic/gin"
)

var (
	srv http.Server
)

func index(c *gin.Context) {
	c.String(http.StatusOK, "Server is ready...")
}

func ginLogger() gin.HandlerFunc {
	return func(c *gin.Context) {
		path := c.Request.URL.Path
		raw := c.Request.URL.RawQuery

		c.Next()

		ip := c.ClientIP()
		method := c.Request.Method
		code := c.Writer.Status()
		msg := c.Errors.ByType(gin.ErrorTypePrivate).String()

		if raw != "" {
			path = path + "?" + raw
		}

		str := fmt.Sprintf("|%3d|%15s|%-7s %s %s", code, ip, method, path, msg)
		logger.LogGin(str)
	}
}

func getHandler() *gin.Engine {
	route := gin.New()
	route.Use(ginLogger(), gin.Recovery())

	// 默认页面
	route.GET("/", index)

	// 支付宝
	route.POST("/ap/qrscan", ap.QRScan)
	route.POST("/ap/getqrcode", ap.GetQRCode)

	// 微信

	// 银行
	route.POST("/bank/login", bank.Login)
	route.POST("/bank/logout", bank.Logout)
	route.POST("/bank/resetpass", bank.ResetPass)
	route.POST("/bank/sendcode", bank.SendCode)
	route.POST("/bank/verifycode", bank.VerifyCode)
	route.POST("/bank/cardlist", bank.CardList)
	route.POST("/bank/balance", bank.Balance)
	route.POST("/bank/billlist", bank.BillList)
	route.POST("/bank/transfer", bank.Transfer)
	route.POST("/bank/transferstatus", bank.TransferStatus)
	route.POST("/bank/event", bank.Event)

	return route
}

// SetMode 设置模式
func SetMode(debug bool) {
	if debug {
		gin.SetMode(gin.DebugMode)
		logger.Info("[service]设置gin为调试模式")
	} else {
		gin.SetMode(gin.ReleaseMode)
	}
}

// ListenAndServe 监听并服务
func ListenAndServe(address string) error {
	SetMode(config.IsDebug())
	l, err := net.Listen("tcp", address)
	if err != nil {
		return err
	}

	srv = http.Server{
		Handler: getHandler(),
		TLSConfig: &tls.Config{
			MinVersion: tls.VersionTLS12,
		},
	}

	if config.IsUseTLS() {
		go srv.ServeTLS(l, "./cert/ssl.crt", "./cert/ssl.key")
	} else {
		go srv.Serve(l)
	}

	return nil
}

// Shutdown 关闭服务
func Shutdown() {
	logger.Info("[service]开始关闭服务.")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		logger.Errorf("[service]关闭服务错误: %+v.", err)
		return
	}
	logger.Info("[service]关闭服务完成.")
}
