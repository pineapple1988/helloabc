package bank

import (
	"encoding/json"
	"fmt"
	"pay/api"
	"pay/mgr/accmgr"
	"pay/service/notify"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"

	"github.com/gin-gonic/gin"
)

func checkPlatform(platform int) bool {
	switch platform {
	case common.PlatformIOS,
		common.PlatformAndroid:
		return true
	}

	return false
}

func getRequestLog(funcName string, req interface{}) string {
	j, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[bank]getRequestLog数据序列化错误: %+v.", err)
		return fmt.Sprintf("[bank]%s请求, 原始数据: %+v.", funcName, req)
	}

	return fmt.Sprintf("[bank]%s请求, JSON数据: %s.", funcName, string(j))
}

func reportLogout(account string, accType, platform int) {
	api.ReportAccStateLogout(account, common.GetPlatformName(platform), accType)
}

// Login 用户登录
func Login(c *gin.Context) {
	var req notify.LoginReq
	var res model.AccountLoginRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]Login解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("Login", &req))

	if !checkPlatform(req.Platform) {
		notify.InvalidPlatform(c)
		logger.Errorf("[bank]Login错误的平台: %+v.", req.Platform)

		return
	}

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		// 创建帐号
		var err error
		acc, err = accmgr.CreateAccount(req.Account, req.Password, req.PayPassword, req.AccType, req.Platform)

		if err != nil {
			notify.Result(c, notify.ErrCodeCreateAccount, notify.ErrMsgCreateAccount, nil)
			logger.Errorf("[bank]Login创建帐户失败, 帐号: %+v, 类型: %+v, 平台: %+v, 错误: %+v.",
				req.Account, req.AccType, req.Platform, err)

			return
		}

		// 添加到帐号管理
		if err := accmgr.AddAccount(req.AccType, acc); err != nil {
			notify.Result(c, notify.ErrCodeCreateAccount, notify.ErrMsgCreateAccount, nil)
			logger.Errorf("[bank]Login添加帐号到帐号管理器错误: %+v.", err)

			return
		}
	}

	acc.SetCardNo(req.CardNo)
	result := acc.Login(20000)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]Login尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	res.Code = result.Code
	res.Msg = result.Msg

	notify.Success(c, &res)

	logger.Infof("[bank]Login用户登录, 用户: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)

}

// Logout 用户退出
func Logout(c *gin.Context) {
	var req model.AccountLogoutReq
	var res model.AccountLogoutRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]Logout解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("Logout", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]Logout没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.Logout()
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]Logout尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	res.Code = result.Code
	res.Msg = result.Msg

	notify.Success(c, &res)

	logger.Infof("[bank]Logout用户退出登录, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// ResetPass 重置帐号密码
func ResetPass(c *gin.Context) {
	var req model.AccountResetPassReq
	var res model.AccountResetPassRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]ResetPass解释请求数据错误: %+v.", err)

		return
	}

	//logger.Info(getRequestLog("ResetPass", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]ResetPass没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.ResetPassword(req.Password, req.PayPassword)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]ResetPass尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	res.Code = result.Code
	res.Msg = result.Msg

	notify.Success(c, &res)

	logger.Infof("[bank]ResetPass重置密码, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, res.Code, res.Msg)
}

// SendCode 发送验证码
func SendCode(c *gin.Context) {
	var req model.SMSSendReq
	var res model.SMSSendRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]SendCode解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("SendCode", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]SendCode没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.SendCode()
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]SendCode尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	res.Code = result.Code
	res.Msg = result.Msg

	notify.Success(c, &res)

	logger.Infof("[bank]SendCode用户请求验证码, 用户: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// VerifyCode 校验验证码
func VerifyCode(c *gin.Context) {
	var req model.SMSVerifyReq
	var res model.SMSVerifyRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]VerifyCode解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("VerifyCode", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]VerifyCode没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.VerifyCode(req.SMSCode)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]VerifyCode尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	res.Code = result.Code
	res.Msg = result.Msg

	notify.Success(c, &res)

	logger.Infof("[bank]VerifyCode用户校验验证码, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// CardList 卡列表
func CardList(c *gin.Context) {
	var req model.AccountCardListReq
	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]CardList解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("CardList", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]CardList没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.CardList()
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]CardList尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]CardList获取银行卡列表, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// Balance 余额
func Balance(c *gin.Context) {
	var req model.AccountBalanceReq
	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]Balance解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("Balance", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]Balance没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.Balance()
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]Balance尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]Balance获取账户余额, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// BillList 帐单列表
func BillList(c *gin.Context) {
	var req model.AccountBillListReq
	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]BillList解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("BillList", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]BillList没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.BillList(&req)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]BillList尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]BillList获取帐单列表, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// Transfer 转帐
func Transfer(c *gin.Context) {
	var req model.AccountTransferReq
	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]Transfer解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("Transfer", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]Transfer没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.Transfer(&req)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]Transfer尚未实现接口, 帐号: %+v, 类型: %+v. 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]Transfer用户转帐, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// TransferStatus 转帐状态
func TransferStatus(c *gin.Context) {
	var req model.AccountTransferStatusReq
	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]TransferStatus解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("TransferStatus", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]TransferStatus没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.TransferStatus(&req)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]TransferStatus尚未实现接口, 帐号: %+v, 类型: %+v, 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]TransferStatus查询转帐状态, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}

// Event 事件通知
func Event(c *gin.Context) {
	var req notify.EventReq

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[bank]Event解释请求数据错误: %+v.", err)

		return
	}

	logger.Info(getRequestLog("Event", &req))

	acc := accmgr.GetAccount(req.AccType, req.Account)
	if acc == nil {
		reportLogout(req.Account, req.AccType, req.Platform)
		notify.AccountNotFound(c)
		logger.Warnf("[bank]Event没有找到指定的帐号, 帐号: %+v, 类型: %+v.",
			req.Account, req.AccType)

		return
	}

	result := acc.Event(req.Event, req.Data)
	if result == nil {
		notify.NotImplementation(c)
		logger.Warnf("[bank]Event尚未实现接口, 帐号: %+v, 类型: %+v, 平台: %+v.",
			req.Account, req.AccType, req.Platform)

		return
	}

	if result.Code == 0 {
		notify.Success(c, result.Data)
	} else {
		notify.Fail(c, result.Code, result.Msg)
	}

	logger.Infof("[bank]Event用户事件处理, 帐号: %+v, 代码: %+v, 信息: %+v.",
		req.Account, result.Code, result.Msg)
}
