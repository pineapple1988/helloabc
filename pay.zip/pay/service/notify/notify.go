package notify

import (
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

// Result 通知返回
func Result(c *gin.Context, code int, msg string, obj interface{}) {
	res := APINotifyRes{
		Code: code,
		Msg:  msg,
		Data: "",
	}

	// 存在数据
	if obj != nil {
		if j, err := json.Marshal(obj); err == nil {
			res.Data = string(j)
		}
	}

	c.JSON(http.StatusOK, &res)
}

// Success 通知成功
func Success(c *gin.Context, obj interface{}) {
	Result(c, ErrCodeSuccess, ErrMsgSuccess, obj)
}

// Fail 通知失败
func Fail(c *gin.Context, code int, msg string) {
	Result(c, code, msg, nil)
}

// InvalidRequest 错误的请求数据
func InvalidRequest(c *gin.Context) {
	Result(c, ErrCodeInvalidRequest, ErrMsgInvalidRequest, nil)
}

// InvalidAccType 错误的帐号类型
func InvalidAccType(c *gin.Context) {
	Result(c, ErrCodeInvalidAccType, ErrMsgInvalidAccType, nil)
}

// InvalidPlatform 错误的平台
func InvalidPlatform(c *gin.Context) {
	Result(c, ErrCodeInvalidPlatform, ErrMsgInvalidPlatform, nil)
}

// AccountNotFound 找不到指定帐号
func AccountNotFound(c *gin.Context) {
	Result(c, ErrCodeAccountNotFound, ErrMsgAccountNotFound, nil)
}

// NotImplementation 接口未实现
func NotImplementation(c *gin.Context) {
	Result(c, ErrCodeNotImplementation, ErrMsgNotImplementation, nil)
}
