package notify

const (
	ErrCodeSuccess           = 0
	ErrMsgSuccess            = "操作成功"
	ErrCodeInvalidRequest    = 2000
	ErrMsgInvalidRequest     = "请求数据错误"
	ErrCodeInvalidAccType    = 2001
	ErrMsgInvalidAccType     = "错误的帐号类型"
	ErrCodeInvalidPlatform   = 2002
	ErrMsgInvalidPlatform    = "错误的平台类型"
	ErrCodeAccountNotFound   = 2003
	ErrMsgAccountNotFound    = "没有找到指定的帐号"
	ErrCodeCreateAccount     = 2004
	ErrMsgCreateAccount      = "创建帐号错误"
	ErrCodeNotImplementation = 2005
	ErrMsgNotImplementation  = "该接口尚未实现"
	ErrCodeGetQRCodeError    = 2006
	ErrMsgGetQRCodeError     = "生成收款二维码错误"
	ErrCodeQRScanError       = 2007
	ErrMsgQRScanError        = "扫描二维码错误"
)

const (
	// EventTypeNone 无事件
	EventTypeNone = iota

	// EventTypeLoadFaceImages 加载刷脸图片事件
	EventTypeLoadFaceImages
)
