package notify

// LoginReq 登录请求
type LoginReq struct {
	AccType     int    `json:"accType" binding:"required"`
	Platform    int    `json:"platform" binding:"required"`
	Account     string `json:"account" binding:"required"`
	Password    string `json:"password" binding:"required"`
	PayPassword string `json:"payPassword"`
	CardNo      string `json:"cardNo"`
}

// EventReq 事件请求
type EventReq struct {
	AccType  int    `json:"accType"`
	Platform int    `json:"platform"`
	Account  string `json:"account"`
	Event    int    `json:"event"`
	Data     string `json:"data"`
}

// APINotifyRes 通知响应
type APINotifyRes struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
	Data string `json:"data"`
}
