package ap

import (
	"encoding/json"
	"fmt"
	"pay/mgr/accmgr"
	"pay/service/notify"
	"pay/utils/logger"
	"payserver/common"
	"payserver/common/model"

	"github.com/gin-gonic/gin"
)

func getRequestLog(funcName string, req interface{}) string {
	j, err := json.Marshal(req)
	if err != nil {
		logger.Errorf("[ap]getRequestLog数据序列化错误: %+v.", err)
		return fmt.Sprintf("[ap]%s请求, 原始数据: %+v.", funcName, req)
	}

	return fmt.Sprintf("[ap]%s请求, JSON数据: %s.", funcName, string(j))
}

// QRScan 二维码扫描
func QRScan(c *gin.Context) {
	var req model.AlipayQRScanReq
	var res model.AlipayQRScanRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[ap]QRScan解释请求数据错误: %+v.", err)

		return
	}

	logger.Infof(getRequestLog("QRScan", &req))

	acc := accmgr.GetAlipayMgr().Get(req.Account)
	if acc == nil {
		notify.AccountNotFound(c)
		logger.Warnf("[ap]QRScan没有找到指定的帐号, 帐号: %+v.", req.Account)

		return
	}

	err := acc.QRScan(req.URL)
	if err != nil {
		notify.Fail(c, notify.ErrCodeQRScanError, err.Error())
		logger.Errorf("[ap]QRScan扫描二维码错误, 帐号: %+v, 错误: %+v.", req.Account, err)

		return
	}

	res.Code = common.ErrCodeSuccess
	res.Msg = common.ErrMsgSuccess

	notify.Success(c, &res)

	logger.Infof("[ap]QRScan扫描二维码成功, 帐号: %+v.", req.Account)
}

// GetQRCode 获取二维码
func GetQRCode(c *gin.Context) {
	var req model.AlipayGetQRCodeReq
	var res model.AlipayGetQRCodeRes

	if err := c.ShouldBind(&req); err != nil {
		notify.InvalidRequest(c)
		logger.Errorf("[ap]GetQRCode解释请求数据错误: %+v.", err)

		return
	}

	logger.Infof(getRequestLog("GetQRCode", &req))

	//校验数据
	if req.SetAmount {
		if req.Amount == "" || req.Description == "" {
			notify.InvalidRequest(c)
			logger.Warnf("[ap]GetQRCode设置了设置金额参数, 但金额或描述为空, 帐号: %+v.", req.Account)

			return
		}
	}

	acc := accmgr.GetAlipayMgr().Get(req.Account)
	if acc == nil {
		notify.AccountNotFound(c)
		logger.Warnf("[ap]GetQRCode没有找到指定的帐号, 帐号: %+v.", req.Account)

		return
	}

	qrCodeURL, printQRCodeURL, err := acc.GetQRCode(req.Amount, req.Description, req.SetAmount)
	if err != nil {
		notify.Fail(c, notify.ErrCodeGetQRCodeError, err.Error())
		logger.Errorf("[ap]GetQRCode生成收款二维码失败, 帐号: %+v, 错误: %+v.",
			req.Account, err)

		return
	}

	res.Code = notify.ErrCodeSuccess
	res.Msg = notify.ErrMsgSuccess
	res.Data.QRCodeURL = qrCodeURL
	res.Data.PrintQRCodeURL = printQRCodeURL
	notify.Success(c, &res)

	logger.Infof("[ap]AccountGetQRCode生成收款二维码成功, 帐号: %+v, QRCodeURL: %+v, PrintQRCodeURL: %+v.",
		req.Account, qrCodeURL, printQRCodeURL)
}
