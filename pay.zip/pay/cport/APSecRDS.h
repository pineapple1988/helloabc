#pragma once

#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <string.h>
#include "ida.h"

extern int EncryptAndSign(uint8_t *in, int len, uint8_t *out);