package cport

/*
 #include "./APSecRDS.h"
 #include "./CFString.h"
*/
import "C"

func EncryptAndSign(in []byte) []byte {
	buf := make([]byte, 0x2000)
	len := C.EncryptAndSign((*C.uint8_t)(&in[0]), C.int(len(in)), (*C.uint8_t)(&buf[0]))

	return buf[:int(len)]
}

func CFStringHash(str string) uint64 {
	buf := []byte(str)
	result := C.__CFStringHash((*C.uint8_t)(&buf[0]), C.int(len(buf)))
	return uint64(result)
}
