#include "APSecRDS.h"

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wshift-count-overflow"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wbitwise-op-parentheses"
#endif

typedef uint8*(*fnPtrFun)(uint8 *, int);

uint8 uint8_104760678[] = {
    0, 1, 3, 7, 0xF, 0x1F, 0x3F, 0x7F, 0xFF, 0, 0, 0, 0,
    0, 0, 0
};

const char *aLtScriptGt = "&lt,script&gt";

const char *a1tScriptGt = "&1t,script&gt";

const char *aItScriptGt = "&it,script&gt";

const char *a1tScriptGt_0 = "&1t;script&gt";

uint8* sub_100ABEB30(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (*v2 >> 4) & 0xF | 16 * *v2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEB54(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = (*v2 >> 4) & 0xF | 16 * *v2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEB78(uint8 *result, int a2)
{
    int v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
        {
            *(uint8 *)(result + v2) ^= aLtScriptGt[(signed int)(v2
                - 13
                * ((1321528399LL * (signed int)v2 >> 34)
                    + ((unsigned __int64)(1321528399LL * (signed int)v2) >> 63)))];
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABEBCC(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
        {
            *(uint8 *)(result + v2) ^= aLtScriptGt[(signed int)(v2
                - 13
                * ((1321528399LL * (signed int)v2 >> 34)
                    + ((unsigned __int64)(1321528399LL * (signed int)v2) >> 63)))];
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABEC20(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 68;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEC40(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 68;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEC60(uint8 *result, int a2)
{
    __int64 v2; // x8
    char v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            v4 = *(uint8 *)(result + v2) - 1;
            *(uint8 *)(result + v2) = v4;
            *(uint8 *)(result + v2) = (v4 >> (v2 - (v3 & 0xF8))) & uint8_104760678[8LL - (((_DWORD)v2 - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (v2 - (v3 & 0xF8))));
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABECCC(uint8 *result, int a2)
{
    __int64 v2; // x8
    int v3; // w11

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            *(uint8 *)(result + v2) = ((*(uint8 *)(result + v2) >> (8 - (v2 - (v3 & 0xF8)))) & uint8_104760678[((unsigned int)v2 - (v3 & 0xFFFFFFF8)) & 0xFFLL] | (*(uint8 *)(result + v2) << (v2 - (v3 & 0xF8))))
                + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABED30(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABED74(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABEDB8(uint8 *result, int a2)
{
    char v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEDE0(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEE08(uint8 *result, int a2)
{
    int v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            *v3++ ^= (v2 ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
            --a2;
            v2 = (v2 ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEE3C(uint8 *result, int a2)
{
    return sub_100ABEE08(result, a2);
}

uint8* sub_100ABEE40(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEE64(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEE88(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -54;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEEB0(uint8 *result, int a2)
{
    signed int v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 202;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEED4(uint8 *result, int a2)
{
    signed int v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            v2 ^= *v3;
            *v3++ = v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEEF8(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -53;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEF20(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w10
    int v4; // w12
    int v5; // w11

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = -44;
        do
        {
            v4 = 0;
            LOBYTE(v5) = 0;
            do
            {
                v3 = (uint8)v3;
                v5 = (1 << v4) & (uint8)v3 | (uint8)v5;
                v3 = (4 * v3 ^ 32 * v3) & 0x80 | (v3 >> 1);
                ++v4;
            } while (v4 != 8);
            *(uint8 *)(result + v2++) ^= v5;
        } while (v2 != a2);
    }
    return result;
}

uint8* sub_100ABEF84(uint8 *result, int a2)
{
    return sub_100ABEF20(result, a2);
}

uint8* sub_100ABEF88(uint8 *result, int a2)
{
    uint8 *v2; // x10
    unsigned int v3; // w11

    if (a2)
    {
        v2 = result;
        do
        {
            v3 = *v2 & 0xF ^ ((unsigned int)(uint8)*v2 >> 4) | (uint8)(*v2 & 0xF0);
            *v2++ = (v3 >> 1) & 0x55 | 2 * v3 & 0xAA;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEFC8(uint8 *result, int a2)
{
    return sub_100ABEF88(result, a2);
}

uint8* sub_100ABEFCC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 2;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABEFF4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = 16 * (*v2 - 2) & 0xF0 | ((uint8)(*v2 - 2) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF01C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 3;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF044(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = 16 * (*v2 - 3) & 0xF0 | ((uint8)(*v2 - 3) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF06C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 4;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF094(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = 16 * (*v2 - 4) & 0xF0 | ((uint8)(*v2 - 4) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF0BC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = ((*v2 >> 4) & 0xF | 16 * *v2) + 5;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF0E4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 = 16 * (*v2 - 5) & 0xF0 | ((uint8)(*v2 - 5) >> 4);
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF10C(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= aLtScriptGt[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned long long)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8* sub_100ABF160(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= aLtScriptGt[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8* sub_100ABF1B4(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
        {
            *(uint8 *)(result + v2) ^= a1tScriptGt[v2
                + 2
                - 13
                * ((unsigned __int64)((unsigned __int64)(v2 + 2)
                    * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF208(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
        {
            *(uint8 *)(result + v2) ^= a1tScriptGt[v2
                + 2
                - 13
                * ((unsigned __int64)((unsigned __int64)(v2 + 2)
                    * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF25C(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= aItScriptGt[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8* sub_100ABF2B0(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= aItScriptGt[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8* sub_100ABF304(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= a1tScriptGt_0[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8*  sub_100ABF358(uint8 *result, int a2)
{
    __int64 v2; // x8

    if (a2)
    {
        v2 = 0LL;
        do
            *(uint8 *)(result + v2) ^= a1tScriptGt_0[v2
            + 1
            - 13
            * ((unsigned __int64)((unsigned __int64)(v2 + 1)
                * (unsigned __int64)0x4EC4EC4EC4EC4EC5uLL >> 64) >> 2)];
        while (a2 != v2++ + 1);
    }
    return result;
}

uint8* sub_100ABF3AC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 67;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF3CC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 67;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF3EC(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 68;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF40C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 68;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF42C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 69;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF44C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 69;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF46C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ += 70;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF48C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2++ -= 70;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABF4AC(uint8 *result, int a2)
{
    __int64 v2; // x8
    char v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            v4 = *(uint8 *)(result + v2) - 2;
            *(uint8 *)(result + v2) = v4;
            *(uint8 *)(result + v2) = (v4 >> (v2 - (v3 & 0xF8))) & uint8_104760678[8LL - (((_DWORD)v2 - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (v2 - (v3 & 0xF8))));
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF518(uint8 *result, int a2)
{
    __int64 v2; // x8
    int v3; // w11

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            *(uint8 *)(result + v2) = ((*(uint8 *)(result + v2) >> (8 - (v2 - (v3 & 0xF8)))) & uint8_104760678[((unsigned int)v2 - (v3 & 0xFFFFFFF8)) & 0xFFLL] | (*(uint8 *)(result + v2) << (v2 - (v3 & 0xF8))))
                + 2;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF57C(uint8 *result, int a2)
{
    __int64 v2; // x8
    char v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            v4 = *(uint8 *)(result + v2) - 1;
            *(uint8 *)(result + v2) = v4;
            *(uint8 *)(result + v2) = (v4 >> (v2 - (v3 & 0xF8) + 1)) & uint8_104760678[8LL
                - (((_DWORD)v2 - (v3 & 0xF8) + 1) & 0xFF)] | (v4 << (7 - (v2 - (v3 & 0xF8))));
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF5EC(uint8 *result, int a2)
{
    __int64 v2; // x8
    int v3; // w11

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            *(uint8 *)(result + v2) = ((*(uint8 *)(result + v2) >> (7 - (v2 - (v3 & 0xF8)))) & uint8_104760678[((unsigned int)v2 - (v3 & 0xFFFFFFF8) + 1) & 0xFFLL] | (*(uint8 *)(result + v2) << (v2 - (v3 & 0xF8) + 1)))
                + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF654(uint8 *result, int a2)
{
    __int64 v2; // x8
    char v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            v4 = *(uint8 *)(result + v2) - 1;
            *(uint8 *)(result + v2) = v4;
            *(uint8 *)(result + v2) = ((v4 >> (v2 - (v3 & 0xF8))) & uint8_104760678[8LL - (((_DWORD)v2 - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (v2 - (v3 & 0xF8)))))
                + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF6C4(uint8 *result, int a2)
{
    __int64 v2; // x8
    uint8 v3; // w11
    int v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = *(uint8 *)(result + v2) - 1;
            *(uint8 *)(result + v2) = v3;
            v4 = v2 + 7;
            if ((signed int)v2 >= 0)
                v4 = v2;
            *(uint8 *)(result + v2) = ((v3 >> (8 - (v2 - (v4 & 0xF8)))) & uint8_104760678[((unsigned int)v2 - (v4 & 0xFFFFFFF8)) & 0xFFLL] | (v3 << (v2 - (v4 & 0xF8))))
                + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF734(uint8 *result, int a2)
{
    __int64 v2; // x8
    char v3; // w11
    uint8 v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = v2 + 7;
            if ((signed int)v2 >= 0)
                v3 = v2;
            v4 = *(uint8 *)(result + v2) - 1;
            *(uint8 *)(result + v2) = v4;
            *(uint8 *)(result + v2) = ((v4 >> (v2 - (v3 & 0xF8))) & uint8_104760678[8LL - (((_DWORD)v2 - (v3 & 0xF8)) & 0xFF)] | (v4 << (8 - (v2 - (v3 & 0xF8)))))
                + 2;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF7A4(uint8 *result, int a2)
{
    __int64 v2; // x8
    uint8 v3; // w11
    int v4; // w12

    if (a2)
    {
        v2 = 0LL;
        do
        {
            v3 = *(uint8 *)(result + v2) - 2;
            *(uint8 *)(result + v2) = v3;
            v4 = v2 + 7;
            if ((signed int)v2 >= 0)
                v4 = v2;
            *(uint8 *)(result + v2) = ((v3 >> (8 - (v2 - (v4 & 0xF8)))) & uint8_104760678[((unsigned int)v2 - (v4 & 0xFFFFFFF8)) & 0xFFLL] | (v3 << (v2 - (v4 & 0xF8))))
                + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF814(uint8* result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 53;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00) + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF85C(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 53;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00) + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF8A4(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00) + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF8EC(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= v3;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00) + 1;
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF934(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= (uint8)v3 + 1;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF97C(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= (uint8)v3 + 1;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABF9C4(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= (uint8)v3 + 2;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABFA0C(uint8 *result, int a2)
{
    __int64 v2; // x8
    unsigned int v3; // w9
    int v4; // w9
    int v5; // w10

    if (a2)
    {
        v2 = 0LL;
        LOBYTE(v3) = 54;
        do
        {
            *(uint8 *)(result + v2) ^= (uint8)v3 + 2;
            v4 = (uint8)v3 * (_DWORD)v2;
            v5 = v4 + 255;
            if (v4 >= 0)
                v5 = v4;
            v3 = v4 - (v5 & 0xFFFFFF00);
            ++v2;
        } while (a2 != v2);
    }
    return result;
}

uint8* sub_100ABFA54(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x10
    char v4; // w9

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFA80(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 1;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFAAC(uint8 *result, int a2)
{
    char v2; // w8
    uint8 *v3; // x9
    char v4; // w10

    if (a2)
    {
        v2 = 104;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 1;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFAD8(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 1;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFB04(uint8 *result, int a2)
{
    char v2; // w8
    uint8 *v3; // x9
    char v4; // w10

    if (a2)
    {
        v2 = 104;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 2;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFB30(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = 102;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFB5C(uint8 *result, int a2)
{
    char v2; // w8
    uint8 *v3; // x9
    char v4; // w10

    if (a2)
    {
        v2 = 105;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            v2 = v4 + 2;
            *v3++ = v4;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFB88(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = 103;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2 + 2;
            ++v3;
            --a2;
            v2 = v4;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFBB4(uint8 *result, int a2)
{
    int v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            *v3++ ^= ((v2 + 1) ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
            --a2;
            v2 = ((v2 + 1) ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFBEC(uint8 *result, int a2)
{
    return sub_100ABFBB4(result, a2);
}

uint8* sub_100ABFBF0(uint8 *result, int a2)
{
    unsigned int v2; // w8
    uint8 *v3; // x9

    if (a2)
    {
        v2 = 201;
        v3 = result;
        do
        {
            v2 = (v2 ^ 16 * (uint8)v2) & 0xF0 | ((unsigned int)(uint8)v2 >> 4);
            *v3++ ^= v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFC24(uint8 *result, int a2)
{
    return sub_100ABFBF0(result, a2);
}

uint8* sub_100ABFC28(uint8 *result, int a2)
{
    int v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            *v3++ ^= ((v2 + 1) ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
            --a2;
            v2 = ((v2 + 1) ^ 16 * v2) & 0xF0 | ((uint8)v2 >> 4);
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFC60(uint8 *result, int a2)
{
    return sub_100ABFC28(result, a2);
}

uint8* sub_100ABFC64(uint8 *result, int a2)
{
    int v2; // w9
    uint8 *v3; // x8

    if (a2)
    {
        v2 = 203;
        v3 = result;
        do
        {
            *v3++ ^= (v2 ^ 16 * v2) & 0xF0 | ((uint8)(v2 + 1) >> 4);
            --a2;
            v2 = (v2 ^ 16 * v2) & 0xF0 | ((uint8)(v2 + 1) >> 4);
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFC9C(uint8 *result, int a2)
{
    return sub_100ABFC64(result, a2);
}

uint8* sub_100ABFCA0(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFCC4(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xE;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFCE8(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xC;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFD0C(uint8 *result, int a2)
{
    uint8 *v2; // x8

    if (a2)
    {
        v2 = result;
        do
        {
            *v2 ^= (uint8)(*v2 >> 4) ^ 0xC;
            ++v2;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFD30(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w9

    if (a2)
    {
        v2 = -58;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 5;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFD5C(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -58;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 5;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFD84(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w9

    if (a2)
    {
        v2 = -51;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 1;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFDB0(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -51;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 1;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFDD8(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x10
    char v4; // w9

    if (a2)
    {
        v2 = -51;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFE04(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -51;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 + 1;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFE2C(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w9

    if (a2)
    {
        v2 = -53;
        v3 = result;
        do
        {
            v4 = *v3 ^ v2;
            *v3++ = v4;
            v2 = v4 - 3;
            --a2;
        } while (a2);
    }
    return result;
}

uint8* sub_100ABFE58(uint8 *result, int a2)
{
    char v2; // w9
    uint8 *v3; // x8
    char v4; // w10

    if (a2)
    {
        v2 = -53;
        v3 = result;
        do
        {
            v4 = *v3;
            *v3 ^= v2;
            ++v3;
            v2 = v4 - 3;
            --a2;
        } while (a2);
    }
    return result;
}

void sub_100ABDD44(fnPtrFun *result)
{
    *result = sub_100ABEB30;
    result[1] = sub_100ABEB54;
    result[2] = sub_100ABEB78;
    result[3] = sub_100ABEBCC;
    result[4] = sub_100ABEC20;
    result[5] = sub_100ABEC40;
    result[6] = sub_100ABEC60;
    result[7] = sub_100ABECCC;
    result[8] = sub_100ABED30;
    result[9] = sub_100ABED74;
    result[10] = sub_100ABEDB8;
    result[11] = sub_100ABEDE0;
    result[12] = sub_100ABEE08;
    result[13] = sub_100ABEE3C;
    result[14] = sub_100ABEE40;
    result[15] = sub_100ABEE64;
    result[16] = sub_100ABEE88;
    result[17] = sub_100ABEEB0;
    result[18] = sub_100ABEED4;
    result[19] = sub_100ABEEF8;
    result[20] = sub_100ABEF20;
    result[21] = sub_100ABEF84;
    result[22] = sub_100ABEF88;
    result[23] = sub_100ABEFC8;
    result[24] = sub_100ABEFCC;
    result[25] = sub_100ABEFF4;
    result[26] = sub_100ABF01C;
    result[27] = sub_100ABF044;
    result[28] = sub_100ABF06C;
    result[29] = sub_100ABF094;
    result[30] = sub_100ABF0BC;
    result[31] = sub_100ABF0E4;
    result[32] = sub_100ABF10C;
    result[33] = sub_100ABF160;
    result[34] = sub_100ABF1B4;
    result[35] = sub_100ABF208;
    result[36] = sub_100ABF25C;
    result[37] = sub_100ABF2B0;
    result[38] = sub_100ABF304;
    result[39] = sub_100ABF358;
    result[40] = sub_100ABF3AC;
    result[41] = sub_100ABF3CC;
    result[42] = sub_100ABF3EC;
    result[43] = sub_100ABF40C;
    result[44] = sub_100ABF42C;
    result[45] = sub_100ABF44C;
    result[46] = sub_100ABF46C;
    result[47] = sub_100ABF48C;
    result[48] = sub_100ABF4AC;
    result[49] = sub_100ABF518;
    result[50] = sub_100ABF57C;
    result[51] = sub_100ABF5EC;
    result[52] = sub_100ABF654;
    result[53] = sub_100ABF6C4;
    result[54] = sub_100ABF734;
    result[55] = sub_100ABF7A4;
    result[56] = sub_100ABF814;
    result[57] = sub_100ABF85C;
    result[58] = sub_100ABF8A4;
    result[59] = sub_100ABF8EC;
    result[60] = sub_100ABF934;
    result[61] = sub_100ABF97C;
    result[62] = sub_100ABF9C4;
    result[63] = sub_100ABFA0C;
    result[64] = sub_100ABFA54;
    result[65] = sub_100ABFA80;
    result[66] = sub_100ABFAAC;
    result[67] = sub_100ABFAD8;
    result[68] = sub_100ABFB04;
    result[69] = sub_100ABFB30;
    result[70] = sub_100ABFB5C;
    result[71] = sub_100ABFB88;
    result[72] = sub_100ABFBB4;
    result[73] = sub_100ABFBEC;
    result[74] = sub_100ABFBF0;
    result[75] = sub_100ABFC24;
    result[76] = sub_100ABFC28;
    result[77] = sub_100ABFC60;
    result[78] = sub_100ABFC64;
    result[79] = sub_100ABFC9C;
    result[80] = sub_100ABFCA0;
    result[81] = sub_100ABFCC4;
    result[82] = sub_100ABFCE8;
    result[83] = sub_100ABFD0C;
    result[84] = sub_100ABFD30;
    result[85] = sub_100ABFD5C;
    result[86] = sub_100ABFD84;
    result[87] = sub_100ABFDB0;
    result[88] = sub_100ABFDD8;
    result[89] = sub_100ABFE04;
    result[90] = sub_100ABFE2C;
    result[91] = sub_100ABFE58;
    result[92] = NULL;
    result[93] = NULL;
}

// 字节数组 2 字符数组 长度翻倍
int sub_100ABCB38(uint8 *a1, int a2, uint8 *a3, int *a4)
{
    int result; // x0
    signed __int64 v5; // x8
    unsigned int v6; // w9
    char v7; // w9
    unsigned int v8; // w9
    unsigned int v9; // w8
    char v10; // w8

    if (2 * a2 > *a4)
        return -1;

    *a4 = 0;
    if (a1 && a2)
    {
        v5 = 0LL;
        do
        {
            v6 = *a1 & 0xF;
            if (v6 > 9)
                v7 = v6 + 87;
            else
                v7 = v6 | 0x30;
            a3[v5 + 1] = v7;
            v8 = *a1;
            v9 = v8 >> 4;
            if (v8 > 0x9F)
                v10 = v9 + 87;
            else
                v10 = v9 | 0x30;
            a3[*a4] = v10;
            v5 = *a4 + 2;
            *a4 = v5;
            ++a1;
            --a2;
        } while (a2);
        result = 0;
    }
    else
    {
        result = 0;
        *a3 = 0;
    }
    return result;
}

int EncryptAndSign(uint8_t *in, int len, uint8_t *out)
{
    fnPtrFun fnFunAry[94];
    sub_100ABDD44(fnFunAry);

    srand((unsigned)time(NULL));
    uint8 randA = rand();
    uint8 randB = rand();
    uint8 randC = rand();

    //uint8 randA = 0x25;
    //uint8 randB = 0x17;
    //uint8 randC = 0xD5;

    uint8 randFunA = randA - 46 * (0xB21642C9LL * randA >> 37);
    uint8 randFunB = randB - 46 * (0xB21642C9LL * randB >> 37);
    uint8 randFunC = randC - 46 * (0xB21642C9LL * randC >> 37);

    fnPtrFun fnFunA = fnFunAry[randFunA * 0x10 / 8];
    fnPtrFun fnFunB = fnFunAry[randFunB * 0x10 / 8];
    fnPtrFun fnFunC = fnFunAry[randFunC * 0x10 / 8];

    fnFunA(in, len);
    fnFunB(in, len);
    fnFunC(in, len);

    uint8 randAry[] = { randA, randB, randC };
    int randOL = 2 * 3 | 1;
    uint8 randOutAry[0x10] = { 0 };
    sub_100ABCB38(randAry, sizeof(randAry), randOutAry, &randOL);

    int ol = 2 * len | 1;
    uint8 contentOutAry[0x2048] = { 0 };
    sub_100ABCB38(in, len, contentOutAry, &ol);

    memcpy(out, randOutAry, randOL);
    memcpy(out + randOL, contentOutAry, ol);
    
    return randOL + ol;
}

#ifdef __GNUC__
#pragma clang diagnostic pop
#pragma GCC diagnostic pop
#endif
