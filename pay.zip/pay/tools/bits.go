package tools

import "reflect"

// RotateLeft 左移[]byte
// eg RotateLeft([1 2 3 4], 1) -> [4 1 2 3]
func RotateLeft(buf []byte, step int) []byte {
	step = step % len(buf)

	tmpAll := make([]byte, len(buf))
	copy(tmpAll, buf)

	tmp := make([]byte, step)
	copy(tmp, tmpAll[:step])

	tmpAll = append(tmpAll[step:], tmp...)
	copy(buf, tmpAll)
	return buf
}

// RotateRight 右移[]byte
// eg RotateLeft([1 2 3 4], 1) -> [2 3 4 1]
func RotateRight(buf []byte, step int) []byte {
	bufLen := len(buf)
	step = step % bufLen

	tmpAll := make([]byte, len(buf))
	copy(tmpAll, buf)

	tmp := make([]byte, step)
	copy(tmp, tmpAll[bufLen-step:])

	tmpAll = append(tmp, tmpAll[:bufLen-step]...)
	copy(buf, tmpAll)
	return buf
}

// ReverseSlice 反转切片
// eg [1, 2, 3, 4] -> [4, 3, 2, 1]
func ReverseSlice(s interface{}) interface{} {
	size := reflect.ValueOf(s).Len()
	if size <= 0 {
		return nil
	}

	swap := reflect.Swapper(s)
	for i, j := 0, size-1; i < j; i, j = i+1, j-1 {
		swap(i, j)
	}

	return s
}
