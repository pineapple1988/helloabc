package tools

import (
	"crypto/sha1"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"testing"
)

func TestRotateLeft(t *testing.T) {
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 1))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateLeft([]byte{1, 2, 3, 4}, 5))
}

func TestRotateRight(t *testing.T) {
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 1))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 3))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 4))
	fmt.Println(RotateRight([]byte{1, 2, 3, 4}, 5))
}

func TestReverseSlice(t *testing.T) {
	fmt.Println(ReverseSlice([]byte{1, 2, 3, 4}))
}

func TestTaichi(t *testing.T) {
	key := []byte("Xiaomao19221")
	data := "O0kCDA4="
	bdData, _ := base64.StdEncoding.DecodeString(data)

	keyIndex := 0
	for i := 0; i < len(bdData); i++ {
		if keyIndex >= len(key) {
			keyIndex = 0
		}

		bdData[i] = bdData[i] ^ key[keyIndex]
		keyIndex++
	}

	fmt.Println(string(bdData))
}

func TestTaichiEncrypt(t *testing.T) {
	pkgName := "com.cmi.jegotrip"
	version :=  "9F8D90CAB7622E6586BEB07F506CEBB3"

	versionBytes,_ := hex.DecodeString(version)
	md := sha1.Sum([]byte(pkgName))
	key := make([]byte, 12)
	key = append(md[:], key...)
	iv := make([]byte, 16)
	out := AESCBCDecrypt(versionBytes, key, iv)
	fmt.Println(hex.Dump(out))
}