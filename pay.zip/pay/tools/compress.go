package tools

import (
	"bytes"
	"compress/gzip"
	"compress/zlib"
	"io"
	"io/ioutil"
)

// GZipCompress gzip压缩数据
func GZipCompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	w := gzip.NewWriter(&out)
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// GZipUncompress gzip解压数据
func GZipUncompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	r, err := gzip.NewReader(bytes.NewBuffer(in))
	if err != nil {
		return nil, err
	}

	if _, err := io.Copy(&out, r); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// ZLibCompress zlib压缩数据
func ZLibCompress(in []byte) ([]byte, error) {
	out := bytes.Buffer{}
	w := zlib.NewWriter(&out)
	if _, err := w.Write(in); err != nil {
		return nil, err
	}

	if err := w.Close(); err != nil {
		return nil, err
	}

	return out.Bytes(), nil
}

// ZLibUncompress zlib解压数据
func ZLibUncompress(in []byte) ([]byte, error) {
	r, err := zlib.NewReader(bytes.NewReader(in))
	if err != nil {
		return nil, err
	}

	return ioutil.ReadAll(r)
}
