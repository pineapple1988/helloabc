package tools

import (
	"pay/tools/gmsm/sm2"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/pem"
	"fmt"
	"testing"
)

func TestSm2(t *testing.T) {
	ss := `-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAEv3+t5KZeJc5KcqW0Ye83Tn3EjAc7
KHrIzCpvmNao3CwhrVC6TDzOU1zA3Afr1q6C2t69WsXOeGkC3oJYUOJRng==
-----END PUBLIC KEY-----`
	pub, _ := sm2.ReadPublicKeyFromMem([]byte(ss), nil)
	fmt.Println(pub.X)
	fmt.Println(pub.Y)
}

func TestRSAPrivDecrypt(t *testing.T) {
	encryptData := "HWYqXE5HhHtmxJs3oEd3hRunbwKzCud4ArTobtZEUMsSETVB3iQkAzg3SBalAds5wBfikW7aLggGRBn4QiP9NHTQmX6iqlEOR/5Lq3T+ErBOLFR1DgetlFqh6itvgXdBTbpJKGDt9CvBgj6mtv2dKYXyQToYVpTQloDjaPjZI1lHXH81kkEO2xoH3iZof6VinZcyNDRJlJf8gvia188z4mNj9Ai/22Dc3jIy2J3aPxsgw9ye1sm1KHzf8sp67Y8U0CrZLjsRO4EqMXpfx7xIRrdA2RGJmOImhz/qrCiyhE8fDX+uU0PFOYFzdW6ZfeWi90ZBQ5A7UqatZGI6dY8k+w=="
	inData, _ := base64.StdEncoding.DecodeString(encryptData)
	keyData := `-----BEGIN PRIVATE KEY-----
MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAIyBWOenr4VY3wzX43biTmb1JoSR
AGve8SfEOQfQdndQGBV5O3v8DKSV57kLP8I0hqWXw8beWpmKI01fV9v+5tlBB1bNtwCjIFhK2O+S
vgev7xDZaSb6jFnPWEaKOWgSlbAXsOZXLQAslJygcw7DH1v2r+UgVCQCUVQGt0GO2M3FAgMBAAEC
gYAf1xoSGRZ2Bf859lyGLt+shkaNyRxK1bFZnSZ9ZljKTfy/NQNtY99rlsr1zJ5MwMF4mi1UDkSC
weKhIIeVA61FXXReIKj5lhpo7Wyrfh1Brb0cQ4pzweYdR3FoCKBQ/6b3AresciPx/BeJ4fY7AtsZ
6W05gttGJ3P+iNSbJ/Sm2wJBAMHDkLUvSapRtm0xxH5LOl2zjyAq9c0ZPXJL9Eckb0ruQfW9JLN2
sFGNUc2XZ1oLmMoxKgb8YOH7k78eF7ks6GMCQQC5oojXsLE0ZYktHYedDvnGvjwH0MXpi6Ls817n
sTegsJAsVaCHomr8iZS6iMKZ0FNNmwboRZo+fTUgN5vrNEW3AkBMcp1obvTQhxbDtEwDTCkGCS8i
EPET765npwIFA6IJXUGW8/5D9EMSmgA5bk/vnf21YHplcTPEVV7wm63eeJJjAkEAiIQjJpvmdaYG
D4ub48DTp3jXJNg/89Sg6KjBrpoBUscF/9SozZaAH1/+ZH+WvQ8bdAMCPWaSXEov+5VpsLssWQJB
AIa/y+A4hwA7vvgqSaqjQol0FmDgDpKdAuav7Ks53bTRncz/DTnyed995EgJeOPiikfYHThAjDXo
1EznwbxAkZ8=
-----END PRIVATE KEY-----`
	p, _ := pem.Decode([]byte(keyData))
	privKey, _ := x509.ParsePKCS8PrivateKey(p.Bytes)
	privKey1 := privKey.(*rsa.PrivateKey)
	outData, _ := RSADecrypt(inData, privKey1)
	fmt.Println(hex.Dump(outData))
}
