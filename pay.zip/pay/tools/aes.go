package tools

import (
	"crypto/aes"
	"crypto/cipher"
	"pay/tools/cipher2"
)

// AESCBCEncrypt 使用PKCS7填充
func AESCBCEncrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)

	in = pkcs7Pad(in, c.BlockSize())
	out := make([]byte, len(in))

	e := cipher.NewCBCEncrypter(c, iv)
	e.CryptBlocks(out, in)

	return out
}

// AESCBCDecrypt 去除PKCS7填充
func AESCBCDecrypt(in, key, iv []byte) []byte {
	c, _ := aes.NewCipher(key)
	out := make([]byte, len(in))

	decrypted := cipher.NewCBCDecrypter(c, iv)
	decrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}

// AESECBEncrypt 使用PKCS7填充
func AESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBEncrypter(c)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// AESECBDecrypt 去除PKCS7填充
func AESECBDecrypt(in, key []byte) []byte {
	c, err := aes.NewCipher(key)
	if err != nil {
		return nil
	}

	if len(in)%c.BlockSize() != 0 {
		return nil
	}

	out := make([]byte, len(in))

	decrypted := cipher2.NewECBDecrypter(c)
	decrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out)
}
