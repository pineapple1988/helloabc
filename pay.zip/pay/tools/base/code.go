package base

type LoginResultCode int

const (
	LoginResultSuccess             LoginResultCode = 0 // 登陆成功
	LoginResultFail                LoginResultCode = 1 // 登陆失败，需要检查日志
	LoginResultFailNeedSms         LoginResultCode = 2 // 需要短信
	LoginResultFailNeedImage       LoginResultCode = 3 // 需要图片
	LoginResultFailNeedSendSms     LoginResultCode = 4 // 需要手机去发送短信
	LoginResultFailNeedReceiveCall LoginResultCode = 5 // 需要接听电话
	LoginResultFailWrongAccount    LoginResultCode = 6 // 账号不存在
	LoginResultFailWrongPwd        LoginResultCode = 7 // 登陆密码不正确, 连续输错会锁卡
	LoginResultFailWrongSms        LoginResultCode = 8 // 验证码不正确
	LoginResultFailWrongFace       LoginResultCode = 9 // 人脸识别认证失败
)

type TransferResultCode int

const (
	TransferResultSuccess          TransferResultCode = 0 // 转账成功
	TransferResultUnknown          TransferResultCode = 1 // 转账结果未知，需要重新登陆，查询账单确定
	TransferResultFail             TransferResultCode = 2 // 转账失败,已知错误
	TransferResultFailNeedSms      TransferResultCode = 3 // 需要短信
	TransferResultFailNeedImage    TransferResultCode = 4 // 需要图片
	TransferResultFailWrongPwd     TransferResultCode = 5 // 支付密码不正确，连续错误会锁定密码
	TransferResultFailWrongSms     TransferResultCode = 6 // 验证码不正确
	TransferResultFailWrongFace    TransferResultCode = 7 // 人脸识别认证失败
	TransferResultFailNotLogin     TransferResultCode = 8 // 未登陆
	TransferResultFailWrongAccount TransferResultCode = 9 // 账号、户名不符
)
