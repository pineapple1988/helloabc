package tools

import (
	"math/rand"
	"time"
)

// RandBytes 随机生成[]byte
func RandBytes(n int) []byte {
	rand.Seed(time.Now().UnixNano())
	r := make([]byte, n)
	for i := 0; i < n; i++ {
		r[i] = byte(rand.Int())
	}
	return r
}

// RandBytesNoZero 随机生成[]byte不包含0
func RandBytesNoZero(n int) []byte {
	r := make([]byte, n)
	for i := 0; i < n; i++ {
		r[i] = byte(RandBetween(0x1, 0x100))
	}
	return r
}

// RandBetween 随机生成一个int [min, max)
func RandBetween(min, max int) int {
	if min > max || min == 0 || max == 0 {
		return 0
	}

	return RandIntn(max-min) + min
}

// RandIntn 与rand.Intn一样只是重设置了随机数种子
func RandIntn(n int) int {
	rand.Seed(time.Now().UnixNano())
	return rand.Intn(n)
}

// RandInt31 与rand.Int31
func RandInt31() int32 {
	rand.Seed(time.Now().UnixNano())
	return rand.Int31()
}

// RandInt63 与rand.Int63
func RandInt63() int64 {
	rand.Seed(time.Now().UnixNano())
	return rand.Int63()
}

// RandInt 与rand.Int一样只是重设置了随机数种子
func RandInt() int {
	rand.Seed(time.Now().UnixNano())
	return rand.Int()
}

// RandString 生成随机字符串
func RandString(count int) string {
	rndBytes := []byte("0123456789abcdefghijklmnopqrstuvwsyzABCDEFGHIGKLMNOPQRSTUVWSYZ")
	rndBytesLen := len(rndBytes)
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytes[RandIntn(rndBytesLen)])
	}

	return string(buffer)
}

// RandStringNoNum 生成随机字符串不包含数字
func RandStringNoNum(count int) string {
	rndBytesNoNum := []byte("abcdefghijklmnopqrstuvwsyzABCDEFGHIGKLMNOPQRSTUVWSYZ")
	rndBytesNoNumLen := len(rndBytesNoNum)
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndBytesNoNum[RandIntn(rndBytesNoNumLen)])
	}

	return string(buffer)
}

// RandHexString 生成只包含16进制数字的字符串
func RandHexString(count int) string {
	rndNumBytes := []byte("0123456789abcdef")
	rndNumBytesLen := len(rndNumBytes)
	var buffer []byte
	for i := 0; i < count; i++ {
		buffer = append(buffer, rndNumBytes[RandIntn(rndNumBytesLen)])
	}

	return string(buffer)
}

// RandFloat 生成一个比给定数字小的float32
func RandFloat(max float32) float32 {
	rand.Seed(time.Now().UnixNano())
	r := rand.Float32()
	for {
		if r > max {
			r -= max
		} else {
			return r
		}
	}
}
