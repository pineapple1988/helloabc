package tools

import (
	"pay/tools/log2"
	"fmt"
	"math/rand"
	"strconv"
	"strings"
)

// 型号					屏幕尺寸	分辨率（pt）	Reader	分辨率（px）	 渲染后（px）  PPI
// iPhone 5/5S/5C/SE	4.0寸	320 x 568	@2x	    640 x 1136	 空	         326
// iPhone 6/6S/7/8		4.7寸	375 x 667	@2x	    750 x 1334	 空	         326
// iPhone 6/6S/7/8 Plus	5.5寸	414 x 736	@3x	    1242 x 2208	 1080 x 1920 401
// iPhone X/XS			5.8寸	375 x 812	@3x	    1125 x 2436	 空	         458
// iPhone XR			6.1寸	414 x 896	@2x	    828 x 1792	 空	         326
// iPhone XS Max		6.5寸	414 x 896	@3x	    1242 x 2688	 空	         458

// iPhone6s以下不能升级iOS13

// https://www.theiphonewiki.com/wiki/Models

type cpu struct {
	Name string `json:"name"`
	Core int32  `json:"core"`
}

type iPhone struct {
	Name           string  `json:"name"`
	InternalName   string  `json:"internalName"`
	SizePt         string  `json:"sizePt"`
	SizePx         string  `json:"sizePx"`
	Scale          string  `json:"scale"`
	PhysicalMemory int64   `json:"physicalMemory"`
	DiskSpace      []int64 `json:"diskSpace"`
	CPU            cpu     `json:"CPU"`
}

type iOS struct {
	// https://www.theiphonewiki.com/wiki/Kernel
	KernelVersion string `json:"kernelVersion"`
	Uname         string `json:"uname"`
	Timestamp     int64  `json:"timestamp"`
	Mobile        string `json:"mobile"`
	// 下面两个都不正确
	// https://www.theiphonewiki.com/wiki/IBoot_(Bootloader)
	// https://en.wikipedia.org/wiki/Safari_version_history#Safari_3_3
	WebkitVersion string `json:"webkitVersion"`
}

var iPhoneMap map[string]iPhone
var model []string
var iOSMap map[string]iOS

func init() {
	// 系统版本直接使用最新的
	iOSMap = map[string]iOS{
		//"11.3": {
		//	KernelVersion: "17.5.0",
		//	Uname:         "Darwin Kernel Version 17.5.0: Tue Mar 13 21:32:11 PDT 2018; root:xnu-4570.52.2~8/RELEASE_ARM64_",
		//	Timestamp:     1836122112,
		//},
		//"12.0": {
		//	KernelVersion: "18.0.0",
		//	Uname:         "Darwin Kernel Version 18.0.0: Fri Aug 10 20:58:13 PDT 2018; root:xnu-4903.203.1~1/RELEASE_ARM64_",
		//},
		//"12.1": {
		//	KernelVersion: "18.2.0",
		//	Uname:         "Darwin Kernel Version 18.2.0: Mon Oct 8 08:27:41 PDT 2018; root:xnu-4903.223.3~2/RELEASE_ARM64_",
		//},
		//"12.2": {
		//	KernelVersion: "18.5.0",
		//	Uname:         "Darwin Kernel Version 18.5.0: Wed Mar 13 15:19:12 PDT 2019; root:xnu-4903.253.2~6/RELEASE_ARM64_",
		//},
		//"12.3": {
		//	KernelVersion: "18.6.0",
		//	Uname:         "Darwin Kernel Version 18.6.0: Thu Apr 25 21:37:28 PDT 2019; root:xnu-4903.263.2~1/RELEASE_ARM64_",
		//},
		//"12.4.2": {
		//	KernelVersion: "18.7.0",
		//	Uname:         "Darwin Kernel Version 18.7.0: Mon Aug 19 22:24:08 PDT 2019; root:xnu-4903.272.1~1/RELEASE_ARM64_",
		//	Timestamp:     1871347712,
		//},
		"13.0": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Mon Aug 12 20:19:35 PDT 2019; root:xnu-6153.0.103.12~1/RELEASE_ARM64_",
			Mobile:        "16A577",
			WebkitVersion: "608.2.11",
		},
		"13.1": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Tue Sep 3 21:52:14 PDT 2019; root:xnu-6153.2.3~2/RELEASE_ARM64_",
			Mobile:        "17A844",
			WebkitVersion: "608.2.11",
		},
		"13.1.1": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Tue Sep 3 21:52:14 PDT 2019; root:xnu-6153.2.3~2/RELEASE_ARM64_",
			Mobile:        "17A854",
			WebkitVersion: "608.2.11",
		},
		"13.1.2": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Tue Sep 3 21:52:14 PDT 2019; root:xnu-6153.2.3~2/RELEASE_ARM64_",
			Mobile:        "17A860",
			WebkitVersion: "608.2.11",
		},
		"13.1.3": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Tue Sep 3 21:52:14 PDT 2019; root:xnu-6153.2.3~2/RELEASE_ARM64_",
			Mobile:        "17A878",
			WebkitVersion: "608.2.11",
		},
		"13.2": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Wed Oct 9 22:42:11 PDT 2019; root:xnu-6153.42.1~1/RELEASE_ARM64_",
			Mobile:        "17B84",
			WebkitVersion: "608.2.11",
		},
		"13.2.2": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Wed Oct 9 22:42:11 PDT 2019; root:xnu-6153.42.1~1/RELEASE_ARM64_",
			Mobile:        "17B102",
			WebkitVersion: "608.2.11",
		},
		"13.2.3": {
			KernelVersion: "19.0.0",
			Uname:         "Darwin Kernel Version 19.0.0: Wed Oct 9 22:42:11 PDT 2019; root:xnu-6153.42.1~1/RELEASE_ARM64_",
			Mobile:        "17B111",
			WebkitVersion: "608.2.11",
		},
		"13.3": {
			KernelVersion: "19.2.0",
			Uname:         "Darwin Kernel Version 19.2.0: Mon Nov 4 17:44:49 PST 2019; root:xnu-6153.60.66~39/RELEASE_ARM64_",
			Mobile:        "17C54",
			WebkitVersion: "608.2.11",
		},
	}

	// A9  S8000 (Manufactured by Samsung Electronics)
	//	   S8003 (Manufactured by TSMC)
	// A10 T8010
	// A11 T8015
	// A12 T8020
	// A13 T8030
	iPhone6s := iPhone{
		Name:           "iPhone 6s",
		InternalName:   "N71mAP",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		Scale:          "2.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128,
		},
		CPU: cpu{
			Name: "S8003",
			Core: 2,
		},
	}
	iPhone6sPlus := iPhone{
		Name:           "iPhone 6s Plus",
		InternalName:   "N66mAP",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128,
		},
		CPU: cpu{
			Name: "S8003",
			Core: 2,
		},
	}
	iPhoneSE := iPhone{
		Name:           "iPhone SE",
		InternalName:   "N69AP",
		SizePt:         "320*568",
		Scale:          "2.0",
		SizePx:         "640*1136",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 16, 1024 * 1024 * 1024 * 64,
		},
		CPU: cpu{
			Name: "S8003",
			Core: 2,
		},
	}

	iPhone7 := iPhone{
		Name:           "iPhone 7",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		Scale:          "2.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 32, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8010",
			Core: 2,
		},
	}
	iPhone7Plus := iPhone{
		Name:           "iPhone 7 Plus",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 32, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8010",
			Core: 2,
		},
	}
	// todo 测试所有iphone机型中的核心数
	// iPhone8以后的手机没有进行测试 2+4 4个能效核心
	iPhone8 := iPhone{
		Name:           "iPhone 8",
		SizePt:         "375*667",
		SizePx:         "750*1334",
		Scale:          "2.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 2,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 11024 * 024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8015",
			Core: 2,
		},
	}
	iPhone8Plus := iPhone{
		Name:           "iPhone 8 Plus",
		SizePt:         "414*736",
		SizePx:         "1242*2208",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8015",
			Core: 2,
		},
	}
	iPhoneX := iPhone{
		Name:           "iPhone X",
		SizePt:         "375*812",
		SizePx:         "1125*2436",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8015",
			Core: 2,
		},
	}

	iPhoneXS := iPhone{
		Name:           "iPhone XS",
		SizePt:         "375*812",
		SizePx:         "1125*2436",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 4,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneXR := iPhone{
		Name:           "iPhone XR",
		SizePt:         "414*896",
		SizePx:         "828*1792",
		Scale:          "2.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 3,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneXSMAX := iPhone{
		Name:           "iPhone XS MAX",
		SizePt:         "414*896",
		SizePx:         "1242*2688",
		Scale:          "3.0",
		PhysicalMemory: 1024 * 1024 * 1024 * 4,
		DiskSpace: []int64{
			1024 * 1024 * 1024 * 64, 1024 * 1024 * 1024 * 128, 1024 * 1024 * 1024 * 256,
		},
		CPU: cpu{
			Name: "T8020",
			Core: 2,
		},
	}
	iPhoneMap = make(map[string]iPhone, 0x10)
	iPhoneMap["iPhone8,1"] = iPhone6s

	iPhoneMap["iPhone8,2"] = iPhone6sPlus

	iPhoneMap["iPhone8,4"] = iPhoneSE

	iPhone7.InternalName = "D10AP"
	iPhoneMap["iPhone9,1"] = iPhone7

	iPhone7.InternalName = "D101AP"
	iPhoneMap["iPhone9,3"] = iPhone7

	iPhone7Plus.InternalName = "D11AP"
	iPhoneMap["iPhone9,2"] = iPhone7Plus

	iPhone7Plus.InternalName = "D111AP"
	iPhoneMap["iPhone9,4"] = iPhone7Plus

	iPhone8.InternalName = "D20AP"
	iPhoneMap["iPhone10,1"] = iPhone8

	iPhone8.InternalName = "D201AP"
	iPhoneMap["iPhone10,4"] = iPhone8

	iPhone8Plus.InternalName = "D21AP"
	iPhoneMap["iPhone10,2"] = iPhone8Plus

	iPhone8Plus.InternalName = "D211AP"
	iPhoneMap["iPhone10,5"] = iPhone8Plus

	iPhoneX.InternalName = "D22AP"
	iPhoneMap["iPhone10,3"] = iPhoneX

	iPhoneX.InternalName = "D221AP"
	iPhoneMap["iPhone10,6"] = iPhoneX

	iPhoneXR.InternalName = "N841AP"
	iPhoneMap["iPhone11,8"] = iPhoneXR

	iPhoneXS.InternalName = "D321AP"
	iPhoneMap["iPhone11,2"] = iPhoneXS

	iPhoneXSMAX.InternalName = "D331pAP"
	iPhoneMap["iPhone11,6"] = iPhoneXSMAX

	// 暂时只加入这些，不使用带faceId的iphone
	model = []string{
		"iPhone8,1",
		"iPhone8,2",
		"iPhone8,4",
		"iPhone9,1",
		"iPhone9,3",
		"iPhone9,2",
		"iPhone9,4",
		"iPhone10,1",
		"iPhone10,4",
		"iPhone10,2",
		"iPhone10,5",
	}
}

// IosDevice 只存储跟硬件相关的讯息，软件生成的不放入这个里面
type IosDevice struct {
	IMEI               string `json:"imei"`
	IMSI               string `json:"imsi"`
	IDFA               string `json:"idfa"`
	IDFV               string `json:"idfv"`
	SysVer             string `json:"sysVer"`
	Model              string `json:"model"` // iPhone9,3
	Name               string `json:"name"`  // jj的 iPhone
	BluetoothMac       string `json:"bluetoothMac"`
	WifiMac            string `json:"wifiMac"`
	WifiName           string `json:"wifiName"`
	OtherMac           string `json:"otherMac"`
	RealPhysicalMemory int64  `json:"realPhysicalMemory"` // 实际内存大小
	PhysicalMemory     int64  `json:"physicalMemory"`     // 规格内存大小
	RealDiskSpace      int64  `json:"realDiskSpace"`      // 实际存储大小
	DiskSpace          int64  `json:"diskSpace"`          // 规格存储大小
	DocNode            int32  `json:"docNode"`            // 文件inode /var/mobile/Containers/Data/Application/26B7CB66-933D-4E8A-A432-49B82C115F56/Documents
	PreNode            int32  `json:"preNode"`            // 文件inode /var/mobile/Containers/Data/Application/26B7CB66-933D-4E8A-A432-49B82C115F56/Documents/Preferences
	En0Ipv6            string `json:"en0Ipv6"`
	En0Ipv4            string `json:"en0Ipv4"`
	En2Ipv6            string `json:"en2Ipv6"`
	En2Ipv4            string `json:"en2Ipv4"`
	Awdl0Ipv6          string `json:"awdl0Ipv6"`
	Utun0Ipv6          string `json:"utun0Ipv6"`
}

// Width 根据size获取宽度
func Width(size string) int {
	i, err := strconv.Atoi(strings.Split(size, "*")[0])
	if err != nil {
		return 0
	}
	return i
}

// Height 根据size获取高度
func Height(size string) int {
	i, err := strconv.Atoi(strings.Split(size, "*")[1])
	if err != nil {
		return 0
	}
	return i
}

// NewSysVersion 随机一个系统版本
func NewSysVersion() string {
	iosVersions := []string{}
	for k := range iOSMap {
		iosVersions = append(iosVersions, k)
	}
	r := RandIntn(len(iosVersions))
	return iosVersions[r]
}

// NewModel 随机一个model
func NewModel() string {
	return model[RandIntn(len(model))]
}

// NewOwnerName 随机一个机主名字
func NewOwnerName() string {
	return RandStringNoNum(RandBetween(2, 5)) + "的 iPhone"
}

// NewMacAddress 随机一个MAC地址
func NewMacAddress() string {
	var arr []string
	for i := 0; i < 6; i++ {
		n := RandIntn(255)
		if i == 0 && n%2 != 0 {
			n++
		}

		arr = append(arr, fmt.Sprintf("%.2x", n))
	}

	return strings.Join(arr, ":")
}

// NewWifiName 随机一个wifi名字
func NewWifiName(mac string) string {
	brand := []string{
		"TP-Link",
		"Tenda",
		"MERCURY",
	}
	// wifimac后6位
	s := strings.ReplaceAll(mac, ":", "")
	s = s[len(s)-6:]
	s = strings.ToUpper(s)

	return brand[RandIntn(len(brand))] + "_" + s
}

// NewPhysicalMemory 随机一个内存大小
func NewPhysicalMemory(model string) int64 {
	return iPhoneMap[model].PhysicalMemory
}

// NewDiskSpace 随机一个存储大小
func NewDiskSpace(model string) int64 {
	return iPhoneMap[model].DiskSpace[RandIntn(len(iPhoneMap[model].DiskSpace))]
}

// PhoneName 获取手机名字 eg iPhone 7
func PhoneName(model string) string {
	return iPhoneMap[model].Name
}

// PhysicalMemory 获取手机内存
func PhysicalMemory(model string) int64 {
	return iPhoneMap[model].PhysicalMemory
}

// ScreenPt 获取手机屏幕大小pt
func ScreenPt(model string) string {
	return iPhoneMap[model].SizePt
}

// ScreenPx 获取手机屏幕大小px
func ScreenPx(model string) string {
	return iPhoneMap[model].SizePx
}

// Scale 获取手机屏幕密度
func Scale(model string) string {
	return iPhoneMap[model].Scale
}

// ScreenWidthPt 获取手机pt宽度
func ScreenWidthPt(model string) int {
	phone := iPhoneMap[model]
	return Width(phone.SizePt)
}

// ScreenHeightPt 获取手机pt高度
func ScreenHeightPt(model string) int {
	phone := iPhoneMap[model]
	return Height(phone.SizePt)
}

// ScreenWidthPx 获取手机px宽度
func ScreenWidthPx(model string) int {
	phone := iPhoneMap[model]
	return Width(phone.SizePx)
}

// ScreenHeightPx 获取手机px高度
func ScreenHeightPx(model string) int {
	phone := iPhoneMap[model]
	return Height(phone.SizePx)
}

// IsPhoneX 判断是否刘海屏幕
func IsPhoneX(model string) bool {
	phone := iPhoneMap[model]
	iphoneXname := []string{
		"iPhone X", "iPhone XS", "iPhone XS MAX", "iPhone XR",
	}
	for _, name := range iphoneXname {
		if phone.Name == name {
			return true
		}
	}
	return false
}

// CPUCore 获取手机核心数
func CPUCore(model string) int32 {
	return iPhoneMap[model].CPU.Core
}

// CPUFreq cpu频率
func CPUFreq() int32 {
	return 0
}

// InternalName iphone内部代号
func InternalName(model string) string {
	return iPhoneMap[model].InternalName
}

// WebKitVersion webkit版本
func WebKitVersion(sysVer string) string {
	return iOSMap[sysVer].WebkitVersion
}

// Uname 内核名称
func Uname(sysVer, model string) string {
	return iOSMap[sysVer].Uname + iPhoneMap[model].CPU.Name
}

// KernelVersion 内核版本
func KernelVersion(sysVer string) string {
	return iOSMap[sysVer].KernelVersion
}

// KernelTimestamp 内核截止支持时间(猜测)
func KernelTimestamp(sysVer string) int64 {
	return iOSMap[sysVer].Timestamp
}

// Mobile 手机的一个数据
func Mobile(sysVer string) string {
	return iOSMap[sysVer].Mobile
}

// Mcc 国家代号
func Mcc(IMSI string) string {
	return IMSI[:3]
}

// Mnc 不同运营商不同数字
func Mnc(IMSI string) string {
	return IMSI[3:5]
}

// CarrierByIMSI 根据不同IMSI获取到不同运营商
func CarrierByIMSI(IMSI string) string {
	if len(IMSI) > 0 {
		mcc := IMSI[:3]
		mnc := IMSI[3:5]
		if mcc != "460" {
			log2.Errorf("mcc != 460开始不是中国的电话卡, %+v", mcc)
			return ""
		}

		// 中国移动系统使用00、02、04、07
		// 中国联通GSM系统使用01、06、09
		// 中国电信CDMA系统使用03、05、电信4G使用11
		// 中国铁通系统使用20
		switch mnc {
		case "00", "02", "04", "07":
			return "中国移动"
		case "01", "06", "09":
			return "中国联通"
		case "03", "05", "11":
			return "中国电信"
		default:
			log2.Errorf("未知mnc，%+v", mnc)
			return ""
		}
	} else {
		log2.Error("imsi == nil")
		return ""
	}
}

// CarrierCode 根据运营商名字返回mnc
func CarrierCode(carrier string) string {
	r := rand.Int31() % 3
	switch carrier {
	case "中国移动":
		return []string{"00", "02", "07"}[r]
	case "中国联通":
		return []string{"01", "06", "09"}[r]
	case "中国电信":
		return []string{"03", "05", "11"}[r]
	default:
		return "01"
	}
}

// 根据手机号判断运营商
// https://zh.wikipedia.org/wiki/%E4%B8%AD%E5%9B%BD%E5%86%85%E5%9C%B0%E7%A7%BB%E5%8A%A8%E7%BB%88%E7%AB%AF%E9%80%9A%E8%AE%AF%E5%8F%B7%E6%AE%B5#%E4%B8%AD%E5%9B%BD%E7%A7%BB%E5%8A%A8
var (
	// 中国移动
	mobileAry = []string{
		"1340", "1341", "1342", "1343", "1344", "1345", "1346", "1347", "1348",
		"135", "136", "137", "138", "139", "147", "150", "151", "152", "157",
		"158", "159", "172", "178", "182", "183", "184", "187", "188", "198",
		"165", "1703", "1705", "1706",
	}
	// 中国联通
	unionAry = []string{
		"130", "131", "132", "145", "155", "156", "166", "171", "175", "176",
		"185", "186",
		"167", "1704", "1707", "1708", "1709",
	}
	// 中国电信
	telcomAry = []string{
		"133", "149", "153", "173", "177", "180", "181", "189", "191", "199",
		"162", "1700", "1701", "1702",
	}
)

// CarrierByPhoneNum 根据手机号获取到运营商
func CarrierByPhoneNum(phoneNumber string) string {
	for _, s := range mobileAry {
		if strings.HasPrefix(phoneNumber, s) {
			return "中国移动"
		}
	}

	for _, s := range unionAry {
		if strings.HasPrefix(phoneNumber, s) {
			return "中国联通"
		}
	}

	for _, s := range telcomAry {
		if strings.HasPrefix(phoneNumber, s) {
			return "中国电信"
		}
	}

	return "中国移动"
}

// NewIPV4 创建一个本地地址
func NewIPV4() string {
	return "192.168.0." + strconv.Itoa(RandIntn(128))
}
