package tools

import (
	"bytes"
	uuid "github.com/satori/go.uuid"
	"golang.org/x/text/encoding/charmap"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
	"io/ioutil"
	"net/url"
	"sort"
	"strings"
)

// NewUUID 生成一个新的UUID
func NewUUID() string {
	u,_:= uuid.NewV4()
	return u.String()
}

// NewUUIDUpper 生成一个新的UUID然后转换成大写的
func NewUUIDUpper() string {
	u,_:= uuid.NewV4()
	return strings.ToUpper(u.String())
}

// GBK2UTF8 gbk转换为utf-8编码
func GBK2UTF8(s []byte) ([]byte, error) {
	t := transform.NewReader(bytes.NewReader(s), simplifiedchinese.GBK.NewDecoder())
	d, err := ioutil.ReadAll(t)
	if err != nil {
		return nil, err
	}

	return d, nil
}

// UTF82ISO88591 utf-8转换为ISO 8859-1编码
func UTF82ISO88591(str string) string {
	reader := transform.NewReader(strings.NewReader(str), charmap.ISO8859_1.NewDecoder())
	b, _ := ioutil.ReadAll(reader)
	return string(b)
}

// Form2Str url.Values toString不encode
func Form2Str(v *url.Values) string {
	if v == nil {
		return ""
	}
	var buf strings.Builder
	keys := make([]string, 0, len(*v))
	for k := range *v {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		vs := (*v)[k]
		for _, v := range vs {
			if buf.Len() > 0 {
				buf.WriteByte('&')
			}
			buf.WriteString(k)
			buf.WriteByte('=')
			buf.WriteString(v)
		}
	}
	return buf.String()
}
