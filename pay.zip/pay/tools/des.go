package tools

import (
	"pay/tools/cipher2"
	"crypto/cipher"
	"crypto/des"
)

// DESECBEncrypt des ecb 加密并使用PKCS7填充
func DESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBEncrypter(c)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// DESECBDecrypt des ecb 解密并去除PKCS7填充
func DESECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBDecrypter(c)
	encrypted.CryptBlocks(out, in)

	return pkcs7Unpad(out), nil
}

// DESCBCEncrypt des cbc 加密并使用PKCS7填充
func DESCBCEncrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher.NewCBCEncrypter(c, iv)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// DESCBCDecrypt des cbc 解密并去除PKCS7填充
func DESCBCDecrypt(in, key, iv []byte) ([]byte, error) {
	c, err := des.NewCipher(key)
	if err != nil {
		return nil, err
	}

	out := make([]byte, len(in))

	decrypter := cipher.NewCBCDecrypter(c, iv)
	decrypter.CryptBlocks(out, in)

	return pkcs7Unpad(out), nil
}

// TripleDESECBEncrypt 3DES ECB加密, 使用PKCS7填充
func TripleDESECBEncrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	in = pkcs7Pad(in, c.BlockSize())

	out := make([]byte, len(in))
	encrypted := cipher2.NewECBEncrypter(c)
	encrypted.CryptBlocks(out, in)

	return out, nil
}

// TripleDESECBDecrypt 3DES ECB解密, 去除PKCS7填充
func TripleDESECBDecrypt(in, key []byte) ([]byte, error) {
	c, err := des.NewTripleDESCipher(key)
	if err != nil {
		return nil, err
	}

	out := make([]byte, len(in))

	decrypter := cipher2.NewECBDecrypter(c)
	decrypter.CryptBlocks(out, in)

	return pkcs7Unpad(out), nil
}
