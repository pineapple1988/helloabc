import struct
import binascii as ba
import sys

if len(sys.argv) != 2:
    print 'Usage: xxx.py MAC_ELF_FILE_NAME'
    print '  xxx.py mac.elf'
    sys.exit(1)
    

out = 'var g_ld = new Uint32Array(['

with open(sys.argv[1],'rb') as fr:
    while True:
        data = fr.read(4)
        if len(data) <= 0:
            break
        data = struct.unpack('<L',data)[0]
        #print hex(data)
        hd = hex(data)
        if hd.endswith('L'):
            hd = hd[:-1]
        out += hd
        out += ','

out = out[:-1]

out += ']);'

with open('ld.js','w') as fw:
    fw.write(out)
