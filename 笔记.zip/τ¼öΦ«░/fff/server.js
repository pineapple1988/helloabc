var http = require('http');
var fs = require('fs');
var path = require('path');
var url = require("url");
var options = process.argv;

if (options.length < 4)
{
	console.log("usage: node server.js ip port [file]");
	process.exit(-1);
}

var listenip = options[2];
var listenport = options[3];
var onlydownload = "";

if (options.length == 5) {
	onlydownload = options[4];
}

String.prototype.endWith = function (endStr) {
	var d = this.length-endStr.length;
	return (d >= 0 && this.lastIndexOf(endStr) == d);
}

function log2file(txt, err) {
	var file = "server"+(err?"_err":"")+".log";
	var logmsg = CurrentTime() + ": " + txt;
	console.log(logmsg);
	fs.appendFileSync(file, logmsg + "\n");
}

function CurrentTime()
{
	var now = new Date();
	var year = now.getFullYear();
	var month = now.getMonth() + 1;
	var day = now.getDate();
	var hh = now.getHours();
	var mm = now.getMinutes();
	var ss = now.getSeconds();

	var clock = year + "-";

	if (month < 10) clock += "0";
	clock += month + "-";

	if (day < 10) clock += "0";
	clock += day + " ";

	if (hh < 10) clock += "0";
	clock += hh + ":";

	if (mm < 10) clock += "0";
	clock += mm + ":";

	if (ss < 10) clock += "0";
	clock += ss;

	return clock;
}

try {
	http.createServer(function(request, response) {
	var t = CurrentTime();
	var ip = (request.headers && request.headers["x-real-ip"]) || 
			 (request.headers && request.headers["x-forwarded-for"]) ||
			 (request.connection && request.connection.remoteAddress) ||
			 (request.socket && request.socket.remoteAddress) ||
			 (request.connection && request.connection.socket && request.connection.socket.remoteAddress);

	    var pathname = url.parse(request.url).pathname;
	    var realPath = "." + pathname;

		//如果是日志查看，则返回日志
		if (pathname == "/log") {

			fs.stat("./server.log", function (err, stat) {
				if (err) {
					var refresh = 
						"<script language=\"javascript\">" +
						"setTimeout(\"location.href='/log'\", 5000)" +
						"</script>";
					
					var subdata = "no log";
					subdata = "<html>"+refresh+"<body><pre>\n" + subdata;
					subdata += "</pre></body></html>\n";
					
					response.setHeader('Content-Length', subdata.length);
					response.setHeader('Content-Type', 'text/html');
					response.setHeader('Connection', 'close');
					response.writeHead(200);
					response.write(subdata, "binary");
					response.end();
				}
				else {
					fs.open("./server.log", "r", function(err, fd) {
						var buffer = Buffer.alloc(1024, 0);
						var position = 0;
						var length = stat.size;

						if (stat.size > 1024) {
							position = stat.size - 1024;
							length = 1024;
						}
						fs.read(fd, buffer, 0, length, position, function(err, byteRead, data) {
							var logstr = data.toString();
							var i = 0;
							var fromIndex = logstr.length - 1;
							
							while (1) {
								var idx = logstr.lastIndexOf('\n', fromIndex);
								if (idx != -1 && idx > 0) {
									i++;
									fromIndex = idx - 1;
								}
								else {
									fromIndex = 0;
									break;
								}
							
								if (i > 10) {
									break;
								}
							}
							
							var refresh = 
								"<script language=\"javascript\">" +
								"setTimeout(\"location.href='/log'\", 5000)" +
								"</script>";
							
							var subdata = logstr.substr(fromIndex==0?fromIndex:(fromIndex+2));
							subdata = "<html>"+refresh+"<body><pre>\n" + subdata;
							subdata += "</pre></body></html>\n";
							
							response.setHeader('Content-Length', subdata.length);
							response.setHeader('Content-Type', 'text/html');
							response.setHeader('Connection', 'close');
							response.writeHead(200);
							response.write(subdata, "binary");
							response.end();
							
						});
					});
				}
			});
			return;
		}

		//如果指定了下载的文件，就只下载这个文件
	    if (onlydownload != "" && pathname != "/" + onlydownload) {
				response.setHeader('Location', "http://" + listenip + ":" + listenport + "/" + onlydownload);
				response.setHeader('Connection', 'close');
				response.writeHead(307);
				response.end();
				return;
	    }

		fs.exists(realPath, function (exists) {
			if (!exists) {
				response.setHeader('Content-Type', 'text/plain');
				response.setHeader('Connection', 'close');
				response.writeHead(404);
				response.write(pathname + " not found!");
				response.end();
				log2file(ip + " " + pathname + " not found!", true);
			} else {
				fs.stat(realPath, function (err, stat){
					if (!err && (realPath != "./server.js" && realPath != "./start.bat" && realPath != "./start.sh")) {
						var stream = fs.createReadStream(realPath);

						if (stream) {
							response.setHeader('Content-Length', stat.size);
							if (realPath.endWith(".htm")  ||
								realPath.endWith(".html") ||
								realPath.endWith(".txt")  ||
								realPath.endWith(".log")) {
								response.setHeader('Content-Type', 'text/html');
							}
							else if (realPath.endWith(".js")) {
								response.setHeader('Content-Type', 'text/javascript');
							}
							else {
								response.setHeader('Content-Type', 'application/octet-stream');
							}
							response.setHeader('Connection', 'close');
							response.writeHead(200);

							stream.pipe(response, {end: false});

							stream.on("end", function() {
								response.end();
								log2file(ip + " " + pathname + ", size " + stat.size + " send success");
							});
						}
						else {
							response.setHeader('Content-Type', 'text/plain');
							response.setHeader('Connection', 'close');
							response.writeHead(500);
							response.write("read file error");
							response.end();
							log2file(ip + " " + pathname + " read file error!", true);
						}
					} 
					else {
						response.setHeader('Content-Type', 'text/plain');
						response.setHeader('Connection', 'close');
						response.writeHead(500);
						response.write("server error");
						response.end();
						log2file(ip + " " + pathname + " server error!", true);
					}
				});
			}
		});

	}).listen(listenport, listenip);
}
catch(e) {
	log2file("listen on " + listenip + ":" + listenport + " ERROR", true);
	process.exit(-1);
}

log2file("listen on " + listenip + ":" + listenport + " OK");

