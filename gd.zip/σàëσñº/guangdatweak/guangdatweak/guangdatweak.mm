#line 1 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/guangda/guangdatweak/guangdatweak/guangdatweak.xm"


#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonCryptor.h>
#import "./tools/WJTool.h"
#import "./tools/Log.h"

static __attribute__((constructor)) void _logosLocalCtor_e8d54f5f(int __unused argc, char __unused **argv, char __unused **envp){
     NSLog(@" 光大银行5.0入口");
}



#include <substrate.h>
#if defined(__clang__)
#if __has_feature(objc_arc)
#define _LOGOS_SELF_TYPE_NORMAL __unsafe_unretained
#define _LOGOS_SELF_TYPE_INIT __attribute__((ns_consumed))
#define _LOGOS_SELF_CONST const
#define _LOGOS_RETURN_RETAINED __attribute__((ns_returns_retained))
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif

@class PublicEncryptTool; @class TKSM2Helper; @class SYHttpTool; 
static id (*_logos_orig$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$)(_LOGOS_SELF_TYPE_NORMAL TKSM2Helper* _LOGOS_SELF_CONST, SEL, id, id); static id _logos_method$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$(_LOGOS_SELF_TYPE_NORMAL TKSM2Helper* _LOGOS_SELF_CONST, SEL, id, id); static void (*_logos_meta_orig$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, bool, bool, id, id, id); static void _logos_meta_method$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, bool, bool, id, id, id); static id (*_logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id, id); static id _logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id, id); static id (*_logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id); static id _logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id); static id (*_logos_meta_orig$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$)(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id); static id _logos_meta_method$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST, SEL, id, id); 

#line 13 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/guangda/guangdatweak/guangdatweak/guangdatweak.xm"


static id _logos_method$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$(_LOGOS_SELF_TYPE_NORMAL TKSM2Helper* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, id arg2){
    NSLog(@"-[<TKSM2Helper: %p> sm2PublicKeyEncryptData:%@ pubKey:%@]", self, arg1, arg2);
    id r = _logos_orig$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$(self, _cmd, arg1, arg2);
    return r;
}





static void _logos_meta_method$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, bool arg2, bool arg3, id arg4, id arg5, id arg6){
    NSLog(@"+[<SYHttpTool: %p> post:%@ showLoading:%d needHttpToolManage:%d parameters:%@ success:%@ failure:%@]", self, arg1, arg2, arg3, arg4, arg5, arg6);
    _logos_meta_orig$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$(self, _cmd, arg1, arg2, arg3, arg4, arg5, arg6);
}

















static id _logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, id arg2, id arg3){
        NSLog(@"+[<PublicEncryptTool: %p> cebSm4Encrypt:%@ sm4KeyString:%@ lastFourTime:%@]", self, arg1, arg2, arg3);
    
        NSLog(@"PublicEncryptTool cebSm4Encrypt==== %@",arg1);
        NSLog(@"PublicEncryptTool sm4KeyString==== %@",arg2);


        if(arg1 != nil){
            [Log appendStr:arg1 fileName:@"myLog.txt"];
            
        }else{
            
            [Log appendStr:@"aaaaaaaaaaaaaaaaaaaaa" fileName:@"myLog.txt"];
        }
        
        id r = _logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$(self, _cmd, arg1, arg2, arg3);
        return r;
}

static id _logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, id arg2){
    NSLog(@"+[<PublicEncryptTool: %p> cebSm4Decode:%@ sm4KeyString:%@]", self, arg1, arg2);
    id r = _logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$(self, _cmd, arg1, arg2);
    
    NSLog(@"PublicEncryptTool cebSm4Decode==== %@",arg1);
    NSLog(@"PublicEncryptTool cebSm4Decode==== %@",arg2);
    NSLog(@"PublicEncryptTool cebSm4Decode==== %@",r);
    
    
           if(arg1 != nil){
               [Log appendStr:r fileName:@"jiemi.txt"];
           }else{

               [Log appendStr:@"aaaaaaaaaaaaaaaaaaaaa" fileName:@"jiemi.txt"];
           }
           
    return r;
}

static id _logos_meta_method$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$(_LOGOS_SELF_TYPE_NORMAL Class _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, id arg1, id arg2){
    NSLog(@"+[<PublicEncryptTool: %p> calculateSm4key:%@ timeString:%@]", self, arg1, arg2);
    NSLog(@"PublicEncryptTool calculateSm4key==== %@",arg1);
    NSLog(@"PublicEncryptTool timeString==== %@",arg2);
    id r = _logos_meta_orig$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$(self, _cmd, arg1, arg2);
    
    return r;
}

















static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$TKSM2Helper = objc_getClass("TKSM2Helper"); { MSHookMessageEx(_logos_class$_ungrouped$TKSM2Helper, @selector(sm2PublicKeyEncryptData:pubKey:), (IMP)&_logos_method$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$, (IMP*)&_logos_orig$_ungrouped$TKSM2Helper$sm2PublicKeyEncryptData$pubKey$);}Class _logos_class$_ungrouped$SYHttpTool = objc_getClass("SYHttpTool"); Class _logos_metaclass$_ungrouped$SYHttpTool = object_getClass(_logos_class$_ungrouped$SYHttpTool); { MSHookMessageEx(_logos_metaclass$_ungrouped$SYHttpTool, @selector(post:showLoading:needHttpToolManage:parameters:success:failure:), (IMP)&_logos_meta_method$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$, (IMP*)&_logos_meta_orig$_ungrouped$SYHttpTool$post$showLoading$needHttpToolManage$parameters$success$failure$);}Class _logos_class$_ungrouped$PublicEncryptTool = objc_getClass("PublicEncryptTool"); Class _logos_metaclass$_ungrouped$PublicEncryptTool = object_getClass(_logos_class$_ungrouped$PublicEncryptTool); { MSHookMessageEx(_logos_metaclass$_ungrouped$PublicEncryptTool, @selector(cebSm4Encrypt:sm4KeyString:lastFourTime:), (IMP)&_logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$, (IMP*)&_logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Encrypt$sm4KeyString$lastFourTime$);}{ MSHookMessageEx(_logos_metaclass$_ungrouped$PublicEncryptTool, @selector(cebSm4Decode:sm4KeyString:), (IMP)&_logos_meta_method$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$, (IMP*)&_logos_meta_orig$_ungrouped$PublicEncryptTool$cebSm4Decode$sm4KeyString$);}{ MSHookMessageEx(_logos_metaclass$_ungrouped$PublicEncryptTool, @selector(calculateSm4key:timeString:), (IMP)&_logos_meta_method$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$, (IMP*)&_logos_meta_orig$_ungrouped$PublicEncryptTool$calculateSm4key$timeString$);}} }
#line 109 "/Users/dadadadidigua/Desktop/IOS_WORK/ALLBANK/guangda/guangdatweak/guangdatweak/guangdatweak.xm"
